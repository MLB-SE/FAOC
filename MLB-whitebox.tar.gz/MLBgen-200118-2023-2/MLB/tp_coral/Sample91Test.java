import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-0.008315785579988032,62.68590037754136 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(-0.012603270747263196,7.87178729795712 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(-0.015782091694630296,-21.558738139081328 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark91(-0.026348732717207606,28.24798514959093 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark91(-0.0454472474455514,77.51357535282416 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark91(-0.05697662253601754,22.705125922722058 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark91(-0.05767000690353758,-15.765664990865142 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark91(-0.06997757318203864,-50.19550488425465 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark91(-0.08585529622033981,-56.46281246839594 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark91(-0.09504077506505568,21.896107800063497 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark91(-0.09711994836158694,-66.27102951215684 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark91(-0.09931300652023207,18.892163521207337 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark91(-0.10080118436221093,78.43901515538262 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark91(-0.11091511797811437,3.030677535611679 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark91(-0.11724805362045604,-135.21351545272398 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark91(-0.14415761505478694,84.82767898554937 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark91(-0.15009218540590957,78.38972415433892 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark91(-0.15798901499437962,-43.824308135262726 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark91(-0.15816686318079642,-1.5707963267948966 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark91(-0.16161848594682066,-48.69728998258469 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark91(-0.16189720359025278,1.5707963267948974 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark91(-0.1686691680255548,-68.9463692109499 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark91(-0.17677590459996947,50.44250047835234 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark91(-0.19369186126680638,84.62930978565761 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark91(-0.19414506137612553,0.19414506137612553 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark91(-0.2003977757913873,0.0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark91(-0.20976354917972662,2481.979722326679 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark91(-0.23292438866569043,-86.44219176158532 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark91(-0.2715721176108019,87.66058147105832 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark91(-0.3136539782370871,-4.398735600197007 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark91(-0.31373792687211843,88.27833222738633 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark91(-0.3609146293974981,70.33153169887055 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark91(-0.38481723149776315,-83.15389786439037 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark91(-0.39299203023775386,-85.21582359326302 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark91(-0.4106340372242448,-3.552226690814038 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark91(-0.42099182812353036,49.7808858698524 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark91(-0.4237177937191632,-39.89782717740154 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark91(-0.44230135344403054,-68.97759582312389 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark91(-0.4892596333818977,6.434576813554109 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark91(-0.49096316113248517,-17.16396642732244 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark91(-0.4982648675217707,-42.2560375827835 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark91(-0.5039060818692076,40.336797753131435 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark91(-0.5168327750006585,96.87253948628293 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark91(-0.5309649148733837,-100.0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark91(-0.5342308960179222,44.51652804627503 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark91(-0.5399470486576591,1.5707963267948966 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark91(-0.5411654645976114,-27.305493278809664 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark91(-0.5573436300330472,-53.96441874105953 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark91(-0.5690233237284246,4.71238898038469 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark91(-0.5787130089388526,-1.5707963267948966 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark91(-0.5821233034881391,-36.942049013489296 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark91(-0.5843181358606415,-2589.5435257848326 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark91(-0.5988875536800419,-41.439908753456976 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark91(-0.6014250901898066,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark91(-0.6330044999248092,-79.17282083966964 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark91(-0.6430538136288588,-60.33346071995229 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark91(-0.6930663454981606,-31.70240916312521 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark91(-0.7054307326521746,0.7054307326521746 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark91(-0.7184029617551307,25.851144190473477 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark91(-0.7264939810364979,-86.38317165924978 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark91(-0.7313253294468999,0.7313253294468998 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark91(-0.7476589781778344,0.7476589781778344 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark91(-0.7528823199996919,84.07011932692473 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark91(-0.7715573677259269,-3.913213384194345 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark91(-0.7932279077355772,61.722686193126556 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark91(-0.8000362389141407,-41.64074073558145 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark91(-0.80665338456842,1.5707963267948966 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark91(-0.8209269331987648,-49.44455552423793 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark91(-0.8615394941767063,-68.25349888479874 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark91(-0.8950399213911057,-16.603003189340072 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark91(-0.8972756307445677,-54.30435074177105 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark91(-0.9030504338174825,65.07039529156818 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark91(-0.9203194385773593,96.46905111884453 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark91(-0.9351682471713403,-27.069366310776275 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark91(-0.9385897812338748,1.5707963267948732 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark91(-0.9402921608544422,-41.780996657521754 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark91(-0.9458611655821013,-30.95551530368799 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark91(-0.9677863344306324,19.817390187134848 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark91(-0.9694474243514659,-81.84982954624016 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark91(-0.9701733866473538,8.4E-323 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark91(-0.9788671369947224,78.76040249613987 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark91(-0.9796327643415133,26.372152597067114 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark91(-0.988450939568414,0.0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark91(-0.9897460510171938,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark91(-0.998680766919752,-112.0986547623128 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,0.0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-0.5309649148733837 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-100.0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,100.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,1.2163433832898076 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-1.5707963267948966 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,1.5707963267948966 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,1.5707963267948968 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,18.84955614623348 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,2599.7420587036304 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-26.193638614699992 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-27.743368967434755 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,49.73451754256331 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-50.149621333779564 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark91(-10.00695760183126,-92.84341752579397 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark91(-10.009634052351146,65.29372713337013 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark91(-1.0010218804288158,2578.9724845227774 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark91(-10.018646104803054,-19.574904219323315 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark91(-10.034631168557224,23.611818525966882 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark91(-1.0046256443878399,-92.53247539874417 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark91(-100.52670384822905,-62.83185307179485 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark91(-102.10176124166809,1.5707963267948983 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark91(-1.0216783675385192E-31,6.533185307179623 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark91(-1.022249255397665,0.0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark91(-10.249957406354014,-42.61414341581187 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark91(-10.266613608271703,36.857276195575196 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark91(-1.0269517749110555,158.10658445440072 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark91(-1.0350527006597619E-171,8.397345134458861E-140 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark91(-10.363001199188309,-0.9379527818668136 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark91(-103.67404173931381,-0.0014137857784661196 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark91(-103.67937830518542,-9.487277960769816 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark91(-1.0371331108526278,23.76861112608649 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark91(-10.500194002760425,62.265696848312686 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark91(-1.0511359910817948E-15,-50.2140322019263 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark91(-10.556520850675916,-27.481584141033167 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark91(-1.055951472960249,17.64033168068488 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark91(-1.0587911840678754E-22,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark91(-1.0587911840678754E-22,91.10617245484636 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark91(-1.0602235832637916,-1.5707963267948948 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark91(-1.0634494311483658,62.848527944148785 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark91(-10.650891914800127,0.0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark91(-10.658386528198275,-89.65210759336368 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark91(-1.065983060637299,46.0579067432096 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark91(-106.81415616550127,182.21236098886877 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark91(-107.14602578168993,0.33187555963695853 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark91(-1.07521060190724,-10.50221142330598 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark91(-10.753781086548067,-91.106186954104 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark91(10.75898329842218,-17.042168605601766 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark91(-1.0768610040535873,-10.383037144530643 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark91(-107.96587259660384,133.8719716889209 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark91(-108.01632850183131,-10.093250253323703 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark91(-1.0837616791695004E-15,50.26549631380081 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark91(-1.0842021724855044E-19,1.5707963267948966 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark91(1.0842021724855044E-19,-55.139971841786135 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark91(-10.888841569234614,-56.5781844253667 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark91(-1.0917155307712745,-98.48108779205486 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark91(-1.0947644252537633E-47,69.11503837897544 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark91(-1.0975970208173977,151.89404439312747 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark91(-10.995574287560895,-1.5707963267948957 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark91(-10.995574287564276,-1.5707963267948966 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark91(-10.99557428756611,-1.5707963267948966 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark91(-11.025358536598514,4.742173229418932 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark91(-1.1099850798463194E-23,-91.10618695372172 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark91(-1.1102234856305377E-16,1.11133794776862E-16 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark91(-1.1129932065579866,-86.85159946459706 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark91(-11.163574760265893,-60.65130324407675 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark91(-1.1205230011066987,-60.81078341931277 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark91(-112.54179228082097,18.885572208551977 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark91(-112.61622473155506,6.306298253081849 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark91(-11.27063693949794,-95.68112306262341 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark91(-113.09810244291951,-21.991148573016613 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark91(-1.1345582959827252,0.0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark91(-1.1405801478723845,89.96560680623162 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark91(-1.141591089591513,-16.346561523816234 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark91(-11.430049041659629,60.67204771393398 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark91(-1.15685221049103,1.570796326794837 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark91(-1.1580221646230655,-111.93869683196021 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark91(-11.594913765071894,90.52133403952294 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark91(-11.613825051289608,57.124090355667995 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark91(-11.616401290462534,46.78314032629635 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark91(-116.63544251069115,-59.842918917564994 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark91(-117.14070575226373,-12.79096719727244 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark91(-1174.5071985957456,-1.5707963267949054 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark91(-117.58874204882902,64.87574998276736 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark91(-117.69201012400693,119.79159961965887 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark91(-1.1792775193010219,27.095056363007117 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark91(-1.1844346178657594,57.73310238248204 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark91(-11.861488731700987,-63.31693285545772 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark91(-1.1881846040350139E-14,44.04480406771069 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark91(-118.98519033490882,73.75259045571796 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark91(-119.11287871932791,0.0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark91(-119.3766496327267,-1.5181772691862784E-16 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark91(-119.38044472678433,6.283185784019742 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark91(-119.38052083365753,1.5707963267948966 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark91(-1.20317491657975E-15,-87.9645943005142 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark91(-1.2256231695938175E-16,28.274332692155088 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark91(-12.275204407791307,26.764806696452684 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark91(-122.8598798657434,-0.3377663757414583 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark91(-123.02085443972811,-35.495805274048294 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark91(-1.232595164407831E-32,12.568323739459082 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark91(-1.232595164407831E-32,94.24777960893556 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark91(-12.35777402928714,-1.5707963267948968 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark91(-1.2374101171889393,1.2383938065570579 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark91(12.47328305694353,-1.9647790584468794 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark91(-125.3014369925326,26.909300445132686 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark91(-12.551483327806627,-51.233446891996294 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark91(-12.56637061435917,0.0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark91(-125.66370624614486,-9.424777764160599 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark91(-12.566370629260335,-1.5707963267948966 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark91(-12.566380389587959,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark91(-12.566534103508328,0.0019531981979519857 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark91(-12.568323739447239,-7.703719777548943E-34 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark91(-12.568704259717947,11.625033486330523 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark91(-12.57973399912256,-1.5707963267948966 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark91(-12.581535236152362,0.0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark91(-125.81838711208493,1.5707963267948983 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark91(-12.594509994920225,0.02813938060580544 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark91(12.597620614360524,1.561005419757267 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark91(-12.609429585034542,-56.50560879394091 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark91(-12.619763044861807,1.5707962707555791 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark91(-126.4193343978391,-79.51524704785386 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark91(-127.04706881003418,50.265506305770096 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark91(12.706776084100182,-15.567557798207957 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark91(-1.2708274843665384,-1.5707963267948966 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark91(-12.774026984055642,-22.159230651776312 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark91(-12.775934162087182,100.0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark91(-1.2826711749317792,-67.25611690031744 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark91(-12.842338107406349,0.27596749304717555 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark91(-1.285497724420818,89.25009202493503 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark91(-1.286823204542005,3.298714468759691 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark91(-12.91800234607841,-22.74790511213788 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark91(1.2924697071141057E-26,37.714737393409465 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark91(-129.45118445408923,0.0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark91(-1.2954473836732614,-2.090638157725678 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark91(-12.97650718263914,-75.68314204297515 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark91(-13.031584247332859,-43.702372867143936 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark91(-13.051833042013635,-90.48611519004605 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark91(-130.66672947308112,-0.687797672497485 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark91(-13.115551251566231,-74.87076856540706 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark91(-1.3212055923515984,-25.132901583328298 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark91(-1.3235214797012955,1.818071173888498 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark91(-132.4859183414511,82.42009142168217 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark91(-1.3361364588931144,32.752062994791046 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark91(-13.402418677245329,0.8360488592347176 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark91(-1.343252224751808,94.55138658640928 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark91(-13.446746662086042,-88.13233844229158 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark91(-1.346384465109638,1.795208188480155 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark91(-13.565962544006112,-21.991374978255667 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark91(-13.58429824973396,4.0474E-320 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark91(-13.794129792538598,-169.27159973888803 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark91(-13.79452309555353,1.2281524811943563 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark91(-13.835740697569536,1.2693700832103627 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark91(-1.3877787807814457E-17,-40.844611740425854 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark91(-1.3904284285316932,-61.080688846737765 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark91(-13.919650599800551,1.3524260608678964 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark91(-139.556578846566,-73.54155523854304 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark91(-13.959407536937672,-51.83196909099159 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark91(-13.990052986537245,-41.49462738679554 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark91(-1.4008493376176974,40.566167714112964 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark91(-14.010121097632124,60.70532291757161 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark91(-1.4021411497131453,0.0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark91(-1.4057906624635206,-1.5707963267948968 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark91(14.137166941154069,62.13687139682283 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark91(-141.49329579724505,86.04230606974616 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark91(-142.61150102608792,-42.733233752247756 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark91(-142.93144453152578,-1.5707963267948966 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark91(-1.4349296274686127E-42,28.274333882308134 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark91(-1.4429142174573217,-4.9E-324 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark91(-144.61283188077567,0.09957190071926436 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark91(-145.34752467531274,57.38293037479853 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark91(-1.4560351243456486,20.53601328033379 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark91(-1.4660223538381758,-36.02552829746169 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark91(-147.6861047187211,2.220446049250313E-16 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark91(-1.4923116733489392,1.5707963267948966 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark91(14.987294685826512,16.684684601457263 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark91(-1.504632769052528E-36,-84.8234899281778 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark91(-150.79537221767245,84.82300164690976 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark91(15.102144182091862,66.44850374615592 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark91(-1.5104307754474222,-29.78476465775556 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark91(-151.2931094858785,-31.8128481551537 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark91(-1.516862245459545,26.757471636848592 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark91(-151.84799777681644,64.92189532087929 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark91(-1.5208272304006987,0.188128893678935 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark91(-1.543853744322547,-23.59245073747717 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark91(-1.549099152266768,1.5707963267948948 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark91(-1.549150418728623,86.02586692821797 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark91(-1.5504650621103355,1.5707963267948966 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark91(-155.1325964386796,-9.740503907466424 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark91(-155.17569249076544,-31.604385400754786 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark91(-1.5613086399116494,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark91(-1.5700134539766204,1.5700134539765256 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707838094564759,1.5708088441323909 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707935107916058,-73.82742454335957 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707947087567775,-98.96016697004323 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707954830072963,78.6057192311243 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark91(-1.57079631620081,-54.98377411180619 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963260676043,-48.684477492464495 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963265849454,1.5651069866542344 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326610362,89.53842295625218 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963266189156,-73.83671878814899 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963266974467,1.5707963267948966 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267395937,-61.27567430768479 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267545344,1.5707963267949054 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326786046,-118.20746877440567 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267886829,-4.712388980389239 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326790083,-48.694686130634686 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267915621,1.5707963267948966 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267929264,-42.39844530786953 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267930962,-48.69468613064689 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267932548,1.5707963267948966 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267934257,20.420352248333415 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267935563,70.68583470577053 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267936127,39.26990816987014 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267937703,-36.128315516280985 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267939087,-193.20773735182198 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267940783,76.96902001295462 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267944063,1.5707963267948966 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267944707,1.5707963267948966 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267945708,-92.67698328089783 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267945932,1.5707963267948966 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794632,1.5707963267948983 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794724,1.5707963267948983 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267947904,20.422215192370846 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794813,-54.977871437821385 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948166,1.5707963267948966 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948348,-48.694262903596744 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948357,1.5707963267904526 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948664,1.5707963267948966 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948677,-36.24038351211812 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794877,-0.38589260384811386 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794877,152.56683345481116 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948881,1.5707963267948983 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948912,-25.491423604295477 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948912,-42.59422299129238 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948912,-62.364595930918924 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948912,78.24622691625964 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794893,-80.11061266654262 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794894,-28.274657417499952 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948946,3.9484127069845653E-177 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,100.53082506637253 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-117.83018496234165 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,13.407560654622742 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,13.57247526630285 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,1.5707963267948957 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,1.5707963267948963 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,1.5707963267948966 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,1.5707963267949019 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-23.561131553504012 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-2510.9742325529633 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-25.132741228718345 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,26.039490318575158 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,2623.4755505638796 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-30.443209700500432 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-30.535241192317987 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,42.80528219396714 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-46.48966382994145 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-55.49877358230802 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-67.5442420521742 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,68.96023309171508 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-71.2822753601898 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,77.08806317525881 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,89.55183800165018 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,97.21991419071142 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948952,146.0849818352514 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794895,-36.131149930693 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794895,-54.97683799101107 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,100.0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,1.5707963267948966 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,21.839009469762864 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,-31.581109114083404 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,-64.55006665939266 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,-86.39295647100195 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,89.55577794583853 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,0.5782029003514032 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-105.24395527404188 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-130.37609512382474 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267948948 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267948957 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267948963 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267948966 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267948983 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,171.21426834141118 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-17.27846033173346 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,20.42035224833974 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,26.703537555513023 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-29.19949422688473 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-61.26105674462528 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,61.28635552927474 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,73.01175074600724 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-75.12986233439638 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,82.84130219877676 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794896,39.26838067875025 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,95.83651590725279 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-0.4166231635074813 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-0.7452596520716696 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-112.57017406103992 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-11.975607033249403 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-12.566370614359172 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-12.624007554295517 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-135.08821369497335 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,14.137166941151317 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,14.13716694115236 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,14.137166941152891 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.4693136105909244 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-15.425762326178088 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5577601549564841 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267890923 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267912035 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267922627 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267933678 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948726 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.570796326794895 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948957 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948961 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948981 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948997 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267949006 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267949019 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267949197 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267949623 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.570796326801054 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.58E-322 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-168.07520679445662 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-169.43825777316476 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,17.68049021838226 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-182.13099430006037 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-18.84955687521308 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,19.042106085704155 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,19.50551137426031 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,20.420352248331064 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,20.42035224833445 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,20.42035224833568 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,20.420352248335735 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,20.420352248338755 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,20.42293462359257 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,20.82933175388351 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,21.244113275741476 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,21.566709672063126 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-21.57077394549488 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,23.23831926086156 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-23.561944901923756 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-23.56194490192689 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-23.842520395432683 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,2547.440983259755 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-25.56090952375115 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-2560.651145213818 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-25.626069059329236 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-2.586487414113762 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-25.9288914864848 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-2.6015592699123717E-259 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-2617.5629661449548 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-26.314517567116972 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-26.565630247926975 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,26.703537555510913 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,26.7035375555144 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,26.703537555516426 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,26.703537555517094 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,30.468657405232193 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-30.71517413688383 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-31.020002672075517 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,31.415927346660872 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-32.32607637357658 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,32.98672286268806 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,32.98672286269147 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-35.68476710983535 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-36.12831551627752 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,40.84071975545638 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-40.890761464508024 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,4.0E-323 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-41.213919870812845 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-41.26330947883078 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,41.968892291112454 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,42.36519382523248 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,42.85510491288579 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-42.85512948592066 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,42.889444759500265 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-43.73484998346604 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,4.4E-323 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,45.036179872836236 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,45.55309347704733 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-4.712388980390296 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-4.712388980392751 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,47.123889811297786 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,47.12389045139495 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,48.95660354027462 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-4.9E-323 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-50.121530418627785 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-50.17672234811124 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-54.967721149907064 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-54.977871437818116 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-54.977871437823836 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-55.04392847476557 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-55.41943491562731 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-55.431287786334195 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-55.460276175654485 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-55.48232917093827 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-56.43731553867617 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,56.54866774575313 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,56.54866776461627 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-59.69026041820606 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,59.872653057419484 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-61.26105674499772 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,62.6594665376233 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-6.283246342335837 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-62.875885807711384 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-62.89435307179587 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,63.23332583728026 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,63.63762794335384 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,64.38245018085182 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,64.40264939858963 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,65.29324236707149 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,65.97344572544387 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,70.4887612236246 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,72.43626157748224 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-72.88266480904161 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-73.84773666302836 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,74.66373191999884 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,76.96048738150475 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,76.9690200129491 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,76.96902001294919 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,76.9690200129502 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,76.97240212871792 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,76.98164565584977 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,78.54030462099483 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-78.89584739121901 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,8.10407979270896 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-81.6721763900447 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-82.57072531494701 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,83.25220532012847 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,83.25220532013014 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-8.379553437900569 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,83.87933415260696 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-84.82300164692224 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-84.82318522053427 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,87.96459430051311 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,88.1692325131209 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,8.832773953929603 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,8.881784197001252E-16 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,8.89103499794031E-162 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,89.53539062730486 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,89.53539062731036 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,89.90229327065128 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-90.07916224709905 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,90.97959844097176 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-9.455569918223695 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-96.54800672202724 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-97.01662461179757 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,97.55154295784513 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-98.96016858807813 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-98.97810924864585 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,9.915487956702545 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-99.47964746260618 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-99.52183610344757 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark91(-15.707963267948967,-1.1640334398265773E-15 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267948966 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,26.703537555513876 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,-48.67556038418269 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,7.853981633972145 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794897,14.113937526824035 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794897,1.552357609368943 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794897,1.5707963267948961 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948974,1.5707963267948983 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948974,1.5707963267949117 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948974,51.84974054686325 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,1.5707963267948983 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,171.21679962063314 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,26.711190711815327 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,-42.796910957869976 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,51.81869339558262 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,-6.045574202396544 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,7.869987969628608 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,83.23629784358842 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267949019,-169.64639758858306 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267953304,1.5113002994363232 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267971377,-112.784769360122 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark91(-157.61059759436307,-99.99999999999997 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark91(-15.777292238965854,-12.691370616073739 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark91(-15.850468874421011,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark91(-15.85366125158874,-81.68326989125707 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark91(-15.86510281628928,-1.5707963267948966 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark91(-15.879443376704401,-19.896200843545614 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark91(-15.887561879544478,93.69533130316492 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark91(-15.89436254627634,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark91(-15.93742754323979,44.94190171333446 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark91(-15.954020460588413,-46.21753772434769 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark91(-15.966052935648001,-75.87424457976412 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark91(-160.22122630918724,166.50441064025898 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark91(-160.45420773010056,95.71222847928867 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark91(-16.10781991073855,-6.68304194996917 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark91(-16.142959343972624,148.08985079474394 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark91(-1.6155871338926322E-27,94.27903093505394 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark91(-16.20042408700685,35.04998000854561 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark91(-16.258744285212373,-13.11715163162258 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark91(-16.275275469350618,-2593.2978490343057 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark91(-16.294033928871315,70.34247502690906 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark91(-16.50113912013471,13.168400216621464 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark91(-1.6613593121416306E-7,14.140112624128017 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark91(16.64017036550247,-4.479017949486973 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark91(-166.56706197793488,-12.691370621808044 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark91(16.71909542870455,-28.6067343641987 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark91(-167.8134150125177,-8.853981636086672 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark91(-168.0072054069326,-68.31545998334101 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark91(-168.452278789224,54.1047688163015 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark91(1.6940658945086007E-21,1.5707963267948966 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark91(-169.48055594915044,128.80604308969367 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark91(-169.7733776205253,-118.05648841346542 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark91(-170.24996120757896,0.6039579137301279 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark91(-1.7025821134010502E-10,25.21232700045337 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark91(-17.278744360913837,-1.5707810929629409 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark91(-17.278759594748756,-1.5707963267933658 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark91(-17.278759594748834,-1.5707963267948966 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark91(-17.32548786778824,-1.5240680537505205 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark91(-1.734723475976807E-18,1.5707963267948966 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark91(-1.734723475976807E-18,91.10618695406704 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark91(-1.7700449648246206,42.865343017368446 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark91(17.758200737011464,-67.06336717757218 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark91(-1.7763568394002505E-15,-50.01208681079835 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark91(-1.7763568394002505E-15,-94.24777962259691 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark91(-1.7774837338237575,85.52303237997657 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark91(-17.787885465864846,60.751930873879985 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark91(-179.0715381608426,-21.991392734371075 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark91(-179.07193094632115,-1.9047981759745526E-17 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark91(-1.7936620343357659E-43,-94.24777960769377 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark91(-17.993154126963447,0.0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark91(-180.10339081630312,-8.392168399084476 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark91(-18.179709487857764,-29.83181889384923 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark91(-182.21210557331406,81.68143951091284 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark91(-18.245919170042054,-18.843663468434514 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark91(-18.263495731227607,73.27714983047696 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark91(-18.356478252225685,-16.250556565473165 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark91(-18.459720208940368,-147.2650190061219 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark91(-18.671534651663162,42.1187806933998 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark91(-18.700683080048904,0.0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark91(-18.714314843243912,25.908386033688217 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark91(-18.795159134360578,-18.903952708724546 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark91(-18.797091572997516,-6.533185307179587 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark91(-18.83330053124052,49.80337167958716 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark91(-18.84955687521308,-1.5707963267948966 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark91(-18.849586476509614,0.01298135803110055 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark91(-18.85168499426374,59.69026736697612 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark91(-18.957477347120417,0.10792142558165733 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark91(-19.028684307952204,-8.85398163399969 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark91(-19.03452411994067,-3.5261469565532053 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark91(19.04202289524568,47.523383886427524 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark91(-19.08474882012895,6.32E-322 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark91(-19.09989300831627,-53.65741219780399 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark91(-19.324787953002456,-1.5707963267948966 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark91(-19.338469595873477,-54.93997285594936 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark91(-19.35569563641883,-47.19769032252729 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark91(-194.8315780377469,-3.266592653859048 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark91(-19.597781333012733,-19.831284970670666 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark91(-19.60394982117337,87.71557287644312 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark91(-19.699552316372902,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark91(-1.9721522630525295E-31,0.0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark91(-1.9721522630525295E-31,1.5707963267948966 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark91(1.9721522630525295E-31,6.284176485729456 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark91(-1.9737348622651467,50.12856026973523 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark91(19.75217589157492,61.583746755220204 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark91(-1.9772215742066632E-17,213.63505967948993 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark91(-19.777144287583145,1.295163E-318 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark91(-19.839330049633414,-89.32310175607248 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark91(-19.845442641293946,-42.97961924495152 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark91(-20.395013913923663,-76.77494869348484 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark91(-20.61191278262423,-34.55752449252903 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark91(-2.0716300580727215E-16,65.97344572547374 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark91(-20.834315759108136,-48.51139677098232 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark91(-2.0841148902680545E-16,-25.132740910453666 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark91(-20.846062814435356,-80.05632016051187 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark91(-210.5819231425596,-25.353094186888498 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark91(-2.1175823681357508E-22,-3.1416544044669545 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark91(-21.471946277208673,-1.5707963267948966 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark91(-21.66092912570025,-33.74026433584767 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark91(2.1684043449710089E-19,5.551115123125783E-17 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark91(-2.1684043449710089E-19,-69.11699150424297 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark91(-2.1684043449710089E-19,-99.52073223680071 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark91(-21.740432266334228,-91.35690326289833 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark91(-21.96052743716083,-82.45647445369795 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark91(-21.969062500235687,-1.5707963266422238 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark91(21.99516658266063,90.19810434815605 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark91(-22.133712081523143,-0.1425635063945903 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark91(-22.138287485199463,-0.1471389100709102 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark91(2.220446049250313E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark91(2.220446049250313E-16,-4.712256800735231 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,-94.2477647489744 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark91(-22.206547010758232,-39.1601399341896 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark91(-22.29742725787771,59.69026041820608 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark91(-22.30233231111376,34.286143357465086 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark91(2.2370289395339386E-12,191.63740323750653 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark91(-22.39030468529605,-0.39915701567127415 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark91(-22.468921264979485,-0.47777268985093274 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark91(-22.728749805133802,77.85361126451377 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark91(-22.80361655166882,1.5707963267948968 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark91(-22.85069946553358,1.5707963267948966 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark91(-229.33654476314948,125.66402317434178 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark91(-23.179787817348867,-12.098273879478725 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark91(-23.21735759547478,1.5707963267948912 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark91(-23.357807858300177,22.355142436514797 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark91(-2.3418167398387857E-15,-6.47582E-319 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark91(-2.350988701644575E-38,21.99152617368139 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark91(-23.532341179037914,-1.5411926039093606 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark91(-23.539512793920977,-1.5707963267948968 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark91(-23.552443185120794,2630.1440978755795 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark91(-23.561944901922363,-1.5707963267948966 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark91(-23.573642088447333,-1.5707963267948948 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark91(-23.72133368382505,-77.7260600521764 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark91(-23.916905053409685,-90.96864624474334 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark91(-24.059471185080696,-26.827748594663063 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark91(24.12963168176357,69.65771184891446 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark91(24.337218426099923,-92.04426330756641 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark91(-24.57276286847126,44.582242649166346 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark91(-2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark91(2.465190328815662E-32,87.96469748156571 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark91(-24.66109498040406,0.0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark91(-2.467472072828559E-12,0.7459283241762458 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark91(-24.761391499372237,-1.104789572407617 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark91(-24.956978079957267,-81.74371317312344 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark91(-25.13256032515178,-47.123952530557496 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark91(-25.132741228684882,1.39643315936174E-17 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark91(-25.583609535662973,-1.5707963267948968 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark91(-25.58607316639984,0.4534583914786263 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark91(-25.58813854667477,54.69315569594053 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark91(-25.636342787649014,90.60258539517334 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark91(-25.656284424684515,-1.5707963267948966 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark91(-25.70125968237346,0.5686300656115767 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark91(2.5707963267949037,-98.27240353768347 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark91(-2.6101217871994098E-54,-56.54866776461627 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark91(-26.213114769099548,36.44673791355291 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark91(-26.273566554756584,37.88927990138704 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark91(-26.28614585542057,0.0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark91(-26.290903972170963,0.0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark91(-26.29563265007468,83.02153839496421 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark91(26.435533528554075,-1.7660213677467311 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark91(-2643.928303886569,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark91(-2644.534052500351,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark91(-26.46117695740545,-50.230759141440245 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark91(-26.499521382065403,76.95954124277674 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark91(-26.524856514669864,59.014513438453264 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark91(-26.67664521067188,181.0273020342907 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark91(-26.70353755511322,1.5707963267948966 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark91(-26.70838740019873,-73.23499537105397 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark91(26.764197944171002,35.06111307261176 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark91(-26.765121909232832,-84.60141376646983 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark91(-268.6076622297649,-1.5707963267948966 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark91(-26.875166403399774,-1979.2292452899048 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark91(-26.953815571850814,-4.6865525434238467E-243 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark91(-2.6979474179515677,-88.17366175427073 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark91(-27.049597740074034,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark91(-2.710505431213761E-20,1.5707963267948966 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark91(-2.710505431213761E-20,3.1415907801693903 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark91(2.7284084219806175,71.58286322746551 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark91(-2.7369110631344083E-48,-47.12388980384693 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark91(-2.754043176453623E-16,2.754043176453623E-16 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark91(-2.7755575615628914E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark91(-2.7755575615628914E-17,43.982298743617484 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark91(-27.9121624933169,-56.28644724113301 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark91(-28.152992162139242,-42.71115026306154 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark91(-28.24153912307824,-53.37077995969718 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark91(-28.274333882160953,-2.1175823681357508E-22 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark91(-28.27433388230837,-1.5707963267948966 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark91(-28.2743341667696,-18.849555916569653 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark91(-28.27435439032062,-0.6641681282413978 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark91(-28.398229704739435,1.5707963267948966 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark91(-28.44927844263198,-46.14779560679655 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark91(-28.500026746953907,-1.5707963267948963 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark91(-28.503359318775132,72.48565646903224 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark91(-28.542303672620385,1.5707963267948966 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark91(-28.54599442041048,88.98071119732725 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark91(-28.604404169174416,0.0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark91(-28.62259709455668,-6.631448519428129 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark91(-28.72357932505389,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark91(-28.761100235878033,0.18705748670552613 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark91(-28.82641186891797,-1.5707963267948966 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark91(-28.82764787018597,-27.72101989443031 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark91(-28.861749299525364,54.179656687746814 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark91(-28.887502646756218,1.2925671145244495 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark91(-28.98492361874941,-69.82562811541672 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark91(29.132427250867494,-86.37268200933539 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark91(-29.169376130946034,12.809258421802603 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark91(-29.198330702138946,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark91(-29.25106200266849,-73.67790258524111 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark91(-29.419315112056523,-83.04168945416153 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark91(-29.43078924903304,-67.42285596049204 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark91(-29.525143612491927,-13.781433121397415 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark91(-2.962793301291122E-77,-1.4740457005909044E-86 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark91(-29.707509002965324,28.46786869635568 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark91(-29.709700248697256,-43.98229715042036 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark91(29.80437053313335,-32.76366084068927 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark91(-29.845130209098368,-1.570796326792537 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark91(-29.845130209100024,-1.5707963267948966 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark91(-29.84513020910186,-1.5707963267948966 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark91(-29.845130209108444,-1.5707963267948966 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark91(-29.84513020910874,-1.5707963267948966 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark91(-29.860889202972054,-1.5707963267948966 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark91(-29.990513142388807,24.64176198576766 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark91(-30.015916318854565,4.120232122211576 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark91(-30.03484754202327,11.185291620484511 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark91(-30.0714645051963,-1.5707963267948966 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark91(-30.171762251823083,58.865475325005406 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark91(30.173655411488966,23.54620683976532 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark91(-30.20789392764955,-19.35017602369563 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark91(-30.3590003937364,-6.542132578206434 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark91(-30.518078591389724,-22.939345502351543 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark91(-30.569161929313026,30.98324367815769 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark91(-30.773351045335275,-78.99135824082029 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark91(-3.0814879110195774E-33,1.5707963267948966 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark91(-31.20398857175418,0.0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark91(-31.41592653474703,-172.79182823385284 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark91(3.1415926535897953,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark91(-3.141592653591782,-1.5707963267948966 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415928920083727,-2.387086161956458E-7 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark91(3.1415945146163717,-1.5707963267948966 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415945609384264,-1.5707963267948966 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark91(-3.141594560938522,-1.5707963267948983 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415946035485756,-1.000001879211249 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark91(-3.141596058120147,-1.5707963267948966 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415965532271115,-0.010807668413910032 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark91(-3.141600282984348,-1.5707963267948966 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark91(-3.1416002829919436,-0.08433855121457076 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark91(-3.1416002834152286,-0.12486064968688489 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark91(3.1416002838804413,0.0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark91(3.1416002918663937,-0.01596980138359062 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark91(-3.141603740685397,-0.5845878526378668 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark91(-3.1416231861307495,-0.21627907507877464 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark91(-3.141760243185814,1.5707963267948966 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark91(-3.141828540337705,-1.5707963267948961 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark91(-3.1420809348397936,-1.5707963267948966 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark91(-3.142080934866064,-1.5707963267948966 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark91(-3.1420809435969055,-0.6050417153163021 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark91(-3.1420810374331882,-1.5707963267948966 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark91(-3.1435458111548242,-0.1460619915369147 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark91(-3.1436379315867864,-1.1487338354129606 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark91(3.144367907163592,21.98837332159398 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark91(-31.44717653589827,0.0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark91(-31.447176535899732,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark91(-31.447176535917503,-8.552847072295026E-50 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark91(3.147157145500355,47.11832531211932 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark91(-3.1494051535898056,-0.007812499923301102 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark91(-3.149405153650017,-18.849555916171937 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark91(-31.56678776398379,-47.966896555348235 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark91(3.15890072707551,-47.13646205136932 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark91(-31.653560177737994,-1.5707963267948968 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark91(-31.73259723776191,1.5707963267948968 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark91(-31.805799272191962,16.280865719442787 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark91(-31.882895518871088,1.5707963267948966 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark91(-3.1988115952458296,97.92161562735055 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark91(-320.44235867548593,-1.5707963267948943 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark91(-3.2132564219619297,6.188683182452053 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark91(-32.2344065867985,-18.956914254875272 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark91(-32.246839330708596,-1.4984360830279675 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark91(-32.25828754523426,78.09940421218147 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark91(-3.2311742677852644E-27,5.551115123125783E-17 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark91(-32.32848372541466,7.888609052210118E-31 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark91(-32.38800128858287,-1.5707963267948966 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark91(32.43210307802755,22.86092658634105 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark91(-32.45701277952158,-55.53808974771874 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark91(-32.4623332698914,1.5707963267948983 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark91(-3.247298223999816,-1.0671605044371946 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark91(-32.49555245342839,175.58572573561332 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark91(-3.2506631094823657,-45.426114352781156 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark91(-32.557665343017526,76.53996249327463 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark91(-32.61612684773982,51.600862292236 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark91(-3.266592653589806,-1.5707963267948966 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark91(3.266884766664427,75.42947368615529 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark91(-3.2725501374619944E-12,84.82300164692114 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark91(3.278686837767908,-59.82735460238418 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark91(-32.795999779383465,50.012220355536016 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark91(-32.83499119044029,-14.63498026673605 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark91(-32.969881517141374,-1.5707963267948966 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark91(-32.9748389443923,1.5589124084943629 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark91(-32.9782045231816,62.203946047902804 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark91(-32.97958470002929,1.5636581641313698 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark91(-3.304757448844157,56.3175608217627 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark91(-33.70694166451689,-1.034783636449447 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark91(-3.3790502088229175,-39.24755303751377 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark91(-33.809388458531515,85.90974705048814 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark91(-3.433432974615836,-0.29184032102604257 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark91(-34.55849575198773,-43.98229577918528 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark91(-34.55849575198775,-56.54865146382039 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark91(-34.564945557303126,3.149019021405233 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark91(3.469446951953614E-18,-15.707963545100842 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark91(3.469446951953614E-18,2.220446049250313E-16 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark91(-3.469446951953614E-18,-28.274335807907345 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark91(-3.469446951953614E-18,40.84070449666706 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark91(-3.469446951953614E-18,65.97344567752278 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark91(-3.469446951953614E-18,9.42477719988218 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark91(-34.713885409155594,138.57016245675794 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark91(-34.816898731240784,-39.10910788513179 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark91(3.487841449364274,15.363790582416884 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark91(-34.989113181643894,91.53778094626017 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark91(-35.08848410436111,100.0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark91(-35.22100682661009,-0.9907551609846847 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark91(-35.26635085194789,89.26154345378055 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark91(-35.446195236923295,-3.248565551764031E-114 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark91(-3.552713678800501E-15,-113.09734990604889 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark91(-3.552713678800501E-15,-13.248897955037805 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark91(-35.53753205839756,34.79202899605477 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark91(-35.55020835034007,0.0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark91(-35.60370321199974,2600.4601081501964 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark91(35.67399589700989,-39.18738247209015 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark91(-35.6886446165927,-56.221807626889 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark91(-35.7148838562875,76.46897674659422 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark91(-35.74766859395182,-89.91603754963991 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark91(-35.81680566665037,80.42212251617198 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark91(-35.83956268084537,-8.142734469411737 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark91(-36.117506538692524,-1.5707963267948963 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark91(-36.12831551624055,-1.5707963267948966 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark91(-36.12831551627947,-1.5707963267948966 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark91(-36.12831551627977,-1.5707963267948966 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark91(-36.12831551628345,-1.5707963267948966 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark91(-36.12831551628638,-1.5707963267948966 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark91(-36.30490161709219,73.65084125855057 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark91(-3.635569141961246,30.92195004752648 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark91(-36.410225464257095,1.5707963267948966 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark91(-36.46616341967754,-2653.928406760001 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark91(-36.64091484869652,5.714482653097946 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark91(-36.86131673910778,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark91(-36.86395462769602,3.7057443397936893 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark91(-36.89362184862925,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark91(36.939415134353595,-48.999894520635465 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark91(-36.939417783874084,73.78181390953465 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark91(-3.6979882290676535E-15,8.9E-323 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark91(-3.708799172561444E-17,-15.70796326794897 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark91(-37.14300221241972,-75.42255845629273 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark91(-37.32786173350279,-21.91710651172005 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark91(-37.44815300844325,-0.25095883463426966 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark91(-3.751097645213605,62.88460068408287 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark91(-37.56987190593216,-90.9659848089859 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark91(-3.76158192263132E-37,3.812568165659224E-21 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark91(-37.69911184241983,1.3234970740292256E-23 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark91(-37.69911184307747,-194.77768715133166 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark91(-37.70221067896907,-62.831853076033816 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark91(-37.71474011502233,56.548667764616134 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark91(-37.74002384975041,-0.04105437763170801 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark91(-37.7515607034381,-37.94727288677721 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark91(-37.75742399279313,9.960692402506659 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark91(-37.7918120016838,-55.808515317787325 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark91(-37.87475012204485,81.80954189150663 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark91(-37.90404505498942,6.567802996632757 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark91(-3.7998733426076914,-53.22783259837379 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark91(-38.04583360079275,-62.49612698510434 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark91(-3.808950442032003E-33,18.849555921538755 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark91(-38.245474606492145,-107.21211385155775 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark91(-38.26369119554761,-49.7009031049666 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark91(-38.39178782337485,2634.8739595316497 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark91(-3.8407624271556505E-4,-94.24739553145108 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark91(-38.48451000647497,0.7853981633974512 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark91(-38.491968148317035,48.48132871623284 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark91(-3.8518598887744717E-34,-94.24777960769377 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark91(-3.8549204702719897,5.56985749049739 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark91(-38.56761875334221,0.0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark91(-38.63091640485088,-2.505210450011216E-293 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark91(-38.670545555972176,9.699609564135045 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark91(-38.72063905323414,33.89590391264772 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark91(-38.74944727483414,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark91(-38.757478089484934,1.058366246407415 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark91(-38.8106656888116,-53.868010678217374 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark91(-38.86530451910039,-49.01452934130537 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark91(-38.99662168495553,82.90090361130476 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark91(-39.00716743652725,89.92558372229215 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark91(39.0970850489488,-37.761009588165265 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark91(-39.13680603869418,45.3276623416273 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark91(-39.218272175481104,-48.74632212503311 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark91(-39.25643041372793,1.570796326794855 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark91(-39.410585012566244,73.7809838613457 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark91(-3.944304526105059E-31,-28.274334954705708 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark91(-40.16660855671424,-33.77373897258305 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark91(4.046847632958826,90.20093197473497 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark91(-4.0529956245106336,11.654967643438333 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark91(-4.077109797143821,-89.87812257466396 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark91(-4.078315292499078E-56,9.424777960769378 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark91(-4.0804492348807075,26.90410490619277 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark91(-40.840719758635245,-47.12388984464259 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark91(-40.8431680607233,-78.58918783292552 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark91(-40.992727913242156,-0.9435497122737928 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark91(-41.27380257370887,15.26627450130627 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark91(-41.27900464542688,-0.43851165711136597 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark91(4.141592648812448,88.96459431842118 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark91(4.141592653589794,-49.93348990703698 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark91(4.141592653589798,59.55738143529807 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark91(4.141592653589801,-0.007189163112549211 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark91(4.141592658272208,-62.83185305330654 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark91(4.141593419877376,140.94548150884188 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark91(-41.465147815325956,-0.6244433186586439 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark91(4.148410698566288,-40.99066117383866 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark91(-41.5346390626775,92.06653409020605 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark91(-41.59582182348187,-1.2E-322 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark91(-41.601998498412954,-1.5707963267948968 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark91(-41.668556156465165,33.02972366787071 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark91(-41.74218703898627,-0.9014825423189612 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark91(-42.04700263144514,0.0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark91(-42.08230649549563,1.4E-322 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark91(-42.307375636894825,-45.44896829048462 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark91(-4.2351647362715017E-22,15.723588270135496 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark91(-42.385714416105714,17.30454600210036 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark91(-42.4027457445104,62.51106651919879 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark91(-42.55195906650684,1.5707963267948966 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark91(-42.557567750805994,-75.02884087141908 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark91(-42.567021315682666,1.5707963267948963 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark91(-42.59441671702379,-2.8480945388892178E-306 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark91(-42.673423220584446,67.28231965505832 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark91(-42.694836134748655,0.0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark91(-42.735462165279365,1.0816961818567234 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark91(-42.75725903594654,-6.169394854663383E-179 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark91(-42.77035107004135,-78.74700582236343 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark91(-42.77942297797338,3.785766995733679E-270 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark91(-42.818393873512136,6.102500843490503 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark91(-4.286793492418517E-18,50.26548245729257 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark91(-42.89536790067214,2404.5377393308336 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark91(-42.90771874359137,3.697038081771171E-273 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark91(-42.919776346764806,99.96161714747299 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark91(-42.93698401139203,2592.4058030143774 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark91(4.317688200761964,133.91238855718893 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark91(-43.30059441716656,48.595901367111054 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark91(-43.664585044213574,45.187135183062566 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark91(-43.9822971502571,40.84070447073015 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark91(-43.98229716516312,34.558496959295006 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark91(-43.98235363986133,-75.39822750085297 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark91(-43.98278547997225,-53.40707459773769 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark91(-44.01650229903003,0.03420514877292475 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark91(-44.12840107628037,-83.35261897019859 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark91(-44.13406012686584,90.95442397749527 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark91(-4.414665768922106,-110.31482046307008 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark91(-4.440892098500626E-16,34.558357939782084 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark91(-44.45144763093809,27.869454876308282 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark91(-44.53999727593787,48.234093662612594 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark91(-4.458953334583294,-64.14921375278936 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark91(-4.470137839500863,-90.58525849746412 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark91(-44.76084304236196,-1.1282464849155185E-277 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark91(44.81141093281545,-70.9690403812225 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark91(-44.848500149272766,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark91(-44.92200079643034,58.91814616136935 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark91(-45.07043870633512,-37.81209957552382 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark91(-45.08593570041042,41.669450039293714 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark91(-45.12153733318547,-2593.76607153617 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark91(-45.13503098976641,-1.5E-323 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark91(-4.516425227599143,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark91(-45.18183968689531,0.0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark91(-45.273429150168305,0.0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark91(-45.3056992235373,12.818630040081004 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark91(-45.31144203984881,73.77502127099433 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark91(-45.33065230045325,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark91(-45.394447631933794,35.19009973276212 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark91(-45.465049624130515,1.4827524738734097 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark91(-45.51527118736709,71.34916409782335 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark91(-45.52795795511361,83.27734084206791 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark91(-45.553093477049806,1.5707963267918132 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark91(-46.37601075654108,28.64288293292111 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark91(4.658491275429821E-14,-119.38010670081296 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark91(-46.8737929090153,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark91(-4.690535542568637E-11,-103.67060809721997 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark91(-4.699223716600508E-12,-169.64538410295444 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980382945,-1.5707963267948966 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980383398,-1.5707963267948966 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark91(-47.12388980384689,-1.5707963267948966 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark91(-4.7123889803846915,-1.5707963267948966 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark91(-4.71238898038469,-1.5707963267948966 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980384695,-1.5707963267948983 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980384725,-1.5707963267948966 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980386138,-1.5707963267978293 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark91(-4.7123889803867165,-1.568025385168837 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980391613,-1.5668105845961566 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark91(-47.12388981771213,-50.265482457432235 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388982725428,-1.562287323184493 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark91(-4.712389656946599,-1.480921605927265 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark91(-4.712714302881616,10.994069848924925 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark91(-47.16176594092082,-0.03792800102556769 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark91(-47.268458689169265,-54.88474889887583 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark91(-47.29105909991866,53.87586405649608 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark91(-47.304867747257724,-93.40611578169673 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark91(-4.734753445845148,-1.5707963267948983 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark91(-47.36316186479165,27.795223066758496 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark91(-47.38994279683317,-29.415571210347608 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark91(-47.39985515263889,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark91(-47.45531922657771,-77.5282394073253 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark91(-47.48517788176781,72.3355827678468 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark91(-47.49361639859588,-2680.3804118702305 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark91(-4.7586729272055575,-1.6170802736157672 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark91(-47.650296515837255,-0.5264067119903562 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark91(-47.67057788568112,-34.49861926557627 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark91(-47.67925777010662,59.1540415650332 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark91(-47.70757929237983,-46.378420826966305 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark91(-47.811103965831926,-72.28771589321036 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark91(-47.87690973899803,1.5707963267948983 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark91(-4.792473647041754,92.75706794755597 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark91(-48.30668168822441,1.5707963267948966 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark91(-48.32537735214619,-71.05514348426595 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark91(-48.33449901090459,-1.2106092070576882 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark91(-4.840739893561648E-122,2.28597478256455E-100 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark91(-48.44001402161153,-64.23794356745549 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark91(-485.37600302861557,1.5160608178790502 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark91(-48.5438105038893,63.54146020107089 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark91(-48.63986025094462,-1.5707963267948966 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark91(-48.66924047180311,-1.5529810279691452 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark91(-48.67869113909562,-1.5707963267948948 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark91(-48.68037505086045,-1.5707963267948966 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark91(-48.69449783007441,-1.5707963267948966 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark91(-48.69468613063493,-1.5707963267948966 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark91(-48.74888439513197,31.44262970263328 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark91(-48.76774358001439,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark91(-48.7806767266688,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark91(-48.79451751774546,178.32583357945987 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark91(-48.80640543326024,61.149337442382524 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark91(-48.81811637606306,123.14516375324328 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark91(-48.82952389642303,-89.67022839309034 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark91(-49.02985410788374,-62.546197644529244 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark91(-49.03982971183686,-59.45354776756617 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark91(49.20945265764402,59.15662506971083 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark91(-4.922307753559949,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark91(49.23623912774718,53.04310524569354 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark91(4.930380657631324E-32,50.26548253692646 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark91(-4.930380657631324E-32,-65.97344572538564 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark91(-49.37504829958894,-0.8906850736154441 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark91(-494.7814626435075,-1.4105977321096907 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark91(-49.54644362466333,54.126113943799844 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark91(-4.979312115760607,-99.09792419362105 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark91(-49.80817463305521,64.0654582719745 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark91(-49.828142568895295,11.088689271866343 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark91(-49.864695567432406,2.5518106008656813 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark91(-49.947650809974206,90.96182736591288 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark91(-50.01970813031387,0.0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark91(-50.0927866065977,0.0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark91(-50.192629020581585,9.497631397624486 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark91(-50.222541382624186,59.156337755776974 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark91(-50.23512461847562,3.3087224502121107E-24 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark91(-50.26546421922632,28.274333463392953 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark91(-50.26548245712994,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark91(-50.265482457435596,34.55751918845437 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark91(-50.265482457436626,1.5707963267948966 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark91(-50.26548257675822,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark91(-50.48051218148884,-4.0E-323 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark91(-50.71447075230734,0.4489541061883981 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark91(-50.77817513114517,-6.079168494738269 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark91(-50.82584475157313,44.499653515847115 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark91(-5.085395054437527,-2622.345336645278 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark91(-50.88548069383025,-86.52005968527095 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark91(-51.0025229936792,100.0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark91(-51.06336556254986,-142.54118958603226 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark91(-51.14809420728561,-129.7958691986588 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark91(-51.200261040177,-10.359556543509685 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark91(-51.25273155521324,2573.9654124570407 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark91(-51.562741195916736,-2.8853058180580424E-129 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark91(-5.157259846069734E-33,-21.991148694338094 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark91(-51.6492273436791,-61.87883552413476 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark91(-51.69661475316897,1.4314667164509012 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark91(-51.751159971833644,33.97977438109564 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark91(-5.17589241588472,162.304627916252 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark91(-51.77189546124589,-16.81326001440369 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark91(-51.81863923262905,1.57079129021297 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark91(-51.9771692703509,71.43532411622124 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark91(-5.215411424879065,36.59303888512983 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark91(5.2202435743988196E-54,15.70796225013717 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark91(-5.2782148943505085,93.24280919486472 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark91(-5.313642561673697,-77.57027359423894 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark91(-5.325720745089139,-20.983090453305508 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark91(-5.340074051051728,-8.48166670464152 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark91(-53.40707511103878,2.4651436039185346E-32 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark91(-53.40707511149215,7.888609052210118E-31 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark91(-53.407075587863645,-4.76837159673921E-7 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark91(-53.407095440268584,81.68922195119421 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark91(-53.57311612633393,-0.16604096849655534 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark91(-53.69865353412673,-89.5758935944396 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark91(-53.82848916882324,-60.74218728456808 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark91(-53.97882327312654,-21.478495018127862 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark91(-54.07815535552156,78.11096378228474 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark91(-54.109075785708896,-0.7020006746824109 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark91(5.421010862427522E-20,-62.83185182227988 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark91(-54.24915099541645,77.43785954081972 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark91(-54.466532864297456,3.7612235547426334 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark91(-5.451772430431815,47.95530268059467 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark91(-54.62558049527151,-0.4386183677825677 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark91(-54.66731036560339,-2696.3406129781147 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark91(-54.82648602957869,11.102179823433552 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark91(-54.845037160282466,-27.841756569252652 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark91(-54.93354367210095,9.548892427561483 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark91(-54.98941322066777,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark91(-55.08700834553687,-2.494570599104211 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark91(-55.09658866825671,-68.29657737314731 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark91(-55.10746230299165,42.04169726563259 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark91(-551.090637024982,-0.8085954097465133 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark91(-55.10956322209411,2.465190328815662E-32 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark91(55.17247913001975,83.81489189357993 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark91(-55.22648185203916,76.0632161956288 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark91(-55.250245904809915,22.663801336208024 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark91(-55.280020024610096,19.362093700539745 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark91(-55.30618704913015,42.410833467277826 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark91(-55.34048221440118,-4.186583378757572 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark91(-55.349782014153774,1.5707963267948966 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark91(-55.48470324101825,92.6769832808989 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark91(-5.551115123125783E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark91(-5.551115123125783E-17,1.734723475976807E-18 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark91(-5.551115123125783E-17,-47.13951636008879 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark91(5.551115123125783E-17,-5.141592653589909 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark91(-55.54303114650677,78.83481297960492 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark91(-55.57647302018986,-26.04668777529757 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark91(-55.69467942094457,62.75037004719093 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark91(-55.70637937881353,-0.7285065248328887 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark91(-55.90553988879137,82.68942961567441 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark91(-56.11502422635745,44.077529662158014 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark91(-56.203440954477,48.51722976301875 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark91(-56.2094786369466,47.82942598338386 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark91(-56.23622344296248,0.0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark91(-56.27424859750834,20.9904203431354 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark91(-56.2782719090527,82.85870539566442 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark91(-56.290180729910475,65.15748232301183 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark91(-56.30485322565405,1.5707963267948966 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark91(-56.38296597461882,59.21357149173693 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark91(-56.414103699639014,64.52187097222466 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark91(-56.5255178368696,0.0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark91(-56.548555667742555,-12.597622295694721 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark91(-56.54856775276248,-6.2870923760684345 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark91(-56.548651358635645,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark91(-56.54866776205214,59.690260417638136 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark91(-56.548667764565394,141.37166882082633 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark91(-56.5489131032599,0.003910398419916676 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark91(-56.58465034780019,0.0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark91(-5.659612266014289E-32,21.99114857512855 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark91(-56.712631047513504,18.95567272416171 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark91(-56.75707448444221,1.5707963267948966 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark91(-56.88990737964341,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark91(-56.91153397611524,-9.701997142471114 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark91(-57.084286421708875,28.274333882308138 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark91(-57.14316420108343,83.9797356615571 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark91(-57.15398775357682,-1.5707963267948966 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark91(-57.243250761190566,87.04174200654597 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark91(-57.260456693841846,7.636633736127036 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark91(-572.7618809962933,1.554994765228047 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark91(-57.445166924617844,-4.141592653589794 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark91(-57.49987925118902,-0.027305159685840505 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark91(-5.752220392306203,100.0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark91(-57.57192245797161,45.26070904863511 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark91(-5.760144629509618,56.3722969790893 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark91(-57.66155441007355,-3.944304526105059E-31 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark91(-57.69770388934661,89.6083840454057 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark91(-5.771616400799701,36.40609800236089 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark91(-57.760368953231136,22.81700870754796 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark91(-57.78327079028479,1.5707963267948966 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark91(-579.6230413402782,0.14897324025759706 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark91(-57.991414460481124,-53.351557817077335 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark91(-58.02192317392227,1.5707963267948966 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark91(-58.02406643956707,1.4753986749507948 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark91(-5.807138351496292,101.38044433391511 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark91(-5.846810328742613,109.69819568913897 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark91(-5.8774717541114375E-39,40.840704496667314 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark91(-59.07639497932189,-52.72019944537596 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark91(-59.10832748113351,80.5648109746983 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark91(-59.323549822237396,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark91(59.60288620872879,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark91(-59.8298486037205,-72.25664246447887 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark91(-59.97620338574043,55.946469158131606 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark91(-60.14078912783913,64.1716046472223 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark91(-6.018531076210112E-36,15.707963267948962 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark91(-60.239952544340156,55.95379388173309 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark91(-60.53681240393787,76.99830036187188 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark91(-6.070712507149054,-5.229509046680008 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark91(-60.936546808195004,39.54600003641096 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark91(61.12279511388775,85.632114492017 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark91(-61.210204568875795,-95.61240800722672 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark91(-61.26105674500328,-1.5707963267948966 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark91(-61.2635805193362,-1.5707963267948966 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark91(-61.26715388793605,-35.9642774433228 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark91(-61.38332972650097,-6.6599917309756716E-257 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark91(-61.59663877887449,85.46292544396596 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark91(-6.162975822039155E-33,3.1420809348397936 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark91(-6.162975822039155E-33,62.8318539667239 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark91(6.196583585500079,82.05477251681421 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark91(-61.98004184903497,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark91(62.22619441742415,59.1490974641074 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark91(-626.7145079953478,-1.5707963267948966 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark91(-62.823501579800656,-1.5707963267948966 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark91(-62.83184796361486,147.65485471690724 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark91(-62.831853035012706,-56.548650820937176 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark91(-62.831853069505776,-56.548667764369455 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185307179585,-1.5707963267948966 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark91(-62.831853071795855,7.703719777548943E-34 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark91(6.283185307180042,0.0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark91(-62.831853071811636,0.31946144030701773 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark91(6.283185307228344,0.007900287201018546 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185307296002,0.0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185307421173,1.5578402670406857 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark91(-6.28318530811091,1.5707963267948966 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185308774799,1.5707963267948966 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark91(-6.28318533698325,1.7899679893244175E-8 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185784220606,0.7453861388118068 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185835494384,1.141620533338692 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark91(-6.283189121877231,6.938893903907228E-18 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark91(-6.283193446503695,0.017351737660971388 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark91(-6.283193943210164,1.0363291971546108E-4 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark91(6.283200634350247,0.0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark91(-6.283307377492434,1.309109511455223E-4 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark91(-6.283319453793081,4.2688362174157996E-4 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark91(-62.84100655719631,1.5707963267948966 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark91(-6.284161869680725,0.028777524280714922 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark91(6.284373542005046,81.68022075850917 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark91(-62.86616715858391,6.491650128678238E-7 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark91(6.287091557179791,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark91(-6.2881726783279674,-89.86523788028661 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark91(-62.89461668569131,-4.14159265358983 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark91(-62.91156651874199,112.79841927395987 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark91(-63.077828411661024,6.529160647044746 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark91(6.312959745985709,-78.53981633946256 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark91(6.31443530717962,4.694812265282386 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark91(-632.2360350162182,-1.5707963267948966 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark91(-63.32043064180528,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark91(-63.374573470155205,0.5427203983593405 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark91(-63.41613467618758,0.5845074440149196 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark91(6.348357619546448,-78.4262061286909 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark91(-63.51442777315939,-0.6825610601930913 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark91(-63.590024973542036,19.78588498977141 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark91(-63.6806510535793,90.65372059279672 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark91(-63.731947714948596,-73.15672567571798 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark91(-6.374709899433202,-12.478766054856052 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark91(-63.78090588387764,-33.70593473212938 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark91(-63.811724984318445,15.420512464539433 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark91(-6.382286140943478,20.038034938034485 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark91(-6.397580697753404E-17,91.10618603355454 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark91(6.411436894394658,-75.39834575646766 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark91(-64.16685449048005,-58.19965173398687 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark91(-6.422847039489634,0.13966117680918888 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark91(-64.36648721811991,-36.164477696753465 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark91(-64.39681061530953,1.5707963267948963 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark91(-64.40264939859041,1.5707963267948966 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark91(-6.450551932847884,84.82300210083908 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark91(-64.54434227744805,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark91(-64.94138711670115,0.0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark91(-6.501697267098085,-21.99114857528177 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark91(-6.525868016638858,0.001953410072225943 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark91(65.27521128826677,-63.0067897300123 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark91(-6.530595251101481,9.373105086847693E-243 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark91(6.533185307179588,62.75071100303939 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark91(6.533185307179592,-28.242680754998368 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark91(6.533185307204859,-56.79548593061091 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark91(6.5331853088092515,22.06845078893079 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark91(-65.99245972304101,77.49703292696711 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark91(-66.0071324355709,98.50337996968481 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark91(-66.08724920040099,-0.11380347501533192 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark91(-66.12016458954857,73.58807770542015 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark91(-66.1525441903876,-2.0294093211823423 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark91(-6.624613961953223,-27.675287939070344 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark91(-66.26359918988446,-0.2901534644988014 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark91(-66.27905578742751,-73.1809240994341 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark91(-66.46085131946838,1.5707963267948966 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark91(-6.652302635463282,116.270871546168 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark91(-6.661338147750939E-16,6.661338147750939E-16 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark91(-66.659978686217,168.4793259299392 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark91(-6.675018537645663,-23.981853454537287 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark91(-66.7513001857817,28.274333894977918 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark91(-66.78649519083294,-20.721398150851428 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark91(-66.8553359854478,-0.8818902600621367 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark91(-66.93406046992683,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark91(-6.6981586937665725,-2.4771368681931563 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark91(-66.99676931970703,-1.0137033232200715E-10 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark91(-670.1928868501137,-0.0928463562060588 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark91(-67.21066516306058,-2623.093473308408 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark91(-67.25088413624614,5.005746896319102 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark91(-67.25682131606374,-7.853981633974483 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark91(-6.726833119184335,-18.40590810953401 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark91(-67.27260926584862,17.007126808411925 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark91(67.28543281635626,-85.97981341340682 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark91(-67.3129255799777,0.0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark91(-67.36193932578504,-43.14886853659567 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark91(-67.46148327629861,-177.41722615194138 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark91(-67.50528975464763,44.52210261359687 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark91(-67.526057699505,-1.5707963267949054 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark91(-67.55116988867425,77.09498246249302 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark91(-67.55818603089389,65.70042054008522 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark91(-6.774625650055012,69.60647872185088 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark91(6.776263578034403E-21,-150.79644292752897 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark91(-6.776263578034403E-21,1.5707963267948966 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark91(6.776263578034403E-21,72.25662926775222 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark91(6.788141093297158E-17,25.13274122871951 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark91(-67.9800651596897,-1.13497321928575 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark91(-67.9802094925271,1.1716381358559617E-243 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark91(-68.23219129904295,20.511469472597696 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark91(-68.30715305290892,7.911557169807651 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark91(-68.47315584168436,-62.88514379556573 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark91(-68.5132398032484,62.80657215643349 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark91(-6.907865997217211,-1.5707963267948966 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark91(-69.09787002823155,-1.5707963267949 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark91(-69.1169915080667,-25.132811878743382 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark91(-69.21538468336658,2616.518848045726 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark91(-6.938893903907228E-18,64.97344497223884 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark91(-6.94417095447347,0.6609856472938833 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark91(-69.60745417036532,2572.099788896948 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark91(-69.94710616528306,-2607.956730757205 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark91(-7.010731108031337,53.49808855430237 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark91(-7.02097917464306,-24.673288465216572 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark91(-70.48875684275572,76.7718925647855 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark91(-70.55354631447864,1.4385079355031871 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark91(-7.143326269365687,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark91(-7.1909241917381,-100.31764775706878 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark91(-7.204929872785696,0.9217445656061096 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark91(-72.07646087497899,-47.29920996989805 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark91(-72.25663103256524,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark91(-72.2566362104076,91.10618683089723 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark91(-72.26948930659316,3.3444356521734666E-198 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark91(-72.27284836258949,-0.01621733002424082 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark91(-72.3288047805212,-28.301272579852068 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark91(-72.33397449774519,0.0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark91(-72.35885365618846,-0.10222262359270626 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark91(-72.3831360563498,61.516900924670324 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark91(-7.248092255901731,90.67169875420089 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark91(-7.252329468788735E-12,119.37839258018026 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark91(-72.77556678944954,-75.57327941448072 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark91(-72.79824924708808,36.31966921301543 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark91(-72.84425938807495,-88.46825991660447 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark91(-72.88831289649117,-94.9907325955933 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark91(-73.01593233714472,-12.32280680177314 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark91(-73.09495930636264,3.8021831325903196E-211 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark91(-73.13675652909922,-70.5371942626045 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark91(-7.316861916931145,66.84784623557175 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark91(-73.2377030521683,0.0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark91(-73.34661174292103,67.31507953856251 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark91(-73.46949328212635,90.88891562488097 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark91(-7.349118756157297E-15,97.38937226128358 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark91(-73.62538341339267,-3.944304526105059E-31 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark91(-73.80709611033755,-100.0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark91(-73.80737534319637,-1.5707963267948966 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark91(-73.82742735935477,-1.5707963267948966 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark91(-73.8274273593589,-1.5707963267948966 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark91(-73.8274273593593,-1.5707963267948966 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark91(-73.83518122674205,-1.5707963267948983 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark91(-74.14395461277377,182.10720007696074 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark91(-74.22939096868873,2631.2189872027625 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark91(-742.6278949137336,0.8896277113417361 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark91(-74.26789940557599,13.533876045480142 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark91(-74.29948203260608,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark91(-74.30155852152284,-2.7805953479584105 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark91(-74.32574065889801,50.965885008441035 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark91(-75.0233649394128,-20.54436118692525 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark91(75.06373082364215,47.91985862805154 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark91(-751.2965247910424,-0.5116025202223768 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark91(-7.518623719426786,-30.180488123650733 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark91(-75.25732426654668,-67.22688051306486 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark91(-75.28517030843665,-12.845731877877572 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark91(-75.37404047980259,3.1657758600105876 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark91(-75.3968379094619,-6.284571083872731 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark91(-75.3978095196942,-1.5707963267948584 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark91(-75.39822239225602,34.557519189487635 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark91(-75.3982236859787,75.4021308315533 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark91(-75.39822368613645,119.38228623641385 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark91(-75.39822368615393,1.5707963267948966 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark91(-75.42674243064201,1.5707963267948966 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark91(-75.42713267422772,0.029120008852430358 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark91(-75.5200559844269,0.12183229827186598 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark91(-75.5596605156106,-141.76933462661287 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark91(-75.57548925895577,-28.264121915527394 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark91(-75.60826376801566,0.21004008186062312 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark91(-75.66900063241779,78.26903939348207 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark91(-75.67859958800145,-56.28023599990167 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark91(-75.79561697029457,0.39738713299779976 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark91(-75.80231530426943,-26.720766199766558 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark91(-75.89352758351733,18.849556044328857 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark91(-75.89573651991444,-43.66047610109246 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark91(-75.8996687011521,-67.75076678500042 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark91(-75.96872267488256,17.132995605042687 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark91(-76.03761847088191,0.0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark91(-76.07400638756833,-22.010177114477145 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark91(-76.10919319448288,11.393652596490938 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark91(-76.1820901286513,0.7839510422101452 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark91(-76.23375745490443,4.776217532431318 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark91(-76.23700770070867,-84.42424140703511 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark91(-76.42258132394076,1.0243576377857238 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark91(-76.4795575797388,1.0813338935837578 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark91(-76.63490259807004,12.912858014749617 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark91(-76.66419723052111,13.724775898530226 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark91(-76.70994029883808,-90.0792312694903 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark91(-76.74542046589974,-39.09416643636309 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark91(-76.78577740623967,-83.18905618472785 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark91(-76.83520079317063,-181.84427709359142 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark91(-76.94281121917746,52.36226176926459 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark91(-77.09397435696879,-86.9616829688619 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark91(-77.1149451020942,-1.5707963267948966 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark91(-77.2309923859809,-0.2616971585956115 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark91(-77.26266214078223,-1.5707963267948966 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark91(-77.97272562157922,-16.273913420592738 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark91(-78.18847263684287,-75.98854332669582 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark91(-78.44778632621302,-23.778913891017055 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark91(-78.48971763093803,-78.45705911220968 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark91(-7.853981633972224,1.5707963267944363 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark91(-78.5398163397446,-4.8148248609680896E-35 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark91(7.853981633974483,-24.294361964554557 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark91(-78.53981634032566,-0.6793011868291957 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark91(-78.539816354646,1.5707963267948966 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark91(-78.53981667292183,2.847603833504777E-14 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark91(-78.55573495004433,-0.01611116905065869 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark91(-78.62038591397409,0.0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark91(-78.63031346292455,14.342698913744641 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark91(-78.68841008451838,39.250210250702935 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark91(-78.72794160908713,0.0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark91(-78.7306354852293,83.42033274521167 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark91(-78.73843893522353,1.5707963267948968 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark91(-78.76386494891727,-56.42162691372083 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark91(-78.91358260277951,1.502096572321723 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark91(-78.91459082999037,-0.3747744902455428 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark91(-78.97832788269272,2534.051857487611 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark91(-79.0689363013186,-26.578531888729202 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark91(-79.33722786011298,1.5707963267948966 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark91(-79.35489755680425,55.95132485175668 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark91(-79.3993437869845,39.201449902855096 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark91(-79.61067514906641,1.414093484417954 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark91(-79.6155149444244,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark91(-79.82666638323319,0.0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark91(-79.90064897681681,9.573762572482252 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark91(-79.91433483784687,-100.0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark91(-79.95513669083209,-1.5707963267948968 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark91(-80.11061266653809,-1.5707963267948966 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark91(-80.11061266653815,-1.5707963267948966 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark91(-80.11061266654035,-1.5707963267948966 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark91(-80.11589439927471,-1.5707963267948966 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark91(-80.33097481172867,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark91(-80.43493459794395,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark91(-80.68218854285448,52.35657015643099 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark91(-80.78581500006494,-42.59427404876087 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark91(-80.79601354995884,7.59892740906723 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark91(-8.0948E-320,0.0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark91(-81.03591590501298,-1.5707963267948966 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark91(8.103981633976685,-1.5707963267948966 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark91(-81.07592723062626,24.655147742991716 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark91(-81.0824787256131,28.674000389432347 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark91(-81.28568809085684,2.0679515313825692E-25 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark91(-81.31244559154358,-0.36920100283306284 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark91(-81.49656541784867,-43.238155096974836 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark91(-81.57240295770059,4.141592653595159 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark91(-81.60093685728715,93.39295182727307 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark91(-81.6814099594011,-69.1169916363559 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark91(-81.68153951368073,-28.274270021238706 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark91(-81.68922149333463,-1.5707963267948966 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark91(-81.73930168472809,34.89720910220141 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark91(-81.84448086077842,-55.45573558861811 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark91(-81.89836856817541,-18.1119299822807 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark91(-82.16228489432804,71.55685957008092 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark91(-82.17242826974518,0.17174530084074519 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark91(-82.32069628746603,0.0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark91(-82.35372564404403,86.49083920639089 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark91(82.39642232438783,33.66168939242536 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark91(-82.4997288231473,0.8183198298126694 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark91(-82.5991635833449,-57.03660690583684 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark91(82.68371617161009,36.87110834871805 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark91(-82.71272610453038,0.0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark91(-8.271806125530277E-25,1.5707963267948966 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark91(-8.271806125530277E-25,31.415926345460434 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark91(-82.9336696809664,-84.24362075917419 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark91(-82.98983124166679,-16.88125492611059 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark91(-83.07019104973097,-2574.7078585276195 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark91(-83.20884529230779,56.30108344228893 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark91(-83.24364592692905,-0.011111034454899027 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark91(-83.2700193161582,-41.7986799819746 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark91(-8.331385079757553,-166.69410904869724 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark91(-83.486849523508,-0.3499585899646971 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark91(-8.382465177527052,-27.904356332806103 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark91(-84.3700916976603,-63.89834708407405 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark91(-84.37819854509378,-39.10798147294834 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark91(-84.43240258790048,-86.56619859645633 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark91(-84.78783758655233,-2621.1964879264656 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark91(-84.79204796141818,-1.5707963267948968 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark91(-84.8230016469244,-1.5707963267948966 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark91(-84.83760762426927,90.3507460037458 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark91(-84.90738142074834,39.17363158322823 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark91(-84.94576610685274,-46.410567940255085 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark91(-8.49709585335527E-16,1.0484438295842169E-14 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark91(-85.0051670302452,-54.58373301328566 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark91(-85.04379916228793,39.68232587323496 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark91(-85.0978719995076,-61.83840021225834 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark91(85.0995690814853,94.66224271167576 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark91(-85.28505791831198,-72.6178553177308 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark91(-85.2865856095313,-1.5707963267948966 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark91(-85.37317247907657,-59.14008958605392 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark91(85.49211598219472,-49.847674647930184 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark91(-85.5934873309121,68.55088522887351 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark91(-85.61783525699988,-4.9E-324 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark91(-85.73732506905162,2669.0536373070136 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark91(-85.92567821106569,-1.1026765641412697 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark91(85.97729334692329,-93.66293751697208 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark91(-85.99810987997925,67.7526686823084 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark91(-86.11070186735404,78.54123262016046 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark91(-86.18308971378865,-1.360088066864229 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark91(-86.19438885773576,-57.74246380764683 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark91(-86.2340441918826,-9.639679460411536E-181 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark91(-86.29471321013304,4.047180537791428 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark91(-86.3436475775352,-1.5248283172928265 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark91(86.34442469942582,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark91(-86.39379797372321,-1.5707963267948966 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark91(-8.673617379884035E-19,-91.10618695410399 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark91(-86.82292785798221,3.3299958654878358E-257 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark91(-86.8691193666517,-34.55754116409729 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark91(-87.13599697727675,-45.66626038217323 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark91(87.57389333912442,55.82916273837671 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark91(-87.71781861047317,-1.8635324832937101 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark91(-87.82595746453798,31.2772896999217 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark91(-87.96459620786285,-1.5707963267948966 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark91(-87.9646095593033,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark91(-87.96460956137621,-40.84070449666564 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark91(-87.96570866527976,147.68611112255724 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark91(-87.99341079856815,-10.92848274777478 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark91(-88.0339670019252,33.14993339895065 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark91(-88.22922053452118,-14.158905582495535 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark91(-88.29886978693045,-25.13281543386183 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark91(-88.31054705123319,59.61230165687727 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark91(-88.31509285612555,0.6162286005120357 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark91(-88.43348934936414,46.65499475499697 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark91(-88.48490651261136,49.32252075256008 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark91(-88.49507582279578,-1.5707963267948912 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark91(-8.881784197001252E-16,-100.0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark91(8.881784197001252E-16,-109.95580683544796 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark91(-8.881784197001252E-16,-33.497174186820715 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark91(-88.94730948766615,-29.257049069460074 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark91(-88.95048190457261,-55.56278016055788 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark91(-89.08576339933563,-88.82684093556756 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark91(-89.23474815376954,139.89676618957822 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark91(-89.25000608716448,1.7529376610675675 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark91(-89.4020410577714,6.374972025635494 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark91(-89.71342779681892,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark91(-89.90535722537957,-11.721798894148705 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark91(-89.9230185904326,-55.36549940094488 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark91(-89.93106039722393,8.202780662461819E-17 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark91(8.997470102614782,97.81822532266698 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark91(-90.66085768042282,-61.31961598321838 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark91(-90.71479048571493,-50.1054782892218 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark91(-90.75367915330847,-78.89232414054037 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark91(-90.85134321617674,-60.29190022641202 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark91(-90.94412671363592,32.30166153432174 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark91(90.94915501228252,83.12423297952341 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark91(-91.1061869538828,-1.5707963267948966 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark91(-91.10618695410405,-1.5707963267948966 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark91(-91.10618695411299,0.0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark91(-91.10618719252265,1.5707963267948966 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark91(-91.10618794192878,0.0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark91(-91.10619076880127,1.5707963267948966 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark91(9.1235664673198,97.69300025114502 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark91(-91.30427783962578,-80.24959484008656 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark91(-91.39556059473458,-152.5127480391169 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark91(-91.73448683165553,81.59502270507409 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark91(-91.78798298409674,-52.45740760367279 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark91(-91.92296035763388,-33.50994817591844 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark91(-91.94554501618926,-119.25630839183147 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark91(-92.02053955733231,45.62399007847705 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark91(-92.03167868168777,2.1106356288215886E-227 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark91(-92.09922112430473,-0.9928474914552954 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark91(-92.22351229747663,-95.699121935277 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark91(-92.33302709683531,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark91(-92.5554986893879,-1.4493117352838991 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark91(-92.67596414857042,-1.5707963267948966 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark91(-92.6769832808958,-1.5707963267948966 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark91(-92.67698328090017,-1.5707963267948966 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark91(-92.8623725586092,-76.78363073523964 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark91(-9.29608347634539E-20,-87.96481592131498 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark91(-93.22285957469556,-54.961133873377086 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark91(93.6526806093342,-98.31217440923194 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark91(-93.86323528553349,-3.6455610097781987E-304 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark91(-93.86644976806573,-2.760262813961731 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark91(-94.24777960769377,1.5707963267948966 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark91(9.424777960769378,0.0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark91(-94.24777960815948,31.415926517759505 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark91(-94.24778151504727,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark91(-9.424793226329452,-65.9734618356689 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark91(-94.2497359200991,59.69026232555471 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark91(-9.424979716517598,0.4098253271933678 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark91(9.428684210769381,0.0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark91(-9.441404915678998E-15,-47.12388980394874 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark91(-94.67388047641403,-59.80861431184188 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark91(-94.7467902969251,6.782195996410888 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark91(-9.487715167343831,-28.21139667573369 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark91(-9.48910457978781E-8,34.55751909459668 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark91(-94.94725712370567,4.956253356627091E-4 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark91(-95.04453465593868,33.760764141242845 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark91(-9.522213566422242E-17,-251.32480650711227 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark91(-95.39704744591782,1.1492002299171031 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark91(-95.48244378538625,-55.314003586923825 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark91(-95.48477325530577,-1.5707963267948966 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark91(-95.49339891890769,0.0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark91(-95.62211037861437,-42.86131270241971 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark91(-95.67205727403363,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark91(-95.67425440281934,-26.30923336261135 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark91(-95.74730754685852,-2579.50572978202 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark91(-95.91398362580368,-51.063690501998174 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark91(-961.2692747278975,-1.5707963267948983 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark91(96.49815843641133,12.43441381321037 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark91(-9.689238933887163,-37.9635728161953 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark91(-9.70594175694967,73.55348841363124 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark91(-97.47562234189209,-1.5707963267948966 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark91(-97.62907044895405,16.09129902740821 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark91(-97.68840720824548,-2.0812474159298974E-258 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark91(97.71716318528615,78.45545991979449 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark91(-9.773970788041424,-12.044013790921255 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark91(-97.74113432577361,60.73738591240479 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark91(-97.80960490824725,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark91(-97.89466152210676,-15.52540178610166 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark91(-98.04159607995796,-0.6522238186743647 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark91(-98.11279201230128,-92.15762923358825 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark91(-98.20004184623664,-95.05844919264685 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark91(-98.20221518608912,-91.49971329710125 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark91(-98.31808116451916,-84.47376748180167 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark91(-98.36088093562432,85.1782815403636 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark91(-98.37011674568093,-6.136285113275367 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark91(-9.860681951752298,-0.7706509917319533 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark91(-98.67740139868211,-1.5707963267948966 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark91(-98.80557284238475,18.45635859187827 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark91(-98.84605183337612,-40.84071572784805 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark91(-98.96016858807883,-1.5707963267948966 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark91(-99.37080734466076,-33.3973616192751 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark91(-99.50812086395058,7.105427357601002E-15 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark91(-9.9590908292015,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark91(-99.66719848577601,59.69026045088452 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark91(-99.68346265376327,-0.922071347888539 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark91(-9.969124532822567,56.00432119256309 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark91(-99.79247583212496,-56.0573969309329 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark91(-99.99333374315822,4.440892098500626E-16 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark91(-99.99674877737218,-0.5342161375012079 ) ;
  }
}
