import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(-0.0010102564841950401,-39.27091842645661 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(-0.0025034645132906664,-1.5707963267948966 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(0.004501322067874956,-89.53088930534123 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark02(0.007156498595251126,-21.633544499194073 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark02(0.01171987755074097,-0.4036931098017976 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark02(-0.011854598687224438,93.79002622823754 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark02(-0.011915688166576885,7.865897322241067 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark02(-0.013824567983558321,-1.5707963267949725 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark02(-0.013861500675596126,-0.5553560069673763 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark02(0.02435059041460132,-64.63118270636308 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark02(-0.028338531915598875,3.449914257501547 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark02(0.03147080460241063,0.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark02(0.032037736410757134,-38.44006000852954 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark02(0.038947624915599895,0.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark02(-0.04352517418576484,-98.91664341379263 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark02(0.044405356840398806,-87.27923496510344 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark02(0.04542474446718929,-0.266013052557397 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark02(-0.04796070397700891,14.277111702202845 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark02(-0.05078382316888508,-0.008398357605955498 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark02(-0.05641968171564373,64.45906908040656 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark02(-0.06413179571656258,-95.81971240334859 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark02(-0.06632897020283121,67.4779130818775 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark02(0.06957924168249008,70.6162554641881 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark02(-0.06969797582533815,-19.65171346418512 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark02(-0.08605512491782533,-89.6214457523273 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark02(-0.09066937627574709,89.5931186762943 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark02(-0.09249804221915081,-57.62777560812009 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark02(0.09348013188241186,45.45961334527003 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark02(0.09916284688433107,80.20977551429716 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark02(0.12385591447528423,-4.317338005397984 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark02(0.12664064978121767,1.5707963267948972 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark02(0.1295308805038946,2557.421316209524 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark02(-0.13383188565872883,-1.507569007450586 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark02(-0.13443062713160359,-13.607326847506524 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark02(-0.13542415331539712,1.5707963267948966 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark02(0.13620414703398934,-14.429203677079315 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark02(0.13657766312380204,-39.228554961519045 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark02(-0.13662806023836263,2479.8992407758774 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark02(-0.1456893189836972,7.661678734143864E-4 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark02(0.14663597787484267,1.5707963267948981 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark02(0.16018446905306996,-33.366008721539885 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark02(-0.1634054077557559,117.80622584561262 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark02(-0.16434628686235087,1.570796326794897 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark02(-0.16839968281518555,1.570796328277332 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark02(0.1830239860652275,-82.06770823493417 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark02(0.1831891638065315,-1.5707963267947314 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark02(0.18362053310499965,-31.614989936186994 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark02(-0.18982736339710773,100.0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark02(-0.19008263946643514,10.805491647996007 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark02(-0.19182257993514007,-1.5707963267948966 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark02(0.1918326114599811,-0.08810869044832259 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark02(-0.19669095090635988,1.5707963267948968 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark02(0.19941803059191443,0.0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark02(-0.21260759421134257,-89.79258412680697 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark02(0.22492883380451056,0.0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark02(0.22742099366773844,1.5707963267948968 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark02(0.24301718305746262,-96.588500004896 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark02(-0.2522231219553636,0.4630729279754632 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark02(0.25899054864615323,29.75224630936998 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark02(0.2652914265005001,-9.650387992790115 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark02(-0.26592600342792067,37.853675073392914 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark02(-0.27986850876638814,-1.5707963267948966 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark02(-0.28871186773207724,23.39423970986558 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark02(-0.2954065583194707,-52.494737268900415 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark02(0.2966842370910279,-53.470749712640455 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark02(0.3137673728590651,5.98827613704799 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark02(0.34074314214054624,-87.52785152505017 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark02(0.3419768612800169,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark02(-0.3578783433922711,-3.5601114154827466E-4 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark02(0.36226412424409915,136.36969184251035 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark02(-0.36777123974939246,0.5707919388818153 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark02(-0.3730008762312042,4.339388104046102 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark02(-0.3772210859309615,76.41708511870044 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark02(0.37765714489988,100.0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark02(0.37836851814522887,-1.6671452998520095 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark02(-0.3869034180348032,-1.5707963267948966 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark02(0.3917412317797613,122.45736855661445 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark02(0.4006863490101311,-1.5707963267948968 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark02(-0.40116648182935943,0.0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark02(0.4164307816255224,23.59393843031053 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark02(-0.4222172751788793,-1.5707963267948972 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark02(0.44240696488501113,100.0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark02(0.45142463311050296,-1.5707963267948966 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark02(-0.4569392978656992,-4.2554496824075585 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark02(-0.4610536921577838,0.0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark02(-0.4676630789004226,-63.83868544277631 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark02(0.468846669326485,74.29627402857453 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark02(0.48756279109611644,-0.7335644794275118 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark02(0.4889410732242685,1.140631360134388 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark02(0.4985811605359629,1.5707963267948966 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark02(0.5006389852931592,72.84329391071265 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark02(0.5118988790010155,0.0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark02(-0.5132531159458433,-27.952938644291606 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark02(0.5170176440025358,-1.6788707195182784 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark02(0.5185062377838392,36.497198342130474 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark02(0.5200177906037011,-93.71411587379166 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark02(0.5259254739928139,33.45476037765473 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark02(-0.5307071303713833,-41.70118171046258 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark02(-0.5656755495833081,99.09715150720815 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark02(-0.5677035678948581,51.94301351637466 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark02(-0.579593769358258,-38.99261451744687 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark02(-0.5853821452321617,-29.781342113540553 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark02(0.5903142105236512,-1.5707963267948966 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark02(-0.5958970713586095,58.71536116289061 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark02(0.5975182253705293,29.21968283588667 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark02(0.6046407606305673,-90.7249059230488 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark02(-0.6064190731437762,-86.4071486838847 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark02(0.6319465857021883,99.14082113494256 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark02(0.6334047066299777,15.533088920589263 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark02(-0.6374442763830714,0.01372127553267661 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark02(-0.64210607128125,0.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark02(0.6429837820142801,1.5707963267948966 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark02(-0.6533220930659789,10.342252194372364 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark02(-0.6564354472340597,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark02(0.6804139563387963,26.133952566417335 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark02(0.6876690579739841,0.0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark02(0.7105139660808364,-1.5707963267948966 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark02(0.7141115765775847,100.0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark02(-0.7146218528951425,-85.67917612072013 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark02(-0.7394613054209493,16.538636090920154 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark02(0.7588211393335668,1.5707963267948966 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark02(0.7603535974448082,0.016808937326829088 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark02(-0.7634297005977179,-58.88289379214731 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark02(-0.7734363520913186,98.43517387636986 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark02(-0.8302956376202841,-36.843760079938214 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark02(-0.8312273994022394,1.5707963267948966 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark02(0.8486720594972752,-107.88793813096713 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark02(0.8532140000679047,0.717582326879068 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark02(-0.8567533003438789,-79.37022298827114 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark02(-0.8596579713844646,0.0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark02(-0.8727431753198862,23.565336108615924 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark02(-0.8814017728448322,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark02(0.9258936651312695,92.45861008951775 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark02(0.962284453301848,-37.59236970530458 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark02(-0.9724224953205518,-72.6552114981037 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark02(0.974378344671905,12.48578117338991 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark02(0.9753328364817521,-27.30444762105887 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark02(-0.9757119290890424,39.39760836874504 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark02(0.9800167714917627,0.0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark02(-0.9894304883158611,129.86343171869348 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark02(0.9960107839480825,-55.152424040023725 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,0.0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark02(1.0000006123233996E-10,-1.5707963267948966 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark02(1.0000006123233996E-10,1.5707963267948966 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,0.016307315413849617 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,0.016725338562721154 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark02(1.0000028327694488E-10,-1.5707963267948963 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-100.0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,100.0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-1.0398314120374792 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-1.314430580860749E-5 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-1.5707963267948948 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-1.5707963267948966 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-1.5707963267948968 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-21.991148575128552 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark02(-100.02261333082785,-5.2207405643159435 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,2615.401665131401 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,45.50327585318942 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-6.116194612263939 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,6.42920370797257 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-6.760619329535487 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark02(-1.0007159638329952,-1.5707963267948966 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-79.56809669399577 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,82.20928649448348 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark02(-10.02426187354017,5.31048066254593 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark02(-1.0029635008939677,-53.974907936741474 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark02(1.0041287064122315,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark02(100.53131620844904,-1.5707963267948966 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark02(100.53848688537043,107.78553140898077 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark02(1.0068035379329592,40.7053530168173 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark02(-10.084310248438845,64.50746885534514 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark02(101.07870342707352,27.498390090185524 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark02(1.0145391568273763,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark02(1.014663299153772E-16,1.5707963267948983 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark02(-1.019888758778432,-59.62360409324361 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark02(102.03434463792391,-40.20829202676839 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark02(-10.243821900664468,-168.8942509068026 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark02(-103.15848617866058,6.51938854119534 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark02(-1.0339757656912846E-25,-0.5707961051028488 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark02(-103.67049678700391,-1.570796326793071 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark02(-103.67258808604132,1.5707963267948966 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark02(1.0398314121189987,100.0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark02(-10.440243933447391,-1.570796326794948 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark02(-10.443963871473247,0.34596602829028683 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark02(-10.46460937288838,100.0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark02(-10.485888567877284,74.88853796626309 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark02(-104.86505915068507,-1.5707963267953957 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark02(-105.22976618487039,7.239851798991965 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark02(-105.23962126819896,-14.429205425370178 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark02(-105.24335389525942,0.0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark02(-105.77269989986397,-44.31324180395807 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark02(1.0587687745112937E-8,-1.5707963267948948 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark02(-1.0587911840678754E-22,-95.818575731621 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark02(-10.593245990295525,-1.5707963267948983 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark02(-10.602589652627856,-61.13052024144985 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark02(-1.0630633088626777,77.07704018297443 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark02(-10.685389245583874,0.310185042308016 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark02(106.91706013403655,-1.5707963267948966 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark02(-107.26174613448899,0.23473560919751435 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark02(-10.769375952562505,88.30831673152795 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark02(1.0792266573798432,65.6806795333381 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark02(-1.0801275907112684,-84.6777962207993 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark02(1.0832385969542702,45.15373008063811 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark02(1.092415927759654,0.04784653657300148 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark02(-10.942323947794193,-30.742391512177633 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark02(-10.995574287561725,0.0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark02(-109.95587238422698,4.859928975231491 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark02(-1.0996044898047765,-10.53778633159446 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark02(-11.021092673818462,0.0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark02(-110.36049020250023,1.5707963267948912 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark02(1.1085357860335563,96.97021003195204 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark02(1.1116981259238505,-16.65732247951472 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark02(-111.48803764725592,-63.49305840950612 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark02(-11.156790754264634,1.5707963267949197 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark02(-111.95497536831186,1.5707963267948966 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark02(-112.54480611275487,-1.5132762435785343 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark02(-112.60994345916734,-75.81232743494341 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark02(-112.8958447969867,9.92461892994892 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark02(-113.08698757560767,-71.04648765013191 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark02(-113.47981155049598,-1.9532723481904217 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark02(113.52566489745755,0.5703681144232516 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark02(-1.1353955437242318,-0.28568742313118484 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark02(113.73959070072257,-0.04907548657980698 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark02(-114.15434424545343,1.570796326794893 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark02(1.147436705902237,99.66475542215903 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark02(-11.478092689222265,22.217279088954072 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark02(-1.1507472294643817,-49.87585776376211 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark02(-11.51615823526464,1.32354186144957 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark02(-1.1526216411819217,1.5707963267948966 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark02(1.1550938186850623,0.4157025083574607 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark02(1.1603646464290787,0.0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark02(-116.23154312780267,-4.714346424656364 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark02(1.1628321743263106,0.5707847209153784 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark02(-11.639909470192043,-6.927520489973834 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark02(1.166926361494443,1.5707963267948966 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark02(-11.671642621702148,-74.72215535185735 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark02(-11.693110590960544,25.882703968656102 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark02(-117.55945317061024,6.062022271196483 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark02(-117.7457996960065,-37.69911184307752 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark02(-117.80972450961397,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark02(-118.21210835773451,50.667866305809305 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark02(-11.84256818830292,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark02(-118.60850885600762,77.05420261144752 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark02(1.1883535774762635,-2576.627213032222 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark02(-119.2587774245686,-4.839531036943213 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark02(-1.1948622837963174,2.3490593648684232E-17 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark02(1.1983264542765344,4.539252597082523 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark02(1.210158637329059,0.11519599736840366 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark02(-12.122320144190564,-1.5707963267948983 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark02(-1.2135755636499521,1.5707963267948957 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark02(-12.19926630717173,-1.5707963267948966 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark02(-1.2210908668900309,-45.08807838133557 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark02(-1.2314018280481924,0.0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark02(-1.232595164407831E-32,-1.5707963267948963 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark02(-123.71748069378198,-29.94417782354337 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark02(-12.56637041376106,-51.83628071031153 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark02(-12.566370596472877,-4.712388980384653 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark02(-12.566370614223288,14.137289011478085 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark02(12.566370614459172,-1.570796326794897 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark02(-125.66372148483518,-0.5240097696944611 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark02(-12.566896173705977,117.81620550300732 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark02(-12.569262025833792,-80.10995853081545 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark02(-12.61163815489049,-10.43702685674414 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark02(1.2615843589922235,-7.828075685646439 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark02(126.70515078659216,-80.49317202267598 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark02(-1.2696559247830208,93.20088745272028 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark02(-127.02899965120433,81.36864986399448 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark02(-12.70953691534958,-98.6479514017087 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark02(12.711680251689799,-45.41732325673291 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark02(1.27142321179416,-14.429865836578792 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark02(-12.727024813375017,1.916989061324571E-4 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark02(12.729562897315482,-1.5707963267948966 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark02(-12.732278751641928,-0.4812926461126098 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark02(-12.749804209011407,80.34672147075761 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark02(-12.765371765286517,21.690437792869545 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark02(1.2772270761983202,-1.5707963267948983 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark02(-12.791487670258931,88.02794530419882 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark02(-128.0497452064009,-15.317752975255686 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark02(-12.813412859751239,27.21831825268211 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark02(-128.80514776639623,0.27557702894821745 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark02(-1.2899197064835985,0.0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark02(12.902473595062204,-1.5707963267948983 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark02(-129.13842044431664,61.261071271554336 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark02(-12.935417245115888,98.59112195721455 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark02(-1.2940575678363235,0.4801452015855695 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark02(12.9560654699049,-87.16566172459284 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark02(1.296902882878186,10.669938951571023 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark02(12.986388461841756,-1.5707963267948912 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark02(-1.3009632959220399,0.0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark02(-130.39687524029478,0.13061490778573823 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark02(-13.046568249740133,-30.25748094832152 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark02(-13.068679320180749,-19.014018153327797 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark02(-13.075506582168373,2.5707963267949254 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark02(-130.8343461250939,-0.4582510013435389 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark02(-13.120596651159342,-65.5712562593264 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark02(13.134116985443129,95.14484447834332 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark02(-13.167630536114483,1.5707963267948961 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark02(-131.94689145073522,1.5707963267948966 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark02(-1.3320773023342825,-71.59816761804336 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark02(13.398808553479796,1.5707963267946745 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark02(13.474241330777659,96.24021536722708 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark02(-13.480569199678712,-57.958906186998284 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark02(-1.3494937327943461,0.0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark02(13.504342208875459,1.5707963267948966 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark02(-135.08859716417746,1.5707963267948983 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark02(-135.33384701871162,67.05196185371395 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark02(-1.3552527156068805E-20,-1.5707963267948963 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark02(-1.3552527156068805E-20,-7.8539816339736594 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark02(-13.566502218570413,-61.78082782784654 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark02(-13.604147635542093,92.67707566662251 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark02(13.604912276654705,-50.81843707999296 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark02(-13.617789391648394,1.5707963267948966 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark02(-13.630745567948807,21.500577678736803 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark02(1.3681091907771399,48.6946861306418 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark02(-13.7099443645657,0.0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark02(-13.737095794707397,50.35247034447369 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark02(-138.23003174887475,17.27875959474372 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark02(13.824212836072817,-0.03145554745717132 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark02(1.3843227065773647,-100.0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark02(13.865012397691281,-0.27215454383479754 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark02(13.87063776002168,22.884848076365785 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark02(13.922211242062616,-1.5707963267948966 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark02(-139.60652395453957,53.88782964433784 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark02(-139.9107749602916,26.2402386512983 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark02(1.4002775434708654,0.26275355161968295 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark02(-14.01329185719726,-122.68748381482277 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark02(14.052033463542443,0.0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark02(-14.054300184163623,19.8799939072154 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark02(-140.58906235252215,-100.77182532893977 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark02(1.4059557044626074,-84.17164665666037 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark02(-140.97435938493243,0.0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark02(14.103100030265653,-0.48794308661122887 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark02(-14.131966192979945,-1.5707963267948966 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark02(14.136246321379112,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark02(-141.3684958831091,7.857803601165081 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark02(14.13716694115214,0.0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark02(14.137166941154069,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark02(14.137166941154069,24.559721575014407 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark02(-141.37272255498104,83.25224039593208 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark02(-1.418109324619324,-97.54205926280171 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark02(1.4210854715202004E-14,24.81272558092575 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark02(1.4210854715202004E-14,6.9562072958266015 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark02(-1.4221566425258687,-2624.284795668563 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark02(-1.42371789600368,-16.410626688175498 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark02(-142.72414244033678,-88.46625662729299 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark02(14.27257657621152,-6.418539963465145 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark02(-143.10954779159823,19.01663797540267 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark02(14.33080256255846,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark02(-144.5171891199907,14.438557168553764 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark02(144.66886776677012,174.3842510686123 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark02(145.0031605871789,46.99105058252002 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark02(-14.501744256888685,31.047751336477205 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark02(-145.08506540812255,-77.69690272134352 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark02(-1.4547020443945038,-8.878466302427363 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark02(14.563231995837157,89.64539065933698 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark02(-147.16197044127472,-58.30608723184845 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark02(1.472985893719251,-1.5707963267948972 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark02(-147.51651441688284,75.9210266272616 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark02(1.4813983788732514,-99.57408231333733 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark02(1.4825248811778764,2594.461154218784 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark02(-148.25858865322067,2.4310133223468227 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark02(1.4875389313548055,-73.82753357609502 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark02(1.4885418136330202,-26.3627253617587 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark02(-1.4902491524036634,31.6280514635979 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark02(1.4945008095563481,-24.662428415153357 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark02(-1.4959404220130583,100.0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark02(-1.5001024446686755,1.3097616817798884E-9 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark02(-1.504632769052528E-36,-39.26990816987241 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark02(-15.064775689363202,-1.5707963267948912 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark02(-1.5071279256055785,-17.63532019312389 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark02(-150.79644737221008,-1.5707963267949032 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark02(-15.17922127459093,54.43979093286771 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark02(151.8426484728282,-135.1413960432706 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark02(1.5237778856864184,-29.458516442500873 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark02(-15.255530285651464,1.5707963267948968 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark02(-152.55993237419005,-54.85311159426658 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark02(-15.263247553315964,-2.3538133860030745 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark02(1.52990550445638,65.03320024468111 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark02(-1.5320287288071681,-34.009894593509 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark02(-15.345369989825473,1.5707963267948966 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark02(15.395302968608718,-1.4701818316128055 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark02(-1.5403489966230728,0.0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark02(-1.5407439555097887E-33,-14.137166940804756 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark02(-154.07476782993314,-31.652278623572982 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark02(-155.0314446859991,1.5707963267948963 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark02(1.5515069141637168,-157.63916056944686 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark02(15.614677780702863,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark02(1.5661551025113811,42.00122444177317 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark02(-15.673513122096765,-2.073281232995385 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark02(1.5674515560074207,57.61299144699695 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark02(-15.68255665076267,32.531638519747645 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark02(-1.5701122788246265,1.3694384955838865 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark02(-1.570509465695856,-11.044544801956413 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707925505953582,-78.53981633563187 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark02(-1.57079632562582,30.301036962131906 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267559315,0.0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267829417,0.0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267945066,69.77377630051855 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267946354,-24.266104792235495 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267946603,22.59460463026774 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267947758,-17.278759594759446 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark02(-1.570796326794806,1.5707963267948966 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948841,84.66502292444235 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948912,-53.96573911430097 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948912,72.27280439644957 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark02(-1.570796326794893,-100.0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark02(-1.570796326794893,-44.09470273315333 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark02(-1.570796326794893,-71.17463924557082 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,-100.0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,100.0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,1.5707963267948966 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,45.182811035527436 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,62.61444949895761 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,-80.43887855640027 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,98.92083998126185 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948957,168.07545110767896 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948957,77.84574368427823 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948961,-0.12995098194955865 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948961,-2517.9423824191263 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,-63.40831045719439 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,72.1651576258693 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,88.27639280605199 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,9.511145331626686 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark02(-15.707963267948964,0.0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.0049253506921219554 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.0279433053129347 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.04858152865401774 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.0978224170211891 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.26556937957724586 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.4192237812460155 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.5590240223154411 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.5678107589271543 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.5696324186357217 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.570716636219403 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.5707963056741577 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.8805577547973884 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-10.995574288460713 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,10.99566571199438 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-11.338755369673454 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-12.763766367909271 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,128.80512854692805 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-13.204276828545702 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,135.57407294309718 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.413476702817053 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.5707963267941152 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.570796326794783 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267948957 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.570796326794897 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.5707963267948974 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267948974 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-15.862450532567372 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.8147177079160977 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-19.159283065705054 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,19.279281870238076 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-22.58497293649262 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-22.642107507252547 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,22.65550826876779 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,24.23395137408677 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-2533.07064241274 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,2567.0611951037267 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-2626.1111659176854 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,26.703537555513233 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-27.69537669023856 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,27.703537235401814 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,27.916914001561537 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-28.27433388230687 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,28.27433388231251 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-28.52473648840214 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-2.8744979906541346 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,29.255909778541877 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,29.889306238494946 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-3.129470125536571 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,32.072529456581776 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,32.98672286269282 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,3.3417297077627417 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,35.58137421814604 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,36.12831551628452 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-36.19824022741392 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-39.26990816987241 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,39.30052052710926 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,39.66796815786067 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-4.015180963534954 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-40.69553817100622 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-40.767285029912784 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,40.84070449666578 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,4.222753925045282 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,42.41150463815948 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,43.24931423608615 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-44.128802337741526 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,45.021422152893905 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,45.17080029550744 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,45.553093477051995 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-47.123889803851206 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,47.123889803852656 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,50.06316456956558 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-54.97787143787959 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,54.97787144009455 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-5.583245460433778E-5 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,6.123233996014252E-17 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-63.14363166368406 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-65.97344572536142 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-65.97344572539043 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,66.05847804959639 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-67.17908177324567 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-68.05718315911528 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-71.71524366263625 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-72.25663103256734 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,72.25663103256922 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,72.25663104935788 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-72.34213834846501 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-73.8274273598258 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-77.96902001294993 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,78.53981633973771 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-7.910585643580417 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-79.64424834904997 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,82.4973494466683 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,82.98042493068789 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-83.2522053201295 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,83.2522053201295 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,84.36823272898546 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,85.9888956340917 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-86.39428625872324 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-88.42588884760653 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-8.853981633974483 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-92.67701379847729 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-93.01881910281001 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-93.72064936510046 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-95.49939322964174 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-95.67049198953426 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,95.76644950832116 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-97.38937226128854 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,98.02603633602337 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-9.900888823088081 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948968,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948968,-0.5573787220886529 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948972,0.0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark02(-1.570796326794897,2600.1389031357294 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948974,56.88751460344281 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,-120.95131716320698 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,24.124747676424008 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,-2.580538199533194 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,57.974125088845895 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,87.32863717339444 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267949019,0.31440627881292615 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267949019,-56.737688618291045 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267949019,9.38629277245586 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267949054,0.0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267949054,-100.0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267949054,9.78876293482243 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267949197,-81.18713211899033 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267949776,-1.2133619509792295 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark02(-1.5708000994631757,-72.2566310326053 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark02(-1.5708001036120796,15.707963263122702 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark02(-1.5708044743363654,-28.274338820894027 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark02(-157.10972641043105,-45.50191484042806 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark02(-15.719721963686071,0.17953989439581985 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark02(-1.5760554723072475,172.79285507402207 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark02(-157.81545292348238,107.46562799228832 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark02(-15.8665150035207,-14.430507088989252 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark02(-15.907368819558897,1.5707963267948968 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark02(-15.910628563384389,80.31333807945867 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark02(-1.5916422999353235,65.9942916937336 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark02(-15.97509832036753,86.6609330260342 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark02(-160.22080808076404,29.84514121361062 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark02(-16.06605866295186,47.59003936161565 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark02(-161.63519940751803,-11.331662456024716 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark02(-16.19251631090763,0.0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark02(-16.22976274285716,4.7698516275976175 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark02(-16.234590495212913,1.5707963267949054 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark02(-163.36361093213594,7.853981633869553 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark02(-16.342192428672547,28.129568203391557 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark02(-16.428467741571566,57.953128677881125 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark02(-164.3142662812144,21.371800543051073 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark02(164.4919154943865,-38.08484034083317 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark02(-164.5371762384468,15.054985034487842 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark02(-16.544133295777968,-56.03203370553298 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark02(-16.61243282815201,-21.57750571399653 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark02(-16.693694226806272,92.02970800686506 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark02(-16.766039462412156,-57.684270058431 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark02(-167.9086306955129,-37.865688115221644 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark02(-16.822982654071367,51.10305331363301 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark02(-16.861173226247644,-100.0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark02(-16.886070349678008,-72.62721195264865 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark02(-169.17304868238097,0.5357400421191016 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark02(-169.2903218432575,17.63444110819334 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark02(-170.59389778066765,65.70634134410898 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark02(17.159807937672955,-191.51820021274906 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark02(-17.230627553863158,1.5707963267948968 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark02(-17.23380967915587,-0.7879162007537877 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark02(-172.6635192898734,51.9603554418976 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark02(-17.331019224192957,0.0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark02(-1.734723475976807E-18,1.5707963267948961 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark02(-173.8913244603365,-49.501745224611525 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark02(-175.9291872360075,102.10176922781153 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark02(-175.9294484576292,0.43258662839105677 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark02(-1.761699326632219E-10,158.65033038203077 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark02(-177.4375995827291,2585.82858238034 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark02(-1.7763568394002505E-15,-10.646576874698411 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark02(-1.7763568394002505E-15,13.020460553683549 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark02(1.7763568394002505E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark02(1.7763568394002505E-15,-92.30118031310894 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark02(-1.7791822447802526,59.93389904006044 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark02(-17.840788321883167,1.5707963267948948 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark02(-17.9009196418942,-1.5707963267948972 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark02(-180.59283519718883,-43.48952522051655 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark02(-18.19522922745864,19.00414029052648 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark02(-18.223512154267215,60.80115081885302 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark02(183.2726111446535,-39.0678280810752 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark02(-18.395918347752897,4.400263255785035 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark02(-1.8546030753437107E-68,14.137165200864594 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark02(-18.59549463559469,100.0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark02(-18.610443231149993,-14.430005105159786 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark02(-18.74917874055838,1.5707963267948968 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark02(-1.88077289285075,-37.75061026406826 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark02(-1.88079096131566E-37,67.54521861625436 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark02(-18.849555921537952,-17.27875959464467 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark02(-18.84955592153876,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark02(18.84973333065289,-2381.5591156998103 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark02(-188.49946546541233,0.5705446237051329 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark02(-18.852729935568842,-23.569787976923422 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark02(18.85736842007338,-124.10072524164664 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark02(-18.857368421540528,0.0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark02(-18.877319011229886,-45.456593445039495 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark02(189.6955216683847,25.503575102792066 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark02(18.96973183254005,-1.5707963267948966 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark02(-18.98066122014903,-73.41345308317642 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark02(19.01897477248862,2727.7925550900436 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark02(19.050668962126593,-11.641288360574407 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark02(-19.07952160920574,0.2186773424162023 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark02(-19.08062739597893,-1.8018678013377971 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark02(-19.20703819130084,-34.751504542277445 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark02(-19.242197593636266,-27.99033112354674 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark02(-1.9259299443872359E-34,80.11061280503971 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark02(-19.28617221843531,-77.51725390404675 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark02(-19.349254769157923,21.89658434341962 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark02(-19.34955593080126,67.17553577775558 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark02(-19.366071271210927,17.341352746745343 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark02(19.40273512772619,-42.79218804666598 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark02(-19.43105078369514,-67.54430295194454 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark02(-1.9447326710012367,-0.001531554190874602 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark02(-19.472762510113025,-60.63785015630355 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark02(19.58021458827585,-0.28615716804313884 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark02(-19.593087021051872,88.22984170768063 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark02(-19.61055925186787,-46.15874805269475 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark02(-19.6775922184425,-49.702141668628414 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark02(19.721299368958455,0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark02(-1.9721522630525295E-31,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark02(-1.9755679327552823E-15,-73.84305235936161 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark02(-19.77328675950119,63.969753518394896 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark02(-19.85979827115664,27.713779905319218 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark02(19.898983825287868,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark02(-19.904014481196967,-86.84019068223536 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark02(19.922029591181882,-43.20847386047597 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark02(-19.965551486752503,-44.13538386884839 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark02(19.998763836843693,46.63036576750516 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark02(20.044348250875743,0.28730394484843436 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark02(20.089996718421162,-1.5707963267948966 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark02(-2.012477138623363E-18,7.8539816339744455 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark02(20.14618590951924,30.441436125148385 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark02(20.14631649176526,-14.429203971053795 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark02(-20.183962774349016,-1.5707963267948968 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark02(20.205968817442113,-18.365991012936604 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark02(20.216098404826937,-23.878397300037914 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark02(-20.247667442909275,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark02(20.417440843706878,31.21814655994349 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark02(-20.43977894999754,-2.470825868212376 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark02(-20.516359358916883,0.0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark02(-20.519070371237753,97.48809038317319 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark02(-20.524327161952584,1.2172816002101514 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark02(-20.535198804700965,28.28796528870165 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark02(-20.537830549670563,-3.2590709540736 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark02(-20.63235257668579,-8.102400342599223 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark02(-20.640786510562556,55.33439094654487 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark02(-2.0664045404616047,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark02(-2.0679515313825692E-25,0.5695222200575768 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark02(-20.697143553666933,19.364427526163723 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark02(-20.753504354879254,92.1825918278827 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark02(-20.769130514698645,-1.5707963267948966 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark02(20.804901508707104,0.5678308236517751 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark02(-20.864393820759446,83.7832791015326 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark02(-20.866636000965023,0.49999456183610486 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark02(-20.898014882409356,4.185529031047164 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark02(-20.89898084425115,-12.848054876636343 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark02(-20.972641788938446,0.0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark02(-20.98878523874534,1.5707963267948966 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark02(-21.012736364170593,-47.5521041463567 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark02(-21.12876056086499,1.5707963267948966 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark02(-21.256787220748265,-2596.59967818426 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark02(-21.43542611816285,15.150425652664012 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark02(-21.488079878318175,99.74156032103028 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark02(-21.490938374298352,-98.62734475999954 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark02(-21.527500391336773,-53.68477275780172 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark02(-21.570777085448213,84.68754863004615 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark02(-21.585833262268125,-0.01052463831110098 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark02(-21.59188365782629,-146.48332296790596 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark02(-21.6692505840101,-26.133964063307587 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark02(2.1684043449710089E-19,-1.5707963267948966 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark02(-21.69334952334628,-98.99244579587261 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark02(-21.70434026462687,49.196438411353995 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark02(-21.710359100257605,-32.76598624516137 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark02(-21.726371809854967,77.5274398957313 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark02(-21.839674337365707,86.14956760936991 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark02(-21.854808943252152,39.40624780184975 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark02(-21.875213713304028,-1.5707963267948966 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark02(-21.89280332952363,1.5707963267948983 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark02(-21.92429836133611,-1.5707963267948966 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark02(-21.986410150946284,42.44439741741951 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark02(-21.987451141342028,-0.38847548045783553 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark02(-21.990962756612603,4.712450209618053 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark02(-21.991148574772403,-1.5707963267948963 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark02(-21.991148575006203,-32.986722862334865 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark02(-21.991148575111676,-67.54521862594508 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark02(-21.991148575123788,0.0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark02(-21.99114857522446,-1.5707963267948966 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark02(-21.991148575228554,-17.278759594743864 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark02(-22.02239857795916,-130.3760841625119 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark02(-22.043112840420434,-40.82640989247979 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark02(-2.2085582542412884E-5,-142.9426023058508 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark02(-22.132555193644038,-2634.8314837367234 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark02(-22.217358159267818,-1.5707963267948966 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark02(-22.24997637971542,-0.4261617371810119 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark02(-22.35366141347825,88.44110975690077 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark02(-22.48457402905042,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark02(-22.60838923038344,0.0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark02(-22.618879705632835,152.24961691251818 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark02(-226.19482353483025,-1.5707963267948966 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark02(-22.638849012366038,-84.19450528249693 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark02(-22.675418345709986,-1.5707963267948966 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark02(-22.99613691812685,23.670996133424005 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark02(-23.093964288656665,-25.43624074718511 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark02(-23.138245005720975,100.0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark02(-23.315205451138407,-1.5707963267948912 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark02(-23.391826222575787,-3.6509312233638838 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark02(-2.3489779016579893,-67.12844158514747 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark02(-23.509789116386372,33.296530101189035 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark02(-23.51446521350369,1.5707963267944265 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark02(-23.52418954588886,69.15279373765794 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark02(-235.61428013813355,23.561975420764956 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark02(-23.593440179378085,-31.44742181652615 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark02(-23.60646287466401,61.44713540533911 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark02(-23.608900677078026,-50.70370599991498 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark02(-23.695863685662474,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark02(238.76887224775174,-17.278759103446532 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark02(-24.005225314313744,51.33082555965126 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark02(-24.102327410825893,0.0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark02(-24.164018652278287,-57.3834993480935 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark02(-2.425589096538559,-21.46930568710306 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark02(-2.4366073477392263,-49.829883288327935 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark02(-24.4490171053206,62.50215251619687 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark02(-2.456517621876231,36.67739039830383 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark02(-2.465190328815662E-32,54.977871438287046 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark02(-2.468539262587591,-0.020411952572512715 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark02(-24.85435503627191,-2694.145545486627 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark02(-24.983536817561877,16.280414504637925 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark02(-25.045689538061836,0.6443894681309601 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark02(-25.056954253442925,1.5707963267948966 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark02(-25.132741228618396,-23.56194490192344 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark02(-25.13274313606698,-120.94907227585335 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark02(-25.13274313607427,-1.5707963267948966 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark02(-25.1327577607316,-14.137114497090835 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark02(-25.13664747871859,54.97799353168272 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark02(-25.19616354256315,-1.634217169683976 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark02(-25.234431341886193,-1.5707963267948968 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark02(25.26350901770185,61.261192305198776 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark02(-25.26680989752586,66.14113312705393 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark02(25.27711434396477,38.96490679745083 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark02(-25.36771740427066,-14.460291711127674 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark02(25.370986937254003,0.0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark02(-25.418935493996585,-51.83872974714754 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark02(-25.442498243556955,1.5707963267948966 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark02(-25.581272137366355,29.283469015821595 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark02(-25.587322176854663,-38.5214430821613 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark02(-25.602462844984252,80.11062392904876 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark02(25.653586546160994,-63.335955569527265 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark02(-25.695940094464653,3.434724375267575 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark02(25.70526171571203,-1.0114882889856656 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark02(25.83258447811451,-63.702806149325326 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark02(-25.855485765787268,10.952121099304364 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark02(25.910134176148564,-33.401027705776265 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark02(-25.930198710895105,-65.83374044206028 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark02(-26.08666906547748,-48.54121400208602 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark02(-26.131755150512937,52.83529270621098 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark02(-26.13271764977023,135.65910481711 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark02(26.18723342261803,-94.76408374079158 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark02(26.209784571176126,-7.228088327030065 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark02(-26.223572866636474,-79.03268563596275 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark02(26.237650800645113,-53.23128861344604 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark02(2627.5933322932883,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark02(-26.306273403901073,-84.42573749557071 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark02(2630.676566940486,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark02(-26.31482842243014,-79.46053137563834 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark02(-2.6346427594471794E-11,1.570796326921243 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark02(-26.350062868107077,2.78811796647251 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark02(-2642.392813851119,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark02(-26.57870800900413,0.6483631995423167 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark02(-26.6087606140581,-0.477994888268933 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark02(-26.620508285952965,-0.39659407058593477 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark02(-26.6972283314712,11.066399741281678 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark02(-26.732331851956268,-1.5707963267948934 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark02(-26.769430980579003,-0.5830866765005055 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark02(26.916926910262262,-10.094333998982648 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark02(-26.93424201831307,66.03500979215825 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark02(-27.048980960659065,2588.9563755693525 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark02(-27.160193072342782,-0.008712934535371081 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark02(-27.21918478639094,0.0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark02(-2730.354490963448,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark02(-2.7369110631344083E-48,-17.278759594976695 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark02(-27.38685467189801,44.211831452037316 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark02(-27.39509772806546,-3.0874454581662967 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark02(2.7419144061683796E-4,-1.5707963267948966 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark02(-27.419294513511787,65.28985220715494 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark02(-27.454840345130208,-85.58586472116336 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark02(-27.49352422864905,-65.69702912620863 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark02(-27.493730941723427,0.0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark02(-27.7209454007957,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark02(-27.722975987302146,-1.5707963267948966 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark02(-27.758816355208936,-0.336566688946106 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark02(-27.779075429441747,-19.46691187447334 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark02(-27.785975534894988,-23.482744179435144 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark02(-27.844674491290448,65.08846299678831 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark02(-27.930991036971307,52.52239977916581 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark02(-28.020731144675743,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark02(-28.04152297399149,-2318.524961893734 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark02(-28.103037115235725,-16.402315444694793 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark02(-28.11485824105586,-0.7431813313301644 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark02(-28.126601154040955,-8.103981633974485 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark02(-28.143818008992582,1.5707963267948974 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark02(-28.148241425676034,-80.11061400506478 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark02(-28.189932251020313,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark02(-28.219304104585923,-9.040869167954202 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark02(-28.274304071421827,-98.96016884467683 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark02(-28.27433199114689,20.420352247990913 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark02(-28.274333882263033,-92.67700730344316 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark02(-28.274333882307864,64.4025260412767 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark02(-28.274333882308074,1.5707963267948883 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark02(-28.274333882308134,0.0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark02(-28.274333882308134,-1.5707963267948966 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark02(-28.274334120726976,36.12830108625305 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark02(28.33500267407581,69.5112574747339 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark02(-28.366583826136985,1.5707963267948966 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark02(-28.399194666015212,9.597260693782527 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark02(2.8421709430404007E-14,0.0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark02(-28.538196605305956,-164.47643521109356 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark02(-28.58682162255991,-50.53820814777259 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark02(-28.67854475276482,0.0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark02(-28.80746256056392,1.5707963267948983 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark02(-29.053517509881146,8.807915157193575 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark02(-2.9257886716849555,57.73709900852157 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark02(-29.54422330330489,21.229442492680036 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark02(-29.546854120929183,1.5707963267948966 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark02(-29.552686761367006,-46.32626802622615 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark02(-29.602749179508223,-1.5707963267948966 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark02(-29.690362528965537,0.0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark02(-29.8355090991801,-14.429225602808629 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark02(-29.845130209107985,0.0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark02(-29.936222638714852,-73.40505335312088 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark02(-30.042919380231254,-65.5166086306333 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark02(-3.009265538105056E-36,-1.5707963267948966 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark02(-30.147086353036464,16.27338662553015 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark02(30.261627524268988,67.85421430217713 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark02(30.37270981136956,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark02(-30.510060929451985,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark02(-3.068932870417001,6.123233995736766E-17 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark02(-30.770024090235207,-1.5707963267948966 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark02(-30.854080850452604,32.61054651614717 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark02(30.896667430626508,71.0729960600998 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark02(-31.0806576285401,8.881784197001252E-16 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark02(-31.235575142220327,-0.32368591216133913 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark02(-31.404976487776054,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark02(-3.1415921203426804,89.53539008886465 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark02(-3.1415926527710565,45.553093476367906 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark02(-3.1415926535839054,-1.5707963267948912 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark02(-3.1415926535897927,1.5707963267948963 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark02(3.1415926535916125,-1.5707963267949172 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark02(31.4159265359976,-1.5707963267948966 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark02(-31.415926537178137,0.0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark02(-3.141592909283453,-1.5707963267948966 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark02(3.141600282984373,1.5707963267949034 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark02(-31.416048790773804,-0.5658582758790188 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark02(3.141629266490659,-10.995568671492023 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark02(-31.4163109688135,1.5707915612551422 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark02(-31.43199268953087,-78.89108947631539 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark02(31.447176535897935,1.5707963267948968 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark02(31.447176535898944,1.5707963267948966 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark02(-31.44717653764883,86.39383629880355 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark02(31.452332593537847,98.87558467514411 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark02(31.47099175550377,-91.31551638314124 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark02(31.480301127551495,30.097430999023743 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark02(31.539250441146475,-4.837388992441973 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark02(31.622513184013798,-0.6945831807150529 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark02(-31.665242915521095,-1.5707963267948966 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark02(-31.709014548722234,-142.9716779696138 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark02(31.720577223784034,-57.42570435575571 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark02(3.1729401421917527,1.5707963267949054 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark02(31.779120986399448,-79.08672116729782 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark02(-31.94698448937166,0.22413291940205254 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark02(31.972973172029327,-95.26152929847511 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark02(31.973888420744377,76.79695667526022 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark02(31.99447243047183,-31.97197302149752 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark02(-32.08267036944859,52.65931799588016 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark02(-32.08816538413856,23.286843540642295 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark02(32.225946222509776,22.565006790044137 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark02(-32.236297429423516,0.0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark02(-32.23923258607499,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark02(-32.3436729588465,0.0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark02(3.241728842552479,-33.08685905073306 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark02(-32.43248129455108,0.0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark02(-3.2529707884421932,95.70719779973692 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark02(32.54435917604983,-0.5117651831977273 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark02(-32.59664601772691,0.4119611507956513 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark02(3.2665926535897936,10.945495953017373 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark02(3.2665926535897953,48.65910218952229 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark02(3.266592653589809,-10.922378790267217 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark02(3.2665926535900285,-80.01619419287528 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark02(-32.745017497971446,0.0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark02(32.82681553800418,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark02(32.882988084719415,-2526.6599455514447 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark02(-3.3173982433590434,72.66032510556435 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark02(-33.39575312671238,-52.672308209450414 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark02(-33.56255719437301,-0.12837225226568152 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark02(-33.74775547481741,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark02(3.3881317890172014E-21,1.5707963267948966 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark02(33.9251786948611,43.17488978555184 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark02(-34.10089345894427,-73.35739806608315 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark02(-34.10136793028127,97.35046421661306 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark02(-3.41700127906914,17.262162877317834 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark02(-34.2168898557579,-5.813392192271195 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark02(-3.423712813732294,-1.5707963267948966 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark02(-3.4271695883887077,1.0037534860162118 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark02(-34.37980904104438,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark02(-34.48154021334178,-3.2144400651766603 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark02(-34.55751716901299,1.570796215984978 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark02(-34.557518552546846,-0.5707328636839631 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark02(-34.55751918540317,-45.5530934769066 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark02(-34.670134671453525,23.03767004484773 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark02(-3.469446951953614E-18,0.0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark02(-3.469446951953614E-18,-1.5707963267948966 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark02(3.469446951953614E-18,-86.69254156142757 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark02(-34.70334069266121,1.5707963267949054 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark02(-34.73373640777095,61.62736919154425 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark02(-34.79667398318777,9.609009342957906 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark02(-34.85843581080432,-38.79423153934014 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark02(-3.4926935424133205,64.57167300066396 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark02(-34.99190238294693,-74.26181055270911 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark02(-35.009327874657885,-66.99600177431557 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark02(-35.096485729870494,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark02(-35.130881550016795,1.5707963267948966 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark02(-35.13938702351918,0.0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark02(-35.15561811973911,70.08773577563997 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark02(35.227236857434036,-47.694218947769016 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark02(-35.24915784968074,-86.39379958612425 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark02(-35.30441159503352,14.42928870109477 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark02(-35.349614360599666,-182.99107506403334 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark02(-35.379849916983325,-1.5707963267948966 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark02(-35.48013583230637,45.18066820969097 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark02(3.552713678800501E-15,38.878715369443455 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark02(3.552713678800501E-15,7.655743502969357 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark02(-35.54514808969502,-60.05966498983446 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark02(-35.7440130734024,-39.061426211015224 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark02(-35.7767321242143,7.269391312733049 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark02(-3.5817376776824545,100.0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark02(35.850671921294065,74.75609107200961 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark02(-35.86348548606904,-22.01704191292275 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark02(-35.93701727531493,-29.11037903590301 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark02(-36.00942240077236,0.0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark02(-36.020172944439665,2571.8844160290955 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark02(-36.0599683864742,15.70740350607305 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark02(-36.128315516280786,0.0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark02(-36.15516161248558,-24.62378319251492 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark02(-36.24591790649077,1.5707963267948963 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark02(-36.553724755175104,0.0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark02(-36.68053537592908,66.23827340303262 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark02(-3.669717268339491,-1.5707963267948948 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark02(-37.03541282414399,-97.08505077785958 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark02(-37.27630378528971,88.58326895890042 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark02(-37.3041646852877,0.0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark02(-37.69911184311054,0.0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark02(37.69911184315979,-1.5707963268126244 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark02(-37.69911196325838,39.26990812958455 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark02(-37.69911232010865,45.5530933879881 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark02(-37.714736843077524,1.5707963267948966 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark02(37.714737865009106,4.712388979449657 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark02(-37.81614020644475,40.15088614423672 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark02(-37.85652794202369,-83.43414373493269 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark02(-37.87281642758629,-2609.11228928564 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark02(-37.87362427300285,2.070796326794897 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark02(38.07107268983938,23.933905748577974 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark02(-38.116017984271465,0.0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark02(-38.150791263116844,64.82054791383472 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark02(38.20922259174665,30.355240957657582 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark02(3.8318846613444877,96.50886794237307 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark02(38.31963986335745,-56.93059114603469 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark02(38.374197427533545,67.15162465370376 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark02(-38.452185545039875,-73.35264503940115 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark02(-38.48099766105979,-1.5707963267948966 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark02(-38.49628754331271,87.48821648180555 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark02(-3.8518598887744717E-34,1.5707963267948963 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark02(-38.56032947302891,44.221649561373056 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark02(-38.60219467685504,-2629.937216191157 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark02(-38.606693602217234,90.5982554400818 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark02(38.61080405803605,-0.2895139057965094 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark02(38.61125030813625,82.0597358532564 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark02(-38.6112931897272,39.20236333139631 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark02(3.863911393616349E-4,92.67739468423804 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark02(38.700784032687984,0.0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark02(-38.81954315632336,0.0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark02(-38.99761032282642,6.2102756012394735 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark02(-39.07541544233189,24.463288478946538 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark02(-39.14483125353891,66.09852264091764 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark02(39.239511735069044,-2.4402038887402018 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark02(-39.2689787069836,-60.73442444428125 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark02(-39.27701762244463,0.0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark02(-39.29040615738331,80.84979612034982 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark02(-3.944304526105059E-31,0.5707876150550183 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark02(-39.47474112903442,-65.12502513292087 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark02(-39.8139008005753,-137.90127354329513 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark02(-3.9889666333627396,-34.119609336924825 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark02(-40.13435211497103,2628.271347133071 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark02(4.023608799403597,-40.15192431584355 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark02(-4.030258018229754,1.570796326794897 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark02(-40.311236357963416,0.42122973873718783 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark02(-4.03242610144261,-14.285012233559442 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark02(-40.68683729482272,-18.005343774318778 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark02(-40.69541165662714,0.0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark02(-40.73572179066094,49.680919212314336 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark02(-40.74778519267386,11.006011279145078 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark02(-4.082661492028384,1.5891302161991026 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark02(-40.83724435211574,-0.5703860031825104 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark02(-40.84066521699182,95.8185759340472 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark02(-40.840704488660954,-32.986722606223566 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark02(-40.84461696612914,67.54424205117796 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark02(-40.904079280282645,87.96453990816224 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark02(-41.01241740772281,-0.6613907545139099 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark02(-41.05950710183524,71.7118215759375 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark02(-41.06421738873191,0.0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark02(-41.10074358983462,1.5707963267948966 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark02(-41.238476028696525,8.018686785003561E-4 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark02(-41.285870412750384,1.5699065453812344 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark02(-41.35498166542308,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark02(-41.36525506181854,-43.0215253200481 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark02(-41.394558292300296,1.5707963267948972 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark02(4.141592653589794,4.436870496071944 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark02(4.141592653589794,-54.95845132562584 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark02(-41.417877792824044,2.9666391663337066 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark02(4.1426099181005815,98.61758598336574 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark02(4.145786345686902,65.40684632508305 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark02(-41.51422845067141,0.7431896115512857 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark02(-41.53292391685519,88.7383122666269 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark02(-4.1840237045803413E-10,64.57054502844235 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark02(-4.194675772532754,14.453697091476968 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark02(-41.94804569649613,0.0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark02(-41.94907515194568,-1.5707963267948972 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark02(-42.02016042100853,-95.36734125753397 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark02(-42.10633709381977,0.0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark02(-42.21385314695576,95.39696661268366 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark02(-42.25780043332376,-0.30486701171603414 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark02(-42.320275474169456,0.5650530873361742 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark02(-42.363715769614835,-145.00374037004786 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark02(-42.53650082346221,0.0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark02(-42.56015296060564,0.5698114138993075 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark02(-42.60092279487368,98.4739357959289 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark02(-42.61568159758896,0.20418077461991793 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark02(-4.264872854370758,-16.297498471649902 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark02(-42.65062630510028,-1.5707963267948966 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark02(-42.68561496826176,0.0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark02(-42.729908453476284,1.5707963267948966 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark02(-42.742118052819436,-73.37770101140566 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark02(-42.76734255125822,1.5707963267948966 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark02(-42.78540072071433,-16.15833510721388 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark02(-42.789678697102524,44.38194693780697 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark02(-42.7949408000576,0.05436618890650264 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark02(-42.79755051672818,-22.731018789530296 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark02(-42.80656838315692,84.49590730028692 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark02(-42.848220023035516,-1.5707963267948968 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark02(-42.86033473862213,0.0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark02(-42.871196929353175,85.14567668295396 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark02(-42.90599867273838,-46.880610095455985 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark02(-42.906558044791595,-1.5707963267948966 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark02(4.291135568073798,-90.65021362232598 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark02(-4.292284003438623,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark02(-42.96650348530153,20.672474246805535 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark02(-42.969969404851575,2493.6565465901836 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark02(-42.97355825826248,0.0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark02(-4.298129073091607,-62.64647056580086 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark02(-42.99387963162826,0.0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark02(-43.028896778117456,1.5707963267948966 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark02(-4.309871966893196,69.81109558238882 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark02(-4.3141757057536125,0.0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark02(-4.3529198480770325E-19,-0.5707963230971919 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark02(43.61351640165498,-48.59663443374937 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark02(-43.69268289452031,51.85984715714639 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark02(-43.85072345948807,0.30811690426707933 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark02(-43.9822971501571,-1.5707963267948966 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark02(43.98250905774712,-73.82742734579391 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark02(-43.98467058044353,-1.5707941778283243 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark02(-44.01294601251929,1.5707963267949054 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark02(44.044797961975654,-158.65055297771147 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark02(-44.16001916102561,-1.5707963267948966 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark02(-44.254984999065286,-28.319287722622335 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark02(-44.29061272709171,1.5707963267948966 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark02(-44.3616097752604,-1.5707963267948948 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark02(-4.440892098500626E-16,-3.3941645486432233 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark02(-44.42658416351568,-19.575431911619688 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark02(44.53751228850964,71.2148187115761 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark02(44.55114896462245,-45.42168026565243 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark02(44.55976938968507,-1.5707963267948966 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark02(-44.601511199031165,-1.5707963267948966 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark02(44.6197018189335,55.93942120935088 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark02(44.68155041027359,-80.18884008427472 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark02(44.68864665972475,73.86800593324742 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark02(44.78880795449194,1.5707963267948966 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark02(44.96288147103788,-84.18838663829537 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark02(44.98175587144976,0.1874377223582814 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark02(45.017519868151794,-9.448023237737829 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark02(-45.01908556835504,-1.5707963267948974 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark02(-45.100267421460316,-1.4712859161113598 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark02(-45.19238326812371,16.699759015929658 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark02(-45.34787472035569,2457.9507277647426 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark02(-45.36774913452247,0.0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark02(-45.40677964558703,16.39081242914412 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark02(45.46647583398794,-95.30691877594757 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark02(-45.49575666620068,0.2039312035348913 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark02(-45.53579065622868,-1.5707963267948966 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark02(-45.70853684496197,0.0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark02(-45.856235012754475,0.0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark02(-46.086355758289784,-15.1747009869079 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark02(-4.615041573621539,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark02(-46.36016465403636,0.0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark02(-46.747217804987265,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark02(-46.799072708319656,-17.38125750237478 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark02(-46.87702726750365,-25.205853503614755 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark02(-47.02788373924034,87.05778088712603 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark02(-47.082921874843066,11.252185083823186 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark02(-47.11066097396688,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark02(-4.712388980359082,-42.410641762101335 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark02(-47.1395148038469,-1.5707963267948966 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark02(-47.24834044258061,52.99312192597219 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark02(-47.46176668090851,-136.15400430571628 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark02(-47.543480730189515,0.0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark02(-47.63589419104426,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark02(-47.68429022385434,-39.1659849206722 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark02(-47.72074335562066,-1.5707963267948968 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark02(-47.795655719581106,29.845130209103036 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark02(-47.85404099873654,23.819936662674145 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark02(-47.95242908295896,0.0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark02(-48.198807474865134,0.5279491710441163 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark02(-4.826787450304007,-48.6946861306418 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark02(-48.28948909644926,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark02(-48.51508478515319,-0.22008195660327712 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark02(-48.69468613064625,0.0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark02(-48.69468620710222,-3.838969698381714E-6 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark02(-48.71993598048925,1.4889853312214183 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark02(-48.74921664491167,0.0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark02(-48.79364777566916,83.5525744633895 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark02(-48.794499646088994,-36.70476294451883 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark02(-48.80650335062056,-2.8928575907886365 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark02(-48.89113102246824,43.78585225791834 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark02(-48.93667176446659,2646.3326374247176 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark02(4.899946572757799E-10,14.13716694813617 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark02(-4.901394707718083,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark02(-49.0395051255234,70.26443228467103 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark02(-49.078928598563394,-0.3185717009618455 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark02(-49.23280212148879,4.1536114586794845E-10 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark02(-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark02(4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark02(-49.70063967381979,-125.91486531264032 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark02(-49.72363085409143,-135.62435422736866 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark02(-49.73979164283793,-72.6149376502096 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark02(-49.7447829403438,51.13590622465498 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark02(-49.76121762551998,-45.466595786236645 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark02(-4.978663478452909,4.712388980384688 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark02(-4.980033253053103,-1.5707963267948966 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark02(-49.80286906144126,0.43593002860536734 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark02(-49.814281849111396,1.5707963267973202 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark02(-49.814816927413716,2592.583263952636 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark02(-49.82513554002661,-5.777894296879932 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark02(-49.830185112177325,0.0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark02(-49.869293500619165,-0.03397509558132688 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark02(-49.90314694290356,26.645317918115847 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark02(-49.97740919604508,94.15461527565847 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark02(-50.02076510177956,0.0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark02(-50.029396512778945,6.288105056824328 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark02(-50.05787159585544,10.57961500237694 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark02(-50.08075092533245,0.0022967141760043036 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark02(-50.08452873077242,32.805769136130216 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark02(-50.098980852363724,0.0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark02(-5.015593890960767,-95.54663932090969 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark02(-50.196846929151114,-2282.4131623320245 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark02(-50.19700069814493,0.4663788004228877 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark02(5.023453612943172E-15,6.283185307179586 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark02(-50.23753191109226,-58.7156366617408 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark02(-50.265393391124675,92.67697645782984 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark02(-50.26545960396347,-102.10176124197595 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark02(-50.265482422699314,-4.7123715038784475 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark02(-50.265482457336695,1.5707963267948966 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark02(-50.265482457386064,-80.11061266649139 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark02(-50.26548245743704,1.57079632679459 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark02(-50.26548598762501,14.137165637212185 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark02(-50.2656045277492,0.0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark02(-50.279690324301754,95.19914560657162 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark02(50.32783127943202,-23.797527196440853 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark02(-50.421638809548625,-0.38717244543618323 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark02(50.48644534926786,-27.09671805806734 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark02(50.54017454957561,55.176010396720244 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark02(50.564230312919534,-1.5707963267948968 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark02(-50.56935333018812,43.267827745095246 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark02(50.58220899249713,2693.7947301746535 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark02(50.60296706129046,1.5707963267948957 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark02(-50.69605055099599,27.13556450657471 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark02(50.724149936992035,1.5707963267948983 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark02(50.74503245959312,42.521540511167785 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark02(-50.77275171856044,-38.94957046247448 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark02(-50.86705398416719,1.5707963267948957 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark02(-50.901093067588214,-6.870265315259076 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark02(-51.03472442151166,1.5707963267949054 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark02(-51.08378440726631,14.55596021948748 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark02(-51.09912013196325,-9.638354947760265 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark02(-51.12663440927834,1.5707963267948968 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark02(51.15152869614772,-16.912256980870552 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark02(-51.16730859048319,-46.45491961025974 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark02(51.19308584769695,-91.996426473296 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark02(51.21850994385292,-66.04331840477414 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark02(51.24852239369748,-78.85061060575609 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark02(-51.281532086048145,-73.32290845157667 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark02(-51.28599251471237,42.27779677699442 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark02(-51.37190620844405,0.0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark02(-51.381487271678985,0.0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark02(51.3826127454177,-1.870410402547634 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark02(5.141592653589794,1.5707963267948966 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark02(-51.50888228588768,-7.600067777527926 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark02(-51.51708880247967,54.62972265616335 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark02(51.55160300439272,-1.5707963267948983 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark02(51.61879028352445,-1.5707963267948968 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark02(51.805527774534426,-97.54638739870308 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark02(-5.182112904137037,-54.977871437821385 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark02(-51.891657468221,-95.05720073405438 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark02(-5.212389030079205,111.13490795009534 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark02(-52.198868625995566,-1.5707963267948966 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark02(-52.236760865936276,-10.79315373248064 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark02(-5.241674181081308,0.0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark02(52.49524762815,-57.7839318544944 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark02(-52.598695059932524,2.3791763780336446 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark02(53.06900858471829,-46.64012264431769 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark02(-53.09451011480627,-1.5707963267948966 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark02(-53.187096880720915,23.294401370410235 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark02(-53.348310091508104,-1.6332963267949423 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark02(-53.405648500769686,0.5691738925964939 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark02(-53.40707511102647,-1.5707963267948966 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark02(-53.40707511102647,1.5707963267948966 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark02(-53.407075111126204,1.5707963267948966 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark02(-53.407075141164114,-36.12831546216388 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark02(-53.40707842751384,89.53563552240729 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark02(-53.50430057492005,76.68076831759161 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark02(-53.69329041156068,-18.53877028844935 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark02(-53.71842762317445,129.31730596380777 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark02(-53.75266308505964,0.41877399832948814 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark02(-53.770974797946195,76.30221619328103 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark02(-53.890404432526125,6.880758287732164 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark02(-54.02717191620714,-1.458342696828834 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark02(-54.094607730010935,62.47348019796104 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark02(-54.18120331685594,2665.2893300784353 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark02(-54.19780344048861,-37.347242844803596 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark02(-54.32492664941578,-1.5707963267948966 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark02(-54.37012039054544,36.150355411451926 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark02(-54.37824669965924,56.471664727070475 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark02(-54.449877370019934,-23.6493248599538 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark02(-54.47422241809961,-44.27564378928232 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark02(-54.52272209919055,0.0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark02(-54.55655598410207,9.583735519049913 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark02(-54.6089754519971,-64.77435484194298 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark02(5.470470198445597E-4,-10.99612133448412 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark02(-54.76175835541145,38.63944552668372 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark02(-54.80716802835885,87.47560302691261 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark02(-54.83494440752257,-100.74308650912651 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark02(-54.870965109031424,-11.007716077898792 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark02(-5.489227285709617,-73.5479556536408 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark02(-55.00156170512825,6.123234229672702E-17 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark02(-55.00565170846911,36.03980023498689 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark02(-55.02612985195645,44.263444998147904 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark02(-55.06098598749314,-26.437122372480566 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark02(-55.07887986525532,-1.5707963267948966 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark02(-55.089071734658745,16.067028401870616 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark02(-55.089827001000806,92.13838987015393 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark02(-55.093535668143595,8.242780276138113E-16 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark02(-55.119426469173895,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark02(-55.122868691635745,1.5707963267948968 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark02(-55.140895373571674,-1.5707963267948966 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark02(-55.14924082279647,-69.28640776453692 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark02(-55.17506712942182,-2086.476977279295 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark02(-55.21316256315003,97.80756270480975 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark02(-55.22099364782736,-0.0412454475111307 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark02(-55.28127350570126,-25.846365319555915 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark02(-55.28911025187445,82.74167208676937 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark02(-55.30732533638051,16.444525649162504 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark02(-55.308632789076896,-20.89407229637758 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark02(-55.32242403385749,-0.6011667029066784 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark02(-55.36913376224304,0.05815686954871194 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark02(-55.37780043160449,0.0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark02(-55.429143796227656,-87.62705135478816 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark02(-55.44432999366461,20.47340947081244 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark02(-55.45180101055072,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark02(-55.46916992794415,45.369370333691364 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark02(-55.500221963426014,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark02(-55.546781119181,14.06611379375451 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark02(-55.74334996171295,31.833922341031176 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark02(-56.03678107623826,-32.78352353729999 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark02(-56.102795909140156,0.0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark02(-56.117252443145944,-69.70923072123058 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark02(-56.22191294683792,-90.95926709757875 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark02(-56.22234835110205,1.5707963267948972 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark02(-56.24578559932269,1.5707963267949054 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark02(-56.25226431833231,-21.17557761700472 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark02(-56.262948302987155,-1.5707963267949054 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark02(-56.274768574109856,37.85302391802051 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark02(-56.294230744314746,33.87220569124714 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark02(-56.31137710605421,-1.5707963267948966 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark02(-56.33426121027929,1.5707963267948966 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark02(-56.346948252506394,0.0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark02(-56.3563154336019,-0.4449577817357613 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark02(-56.36531263788812,-95.36071080049473 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark02(-5.642401485669335,-19.35051283346123 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark02(-56.470582165343586,-32.90863726352044 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark02(-56.471432289812334,-19.416140065864354 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark02(-56.505410500748,0.0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark02(-5.650921930682918,0.0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark02(-56.518957906473204,-4.340988798272743 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark02(-56.52024906411765,1.5707963267948966 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark02(-56.541157314451084,179.44678006843512 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark02(-56.54431904269972,8.67821655054017 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark02(-56.54829193804651,-1.5707963267948912 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark02(-56.548609097348695,73.82742732752494 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark02(-56.54866776086629,-4.743652476193771 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark02(-56.54866776451628,-1.5707963267948966 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark02(-56.54866776451629,-1.5707963267949068 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark02(-56.54866776451629,-4.71238898038468 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark02(-56.54866776453209,-1.5707963267948966 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark02(-56.54866776456415,1.5707963267948966 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark02(-56.54866776461626,73.82742735926016 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark02(-56.548667857470456,0.5394114266098781 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark02(-56.548670104550304,1.5707963267948966 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark02(56.548683023405346,-1.5707963267948977 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark02(-56.60791708418809,17.206190133453603 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark02(-56.66908215227511,-5.418863396581841 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark02(-56.66951245298911,-51.96619557948687 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark02(56.70362227954399,38.92083119404528 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark02(-56.70822746904383,16.67000895669296 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark02(-56.77873454382567,75.18310623791928 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark02(-56.951768627664315,-1.5707963267948966 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark02(56.9534790720759,-1.5707963267948966 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark02(-5.706263653147232,0.0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark02(57.070099108582845,-32.46529151884159 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark02(57.0999692334409,-4.613822111505158 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark02(-57.31433670673651,-85.09160416468016 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark02(57.414921742554014,-76.69458771744058 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark02(-5.75769484298904,98.96016859072925 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark02(-57.62564820635489,72.93841969732983 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark02(-57.73312986106998,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark02(-57.833540697238675,67.20142435971083 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark02(57.84209215746715,-1.5707963267948966 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark02(57.97285813954426,-60.84932559620135 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark02(-58.00553166732019,45.40333157109177 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark02(-58.02233478798347,-0.06278073783009186 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark02(-58.09127763690608,45.862062704100794 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark02(-58.180629462878386,88.77369029756744 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark02(-58.182291386894725,93.35953833209447 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark02(-58.38802451731557,0.8325213302704977 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark02(-58.39759812227925,-38.21088373209871 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark02(-58.42717174708276,13.339741357511059 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark02(-58.50533892981957,66.47789313105329 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark02(-58.51040134529704,1.5707963267948966 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark02(-58.713987233002875,-1.5707963267948968 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark02(-58.84486773693449,79.35702726147997 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark02(-59.18605142298833,-39.77411716520437 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark02(-5.923000975894798,-45.3085477236407 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark02(-59.480527480217475,0.0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark02(-59.525030067352716,16.92702477332948 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark02(-59.60115371568761,39.68161802316919 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark02(-59.604475841279076,0.47207378197287025 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark02(-59.69026041820606,-1.570796326794896 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark02(-59.69026041820606,-1.5707963267948963 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark02(-59.71645962976221,1.5707963267948966 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark02(-59.72283876712217,-54.55952466666495 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark02(-59.86212782011077,44.295356589409344 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark02(-59.90957226457152,0.0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark02(-60.172208268518766,-73.89901865806024 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark02(-60.34572805959557,2599.393373516121 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark02(-60.39763891246549,-2.696209298459599E-5 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark02(-60.60897715200715,-10.698433786042115 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark02(-60.61656444643444,-17.477883718044268 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark02(-60.632730985582214,23.514656209767182 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark02(-60.73009183032507,100.0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark02(-60.84054616658141,15.026549842325338 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark02(-60.88142353519217,-77.26053861306832 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark02(-60.91037612447592,0.018544748366769843 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark02(-61.01256680320732,-2629.7758687115443 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark02(-61.01806976930798,0.0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark02(-61.08791804324907,1.5707963267950404 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark02(-61.09972467437566,0.4481417614564258 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark02(-61.13515503457489,-0.12590171122237948 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark02(-61.15977027913808,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark02(-61.16275434082627,-9.498321771732202 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark02(-61.16656080651366,-1.5707963267948966 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark02(-61.2547211570718,0.14666370786915606 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark02(-61.261056622029656,3.879339672522267E-6 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark02(-61.334971163273664,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark02(-61.3881762189809,1.570796326794897 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark02(-61.48040701508516,-0.40975758503524606 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark02(-61.51194008145795,-70.86886844009801 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark02(-61.593215997657204,-68.20798806988873 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark02(-6.162975822039155E-33,1.5707963267948966 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark02(-61.853218496500816,24.444347736024355 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark02(-62.12901414807077,-97.2189644462445 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark02(-62.17984451904902,-137.8120841486636 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark02(-6.222698952901283,-36.55005977285748 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark02(-62.27249227583411,-1.072673759043127 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark02(-62.38973924857332,71.42306822988294 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark02(-62.70606262119508,31.793605305557797 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark02(-62.753063941057974,-47.966389559256875 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark02(-62.81847165194987,90.19825203466604 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark02(-6.283185307079641,1.5707963267948974 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark02(-6.283185307083156,-1.5707963267948966 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark02(-62.831853071500475,-73.82742732458166 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark02(-6.283185307179585,10.995574287464603 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark02(-62.83209721242087,0.0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark02(-62.832097326064805,1.5707963267948966 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark02(-6.283246400406278,-1.5707963266585117 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark02(-62.83660196733017,0.0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark02(-62.83990043832683,-80.78192730855773 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark02(-62.842589605310465,-1.5707963267948966 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark02(-62.85103218673963,-7.651087162025182 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark02(6.287259648707672,39.26986083039972 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark02(-6.287602691437077,-1.5707963268022218 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark02(62.89435307179641,48.69406481408653 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark02(-62.89435941596818,-0.5657538340127776 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark02(-6.297516106781856,-2.7473860878413863 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark02(6.302813497095935,97.40900030131087 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark02(-63.04144882862171,1.5707963267948966 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark02(-6.305219390225031,-95.84061001763416 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark02(63.0549375127153,-74.05051180017703 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark02(6.305692076622259,158.65010863931425 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark02(6.314435307179977,23.577343860440244 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark02(-63.17650810299736,-14.727418889355768 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark02(6.3294548594324564E-27,23.56194490182345 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark02(-6.331549491176077,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark02(-63.3378326141381,34.239961821807725 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark02(-6.345105097616589,23.238063953819733 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark02(63.50557221091563,1.5707963267948966 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark02(63.580140970406546,7.138214694865412 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark02(63.59445242305617,-77.82652917475951 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark02(-63.625504317155276,-72.9015832860756 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark02(6.367163791054,14.05318845738009 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark02(-6.372667670065565,77.05850237593631 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark02(-6.373059939610606,-10.966887969935872 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark02(63.778715619014335,-0.1133661452340052 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark02(-63.82214255968203,-8.133379890458455 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark02(-6.3859537911481254,99.80792422308596 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark02(-63.987797810262336,1.5707963267948966 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark02(64.12894975022928,0.0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark02(-6.415960630797586,-0.2612214735853076 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark02(64.18166133553063,-0.8160538885798587 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark02(64.23961007407559,-0.22863535184284375 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark02(64.25330865585947,0.14934074340335465 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark02(64.25370186351702,1.5707963267960314 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark02(64.28107686900344,-3.521220756467926 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark02(64.31768187149265,-40.71893233778845 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark02(-64.32203379900412,-31.822511309516628 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark02(64.39138176662192,44.34662737173193 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark02(64.40264939859064,0.0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark02(-64.49132683016735,-45.32834637563313 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark02(-64.67100286122245,45.60264941243936 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark02(64.78962099115307,-71.12216892538059 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark02(-64.89195316233003,-55.05299049481736 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark02(-64.92461423690366,-24.496681075342195 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark02(-65.01663456570151,-1.5707963267948968 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark02(6.5169932846748395,-38.56027114986361 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark02(6.526247985602346,-1.5707963267948972 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark02(6.533185307179587,-20.17182708272974 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark02(-6.533185307179588,-67.36011388945685 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark02(6.533185307179588,-74.07674583402095 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark02(6.533185307804019,76.96865997408058 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark02(6.533228386166257,11.09332281624264 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark02(-65.37725535394652,1.5707963267948966 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark02(-65.44571703198955,-2603.980482527025 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark02(-6.548461725338429E-19,45.55309347705184 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark02(-65.68791601928065,2.070796326794897 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark02(-65.78317112688008,-1.5707963267948966 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark02(-65.85820895227252,-1.5707963267948966 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark02(-65.87688769734629,-1.5707963267948966 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark02(-65.91911504983105,-0.23821694991718295 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark02(6.596561899590526,-0.021013385036263328 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark02(-65.97344572538564,-1.5707963267948966 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark02(-65.97344597632191,-4.712388980190107 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark02(-65.97848840746299,-0.010329806116671386 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark02(6.598049659837906,-17.593623947302003 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark02(-6.600859308885163,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark02(-66.0341285258522,-2586.427634609663 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark02(-66.60144254542692,0.0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark02(-66.6015419494752,35.55431749733867 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark02(-66.61329864657218,1.5707963267948966 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark02(-66.6826014257496,9.810611731454657 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark02(-66.7439314203546,-8.673544684124844 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark02(-66.81708387760101,100.0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark02(-6.681911775230489E-52,-17.279247875994404 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark02(-6.6939105495781845,1.5707963267948966 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark02(-66.96925700210133,-1.5707963267948966 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark02(-66.99495941115609,-100.74416785208547 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark02(-67.04852951532521,-76.7933602402806 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark02(-67.20560257901145,45.00642618628004 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark02(-67.2436171285082,0.0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark02(-67.27261518326505,106.7298807537893 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark02(6.731670464894378,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark02(-67.38685902394819,-12.723753643229525 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark02(6.741683324531772,5.170886997625358 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark02(-67.57035318195216,-87.76499204146788 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark02(6.757041788166958,-70.79947917390031 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark02(-67.61879776282807,-84.00697525813277 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark02(-6.764714561038212,2.070797684198409 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark02(-67.69665525767219,0.0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark02(-67.69770668529925,62.589526224234845 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark02(-6.777850985944313,-73.3327616804818 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark02(-67.88607758980743,1.5707963267948966 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark02(-68.24627312852508,-90.33137484668521 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark02(-68.45109050001275,-30.50907808793876 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark02(-6.85440414712275,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark02(-68.68505811401995,-135.13244290662794 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark02(-68.70555243567296,37.38081028143566 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark02(-68.7649874864675,-1.5707963267948966 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark02(-68.76832523979253,-1.5707963267948983 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark02(-69.11503523115685,4.7123889803684404 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark02(-69.11503835352131,29.845130138723178 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark02(69.1150383795323,1.570796326794898 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark02(-69.11503837990689,1.5707963267948966 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark02(-69.1150388560263,-1.5707963267948966 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark02(-69.11516044928801,-39.269908169811124 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark02(-69.11699150757845,-32.98672286269147 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark02(69.22323907157637,0.0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark02(6.9238526871191315,53.773987042252514 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark02(69.2714488999834,-86.76576189944016 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark02(69.3127033090923,108.18799518375619 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark02(69.34125162042304,-15.637977033084056 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark02(-6.938893903907228E-18,1.5707963267948966 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark02(-69.41684968928078,-0.9661273210265122 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark02(-69.4562241723165,-4.371203186937528 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark02(-69.50683092917735,0.012227988307998377 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark02(-69.50759997347966,0.0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark02(69.51030296572529,-1.175531740153415 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark02(69.56969892509633,-64.19712112375879 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark02(-69.57003774731731,1.5707963267948966 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark02(-69.57090121451155,1.5707963267948966 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark02(-69.61218894550512,-20.9175028149771 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark02(6.961596228403948,1.570796326794877 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark02(69.70636166360902,-23.23729919334535 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark02(-69.73889944407563,-31.70767036387599 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark02(-69.77902948472959,-0.012711766636685546 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark02(69.80366626987527,52.63411795288249 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark02(6.988309496977292,-19.410783613469416 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark02(-7.000105505756712,-14.432772982818648 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark02(70.06075377770878,-110.47054594760758 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark02(-7.008132646633302,-14.862114274097715 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark02(-70.09554768856515,-82.0145843694472 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark02(-70.16031514914044,-0.3533913973652563 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark02(-70.1615905637423,-0.272986159631446 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark02(70.20238192470708,64.84105374337855 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark02(70.20421445060161,1.5707963267948966 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark02(70.22642822001495,-0.14822017854123892 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark02(-70.29989097686965,0.0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark02(70.31895037750962,-2621.293239173148 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark02(7.0346830192807896E-15,-89.5353906274091 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark02(70.36308534314355,-24.949145617202333 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark02(-70.39777982169099,10.548249668307633 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark02(-70.50474936242762,-50.10449237932174 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark02(-70.54787046620334,-1.5707963267948963 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark02(-70.5591558355166,1.5707963267948974 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark02(70.5725584338243,-17.80918596853205 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark02(-7.060303221569841,-12.111403272709012 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark02(-7.06153514184601,85.61544813891246 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark02(70.63808807255842,-69.33132799722205 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark02(-70.93971622737634,1.5707963267948968 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark02(7.105427357601002E-15,0.0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark02(7.105427357601002E-15,0.9006131789833773 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark02(7.105427357601002E-15,-1.48778733997991 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark02(7.105427357601002E-15,-1.5707883031340022 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark02(7.105427357601002E-15,1.5707963267948957 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark02(7.105427357601002E-15,-1.5707963267948963 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark02(7.105427357601002E-15,1.5707963267948966 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark02(-7.105427357601002E-15,9.92171439691441 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark02(-7.125220935199096,-0.25848851689960706 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark02(-7.161357855593101,-100.04178667260805 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark02(-71.75828986870413,33.11895991015288 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark02(-71.95863239560254,-87.79187771922719 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark02(-72.25663103266523,1.5707963267949154 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark02(-72.25663103266524,-1.5707963267949012 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark02(-72.26095734322222,-4.624821729685678 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark02(-72.26613521846751,-48.95497246677628 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark02(72.26995609782918,-40.36123833921579 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark02(-72.27338790546582,-59.20578629459556 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark02(-72.31745497914676,-1.5099723803135665 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark02(-72.32507039673278,1.5023569627275921 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark02(-72.39389003605304,0.0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark02(-72.55252996295194,-1.2005824690634905 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark02(-72.55941887307313,-1.5707963267947385 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark02(-72.59744438733193,0.0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark02(-72.65174140887967,44.84459016738941 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark02(-72.67353687520004,12.975091622249828 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark02(-72.78166053289799,-50.144531671947675 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark02(-72.87014046089365,91.44784490318204 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark02(7.292602952981284,-91.4673974025612 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark02(-7.29691403859789,-30.94447645470174 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark02(-73.08152309296598,-3.375828588569073E-6 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark02(73.1480308268614,-56.72090795525728 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark02(7.323016719298585,-100.0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark02(7.329018540523552,0.0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark02(-73.4396715124803,227.56297492802537 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark02(-73.4940790504483,1.5521899473263348 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark02(-73.68552435046331,-16.897735493787053 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark02(-73.82742735935688,0.0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark02(7.394677459603239,0.0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark02(7.3993476009725185,-0.5546967846039195 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark02(-74.01167176274377,68.10020111779383 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark02(-74.48566738619263,-40.69855160589755 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark02(7.461184554433452,-136.57526068035992 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark02(-74.72325525021239,-1.5707963267948963 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark02(-74.90614596331125,-57.50537562808284 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark02(74.95895894774779,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark02(-7.496218884942019,70.00081976328278 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark02(-75.02310286662055,-1.5707963267948957 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark02(-75.13848785029855,-55.18328484626336 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark02(-7.523591089353474,62.191630205464946 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark02(-7.536140907185285,-15.824973123750617 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark02(-75.39822387028765,1.5707963267515466 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark02(-7.542456795601609,2361.748461936171 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark02(-75.51532478474402,-97.54785060411366 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark02(75.52551353712755,-1.5707963267948912 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark02(-75.60743589784802,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark02(-75.69919766751377,94.60675602861397 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark02(75.71634925779534,9.693161460225767 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark02(-75.77230221683124,-1.5707963267948966 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark02(75.8186446199926,-1.5707963267948966 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark02(-75.82676269436891,-16.475069875694984 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark02(-75.85739479077627,8.735159759636147 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark02(-75.87121204817397,-2332.8591687865232 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark02(7.59283143265732,-13.488607719636917 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark02(75.9810666089657,90.83959092794413 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark02(76.0333530258151,-1.5707963267948966 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark02(-76.11056818425831,1.6200556123289873E-15 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark02(-76.16734495300406,-87.19491774353719 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark02(-76.24355737146362,-55.98942253941821 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark02(-76.26698072941359,-76.34683500816782 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark02(-76.2747523309128,62.915430212978634 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark02(76.32642705534766,1.5707963268139524 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark02(76.33089404300412,-2482.34304473235 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark02(7.635773526755152,69.99564198970819 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark02(-76.38965948381478,1.5707963267948968 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark02(-76.39792279156369,-9.995875181970632 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark02(-76.46271931547855,46.460438933450384 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark02(76.47259030670989,0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark02(-7.67008382975294,-95.76448276596072 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark02(76.73438970844936,0.0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark02(-76.73764701288809,-0.010052817889580137 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark02(-76.76659117547437,-22.86956040770988 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark02(76.7688425752763,0.0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark02(-76.76951427175234,1.5707963267948968 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark02(76.80713619466566,0.0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark02(7.68131959198026,31.588588578474184 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark02(-76.82183149379854,-1.5707963267948983 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark02(76.82736299102022,-7.2603072985919255 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark02(-76.85894484750017,76.17893769507796 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark02(76.86472294521536,-71.22249565603022 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark02(-76.98002959723158,-5.052645849928544 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark02(-77.00347160816827,-1.4885815499817099 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark02(-77.17300248442046,-28.524664777142576 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark02(77.18469573196367,-5.886512001107036 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark02(-77.21048769015206,-39.517276777616814 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark02(-77.30211841957272,2340.220709475653 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark02(7.731243230402343,-31.53866494028679 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark02(-77.36228023482239,100.0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark02(-77.42983095787757,15.853543706661839 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark02(-77.4301644164364,0.0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark02(-77.48285094935433,1.1900063013765632 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark02(-7.751011888243386,1.3660492391911094E-9 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark02(-77.51286594874016,1.5707963267948968 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark02(-77.51301753755781,-4.2753797837851195 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark02(-77.6728461582196,2.5707963347465173 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark02(77.82578914393665,-71.2394711128799 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark02(-7.7849493832641254,-1.5707963267948966 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark02(-78.11042522806994,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark02(78.15144958684198,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark02(-78.32472091923492,-47.06342848905896 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark02(-78.35152079357385,63.40726075819464 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark02(-78.38456946913897,89.69063749801619 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark02(-78.4441648282768,0.0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark02(-78.45192944827615,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark02(-78.45330271875201,-71.9214395936577 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark02(-78.50471675255001,-45.287323191652746 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark02(-78.52978747324974,-1.5707963267948966 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark02(-78.5359068942304,-44.434625483281515 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark02(-78.53981633974482,1.5707963267948966 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark02(7.853981633974483,-40.63406699163173 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark02(7.853981633974483,-54.528927113322 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark02(7.853981633974483,8.040773867900258E-28 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark02(7.853981633974483,83.70232239580943 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark02(7.853981633976547,-11.389016294997047 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark02(-78.54190522455632,67.54419045112968 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark02(-78.55544133974483,92.67698195697695 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark02(-78.87172411986016,7.432741893667823 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark02(-78.89079432500357,0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark02(-78.9968610094769,-0.42233714972234104 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark02(-79.0031156524033,-83.19690300323947 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark02(79.07234521323124,0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark02(79.15844465742344,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark02(-79.26406297294587,1.5707963267948974 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark02(-79.34660093177195,0.0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark02(-79.34669880407989,18.548176501022965 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark02(79.45672362879847,31.814431832125166 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark02(-79.46571899988679,1.5707963267948963 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark02(-79.56669105525893,64.24928362793437 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark02(-79.64568176093651,86.29057128632303 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark02(-79.69176938704183,0.0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark02(-79.87800940334186,-90.36819294673244 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark02(-79.96711564119022,0.0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark02(-80.02421497660661,55.13914411731852 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark02(-80.11061266848783,1.2584898541693174E-10 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark02(-80.33832075103874,76.24148543663699 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark02(-80.56454886687293,-65.13376570436138 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark02(-8.058275131843757,64.09233225290603 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark02(-8.074654458840902,123.6848465868791 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark02(-80.74771230525658,-80.84210620757888 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark02(-80.7782114095427,67.42377808696574 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark02(-8.089808243823981,1.5707963267948972 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark02(-8.098705587406755,-8.112445007812184 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark02(8.100730543199058,-6.036505701499633 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark02(-81.17664133205994,1.5707963267948966 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark02(-8.122927493824168,-1.5707963267948968 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark02(-8.133342469682077,-38.221388794590894 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark02(-81.50501567286916,32.810329542328944 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark02(-81.6814089932383,1.5707963267985794 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark02(-81.68140994700894,-1.5707963267948966 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark02(81.68140994700894,-1.5707963267948966 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark02(81.68143951091275,-1.5707963267948966 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark02(-81.68798980329912,15.25617972988043 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark02(-81.68922149333463,-1.5707963267948963 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark02(-81.8128067610272,1.5707963267948968 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark02(-8.181700016755627,1.5707963267948966 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark02(81.82834776515045,-32.269085412968195 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark02(-81.8803462284488,-41.99836081508246 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark02(-81.89841461875695,31.584760582512985 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark02(-81.95878010573361,-2629.4514548813722 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark02(81.95892927955157,1.5707963267948968 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark02(-8.196157683185826,-53.06489906211317 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark02(-82.09114202219756,-75.38201192151266 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark02(-82.09309920154723,-86.60277596250828 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark02(-82.11259314324622,66.78940132378567 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark02(-82.13975386374327,28.457115555368105 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark02(82.17011478657815,10.925404829709843 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark02(-82.23977775648004,3.374904446164 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark02(-8.22544250814197,-30.51194143417016 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark02(-82.25868218106459,72.25852154635922 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark02(82.30812834893524,-1.5707963267948948 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark02(8.236482152010164E-19,-1.5707963267949077 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark02(-82.39817941251904,57.54173265134537 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark02(82.48997812020428,22.992479096709985 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark02(-82.52257540172407,8.695148042513944 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark02(-82.5965992875629,0.0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark02(-82.61095808237442,84.1730842194138 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark02(-82.6539663587995,146.83858622233063 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark02(82.71466324023947,1.5707963267948957 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark02(82.72318805057719,0.35549861370996566 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark02(82.82538967169651,-27.820585999107315 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark02(-8.283133161288571,-12.933728468314357 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark02(-8.297182225923692,71.90594849984248 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark02(-83.0197463262652,-28.985848585230848 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark02(-83.07251455126448,0.0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark02(83.10110593356733,-18.698456534312264 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark02(-8.312217896266816,0.42635301909184253 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark02(83.12220821756384,-38.928468441290946 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark02(83.14102267780387,0.09288261248360641 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark02(83.17795772327666,0.0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark02(-83.18491057926732,1.5707963267948966 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark02(-83.19448327079692,0.0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark02(-83.20564110456321,67.67761460745791 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark02(83.24369833357852,60.72602191107234 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark02(-83.31286772768175,71.32546911080561 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark02(83.40717027121354,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark02(-83.41308809057635,-4.224246605486101 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark02(-83.46840342346057,0.0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark02(-83.50145375939178,-45.47026923120005 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark02(-8.355733206303313,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark02(-83.68535376694987,1.1530487964890441 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark02(-83.8222148479769,1.1297566897254594 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark02(-83.82623467026642,-34.29393590680536 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark02(-8.388268118800514,-35.09180567411738 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark02(-83.99103601709642,0.0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark02(-8.403947255196721,66.52341134641657 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark02(-84.1961169260471,3.116001416041624 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark02(-84.3395491754091,13.965198674085471 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark02(-84.46493527423824,0.0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark02(-84.47322782093225,45.363575911533836 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark02(-84.59952153527493,0.0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark02(-84.64039883796684,122.64080981773303 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark02(-84.64963340803935,1.5707963267948966 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark02(-84.65010766775055,-41.17906563172799 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark02(-8.468046516729032,-50.60024569832795 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark02(-84.735628077037,0.008156943676585282 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark02(-84.74804087627304,134.01291354086703 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark02(-84.8206922293374,0.48116881607666484 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark02(-84.82300019460186,32.986708489698316 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark02(-84.82300160711883,45.55309347700367 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark02(-84.82300164692244,-51.83627878423157 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark02(-84.8230016469244,-32.98672212994552 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark02(-84.82300164698866,-1.5707963267948968 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark02(-84.85425164692442,-1.5707963267948966 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark02(-85.04898052291102,-0.04202215729434695 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark02(-85.11184187933452,-45.26425324474622 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark02(-85.20891921611795,29.2316663228155 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark02(-85.21835973009934,136.51524085077057 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark02(85.25271472853257,-54.23652289711851 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark02(-85.25935171161814,-136.6592807239285 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark02(85.50942105187812,61.457873380905085 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark02(-85.70354030825077,-29.845130209103036 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark02(-85.77162562329796,0.0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark02(-85.78026817540626,-30.15412667316009 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark02(-85.90594607086753,57.82117511193927 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark02(-8.673617379884035E-19,80.11085680716474 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark02(-86.87283213408823,9.189676653144048 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark02(-87.26531339380924,-23.97256841345812 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark02(-87.34167648673831,-73.26647061731819 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark02(-87.40420264653903,-83.50541542247163 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark02(-87.50571297279708,-60.69295253757379 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark02(87.9645943006132,1.5707963267948966 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark02(-87.96459433031967,64.40259701453621 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark02(87.98413135070817,0.0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark02(-88.0245894762906,98.02439673517699 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark02(88.078375300217,-67.54424205218055 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark02(-88.09719119306779,150.5533687907413 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark02(88.15283751120985,-1.2703262078666278 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark02(-88.25337207108012,-99.7735659633572 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark02(-88.40233618744092,0.0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark02(88.41992392867851,-31.21595039418561 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark02(88.4464205282346,-94.56646944130878 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark02(-8.847234643323091,53.87914577965594 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark02(-88.49860508798892,-48.69697575893193 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark02(88.52779523402687,19.649481524296576 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark02(-88.56787993585111,16.67642990413901 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark02(-88.59718225970073,-83.47336572316573 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark02(-88.61017111191514,66.11206527676181 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark02(-88.65485458863805,0.0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark02(-88.68526383595217,2.7031133669041623 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark02(88.71750532971353,-31.657751728149428 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark02(8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark02(-8.881784197001252E-16,-0.902053784211195 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark02(8.881784197001252E-16,16.74222059602642 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark02(-8.881784197001252E-16,22.338278605600312 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark02(-8.881784197001252E-16,2603.2868805568114 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark02(8.881784197001252E-16,-74.74310110602794 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark02(-88.92660770400539,0.0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark02(-88.95726341318486,-36.88955127887345 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark02(89.03541520680305,-31.915897216777854 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark02(89.09682562093775,1.53133789823646 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark02(-89.11841049777762,-63.18059421127127 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark02(-89.12554876989134,0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark02(8.925401205564471,5.212959908586162 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark02(89.36987853902937,42.75742513282006 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark02(-89.37762102796125,100.0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark02(89.50452876013112,30.082470542532768 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark02(-89.61956975979044,-0.4115814720639551 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark02(-89.63566193433955,86.39428199111862 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark02(-89.63610763334975,-46.073077698719565 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark02(-89.65402078316924,-99.19212664042232 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark02(-89.67041909346038,-4.892035634308312 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark02(-89.68553549937988,0.47328000253335745 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark02(-89.86384066566885,54.999061657218235 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark02(-89.98449936023316,-40.43121507829875 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark02(-90.01546968781368,-3.158388107191149 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark02(-90.02194001596742,-86.42658298533027 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark02(-90.10308303137376,1.5707963267948966 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark02(-90.1791960273467,2613.9026124855363 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark02(-9.028850019149644,0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark02(-90.37006253644466,-1.5707963267948966 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark02(-90.5429638311241,59.24008061031469 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark02(-90.55286482972106,75.21980748134425 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark02(-90.58539576643656,-6.413508472546351E-8 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark02(-90.73537518064472,-2634.8582516770084 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark02(90.79259742702797,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark02(-90.85567730271106,163.40649521350258 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark02(-90.86508976575107,34.761162073017374 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark02(-90.88558161441492,-95.55465729046668 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark02(-90.88842758551148,0.0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark02(-90.90603305097862,-136.47775273296816 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark02(-90.91156909867311,-1.5707963267949197 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark02(-90.92377924099686,-1.7532040400037228 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark02(-90.93749043416031,-0.32835734291295315 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark02(-9.094884530257197,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark02(-90.97529933782802,74.43779320777398 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark02(-90.98010981237877,1.5707963267948983 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark02(-91.05875013950612,0.0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark02(-91.076114817044,0.0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark02(-91.10610616023249,-1.5707962394661004 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark02(-91.1061865125825,-1.5786088267951728 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark02(-91.10618687340357,-58.1194640732123 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark02(-91.10618690209053,-0.55294866696116 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark02(-91.10618695410392,1.5707963267948963 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark02(-91.10618695410399,-1.5707963267948966 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark02(-91.1063056038142,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark02(-91.1312497971341,0.71333389448852 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark02(-91.25767261482598,-173.22702665271228 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark02(-91.30320232545941,-56.89817988116535 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark02(-91.38227327841254,-84.3793463978852 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark02(-91.42893566462065,-4.9809531496754005 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark02(-91.6036090406264,-129.8994958399457 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark02(-91.63586038043192,-98.34239748649938 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark02(-91.67996449920261,-43.802954939193995 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark02(-91.7154626791731,-24.171220626870603 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark02(-91.77596096544679,-35.44359002825604 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark02(-9.179966350381669,45.18497492572371 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark02(-92.07025541685384,0.5707087463947459 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark02(-92.18379963613114,-108.35406741252993 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark02(-92.18950733866882,54.38753335371105 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark02(-9.23010999504929,-19.094893483033616 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark02(-92.30736744172935,1.5707963267948966 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark02(-92.46595626864222,8.382976526881919 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark02(-92.676983287104,3.778006008982038E-6 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark02(-92.74923430915298,-22.350446747266624 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark02(-93.42470254099872,3.7586127503263356 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark02(-93.50878941377148,1.5707963267948968 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark02(-93.64011074404321,78.43473821645546 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark02(-93.74734354185898,1.5707963267948966 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark02(-93.80910154364695,8.091943471818297 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark02(-94.0611054406081,62.886855297907886 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark02(-94.15539210367608,-11.087961791481566 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark02(-94.1598164976052,-86.72151157315696 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark02(94.2186800451752,0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark02(9.424739847393232,54.97787143781328 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark02(-94.24777957307694,-45.553093603113304 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark02(-94.24777960759381,-1.5707963267949054 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark02(-94.2477796075938,1.5707963267948966 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark02(-9.424777960769378,0.0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark02(-9.424777960769378,1.5707963267948966 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark02(-94.24777960769858,-1.5707963267948943 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark02(-94.24778763839706,1.5707963212294502 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark02(-94.24790174222716,-114.66813088556395 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark02(-94.24973314351672,-86.39380577140695 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark02(-94.29056148347496,2120.1381269390176 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark02(94.32616062287477,-40.716928620551016 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark02(94.45209823236164,2.106265650300879E-5 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark02(-94.48369088192203,-57.70127425403304 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark02(94.6445715947722,164.5895892207784 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark02(94.64799975170317,17.702652384443795 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark02(-94.730539716031,0.0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark02(-94.77508946767809,4.185079120284683 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark02(-94.82726048493339,-14.292562858833335 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark02(94.83283449350253,199.21879487630758 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark02(-94.8623214480441,45.0258959313895 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark02(-94.888026043935,0.0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark02(-9.490195645290228,-9.68464714285237 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark02(94.90560972027544,-51.52294325036768 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark02(94.94695050686067,24.645868831140945 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark02(-94.95516606361237,-1.5707963267948974 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark02(-94.98340620063763,0.0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark02(95.00099669133712,-45.21616321242967 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark02(9.50428628549347E-11,-73.82742735935518 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark02(-95.07224420887941,79.79834412170085 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark02(-95.09239494858268,-0.5707350907539622 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark02(-9.514094509257916,136.43209949562558 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark02(-95.20648798433388,15.744574102082401 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark02(-95.25515333701378,-16.34751408256733 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark02(-95.27653847929517,-100.0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark02(95.33258160872677,-74.1857202504406 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark02(-95.37113965693071,-60.01885148052117 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark02(-95.43531765075738,-63.791859525916664 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark02(-95.60455072300897,44.15742239919443 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark02(95.67018418144727,0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark02(95.68021594603793,-2540.363021327647 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark02(95.69871088463262,-0.11986505069226816 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark02(-95.73993525008714,-108.89667857095098 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark02(-95.80014124900677,1.5707963267948966 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark02(-9.581197845105052,2629.983950725864 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark02(-95.92809775261051,-29.74769413724094 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark02(-96.00576949499138,76.62960203455401 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark02(-96.15168273592067,0.0 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark02(-96.45365936855997,-85.41417795779948 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark02(-96.62228116404643,-99.05150689925868 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark02(-9.670235690694641,39.024450440050245 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark02(9.67477796112844,158.83317866691863 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark02(-96.79568788194382,13.548898428973772 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark02(-97.08216154313907,1.5707963267948966 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark02(-97.19749330194965,-4.415190810863564 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark02(-97.22061539281917,-72.95642303760515 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark02(-97.23451324847534,9.467739772526466 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark02(-97.37359547801019,96.25432919514643 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark02(-97.38937226128357,1.5707963267948901 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark02(-97.38937226314624,1.5707963267948966 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark02(-97.4521261636292,-86.39379797371927 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark02(-97.60982852599724,-99.18062485268966 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark02(-97.69352106557804,-73.83744795111743 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark02(-97.71578187905867,1.5707963267948966 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark02(-97.85562971425333,66.49619692072832 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark02(-97.88960191892015,-2597.439305605575 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark02(-9.80245850214476,43.398638085507486 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark02(-98.10259762441,42.55492077220597 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark02(-98.11120897088654,-100.0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark02(98.19118450385983,-33.6737681504889 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark02(-98.19278590918628,88.423703774541 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark02(-9.821631694262152,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark02(-98.2889799624464,-1.5707963267948983 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark02(-98.29125871542041,-7.700735037117028 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark02(-98.32220093768733,-25.597271221199673 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark02(-9.832716638010943,-1.5707963267948966 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark02(-9.840481467987754,1.5707963267948983 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark02(-9.841943919569161,0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark02(-98.44700040188916,-1.5707963267948966 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark02(-98.60372050667911,5.07750436544887 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark02(-9.860761315262648E-32,0.0 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark02(9.860761315262648E-32,-0.038477195749872566 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark02(-9.897866472620489,-87.96459430051421 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark02(-98.98065087335735,-2699.54160643578 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark02(-99.14839379892055,-2.0150983178505157 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark02(-99.16469036552851,40.38754533167236 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark02(-9.924777960767106,61.76105674500847 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark02(-99.3532212964859,68.72198567030695 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark02(-9.93727332918408,0.0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark02(-99.49855594917612,-66.23097046572877 ) ;
  }
}
