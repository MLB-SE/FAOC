import org.junit.Test;

public class Sample34Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark34(0.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark34(-0.11022577664485143 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark34(-0.34647186178989386 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark34(-0.4506632112770819 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark34(-0.5707963267747745 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark34(-0.8522705802784998 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark34(-1.0375484425827008 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark34(-10.479493723382689 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark34(1.1102230246251565E-16 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark34(-1.1235883814548888 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark34(-1.1942754785176248 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark34(-1.2966284431438029 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark34(-1.4141666471829286 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark34(-1.5705383856336799 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948948 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948957 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948961 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948966 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948968 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark34(-1.570796326794897 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark34(-15.872249941489606 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark34(-16.0687385092352 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark34(1.764327704968254E-7 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark34(1.8429090329024694E-7 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark34(-192.8373505786896 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark34(-21.865824244940725 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark34(-22.258025749829073 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark34(-25.983141242021432 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark34(-2717.6282692674495 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark34(-2723.8958642514804 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark34(28.70356261252947 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark34(-2.9166041064463144 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark34(3.0758569695380546E-4 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark34(3.1415926535897936 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark34(-3.1415926535899255 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark34(-3.1415926535916143 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark34(-3.141592654694048 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark34(-3.141592892012421 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark34(-3.141951372495199 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark34(-3.469446951953614E-18 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark34(-35.19125714072098 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark34(-35.574596700088335 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark34(38.417228746854136 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark34(-386.91578506465913 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark34(-39.25942036167422 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark34(-40.771768926085116 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark34(-42.2509017879436 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark34(4.4925801159842946E-8 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark34(-47.39251252453267 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark34(-47.50564934366486 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark34(4.8734352949546425E-5 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark34(4.930380657631324E-32 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark34(5.269258265397303E-6 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark34(-53.5632246809471 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark34(57.619095579968814 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark34(-6.077163357286271E-64 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark34(-61.00196252871606 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark34(-63.07796637862217 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark34(-65.97772825575494 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark34(66.37761133233465 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark34(-66.56232637214687 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark34(-66.80704429163029 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark34(-6.68910168026872 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark34(-7.337095950370269 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark34(-73.48354022291903 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark34(-739.2742691793516 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark34(-76.96902001294994 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark34(-78.66676708585389 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark34(-78.8071292003709 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark34(80.65950520479234 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark34(-84.82300164692448 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark34(-86.15514687857262 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark34(8.673617379884035E-19 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark34(96.5626930794972 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark34(-97.36259136161125 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark34(9.752004222120547 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark34(-98.15211707727845 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark34(-9.860761315262648E-32 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark34(9.860761315262648E-32 ) ;
  }
}
