import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.001254097491423689,0.448485103163901 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.002873853443837393,0.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.0028785708383595246,-51.655986973439845 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.01036418745543577,1.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.014376975304195452,-0.04332233215013653 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.02124840705540064,-9.450951886297318 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.02576415824421474,2361.755370123854 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.038903721968456116,1.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.04427100804275774,0.8814453038753265 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.08335661037678055,0.0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.08518832105680615,-1.0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.09233075820114524,-1.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.09235167369161293,-1.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.09332884892912208,0.9998234487380625 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.09483331140234039,1.0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.11265228084384388,-1.0000000013260935 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.12431130277459349,-1.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.14516807894139128,-0.319916754628757 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.15072920492776642,-37.70097903251204 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.17734955509767913,62.30966676023965 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.1879328571967802,0.016187988766681864 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.19562243000254043,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.19841688491614878,-0.3042537540156047 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.22279378019148574,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.22659563307222358,-0.9999999999999982 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.24172376525995184,-0.33721242095971515 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.2489692917318846,-24.95927194908913 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.28640290280328884,65.57954025680456 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.2916811006065515,-0.21677230761558142 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.3180968781414875,1.0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.331110747185285,85.96365073862947 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.3532804677885888,-1.0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.3555662137660601,-100.0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.35960893248493364,78.85660647346748 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.3626743316416238,1.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.3708647810046316,3.910318545279494E-149 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.3911277902540396,1.0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.39496159487590254,0.36208927228844756 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.40250772334464413,1.0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.4240619161608693,-0.04011248756763974 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.5237403426437977,-2282.0205751379067 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.5358153645127448,60.7845113268495 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.5530955996437014,-59.72746452199369 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.6237187435468591,99.70036951184085 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.6267266371718798,29.273020686579336 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.6527530258370225,0.0011216869213855835 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.6859669628421808,-56.59016664341766 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.7073235858802241,1.0077486652448788 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark55(0,-0.0743315778105309,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.7560093927978926,-72.37270979600962 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.7579513320293193,-82.0923270379514 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.76708339272669,-1.0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.7713806625343479,1735.3956159289598 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.7997816977354579,0.6761601275803366 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark55(0.008338856676388767,-0.10083206923240262,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.9445077050538064,-0.026311773807908563 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.9473592250536016,0.009298680538990127 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.9558858900464586,-0.0029724738783344865 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.9561794633277017,-1.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.9709976117503952,0.6873264939413559 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.9736014591679512,-66.6094048447223 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.9763402239015448,-38.21196110822785 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.9890565925752091,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.0091543820337723,100.0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.0391357262224106,1.0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.0786277290820616E-5,0.7893444980336225 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.1176693667538915,46.14495874517947 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.1296543132801395,10.65937656659008 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.138985551315202,0.02970817489582847 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.162274728444212,-46.9165450479037 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.1738807630795662,-0.011677876000035685 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2232729362110495,-53.29532262292549 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2282716766216453,3.7148315042520306 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2322804358163062,0.746752640605479 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2366168440036809,-0.5552851315432832 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2722318723620814,8.881784197001252E-16 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.29767255568889,-12.92105006893923 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.3260912193803178,1.0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.3303729277458842,1.0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.334013920067297,59.26289442620584 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.3383012327202406,1.0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.3522268333687695,-8.869000584230697 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.3553962491080067,8.673617379884035E-19 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.363935968332602,-0.2999380324050642 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.3692768970554647,72.71917345277437 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.3722964216869888,-0.3842581325900214 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.3811176766001774,1.0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.394198500750447,0.866056749630759 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.3942526178701566,0.273094594419927 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4105460306593942,48.04279586375898 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.418316752347234,-31.345834908781498 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4263437178361622,-48.978796550097734 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.43165091901038,0.08453966099821697 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4317070633134732,1.0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4415214029844872E-15,-0.02949461689257238 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4430099223079549,-1.0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4648782590481948,-1.0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4703942131100023,-2.7516420536594796E-135 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4738765117654047,-0.5955735417205161 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark55(0.01474598900497881,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.492629206948937,1.0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4980173101008232,0.8912747727889851 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4992162392948576,0.9999999999999991 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.499789922308191,-1.0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4998403372266467,1.0000000006270917 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999943472521418,-92.62225148898538 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999925720913,1.0000000088888148 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.499999999999997,-0.8947550380833678 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999999999991,-1.0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999999999991,1.0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.499999999999999,23.533150451422912 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999999999996,0.06255252568606275 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999999999996,-0.5731865256206135 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999999999998,1.0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999999999998,-1.000000000326023 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999999999998,-1.0893082596889171E-16 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.6543612251060553E-24,8.271806125530277E-25 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark55(0.020884542648741067,-0.17630685750876185,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-2.220446049250313E-16,0.5665837621497394 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-2.220446049250313E-16,64.75265972435056 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-2.5155409315458455E-9,-1.0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark55(0,-0.2717122097594884,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-2.999393627791262E-241,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark55(0.0,3.2048143219015296E-18,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark55(0.03276561160615188,-0.6198682620465377,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark55(-0.038519819686013576,-0.04600425501873171,-0.8713873540797732 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-4.440892098500626E-16,92.74740179204964 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark55(0.044856377334241415,-1.399149216552427,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-4.968240779877628E-5,-1.0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark55(0.05388500112186989,-1.1840556971627008,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-5.626658763263925E-15,5.867280823870266E-9 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark55(0,-0.5800233029628288,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-5.99034852451248E-7,-1.0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark55(0.0663164335490459,-0.5126053144158926,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-6.989131185422577E-4,-1.0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark55(0.07008792149139761,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark55(-0.07050272304445586,-1.4999999914867734,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark55(0,-0.7264024107863918,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark55(0.07715251342702954,-0.6097693497881082,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark55(0.0809184000994918,-0.8773389172142441,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark55(0.08164140355413221,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark55(0.08477947272934117,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-8.881784197001252E-16,1.0000000000000009 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark55(0,-0.908579672326141,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark55(0.1031380355308617,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.0523167341511233,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.1075593708206513,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark55(0,-11.307461183808229,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark55(-0.11941843064128288,-0.8810252237293251,-2.4333972048578046E-209 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.2137606527834635,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.2590436560803175,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark55(0.13714105681590638,-0.8151749922582496,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark55(0.15041063275443406,-1.180918291118994,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5613201284778344,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark55(0.17343583820281427,-0.05796229710907374,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark55(0.17729780239328363,-1.4329409241956492,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark55(0.17919233631373288,-0.1582259027347952,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark55(0.17939098575231593,-0.1320001503596172,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark55(0.18100813283868789,-0.43570292187688,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark55(-0.19006408434596267,-0.7412910488493454,0.37238295941994937 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark55(0,1.960354222798074,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark55(0,-23.960456644536194,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark55(0.2577990245395938,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark55(0,-2.5E-323,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark55(0,-2625.8842863367377,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark55(0,-2643.8069859777065,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark55(0.2824271851012865,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark55(0.28419172565146766,-0.32698145745024476,0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark55(0.302087193608088,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark55(0.30308493205635045,-1.3313598923366605,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark55(0,-32.26773802704912,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark55(0.33262378219815436,-0.3614753379595831,0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark55(0,-33.849927580386534,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark55(0.3393498129888819,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark55(0.3602640620359807,-0.13683797358421743,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark55(0.37081214613192204,-0.47650771880290677,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark55(0.3740512675923434,-0.349630029971705,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark55(0.38552749520499674,-1.4933715252658892,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark55(0.41981432218984216,-1.4999999993595377,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark55(0,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark55(0.4538675172149169,-0.6593549459578725,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark55(0,-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark55(0.49654785591235395,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark55(0,-51.39401618840505,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark55(0.5467964112595092,-0.8890014144108855,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark55(0.5506896063672144,-0.035430753569043016,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark55(-0.5733398288632952,-0.009330221522133062,1.0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark55(0.5768058834455019,-0.3063233105538392,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark55(0,60.259725840976046,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark55(0.6076730109696058,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark55(0,62.469187158386376,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark55(0.625415219320077,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark55(0.6414604862744682,-1.0704002856660129,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark55(0,-64.2226943730696,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark55(0,71.57644426197464,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark55(0.7178449642720466,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark55(0.7442851160442081,-1.3391093745174185,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark55(0.7461112105701115,-0.6048114161304454,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark55(0.7647028121660231,-0.6287087175693955,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark55(0.7686717094477541,-0.9101593519743076,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark55(0.7977106568384789,-0.9994337644888742,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark55(0.8015825792343619,-2.596175597588752E-9,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark55(0.8060863797500446,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark55(0.807708663076715,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark55(0.8232120523432798,-0.449309537929679,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark55(0.8233707665877006,-1.4434145191003438,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark55(0,-82.59110884410528,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark55(0.8547734593958296,-0.5940985973186335,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark55(0,-85.63882084512252,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark55(0.8577802144881872,-0.9800282412136596,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark55(0,8.684769952010341E-19,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark55(0,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark55(0.9191548338190367,-2.5871380192900127E-7,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark55(0.939371416937135,-0.6101933702615554,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark55(0.9667575596512092,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark55(0,-99.72816849709281,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.0072168753413330835,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.02280979946045425,0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.025667646283402012,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.0312324865359912,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.031761468000990556,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.03626615879941312,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.06279419692477213,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.07062225128679525,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.07978403916401389,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.08891204106814216,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.09101039522041507,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.0941949435386073,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.10397208855803576,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.126111600400248,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.14072624427997726,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.15582938983105699,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.16307194166354277,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.16577643392737157,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.17084269898250248,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.17874621406466118,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.1859357658539011,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.19129233620440508,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.2036186331895073,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.21250602915801542,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.21917733234030523,0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.23643247676642987,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.2538386847487637,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.25678238618811866,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.27558414458202884,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.276975987298816,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.2881057822302491,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.289240277229209,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.29074548649869647,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.2927678993069515,0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.29923985460413527,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.29983354862779105,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.30231974744324713,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-0.3103585384947536,1.0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.3173481136853049,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.33504459981809365,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.34254415961720097,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-0.3552290142716521,2.4996521470859035E-15 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.3615857057996069,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.3643725883816826,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.37413264369478316,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.3755308116231776,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.38628517290576436,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.39708638130306584,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.39969635366284406,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.41861985139848024,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.44124093320531976,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.44944342078866073,0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.4528353018905978,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.45822287895876146,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.47015986217076366,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.47988194339509005,0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.48831297386229305,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5205043820919271,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5289952777457569,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5312979335288296,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5911878471215136,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.6004509401481601,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-0.6243351876568172,1.0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.6455839590168295,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.6637444813133566,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.6741923262888976,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.6775792310200548,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.7316957910776629,0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.7386265930277304,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.7477416594109503,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.8325629580796599,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.8719701346760811,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.8731823139565367,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-0.889215050169061,-1.0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.891928176657391,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.8983133099010552,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.9284784632963845,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.9388203934313233,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.9420716607877807,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.9481532435879549,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.9599385857693556,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.9694893118290056,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.973092811631594,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.0013006970082545,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.02121971172149,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.0645436740976733,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.0780208549722705,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.1108277020770798,0.49186538917386213 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.1179761173568408,0.9313347320744451 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.132538931113895,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.1491512323028665,0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.1508000858888923E-6,0.5701482293815058 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.157430672113391E-15,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.1583897841305304,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.189901320476173,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.212788319118613,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.2562464781815397,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.2786073693863202,12.989648617828095 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.2828961866320074,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.3454378243256824,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.351882110158022,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.3608958986076343,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.3811809130600854,1.0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.3875021707832047,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.3898321797303106,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4193751387417284,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4321057563682822,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4334766869826994,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.4446364063336343,-0.056295439368828026 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4570040037502974,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4756371348255986,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4860329748810983,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4997737810329057,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999285985606,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999783110487,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999795817018,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999596156,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999716,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.4999999999999964,-100.0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999967,0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.4999999999999998,-0.9828356503562182 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.7075770273941657E-6,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.7763568394002505E-15,100.0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.9561479361565364E-6,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-2.1342492146670695E-7,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-2.1731619394404606E-7,-0.0625526542450986 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-2.2643822644480983E-7,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-2.990387632224289E-7,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-3.6191896624476357E-7,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-4.2289753907067315E-8,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-4.444415148851397E-10,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-5.874960006162337E-10,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-6.260356083366231E-8,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-7.060542859686772E-7,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-7.735232077900676E-9,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-8.855373344294521E-10,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-9.111056934607346E-4,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-9.138173742910659E-10,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-9.373056447845585E-4,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-9.711506410675625E-8,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark55(10.011757002188624,-1.4999999977932483,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark55(10.031972208991498,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark55(10.068869553905593,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark55(-1.0076400039022306,-0.4177080822630404,1.0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark55(10.08903621536413,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark55(10.122552728382757,-0.8672569140236162,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark55(-10.143849392656712,-0.8189363756636894,-1.0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark55(1.0151131618445817,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark55(10.195253595918075,-0.011603544063229812,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark55(10.231513099346962,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark55(10.257990008511857,-1.2348637189876932,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark55(1.0261342003245941E-289,-0.7742494328812813,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark55(10.306903182495201,-0.7509513635083751,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark55(10.343304598388215,-0.4065085712988443,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark55(10.355422072429134,-0.6853662657674833,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark55(1.0364628690298134,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark55(10.37845819004584,-0.32481499057276475,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark55(10.379911543107372,-0.9314640872539663,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark55(10.380274916156331,-0.2134925995603218,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark55(10.381441031563838,-1.100179993931235,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark55(10.387957218937999,-0.42348495868663816,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark55(10.393033939696561,-1.371122123331004E-7,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark55(10.401667116308122,-1.0270801337091076,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark55(10.416040955213163,-1.4411560623685444,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark55(10.421102848524,-1.837294348095096E-8,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark55(10.435251226851179,-0.7888545980791355,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark55(1.0465223549155418,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark55(1.0517744365832824,-1.1926511527303268E-7,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark55(1.0517903453985582,-0.7031508113723999,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark55(-10.532783631903431,-0.03803647670518773,1.0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark55(10.54194421241954,-1.3613589968407735,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark55(10.618026624965452,-1.2990429056699782,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark55(10.65770353851731,-0.9493296903221894,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark55(10.722074470978498,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark55(1.0728077947348744,-0.3601183696316107,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark55(10.773013981501952,-1.2140521362289505,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark55(10.776648583701885,-0.2364793839482182,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark55(10.861575981879312,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark55(10.893932247038212,-0.1984025368117509,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark55(10.926937933500568,-1.4999903339462315,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark55(10.999062185717563,-1.0657479581026568,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark55(1.1021930932827317,-5.4486358871581155E-9,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark55(11.069113476607782,-0.8613483003534952,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark55(11.072843192143992,-0.6800740524578153,0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark55(11.111379475927425,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark55(11.112722840421753,-1.2045767967162702,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark55(11.147852801039006,-1.4999999336855154,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark55(1.1235225828230426,-0.42574738623670205,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark55(11.249393626219433,-1.3892757205420367,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark55(11.27027874068498,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark55(11.306875584722263,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark55(11.309894892181347,-0.7598369034552945,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark55(11.406516707634921,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark55(11.42587842640475,-0.41952028003493314,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark55(11.435640286162709,-0.744534514489539,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark55(1.145812882212594,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark55(11.477362253562305,-0.47598448991382036,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark55(11.484751783349154,-1.4999999999999503,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark55(1.148679157297039,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark55(11.495887934630943,-1.3928483537509297,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark55(11.52770383917121,-0.5673008753270569,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark55(1.153524388971964,-1.2348116548252905,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark55(11.558506527160947,-7.9146059856809E-6,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark55(11.58919049686288,-0.2800379151756971,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark55(11.601245604988552,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark55(11.629329326523504,-0.08642236880202459,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark55(11.636628820086651,-1.4999999996637368,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark55(11.674118625185825,-0.9197520923723346,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark55(11.686662791864464,-0.44056380637655473,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark55(11.764919587719874,-0.3601310877583739,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark55(11.78126382393922,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark55(11.81032675330762,-0.02886945988342049,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark55(11.828101770307743,-0.581450001620171,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark55(11.896742596077715,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark55(1.18992062318868,-0.8636891288822426,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark55(11.907240817742302,-1.499999999966435,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark55(11.913832780466677,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark55(11.933372587737946,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark55(11.977777176266786,-1.4999973147503591,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark55(11.999414816463183,-0.3431514585419624,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark55(12.05329571570067,-1.359630354854239,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark55(-121.05590067433914,-0.12138574832947555,35.043962037218456 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark55(1.2107861600925531,-0.07728776731208509,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark55(-121.29381005762968,-0.4742124410449975,-0.3695476220615177 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark55(1.2168206295585244,-5.611464916048247E-8,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark55(1.2367198702352624,-0.014279442369293596,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark55(12.396202556416497,-0.3666552245245924,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark55(12.406727855087098,-0.8164809111826123,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark55(12.414893088276457,-0.7764199056118599,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark55(12.484710418237071,-0.028846334950398234,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark55(1.250578081759624,-1.4999999136687487,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark55(12.605901425141212,-0.4077026246385387,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark55(12.630941696822148,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark55(1.2689902356672096,-1.499999999949949,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark55(12.691023328213745,-0.8075705734483165,0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark55(12.701639305366019,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark55(12.711143267663786,-1.3482153379516353,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark55(12.751462810051379,-1.210385019416544,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark55(12.7712002423511,-1.3079697655949944,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark55(12.818577362903767,-1.4988187299812679,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark55(12.871333230355802,-0.40488908568353565,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark55(-12.874749239302302,-1.1486512121980517,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark55(12.899724381759539,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark55(12.920916415157109,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark55(1.2930815060097558,-0.2626013973955139,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark55(1.2985067832571477,-0.8734223065705883,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark55(13.076411714858367,-1.271757121676842,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark55(13.08738847474929,-0.5095700463407837,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark55(13.092922660453805,-0.7444004510551142,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark55(13.131807927266282,-0.20058194337604032,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark55(13.172799720548795,-1.4646536853682206,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark55(13.206544094456447,-1.4999999126661847,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark55(13.222773881033874,-0.6202887965968205,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark55(13.30915781201672,-0.9144499273625746,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark55(-13.32925620897463,-1.1806114511892571E-6,6.7833213790438156E-167 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark55(13.35032609876577,-0.34477019942829656,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark55(1.336033225887984,-0.0042011084502071045,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark55(13.36250227244659,-0.47975805110565917,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark55(13.44053452412497,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark55(13.44677604729199,-1.3078770706363825,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark55(13.463856689157865,-1.1260992641570797,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark55(1.348574477461885E-10,-0.8907489551436135,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark55(13.492576508327641,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark55(13.512116935032823,-1.4999999983591532,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark55(13.51246053958695,-0.24779151705819386,0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark55(13.529323917091048,-1.183635171024059,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark55(13.552252277591464,-0.030553535199529802,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark55(13.555894844646033,-0.338366936039717,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark55(13.58658246332989,-0.8239090089574748,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark55(13.589545662075214,-0.41502991456640065,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark55(13.603439023807574,-1.121178911348907E-9,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark55(13.618038903297187,-0.507938665872321,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark55(13.631173453157501,-0.379567487924815,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark55(13.676968707698904,-0.30596364557661426,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark55(13.708954776098654,-0.5956084146420366,0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark55(13.709346996104223,-0.24292268727638633,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark55(13.747576356415493,-0.742449938397916,0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark55(-13.777929474282402,-1.0274167644931438,-0.44429076751650043 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark55(13.79264411172924,-6.2701936949742936E-9,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark55(13.800790602246646,-0.6502257141065426,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark55(-13.835547404563291,-0.39542002813505706,-0.334810364551098 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark55(13.922845390871814,-0.8807980248065865,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark55(13.942869086051445,-0.8793851850843039,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark55(13.949768912608192,-0.9944586614806575,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark55(13.960469119253588,-0.2901360296177666,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark55(14.037442160623755,-0.8711690780380055,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark55(1.4049394756162599,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark55(14.057251480493672,-0.7134156751679162,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark55(14.062146095808508,-0.07663516843505169,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark55(14.083895586126431,-1.2184726946099667,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark55(1.409688530422443,-0.37104878938352426,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark55(14.102843196210618,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark55(14.145475888804228,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark55(1.4159521718110142,-1.3137508769701611,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark55(14.32085849088,-1.332047623798502,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark55(14.321850614329662,-0.9962637848780922,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark55(-1.4332784169474735,-0.8861908659186384,-69.9053205246776 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark55(14.375124677347799,-0.3079651674843644,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark55(14.41433645437957,-1.0988974374256828,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark55(14.490777690995547,-6.886341583041876E-8,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark55(14.528164730008264,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark55(14.530885387877433,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark55(14.545219868317432,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark55(14.56768914265102,-1.090434693573509,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark55(14.590102840202077,-1.4999999998339113,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark55(1.4642190900354726,-1.2747322105669014,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark55(14.658247820124743,-0.26307362655494726,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark55(14.66586604036209,-0.666996673261238,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark55(14.673378026043935,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark55(14.673800730698757,-0.6576365565811031,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark55(14.704048869745634,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark55(14.71801696554813,-0.6699252119232142,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark55(14.730665764496592,-0.3498029314839841,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark55(1.4731754840715752,-0.12682563687005932,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark55(1.4735323350490188,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark55(14.891447679733758,-1.4573849000924577,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark55(14.90688678093094,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark55(14.917369348517823,-0.36555553715771716,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark55(1.4956829947916574,-1.1881037394242613,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark55(14.960315562249662,-1.072766633725518,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark55(15.116904572922143,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark55(15.173469704128877,-1.421961661486364,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark55(-15.22210391001062,-1.1767986319285129,1.0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark55(1.5248640396747852,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark55(15.254412072210787,-0.7548158670862747,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark55(15.265885512407229,-0.5576707874639348,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark55(1.5267898717308666,-1.225871367501064,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark55(15.284199028670614,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark55(15.29161936128034,-0.11993230188173865,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark55(15.304072143697695,-1.1239928597951279,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark55(15.332948635915827,-1.0342515490865622,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark55(15.354272763811565,-0.916875415610491,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark55(1.538398856791055,-1.0839287090547,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark55(15.453335106890037,-0.9187837047814738,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark55(15.513930557917604,-0.9394903422372489,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark55(15.53658993073115,-0.004651446618211708,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark55(15.549573799316278,-1.1850425374765252,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark55(15.551022548323857,-1.230719473554279,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark55(15.567915666693311,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark55(15.584233169983946,-0.3061683472935689,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark55(15.591949445012649,-1.3233157018136115,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark55(15.596237564829934,-0.8280179564862715,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark55(1.5633971775305184,-0.9205364304479393,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark55(15.647023385894968,-0.42767477658646413,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark55(15.677409827576398,-1.1084678937656207,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark55(-15.729237057673458,-0.9310574785834135,-49.81581576085341 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark55(1.573077071378585,-1.4532402410934921,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark55(15.762722864869442,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark55(15.774994299589224,-0.2122344702890473,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark55(15.806049894944636,-0.8920124880264391,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark55(15.854345654580724,-0.7698750079125121,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark55(15.88154137112545,-1.2254390413011986,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark55(15.890305673575508,-0.009660004272008749,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark55(15.900656082554868,-1.4999999996741793,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark55(-15.925471126423545,-1.3807676727299623,61.823828742287155 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark55(15.945106787920054,-0.6931941306996681,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark55(15.961854318874131,-1.1262924656843012,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark55(15.978675319492549,-1.0315093500898644,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark55(15.98117781720947,-0.8260093746147419,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark55(15.99749530078725,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark55(16.032294291144964,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark55(1.6043326081191793,-0.7808526304666495,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark55(-1.6119901167095554,-0.039868391767414885,-100.0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark55(16.1546714497728,-0.7316720462715796,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark55(16.15504544137981,-2.2593591277085367E-8,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark55(1.6176940837959801,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark55(16.184945974979918,-0.3341242750619269,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark55(16.224273875088958,-2.5630048704950357E-9,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark55(16.25210887204078,-0.3663121183181719,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark55(16.342310095747223,-0.37719725624895073,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark55(16.359784840763638,-0.5784601755965335,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark55(16.36167754984224,-0.6873301078991986,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark55(16.383675908431215,-0.43264326058812763,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark55(16.400355671719915,-1.9938182765182867E-15,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark55(16.4221645250024,-1.1603893473675764,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark55(16.449745448258888,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark55(16.457252973548563,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark55(16.506313129649072,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark55(16.550789148741693,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark55(16.624567004922298,-0.5123382880788945,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark55(16.683127924870718,-1.2617628512940229,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark55(16.688037390716246,-1.4890362074204107,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark55(16.757616726199423,-1.4999707921304086,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark55(1.6763689731880183,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark55(16.78874335204918,-0.1986351341255208,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark55(16.80334800692704,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark55(16.815703028594186,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark55(16.887900992433636,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark55(16.913436259098432,-1.0400657855165767,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark55(16.922487336357378,-0.32877762268107436,0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark55(16.987878034070732,-0.552034237587584,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark55(16.988711314933695,-0.1982416404233618,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark55(16.99059731083834,-0.9358846792028892,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark55(17.017066560539632,-0.4579777846667987,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark55(1.704697507075963,-0.2709012705361721,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark55(17.09020756181801,-1.0641399246404215,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark55(17.144213180808926,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark55(17.163953056689216,-1.4151822121569544,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark55(17.180964557955775,-0.9429084862191246,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark55(17.215211278343105,-0.984019007943659,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark55(17.242061096379558,-0.11268252289724501,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark55(17.30195339293668,-0.309311284018019,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark55(17.303200593339323,-0.023563745782855028,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark55(17.330232610244465,-1.4668488734354668,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark55(17.332758140429625,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark55(17.335975564686933,-1.1343259967018278,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark55(17.353177207257843,-0.9666161422017634,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark55(17.358741658829842,-0.9019798623973969,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark55(17.502334733891317,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark55(17.65296087566422,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark55(17.729219960216007,-1.2202365751614586,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark55(17.737340835570507,-1.219593991878881,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark55(17.75519354647744,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark55(1.7763568394002505E-15,-0.777755424193423,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark55(17.79769885610664,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark55(17.810864824179774,-1.0024373107648872,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark55(17.82999562173211,-0.003383983270917046,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark55(17.90767663049107,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark55(17.90768717819566,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark55(17.982714767920235,-2.684911751249227E-9,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark55(18.09120015761555,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark55(18.163132499217994,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark55(1.818982715670387,-1.1964321960964863,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark55(18.226304549268747,-0.7203302045790423,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark55(18.229632341984,-1.188380059152916,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark55(18.25577104120491,-0.43343874623154477,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark55(18.26454435368241,-1.4999999999999876,0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark55(18.29438477727878,-0.820176440148364,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark55(18.310385294834106,-0.3568935567328708,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark55(18.420864019037996,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark55(-18.42219170800196,-1.1399104754993215,-1.0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark55(18.423878343542114,-0.3711657205662622,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark55(18.428857095463343,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark55(-18.521402966716547,-3.552713678800501E-15,-1.0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark55(18.55271504399832,-0.25469991722451457,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark55(18.557685052540585,-1.3901702897108592,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark55(18.566613957607643,-0.5062312344351514,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark55(18.56928384732917,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark55(18.586200432939947,-0.9301011019669618,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark55(-18.622318196506498,-0.11255803584953739,-1.0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark55(1.86369640912001,-0.35388578921813973,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark55(1.8663891099850594,-6.605795265187887E-5,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark55(1.8689786327971993,-0.49950256369612894,0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark55(18.736271820555245,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark55(18.752054754986744,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark55(18.774698484456096,-1.2728787976024578,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark55(18.77712943906166,-3.5921421158074784E-8,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark55(18.786018753331874,-0.9028517931372809,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark55(1.8786856560612468,-0.08799600289237823,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark55(18.801835517898596,-1.2334372011010932,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark55(1.8822139781442369,-0.3327092633957882,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark55(18.850484800763823,-0.09370699305799034,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark55(18.93289903613508,-0.8051258996485058,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark55(18.98404387218386,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark55(-1.8E-322,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark55(19.000122812549122,-0.8613886897963035,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark55(19.066869638168995,-0.8273386000880797,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark55(1.9120416137900236,-0.006008025749773882,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark55(19.16047050856716,-0.35030227255388535,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark55(19.226531352860356,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark55(19.25684532615209,-1.398145011097495,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark55(19.30178893799455,-0.0023813622036697214,0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark55(1.9309059332954108,-0.3825572862765312,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark55(19.319344202467306,-0.17811292929615963,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark55(1.9346469465723999,-0.5145502307283953,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark55(19.374176536742823,-0.2997908377385188,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark55(19.438260874712725,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark55(19.440454689567396,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark55(1.94641215672209,-0.8829815930088039,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark55(-1.9501045677198157,-1.4999999999999996,38.45348300982681 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark55(19.558175846784476,-1.0876905015581286,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark55(19.607827681500382,-1.0433130058099471,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark55(1.9631111864822044,-0.307448639889324,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark55(19.673779649165716,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark55(19.678853863235094,-5.9581332822526334E-8,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark55(19.67997491749442,-0.19280073406514564,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark55(19.714523190146565,-0.7793015957266858,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark55(19.733736842343777,-0.27832172257862337,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark55(19.747426859770954,-0.7385033145715533,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark55(19.762593975095342,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark55(19.783783638628766,-0.02928725871877033,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark55(19.827420647383235,-1.2692154140248562,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark55(19.868328726787627,-1.499999999383826,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark55(1.989623773777062,-0.5020962867795983,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark55(19.935133812590806,-1.4817056077735546,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark55(19.950195196695873,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark55(19.955144223764066,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark55(20.001548370978938,-1.1132068974974985,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark55(20.02665158712034,-1.0251780328632694,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark55(20.034984886702873,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark55(20.081070008603504,-0.6317396845770844,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark55(20.089987808684754,-0.15944723630388036,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark55(20.124660538774535,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark55(2.0131268423140227,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark55(20.21016052653145,-6.472903308089158E-7,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark55(20.219838899166785,-0.10881643543001684,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark55(20.264338072572258,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark55(2.0307234618621948,-0.6765582921816728,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark55(20.336269599674452,-1.2684834601674804,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark55(20.34721890493651,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark55(20.349973876363464,-0.7758592233568358,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark55(-20.365579862258485,-57.41665426148881,7.467302734130257 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark55(-2.041634659613024,-0.017323256155372842,-47.66697422945177 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark55(20.424415688432674,-0.34192279819669125,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark55(20.42751026246941,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark55(2.0433192976826433,-1.150800110525079,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark55(20.461091814044003,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark55(2.047394195316933,-0.6581665465168784,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark55(-20.479557862449003,-1.0500000000000012,-0.01774555397537325 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark55(20.485145504510058,-0.16924900622654682,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark55(20.542077754275393,-1.106959774300431,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark55(20.56335487056041,-0.22896636464463893,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark55(20.611978552373415,-0.6902322378111094,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark55(20.633643817639907,-0.38554435425974276,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark55(20.643038394047675,-0.38859484123746757,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark55(20.664209277766005,-0.4188377494562553,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark55(20.71542890311642,-0.7702351199153479,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark55(20.771937606634566,-0.23799329212004605,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark55(20.805759385339243,-1.3573813854645351,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark55(20.822474108218202,-1.2789195509598819,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark55(20.84077403238969,-1.0369092786515182,0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark55(21.00532601743963,37.47627826760885,-43.99313425993536 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark55(21.04169859253531,-0.0022340262572271286,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark55(21.05777038005246,-0.31901615997647603,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark55(21.063412283421325,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark55(21.090575099123583,-1.4664421989122278,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark55(21.151111433051994,-0.15414648015822907,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark55(21.189043966247368,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark55(21.205364374713426,-1.287004663837322,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark55(21.240401218577226,-3.183678933055532E-9,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark55(21.24527204722214,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark55(21.26892263927988,-0.04571048430655367,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark55(21.280873046559876,-0.5889374589513388,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark55(21.31138924401105,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark55(21.36381746663264,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark55(21.374679465889706,-0.07540205649410364,0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark55(21.37751958518652,-1.141439603319613,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark55(21.446128134697616,-0.9102524922821469,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark55(21.449626639991322,-8.513020937248517E-10,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark55(21.45084951151878,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark55(21.517348018796365,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark55(21.55968114851351,-0.4209671805223625,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark55(21.584852334149332,-0.39928892744206834,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark55(-21.589826251781556,-1.7763568394002505E-15,0.9470170853478925 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark55(21.601527065688202,-0.5574507875539769,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark55(21.607368871840052,-0.269716421137448,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark55(21.680686439856018,-0.21185701792024147,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark55(21.704141083416587,13.834523189751806,37.116486688900096 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark55(21.714262754457145,-0.4385798190596879,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark55(21.75655123401195,-0.46968871098428117,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark55(21.77177717000785,-0.6078699836725838,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark55(21.779407858328753,-0.21688069752157446,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark55(21.83464306061238,-0.4921311979856142,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark55(21.83948840987044,-0.875105956063142,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark55(21.852199014151523,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark55(2.1854842700799963,-0.05916195720623618,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark55(21.91873548971623,-0.739948464442385,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark55(21.92232607412088,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark55(21.972290386537523,-1.244800092575744,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark55(22.00157853785798,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark55(2.2038921950740926,-0.19812178339122966,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark55(2.2046432231043127,-0.46136130946257126,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark55(22.05119313599721,-1.16844232423297,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark55(2.2067338627481097,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark55(22.07139100789537,-1.2913149974083051,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark55(-22.09696326816088,-1.2382299551296427,-1.0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark55(-22.113005086157543,-0.9975655827634169,-0.00160068700733533 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark55(22.143799118409177,-1.176085964527637,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark55(22.149128729904174,-0.6388527847994188,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark55(22.169825318511037,-1.0023194053740605,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark55(22.185082882611297,-1.0990709223259123,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark55(22.212379906861536,-0.5471936901641774,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark55(22.257888241224997,-2.246841645145057E-9,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark55(22.270327222985834,-0.30853457580376675,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark55(22.275668418151785,-2.954205394468957E-9,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark55(22.297563547769556,-0.564239931310329,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark55(22.382079875107834,-0.5094005354127091,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark55(22.383076368035415,-1.1698199154904438,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark55(22.402351085155843,-1.340841688391361,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark55(22.555060856924335,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark55(22.57009978524343,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark55(22.63918460788961,-5.208439029532699E-16,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark55(22.768477448563317,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark55(-2.277954791449681,-1.4924044458819177,0.0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark55(22.937266704908993,-1.4276260862165415,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark55(22.94049730712797,-0.750789351172017,0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark55(22.949952529646893,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark55(23.00490801167021,-0.9397824327313202,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark55(23.028664410286396,-1.0365988645726782,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark55(2.3036082311247696,-1.4186300258798377,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark55(23.063363734671455,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark55(23.098594679197376,-9.400249803705245E-10,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark55(23.13900021361684,-1.4657575222882855,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark55(23.159417407392347,-0.024452704965139738,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark55(23.237440238416696,-0.9520395668795842,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark55(23.302966537700314,-1.2375429624452279,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark55(23.321918104370212,-0.9947226850119985,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark55(23.324305259871863,-1.295639664105848,0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark55(23.335400079779035,-0.6843486305750814,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark55(23.34863157531037,-0.8550009609628951,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark55(23.349681203809155,-0.1829922319388821,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark55(23.3519774230014,-1.2957173007305238,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark55(2.336740081359352,-0.11721608239647807,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark55(23.449070164083018,-1.062837522531943,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark55(23.453679019811617,-1.4975002700750397,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark55(23.4579636959175,-0.3207675774859382,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark55(23.50807372774635,-1.1190992429301048,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark55(23.526635479646657,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark55(2.354869783838825,-0.3173459056665836,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark55(23.56492679782104,-0.9188482199618586,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark55(2.357877392893016,-1.1171226466899924,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark55(23.601111341913224,-1.2129301463361628,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark55(23.624784489457948,-0.6838013604764861,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark55(23.70604779826313,-1.1709413236124646,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark55(23.72359573231222,-0.06449687331107451,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark55(23.799514570891105,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark55(23.81095806452072,-0.3741511636348278,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark55(23.83253190711818,-1.1167651537214562,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark55(23.839139385013453,-0.23110530892311232,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark55(23.864574176555955,-0.6791727482307285,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark55(2.3901277346160867,-0.12135225155531693,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark55(23.943501171752146,-0.22494118731447088,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark55(23.984605376937566,-0.4930060254622548,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark55(23.989085157367274,-3.787397359185661E-7,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark55(24.030330545981897,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark55(24.05425075550015,-6.218792913639118E-5,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark55(24.105335569659474,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark55(24.15970351895791,-1.3308141492072726E-4,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark55(24.187266476961366,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark55(24.20178012603462,-0.0035018121700431948,0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark55(2.423436468599135,-1.4501874702866422E-7,0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark55(24.246157055639813,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark55(24.279994109857256,-1.4816742574807895,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark55(24.33368513443517,-0.2972733394756162,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark55(24.392689597837915,-0.5490425082971355,0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark55(24.421512078463106,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark55(24.438248555001923,-0.6777375341954912,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark55(24.469528584736963,-0.8260013509570427,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark55(24.523574770680455,-0.39534195621227664,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark55(24.535119853608833,-1.4995144191288716,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark55(24.566411171714833,-1.330896137582168,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark55(24.59395152421402,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark55(-2.465190328815662E-32,-0.32776889901846057,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark55(24.66076164493447,-0.8604495774016667,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark55(2.478227398920499,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark55(24.800849390711253,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark55(24.820121271805377,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark55(24.821771588461615,-0.16481058421610917,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark55(24.83795956412966,-0.6887266427653174,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark55(-24.853368982376928,-1.4646582638645487,-1.0000000000097409 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark55(24.87331208108653,-1.3511542058726642,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark55(24.964853543075776,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark55(24.987048454004167,-1.3782928109568116,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark55(25.045587269370753,-0.42133773035471334,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark55(25.159464869314796,-0.32735225935592527,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark55(25.23448372225043,-1.2449431535282862,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark55(25.333089952702665,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark55(25.351546084274442,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark55(25.369886897644562,-0.3584437903891171,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark55(25.37840014157085,-1.0883008719596319,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark55(25.39331839150918,-0.019947975534787332,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark55(25.41093723107936,-0.6761609431604363,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark55(25.432093309329346,-0.23271341928609957,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark55(25.43989472867689,-1.2473490334156287,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark55(25.454766487181303,-0.8769979744536696,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark55(25.45686177863927,-5.448712001793892E-4,0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark55(25.47663041945507,-1.3589646514160427,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark55(25.48911256215372,-0.83305675366225,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark55(25.577248251107207,-0.008024652861171155,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark55(25.580314376286637,-1.0127656535258165,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark55(25.598884415634586,-0.8657133818561042,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark55(25.645228034200613,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark55(25.6656563893535,-1.3254986976260312,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark55(2.5724065650492065,-0.21608498318452163,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark55(25.765434284658774,-1.123776099066422,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark55(2.582629320842524E-16,-1.5459395987444158E-7,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark55(25.873153794930055,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark55(-25.886982003621455,52.32800318723068,0.3657941097420405 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark55(26.02821152908888,-0.633413458087233,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark55(26.044284600801703,-2.7309889159471223E-8,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark55(26.057227118407376,-0.6379274368168659,0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark55(26.07980881882736,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark55(-26.132302673342764,-1.3914505761102905E-16,-1.0000000000000002 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark55(26.132826921203332,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark55(26.16751674020385,-0.610447002004789,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark55(26.184238229482062,-1.0908759297547075,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark55(26.283218651262338,-0.7166841829698221,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark55(26.315135196860666,-0.14673984874458768,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark55(26.324230882016764,-1.272722701696864,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark55(26.332265174114355,-1.4514011671052427,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark55(26.365444287401736,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark55(26.408907217007254,-0.11065753571261894,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark55(26.426139087124128,-0.7756349426530749,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark55(26.48607885562437,-0.5740229101704988,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark55(26.486491281892512,-0.1204303733179195,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark55(26.48832162328783,-1.3422740018965775,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark55(26.49176486964069,-0.3603855182210727,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark55(26.507906270625867,-0.9578702716787504,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark55(2.653978499964603,-0.5822958264269225,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark55(26.58961992036282,-0.8563172359892661,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark55(-26.67261173432632,-0.048919310339199495,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark55(2.6678331521978276,-0.12630845940949875,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark55(26.69840636951186,-0.6291152217360718,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark55(26.716530701710894,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark55(26.717217819868722,-0.12930746111735292,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark55(26.7388833908593,-0.628766581613196,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark55(26.77265403861614,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark55(26.78250409219713,-0.8767833116517583,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark55(26.849290348326576,-0.2424897382352924,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark55(26.85084637167656,-1.2268395583528526,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark55(26.885862531565202,-0.2647950188424215,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark55(26.888119040128686,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark55(26.892443576137666,-0.6998946959915457,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark55(2.690199239863175,-7.34297006950858E-5,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark55(26.925492095930483,-6.347834986216617E-10,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark55(27.017299050674055,-0.8415663583979902,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark55(27.018470627552716,-1.3817620082250184,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark55(27.039085496031007,-0.43542414838026045,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark55(27.08168396052092,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark55(27.0856094890499,-0.9105422232095037,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark55(27.09426282427413,-0.7212055241924122,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark55(-2.710505431213761E-20,-0.5096769642603254,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark55(27.109953063098715,-0.37198085006178183,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark55(27.13896207603132,-0.34379055702653716,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark55(27.218706656390808,-0.9900506498634902,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark55(27.245945617532424,-0.47449648406646305,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark55(27.25235573524145,-0.04138735790823426,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark55(27.28601146786471,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark55(27.305846193897025,-0.008882073240889823,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark55(27.31258769641029,-0.05430344318506031,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark55(27.38676744665012,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark55(-27.393111191955143,-1.4999999999999964,21.18315617264407 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark55(27.435896160239665,-1.2978595233260677,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark55(27.521463625984534,-5.661444172449287E-17,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark55(2.752722402800714,-0.07684219192591657,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark55(27.602482826959033,-0.5260193386654137,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark55(2.7602772342069812,-0.5825587024678613,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark55(27.609674863309834,-0.4820185151596049,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark55(27.62987878142662,-0.21046171831116045,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark55(27.690232509694027,-1.0807195344142428,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark55(2.7755575615628914E-17,-0.0035570124103601803,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark55(2.783851425343613,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark55(27.83951471739489,-0.6741643449070502,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark55(2.785392052678162,-0.25645110071844457,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark55(27.8687877494191,-1.4939464816449721,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark55(27.968798687219135,-0.2547283716879636,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark55(2.7991507438156873,-0.8409629611316518,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark55(28.032160490502292,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark55(28.035620490510723,-0.38892200169984115,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark55(2.8046097320263312,-1.138447620652379,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark55(28.066448081804992,-1.0856323952322668,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark55(28.085087509603603,-0.19268943196402835,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark55(28.099323545567245,-1.4443774739915902,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark55(28.113211876172045,-1.4999999999999467,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark55(28.15153253971703,-0.15471635577683573,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark55(-28.21595571297599,-0.7554537723052049,1.0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark55(28.217206139673237,-0.20356070640475316,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark55(2.8251150039267685,-1.1059002798009656,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark55(28.279811030436306,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark55(2.829139296233525,-0.004003432471076841,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark55(2.832098400931642,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark55(28.33933871717935,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark55(28.358454403665796,-0.6920900024086625,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark55(28.413806591753968,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark55(28.416452338212668,-0.16150281198960492,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark55(28.443059219162762,-0.8324695777253837,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark55(2.8446158482629045,-0.9584163027458459,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark55(28.455495534841674,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark55(28.4618227238104,-0.5161972056012097,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark55(28.488272155060656,-1.2124441412190576,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark55(28.63867239043961,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark55(28.67939355427285,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark55(28.68142889069,-1.0732097792053992,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark55(28.686751339126403,-0.6669183852857685,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark55(28.696682680896508,-1.217179075770403,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark55(28.69914265828737,-0.9922419758513139,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark55(28.722266487377084,-0.979083488651515,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark55(28.76137138275709,-1.4966056246301394,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark55(2.8777639802173147E-15,-1.343747609557571,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark55(28.81082529626306,-0.6110832431989621,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark55(-28.834205684523866,-1.4999999999999991,72.93791879572504 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark55(2.8843862341115525,-1.3299209635578535,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark55(28.86609885146973,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark55(28.87252285574302,-0.5890360714442551,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark55(28.893211452361925,-1.0956387468900786,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark55(28.921481610996455,-4.777398399273261E-9,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark55(2.892424108199208,-1.1739237397589226,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark55(28.939489176936377,-1.3994387820440732,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark55(28.94368909508168,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark55(28.960197030479076,-0.7808508351114,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark55(29.025352994430975,-1.1744943526450546,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark55(29.06668710235826,-0.7974588450544129,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark55(2.9086850504013246,-1.5379423673328814E-8,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark55(2.9131175620996674,-0.017556835836854683,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark55(2.916998106243032,-0.30573695066271167,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark55(29.17947169015062,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark55(29.197974808974568,-1.0974734890439297,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark55(29.213994370917863,-0.6895632493328592,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark55(29.22276821553712,-1.1631820520834475,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark55(29.23892118793549,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark55(29.258278180299072,-0.7130508997530645,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark55(29.274419084712598,-0.11388210695372103,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark55(29.282379522000753,-1.2110781984307462,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark55(-29.364332070602757,-0.7792611416207327,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark55(29.378825848528436,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark55(29.41600176557183,-0.664354258911873,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark55(29.57558853881241,-1.3188610940666896,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark55(29.59202100095802,-0.5716871671244834,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark55(29.63777382170784,-1.1820956481124698,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark55(29.665130284724285,-1.1326476910586205,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark55(29.672532870595976,-1.4999997656165884,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark55(29.680421366653214,-0.36051761033124063,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark55(-29.70429582607572,-0.3746631763204499,-1.0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark55(29.724960390245087,-0.8427895364922742,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark55(29.758296600273553,-0.23466243919175156,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark55(29.767391538505166,-1.3291981870786174,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark55(2.978359723932016,-0.6886471371230403,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark55(29.786504245837705,-0.23076482460899794,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark55(29.801818396528233,-0.3062522380628745,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark55(29.80823008503043,-0.30077673640612357,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark55(29.811340885016698,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark55(29.828305024127985,-0.5777627407678914,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark55(29.863522955152142,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark55(29.87028051373742,-0.23515150016759456,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark55(30.01116559253157,-1.386978979092012,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark55(30.036770884710734,-1.3486587054270736,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark55(30.055864431248494,-1.4905825418546557,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark55(30.07472135000978,-1.4999999999256572,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark55(-30.074900895863415,-1.499999999945201,-0.810481656547267 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark55(30.144587761928108,-0.09649352058409866,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark55(30.158469900270745,-0.9292786577724321,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark55(30.233561618013482,-0.09717148640514273,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark55(30.258526911623942,-0.3396460917926394,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark55(3.0303389039506745E-10,-0.7775190469477374,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark55(30.35038548500466,-1.0097590888623884,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark55(30.376850091693655,-0.22585176700333953,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark55(30.38579403745345,-1.4929221566913624,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark55(30.395090615788803,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark55(30.477797352891855,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark55(-30.481822286081666,-0.3664688300124004,36.0992111304943 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark55(30.506637133228963,-0.14258804698357608,0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark55(30.5326578142935,-1.4770937023133497,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark55(30.53726639242739,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark55(30.57044524544699,-1.4999999999999778,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark55(30.60504955542891,-0.5822262321458364,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark55(30.605087982086616,-1.3377798345087233,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark55(30.605091331941495,-0.20176799570032777,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark55(30.630375320735332,-1.0295481496387706,0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark55(30.63504870604406,-1.4592679867676175,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark55(30.674462427857975,-1.3341215762646836,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark55(30.78574637531716,-1.1348850245372202,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark55(30.815272880431365,-0.010137083191743557,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark55(3.0828565302886863,-0.6717209985398824,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark55(-30.86833737788494,-0.00820226595460352,-0.7734592837990151 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark55(3.094548099506381,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark55(30.95896697237463,-0.5736089030551963,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark55(31.01938458383424,-7.590653327158707E-7,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark55(3.1038887177610803,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark55(31.04882533333776,-1.3085963886840004,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark55(31.062239199103544,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark55(31.07508696556696,-1.3141824916176752,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark55(31.082300182604452,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark55(31.313636546850553,-0.2265434194728739,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark55(31.395507228745796,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark55(31.447670769453115,-1.4999999997049946,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark55(31.493902580464418,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark55(31.500557094862174,-1.4999999999781806,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark55(31.51470571837529,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark55(31.524584226861805,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark55(-31.559880324703002,-1.4999999999999905,1.0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark55(31.565982864802876,-0.21327776451675778,0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark55(31.569896532257644,-0.187589064584472,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark55(31.582301839142787,-0.5047491657786782,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark55(31.588883620865886,-0.9156915417598128,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark55(31.648836799672466,-0.5879949234388429,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark55(31.657402501960206,-0.7904580637810248,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark55(31.680531924672806,-0.9908408902972976,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark55(31.686665101646184,-1.0663841017781035,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark55(31.696882123027677,-1.2660053139348393,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark55(31.71438533345966,-1.006053114237221,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark55(31.73472655440534,-0.4654225959654674,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark55(31.791286454287473,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark55(31.801384878122946,-1.4882267753317513,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark55(31.857933277926378,-0.9235064179285075,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark55(3.1863219324055336,-1.1846809730111403,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark55(31.870460764596473,-0.0010660162389498629,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark55(31.927160671197072,-0.80121643466193,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark55(31.93985336981615,-0.2204767002155421,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark55(31.945604550548587,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark55(31.954959581287785,-0.9645617117047154,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark55(31.978206695717944,-46.74318657579908,56.12563052953442 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark55(32.009365348517576,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark55(32.0140393596854,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark55(32.06961891964792,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark55(32.07082139822703,-1.3047657342217605,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark55(3.207814626649935,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark55(-32.11491722903621,-1.4971235704200143,-1.0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark55(32.12207660210514,-0.02641307868191456,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark55(32.13617808131782,-0.700570682452676,0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark55(32.146298957219756,-0.4319695390002636,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark55(32.17759946197544,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark55(-32.17921874443082,-0.6247917427128584,0.9966097961246936 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark55(32.214221201362875,-0.8917423698239437,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark55(32.34230747086118,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark55(32.3464878859338,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark55(32.40394448460496,-3.485178500281646E-5,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark55(32.408036066970936,-0.3884126869343757,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark55(32.46971281202863,-1.485049461561479,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark55(32.486294724625026,-0.7941588040416043,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark55(32.5038427121024,-1.4279346098589656,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark55(32.507800912158686,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark55(3.2515991030638123,-1.4008045363234198,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark55(3.2520841531301743,-0.6161953054338423,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark55(3.2529842236821906,-0.39808805515898804,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark55(32.55106021999791,-1.0879466925381465,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark55(32.574693951484804,-0.5346176844520206,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark55(32.670529369643106,-1.2601244863949717,0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark55(32.67944044291459,-0.6201851145791148,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark55(32.68362822815027,-1.2462127064444957,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark55(32.686075913787846,-0.008471500990879122,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark55(32.744306468455974,-0.631843378871805,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark55(32.759018345143176,-1.0762347431783006,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark55(32.76151637009664,-0.1931830251813853,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark55(32.809374081948306,-1.271622002212073,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark55(32.81096275471512,-0.97858677266691,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark55(-32.8386354039611,-1.430147530287809,-1.0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark55(32.91540616083185,-0.10402577548580316,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark55(32.93659142197431,-0.5849672811895061,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark55(32.93690817393104,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark55(32.97120302067674,-0.7123578625371052,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark55(-33.01096070899042,-0.14895364065049418,1.0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark55(33.01210487739154,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark55(3.303766656857821,-0.10958379311458799,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark55(-33.04488145976967,-0.8183805112307372,87.84935527787226 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark55(33.05075882549389,-1.3335897661791625E-9,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark55(33.053750811246246,-1.438877264268153,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark55(33.09710955752654,-0.061959093409516885,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark55(33.13515828093455,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark55(33.14657337744909,-1.0662993915096508,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark55(33.222825076511725,-1.2668176065641745,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark55(3.3236032447031363,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark55(33.27215985019371,-1.499999999374134,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark55(33.29253657803381,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark55(33.311294018357074,-0.6633448934536951,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark55(33.31360031567337,-0.3339900245720322,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark55(33.35056218775733,-0.5494106910477727,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark55(33.37093787581392,-1.1501394825765754,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark55(33.41834059887614,-1.4864728197337627,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark55(33.424336998235155,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark55(33.432611576857056,-1.401838602474939,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark55(33.43341985348598,-1.7412997629369407E-9,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark55(33.43565198067975,-0.2870714729308732,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark55(33.55744746943762,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark55(3.3582460291030554,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark55(3.3642159915907186,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark55(3.365264030970039,-1.3445213391155733,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark55(33.691316722056634,-1.4606703886111856,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark55(33.694240517518125,-0.2958293165709267,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark55(33.715773049816335,-0.7661125742728103,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark55(33.765489297015144,-0.9219573488856013,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark55(33.78363488672472,-0.2086775632469998,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark55(33.81914623864566,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark55(33.85623107231817,-1.29244827054886,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark55(33.865924844973854,-1.4960737652911384,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark55(33.97524450826693,-0.13132018521322275,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark55(34.066017044341436,-0.7663281707877463,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark55(34.07090146458091,-0.9855131157148878,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark55(34.23451096568798,-0.016909591694338033,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark55(34.28016222542155,-1.4999999999998792,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark55(34.34877325877065,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark55(34.34998996002783,-1.4999999999496212,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark55(34.36279891643946,-1.0110572088104064,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark55(34.37841513431573,-1.3673278095918868,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark55(34.489966158324705,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark55(34.53331249926656,-0.48139077001155217,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark55(34.608621667402616,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark55(34.60959180939696,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark55(34.62428306023702,-0.8385241138567472,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark55(34.63619672048438,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark55(34.65494584833954,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark55(34.68879446000531,-0.6651491590517331,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark55(-3.469446951953614E-18,-0.07452729392193444,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark55(-3.469446951953614E-18,-0.5757077696818849,-0.9976074137693984 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark55(34.711602552184104,-0.9837674003453276,0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark55(3.472302672668505,-5.8076500063325295E-6,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark55(34.733654687755546,-0.03220885992849753,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark55(34.744718552781706,-0.5284288384198241,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark55(34.75830606556406,-0.991398340760032,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark55(3.491797524995107,-1.4116472254333752,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark55(34.92429291059585,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark55(34.96616692777557,-1.1268635232958566,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark55(35.016911277982764,-0.883226240150446,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark55(35.02556556301391,-0.9343022102251437,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark55(35.03320122431296,-0.19986256546845915,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark55(35.081016500431794,-1.4999999999683504,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark55(-35.15554970205925,-1.4586771855012988,-0.5654227560410219 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark55(35.15584263521956,-1.2493922530591024,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark55(35.19599323982328,-0.5770340736378756,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark55(3.527110379916593,-1.1333171154273627,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark55(35.27204007081137,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark55(35.387748477924184,-0.7912235520460276,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark55(35.422637897013786,-2.3870107826914908E-8,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark55(35.521858751152735,-0.7894355750879427,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark55(3.552713678800501E-15,-0.23947469886337647,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark55(3.552713678800501E-15,-0.38088121377700723,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark55(3.552713678800501E-15,-1.2220569526406078,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark55(-35.55680342697185,-0.5374487876952947,0.8077228426703414 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark55(35.55712092596588,-1.2339773378034151,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark55(35.56922721103419,-1.003145288666182,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark55(35.69499151154373,-0.2818095812298953,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark55(35.70759732475682,-0.38094506581114995,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark55(35.755567875710476,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark55(35.77233652201923,-1.3099397028636588,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark55(35.78387747421357,-1.4683204880545748,0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark55(35.79795741265269,-1.2885857938762797,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark55(35.81235513219437,-1.1809501620639224,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark55(35.813397582780624,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark55(35.8846538321481,-0.0036668007268307588,0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark55(35.905127099909684,-0.7294809337058505,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark55(35.97351233542756,23.799347658181745,-52.44061837267105 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark55(36.05896098208072,-0.05995326197785289,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark55(36.08910186773832,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark55(36.10103163854533,-5.011993353240499E-9,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark55(36.11924212421266,-5.1310068285174154E-6,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark55(36.15741095839519,-0.17521243949908616,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark55(36.16247214907895,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark55(36.191710956527686,-1.3749826055181131,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark55(36.28046117311109,-0.3461748593824798,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark55(36.29623652261361,-0.0787250978866495,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark55(36.31583132178727,-0.9008801843254162,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark55(36.33741716989048,-4.489926247668022E-16,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark55(36.34081562885858,-1.1401448973726773,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark55(36.38522145742981,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark55(-36.46493553596566,-6.636515412601907E-4,0.05754782008605737 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark55(3.6477751573161834,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark55(36.48359314457937,-0.5131528641253125,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark55(36.505401996567144,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark55(3.652374724688471,-0.5108150682888704,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark55(36.538933569909005,-0.3712141794286481,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark55(36.5860147437549,-0.4933002218216284,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark55(3.6627053301392394,-1.4516492150644775,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark55(36.6502543557466,-1.4417746993160248,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark55(36.65222266910956,-0.5374475928747972,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark55(36.69138546900791,-0.043625608684170925,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark55(36.696747487620314,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark55(36.73949962308852,-0.11173783857778052,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark55(36.74666268977278,-0.517990684926914,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark55(36.82029433070905,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark55(36.83694576556516,-1.237966618538924,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark55(36.84239984569253,-0.38360368239501774,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark55(-36.84915602370011,-0.8067580233214962,-2567.6677127729954 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark55(36.85504101826705,-0.3758139606283595,0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark55(3.6856093326163943,-1.4542190071526306,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark55(36.90865132582296,-9.574509849716861E-4,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark55(36.932559359859304,-0.20761456376337994,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark55(37.016982867766146,-0.37843990752270906,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark55(-37.03761546461808,-1.4999999999999991,38.85861814206015 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark55(37.083915699500196,-1.865263823304303E-9,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark55(37.11910931648574,-0.30810698930079083,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark55(37.127534041793155,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark55(37.12843408282035,-0.726322911194341,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark55(37.16098137679904,-0.5093829035976212,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark55(37.21028868589994,-0.44310197812062446,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark55(37.30977140274449,-0.17473434489710216,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark55(37.32162596790417,-3.4883160779585154,22.069818711453436 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark55(37.3587632822165,-0.8122261126968198,0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark55(-37.38570038403318,-0.4131968856241604,1.0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark55(37.38787131334985,-0.3599268187241602,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark55(37.418564277299396,-0.05276923492826047,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark55(37.43520907062079,-1.844547173946661E-8,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark55(37.44439069684213,-0.9306333344608582,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark55(37.447749495506855,-1.191580033317436,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark55(-37.46702084616709,-0.3550047225827154,1.0000000000011378 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark55(37.48818026965536,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark55(37.54535749815912,-0.08171190248284052,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark55(3.7547615102331475,-0.2648899783735485,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark55(37.575857190543616,-0.14639106393212975,0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark55(37.60261058295049,-0.8203066264890717,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark55(37.60485008206092,-0.4279271975944918,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark55(37.647253931127864,-0.47229077450415957,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark55(3.7703812744862546,-0.8708438856446783,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark55(-37.72853966740528,-56.14153527020056,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark55(37.73333926754998,-1.1011362154661877,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark55(37.800466757938125,-0.0034572349540495768,0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark55(3.781223451693336,-0.6288222381396789,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark55(37.81757764037539,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark55(37.82035129070633,-0.2781823872174112,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark55(37.87603224756249,-1.2796486092028945,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark55(37.91350864513195,-1.2836141413739304,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark55(37.91504172931266,-0.5079633544585445,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark55(37.92239069990103,-0.9211363919744073,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark55(37.927267603465,-1.1134564115745071,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark55(-37.96511227920932,-4.1328442601097214E-15,0.44500720903737423 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark55(37.98037437053566,-0.3033783007838611,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark55(37.98263360683933,-0.23084685864380822,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark55(38.04635794881922,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark55(38.059112686744214,-0.6795222555310237,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark55(38.0753967719664,-0.8044487996298767,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark55(38.14710575148846,-0.7799466486135664,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark55(38.24587704148996,-1.160324167014382,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark55(38.276287937170935,-0.10222497290043905,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark55(38.318792332604545,-0.11373724902132665,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark55(38.35778951048352,-0.48723769937291506,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark55(38.401292843907015,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark55(38.44824551940951,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark55(3.846482024832472,-0.41889859711088206,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark55(38.47224082231948,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark55(38.53315827588975,-1.4581909104095443,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark55(3.8538689267539468,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark55(38.5622585068152,-0.97799264652047,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark55(38.576454730627816,-1.2974327190739197,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark55(38.606385250307596,-0.981565979570842,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark55(38.607595391425605,-0.05223676733493075,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark55(3.8616525580570453,-0.23816901873337137,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark55(38.63197568026479,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark55(38.64044990110503,-1.4876243117106638,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark55(38.654013857972984,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark55(38.657540698775925,-3.4342436137243853E-6,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark55(38.691341670122625,-1.1357642124991032,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark55(38.75749537768016,-0.13697883078453457,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark55(38.76059863444959,-0.6313975279089945,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark55(38.785578410873285,-0.9062336488957357,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark55(38.7956359329483,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark55(38.811890120042236,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark55(38.81362585194783,-1.4456924486018008,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark55(3.8839030571802198,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark55(38.84035395620208,-1.2717363965892723,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark55(3.8868605372583573,-1.0313430422461023,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark55(-38.98753282988716,-0.38916337603059525,100.0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark55(39.052990431645725,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark55(39.13979916810922,-1.24310849200387,0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark55(39.15835800334699,-0.17056258941977226,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark55(39.160312350973676,-0.6182165705484847,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark55(39.17012821827152,-0.4822498362210603,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark55(39.21128555180524,-2.820396567160862E-7,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark55(39.24401379919604,-1.1717396817285293,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark55(39.342031757066394,-0.808795794815012,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark55(39.35351625911927,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark55(39.356915122929394,-1.4407064768221913,0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark55(39.40003525192947,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark55(39.42963127231798,-0.5002612198069298,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark55(39.44928277399228,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark55(39.45192464851036,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark55(39.45521962581472,-0.44092681948132695,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark55(39.46324317192479,-0.0011779774618861927,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark55(39.47433891875016,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark55(39.52128378462316,-1.3284980105531163,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark55(39.545425076094375,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark55(-39.58773513381372,-0.9495644864892299,68.18248044855021 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark55(39.61425828760059,-1.0783765239552103,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark55(39.67479143551168,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark55(39.67684527386689,-1.237786739791403,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark55(39.70448924522759,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark55(39.719563727657004,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark55(39.71997638047529,-0.7542783140456493,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark55(3.9762833390536834,-1.4296578723868372,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark55(-39.86736604444262,-0.4217013574387899,-1.0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark55(39.88841567930049,-1.226986751539112,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark55(39.91248395329103,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark55(39.97935471091537,-0.02243810206844654,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark55(40.029875366552886,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark55(40.04461472928608,-1.2182987315250813,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark55(40.061889925339564,-5.295714806971271E-10,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark55(40.070330537793524,-0.6952503494517543,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark55(40.10551501126811,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark55(40.16622549854986,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark55(40.21281812197054,-1.2754918314208297,0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark55(40.22495046536781,-0.8571663974135394,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark55(40.28057751564336,-0.3152257680821182,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark55(-40.2859120900033,-0.009836114202006937,0.6063356905963574 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark55(40.348725761946454,-3.5678463267254E-8,0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark55(40.36909263339652,-0.7142406351092367,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark55(-40.40437345532179,-0.26814857033019457,0.0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark55(40.43193077090791,-0.1287805395144085,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark55(40.44711874572249,-0.7078831530919939,0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark55(40.45405090301585,-1.4564397639314564,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark55(40.457273666570856,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark55(40.512219253995404,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark55(40.52901164777592,-1.1549902446846687,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark55(40.53383646909916,-0.967963043353727,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark55(40.53699010997494,-0.5960615818191428,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark55(40.56204973013484,-0.5841959610410814,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark55(40.62299625497861,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark55(40.62459030625081,-0.3630226696224952,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark55(40.630284251634066,-0.28530599082919217,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark55(40.63902781693875,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark55(40.722561082507994,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark55(40.76638681373723,-1.2241209146540217,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark55(40.767756994007755,-0.26573345201796705,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark55(40.79495737115072,-0.7764620241043999,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark55(40.81116132244648,-0.6524362194198925,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark55(40.865163041971826,-1.011589593659367,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark55(40.87105339210916,-0.362838071422388,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark55(40.88598710915912,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark55(40.88976281859621,-0.29147779783248895,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark55(40.9224822836305,-1.3847177847627892,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark55(40.96810482328986,-6.154899997540729E-10,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark55(4.101087169382623,-1.0344901143680971,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark55(41.02165766842869,-0.08617358015715304,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark55(41.034958862402256,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark55(4.106511633659622,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark55(41.06625364868336,-1.1971116046088923,0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark55(41.101815997913405,-0.16016093659520791,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark55(4.113493319079311,-0.21099249671049553,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark55(41.286899799990636,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark55(41.287984037023364,-0.05908635495311998,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark55(41.29159680967214,-0.9831107598162134,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark55(41.29863199314451,-1.1420770702029301,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark55(41.32899353841787,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark55(41.350609792155794,-0.4725562482305916,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark55(41.382697936308155,-2.9484890404875264E-4,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark55(4.139413528992037,-1.4999999986302188,0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark55(41.454360763669385,-1.4683834922488959,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark55(41.481434520323546,-0.17096454932652883,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark55(41.491750174531006,-0.8581423830700268,0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark55(4.149539902412021,-1.486820295934719,0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark55(41.51912071846995,-0.3983035920103317,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark55(41.5288880882635,-1.4576689011157722,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark55(41.5479864449087,-0.21672969689818444,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark55(41.553698275881125,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark55(41.58743537978583,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark55(41.615576708506424,-1.4999999999999787,0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark55(41.63354607828538,-1.3598077064849559,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark55(41.64152539798147,-0.8019121647009371,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark55(41.65321121581988,-1.499986824308159,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark55(41.65778080310241,-0.15266087928821648,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark55(41.70093823917969,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark55(4.172524089802948,-1.3649371841740026,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark55(41.761268418965564,-0.9775310987260513,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark55(41.78087651758645,-0.6917606481029308,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark55(41.80169763100049,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark55(41.83267207909941,-8.351256524084943E-10,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark55(41.882200293305885,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark55(41.89609600533785,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark55(41.94004836963383,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark55(41.95099263921355,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark55(41.96268029678675,-5.318413981417452E-4,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark55(41.975439150862286,-0.8520238893584748,0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark55(42.05858726286888,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark55(42.078083468150275,-3.6924041949992737E-9,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark55(42.13368688764521,-1.0038265480678064,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark55(-42.23024963526168,-0.1855675767256721,0.0137729372128007 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark55(4.235063303166854,-0.7571743344686865,0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark55(42.36299118308388,-0.28773301204341717,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark55(42.39449496661453,-1.4547563697351593,0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark55(4.240811755182605,-0.027933309894760505,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark55(42.41804519337512,-0.22006416187340638,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark55(-42.44119989466357,-0.7656905247438326,0.3626288567642854 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark55(42.44380433938289,-0.29215991601174096,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark55(42.45059348689105,-1.2514851251570471,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark55(42.4670082311377,-0.8915300795260492,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark55(4.250860793800058,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark55(4.251387802541553,-0.40678702339879647,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark55(42.53328138150877,-0.8185270604784876,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark55(42.54672611209169,-2.908874168597418E-8,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark55(42.55359870757158,-1.2964889116982725,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark55(-42.558208529146995,-0.5521978711024552,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark55(42.5656800851464,-0.9611670297271875,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark55(-42.581422510341426,-0.32764686929682796,-31.096445109285753 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark55(42.63669388580999,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark55(42.638036516587675,-0.8902851820812714,0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark55(42.65007202970501,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark55(4.2733483388018705,-0.2318583129538645,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark55(-42.80833190622124,-1.4999999996818294,-25.240199093068966 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark55(4.2828146308048884,-1.1728415060112269E-9,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark55(42.85985705429359,-1.1159901699382384,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark55(42.875914344850536,-0.2661576788144342,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark55(42.89920379218694,-1.2219162593628123,0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark55(42.93124105212084,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark55(42.94289098177201,-1.4868091582256397,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark55(42.982224366876125,-0.6396632081509495,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark55(4.30886769857031,-8.088772915288716E-4,0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark55(43.09113214429502,-0.27933334112810565,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark55(43.10014961208795,-0.11442787850475433,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark55(43.11438139655857,-1.0029518093028749,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark55(43.15644466133176,-0.30352109435698993,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark55(43.22212798127097,-1.1833350712054909,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark55(43.23309606846521,-6.412330377249436E-5,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark55(43.265364719531846,-0.8862484629303535,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark55(43.277070557597845,-0.0798845884488294,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark55(43.344679076971275,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark55(43.381767063177875,-0.06466365903845295,0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark55(43.40614813094416,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark55(43.424957414732596,-0.05549944320243577,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark55(43.45067794936065,-0.014494142425320433,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark55(43.45169508608008,-1.1352183667648763,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark55(43.45259018398434,-0.2019190654077363,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark55(-43.50334327193517,-0.5137172613178245,-0.01042315111258539 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark55(43.55422680239954,-1.3069559903805583,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark55(43.59383989473288,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark55(4.363872600604665,-1.196643712480821,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark55(43.651315678959804,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark55(43.68049326291839,-0.11843387153708207,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark55(43.723886643500435,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark55(43.7687221731324,-1.3614583666619655,0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark55(4.381602036843161,-1.4999999998742404,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark55(4.382043431361785,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark55(43.823116685563036,-1.054341934251226,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark55(43.870223615952,99.42859804837764,-85.14966313115218 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark55(44.00930809808659,-1.2274625867171418,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark55(44.017017882627385,-0.1558113966516581,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark55(44.03191869421826,-1.0851100022710671,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark55(44.0376217523183,-0.8374977489343678,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark55(44.17329387563835,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark55(44.19801222724823,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark55(-44.24009014674952,-0.9826965018937812,-1.0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark55(44.24212729999811,-1.259864985318526,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark55(4.428308798864194,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark55(-4.42882466910917,-1.4995064074236006,-0.6962436763816134 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark55(-44.31566606700064,-1.2300546608231526,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark55(44.33571522822261,-0.6042282570662133,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark55(44.337933239238424,-0.2486974722561235,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark55(44.3682630473306,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark55(44.38159905681403,-0.17254664675716697,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark55(44.3871610239857,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark55(44.39425657013706,-0.6496981200939815,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark55(44.406489073732686,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark55(4.440892098500626E-16,-1.210211708231945,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark55(4.440892098500626E-16,-1.2960634665175381,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark55(4.440892098500626E-16,-1.309372504760914,0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark55(4.440892098500626E-16,-1.497681800198087,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark55(44.43662380033899,-0.18359075678596193,0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark55(44.44517495335242,-1.3432330830762518,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark55(44.47378424693514,-0.4214630581553429,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark55(44.5057153460445,-1.4471510208684117,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark55(44.51609280845424,-1.2783427155290736,0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark55(44.52258399362529,-1.0971951122576815,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark55(44.56042603372778,-0.38702200394467556,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark55(44.57665394646553,-0.6279626028425698,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark55(4.458834672120233,-0.2511034693481211,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark55(44.60360757271468,-0.4670204867586388,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark55(4.46785075255076,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark55(44.72336065990704,-0.38952844055605274,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark55(44.745299997373884,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark55(4.47552796365969,-7.71319272447302E-8,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark55(44.78950353253154,-0.05652514179340265,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark55(44.80180883740721,-1.4384030825644984,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark55(44.80899962562014,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark55(44.89458461695574,-1.2925485270460797,0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark55(44.89765315268599,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark55(44.92703681113692,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark55(44.947055612653294,-0.08788686451730188,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark55(44.964323268159774,-1.2547649911716547,0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark55(44.971446292095266,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark55(4.497178917048375,-0.3865644723689403,0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark55(-44.994391406667354,-1.4999999999999998,28.336643527188286 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark55(44.99733804929363,-0.31396598003778564,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark55(45.048111114158985,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark55(45.09253570520866,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark55(45.1502491422697,-1.2003409875312894,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark55(45.210451676443455,-7.51071686465811E-10,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark55(45.21069594345579,-0.1301749624447197,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark55(45.29335794554913,-1.2821655128312273,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark55(45.344266936683624,-0.5843001365847318,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark55(45.36616251338606,-0.9430904687327057,0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark55(45.381044862742016,-1.154823679556083,0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark55(45.3962637085766,-0.27576490006813614,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark55(45.4432260525235,-0.297751220036103,0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark55(45.54164056637586,-1.4078539372145613,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark55(4.563574253339937,-0.2260690906283126,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark55(4.564204310845128,-0.18969020820271965,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark55(45.66139896294828,-0.7788398902131881,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark55(45.75688118190874,73.77848851482699,-55.128701037479246 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark55(45.764765742338625,-0.9738675944424138,0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark55(45.77887430443204,-0.036816271522890354,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark55(45.78881349226603,-0.14824737128447474,0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark55(45.79856910167185,-0.1352014750469867,0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark55(4.5800752634807225,-0.29005468355276776,0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark55(45.83364713678043,-0.13456985261390741,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark55(-45.83807866790172,-0.9834026816865041,-84.11174277658742 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark55(45.83999690083847,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark55(45.91985778234903,-0.08302443207280419,0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark55(45.92515342984791,-0.021195781584641082,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark55(45.954574094768326,-0.30869907739940716,0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark55(45.97377325736682,-7.20513345261981E-6,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark55(46.07823847961138,-0.2716721430218234,0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark55(4.614278482248029,-1.4999999999435187,0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark55(46.16011928202028,-0.3938771548404345,0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark55(46.18968028548383,-0.20357930553206938,0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark55(46.202071630297496,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark55(-46.2745522960358,-0.18912116304322146,1.0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark55(46.276174454979746,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark55(46.28627268765277,-1.040522215255562,0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark55(46.37389864786545,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark55(4.638392992141542,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark55(46.3954886449751,-0.652448293324774,0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark55(46.46939511908511,-1.2103775168682596,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark55(46.505708355750166,-4.0552712922893566E-10,0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark55(-46.51350643521562,-1.1086144264514917,1.0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark55(46.57770937056597,-0.8007941312010685,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark55(46.63752244032395,-0.23197547087051407,0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark55(46.67397323566246,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark55(46.69096982669444,-0.36205100389729017,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark55(46.78115050577616,-1.1744711829135672,0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark55(46.83830503399071,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark55(46.83860259596548,-0.7546961168050785,0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark55(46.84910520368794,-0.41776240971796597,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark55(46.88163234442459,-0.9589093221216229,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark55(46.927519839113046,-0.8795646192992734,0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark55(47.00394723523786,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark55(47.0215588393053,-1.3194247133277752,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark55(-47.083436287280804,-1.4999999999999982,32.5228857054703 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark55(47.10853542295709,-0.5658544334832438,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark55(47.11142021776788,-5.134180078476934E-8,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark55(47.13886803466835,-1.0637198099191494,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark55(47.17648807745266,-0.8545732889746489,0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark55(47.225832809539185,-0.21137057429234574,0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark55(47.276249849035565,-0.9761285433067881,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark55(47.40144398415106,-0.8248560634678102,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark55(47.46867117952755,-0.08828374252712545,0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark55(4.747699046413416,-0.5572911133294303,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark55(47.48575624953901,-0.38529153093130153,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark55(47.50033881156807,-0.4767840834678907,0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark55(47.542478231306,-0.13987335970051434,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark55(4.754957244104574,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark55(47.578267266090954,-0.9030496325161175,0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark55(47.582172867891046,-0.8937491043409267,0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark55(47.597990338138345,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark55(47.609217242557875,-0.26728813633987136,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark55(-47.61447549173244,-1.324620990273944,-10.515686001123044 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark55(47.618293220387905,-2.2031040516588943E-4,0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark55(47.700649181948506,-1.2332093823264376,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark55(47.75510119393692,-0.19668493501066742,0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark55(47.76367685227317,-0.5060535719634425,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark55(47.79117148344585,-0.17697582967791098,0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark55(47.798708524324724,-0.5775540283642908,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark55(47.851852991367515,-0.7371734728514934,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark55(47.86654375710495,-0.1592346183089859,0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark55(4.7927269099292715,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark55(47.96334447045737,-0.11966275649888347,0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark55(4.7969073846806936,-1.4999999958323338,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark55(47.98177647171174,-0.9135888204528533,0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark55(48.011103439605165,-1.471968795258345,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark55(48.02164532629709,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark55(-48.06260929552351,-0.803821572676791,-1.0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark55(4.809613135134484,-0.763410147173488,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark55(-48.15528035607882,-0.003624044302032406,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark55(48.16712203309831,-0.010922684487410628,0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark55(48.16856677979621,-0.8175644857567939,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark55(48.195809220200715,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark55(48.20974367093464,-1.3045295497715585,0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark55(48.21462329382491,-1.6123384556882332E-8,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark55(48.219114683911215,-1.3426993590974363,0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark55(48.23251184723978,-0.6662776904658042,0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark55(48.251671090461485,-0.10838687211364273,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark55(48.25827365761961,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark55(48.35110000167398,-0.7770145580872203,0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark55(48.4199603615256,-0.36080587683602516,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark55(48.449430516778534,-1.3698139024777816,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark55(48.45014524988386,-1.3152706990085603,0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark55(48.50804028179053,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark55(48.5846004149773,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark55(-48.614682701934406,-0.35242258924514,0.9999999993749389 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark55(48.65072348255546,-0.024408642065490507,0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark55(48.658305855094454,-0.0872511618080575,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark55(48.69979423422271,-0.4470821486904981,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark55(48.7026589629941,-1.0525621716217943,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark55(48.82236354717181,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark55(48.87631399367236,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark55(48.938835706258985,-1.0860116865590346,0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark55(4.894521807284264,-1.1007632489655492,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark55(48.96483397076282,-0.5548039586745945,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark55(48.986875335738944,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark55(49.014657756410365,-9.018364401647888E-9,0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark55(49.04610312587913,-1.1622989215385533,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark55(-4.906769983662016,-1.3052558451398113,88.50462354640248 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark55(49.14427944162131,-0.067051271647534,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark55(4.919487757095938,-0.9951953138298483,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark55(4.921650863414158,-1.1168829634092665,0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark55(4.928609413534708,-1.3844330816714783,0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark55(49.29647218531605,-0.00395832421140474,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark55(-4.930380657631324E-32,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark55(49.31993962203016,-0.4923590418748049,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark55(49.3416149388529,-0.6657858782952744,0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark55(49.34162063836172,-1.4968742843637757,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark55(49.38147164319233,-0.543376575230397,0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark55(49.39984493083724,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark55(49.537192339541974,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark55(49.563801020688345,-1.2275187860790666,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark55(49.571851591860764,-0.13695650733238685,0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark55(49.58808371103126,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark55(49.71927740328413,-1.4263139602786596,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark55(49.73666941597983,-1.2153004953209035,0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark55(49.738168647627994,-0.2740256709162274,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark55(4.9766722471503755,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark55(49.80401250294341,-0.4815734711274766,0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark55(49.819320928150034,-0.7242578806614688,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark55(49.886386611587845,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark55(49.94136178444481,-0.13748958623941318,0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark55(49.943040813432646,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark55(49.98349983760846,-0.9626804020507373,0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark55(5.001930618609496,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark55(50.03094488387951,-0.8108214533418874,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark55(50.071296291124646,-0.12736455987716244,0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark55(5.007290864532923,-0.17360487355468252,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark55(50.10449356604282,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark55(50.10917322889975,-1.1962133313828076,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark55(50.124438507054606,-0.676441666245551,0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark55(50.14759261088466,-4.7780131917179904E-5,0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark55(5.01484834912489,-0.37455165063202855,0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark55(50.19411530016521,-0.6673547750888105,0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark55(50.194480948429685,-1.069606014481331,0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark55(50.20442559477413,-2.9514192090454597E-7,0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark55(50.274257242102976,-1.1776948965319392,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark55(50.27479281940509,-0.10796116395464939,0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark55(50.31468369386675,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark55(50.34614401188978,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark55(50.382760949290684,-0.190133684129826,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark55(50.47855609708992,-0.7588360604314532,0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark55(50.49777266041161,-0.02617329130735868,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark55(50.50150634097116,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark55(50.53682170927064,-1.493910944269517,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark55(50.629857690831656,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark55(50.659230322186346,-1.0651557338019622,0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark55(50.66953188021612,-0.19098069291032638,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark55(50.67171175271068,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark55(50.69105297184481,-1.4999998641011494,0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark55(-50.69308959097574,-0.9773838819766709,95.1331582611746 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark55(50.74930006646166,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark55(50.83836669661194,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark55(50.89651410162671,-0.4181559612804606,0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark55(50.90252125793947,-0.02558644612307326,0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark55(50.917522568729,-0.604859986405593,0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark55(51.03448114211388,-0.22089788462235838,0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark55(51.03532055571105,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark55(51.03836714434575,-0.18469275852202824,0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark55(51.05631416216207,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark55(51.06669449267744,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark55(51.08359062690525,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark55(51.11588230439526,92.45165450468448,-28.1438531345144 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark55(51.12502468106338,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark55(5.113251709951887,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark55(51.17890858424805,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark55(-51.21977813014893,-0.04578233466684267,31.895442091317904 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark55(5.124309150485871,-0.9181298627128385,0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark55(51.25131364167652,-0.9389059566381134,0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark55(51.322166951633875,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark55(51.36600034015032,-0.23105528033976416,0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark55(51.39087286543247,-1.1846677018300795,0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark55(51.40287807518277,-0.25705286626510615,0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark55(51.415374096206875,-0.5839869788105645,0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark55(51.42042016815216,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark55(51.447327899781726,-1.0021442683915538,0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark55(51.466368071720815,-0.31883310299645107,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark55(51.55593009894548,-1.341811075558907,0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark55(51.68597782017997,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark55(51.7088977012194,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark55(51.712799782261925,-0.2537376052960929,0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark55(5.172838041250287,-0.8954419096225663,0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark55(51.7502970658071,-0.14612735357989148,0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark55(51.76268217902111,-0.5046532146868934,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark55(51.76445021400149,-1.496157497000115,0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark55(51.79172493926387,-0.10906904497606718,0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark55(51.79667735020999,64.51740091171516,-84.29343239396036 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark55(51.843597636945134,-1.4763878901847,0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark55(5.191103719711393,-0.004637560786886014,0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark55(51.92364984751728,-1.0571789326122776,0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark55(51.94238961157512,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark55(51.94273054373957,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark55(52.02269234121928,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark55(52.043006770664604,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark55(52.06488404034019,-0.43222569631204366,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark55(52.09346899793189,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark55(52.102825263976285,-1.3544200137839653,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark55(52.13724879761057,-1.4999999999999942,0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark55(5.2219324716139965,-0.338330898739045,0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark55(52.2789226409007,-0.9666334805244503,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark55(5.239592437656171,-0.029896432720208033,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark55(52.39853657444027,-0.5367132410406925,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark55(52.46930643789074,-0.14015491795317156,0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark55(52.48247317227609,-0.015681949704289388,0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark55(5.249956350553944,-1.1798282684672046,0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark55(52.51617715994317,-1.0768034860403857,0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark55(52.51730368724849,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark55(5.253299553843078,-0.497899649321879,0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark55(-5.258554245393188E-20,-0.007234306273650779,-0.06255252525413836 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark55(52.58727405798189,-0.2052460911788927,0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark55(5.258934659132947,-0.7034117029381193,0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark55(-52.601791172584846,-0.44945604557023383,-9.659583408882959E-11 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark55(52.61341396648231,-0.5601875097889377,0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark55(52.66810249704186,-1.1508380772934382E-7,0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark55(52.69628958602926,-0.10709915400691522,0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark55(5.271653194375253,-1.3924211199511252,0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark55(52.729865575991084,-0.42123037112847594,0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark55(52.73735702126831,-1.1819426133100088,0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark55(52.75773398876332,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark55(52.76354257580158,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark55(52.78040502880984,-0.8756195583041944,0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark55(5.278900506675882,-1.056689349177617,0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark55(52.78989994436532,-1.134178392281552,0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark55(52.80060216272329,-0.10985888260317722,0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark55(52.826002663474256,-0.5235814993925502,0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark55(5.291773768652227,-0.943973349791408,0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark55(52.9285743589827,-0.025030080713102254,0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark55(52.953229172249394,-1.1911934274862666,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark55(52.965733242068296,-1.194685570487323,0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark55(52.98388456307609,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark55(53.03738799749913,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark55(-5.305761288918532,-9.442928949633157E-9,-9.20048808422029 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark55(53.07019526335115,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark55(53.09214145220068,-0.789057259898377,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark55(53.11086653673678,-1.4029394212895365,0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark55(53.11288365823207,-0.797794181053615,0 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark55(53.116928228320134,-1.1913174909072473,0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark55(53.15611125757448,-0.004689989155300428,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark55(-53.205030456137635,-6.577389093541057E-9,1.0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark55(5.323026259235192,-0.1298340275294514,0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark55(53.237651237958914,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark55(53.238418140502304,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark55(53.291026581050446,-0.9537977191644362,0 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark55(53.31587127323989,-0.13636354177508636,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark55(5.332624150958215,-1.4233906111142063,0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark55(53.40252674654589,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark55(53.423932033606654,-0.20169557692038625,0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark55(53.4481412770721,-0.9125985253238172,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark55(53.458243365668324,-0.15283200763652083,0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark55(53.48405128324268,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark55(53.48857167634429,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark55(5.3510970434775465E-197,-9.860761315262648E-32,0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark55(5.354483694556581,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark55(53.61003349981493,-0.19765535094448694,0 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark55(53.62629737041798,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark55(53.62675725595652,-0.32532821389055494,0 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark55(53.7089924818564,-0.6856287581703127,0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark55(53.722896698065085,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark55(53.79055695312752,-0.8837984504125982,0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark55(5.383265305568514,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark55(53.842461567655675,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark55(53.85405404972167,-1.047831554455783,0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark55(53.89175428603045,-1.2069428108103182,0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark55(53.893150686771676,-1.3284884218949036,0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark55(53.92993479724595,-0.8243653083405542,0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark55(53.96159369178548,-0.40861056954251307,0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark55(53.96419884192298,-1.1825608765597009,0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark55(53.97066763006379,-1.0340818430721441,0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark55(54.01237605192867,-0.574635955613644,0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark55(54.0136784193397,-1.0444411769167719,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark55(54.0430769086654,-0.021895699981225647,0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark55(54.128079126513484,-1.2851201881117706,0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark55(-54.132550012798994,-0.2806050889123952,2374.7823077226026 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark55(54.134102814960926,-1.065736532234518,0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark55(54.2209048987567,-0.1714997910474685,0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark55(54.2480831427371,-0.32962001623431547,0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark55(54.39142684527263,-1.3252907487176149,0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark55(54.40860338013979,-1.2339256305049384E-9,0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark55(54.43208320939138,-0.014767243212549852,0 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark55(5.445807359502375,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark55(54.47953546957086,-8.462052665339426E-7,0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark55(54.53294204730412,-4.493604793191341E-9,0 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark55(54.55315383145475,-1.2755825855790919,0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark55(54.662869802046984,-6.351684037865266E-9,0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark55(54.6963324658473,-1.8042856831230563E-7,0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark55(54.72111793899733,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark55(54.764887865626775,-1.4999999998842461,0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark55(5.478165675591523,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark55(54.82755091800182,-0.2277227267853208,0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark55(54.83367016400152,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark55(54.91034015322265,-1.499999999901632,0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark55(54.92793515264298,-0.9119008865699181,0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark55(54.94798466420545,-1.22819762922181,0 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark55(5.495043134583634,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark55(54.990536958742666,-1.1924217614047259,0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark55(5.500936400399503,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark55(55.015582352571414,-0.9846929298007403,0 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark55(55.05425325978373,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark55(55.06552999431446,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark55(55.074448882513835,-1.135434853164158,0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark55(55.078491325049704,-0.3571469568275534,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark55(55.084527788024786,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark55(55.086164650015206,-0.44616247281552696,0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark55(55.089501630072675,-0.581065550357442,0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark55(55.10904815395401,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark55(55.121003139824,-0.4946520862193111,0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark55(55.12537219496674,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark55(55.15324704815612,-0.3219762893793483,0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark55(55.17957523496881,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark55(55.208333917009696,-0.25651921804208677,0 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark55(55.220424731447906,-0.4251815164128177,0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark55(55.220801722242754,-1.180707865032014,0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark55(55.22128431410951,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark55(5.523150423256993,-0.06523863407828401,0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark55(55.24203986849773,-0.7125142370508719,0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark55(55.265747232434336,-0.17145244364138623,0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark55(55.296190339171034,-1.0918969455916332,0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark55(55.349738226120294,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark55(55.35915881236417,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark55(55.39385012573089,-0.6256663344789501,0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark55(55.45140959495461,-0.09539999435745017,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark55(55.48332072135169,-1.1322279753726756,0 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark55(55.52778718349089,-0.21213810365185282,0 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark55(-55.563245894006734,-0.0019477482651053984,54.82936103161083 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark55(55.569746972132855,-0.8591893513772495,0 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark55(5.557626171006106,-0.8973896728381083,0 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark55(-5.561869746593752E-16,-1.7763568394002505E-15,-1.0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark55(55.637185519001775,-1.349448879851166,0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark55(-55.63873770213464,-0.8296197647729344,-58.19319990584023 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark55(55.641939779033436,-0.019952746197775983,0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark55(55.71792396423106,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark55(55.77608983548456,-1.4999999999654285,0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark55(-55.78185738831034,-0.19960095967700275,-3.9849084470737353 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark55(55.79146590853489,-0.23957949888267738,0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark55(55.81846914270665,-1.4999999999998437,0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark55(55.88352604561163,-0.5207585893581097,0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark55(55.88470692353519,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark55(55.92187827259593,-0.3993238918543225,0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark55(55.94606555162329,-0.19476445263057005,0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark55(55.948358010767436,-0.41598329701958825,0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark55(56.026540732565174,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark55(5.60333494255994,-1.48443496490232,0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark55(56.047538200801114,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark55(56.05922984001356,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark55(56.069777814928244,-0.20931280920939344,0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark55(56.10584952037312,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark55(5.611174715462425,-1.3768191184928953,0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark55(56.124107600856235,-0.07788198328968332,0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark55(56.15457891385532,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark55(56.16779811938159,-0.6365878767023112,0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark55(5.622597457964883,-0.6577894027313707,0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark55(56.23568356536098,-0.3492655409437616,0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark55(56.29273262697404,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark55(56.392842260045256,-0.3113116640441689,0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark55(56.435081600773756,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark55(56.43960976386578,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark55(56.45090198405197,-0.1496203991964753,0 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark55(5.654551416988852,-1.2914516314341988,0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark55(56.593416855552405,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark55(56.639386073415466,-0.08244717335386029,0 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark55(56.66232678035345,-1.1355081334801724,0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark55(56.70757642333598,-1.4999999999999885,0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark55(-56.709532776483464,-2.1025082134759667E-8,-41.57486591813758 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark55(-56.90013721282814,-1.0139533868805528,1.0000000000015419 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark55(56.90924310916064,-0.964480961269272,0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark55(5.691965040092796,-0.325016970085117,0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark55(56.924003105146966,-0.7489888328936303,0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark55(56.956896272590626,-0.07481894305747261,0 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark55(57.04174951253387,-0.18181525735518278,0 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark55(5.705080391858331,-1.17156244652333,0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark55(57.0641346507592,-1.2171697568923143,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark55(57.0748223851085,-1.149648944322253,0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark55(57.080230090523514,-1.3418340815735443,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark55(5.709721743539035,-0.1788476040592144,0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark55(57.11128966401538,-1.281800752472753,0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark55(57.11199323244723,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark55(-57.13537237033642,-0.6643867800247565,-1.0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark55(5.7169052042838375,-0.016374709089705956,0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark55(57.18906182959083,-1.3170180687140203,0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark55(57.1991809572535,-1.1200366222352613,0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark55(57.20465598440812,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark55(-57.20916417450678,-1.4963585378567508,0.06255805552319588 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark55(57.221204718298225,-1.295738027407019,0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark55(57.29410132539945,-1.001279447864306,0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark55(57.316918887603464,-1.1167616501511715,0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark55(57.32217016801283,-0.28189959693892075,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark55(57.33301653676875,-0.5696517903833511,0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark55(57.34367755381305,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark55(5.737479023566437E-11,-1.4085378453767692,0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark55(57.37533399353761,-0.6335358105899923,0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark55(57.43695991823924,-1.2116859624244443,0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark55(57.456913004069065,-1.4999999999999787,0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark55(57.50709102210442,-0.4888364825106535,0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark55(57.51678790190872,-0.628202076069815,0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark55(57.52883338352876,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark55(-57.63282025156133,-0.21082082588378503,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark55(57.63546874155578,-0.9246764167910584,0 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark55(57.67665955883765,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark55(57.69888686639331,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark55(57.760435814659466,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark55(57.76988348733144,-2.385931426195267E-9,0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark55(57.77267977295252,-0.5425563807994284,0 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark55(57.79184580233853,-0.9009259249163486,0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark55(5.77924678246029,-0.49389374210572123,0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark55(57.80043059139715,-1.7590675309095212E-9,0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark55(57.82655744627036,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark55(57.82691713064429,-1.357326650752583,0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark55(57.89313614910498,-1.1656215870104454,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark55(57.90932932112983,-1.474209383051312E-7,0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark55(57.910673835189776,-0.6083009213205877,0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark55(57.92869553121864,-3.93805165594538E-9,0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark55(57.98896040256096,-0.11365174964184632,0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark55(57.994316378466394,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark55(58.017683829893116,-0.14934644921298457,0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark55(58.07013533687919,-1.4357832049873593,0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark55(58.240912232464325,-1.4111319797213007,0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark55(58.25300562681397,-0.34744144773413926,0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark55(58.25345463570355,-1.1813321562641743,0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark55(58.350021174659986,-3.1431241112828036E-7,0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark55(5.836148883220342,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark55(5.83882032813456,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark55(5.843481045201186,-8.087908320139382E-5,0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark55(-58.43940885513123,-0.7051765885404517,98.10381086212163 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark55(58.47461572542346,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark55(58.53001059038307,-0.9713178617752902,0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark55(58.54549470295575,-0.1329795813791249,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark55(58.67923009873063,-0.24816715783923238,0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark55(58.6940498752451,-0.8979844355593887,0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark55(58.752777961235125,-1.3907989835037036,0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark55(5.8823943945047885,-0.3896014525511773,0 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark55(58.82763091497617,-0.09986388266607094,0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark55(58.86851247904673,-1.4999999999999885,0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark55(58.89735154399406,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark55(58.93743120806349,-0.2528985884693286,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark55(58.947307641531964,-0.6503607062884926,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark55(-58.95690136064804,63.010140084308375,19.23467542943675 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark55(5.898525731040067,-0.3918166125386904,0 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark55(59.00822299036987,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark55(59.00845320628565,-0.3703126800951253,0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark55(-59.0564908541551,-1.2286013077904459,2498.5941121955475 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark55(59.072008707840645,-1.3601390874653123E-9,0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark55(5.914260014196188,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark55(5.9144096980616325,-0.9127622469659684,0 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark55(59.17229014963132,-0.10843041100851991,0 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark55(59.21998677425756,-1.1803176594774385,0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark55(59.251614253733386,-1.6854033012778611E-6,0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark55(59.27890598662319,-0.561374459152585,0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark55(5.9279360179093405,-1.4682868428866271,0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark55(59.289425893798466,-1.086227061229911,0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark55(59.356325942436385,-2.0669311908545325E-8,0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark55(59.38476879507141,-0.909927121050514,0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark55(59.3866861189274,-0.004540934612393244,0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark55(59.40802396950804,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark55(59.41433570996537,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark55(59.4630045544984,-0.050758121611026295,0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark55(59.47684854570093,-0.1974901750718452,0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark55(59.50781320867651,-0.020453034797401584,0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark55(59.51637712948147,-0.9794822919158087,0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark55(59.55736648654229,-0.03660069144713418,0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark55(59.57445257297873,-1.3624256288297558,0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark55(59.58120841434111,-6.565339402178003E-10,0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark55(59.58847067274172,-0.034126410837217236,0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark55(59.59774861742994,-1.2527617052978002,0 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark55(59.60328372048461,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark55(59.771130831674185,-0.04632469186680055,0 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark55(59.78161699143257,-0.318568500087715,0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark55(59.82391176784298,-4.2482906461094515E-8,0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark55(59.87425107339007,-1.4104529394721395,0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark55(59.87681366900537,-0.17660647589673334,0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark55(59.87712493726639,-1.1135441140137488,0 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark55(59.95292865284105,-0.39017254604195584,0 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark55(59.97549143927279,-0.06466876465767009,0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark55(59.97574418533446,-0.3361742150657321,0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark55(6.001582589676618,-0.5492752911263684,0 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark55(60.078373511253005,-0.20227927145508318,0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark55(60.14830960478511,-0.43857520658723104,0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark55(60.15591489134749,-0.02027677674576367,0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark55(60.186143691814394,-8.675781176879358E-9,0 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark55(60.24210221232789,-0.2243558983074223,0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark55(60.303872130127644,-0.37380613968792575,0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark55(60.306701753886614,-0.2670849243681257,0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark55(60.31622635351536,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark55(60.31735166896317,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark55(60.36724921019612,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark55(60.368643812472726,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark55(60.37649809722776,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark55(60.40085480610992,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark55(60.418457812160966,-0.9205870559240132,0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark55(6.042542847369646,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark55(60.43675238917248,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark55(60.46221981509932,-0.032953703481072294,0 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark55(60.480933801535826,-1.2185079531631886,0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark55(60.50601135541967,-0.005657260364440898,0 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark55(60.51764418156614,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark55(-6.053230826548509,-0.013332735708017249,0.04885317789774731 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark55(60.53460089371032,-0.6796609364436224,0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark55(60.53497052686268,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark55(60.55025243550675,-7.610670099175715E-10,0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark55(60.557931487792345,-9.653105667336084E-10,0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark55(60.58022015620134,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark55(60.61814403338005,-0.8052294409469054,0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark55(60.6324508797888,-1.0317428877794237,0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark55(60.65506363604321,-1.357818450971318,0 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark55(60.74399195686448,-0.47368414837777717,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark55(60.75413432004757,-1.2556936504038168,0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark55(60.75550259091575,-1.2053806437316619,0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark55(60.83162699306047,-1.0229322885663863,0 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark55(60.835694060377534,-0.7207714232459437,0 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark55(60.84344259789401,-0.26421598901989696,0 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark55(6.089133368578173,-1.238453348883099,0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark55(60.89206091467366,-0.6203812567686615,0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark55(-60.90245242015906,2.7155950487921814,13.865600914785418 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark55(60.92720948379565,-1.4999999999999876,0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark55(6.093545147496239,-0.0013351103496628425,0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark55(60.95019863490725,-0.6440343585153272,0 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark55(60.95147313687491,-0.749343083108581,0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark55(61.10325706631457,-0.20516421637031268,0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark55(61.11187406937759,-0.7065048930921964,0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark55(61.11673348286908,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark55(61.161146031173445,-1.3058857958188632,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark55(61.16130518109978,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark55(6.122777968390892,-0.11508389697862809,0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark55(-61.22877939335264,-1.4999999999999996,-1.032977034106853 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark55(6.1239976623284775,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark55(61.24817109995266,-0.42157441813338314,0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark55(61.310605290911475,-1.385100296626984,0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark55(61.355129833191626,-0.8053444666603573,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark55(61.36714380442661,-0.4131012759639494,0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark55(61.4374089003384,-0.7931272844551986,0 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark55(61.53197522716707,-0.09821754895610724,0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark55(61.609329800169434,-0.727228777448119,0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark55(61.66276637130977,-1.3932336884852872,0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark55(6.167626792907077,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark55(61.70600285263953,-0.026169934525896554,0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark55(61.764472383767554,-0.39866660029489953,0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark55(61.82642992187621,-0.9645910273161107,0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark55(61.85966232921021,-0.9451904260472479,0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark55(6.198992644772394,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark55(62.01574518551155,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark55(62.037914809563574,-1.4999999139543807,0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark55(62.05418927503654,-1.0832846585161142,0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark55(6.207007923339724,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark55(62.12956630152165,-0.8343654107367799,0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark55(62.21441075236896,-1.1827910560515242,0 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark55(62.25397551494156,-0.011365238521452253,0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark55(62.25447669446583,-0.6535872152892588,0 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark55(62.25855353337295,-0.20935745648584714,0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark55(62.30983287089896,-0.9039971107062472,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark55(62.319299922338445,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark55(62.33737076704524,-0.3904096272885758,0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark55(62.35200056031054,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark55(62.37521615277174,-1.1840727200875256,0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark55(62.42502993891169,-1.2487494526068534,0 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark55(62.43712299563808,-1.040829990356805,0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark55(62.444465725720164,-1.3018828302022536,0 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark55(62.46644990431536,-1.49999999939018,0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark55(62.47505252146425,-1.0923358071583609,0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark55(62.495394578120624,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark55(62.52735656344018,-0.613936288103675,0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark55(62.57075063829254,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark55(6.2595790989222735,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark55(62.63120555412547,-1.0188475116651006,0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark55(62.66166384526724,-1.4180878305706635,0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark55(62.71474570378288,-0.26862139626142323,0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark55(62.74763626619219,-0.8177082203269349,0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark55(62.88539780948494,-1.0982070033601676,0 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark55(62.90584229239198,-0.5223162132197299,0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark55(6.300010589758296,-0.704732500092624,0 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark55(63.102357319624076,-1.1385299610521002,0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark55(63.195996405310524,-1.499999999999753,0 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark55(-6.320019677063551,-0.9228762190961932,-0.1119363573576635 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark55(63.20737313298986,-1.0904706833360343,0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark55(63.22803942551325,-0.258353918009816,0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark55(63.26205736999799,-0.10556061867652033,0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark55(63.313501837722924,-1.0450879066662315,0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark55(63.33432144265028,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark55(63.3597228497503,-4.1169045858684315E-9,0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark55(63.399026775126345,-1.3603487726727934,0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark55(63.40970447909663,-0.22633179369581224,0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark55(6.347331296581871,-1.2350485360824281,0 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark55(63.48003903972824,-0.8273515201988886,0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark55(-6.348721394968872,-0.3662540790480959,-1.0000000000000018 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark55(63.49677897765045,-0.739140844940195,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark55(63.49928790847099,-0.9435922387268563,0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark55(6.353147315496624,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark55(63.54242957611393,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark55(63.56006351662347,-0.9413864604559832,0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark55(63.56025661186534,-0.4577018765906189,0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark55(63.56420991605556,-0.6640423927053976,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark55(63.609141186605825,-0.654651602519583,0 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark55(63.62459714941414,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark55(-63.66146903857704,-1.2708484836877751,-0.05942892739821841 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark55(63.66575228801642,-0.9115460983017787,0 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark55(63.68807641293343,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark55(63.695923653103556,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark55(63.72612144834724,-1.4999999999999845,0 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark55(63.73850663473581,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark55(63.75527189364331,-0.2551673118085989,0 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark55(63.815722141004066,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark55(63.845023372903015,-4.985414240529776E-10,0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark55(63.84534126016774,-1.477333450089958,0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark55(63.84597830878039,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark55(63.88553212381696,-1.1145964381852385,0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark55(63.89086893254296,-1.0507375077555006,0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark55(6.393573700507687,-1.2463042304868102,0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark55(63.954473884524276,-0.48383045693026894,0 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark55(6.399468878733263E-6,-0.08836898398978167,0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark55(64.01265033319703,-1.2298214872551694,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark55(64.01443021782733,-0.1668212013563375,0 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark55(64.01562682719444,-0.21867001664329067,0 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark55(64.04407976128729,-6.5591691241765325E-9,0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark55(64.04679800677266,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark55(64.08731973136128,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark55(-6.415634523315247,-1.082745534852325E-4,51.194332985785124 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark55(64.1638090460043,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark55(64.17281507642394,-0.21397471259796808,0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark55(64.21849785595964,-0.7133598447576581,0 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark55(64.23643459400509,-1.0673394372136595,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark55(64.437184611363,-0.5378145290420271,0 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark55(64.47984599300102,-0.1678606100440092,0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark55(64.48323464624178,-1.3979151627399817,0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark55(64.48928720921822,-1.3241234998076656,0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark55(64.52761057166907,-0.9338010910027659,0 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark55(64.5942469494706,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark55(6.459793477107227,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark55(64.61019070565825,-0.29938435000729946,0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark55(64.7654929263407,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark55(64.80821901638289,-0.1589268085417085,0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark55(64.80897988461217,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark55(64.88902129864047,-1.4545799279048643,0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark55(64.90493885699823,-1.4999773752676606,0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark55(64.90869827897762,-1.1669362173495899,0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark55(64.91671172209658,-0.31941335997562526,0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark55(64.97308343334669,-1.2115822220035994,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark55(65.03154194503408,-1.3469305358922534,0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark55(65.09896397447295,-0.980767882045352,0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark55(65.12966217009085,-0.28936369963574826,0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark55(65.1860612086285,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark55(65.2461664741177,-0.1913582042373747,0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark55(65.32726520202678,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark55(65.33736289414307,-0.24849693576686605,0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark55(65.35428126598637,-0.45354776331340574,0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark55(65.37373006870769,-0.6840705910688296,0 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark55(65.41057338549234,-1.2116189312983274,0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark55(6.542776133788308,-0.41372735531413585,0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark55(65.45976930480515,-0.332771056112926,0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark55(6.553180213762545,-0.7913439379331635,0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark55(65.68130431016232,-0.5638101908326263,0 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark55(6.572236974773064,-5.9243478603711785E-5,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark55(65.8250936556748,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark55(65.82695658995789,-0.5123504087730542,0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark55(65.84938971895016,-1.4999999999999574,0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark55(65.92919667153078,-0.36940256359798695,0 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark55(65.92987243649938,-0.5844722782866586,0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark55(65.9513472922649,-3.238864086821159E-9,0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark55(6.596567753298473,-0.9708210996924436,0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark55(65.98714665815976,-1.1385394073237358,0 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark55(66.01121045634282,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark55(66.0301643513001,-1.0257869600927023,0 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark55(66.0348315723844,-0.6811054536659369,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark55(66.08068209040951,-0.4583484116075578,0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark55(66.12456261785138,-1.2126968663808823E-8,0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark55(66.17424137438292,-1.1930999916797345,0 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark55(66.20006271177641,-0.9801734324579137,0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark55(66.21042572578641,-5.297709237642431E-8,0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark55(66.23222746909606,-0.4719420044712095,0 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark55(66.23916512765439,-1.4894936453926169,0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark55(66.24561861945716,-0.13947411574156554,0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark55(66.26469998358061,-0.6564991017178841,0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark55(66.27314431118101,-2.402737568908909E-9,0 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark55(66.2888281091535,-4.716575684947003E-10,0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark55(6.628895998243349,-0.8602587959786225,0 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark55(66.29179155154036,-0.3632905668612558,0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark55(66.347690067647,-0.8298778431793536,0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark55(66.3502789491248,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark55(66.4082856520123,-1.3219223561247588,0 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark55(66.4380388251756,-0.2824784705172618,0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark55(66.49329872600828,-2.275574888098028E-5,0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark55(66.50123675788976,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark55(6.658091115554527,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark55(66.5827364980183,-0.8153491394782719,0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark55(6.663186876204037,-0.25792938666845955,0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark55(66.64999262300762,-0.07105849755386706,0 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark55(66.65318672470514,-0.032000556217965936,0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark55(66.68325495837263,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark55(66.68952265180343,-1.4034022897628864,0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark55(66.88995946673815,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark55(6.6892704562299015,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark55(66.96861341305305,-0.2291693843065588,0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark55(6.698560592348656,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark55(67.01287331408334,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark55(67.04258805331753,-0.5746493478560767,0 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark55(67.04289904249,-0.05853198584332109,0 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark55(67.07355537873002,-1.4999999999999334,0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark55(67.11384675237494,-1.2829708805605202,0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark55(67.1224241574769,-1.499999999999977,0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark55(67.18601775902769,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark55(67.20144835854455,-0.3719595816211216,0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark55(67.23481957798538,-1.3940278179842847,0 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark55(67.25021028688582,-1.064793810508431,0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark55(-67.27924650493216,-41.13704668737208,25.136860351309224 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark55(67.36497160412543,-0.29192016930391596,0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark55(67.3671535483073,-1.0018937838125748,0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark55(67.38153019797605,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark55(6.7459141808248795,-0.5798745707429478,0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark55(67.4705609276098,-0.9557384704069332,0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark55(67.48294482221911,-0.6483770429600675,0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark55(6.751075069957807,-0.5130233220310444,0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark55(67.51453491717636,-1.734723475976807E-18,0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark55(67.52314506403022,-1.1383923072270838,0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark55(67.61307763760297,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark55(67.65202505823314,-0.17330658591279757,0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark55(67.66306007091856,-0.8728333456975008,0 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark55(67.70469737182705,-1.8369010131011447E-16,0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark55(67.77178368840592,-0.3816969954731917,0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark55(67.79119626579754,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark55(67.79490996553068,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark55(67.80966533872984,-0.007644368846353444,0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark55(67.88295464851778,-1.649313039118736E-4,0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark55(67.93248992554922,-0.18640934212814386,0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark55(68.1156584767131,-0.28190823899176465,0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark55(68.19081091008553,-0.39871484281653125,0 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark55(68.19090022461776,-0.7959761023790426,0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark55(68.21690704955932,-1.2371328982792278,0 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark55(68.22323544042166,-0.26775238443828164,0 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark55(68.23219183515675,-0.41331193960812507,0 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark55(68.24813141577567,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark55(68.26219739451787,-0.774197027029135,0 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark55(68.26823155016473,-1.427367176269638E-7,0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark55(68.32365540140916,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark55(68.36051515641441,-1.4341445831205504,0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark55(68.36553422774134,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark55(68.3769652882172,-1.0839851836133083E-8,0 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark55(68.38747598475962,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark55(68.43490323141518,-0.6666843897646544,0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark55(68.44475830291643,-0.3174798404334314,0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark55(68.45593292753907,-0.7844061339578001,0 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark55(68.48159487950284,-0.7096598380800696,0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark55(68.58987350853945,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark55(68.59028181608977,-0.34475082206198837,0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark55(68.6411413127084,-0.02209297628618867,0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark55(68.64545651758091,-0.37842355580012715,0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark55(6.864720253652107,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark55(68.65166303704925,-1.3830499635441464,0 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark55(68.82754257436662,-4.7498586556612876E-5,0 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark55(68.84059877854637,-1.422938332713555,0 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark55(68.88124507964454,-0.4354781331119626,0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark55(68.89115644026569,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark55(6.89249158291949,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark55(68.92591585558907,-0.06371591998319559,0 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark55(68.94182636746237,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark55(68.961809357144,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark55(68.97684926452561,-0.21081751895705653,0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark55(69.00799196601892,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark55(69.00941664919887,-0.12263129492646385,0 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark55(69.04670182846966,-1.3139861147792748,0 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark55(69.04723643608344,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark55(69.07058979722646,-1.6273653823411474E-4,0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark55(-69.11043216998638,-0.6220144691715461,0 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark55(-69.1392215937633,-1.3388767667476866,1.0 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark55(69.15849512106055,-1.4941749466987293,0 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark55(69.27297453723463,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark55(69.28388452687705,-1.210521018321284,0 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark55(69.289631166996,-0.1693777046730247,0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark55(69.29927496509298,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark55(69.32379628852689,-0.29841544991459235,0 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark55(69.33988119688756,-0.008853460297059069,0 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark55(69.35007539892973,-0.005413776001290671,0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark55(69.36421476109675,-0.25925467878856523,0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark55(69.43976674491171,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark55(69.46101786881556,-0.5001129903088781,0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark55(6.952792774584296,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark55(69.56325711077963,-0.5855289657476432,0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark55(69.58857162392877,-0.0038578116488666337,0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark55(69.63436713757824,-0.6151592181194729,0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark55(69.63557751009591,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark55(69.64520492096835,-1.459748745405264,0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark55(69.64845990540906,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark55(69.6736049250992,-0.11536571140362639,0 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark55(69.67942814893627,-1.2115345686754047,0 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark55(69.72880095662524,-1.2649062123870083,0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark55(69.78893407879991,-1.4999999999699827,0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark55(6.987638785359195,-1.1166949040831005,0 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark55(69.88610103585341,-1.2930233374355993,0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark55(6.988861493859403,-9.17550067365708E-8,0 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark55(69.91846591561611,-1.3366507963744096,0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark55(69.93062549876836,-0.24185442150722736,0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark55(69.93238475912864,-5.881422257335202E-9,0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark55(70.01963003238575,-0.1630082175835006,0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark55(70.03775505390507,-0.9331503901455847,0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark55(70.0979392974692,-0.29235654069790606,0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark55(7.0203211794908,-1.499999944741562,0 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark55(-7.025131076433384,-1.47843691582499,-0.6157510664201373 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark55(70.25314430073863,-1.129473089361424,0 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark55(70.2644614046043,-0.08112354821061066,0 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark55(70.31985587092177,-1.0531829515942097,0 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark55(70.35909031795958,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark55(70.3738428041564,-0.16083683035241048,0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark55(70.38482664539086,-1.490914404768099,0 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark55(70.3904965191918,-1.4999999999999627,0 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark55(70.45169306466366,-1.4549723354409982,0 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark55(7.045381238121834,-0.5508573204506007,0 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark55(70.48449450870916,-1.139690138934279,0 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark55(-70.49357719429149,-1.1905833028879376,-1.0 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark55(70.51499990525883,-1.3857561370469043,0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark55(70.54469278714379,-2.5120463445588067E-4,0 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark55(70.54808898295258,-1.2820746301117012,0 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark55(70.5760279134733,-1.2844435027854746,0 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark55(70.57802809979,-1.0345414251199117,0 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark55(70.61466253325128,-1.1648276917837102,0 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark55(70.61918216204592,-0.6562768407868889,0 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark55(7.069086589590313,-0.6378273072149625,0 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark55(70.69295749425169,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark55(70.74092073258507,-0.8462783828624927,0 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark55(70.75774560424159,-0.21965760226575526,0 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark55(70.76387768014771,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark55(70.8548557947517,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark55(70.87231183353667,-2.2728014498775904E-16,0 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark55(70.92691780585497,-0.8625444701399232,0 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark55(70.93299712497253,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark55(70.94746481726119,-0.9319862895260549,0 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark55(7.09925323866816,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark55(7.105427357601002E-15,-0.23194911664738305,0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark55(-7.105427357601002E-15,-0.2741251974609641,76.33969977822618 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark55(-7.105427357601002E-15,-0.3016152575911948,-0.5207314223164572 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark55(7.105427357601002E-15,-1.3993598447724587,0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark55(71.09842308157346,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark55(71.10021724923311,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark55(7.115307525651502,-0.4289207326525166,0 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark55(-71.1804599990943,-1.4999999999999991,-88.01577862463571 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark55(71.18173300355087,-0.5525317783365487,0 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark55(71.19434099645068,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark55(71.26509885042947,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark55(71.28393490861995,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark55(71.28659069588062,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark55(71.31611412929028,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark55(71.33605948158927,-0.640055560392502,0 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark55(71.37645296357042,-1.4999999998539513,0 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark55(7.138359480503245,-9.75598863835281E-6,0 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark55(-71.38569673572582,-0.83267917636042,0 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark55(-71.40419877042316,-41.32603929442094,-2.8211426270783733 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark55(71.4072981642853,-8.949373227802026E-10,0 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark55(71.4424711199519,-1.4999999999999805,0 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark55(71.45991715106763,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark55(71.56540750972387,-0.07185372821929958,0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark55(71.59387911744597,-1.0802566466667827,0 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark55(71.60781675584732,-1.4126678479231813,0 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark55(7.164108373961526,-0.7424696695740742,0 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark55(71.6621898904038,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark55(7.167218225245037,-0.6565983771516031,0 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark55(71.7198059839946,-0.9726441258656218,0 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark55(7.1721088354356235,-0.0879529118090479,0 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark55(71.7636008298368,-0.7673988973894992,0 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark55(71.8119499939686,-0.45239990488886406,0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark55(71.83650942573826,-0.03588800281995563,0 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark55(71.84590529145837,-0.7139281041794732,0 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark55(71.84868248095603,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark55(71.85541008282235,-1.4999999999999902,0 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark55(71.86257284055819,-0.47486864590039257,0 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark55(7.192944411310734,-1.1355634120380032,0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark55(-71.99635921464501,-0.49555984743110987,0.9999999999999998 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark55(72.00322678937204,-1.4340435077422938E-8,0 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark55(72.04429689829368,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark55(7.209726532483259,-0.2522419469963779,0 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark55(-7.21016320629403,-1.062807119462832,1.0 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark55(72.15712255286051,-0.7872552167331754,0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark55(72.22577972699767,-0.639497991002127,0 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark55(7.223138983902388,-1.1631054709734794,0 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark55(72.27834751011487,-0.5324365189591286,0 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark55(72.29824845186724,-0.3005489305597172,0 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark55(72.33256806960745,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark55(72.44852833636114,-0.6303325900514833,0 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark55(72.45083395127264,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark55(72.46202244317504,-0.6999886560238764,0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark55(72.46998691191169,-0.5284194797845885,0 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark55(7.261116373727148,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark55(72.63052416881345,-2.7154270274703014E-7,0 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark55(72.6708879841471,-0.1682837104105852,0 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark55(72.69100769847915,-0.031211469260632896,0 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark55(7.271218140552499E-16,-1.1692978676337895E-15,-0.7340734118250598 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark55(72.71321934128065,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark55(72.77463429677701,-1.1902554214201189,0 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark55(7.278480386911983,-0.4953432208331918,0 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark55(72.87636969676092,-1.2254474787133498,0 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark55(72.89009869924902,-0.3448201407061518,0 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark55(7.289338389332457,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark55(72.90647212455298,-0.5734561718336693,0 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark55(72.90985038420118,-0.21799456875471718,0 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark55(7.295472825855596,-0.3487542727422941,0 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark55(72.97484976047036,-0.23515438280604783,0 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark55(73.04538397171603,-0.20775824901006956,0 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark55(73.0475156793021,-0.16637863409489784,0 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark55(73.09248508522873,-0.5345797713112148,0 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark55(73.15012901673458,-0.5979664182989897,0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark55(73.15704502905504,-0.0063411081608611974,0 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark55(73.26076821893182,-0.43574400490602816,0 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark55(73.33113614624031,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark55(73.33234168420361,-7.991261302302916E-9,0 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark55(73.38054162477499,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark55(73.40007655290728,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark55(7.340038406974259,-0.775355156372194,0 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark55(73.44020225801947,-0.39862601783932927,0 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark55(73.46335635180601,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark55(73.48621746029767,-0.18902040944035647,0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark55(73.50000605585706,-0.5488066569737766,0 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark55(73.52985200533843,-0.670476010758577,0 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark55(7.358059410511089,-0.3773145135060847,0 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark55(73.5961510760188,-0.5583487175330362,0 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark55(7.362006693152878,-1.4999998213399135,0 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark55(73.62828079539068,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark55(73.62876828628478,-0.47072793614002917,0 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark55(73.68531363603165,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark55(73.70678157920747,-1.1972530188919563,0 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark55(73.75134701612751,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark55(73.7705257730214,-1.1712156962836673,0 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark55(73.79013117699974,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark55(73.79352182885665,-1.4236886068995602,0 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark55(73.87616875970457,-0.5303142685868769,0 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark55(73.91056387987882,-1.3760081255655905,0 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark55(73.93319607771261,-1.0698989170222846,0 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark55(74.00674137443286,-0.6206731452166746,0 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark55(74.0135468109076,-0.6375959938593878,0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark55(74.01917329888153,-0.3282994002321282,0 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark55(74.06981383263764,-1.4481854078350738,0 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark55(74.10317026427214,-0.19493101652400924,0 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark55(74.11394702799493,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark55(74.1284908271413,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark55(74.2973559982924,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark55(74.35970869023207,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark55(-74.371187920195,-1.042163470615491,-54.35593939750844 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark55(74.39842465468246,-1.1929955276404938,0 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark55(74.40037404571464,-0.5997080700553081,0 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark55(7.4444847320770435,-0.33362608076706657,0 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark55(7.444994452621529,-0.45007122900857843,0 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark55(74.48493510922717,-1.434581053288916,0 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark55(74.49816076800298,-0.28107913694211284,0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark55(74.50091547678525,-1.3150758231612674,0 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark55(74.5198157430878,-0.31361102555666615,0 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark55(74.6076139637731,-1.4120414878749799,0 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark55(74.63388665653486,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark55(7.463531942510059,-0.5949879412390926,0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark55(74.64165815462886,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark55(74.6756517479981,-0.12018599281254616,0 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark55(74.7452451118867,-0.1750097799402515,0 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark55(74.76830428986804,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark55(74.7805413379188,-0.0019060090530661489,0 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark55(74.84863280507398,-0.7951950772737897,0 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark55(74.87488257538203,-1.3091953128484761,0 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark55(74.87942723678121,-0.18641168112828677,0 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark55(74.89345142674684,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark55(74.89770508675201,-1.382741351735291,0 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark55(74.92974240367462,-1.3134865209663886,0 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark55(74.9779091068983,-1.232252404017467,0 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark55(7.498416530600553,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark55(75.02888897829995,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark55(75.0400945482171,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark55(75.09185107528674,-8.640306418003255E-5,0 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark55(75.11860244217647,-0.6954907251666973,0 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark55(75.12576200092101,-0.532067992513447,0 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark55(75.16332265627966,-0.03150294278827911,0 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark55(75.17915311251957,-0.23011543697126147,0 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark55(75.19254791980019,-2.645633960109449E-9,0 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark55(75.19281479990306,-1.4210152274722967,0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark55(75.26497510880101,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark55(75.29217941998857,-0.990837821157335,0 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark55(75.32832824911668,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark55(75.34499815191133,-1.4231599373703398E-7,0 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark55(75.34587100011714,-0.2640919577252392,0 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark55(75.42102311079455,-1.3893824569148672,0 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark55(75.42125260213771,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark55(75.43121428228469,-1.45312852015527,0 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark55(75.47596765108301,-0.8507116095038794,0 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark55(75.5373509063223,-0.3362821683840707,0 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark55(75.59199363145177,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark55(75.59960308686706,-1.0863382561698662,0 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark55(75.60517741901708,-0.598043476618038,0 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark55(75.63272634834155,-0.2726914980115369,0 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark55(75.64790985711917,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark55(75.65106549187911,-65.41303985608604,7.50123182813644 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark55(75.72649200421041,-0.926218999068745,0 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark55(75.77069254703207,-1.0830211582717908,0 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark55(75.79310505482891,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark55(75.79664298796216,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark55(75.84835950758944,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark55(75.8918789766058,-0.32469543844384563,0 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark55(75.904572899398,-0.5549453419519566,0 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark55(75.92104882455578,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark55(75.92539894552473,-4.702198331493362E-9,0 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark55(75.92798105234016,-0.6918314584810699,0 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark55(75.99878235463319,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark55(76.01244343565438,-1.1702100546189413,0 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark55(76.09414089013431,-0.2831797595720896,0 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark55(76.10644839375634,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark55(7.618748905813447,-0.042952032517746375,0 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark55(-76.20976250708146,-0.46826433666028544,0.013931983567329206 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark55(76.22991997327239,-0.01781025984884306,0 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark55(76.24232530363685,-0.11153857783174241,0 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark55(7.628726050204591,-0.35282884203408543,0 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark55(76.30495824259376,-0.7144068551075478,0 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark55(76.39588906089449,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark55(76.40645140758116,-1.1882711525150595,0 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark55(76.41357281661541,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark55(76.417353026904,-1.121738454345319,0 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark55(76.54701459759539,-1.0218177196277751,0 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark55(76.5515077351667,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark55(76.6025345497572,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark55(76.68127124217219,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark55(-76.68145077031062,-0.6681858320951071,-1.0 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark55(76.69416742174633,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark55(7.674565149975788,-5.4547772299159375E-6,0 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark55(-76.74741992868343,-0.5855589046641576,-39.465718096645716 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark55(76.75727550458421,-1.1226039370275824,0 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark55(76.79860914549116,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark55(76.82248324002,-0.025406232551947627,0 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark55(7.68325243721475,-0.31333462310483007,0 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark55(76.84906150506518,-0.36640459386644864,0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark55(76.85930105905277,-0.28487577683881327,0 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark55(76.92444732624254,-0.1901929293443515,0 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark55(-76.93410505019243,-0.008039776566126804,0.05282168445096325 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark55(7.695130175865515,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark55(76.96461114168284,-0.21674959632371382,0 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark55(76.9797846289249,-0.6314058963727944,0 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark55(77.09891550611377,-0.7065336741802071,0 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark55(77.16614145682098,-0.24611503519084033,0 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark55(77.19372666531314,-1.3515405584561984,0 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark55(77.20964633916938,-0.5775302756916059,0 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark55(77.2134630497394,-0.8776257061411599,0 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark55(77.22314531421611,-0.42673031540905626,0 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark55(77.34652279885967,-0.2851950337512436,0 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark55(77.3812486468264,-1.3425020681491588,0 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark55(77.41969966750605,-0.27630941116897034,0 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark55(77.43232334687282,-3.5288099881733392E-9,0 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark55(77.45047445244631,-0.01579102860499937,0 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark55(7.748038573388527,-1.4999993774398346,0 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark55(77.56069466960005,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark55(77.66442763959726,-0.1633043722462102,0 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark55(77.67384980568443,-0.9571578035638066,0 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark55(77.69914968633799,-0.46695992267241593,0 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark55(7.778164465586855,-0.5758286243261218,0 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark55(7.781302132617574,-1.347133732273938,0 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark55(77.87455364875804,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark55(77.94847146206197,-0.19799891152326765,0 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark55(78.04290103305337,-0.4417528676288214,0 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark55(78.0759457910082,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark55(78.12701013963208,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark55(78.1423447690243,-0.8388215662355778,0 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark55(78.18815338820303,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark55(78.20012684240328,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark55(78.2288568667795,-0.5841236220487218,0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark55(78.28404654613132,-1.4864278998176754,0 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark55(7.834686129252216,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark55(-78.40064105559034,-0.5314174910256213,1.0 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark55(78.44462397076524,-0.07485865191815222,0 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark55(78.45428087085409,-0.7766040868678061,0 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark55(78.46385806077197,-0.12327795429975374,0 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark55(78.51289616039556,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark55(7.852565053139699,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark55(78.53613565219274,-0.27710205737671034,0 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark55(78.66043212927805,-8.700927758070651E-6,0 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark55(78.72083190315203,-0.33598265737370914,0 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark55(78.75598173858546,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark55(78.80907414167103,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark55(78.81678317981212,-1.1864628036649947,0 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark55(7.8851507840611035,-0.2828323439320304,0 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark55(78.85478125612036,-1.2228082761761891,0 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark55(78.85512379385699,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark55(-78.9277260765969,-1.4954756983412534,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark55(78.98662622457792,-0.05533386421670983,0 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark55(78.99187676590753,-0.0051481282764171965,0 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark55(7.899990371842321,-0.1306128227102449,0 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark55(79.0557100535568,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark55(79.08907622813823,-1.457380384539412,0 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark55(79.11536367890882,-0.7913915177191195,0 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark55(79.12609215039541,-1.080136260841464,0 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark55(7.9126891773165084,-1.102999660502661,0 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark55(79.22841900201024,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark55(79.23637735556511,-0.03331679166780077,0 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark55(79.26328670837015,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark55(79.33410665900072,-0.24981554798877426,0 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark55(79.38602711006325,-0.2431561957816042,0 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark55(79.44904288992137,-1.0232746743944592,0 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark55(79.47092198130207,-0.44245284325967427,0 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark55(79.47411798628713,-1.2273855361697619,0 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark55(79.48752685156938,-0.9359262424697885,0 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark55(79.4891119003298,-0.8559293677869639,0 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark55(79.54437326553568,-0.9927253226669421,0 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark55(79.56025928892996,-1.4803872782344172,0 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark55(79.56068749037533,-0.5086091743673151,0 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark55(7.967227951591568,-0.7249262295620444,0 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark55(79.68838672121959,-1.03741448085859,0 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark55(79.70233934948354,-1.0211855420020042,0 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark55(79.71341350672441,-0.9390322457261713,0 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark55(79.73225457809357,-0.4463990767673067,0 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark55(79.83433708075239,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark55(79.87937014778169,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark55(79.89912975800115,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark55(79.9239081243658,-1.1948955767678626,0 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark55(80.00932981099496,-0.9641448589673125,0 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark55(80.02602474390235,-0.43271505117372655,0 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark55(80.05670533138351,-0.0024366899280091714,0 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark55(80.08053853356313,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark55(80.08097489924293,-0.2160393775602678,0 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark55(80.08974352182071,-1.4897558037460783,0 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark55(80.12372948879204,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark55(80.131612088471,-0.18746242832187576,0 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark55(80.17792685654686,-1.0055379296708367,0 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark55(80.25791394274796,-0.7428324967271394,0 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark55(80.31106309878791,-0.4067198229243445,0 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark55(80.40489141855474,-0.5903462146840044,0 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark55(80.40574579136813,-1.4020489111821348,0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark55(-80.42222468350187,-0.057039187745847375,-0.025732880519594478 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark55(80.441813275486,-0.7642352200757003,0 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark55(80.4533433624386,-0.4910700081667174,0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark55(80.55512470304072,-1.380140658698565,0 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark55(80.62042595517408,-0.5857504571641385,0 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark55(80.65538106156919,-0.6460755467967081,0 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark55(80.68492853672197,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark55(80.69674251398453,-0.18483598923476885,0 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark55(80.86996749918066,-0.7815010853727824,0 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark55(80.98789355149505,-1.0071586043018113,0 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark55(81.04701290164884,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark55(81.06402610525507,-1.114688902096188,0 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark55(81.19890084222378,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark55(81.20102544646386,-1.4222900587554437,0 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark55(81.21714974372361,-0.11288257971539695,0 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark55(81.21760540999713,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark55(8.12385408030083,-0.26651457156302727,0 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark55(81.25451193548986,-0.04164518856458321,0 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark55(81.26625770968892,-0.04640299958250438,0 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark55(81.28377230239839,-1.4806546722988534,0 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark55(81.32334486871471,-1.1880263483877416,0 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark55(81.32911373519946,-1.4843470930486362,0 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark55(81.37671886809102,-0.8027260342270339,0 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark55(81.47921120657936,-0.7086151447575424,0 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark55(8.148710222913701,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark55(81.49898985796068,-1.1460262709848772,0 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark55(81.52563653285355,-1.2914325530445865,0 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark55(81.59119416744743,-0.3986634152562466,0 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark55(81.60009516713691,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark55(-81.63487429301668,-1.4999999999999982,0.932727768515907 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark55(81.64473855092452,-0.19556081801143055,0 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark55(81.66828458486609,-0.19601019682136211,0 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark55(81.68865911372217,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark55(81.72917504745938,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark55(81.7419448243679,-1.170822946383625,0 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark55(81.81903771228002,-1.786412691712729E-15,0 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark55(81.82627560436313,-0.8553837812949534,0 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark55(81.85832996171615,-0.0759236160886024,0 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark55(8.195148644913719,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark55(81.99405544405039,-1.015645488613231,0 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark55(82.00501217669404,-0.6897710144185867,0 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark55(82.0265709166129,-0.44558133749853557,0 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark55(82.0682200017155,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark55(82.07746323732661,-0.9021375981478315,0 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark55(82.08201951505549,-0.8935497413320661,0 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark55(82.08867644223889,-0.9424044619336325,0 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark55(82.1390042574688,-1.393263324195421,0 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark55(82.17275843784584,-1.37964156536579,0 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark55(8.217309771355538,-0.37463217012185446,0 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark55(82.17615705889395,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark55(82.18093592553599,-6.122767966084743E-5,0 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark55(82.18546683339375,-0.6429662537069185,0 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark55(82.1864951316404,-0.24113774431599433,0 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark55(82.30464131438774,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark55(82.31276159823514,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark55(82.32312711773713,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark55(-82.34361106421659,-1.3391746901618369,-0.9886801304502271 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark55(8.238299076813588,-4.373693134709188E-5,0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark55(82.48816432183276,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark55(82.51030838691068,-1.1938688284680832,0 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark55(82.51998965360758,-1.3373886653896108,0 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark55(82.54190733985587,-0.2996668871457504,0 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark55(82.613472467971,-1.4350114015320348,0 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark55(82.63060341833301,-0.28901492570333875,0 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark55(82.63080542873868,-0.7846236710132121,0 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark55(82.67022950291778,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark55(82.68822208672339,-0.1941519790660493,0 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark55(82.79297408958226,-0.6152976234853034,0 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark55(82.84536692641376,-0.7503900063619255,0 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark55(82.88847890163811,-0.7189955115813262,0 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark55(82.89741716085602,-0.9898747443444398,0 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark55(82.90314387413619,-1.1095752142034563,0 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark55(82.93713252431525,-5.883396752553052E-9,0 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark55(82.94238054107993,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark55(82.99456192587762,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark55(8.310386138633357,-1.268307848897308,0 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark55(83.14968483216589,-0.12914234542467806,0 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark55(83.18490203861931,-0.8838682525687034,0 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark55(83.23797021132685,-0.09487204009938921,0 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark55(8.324963167555854,-8.79236741524754E-6,0 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark55(83.30130674409722,-8.455085438547453E-6,0 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark55(83.32411784480917,-0.41652460273412517,0 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark55(83.33076686153126,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark55(83.35515045277347,-4.214994064917934E-9,0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark55(83.38224258376678,-1.3329037088548805,0 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark55(83.4219799473706,-0.26214325542101413,0 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark55(8.346217828776645,-0.17755047282840908,0 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark55(83.49984613763078,-0.7659766578786815,0 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark55(8.35169397094431,-1.4987085621158154,0 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark55(83.59071053810418,-4.1932161551131486E-8,0 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark55(83.62754441580492,-0.3772010180049996,0 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark55(-83.62988618618404,-0.5335774180231567,-0.9999999999999998 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark55(83.64885211884354,-0.3672681135950622,0 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark55(83.66614180496408,-1.445457004954142,0 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark55(83.72033080259561,-0.4005726674241643,0 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark55(83.78020732678007,-0.6650390931575956,0 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark55(83.79244237877228,-0.4983259764347947,0 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark55(83.80125206444691,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark55(83.93132002586466,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark55(-83.98496057284494,-0.3294229306564582,0.0 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark55(84.03050458991444,-0.20533569083069292,0 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark55(84.04851337214853,-0.39357715594687903,0 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark55(84.04978506968965,-1.4248646114288004,0 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark55(84.11237987178482,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark55(84.1293679010634,-0.9173376676171389,0 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark55(8.414375969449893,-1.4347511848704642,0 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark55(84.2032974215665,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark55(84.22497781371845,-0.9330082335618286,0 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark55(84.30684699806207,-1.156120681880168,0 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark55(84.40984350777109,-0.5366892838340618,0 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark55(84.4936108471918,-0.686638622657594,0 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark55(84.49370383583326,-0.47994124481611244,0 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark55(84.58721338638384,-0.6892198434878765,0 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark55(84.63773701277864,-0.5380343874118192,0 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark55(84.63810729777703,-0.36974834029033143,0 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark55(84.65509483380819,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark55(-84.6573978846873,-0.39625274857830683,-87.80264533058525 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark55(84.6744654259462,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark55(84.6808314174891,-0.012534829727368413,0 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark55(84.68635260102565,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark55(84.72049678188839,-0.23729195425848104,0 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark55(-8.47508617643459,-0.3358368485605885,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark55(84.76973182265309,-0.3469943816497416,0 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark55(84.79636716530487,-0.47197964989540253,0 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark55(84.80321479023647,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark55(84.83984895152335,-0.20965683444089223,0 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark55(84.8757185529843,-0.36235585678345217,0 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark55(84.95076444669084,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark55(84.98614211225828,-1.3227029402833779,0 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark55(8.4E-323,-2.4789635951174877E-4,0 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark55(85.13337552823961,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark55(85.17656879225964,-1.3222568778904007,0 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark55(85.18286740517016,-1.174806366839681,0 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark55(85.2305818170012,-0.14989811188949353,0 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark55(85.270745401982,-1.4999999999999676,0 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark55(85.39562691243685,-0.9794033393786785,0 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark55(8.549399552988518,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark55(85.52996988131068,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark55(85.53596628206651,-1.459787097904126,0 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark55(85.53937903318624,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark55(85.56156612991613,-1.2398954413050196,0 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark55(-8.557418628410792,-0.881616689084163,-1.0 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark55(85.6234648403892,-1.4365459591294751,0 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark55(8.563463834710006,-0.0023865708596702007,0 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark55(85.70704553937705,-0.900376913004159,0 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark55(85.74285281940067,-0.15962155908584919,0 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark55(85.75746845097319,-0.5286823271754884,0 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark55(85.77690851661322,-0.17276492793706666,0 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark55(85.8003757174177,-0.010014644012023233,0 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark55(85.82842465309716,-0.9729247807030665,0 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark55(85.83963940442936,-0.7528305395645027,0 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark55(85.85860341759164,-1.0752589979862996,0 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark55(85.8621345744688,-1.049058221983472,0 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark55(85.86585168254736,-1.4999999907159602,0 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark55(85.87294610377774,-0.7662310152869418,0 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark55(85.88323643394324,-0.479377031710996,0 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark55(85.89136016765124,-0.26049545219883097,0 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark55(85.91869348979785,-0.8250538516989252,0 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark55(85.97561780561358,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark55(86.02486239928966,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark55(86.0641130028078,-0.7071893478950884,0 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark55(86.08674965195118,-0.016730938438485554,0 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark55(8.611344312192484,-0.01104877272480237,0 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark55(86.1512328763481,-0.6809480092457818,0 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark55(8.617375606799385,-1.1236172123740804,0 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark55(86.19309161934456,-1.2334991102996176,0 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark55(86.25959132871537,-0.5969744382429991,0 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark55(86.26602568983503,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark55(86.27410556234122,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark55(86.42100882550895,-0.40168912693003733,0 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark55(86.50741708205456,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark55(86.51909475780892,-1.4327993016253133,0 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark55(86.59574018939395,-1.4027532373283407,0 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark55(86.61579922344879,-0.039148451289133135,0 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark55(86.62603041474338,-0.06754015154623971,0 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark55(86.64280057571503,-0.039750525401797354,0 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark55(-86.67495478581155,-0.6917438047564861,-15.829630291753631 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark55(86.73415416151232,-0.9000259827873716,0 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark55(86.73494198242568,-0.2755685463334281,0 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark55(86.87804929001156,-0.1097165858214284,0 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark55(86.90074405788458,-0.886733782504991,0 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark55(86.93519345404229,-0.8371601594143607,0 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark55(86.93754019849095,-0.8542539107869427,0 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark55(87.08086317437557,-1.4917044218489188,0 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark55(87.08984409423098,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark55(8.71884582640277,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark55(87.25512310231545,-1.497061205502915,0 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark55(87.26989478420111,-1.4289556876613219,0 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark55(87.36800607953553,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark55(87.39799639663359,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark55(87.44674339559143,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark55(87.46039879675324,-0.06340720899332908,0 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark55(87.5009729640167,-1.2916351086741678,0 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark55(87.50862757507856,-1.4406973835104886,0 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark55(87.5209796459341,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark55(87.5215735823518,-1.238813558266477,0 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark55(8.754121531752846,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark55(87.56687715747438,-1.4162377512204518,0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark55(8.75931166601734,-0.8819096613511164,0 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark55(87.61078955140951,-0.18593323272322282,0 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark55(87.65061539913954,-6.842456097953344E-9,0 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark55(87.65078702048547,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark55(8.765604604445443,-0.311349896477489,0 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark55(87.66351755642268,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark55(87.67475940947699,-0.1818997723137734,0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark55(87.72485522818685,-0.9893282238551808,0 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark55(87.76144061015444,-0.31702749753851217,0 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark55(87.83183426411829,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark55(87.86262256051663,-0.8786871050226273,0 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark55(87.86735084694014,-0.01689589524952695,0 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark55(88.034686665884,-5.413837034147267E-10,0 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark55(88.0963585894219,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark55(88.10116361476358,-1.9562246131865155E-7,0 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark55(88.12636249532164,-0.30223363438972384,0 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark55(-88.149726199593,-41.819245368832924,-16.146232698500043 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark55(8.817340886996107,-0.9745514711741352,0 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark55(88.19287814797616,-1.3560645095634034,0 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark55(88.21196461856039,-1.2923161754306527,0 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark55(88.24511061990214,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark55(-88.27040454951805,-0.13978623666645892,0.0 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark55(88.28547305291141,31.640195652481083,0 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark55(88.29420715969317,-1.0614464894944717,0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark55(88.30740594838528,-0.3374771849126308,0 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark55(88.31364355116543,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark55(88.36258528362572,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark55(88.46599406578457,-0.2921854017464123,0 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark55(88.53858548789051,-0.39513571523112745,0 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark55(88.53923214506513,-0.12867782411332673,0 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark55(88.62401564178987,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark55(88.63819168264025,-1.450281997071837,0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark55(88.76850791660539,-0.17665626783590066,0 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark55(88.77567790822924,-1.4417046894464742,0 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark55(88.78297002793067,-1.2267653844168223,0 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark55(88.78499878136594,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark55(88.80796957794429,-0.014824585181852841,0 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark55(8.881784197001252E-16,-0.03514540706637015,0 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark55(8.881784197001252E-16,-0.11457414233048478,0 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark55(8.881784197001252E-16,-0.12086577652556613,0 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark55(8.881784197001252E-16,-0.4372332741554559,0 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark55(-8.881784197001252E-16,-0.770945891089454,-1854.0300837028867 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark55(8.881784197001252E-16,-1.4742937511828274,0 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark55(-8.881784197001252E-16,-1.4999999999999998,0.9999999999999982 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark55(8.882800269255114,-1.1214160821001684,0 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark55(88.84109849097933,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark55(88.84804926624085,-1.3199865020775325,0 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark55(88.85879189277992,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark55(88.89381957322178,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark55(88.9398881331947,-1.4113550848000358,0 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark55(88.98486368944387,-1.0567796982989601,0 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark55(89.00897885045998,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark55(89.07499430595362,-1.3732142742498696,0 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark55(-8.907580120527002E-16,-1.4999999999999964,-1.0 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark55(89.16797195649309,-0.4023077054309896,0 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark55(89.20940277820571,-0.20861498475638518,0 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark55(89.27520138705248,-0.9449806036490173,0 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark55(89.29325931236062,-0.021825052259828226,0 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark55(89.2949957791751,-0.4513112764366043,0 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark55(89.29601210674733,-1.366545914532455,0 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark55(89.34493417418376,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark55(89.38225416884673,-4.6114660733908585E-5,0 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark55(8.939488504354685,-0.06245620257338658,0 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark55(89.40883253635664,-0.6771924604744668,0 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark55(8.946165849347947,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark55(89.48603215941188,-1.4999999999999938,0 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark55(89.48667195801275,-0.14942461331327195,0 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark55(89.4875589997614,-0.9717822888181915,0 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark55(89.52989431554246,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark55(89.57998445640652,-6.315200695775027E-8,0 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark55(89.58304735889399,-0.12452613777407293,0 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark55(89.61146482549677,-1.09129405762451,0 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark55(89.61260954573044,-1.449759080585884,0 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark55(89.7174680710917,-1.4999999999999112,0 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark55(89.76078389688341,-0.26440190008308395,0 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark55(89.80255794004793,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark55(8.991714304772357,-0.3720272339105879,0 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark55(89.93021963854613,-6.871400058904268E-8,0 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark55(89.94063253613359,-0.43186838278411965,0 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark55(89.94546868914969,-1.430119819900561,0 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark55(90.01246420163486,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark55(90.03817547032526,-0.29737415603397466,0 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark55(90.06208123297563,-0.03525815493354568,0 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark55(90.1129869901265,-0.7319239449240137,0 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark55(90.20357017942447,-0.4221002864932577,0 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark55(90.26230083877766,-0.0413682753631035,0 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark55(90.26473336646126,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark55(90.28177102261213,-1.4853958213608678,0 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark55(90.28933471300394,-0.26344221419534364,0 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark55(90.33705669633672,-0.049626255413707694,0 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark55(90.35084187293171,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark55(-90.36517900604294,-1.1912778925107506,16.90117639340202 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark55(90.37505974902484,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark55(90.39639447467977,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark55(9.04188242985244,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark55(9.05046380498682,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark55(90.56086974803875,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark55(90.64384659696586,-1.1268622672293844,0 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark55(90.64675787687608,-1.2929624740690713,0 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark55(90.68476489125314,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark55(-90.68645172680321,-0.8071344002854526,0.9999999999999998 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark55(90.68917330866051,-0.34991227919520307,0 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark55(90.70584841277113,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark55(90.7488307766929,-0.5470160467485095,0 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark55(90.79943768321942,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark55(9.080106916078616,-0.8036602220798843,0 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark55(90.83647825677974,-0.13621048588316853,0 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark55(90.85599853811362,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark55(90.89064198810709,-1.4811007207955162,0 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark55(90.91083167294488,-0.3381476489494588,0 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark55(90.94541656751093,-1.4999999999998614,0 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark55(90.95072709684342,-1.2898224885286425,0 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark55(90.97117111836498,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark55(91.0307859330181,-1.087266324095597,0 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark55(91.03081744735235,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark55(91.08520569236383,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark55(91.0896235502477,-0.02819203993650926,0 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark55(91.12053121139215,-0.1485546266713662,0 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark55(9.112215868320908,-4.094557087640383E-10,0 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark55(91.14174263359773,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark55(91.18069304024593,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark55(91.18730036156512,-0.1313228523935629,0 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark55(91.1958213960263,-0.7075083916931106,0 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark55(91.28246321766773,-0.027665961119031246,0 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark55(9.130967806821339,-0.1576513317113929,0 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark55(91.4479409627175,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark55(91.48278306614398,-0.7034906514872716,0 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark55(91.49145196086377,-0.232492228483272,0 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark55(9.156102212125731,-0.048373055060859205,0 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark55(91.6142737977386,-1.4997387582989024,0 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark55(91.6335695628037,-1.235294493249512,0 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark55(91.65507301290639,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark55(91.66557734651718,-0.973455239492446,0 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark55(91.78717463601114,-0.773068053387861,0 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark55(9.180951300537927,-0.008403687759920404,0 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark55(91.87209819492656,-0.1883027998045037,0 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark55(92.04370851365775,-0.5961761717189145,0 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark55(92.08667150564165,-8.737109429568616E-9,0 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark55(92.09394089614867,-0.2824627324147295,0 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark55(92.15803921830705,-0.7001987015946298,0 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark55(92.16517034094994,-0.13461538360529035,0 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark55(92.1692982923853,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark55(92.16979993212965,-0.03069764651060325,0 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark55(92.29710426068377,-1.4999999999999627,0 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark55(92.3266092474974,-0.2651340606519641,0 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark55(92.37042099390342,-0.39870461877814023,0 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark55(92.37697519576784,-0.39977051141210396,0 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark55(92.38240134749765,-1.4825735649859126,0 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark55(9.240738456491712,-0.95126188993793,0 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark55(92.41457015396841,-1.0943358619355514,0 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark55(92.43425903646326,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark55(92.49207142343968,-0.2935159833017966,0 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark55(92.52512826060754,-1.4999999999985114,0 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark55(92.56267380616661,-1.4589986408555458,0 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark55(92.58195473254142,-0.9572582425982006,0 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark55(92.59391502007279,-0.06890661453434,0 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark55(9.263942495918002,-1.1709824328431893,0 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark55(92.7774006114696,-0.9302863794876668,0 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark55(92.79528909565235,-0.18007790772078325,0 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark55(92.82496739475502,-1.2639172201863302,0 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark55(92.91589137673807,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark55(92.9285051992997,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark55(92.9350693545822,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark55(9.299916823190642,-1.4692172251410822,0 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark55(92.9997413422943,-0.43324834850050564,0 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark55(93.06892912811324,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark55(93.07442831949194,-0.9917059518954696,0 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark55(93.08712854436234,-1.2490010849286604,0 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark55(93.10263406083129,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark55(93.10799825654547,-1.1686361319332015,0 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark55(9.313516632231384,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark55(9.31455399886323,-0.8585747921489494,0 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark55(93.20384191894266,-1.3901814522773603,0 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark55(93.2734702797195,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark55(93.31912969992578,-0.008577575538843899,0 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark55(93.32931709105,-0.10762228222621051,0 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark55(93.76097777898856,-1.1258577133508034E-9,0 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark55(93.8745988631999,-0.4550030614012748,0 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark55(93.91628600760751,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark55(-93.97517992578652,-0.26747866246686214,-1.0 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark55(94.01438419110707,-0.43286166927571057,0 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark55(94.02211622816185,-0.9159973425200936,0 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark55(94.03775284569379,-0.030534172652198183,0 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark55(94.08822024869801,-4.0985815859023907E-10,0 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark55(94.09361412870825,-0.9425871743732301,0 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark55(94.12448842037338,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark55(94.12806272735179,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark55(94.13815446034278,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark55(94.21709589271441,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark55(94.24469852362614,-0.5609187337295225,0 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark55(9.427032348762054,-0.4189582593377281,0 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark55(94.32298241180695,-0.7020496588314167,0 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark55(94.35739362411095,-1.004447495576355,0 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark55(94.36067900354413,-1.0224962065873484,0 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark55(94.36452316809209,-0.15738969822161852,0 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark55(94.36796273363328,-1.1422844683482225,0 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark55(94.37171785700374,-0.15254893620733623,0 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark55(94.37614156901179,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark55(94.49316571412173,-0.6206623712811563,0 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark55(94.54421141639577,-0.08161024910246795,0 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark55(94.6019947599442,-1.221293673346225,0 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark55(94.61186406989353,-1.2404610501447366,0 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark55(94.63330380508869,-1.3138896002030425,0 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark55(94.65430304070485,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark55(94.74029272746068,-1.4098415615226827,0 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark55(94.80856910585328,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark55(94.86426455803903,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark55(94.87651084387733,-1.499999999999993,0 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark55(94.90070569784868,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark55(94.9385620084054,-0.02492341771796991,0 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark55(94.99854607777888,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark55(95.00252729268361,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark55(95.09275058579277,-0.2555689740515108,0 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark55(95.11434717227576,-0.3295375430813223,0 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark55(95.17616099492503,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark55(95.18464865786112,-0.8980017988425004,0 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark55(95.19374962673018,-0.6982224959372001,0 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark55(95.1988221242963,-0.0775035483569404,0 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark55(95.23958283351922,-0.30497266420125824,0 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark55(95.30365694383306,-0.8010238614424954,0 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark55(95.3340429301646,-1.4066837453647594,0 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark55(95.37772617720935,-0.6713403435794234,0 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark55(95.39543883105043,-0.6165950139588148,0 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark55(95.41362364599183,-0.9198662864213318,0 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark55(95.4376952591918,-0.2091968105809725,0 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark55(95.53324989964196,-0.5624444341934165,0 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark55(95.56614110460026,-1.1987516249858583,0 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark55(95.62678199075808,-1.0797844734353186,0 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark55(95.66100275731071,-0.15282594643659309,0 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark55(95.69002295057695,-1.4999999999999951,0 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark55(95.69639344025691,-0.08273740904495241,0 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark55(95.75304015757501,-0.06331865882019372,0 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark55(95.81901567816925,-1.308307545105933,0 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark55(95.99842577763832,-0.6158682821983081,0 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark55(96.00713477819885,-7.072923167866929E-7,0 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark55(96.04330546567468,-0.08759099303697582,0 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark55(96.04409706286025,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark55(96.10245145001755,-0.7625467468021636,0 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark55(-9.613640993244859,-1.4999999999999998,-0.5271407383442224 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark55(96.15366164293707,-0.7019328811422507,0 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark55(96.16755568036751,-0.15244616555970608,0 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark55(9.619264050923892,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark55(96.19794006080078,-0.30810963248514955,0 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark55(96.20826444810908,-1.0798040259149753,0 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark55(96.21806820863088,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark55(96.34959998878405,-0.5244256460060972,0 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark55(96.37959888331748,-0.18713989534803055,0 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark55(96.45891116186182,-1.375093954841631,0 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark55(96.48723605283853,-4.9040200448421345E-9,0 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark55(96.55391355405672,-0.02255371112070263,0 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark55(96.64093592118893,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark55(96.67654245451257,-1.0183722055834235,0 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark55(-96.71404098848726,-0.851515120295522,-0.022238575657261395 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark55(96.72546390976498,-0.5560051305070601,0 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark55(96.73891162853477,-0.6731118015324942,0 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark55(-96.74994079106851,-1.3447753451846403,0.43626855685856786 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark55(96.79574830702276,-0.5814793459686598,0 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark55(96.79968057314953,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark55(96.94743462831678,-0.4109935335773258,0 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark55(96.97877779638472,-1.015087527294991,0 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark55(96.98835272590824,-1.499999999999992,0 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark55(9.703489454139145,-0.7447787395551826,0 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark55(97.04118493736416,-1.1511360893142069,0 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark55(97.06002570650412,-0.07877688184181864,0 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark55(97.1017818054546,-1.499999999996021,0 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark55(97.13654497317833,-0.8137929775240869,0 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark55(97.14660451217651,-1.3584053150561672,0 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark55(97.19148375872993,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark55(97.21119673121046,-0.03609253054786521,0 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark55(97.26144524928341,-0.4687714187637124,0 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark55(9.727940848124625,-1.2544484056880134,0 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark55(97.28956645117935,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark55(9.735807837441925,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark55(97.38373306648828,-0.06689936619592185,0 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark55(9.745778832924701,-1.627096962739509E-8,0 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark55(97.47526344578327,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark55(97.49675985511584,-0.6068459166940414,0 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark55(9.751527108019474,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark55(9.752773344969373,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark55(-97.56759411759013,-0.0792804596029143,1.0 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark55(9.763178673987284,-1.0447745724582802,0 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark55(9.766593761678854,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark55(97.68917161434587,-0.7867981862570019,0 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark55(97.7438692723936,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark55(97.80249969187639,-0.7743686828125185,0 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark55(97.80510148751901,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark55(97.83862398822197,-0.19043361083686428,0 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark55(97.84215299417984,-1.089953408771765,0 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark55(97.90221068496027,-0.6237518201460348,0 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark55(98.05276335209848,-0.35721612658920776,0 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark55(98.08472459384433,-0.6111963705860148,0 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark55(98.17136241993472,-0.5059203927975489,0 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark55(98.19268484034643,-0.37152686752092734,0 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark55(98.26603302830004,-1.1876005524629303,0 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark55(98.31133379350103,-0.3610763044617462,0 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark55(98.3310995995785,-1.269209604838395,0 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark55(98.38713416616682,-0.280780996432469,0 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark55(98.39029329035313,-1.2339998142474675,0 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark55(98.48925897854107,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark55(98.51033694971622,-0.5616984373817502,0 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark55(-98.6175283331269,-1.2447842544461059,1.0 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark55(-98.65893809927879,-1.499999928504279,1.0000001950768336 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark55(98.68918285762635,-9.32760242959109E-10,0 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark55(98.72505938528221,-1.1577270256981382,0 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark55(98.753344460969,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark55(98.76609531791439,-0.11798352550020752,0 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark55(9.877197701664997,-1.1926501506883227,0 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark55(9.888363680782291,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark55(98.88764991711591,-0.21867311667489275,0 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark55(98.8933615018916,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark55(99.05733983866148,-1.117841575761374,0 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark55(99.0764119914761,-0.02812642997524506,0 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark55(99.0795798131941,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark55(99.0892879342876,-0.24274103359553434,0 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark55(99.09196769160113,-0.3808286427053559,0 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark55(99.14639419906416,-0.765093144407281,0 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark55(99.19866556263224,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark55(99.24657132532374,-1.1652427509372718,0 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark55(99.31489628288634,-0.4386207169354268,0 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark55(99.3695835423822,-0.4879417354201214,0 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark55(99.55283226985989,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark55(99.55859231033524,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark55(9.958987003850453,-0.38286973789224554,0 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark55(99.59303387768165,-0.0421092128769209,0 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark55(99.59484692506234,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark55(99.6706380579993,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark55(99.73760548585727,-1.2836272872778842,0 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark55(-99.81250490330997,-1.4290626409342893,0.7656351793273827 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark55(99.8192240863147,-0.06533344664823915,0 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark55(99.89984437104516,-0.986983265251709,0 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark55(-99.91667016587706,-0.02054742935213898,-2372.0903043211524 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark55(99.96982249993876,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark55(99.98050033146956,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark55(-99.99999996991806,-1.8020164284938053E-8,-100.0 ) ;
  }
}
