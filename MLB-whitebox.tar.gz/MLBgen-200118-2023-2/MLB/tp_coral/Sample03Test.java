import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(0.01006692037724258,15.900083940173001 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(0.015030640857907951,0.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(0.015333366832917972,-1.5334846069506924 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark03(-0.017489050744676937,-0.5707916586417207 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark03(-0.018386573094131456,-41.815325389255875 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark03(0.019428471517844853,-16.818545377268244 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark03(-0.02615701150731563,1.5707963267948963 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark03(-0.026316898469442407,-86.14454548905127 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark03(0.03291522457324869,1.5431000256151144 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark03(0.03962361987037899,1.5707963267948966 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark03(0.05058402713135331,-14.42922126419409 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark03(-0.052595125523311026,-0.07589663799389446 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark03(-0.05299057170515731,-57.014736243200595 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark03(-0.06794928888157603,-67.84640178814291 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark03(-0.0711653122841211,-29.087569510822945 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark03(0.08094220089995985,-1.5707963267949054 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark03(0.08206420559737769,0.0018070050766781512 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark03(0.08240304970615153,-29.416211455105792 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark03(-0.10014935723809515,-94.27854066268392 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark03(0.1145880733647134,-7.222379749873507 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark03(-0.12311784650920532,55.38459466687647 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark03(0.12913049106194174,0.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark03(-0.13300932680245753,-41.04534755038361 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark03(-0.13724424157427412,1.5707963267948966 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark03(0.17572070075320978,-36.73825807959374 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark03(-0.18093185945721713,25.132741228718345 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark03(0.19076216864341244,33.84723854458761 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark03(-0.23325182791239452,-0.21269931967518682 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark03(-0.23704037236248313,0.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark03(0.25324433252192513,-89.53547906877046 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark03(-0.2536654463634591,0.0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark03(-0.2540030369993592,1.5707963267948966 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark03(-0.25775403635661276,-66.16026923621057 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark03(0.2727778468097989,-67.86711130322404 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark03(-0.28851299290204224,0.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark03(0.28960419946328253,57.32651786397057 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark03(-0.29067204721377493,2613.54144101332 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark03(-0.29496285117662246,0.014590300950251772 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark03(-0.30189298027688594,11.34914276002715 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark03(0.3027066441069992,1.5707963267948968 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark03(-0.3074668802642988,29.561989885119047 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark03(-0.3149444802308149,96.34298172661133 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark03(0.32125593211925096,0.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark03(0.3262981630736883,-98.528462508527 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark03(0.32818648802369355,74.68311959660721 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark03(0.3348871207037341,-64.06776227788703 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark03(0.33678172658924077,-1.2022266214228783 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark03(-0.3382083996514095,54.61006943594464 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark03(-0.3391456202052312,-65.44147428154358 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark03(0.34477227554411627,1.5707963267948273 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark03(-0.4145995723994977,4.297789407985192 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark03(0.42529454029728925,-1.1455017864976074 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark03(0.4518337014347624,-74.63258202192456 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark03(0.45387172563975886,35.38884928394151 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark03(0.4586038257513364,-13.438351968642493 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark03(0.4754909746108562,-1.1714288295993005 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark03(-0.4790657055010714,-1.5707963267948966 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark03(0.4820839211965193,-76.97139237378745 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark03(-0.5236001783932791,83.7758054985228 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark03(0.5422042163780922,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark03(-0.5537345788706679,-33.5404574415635 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark03(0.5560897590680592,1.2854636223129695E-6 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark03(0.5589311616474966,-2577.245543804523 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark03(-0.5738824834548595,-12.240147787837 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark03(0.5771929298642808,100.29343196245904 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark03(-0.5776995918872161,0.0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark03(-0.5778329971110026,135.65005595691747 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark03(0.602983632761962,-100.0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark03(-0.6231022039544492,-81.08947434631095 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark03(-0.6236304702116824,0.0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark03(-0.6263469105889374,100.0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark03(-0.6291136987583419,74.0465840952932 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark03(0.6541750383371685,-0.3622438500413959 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark03(-0.6563583551793005,-0.4923185580184715 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark03(0.665289807090879,83.40750033177994 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark03(0.6693720000023404,0.0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark03(0.6806371922676638,-49.37532332290946 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark03(0.6960733173445208,0.0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark03(-0.7127756603280684,0.0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark03(0.7214772092641686,2440.0925766347777 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark03(0.7217820527267924,1.5707963267948966 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark03(-0.733363957718999,1.5707963267948966 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark03(0.740479168130884,-93.41746244902978 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark03(0.7426720945143983,-1.5707963267948966 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark03(-0.748192087152626,1.5707963267948966 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark03(0.7525268356153272,-5.733080510627463 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark03(0.7599881180033412,-73.73474660687098 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark03(-0.7636411882384555,0.0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark03(-0.7659211807177319,85.80875794973781 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark03(-0.7702162899937719,-1.570796326794897 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark03(-0.7979426244648913,0.4166114521383244 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark03(0.8019301411756234,100.0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark03(-0.8108510333361104,2429.0426123571697 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark03(0.8137658183790055,0.0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark03(0.8141179637297986,42.486913232110034 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark03(0.853596559861765,-41.271081750085486 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark03(0.8620384805940198,-96.17680403529765 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark03(0.8756924187537105,-66.15567649685252 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark03(0.8870049521884192,32.09971791050441 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark03(0.8971479491434451,21.44328203417571 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark03(0.9080874037493595,-1.5707963267948974 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark03(0.9350628000162275,-1.5707963267948966 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark03(-0.9390505974974388,-32.70291546342622 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark03(-0.960513740464612,-57.02474809802902 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark03(0.9641121721798341,-100.0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark03(0.9790844218734653,-0.1774919061084193 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark03(-0.9863812703359102,-0.8619481987205634 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark03(-0.9998740833457995,-48.13791137719899 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,0.0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-0.18143448025653675 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,0.2760033726439183 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-0.5542758464090541 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-100.0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,135.2625930611727 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-1.5707963267948966 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,1.5707963267948966 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,1.5707963267948968 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,2.220446049250313E-16 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-2.659071904180198 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-40.54575439760404 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-45.51395529376021 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,5.7481117072610494E-8 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-90.81206186235487 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark03(10.020802022356506,72.60386037545993 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark03(1.0036648924835987,-42.81258604961411 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark03(-100.52927953866359,-3.2482386841615027 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark03(-100.53090222775693,1.5707963267948966 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark03(-100.53096259633769,130.3760516152464 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark03(-100.53293822887473,-143.0049657383356 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark03(100.69577727081489,0.0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark03(-100.76805087553072,-96.25800259097271 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark03(1.0078640583800036,0.0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark03(101.11867916995926,-68.28774232763551 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark03(-1.0112982900890397,82.99435450070773 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark03(1.0136717095519092,20.818965875686466 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark03(-10.162618229979742,-24.80613489333215 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark03(-10.172942763973586,-69.93766990256614 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark03(-102.01883605306324,-53.87668734300776 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark03(1.0203751404419648,-1.5707963267948966 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark03(-10.211557802674072,-168.08469274615575 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark03(-10.214744838496827,-89.78885209269048 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark03(-10.230166470681937,136.35710825380548 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark03(-1.0248551625885933,-4.738738509040219 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark03(-10.248893551809303,1.1353240793119994 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark03(1.0310462453082572,185.38164800638202 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark03(-103.29051727209945,33.368763159056556 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark03(-10.342208991138074,38.85321325015312 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark03(-10.354938556946003,-1.5707963267949054 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark03(-10.388782299560612,-181.60558192020434 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark03(-10.396905350464166,0.0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark03(1.039831411921513,100.0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark03(-104.16961673021484,1.5707963267948974 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark03(-104.46269419377546,-1.5707963267948966 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark03(-104.8527763777821,0.10167568558973772 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark03(-104.90831070920798,25.46778441476844 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark03(-1.0541395331357613,-53.91244961624205 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark03(-10.585316222173,-0.7014294890666974 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark03(-10.641700740780522,0.4771398751483232 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark03(1.06440327903438,-44.48869019801762 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark03(-106.81415403675024,0.0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark03(-106.90599943699036,-130.28066376485503 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark03(1.0693401590620173,88.46605046824709 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark03(-107.54806012854797,-3.2224267164615696 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark03(-107.99978518036383,40.45554312818327 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark03(-108.01876377355167,-12.591081368583929 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark03(-1.0842021724855044E-19,45.55309347705199 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark03(1.0842021724855044E-19,92.67698327973801 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark03(-1.084202301088628E-19,-86.3939082614725 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark03(-108.80133518080109,-1.5707963267948966 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark03(-10.911949583439508,4.727978325633757 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark03(1.095185936023737,-1.171893202181332 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark03(-10.975179668057194,-1.5610577595438357 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark03(-109.95648117377388,-1.5707963267948966 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark03(1.1001076902447284,-0.4164932375236289 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark03(-1.1102230246251565E-16,0.0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark03(-11.139630650525476,-23.90103250904751 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark03(-111.66889611731946,-39.26990845705122 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark03(-11.174741890253955,-38.045512970230135 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark03(-112.05695775052524,31.595350822016712 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark03(-1.1268760743065918,-1.8344609720238907 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark03(-112.74634147744064,135.51492936950447 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark03(-112.89712574922987,28.73078048398429 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark03(113.46379753747127,56.036935643229185 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark03(-114.16972774439577,-11.086882200897367 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark03(-11.43513840674781,135.23067730556585 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark03(1.1547690076014514,-0.41602731919344527 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark03(-11.560355250976782,-32.47796990950079 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark03(-116.22576909528843,-78.46615172896401 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark03(-1.165378544251468,47.5248599381361 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark03(-116.65446697971247,-43.994442530470906 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark03(-116.87553534703241,-4.9780854756481565 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark03(-1.1754943508222875E-38,36.1283157826654 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark03(1.188200176133435,-3.859124919124011 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark03(-119.06690587787155,62.55243499287814 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark03(-1.1912101326983553E-7,45.6836011636124 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark03(-1.1928919173039827,-0.11007257434363227 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark03(-119.36049423306139,44.047409256326944 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark03(119.52076853570478,-37.758878400992366 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark03(-11.986412431972255,43.353095067121075 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark03(-120.00993232540942,33.55409413205666 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark03(120.25542567610572,-5.587293820078263 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark03(120.58097972357768,66.19924013219175 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark03(1.20685545226047,2626.896581575019 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark03(120.86079195955442,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark03(-122.34404505713222,124.0929358397577 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark03(1.2249865111657812,-90.9963046430595 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark03(-122.52134368058081,152.36722516776308 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark03(1.2259550229604566,-72.68518785256357 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark03(-122.90324873717434,0.0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark03(1.2325951644078111E-32,-89.53539062730913 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark03(1.232595164407831E-32,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark03(-1.232595164407831E-32,-1.5707963267948963 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark03(-1.232595164407831E-32,-1.5707963267948968 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark03(-12.360344481660547,32.546299538699884 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark03(-1.2370848089949955,100.0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark03(1.2393064432747043,-44.368172602369 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark03(1.2528759913450795,93.61431305932189 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark03(1.2549992753604367,111.52694852884424 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark03(12.566370615600936,-1.5707963267948966 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark03(12.566408748140214,-1.5707963267948966 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark03(125.66410820187642,-80.11061266542829 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark03(-12.568327719327948,1.5707916381379619 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark03(-12.568352501552871,95.81857593411496 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark03(12.568365297235081,-32.986712062064356 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark03(-12.569088057747603,29.845130209110312 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark03(125.81623931974099,17.827234847734587 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark03(-125.8760094884735,0.0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark03(1.2589459247611519,37.8768900551323 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark03(1.262381013747897,10.54154218897488 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark03(-12.629967955353365,0.12184556224518249 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark03(12.633590118385973,11.062793791591076 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark03(12.677194099686929,-1.5707963267948966 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark03(12.691370653106391,-14.030207694986558 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark03(127.09077048443486,-6.139453321227817 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark03(12.720415743714524,1.5707963267948966 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark03(-127.23756190701992,68.30314430178927 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark03(-1.2863337653368547,-30.83935451531042 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark03(-1.28735252159712,78.25637253454705 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark03(-12.880254018016595,114.79092089689529 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark03(-128.80656377171442,67.54424205218052 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark03(-128.98083543137173,-49.549928654423205 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark03(1.289867697261963,-1.5707963267948966 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark03(12.90138367526452,-95.66696091734784 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark03(12.925494240836471,-1.4080239579048985 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark03(-129.44331244262742,0.042344063969019415 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark03(-12.959916918924037,-53.67796050887781 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark03(12.968342707333377,1.5707957381055995 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark03(12.976382396587653,69.32934779931747 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark03(-1.299141604310263,-40.4738832059725 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark03(-1.306102164436775,-14.429212892076876 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark03(13.096498824972826,0.0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark03(-13.119932114300653,41.47954833535249 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark03(1.3173684553390625,16.312235053868605 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark03(-13.227749243869223,-22.9005662724134 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark03(-13.269183818448905,-2637.50952513395 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark03(133.40134541270155,-44.327492426229284 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark03(-13.343817383341882,-1.9844746946549194 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark03(-1.3372086876096745,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark03(-1.3379353444267672,44.16606932274985 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark03(-133.81007790599892,44.43772982475868 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark03(133.8803762463829,-152.6840526653329 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark03(-133.88576745204688,21.623068900647887 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark03(-133.90090802768205,-15.324743017833129 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark03(133.9105292641371,-84.17766252708793 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark03(1.3391190810905973,-6.712388980384691 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark03(13.412993391313377,-69.18810259652214 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark03(-134.18876499844004,-23.449689884490013 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark03(-134.21356593907402,-32.98672286269283 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark03(-13.441329783213092,-67.29027614498901 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark03(13.457880987952382,89.62320158315465 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark03(-135.0907016955469,1.5707963267959253 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark03(13.529094738519484,106.20607801941838 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark03(-1.363016990185295,-1.5707963267948968 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark03(-136.40642436341471,56.22590878082622 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark03(-13.674941580083313,-1.5707963267948966 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark03(13.68780599536008,1.5707963267948968 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark03(13.739148543356833,-25.81598713698399 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark03(-13.746726995092985,57.11647138920068 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark03(-13.77994538420755,45.11028489320622 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark03(13.804791854339308,-143.38405252650932 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark03(13.81187788221851,-1.3519081441946421 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark03(-138.23007674974468,-1.5707963267949099 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark03(-138.23426885820967,1.5707963267948966 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark03(-138.2794135292802,-1.570796326794653 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark03(13.873262180933702,-1.5707963267948961 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark03(1.3877787807814457E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark03(1.3877787807814457E-17,58.11952512656743 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark03(-138.82840884372303,1.5707963267948966 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark03(13.889059434749667,0.49175178128210606 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark03(13.90597032350162,77.39857032771485 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark03(-1.3907535063712289,-19.451359620783947 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark03(139.25214418894018,72.48374752558004 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark03(14.013058754028775,0.5698141306611683 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark03(-1.402812038980251,-2524.129254935514 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark03(-1.4087130175789502,1.5707963267948963 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark03(-14.122449656291991,-43.955207858458856 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark03(14.137166941154069,100.0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark03(-14.148480297042369,-42.63847601719113 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark03(14.175456261514519,-25.094548054569614 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark03(-142.0666949159162,12.566370614359172 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark03(-14.223164036450104,-72.0126619843823 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark03(-1.4232789322885533,0.0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark03(1.429512369576118,12.854896161657312 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark03(1.4307601535666339,-1.5707963267948974 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark03(1.439291888426867,0.0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark03(-1.442950979463739,0.0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark03(-1.4435843159324273,-84.53465078348523 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark03(-144.50411372472556,-73.82742735934603 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark03(-144.51477158486404,-0.5701955224009906 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark03(-144.52907103370467,-0.018810867578090314 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark03(-145.09595332757118,-84.91200169056803 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark03(-1.4518282589808635,-1.5707963267948966 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark03(1.4545231944642847,0.0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark03(-1.457407512414623,-0.05350654872009313 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark03(-14.599130286505172,3.997487453518577E-4 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark03(146.09869602781149,-31.792718233335776 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark03(-146.47790272245706,-100.0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark03(147.2990669537873,-34.85210769170435 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark03(-147.6509663836259,1.5707963267949054 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark03(-1.4776120412979603,0.0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark03(-148.7657512769782,-88.4244940690512 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark03(-149.01922614763154,-93.36755595471963 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark03(-1.494947899886276,31.750953765733673 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark03(1.4997002599440536,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark03(-15.017403579343735,-19.70014167394673 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark03(-15.067935108200572,22.227444262378484 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark03(-15.11553484782715,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark03(1.5145632918174186,45.46965150056146 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark03(1.5163308728900091,38.49296518104528 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark03(-152.05354168047518,4.541486509663336 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark03(-1.523139564322538,0.0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark03(1.5296684816740667,-71.54975866842592 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark03(-153.1180516224178,0.0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark03(-153.93088926813533,1.5707963266835712 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark03(-1.5405346143784606,12.861664335735954 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark03(1.5407439555097887E-33,1.5707963267948977 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark03(1.5407439555097887E-33,17.278759594743857 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark03(-15.473327965378473,0.0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark03(-1.5505132588563129,100.0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark03(1.5507117499742886,-0.0054138647314493854 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark03(1.5510316785914755,0.0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark03(-15.559972232559318,-2634.778750927097 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark03(-15.564127843096283,-73.64119683585635 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark03(-1.5593632332170593,-1.5707963267948966 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark03(-1.5603766891240025,-107.18792555284054 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark03(-156.05292694205696,-49.574585363381956 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark03(-1.5618814676587665,0.0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark03(1.5619135657018017,75.38934092506193 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark03(-1.5627948240191496,-71.56404600859436 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark03(1.565941159227453,-2593.9685243074623 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark03(1.56853796870607,21.991148575128552 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark03(-157.07595604751137,92.67698328050527 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707942428506183,25.438617901233812 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark03(1.5707961276020845,0.5277808896298732 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963246397092,81.99659843911235 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963263455698,78.53981634018764 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark03(1.570796326788893,75.39822368614738 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267891987,6.7123889803865335 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark03(1.570796326789577,0.0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267910783,28.274333882309055 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267928313,37.699111843078384 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark03(-1.570796326793119,-59.690260418208524 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267933178,59.69026041820521 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267935123,94.24777960769346 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267935439,-65.973445725381 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267936917,9.424777960770784 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267938303,0.0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267942775,69.1150383789755 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark03(1.570796326794317,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267944767,78.53981633974377 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267945304,-69.11503837897406 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267947238,-34.55751918948495 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267947704,-37.873255811835335 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267947953,-3.0445347059676275 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267947953,4.943620236336983 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267947989,39.070721314503544 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948477,44.53116008581532 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948735,-9.424777960770193 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948912,1.570796326794897 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948912,-44.96517843877608 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948912,93.4175113435333 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948912,-9.593959383143352 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948915,1.5707963267948963 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,122.68957017327094 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,15.414042858196808 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,-1.5707963267948966 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,1.651671258319226 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,-17.276947719082898 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,25.95471794935086 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,-2602.929424709702 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,2.895482397603888 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,-47.12388980384737 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,-49.31258162997971 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,58.74888886391852 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,-67.72845083695579 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,72.03160615398335 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,73.58593553678902 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,75.35938367325157 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,78.74038272377625 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,-81.79555911549099 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,8.220951592674487 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,-92.68750547639216 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,-94.2477796076938 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948954,-33.43672531798609 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948957,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948957,12.28780922106634 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948957,-17.278759606155226 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948957,-27.127970102914745 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948957,34.59098549856458 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948957,3.552713678800501E-15 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948957,62.12773849450494 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948957,-70.72413091971994 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948957,82.74704268418822 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948957,-8.472312330513628 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948957,87.12382243029269 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948961,-1.5707963267948966 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948961,-18.081245737006753 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948961,34.208890032129204 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948961,4.712388980689353 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948961,47.65485256901164 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948963,100.0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948963,1.5707963267948966 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948963,32.042801793768575 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948963,38.597270548174855 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948963,-44.44971411419816 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948963,53.95454377536727 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948963,-64.01190511316685 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948963,6.429296786009165 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948963,71.11534432126408 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark03(-15.707963267948964,0.0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark03(-15.707963267948964,-1.5707963267948963 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark03(-15.707963267948964,-51.82151627246107 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-0.0016878958220129469 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0.003252723793152626 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-0.011330372650344943 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-0.016030978222836834 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-0.03023432532704362 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-0.17336498419277035 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0.19863532951641302 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-0.2475961150564091 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-0.43838403703160994 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0.48636241447679934 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,0.4970895182043534 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-0.5315715141750773 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-0.5505434485128778 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,0.5707922145682353 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0.5896090499777866 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-0.6209667144913145 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,10.770967405286983 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-10.958625795602442 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,10.995574287564224 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.159765348377947 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-12.231528462770253 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.2688628805765831 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-12.80702985800182 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.3172939827779402 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.37634848196417E-4 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,13.79867764559806 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,14.302984435713162 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.4340456407969242 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,14.429203676441368 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,14.432680655966692 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.4593502680729422 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.4981796126503597 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.4986802811447244 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.570794193881503 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.5707963267880445 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.5707963267918696 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.5707963267948895 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.5707963267948943 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.5707963267948957 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.5707963267948961 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.5707963267948972 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.5707963267948972 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.5707963267948972 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.5707963267948974 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.5707963267948977 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.5707963267948977 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,161.79277401313811 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-16.215375738680578 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-16.418126699028686 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,16.441633974085647 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,16.645540231450763 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,17.278759594743864 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-17.278759714176697 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.734723475976807E-18 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,18.217415139903895 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,20.494632992479296 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-21.09361439726262 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,21.54689004037178 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,23.296199893608716 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,23.492504512016836 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,2.355611783240352 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-23.56242401026664 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,24.152181567071402 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,2428.6022167900937 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,2460.568240013018 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-2.5006725650966537 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-25.132741228773547 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-2.526514628534244 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,25.292236847518353 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,2541.802327866091 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-2552.9729376363803 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,2603.1832195864 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-2605.8162384171264 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-2613.5508655965423 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-26.509443153271548 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-26.619296202908703 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-2.721810795903004E-11 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-28.27433388230556 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-28.630038007739245 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-29.484827413297364 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,2.9534803505412457 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-29.845130210034487 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,30.92987607669724 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-31.415926535900383 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,31.41592653590074 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-31.54343423210699 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-31.761163826004562 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,32.273698953514355 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,3.2388273446425333E-6 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,32.48522627053902 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,32.98672283673755 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-33.18910192408478 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,33.51786553391197 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,3.3616380560527523 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-33.80801510985696 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,34.512934964095564 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,35.94905937239966 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,36.8270873138454 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,37.71761356788796 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-39.26990816987238 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,39.26990816987241 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,39.96965013658581 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,4.0473350436313066E-14 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-41.975971376112746 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,42.18160228799256 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-42.41167113866525 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,43.96790249504862 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,44.170216880925835 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-44.23848092718241 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,44.451370285303916 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,45.04274660873118 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-45.17927968605978 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,45.20962127623878 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-45.43882482721586 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-45.48358382381029 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-45.553093477051995 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,45.55309399608818 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-45.555046602052 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-45.62943945144349 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-45.78802991900315 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,4.596659230013966 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-46.59187221318335 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-4.712388980356996 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-4.712388980384623 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-47.12388980384725 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,4.712388980384748 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,4.714342105384691 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-4.743638980384772 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,47.643135949035724 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-47.802789012715685 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,48.69468613015039 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-49.11229340275736 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-49.42873163931912 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-50.08261076300553 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,5.012384246753063 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,50.26548245743572 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-5.033256747538212E-4 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,51.240231344626544 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,53.033769332120684 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,53.36645632319381 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-53.4070751110259 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-53.73620069426437 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,54.898907245033 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,54.977871437821406 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-55.04654731444949 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-5.564287900310422 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,57.46558655842921 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-58.11946409140493 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,58.11946409141104 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,58.11946409141119 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,58.15071409141118 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,5.92380752269354E-16 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,5.968935612534048 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-61.41153585256515 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,62.47220782028613 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,62.635852904451596 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-6.283185307176202 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,62.83185307179641 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,6.34492458573277E-13 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-6.429204183386632 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,64.40264939859074 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,65.96171385676607 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,65.97344572538458 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,65.97344572538968 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-66.17364439340398 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-66.20053633380867 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,66.52342009459079 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-6.668474416657298 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-67.1829373761908 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,67.24986105839751 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,67.56949506497 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,68.82469042948226 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-69.050403777849 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-69.11503837898026 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-70.85632168375385 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,71.52291849347179 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-7.164792490557102 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,7.2313692511613015 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-72.37841171265349 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-7.27074919328347 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-73.01254865731161 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-73.23247939923667 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-73.37650855244149 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,73.82742735936013 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,73.82742735936014 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,75.18590734612118 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,75.39822368615503 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,75.78684596611335 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-76.53442044461211 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,78.13314497989757 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,78.53981633974537 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-78.94759070329731 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-79.55707881377255 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,80.11061266653905 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-80.11061266653971 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-81.5640653623551 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-81.62098705551608 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,81.68140899333326 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-83.04039612546643 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-83.2522053201295 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-84.78279690846371 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-86.36733084956663 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-86.39379798862048 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-86.8307508218132 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-86.98743753223656 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-87.10057400498177 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-8.771808846818413 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,88.30588688493697 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,88.48485158509556 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-92.67698328089888 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,92.67701379847703 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,92.67717392069616 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,93.64476692651334 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-94.24777960769264 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-9.424777960770953 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,94.25090160690658 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-9.507402817937944 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,95.81857593448869 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,9.69140900682315 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-97.11154781201446 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,97.38937226128355 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,9.968858483062354 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,99.83627929668252 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948968,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948968,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948968,-98.16479084253368 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948972,-15.158894604060265 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948974,96.86680914004697 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948977,81.88719570651338 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,-100.0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-1.403559036933338E-8 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,-14.433814042868661 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,-157.07963267948875 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,-18.7956229901993 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,-2569.868998032358 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,27.607486927637922 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,31.19753419519853 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-38.989832480148586 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-69.68786498164246 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-82.40386877476044 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-9.67040258413536 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267949003,-72.25663103256811 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267949019,1.5707963267948961 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267949054,-0.0024147143811890925 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267949054,-1.5707963267948968 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267949054,39.07519145363639 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267949054,66.44440785750902 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267949125,-190.06733210493243 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267949159,1.570796326794897 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark03(1.570796326794936,-7.171678827030336E-31 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267952454,2.2204460491501462E-16 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark03(-1.5708439324908137,-84.82295404122704 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark03(157.32280665752535,1.0766871853862247E-19 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark03(157.33082412164117,138.11325262642683 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark03(157.5525639233572,-89.35929490188326 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark03(-160.5597824823113,6.0575852418631756E-27 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark03(-16.087212364795736,0.0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark03(-16.114166743066207,0.12746155431945194 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark03(-161.52064933157945,88.23596662880911 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark03(-16.177906012489665,0.9504876307776386 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark03(-16.269191317503854,0.0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark03(-16.28763628245558,1.5707963267948966 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark03(-163.3627260363418,1.570796326794898 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark03(164.51016245912027,-0.4782922182907135 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark03(-16.599607031007267,-72.16484479494326 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark03(-166.51222314073289,45.55333761775739 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark03(-167.4757465567199,2612.0174305006954 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark03(-16.816113535076553,-48.6946988624861 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark03(-168.6423775961414,1.5707963267948966 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark03(-169.26296303790863,61.26218703504446 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark03(-169.53757165751483,-136.15901197017544 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark03(-16.965434594576806,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark03(-16.972479582189536,1.570796326794897 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark03(-169.73584231586108,-1.5707963267948983 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark03(-169.80377994968217,48.01197609966454 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark03(169.93196900492018,0.38768499311463783 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark03(-17.002932638605174,18.83908135993441 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark03(-17.020568238880657,-2476.773826281587 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark03(-1.7053773565214687,9.559358990495952 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark03(-17.07115020394123,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark03(-17.10565633897686,100.0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark03(-17.124471276310672,-42.478791031364224 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark03(-1.7151244994428829E-15,-1.5707963267948983 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark03(17.261599953823634,-12.954554712966498 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark03(-172.73681357023798,-1.5706553463361124 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark03(-17.278759594740293,1.006644338165387E-12 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark03(-17.278759594747616,0.0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark03(-172.78874405075481,-45.55504662970535 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark03(-174.54683386923318,3.552713678800501E-15 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark03(-175.69166281881982,39.032382387663816 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark03(-17.573920691618554,35.543987749701245 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark03(-175.86951603023257,92.67698328089884 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark03(-1.7595261298884282,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark03(-177.45354547218884,4.397089632888225 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark03(-17.76264113036828,2638.4484878657186 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark03(-1.7763568394002505E-15,1.5707963267948974 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark03(-1.7763568394002505E-15,-36.55443683760667 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark03(1.7763568394002505E-15,55.60447779502649 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark03(-17.883093568348233,-97.37857957309399 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark03(-17.961138620574516,-69.22401165245047 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark03(-17.993900374655155,94.4149393180756 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark03(-179.99446360049603,2592.6485097331783 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark03(-18.041648765867734,0.7628891711238712 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark03(-18.400623728450014,0.005426728709915069 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark03(-185.50339363607307,-120.58443007036078 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark03(-186.01367212326141,94.83151635346945 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark03(-18.642655087470743,-81.49131467815644 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark03(-186.67499349200597,36.554983837190576 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark03(18.715463356781,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark03(-1.88079096131566E-37,-95.81857592190681 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark03(-18.832219972391012,67.5615780013283 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark03(-18.849555921535448,-1.5707963267915845 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark03(18.849800761440036,10.995574287561203 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark03(-188.4980086349948,54.97787144021405 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark03(-18.857368421538762,64.40264862894409 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark03(18.885103806969873,-101.83193120708764 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark03(-18.92668469143399,25.808883768862046 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark03(-18.936457553926456,-25.08643305142057 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark03(-1.9022249427330078,-26.747785950600292 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark03(-19.04626035674839,66.48481660728166 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark03(-19.13171257013279,78.17371121490174 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark03(19.13174501494176,0.13960437810484283 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark03(19.16314443942258,-64.08906088070694 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark03(-19.189492746200102,-48.69469456614537 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark03(19.20143800574543,0.032176358645165166 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark03(19.257613581188068,-76.38494504328546 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark03(-1.9259299443872359E-34,1.5707963267948963 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark03(19.2945747031904,0.25357772529872485 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark03(19.35289806977619,-14.450721728572006 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark03(19.368100829154237,6.617162534530906 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark03(-19.416347029403454,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark03(19.4780859773866,36.65577358329062 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark03(-19.530984686149953,137.26465194793886 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark03(-19.584128431804597,62.42652368568682 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark03(19.63147239917815,-45.869371649257886 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark03(19.671851705997607,74.64972314381899 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark03(19.77830246207087,1.5707963267948966 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark03(19.792662407851907,-41.46166357532438 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark03(-19.91292128013803,1.5707963267948983 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark03(-19.96366428537509,90.0625617249388 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark03(19.96857014438026,22.286162285076784 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark03(-19.997728849784913,-33.947795684564184 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark03(20.047307162220292,88.25153284164334 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark03(20.06636133434575,1.5707963267948974 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark03(20.094694419461874,-1.5707963267948966 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark03(-20.128803686304806,94.3705836880132 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark03(20.180130066386482,-73.82031779085624 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark03(-20.194668728356213,-82.77521604945366 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark03(-20.2082867444538,78.32775083586498 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark03(-20.20915024091714,33.14853756618388 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark03(20.281456786490182,66.15162159297456 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark03(-20.282649771552162,1.570796326794897 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark03(-2.0297169016968155,42.780766128638135 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark03(-20.302525170246437,0.0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark03(-20.33576438953447,-1.5707963267948966 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark03(20.382968108305434,-2509.381046750184 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark03(-20.452660387565572,-68.71666878217673 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark03(20.517418154840513,-0.12358898118610494 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark03(-20.519378179855963,0.006902546442294328 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark03(-20.547551860173414,3.268792265429552 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark03(-20.56816717054483,1.5707963267948966 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark03(-20.584737513266024,-14.441793595938826 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark03(-20.598520196040383,-72.53045942143433 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark03(-20.613880969630372,-1.5707963267948968 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark03(20.635496352439947,-44.1974412543634 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark03(20.64316324379172,-1.5707963267948966 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark03(20.671663914445347,-1.5707963267948966 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark03(20.805173419323154,-147.34530312654726 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark03(-20.83343736603311,125.24877850458063 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark03(-20.834327610801985,4.562720067803134 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark03(-20.86906227770325,-1.5707963267947704 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark03(-20.880348687373825,-1.9223316206435805 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark03(-20.893986793042835,9.919133025230524 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark03(-20.958942849965464,-0.005002936212996917 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark03(-20.959801415498717,-28.05069327482795 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark03(-20.973819528823,-94.69851863797102 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark03(21.063857874128857,-37.52077077846179 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark03(21.269456310656935,29.190483787027034 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark03(-21.492466949062823,140.58048004966616 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark03(-21.573458777878546,-2.7701157281358633 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark03(-21.612643479285207,51.999165686177165 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark03(21.648368176320158,5.055169379193085 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark03(21.659673384616617,-55.50361861849786 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark03(-21.66940845945674,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark03(-21.678950964471994,19.840164490036244 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark03(2.1684043449710089E-19,-4.712388980384689 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark03(-21.81085054719173,5.167420937563634 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark03(-21.856345545949637,73.07597804315469 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark03(-21.876215680366073,-4.6083102867090044 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark03(-21.967959004896116,1.6004295928529113 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark03(-21.978995347579662,0.25932959377757314 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark03(-21.98945178865117,51.8242766259803 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark03(-21.98971248114457,1.5747240464080832 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark03(-21.991128575415093,-2.070796367077083 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark03(-21.9911464167533,61.26301458369097 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark03(21.9911485751278,-76.96950829729231 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark03(21.991148575128335,-1.570796326794679 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark03(-21.99114857512836,-32.986722856300105 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark03(-21.99114857512855,1.5707963267948966 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark03(21.99114857512855,-1.5707963267948966 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark03(-21.99114857512855,-32.98672252356599 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark03(-2.2050430341317507E-34,-14.137166941136462 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark03(-22.071074333048728,-71.03052090403452 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark03(-22.09693777015713,0.0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark03(-22.147047701390107,1.5707963267948966 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark03(-2.220446049250313E-16,-1.5707963267946592 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark03(-2.220446049250313E-16,1.5707963267952028 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark03(-22.27926569923498,-4.723715512153762E-9 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark03(-22.315780690241855,8.855055526930566E-5 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark03(-22.37055893685924,45.42946617848247 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark03(-22.446181801976223,51.607165481627476 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark03(-22.50456395729789,-60.71633304721076 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark03(-22.597369360699403,43.01772160903306 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark03(-227.9761084025976,-95.32506685789289 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark03(-22.836631490530948,42.817135704320535 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark03(-22.89722686461137,21.844674307840762 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark03(-2.2972047100237782,-14.981554884720085 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark03(-22.977246211188728,48.6946861306418 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark03(-23.031757545745535,-80.73253639184468 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark03(-232.48824114162824,32.98672286268702 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark03(-23.343433457978236,31.745043362163802 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark03(-23.3830204024664,-1.570796323985721 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark03(-23.413276711241,-32.82004265970861 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark03(-23.502642246128378,-0.13267383770805904 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark03(2.350988701644575E-38,-1.5707963267948977 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark03(-23.741789705563225,20.430207017309513 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark03(-23.81199607305625,0.44754735977527954 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark03(-23.84024093807388,31.694222572048364 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark03(-23.873628815141217,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark03(-23.887492404119683,0.34675440839984645 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark03(-23.963347447179913,-4.0729934021892946E-5 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark03(-24.026023398788453,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark03(-24.07197733987875,0.5100324379553 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark03(24.144028779175343,-1.865035206724869 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark03(-24.152303102582266,-24.540500933610105 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark03(-24.158179151670893,-23.696624497951348 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark03(2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark03(2.465190328815662E-32,45.55310656268043 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark03(-2.465190328815662E-32,98.9601685880786 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark03(-24.779138406685636,11.601085594090279 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark03(-24.861840124508277,0.0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark03(-24.957438305339764,15.31531397794133 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark03(-25.104050363973542,39.588065485824956 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark03(-25.13274122871834,-1.5707963267948966 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark03(-25.132741228718363,-1.5707963267948966 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark03(-25.132741228718782,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark03(-25.132744210625205,-1.5707963260694773 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark03(25.201265496916136,-59.11948989237108 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark03(-25.218127945329215,-2.39628267856358 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark03(25.232666325887617,1.5707963267948983 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark03(25.26527184831371,51.43064329801298 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark03(25.26604576234152,84.40029531409948 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark03(25.29174687784643,-1.4273091464487124 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark03(25.349639252639147,-58.46679298383663 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark03(25.366141234393638,-88.49852334251078 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark03(25.463619331005468,55.357949679413075 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark03(-25.491915790558995,22.29541837492191 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark03(-25.559337858640596,-48.789510629745415 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark03(25.56108381394681,0.45359156220983377 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark03(25.562420503060505,-62.3770990720101 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark03(-25.573153985181023,-8.08648356372517 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark03(-25.62648430323251,-55.79525155068984 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark03(-25.70695245822317,-7.578839241998381 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark03(25.708698380090397,-89.18361055637013 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark03(25.792360375057584,1.5707963267948966 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark03(-25.79735307174976,0.0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark03(25.805516358881817,-149.64237528622 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark03(25.84217731202488,1.5707963267948968 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark03(-25.894157753058437,-52.061160055236066 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark03(-25.94495176395186,0.0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark03(-260.7445738850435,1.6332963288415605 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark03(-26.24518438086907,-45.53601527465203 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark03(-26.25160892816045,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark03(2629.1391245738287,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark03(-26.29862270713103,-0.5183275835659846 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark03(26.32038452534657,0.0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark03(26.38434335530764,31.2401870569567 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark03(2.6469779601696886E-23,-17.278759592893092 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark03(2647.739624198988,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark03(-26.482700174962133,38.99930881036883 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark03(-26.56569830638749,-1.5707963267948968 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark03(26.58422549104099,43.73151042238134 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark03(26.61952005451795,28.670424482764787 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark03(-26.63078736078699,65.9006955306594 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark03(-26.67290261347277,-100.0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark03(26.72990450706221,-0.026366951548968114 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark03(-26.75225332191242,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark03(-26.75965617273071,-63.94969793053056 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark03(-26.807013454247983,1.5707963267948983 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark03(-26.835094702348698,0.0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark03(-26.848451613525192,-0.11317858099945938 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark03(-26.856092922590975,-0.5770704241853575 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark03(-26.88566136957793,-53.463054395681326 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark03(-26.890530136974263,-16.59226052092776 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark03(-26.894262812194114,55.86463142817708 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark03(-26.904583047757086,92.43369994708556 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark03(-26.927925510908963,0.0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark03(26.92990501348265,-26.57066691064665 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark03(-26.954739078399907,1.5707963267948966 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark03(-26.956398931321075,0.0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark03(-26.98407351405988,0.0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark03(-26.987826751546407,65.97344572538566 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark03(27.00406591571692,-44.12715757390445 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark03(-27.01064342210057,2572.763216474496 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark03(-27.0112606645051,0.0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark03(-27.01325279128536,22.678138512055227 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark03(-27.03621714293699,103.77118220583304 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark03(-27.059400040353147,-84.58778177935591 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark03(-2707.4449181508858,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark03(-2.710505431213761E-20,-0.5696747597210675 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark03(-27.11279380978354,-5.857815909834908 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark03(27.12794042934766,-1.5707963267948966 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark03(-27.149977880861,2.811106920411504 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark03(27.202160209896277,-89.11060053147008 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark03(2.727250644700217E-23,-67.5442392980526 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark03(-2729.4380759762657,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark03(-27.325069084697702,2596.726821672038 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark03(-27.59447693153979,10.31571733679593 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark03(-27.681472886280872,0.0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark03(27.7075405049991,-1.5707963267948966 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark03(-27.71037533680942,1.5352805753187693 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark03(-27.746775366062415,0.0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark03(27.750459219647205,-44.033260354466606 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark03(-27.81087065889801,1.5707963267948966 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark03(27.87598899286652,-16.44079639730147 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark03(-27.901066888575244,88.8975480477744 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark03(-27.931454729473273,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark03(27.94835266427129,-58.119464091411174 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark03(27.951337340203253,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark03(-28.011160776409668,96.67548582429339 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark03(28.0344461369898,-29.42126453267558 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark03(-28.052106870485044,-2520.6565014684784 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark03(-28.073961964521274,67.31425235634754 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark03(-28.075854711682908,-11.413140019530047 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark03(-2.808370472127887E-10,-27.478726939691107 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark03(-28.088002018706092,-55.283053013345864 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark03(-28.111798596875417,16.771124427560167 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark03(-28.126877006454585,-66.46383148903638 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark03(-28.14716620588768,-76.5990657858689 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark03(-28.148201149179215,-1.5707963267948966 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark03(-28.230048261772243,-86.39379797888601 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark03(-28.256138099791215,34.289847981912416 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark03(-28.265731832180577,2564.5204509287005 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark03(-28.27433377920096,-1.5707962728969433 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark03(-28.274333882305836,-1.5707963267972376 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark03(-28.27433388230813,0.0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark03(-28.27433388230813,1.570796326794905 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark03(-28.274333882308134,70.68562596040913 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark03(-28.275808490895695,-31.158695736286248 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark03(-28.276306403873075,67.54424205217896 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark03(-28.27716041356458,89.53563476793411 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark03(-28.333781046273945,50.421932795113065 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark03(-2.8445287133752974,-70.95882848626476 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark03(-28.501426871130842,68.53445348735849 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark03(-28.514966660408405,17.693282017691885 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark03(-28.607628075050968,-45.322577147733405 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark03(-28.965905981710478,-32.36432295815373 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark03(-29.011744982016126,24.299356001631434 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark03(-29.059643730237312,6.500399130352918 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark03(-29.13681424549489,-0.49806551910231767 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark03(-29.172952300037082,1.5707963267948912 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark03(-29.224739949144677,-6.9035755671379455 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark03(-29.310801910660672,1.5707963267948966 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark03(-29.343789662837764,36.55529818808601 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark03(-29.349875381602914,0.4952548275001223 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark03(-29.36168045284397,81.63494430973873 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark03(-29.388835083319247,-1.5707963267948966 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark03(-29.525177770104463,79.11428739335673 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark03(-29.563550660371064,-34.09993345926185 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark03(-29.698112732068864,-1.5707963267948966 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark03(-2.990508389548822,-1.5707963267948966 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark03(-3.0069490919659962,9.655757343136141 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark03(-3.009265538105056E-36,-1.5707963267948966 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark03(-30.279357186293964,36.988423069875324 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark03(-3.0410344477408273,89.31630962458186 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark03(-30.481412489549072,0.0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark03(-30.52521589568471,-67.72735115028559 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark03(-30.54105249522658,-81.65233853874763 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark03(-30.578087212795495,-20.89040184858233 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark03(-30.637257184101333,15.678693924566318 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark03(-3.0650116823313738,79.74740210689737 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark03(-30.801445962982044,11.86106263069118 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark03(3.085660361933236,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark03(-30.925867145107162,14.806431758362649 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark03(-30.992550306656,0.0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark03(-31.01517036155124,-2635.0912566022066 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark03(-31.149106605288488,1.5707963267948968 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark03(-3.1279699173747835,-14.429273478161505 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark03(31.301608040438225,-80.26412659975486 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark03(-31.349800703450597,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark03(-3.1415668192589954,-45.553093477051995 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark03(-31.41573613495929,-45.555046602052016 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark03(-3.1415926535897927,-1.5707963267948972 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark03(31.41592653961042,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark03(-3.141592674771511,-86.39379729601526 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark03(-31.42180199191394,-33.85208724930476 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark03(3.1422896431337617,-10.995574152749079 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark03(-31.445731169604315,0.0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark03(-31.447176535897935,1.5707963267948948 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark03(31.44717653884303,-10.995574287537535 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark03(-31.463225787867085,221.47941391617644 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark03(-31.55204461315556,-1.5707963267948983 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark03(-3.1553123940286767,-128.95978564274571 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark03(31.62446727227163,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark03(-31.65000892285272,-10.974933408708292 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark03(-31.727697254238038,1.5707963267948966 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark03(31.749178096515266,59.0756140090304 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark03(-31.752393614577073,-4.375921901705549 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark03(31.75274306912884,7.871538524044013 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark03(31.774368603044238,0.0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark03(-3.1804175812542894,1.5707963267948966 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark03(-32.01444151075317,3.688608514260949E-15 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark03(-32.03401552879852,-56.284688064496514 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark03(-32.059149813645774,0.0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark03(-32.09942548462974,-1.5707963267948912 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark03(-32.12301961666242,-0.5707851077542726 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark03(3.2197617728943717E-4,-31.5574018055873 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark03(-32.22599372127867,-0.03295804427185811 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark03(-3.2249931526829307,-93.74127970629624 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark03(-32.257871462874405,-8.695926560950957 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark03(-3.2320286748161777,-100.0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark03(32.34250970385153,-75.32185032846431 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark03(-32.39392109860199,115.72078259712517 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark03(-32.49232782099421,-46.62949476214828 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark03(-32.59901722697402,-84.55775362975389 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark03(3.266592653597874,136.59777348035988 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark03(3.2665926536253216,33.09536294075784 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark03(3.266592653789614,79.99855801733717 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark03(-32.666344984730316,-54.049273222904546 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark03(-32.71330770667987,-100.46566877827694 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark03(-32.71499789750291,0.0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark03(32.720864296420885,6.7123889803847 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark03(-32.85116821750213,-86.08908350192382 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark03(32.90548501453179,-1.5707963267948966 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark03(32.9301877878521,-44.21619880045771 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark03(32.94867221060082,0.05798320091635196 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark03(3.29852347487802,-4.625849506954072 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark03(-33.03786324012688,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark03(-33.04987133195635,24.831077126365628 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark03(3.317365035763939,161.6162492777002 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark03(-3.3183222235837683E-18,51.836278784231574 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark03(-33.23914842317754,-97.55750187469803 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark03(-33.37095881419137,0.0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark03(-33.41455870524722,100.0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark03(-3.343008047975715,-36.91043220169478 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark03(-33.5492988388025,46.56131382773723 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark03(-33.795041355429674,90.01438706322033 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark03(-33.93740605878709,0.0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark03(-34.03060785865024,77.63990758559117 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark03(-34.204230959083475,-69.37968749110503 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark03(-3.431219785134655E-18,95.81857593448868 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark03(-3.4331714161687146E-9,4.494596197576952 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark03(-34.442872374264894,63.69068260550938 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark03(-34.44560522692646,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark03(-34.55403087311291,-80.10712435016491 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark03(-34.55751918948629,-36.12831551628263 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark03(-34.557519223206626,0.0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark03(-34.55752767640773,54.97787141383658 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark03(-34.58275775782941,-100.0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark03(-34.66671328865328,-1.467648584237193 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark03(-3.478848924014599,-15.82317168861735 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark03(-34.8359808690936,1.5707963267948966 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark03(-35.09627842218113,-76.53853964591482 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark03(-35.10611434044755,25.06618683839325 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark03(35.20774505635262,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark03(-35.33763842500414,-5.492508215901101 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark03(-35.383364365429465,-1.5707963267948966 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark03(-35.52412899293964,-35.64084418686025 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark03(-3.552713678800501E-15,-11.643637275797985 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark03(3.552713678800501E-15,-14.551786595994592 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark03(-35.56511115168858,44.35541319007926 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark03(-35.57602418326735,4.422217355351705 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark03(-35.745683344345935,0.0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark03(-35.77592268333004,20.473418010626816 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark03(-3.5802028584615755,0.42342375367627266 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark03(-35.840983562236616,-98.54222278246844 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark03(-35.93119421158915,61.68538724630383 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark03(-35.9330163733804,6.579765306642997 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark03(-35.94980759385649,1.5707963267949054 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark03(-36.12831551627642,0.0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark03(-36.371457186673894,90.44168233665212 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark03(-36.41307557512313,-86.3937979738332 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark03(-36.41329998117244,-117.84167036926671 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark03(-3.6441720244956315,-48.90949170331108 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark03(-36.537480606091385,97.04873769154818 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark03(-36.56190539597483,69.65920463165881 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark03(-36.93751977717368,-73.41319344425489 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark03(-37.00991434840078,-1.5707963267948966 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark03(-37.011711895027986,-64.28712496008109 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark03(-37.13961382814017,-54.06851181740642 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark03(-37.262830207531294,-1.5707963267948983 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark03(-3.732935138153636E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark03(-37.551748179465335,-95.13080485069499 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark03(-37.69905516857294,4.712633121018566 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark03(-37.6991118140263,4.764289484940436 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark03(-37.69911184308242,-1.5707963267948966 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark03(37.69911184355345,1.5707963267948966 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark03(37.69911184398635,1.5707963267948966 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark03(37.69911204554942,29.84512965522532 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark03(37.720208724187025,159.5909796382275 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark03(37.76868640101597,-31.140873796534027 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark03(-37.81014460318906,-0.3123272690908672 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark03(37.855454672418304,-136.4026073194115 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark03(37.95097119508995,70.85481254940572 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark03(-37.982288583455876,2622.926436197165 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark03(38.097183418832,-99.35824016383297 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark03(-38.17807627714326,-22.88045587297509 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark03(38.19268967665549,158.75648622751356 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark03(-38.21044197111708,-14.42920427531692 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark03(-3.8225344146978557,15.060705364155426 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark03(-38.23477063945939,-13.96542898963095 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark03(38.25955294024786,-53.283207447188374 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark03(38.314256433101235,1.5707963267948966 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark03(-38.49323346619785,-95.54098606897746 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark03(-3.850001382617342,-2587.7817979303913 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark03(-38.526757863375174,1.5707963267948966 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark03(38.53198967127972,94.76973638371123 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark03(-38.53367858128799,-59.376359961248085 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark03(38.573420347391064,2543.975998354965 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark03(-3.861634462938118E-15,-0.04312626237358219 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark03(38.650180817821834,14.099244500158088 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark03(-38.65875781495399,62.21139296035098 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark03(38.73894325499903,100.0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark03(-38.748384722050375,10.037143303821196 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark03(-38.76951068389411,32.35752532150505 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark03(-3.8923980120683837,29.67633909344123 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark03(38.93010847148691,-44.32209684864261 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark03(38.99448779239074,-37.29724940027239 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark03(39.028182859188064,-58.440932822423754 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark03(-39.03198684535296,1.5707963267948983 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark03(-39.03936202046086,13.749992446209978 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark03(-39.06221391416722,2.0573773944886398 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark03(39.10757999351926,-1.5707963267948968 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark03(39.156923739592386,17.27876054613142 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark03(-3.9203634233273306,-0.21433888756163527 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark03(39.25909936034756,151.1296799746837 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark03(39.26019418577196,-25.123027244617884 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark03(-39.64352430365572,100.0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark03(-3.9658471513792897,72.58941389558765 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark03(-39.830580018063785,0.0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark03(-3.983170562321689,-78.46303954174489 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark03(-39.864848647623944,21.575785834949983 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark03(-39.92430616787661,1.5707963267948968 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark03(-40.074065624921005,21.290102265761746 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark03(-40.266785968749716,-103.87007618660876 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark03(-4.037510874060786,0.0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark03(-40.43058422254613,1.5707963267948966 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark03(-40.535092039055776,-0.5691007945597885 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark03(-40.548952747743314,0.5707536853260088 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark03(-40.59573059882613,28.774689208312424 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark03(-40.752488677897446,-4.624173161614824 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark03(-40.8407044966673,-1.5707963267948966 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark03(-4.098099180093975,-100.0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark03(-41.01724778217614,57.215971140210286 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark03(-41.06735940950957,-5.212388980387245 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark03(-41.07308437852913,-33.682774171767576 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark03(-41.24217783549355,6.147729489253525E-17 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark03(-41.32985834679483,101.61260739154076 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark03(4.141592653589794,45.91707959786772 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark03(4.141592653589808,22.58975598014717 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark03(4.141592653628566,-46.40697986187465 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark03(4.141592653695001,-29.302457885965893 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark03(-4.148486836223242,67.19891752578522 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark03(4.151831889602665,9.98537170724573 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark03(-4.155545600652161,2525.035978562574 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark03(-41.564569483559865,73.83744174041365 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark03(-41.63641247651523,-16.2255895791173 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark03(-41.80506828859475,29.357310046490937 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark03(-4.181662210807887,1.1996560805448252E-4 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark03(-41.83495959073229,-73.56975789597202 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark03(-41.90033589175462,87.45342936880662 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark03(-41.94449592808376,99.89247849045506 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark03(-42.00530436705929,0.40619645640292046 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark03(-42.153997505641485,-85.43867198562415 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark03(-42.24457133693646,75.23129419962929 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark03(-42.27170902621016,0.8114904508278917 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark03(-42.27884871907416,0.1326521043880462 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark03(-42.30229857523062,0.0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark03(-42.4115008234647,0.0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark03(-42.53650082346221,0.0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark03(-42.54209082727781,0.13059000381560137 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark03(-42.55831356416206,-110.26212408070478 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark03(-42.56547174749893,14.429479893949406 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark03(-42.565957006315806,73.81664425627586 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark03(-42.57938195886217,-103.14092637014797 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark03(4.2594278458616743E-13,1.5707963267944707 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark03(-42.59958877164905,-1.86330341417478 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark03(-42.60489206787779,55.74029388721578 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark03(-42.633045420824644,-47.939251150722725 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark03(-42.670326589978245,0.0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark03(-42.69543003844569,47.48045920196352 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark03(-42.70158947312473,93.95769095803128 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark03(-42.71375621573488,-38.74089429910039 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark03(-42.7183593304337,0.0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark03(-42.75346718126987,-52.77388900158472 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark03(-42.75868511997939,-88.31177859703139 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark03(-4.276423536147513E-50,70.68583469824839 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark03(-42.7754703249513,1.5707963267948972 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark03(-42.78385979434134,1.5707963267948968 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark03(-42.78613157871456,47.675704113385365 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark03(-42.80347555970856,42.66850864739891 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark03(-42.80469596729053,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark03(-42.81510754218098,-6.471187419310689 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark03(-42.9075672881122,72.30145435130694 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark03(-42.91888773970812,-12.402578321934147 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark03(-42.92113841556243,5.7735477150793635 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark03(-42.93625432961654,-38.543225089470326 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark03(-42.93665533076869,89.67540982165087 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark03(-42.94528337858551,1.5707963269703384 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark03(-42.95060154692277,1.5707962022725075 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark03(-43.11975763012833,97.33095880229419 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark03(-4.3368086899420177E-19,1.5707963267948963 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark03(-43.5306705422976,-21.52584248866107 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark03(-43.751314727446065,-68.89963987178089 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark03(-43.947180721635576,80.9474871254518 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark03(-43.98112973103806,67.4632635406407 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark03(-43.982297147335686,-80.11061259228805 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark03(-43.98229831132379,67.57549205218058 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark03(-43.98278547854056,1.5707963267948966 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark03(43.99010965027641,98.96016858806591 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark03(-44.061206288879546,129.9760673198736 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark03(-44.06635293444332,45.520385953917526 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark03(44.08571710456954,66.55952975199625 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark03(44.116467992297856,-29.372764057282993 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark03(-4.415598332397497E-14,1.5707963267948966 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark03(-44.30270579488688,-75.6918687997844 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark03(-44.31726328534496,-83.32790537190118 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark03(44.351037677364125,5.2123889803846915 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark03(-44.35848739652534,-44.30471853595387 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark03(-44.381277330379916,0.015539068777055192 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark03(-4.440892098500626E-16,-0.24412824776182018 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark03(-4.440892098500626E-16,1.5707963267948983 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark03(-4.440892098500626E-16,3.3885623428816984 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark03(4.440892098500626E-16,55.344844207306494 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark03(-4.440892098500626E-16,-57.03590403261914 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark03(4.440892098500626E-16,65.06357058572954 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark03(-44.426167744624166,-13.810077577933797 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark03(44.529128768948254,-96.69483158185412 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark03(44.61416039824613,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark03(-44.6636974161974,136.4982853100195 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark03(-44.72974062987048,2571.4400511527624 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark03(-44.73179329226921,0.0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark03(44.75991310170418,-39.25332525674867 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark03(44.80026625437652,4.440892098500626E-16 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark03(44.88182463320776,-0.6712688438442385 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark03(44.937831440965255,-16.683366876952263 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark03(-44.98369953610376,9.133679423160885 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark03(45.03187277663736,-34.927229692025236 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark03(45.07396635169545,1.2203906194399479 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark03(45.12283487120792,0.430258605844081 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark03(-45.16752561507335,37.888891626536186 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark03(45.176630443994725,-23.343439858174037 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark03(45.201719329305575,-6.339076196785589 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark03(-45.305830299521766,-53.65433828855672 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark03(45.35091829842409,34.195312770179385 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark03(-45.35577155391529,0.20307768415020178 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark03(-45.41484949641194,81.66333293212759 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark03(45.41838753773831,57.04843638109497 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark03(-45.47807688001362,-39.29754478959446 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark03(45.499519648988134,-1.5707963267948966 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark03(-45.54099535338039,44.79295447644586 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark03(45.54831582715264,-123.82736472848251 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark03(-45.60603108563573,14.429204338163835 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark03(-4.561169358612194,-131.79567182899882 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark03(45.67622511546105,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark03(-45.7367079572768,0.0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark03(-45.93909545361532,-25.164940982114416 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark03(46.23192801991658,-0.30575163814926043 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark03(-4.627129092102556,-1.570796326794806 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark03(-4.6318650775571255,88.04511820334177 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark03(46.52929167978229,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark03(-46.707735011127085,77.92272756879558 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark03(-46.736297476563536,0.0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark03(-46.90970280485638,-81.67735822910815 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark03(-46.912938900689014,6.283185307179585 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark03(-47.087110322291664,-1.5707963267948966 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark03(-47.119785362113895,-18.917911127057636 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark03(-47.123391179084265,-0.5707693899253915 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark03(-47.123889658167826,26.703537555496432 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark03(-47.123889803846936,1.5707963267948966 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark03(-47.20510220019138,0.0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark03(-47.34690002742905,1.5707963267948972 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark03(-47.348543590260725,-135.09972618485193 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark03(-47.7118279490398,1.5707963267948966 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark03(-4.78101584713761,-47.639718031764275 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark03(-47.94303603127599,-98.20010834325379 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark03(-47.971541524997534,-91.66714669594434 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark03(-48.21829340337633,0.0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark03(-48.2505919120246,1.5707963267948966 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark03(-48.26231517560178,-6.309043669028583 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark03(-48.35643037918797,0.0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark03(-48.38320251375014,-0.570781481353711 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark03(-48.65289750153444,0.0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark03(-48.69426129880094,-7.812517854216722 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark03(-48.69455707465295,14.429364074952765 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark03(-48.695658718576816,-7.716478275023407E-31 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark03(-48.71515511416921,-12.586839597886586 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark03(-48.72765769952524,2.05907532797805 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark03(-48.73102485620326,70.63374259319218 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark03(-48.76934694343051,18.924216734327477 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark03(-48.771510469640454,31.68577630560117 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark03(-48.79459277427347,-89.4613538336458 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark03(-48.876841101909214,0.18215497126741864 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark03(-49.00487711829893,88.98885696977658 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark03(-49.03182076633059,0.16708405997379006 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark03(-49.05896396513032,-72.91293195198654 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark03(-49.065243993903216,30.432749589977732 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark03(-49.07118186180392,-0.36912818245150497 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark03(4.930380657631324E-32,10.99557428756427 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark03(-4.937558075702071,35.862090991783305 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark03(-49.417489237357444,0.4872134658189085 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark03(-49.44805641268759,-62.33403056877802 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark03(-49.48436455741272,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark03(-49.48689019635981,0.0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark03(49.49426954290976,0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark03(-49.72311824564406,98.03908223937253 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark03(-49.73363549589163,83.50850398480871 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark03(-49.764764943350954,6.6126405136333855E-9 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark03(49.80251194701603,71.10945600497882 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark03(-49.82263485556429,-1.5707963267948966 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark03(-49.83486483587503,-1.5707963267948966 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark03(-49.85325760743721,1.7143714180038667 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark03(-49.87266734379301,71.11951071457753 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark03(-49.88639515085053,-5.2123889803888535 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark03(-49.894145278375234,97.00781194357623 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark03(-49.902074993146314,-8.492706772063226 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark03(-49.92347555694718,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark03(-49.92533251595684,0.0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark03(-50.005724053010425,32.402807571108326 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark03(-50.03342139032186,15.016537305394134 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark03(-50.07378242720473,1.5707963267948966 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark03(-50.08820056053529,-29.845137764162416 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark03(-50.09204754383453,-53.80220208208172 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark03(-50.12704120218769,0.0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark03(-50.13968611547687,2146.160787787443 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark03(-50.14153910564476,100.0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark03(-50.14958879198495,1.144072913844077 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark03(-50.202228097941635,83.17564279997515 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark03(-50.229751737087916,-1.5707963267949019 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark03(-50.23413336595508,-75.44708793797543 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark03(-50.26532467131826,4.712388978673067 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark03(-50.26547641386611,-61.26105674500096 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark03(-50.2654820470638,4.8373889804775345 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark03(-50.26548245669863,1.5707963269276597 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark03(-50.26548245742364,1.5707963267948966 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark03(-50.26548245742737,-155.50652200678078 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark03(-50.26548245743668,-1.5707963267948977 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark03(-50.26548245743668,1.5707963267948977 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark03(50.26548627213396,-45.55333809382666 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark03(-50.26551297501482,0.0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark03(-50.2732977693285,-1.5707962897611176 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark03(-50.273347498682874,-227.76546717561487 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark03(50.29467755140831,-83.67494933463007 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark03(-50.31627581516835,-1.5707963267948966 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark03(50.3640727835878,-1.5707963267948966 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark03(-50.48220517119009,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark03(50.60321915083457,-24.401999745386178 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark03(-50.63362966701255,67.1760948426047 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark03(50.684548824261555,48.6946861306418 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark03(-50.70363107314883,49.99535106832093 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark03(-50.753155283210646,0.0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark03(50.77538259437403,18.595992771282255 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark03(-50.84373449438131,77.40612326535394 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark03(-50.86667585488162,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark03(-50.92560587387869,28.029487226950323 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark03(-51.05648144120158,-190.3145742834104 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark03(51.103784454547394,31.880490032393084 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark03(51.10687530348724,7.787946986449543 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark03(51.128805457200144,-0.728078295561061 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark03(-51.18923060434084,-27.627285702417392 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark03(51.200623293094765,100.99015750097925 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark03(-51.234581617515516,-1.5707963267948966 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark03(51.25392993658983,2555.6951380457576 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark03(51.258595547442006,58.96346248128894 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark03(-51.26354305381601,-14.432188325732973 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark03(51.27761621780914,40.11968395212527 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark03(-51.28209275255294,-1.5707963267948974 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark03(51.29380014147975,0.5424786427518385 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark03(-51.29924229081824,1.5707963267948966 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark03(51.35348133078159,80.74036357054439 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark03(51.35747669172822,0.49992381708605965 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark03(-5.141061983754323,-1.5707963267948968 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark03(5.141592829985658,-105.24659400236678 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark03(-51.44776666083824,2.753080530196445 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark03(-51.4881222453873,-2.3858616973970683 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark03(51.49720354761803,-99.86212105859573 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark03(-51.49810134641002,-89.04374162558584 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark03(-51.55041588844013,10.62096894483049 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark03(-51.60670939460863,-3.7328395051548514E-7 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark03(-51.65391920507909,1.5707963267948966 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark03(-5.168499277839004,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark03(51.69315706510699,-49.14490574601816 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark03(-51.70865257342791,28.401960093111814 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark03(51.735213495647514,72.70385972635967 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark03(-51.80449254502658,44.36288213154211 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark03(-52.372681762878685,-24.337276238346178 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark03(-52.46340971266022,-1.5707963267948961 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark03(-5.250705346928356,-0.5261267817048747 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark03(-52.91689199410416,0.2809121020060843 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark03(-5.293955920339377E-23,-23.56194680941051 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark03(-5.293955920339377E-23,-7.853664105944429 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark03(-53.32416156782796,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark03(-53.40698428125364,-42.427158806688354 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark03(-53.407074607862356,-58.11946409141116 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark03(-53.40707509816834,32.986722087317325 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark03(-53.40707510387647,0.0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark03(-53.40707511102647,1.5707963267948963 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark03(-53.40707511102649,0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark03(-53.40707511441022,59.32588316671613 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark03(-53.43600470837663,1.5707963267948966 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark03(-53.497055387955015,30.046024108787748 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark03(-53.56585517904624,-0.37368637368528557 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark03(-53.634838198814066,61.683729563806395 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark03(53.69033578242701,-18.55459833935531 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark03(-53.697823999335,43.78823660531555 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark03(-53.72398108684677,-51.513265753318805 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark03(-53.78570048798956,16.51793295703035 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark03(-53.82671718184147,1.5707963267948912 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark03(-53.885421849728864,-33.669572492846925 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark03(-54.04805247490165,29.51162693945139 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark03(-54.18025298559748,0.0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark03(-54.28066187207409,-0.2779298160962183 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark03(-5.438693092235901,0.0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark03(-54.53101384678762,71.71450677345882 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark03(-54.57513943903344,0.5444599244319331 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark03(-54.59225310461548,1.5707963267948966 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark03(54.6207338290198,-86.01548382220724 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark03(-5.466590180505392,84.8704660024365 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark03(-54.70151917271062,-93.58771481724133 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark03(-54.72678557740093,0.4941485324187763 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark03(-54.75220590145468,-38.57878093539813 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark03(-54.884978585630535,74.87898223197644 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark03(-54.90688863877369,-0.07098279904769644 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark03(-54.98446728233528,-2606.5396240977584 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark03(-54.99421338669492,1.5707963267948966 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark03(-55.02261230475201,0.0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark03(-55.03003957130404,0.16618321125163776 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark03(-55.06485803874894,-1.5707963267948912 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark03(-55.10481326724876,-1.5707963267948966 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark03(-55.115259899989326,-0.1373884621679441 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark03(-55.13289424506273,-81.52638618609328 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark03(-55.146562001402195,45.15835542259147 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark03(-55.19930232095498,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark03(-55.238085316598465,-1.4847338704704434 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark03(-55.26703296072539,-1.5707963267948966 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark03(-55.29153427097358,-1.4379982859008302 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark03(-55.298086142690174,-1.3282806957490996 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark03(-55.31357127858607,0.0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark03(-55.32737429435215,-1.5707963267948966 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark03(-55.332115924982396,100.0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark03(-55.33984830467349,-31.969916117190124 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark03(-55.34645394188211,1.5707963267949197 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark03(-55.355977433856225,-33.48548868128188 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark03(-55.356842791466136,-4.166649387678163 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark03(-55.36659756724674,-1.5473306795345405 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark03(-55.397014638764674,95.48551467626274 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark03(-55.46627066033868,-0.34114974324079483 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark03(-55.47372393256538,-44.26629219374955 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark03(-55.48642004281623,76.1126448488576 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark03(-5.551115123125783E-17,-14.389201335933492 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark03(-55.70050181772995,44.22905463511798 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark03(-55.715630323221355,-37.230769124434595 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark03(-55.87074631831395,20.992562572782358 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark03(-55.98737336694841,0.006569866487745885 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark03(-55.99167713151726,-1.5707963267948968 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark03(-56.02912863704024,1.5707963267948966 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark03(-56.03227531351351,-45.35910231948387 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark03(-56.03590725053779,0.0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark03(-56.06575773952506,0.0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark03(-56.076556453135886,-45.31676358815671 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark03(-56.08896577550807,100.0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark03(-56.09445085728126,0.37243161148232673 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark03(-56.10414933229709,-43.73228847572599 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark03(56.10476570044983,81.82265272905758 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark03(-56.10833139442792,-11.216615282128899 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark03(-56.110647248698285,30.094517208230634 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark03(-56.18355783803009,-18.876873320146487 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark03(-56.21573318624109,57.62635998228228 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark03(-56.22163063345117,-34.165856565968205 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark03(-56.236596231085954,-49.91200533594908 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark03(-56.26896761786347,1.5707963267948968 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark03(-56.312485558622,2574.3126428039673 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark03(-56.35471404661467,1.5707963267948966 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark03(-56.35726560357713,4.962389054492358 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark03(-56.409664674494294,-72.83129988474663 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark03(-56.42391167795618,-58.207136575045595 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark03(-56.438088457006074,40.321790378263216 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark03(-56.471550128253625,-44.423951119253836 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark03(-56.473280446573625,-24.385438348447508 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark03(-56.52507999931784,0.0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark03(-56.5485783640624,10.995574287554177 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark03(-56.54865377194038,89.53545188616377 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark03(-56.548667726642606,48.69468613063514 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark03(-56.54866776341835,-10.995574152631317 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark03(-56.54866776461451,-1.5707963267930853 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark03(-56.548667764616106,-1.5707963267948966 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark03(-56.54866776461627,1.5707963267948966 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark03(-56.54866776461627,-1.570796326794897 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark03(56.54866776461631,-1.5707963267948966 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark03(-56.54869828219442,1.5707963267948963 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark03(56.55257401461628,1.5707963267948966 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark03(56.606480609111884,100.0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark03(-56.62943782055208,43.305334159661015 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark03(56.65166083206233,-2521.0602936870473 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark03(-56.66949327733801,43.33211461164973 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark03(-56.674696048787354,-2.0707963582973212 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark03(-56.752945665744356,-1.7750742279370229 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark03(56.76372218841689,-1.570796326794861 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark03(-5.677142153527527,1.5707963267948966 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark03(-56.849231448720445,0.05941988664341331 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark03(56.88151549966747,-82.12178263069345 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark03(-56.90714065165658,-2602.791872501402 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark03(56.923760092089395,39.863657802881676 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark03(5.69271271830705,49.32695194243689 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark03(-56.960149668602256,-92.19404088209244 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark03(-5.704606303708772,-5.57954190909868 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark03(57.08316411776158,-62.951022225937315 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark03(-57.11837896822152,-62.135382066203505 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark03(57.130464740478935,45.04719826109175 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark03(57.138104887598246,-82.53054510159876 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark03(-57.21788406079155,-1.5707963267948966 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark03(-57.23177042354927,29.411687664979905 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark03(-57.30733103604244,-59.375244262293805 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark03(-57.40242969182299,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark03(57.424722474067764,32.63280944991615 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark03(-57.55953739084254,94.53018172381186 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark03(57.5659428406114,-0.4080325814783663 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark03(-57.573113015298475,-39.236251920605866 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark03(-57.59189894144294,192.16471701894562 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark03(-57.615565723534964,2.637694285713582 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark03(57.62726035958118,-68.62283464714545 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark03(-57.63932341610342,98.76240602486789 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark03(-57.65575963805401,-1.5707963267948966 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark03(57.66678018167602,93.14752519127141 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark03(-57.669116225430614,0.9271269140246972 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark03(57.68283889278828,17.11936579795463 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark03(-57.705818997253104,-1.5707963267948966 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark03(-57.72290455982707,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark03(-57.749424127219484,2618.981936545904 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark03(57.75102628813302,-11.813372885479694 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark03(57.773697369757606,30.08291905128027 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark03(57.7843102802357,47.57329769051836 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark03(57.806709947138955,1.5707963267949054 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark03(-57.82791680173346,17.16424919344219 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark03(-57.86162570877658,1.5707963267949976 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark03(-57.88633195244633,0.0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark03(57.8927819905135,-47.96238127792347 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark03(-57.93126557634724,0.0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark03(5.793473218143645E-18,-86.39379797371926 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark03(57.94541962683144,-6.457229771759324 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark03(57.96098480036264,72.69425875566836 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark03(-5.796552477615151,2623.672845978123 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark03(57.99942775603598,-15.287054199675914 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark03(-58.02833673787844,2690.7132839495775 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark03(-5.80663312691477,1.5707963267948966 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark03(-5.820592158457345,91.12817142859316 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark03(-58.306336397397665,77.15583403361515 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark03(-58.385404084795695,-0.4572619836302028 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark03(-58.41280870570398,-2625.803887291184 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark03(-58.58481005869867,-72.02406449268683 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark03(-58.7636921547851,77.62407744462239 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark03(-58.79066908808453,0.03701607015996739 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark03(-5.912236337557779,-1.4557983170635467 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark03(-59.253103696369536,-11.716565076442492 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark03(-59.290582905194576,-95.32695272160237 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark03(-59.3368955208176,1.5707963267948966 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark03(-5.953441279641442E-18,54.97790195539951 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark03(-59.69034632895921,-29.845129796019783 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark03(-59.691236980938115,-4.712388967018333 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark03(-59.69462787645329,-89.5356347683015 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark03(-60.06409867982902,-1.5707963267948966 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark03(60.171134378371136,52.953983930710876 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark03(-60.20365487679835,-61.080602882287536 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark03(-60.24195371796342,-1.5707963267948966 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark03(-60.24760193299325,5.269730495171867 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark03(-60.30559244668934,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark03(-60.356999445420854,-1.5707964349611907 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark03(-6.041651175102956,30.1492189136751 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark03(-6.051348938299526,43.982611351403875 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark03(-60.53953250516698,27.029028717212384 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark03(-6.055856235795787,51.00040664566242 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark03(-60.61251910650547,-13.58515086762253 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark03(-60.65548225574818,76.76499385059267 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark03(-60.750527108709626,0.0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark03(-60.79774651567846,-1.5707963267948966 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark03(-61.14868793054308,45.550626438393614 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark03(-61.21375649561179,-0.44517600319948514 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark03(6.123233995736766E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark03(6.123233995736766E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark03(-61.26105674499974,1.548206372503621E-12 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark03(-61.35238705349568,25.782237965060418 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark03(-61.36460414117611,-1.5707963267966565 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark03(-61.62592032991725,-49.611586776288476 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark03(61.64616391822028,0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark03(-61.680002855774184,-18.430609810765542 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark03(-61.692798224484854,0.0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark03(-61.783912472593286,46.9706358219092 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark03(-61.856871385217474,-32.01174117611444 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark03(-62.16400431953687,77.35974446075181 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark03(-62.2603176775489,3.2452279339826777 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark03(-62.329752706880036,-61.7631571099168 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark03(-6.253210525217555,-4.837388980384845 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark03(-62.62838372249224,95.52392378350069 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark03(-62.72174277724248,-57.352833226345055 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark03(-62.758055030414525,0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark03(-62.77194591790807,76.58231570059684 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark03(-62.83185305511624,-4.743638986734257 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark03(-6.283185307182714,-1.5707963267949054 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark03(62.8318530736864,-73.82742735935997 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark03(-6.283186080438983,1.5707963267948966 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark03(-6.283208658884014,-45.5530912374858 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark03(-6.283337202230426,1.570796326795732 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark03(6.284161869679786,-1.5707963267948988 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark03(-6.2841618696868355,-1.5707963267975065 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark03(-6.2841622626552,20.420352248445692 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark03(6.284164349453264,-67.54429538140691 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark03(62.85317194194113,-1.5707963267948966 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark03(-6.287091557179588,1.5707963267949054 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark03(-62.884894163743965,-1.2936124578203874 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark03(-62.88832743247126,4.726103631111199 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark03(-62.8894150258871,-1.5707963267948968 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark03(-62.89435307179587,0.0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark03(-62.90499229065848,183.7835541324047 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark03(62.91210266019746,1.5707963267948966 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark03(62.940565674917195,-88.28012729082354 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark03(-62.98336895608687,52.975743082450066 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark03(-62.983548849671145,-8.47327557100084 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark03(6.298810307179588,-17.293963499636593 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark03(63.04778023222323,19.328625951089663 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark03(6.305136378308092,14.135252039223676 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark03(-6.306951299520502,-36.10454952394171 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark03(63.09431775288189,63.6700892542265 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark03(63.125670303753054,-1.5707963267948948 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark03(6.31443530718441,-64.37956271163239 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark03(-6.318851471923844,-45.58875962997676 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark03(-63.38556496665764,1.5707963267948972 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark03(6.343195625972912,27.11843616022071 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark03(-63.48585877641253,-45.30668629660006 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark03(63.63881094337168,-1.5707963267948983 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark03(63.65616896952781,56.16144560653299 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark03(-63.66032842436071,100.0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark03(63.71887775455185,0.0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark03(-63.787953366430436,-1.5707963267948968 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark03(-63.82245917937073,-26.548687417647756 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark03(-63.8278548495079,-35.29498397851571 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark03(63.83026986646726,-68.75049654949356 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark03(-6.3846208760244485,73.7260262714192 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark03(-63.84806592530945,-1.548542097600765 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark03(63.8694476315238,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark03(-63.89330314812451,-84.93366446892708 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark03(64.01098575074307,1.0793620148764116 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark03(64.14410968432864,88.66135134608601 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark03(6.415588724838538,-1.5707963267948972 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark03(6.415965837667459,-23.051587638351243 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark03(-6.421002282138247,34.225734728394286 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark03(64.38152128447635,27.24914034994248 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark03(6.440192811555633,-42.84347457815955 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark03(-64.42678472132376,-128.78116347444853 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark03(-64.50454561921262,39.155114365043424 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark03(-64.61028011762812,-0.0022822067287155356 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark03(-64.6912427491175,80.56498361623784 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark03(-64.76478190405582,-4.737292089835137 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark03(6.480982318639417,-1.5707963267948966 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark03(-64.86809398760815,-11.605794601879701 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark03(-64.92252107823846,0.18905358343332276 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark03(64.92583499939477,-1.5546610420726015 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark03(-65.01775002581529,-31.514255231251354 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark03(-6.530186422654721,1.5707963267948966 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark03(6.533185307179588,-143.17685199825848 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark03(6.533185307179588,45.314686830064545 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark03(-6.533185307179588,4.601790117145304 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark03(-6.533185307179589,-17.194608229979487 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark03(-6.533185307179598,48.48330900387045 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark03(6.533185307179611,51.64300303618805 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark03(-6.533185357165782,-67.3218548460624 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark03(6.533186182679023,-36.22249503398936 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark03(6.533834541507441,74.07807659368798 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark03(-65.36309366516097,46.40094553246112 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark03(6.548685390484305,4.977889063689305 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark03(-6.5548683096552205,61.55528804752903 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark03(-65.55270856590896,2630.931452060275 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark03(-6.567277904617569,0.0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark03(-6.569653910384979,-21.75705232758547 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark03(65.69846273734333,-59.07992631515593 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark03(-6.5807159263154285,0.0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark03(-65.83736671639504,0.0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark03(-65.93626350312208,-1.5707963267948966 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark03(-65.96405116055216,0.560685997196929 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark03(-65.97344572538564,1.5707963267949099 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark03(-65.97917026334648,53.88038933881353 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark03(-66.08642370415856,98.59232610581935 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark03(-6.612691530105636,-26.834385704271853 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark03(-66.14632103376567,27.025571175834532 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark03(-66.25685398990294,37.768960102946345 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark03(-66.26675579240408,-83.9883554908027 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark03(-66.30299982494364,-14.466427929263027 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark03(66.46837702671814,5.167209052191055 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark03(6.648362478230638,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark03(6.663647917557094,-17.65922220512137 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark03(-66.6963885772032,-93.39992613271643 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark03(6.687630591149144,-86.32484451161282 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark03(-66.94724968066357,-52.995741015053355 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark03(-67.09193764123492,1.5707963267948968 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark03(-67.10173780175936,0.0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark03(-67.19895312280299,-0.6461898432278005 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark03(6.730285234763016,0.7987244408252394 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark03(6.75559645394388,11.235307257461244 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark03(6.776263578034403E-21,-1.5707963267948977 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark03(6.777772053448966,-95.32398918821931 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark03(6.778950692071902,-60.48629012415396 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark03(-67.81844589128042,1.570796326794897 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark03(-68.0106598431844,80.11061266653974 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark03(-68.06282437172409,35.12149479054153 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark03(-68.25840033463354,75.18856126468006 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark03(-6.835789788222371,1.5707963267948912 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark03(-68.50118681674451,0.0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark03(-68.71114769321267,0.0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark03(-68.97009662015358,43.81014288699633 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark03(-69.1150222789125,-10.995574287564267 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark03(-69.11503834505429,-92.67698328069297 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark03(69.11503837897544,1.570796326794905 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark03(69.11503905560944,-124.09265385519991 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark03(-69.115282519748,1.5707963267948966 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark03(-69.11699150398114,-7.853981633885552 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark03(69.11699992054236,45.553128331501924 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark03(69.22883770367037,54.977855133162414 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark03(69.35046866026629,1.5707963267948968 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark03(-69.35130644282607,0.4153345913326379 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark03(-6.9388939039072276E-18,1.5707963267948968 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark03(6.938893903907228E-18,0.49985256841252196 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark03(-69.40503339931715,8.895696113741437 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark03(69.42476973791554,-59.71876112257788 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark03(69.46271056034384,2557.8563183400283 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark03(69.48192939215252,51.461861948120486 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark03(-69.5077545505099,-10.602858116029827 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark03(6.951252373063609,-1.5660487927105844E-4 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark03(-69.72918321705276,3.473748635548416E-10 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark03(69.74533731775891,-226.58896593645676 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark03(69.94223019365099,57.46287652844012 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark03(-69.95707707798644,-54.46273018156167 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark03(69.95956066229535,-0.5707963241500017 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark03(-69.96628265156473,-12.106726518125924 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark03(69.9890282285645,-1.9580534233624007 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark03(70.0458975032017,-80.30944581307081 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark03(70.1019602380625,1.5707963267948966 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark03(7.011323466071545,-13.667458442737885 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark03(70.14181001344805,-1.5707963267948966 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark03(-7.025832140704865,-11.30595336809337 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark03(70.26006103594428,1.5707963267948966 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark03(-70.2723769197079,45.00840134014611 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark03(70.38404648632724,-1.5707963267948966 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark03(-70.4505348927224,-96.67793540050135 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark03(-70.60208409582525,0.0633834728750875 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark03(7.061383720603018,-1.5707963267948972 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark03(70.62091180881433,43.917374253301084 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark03(-70.66340505844812,3.5926385777883922 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark03(-70.80127358671153,-2.1420807660989576 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark03(7.082889084824018,53.09853760878602 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark03(-70.88696395660534,-66.96492520903362 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark03(-70.8908559532579,1.5707963267948966 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark03(-70.99911168695571,64.6984083047916 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark03(7.104486690590124,-3.7432744169079756E-10 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark03(-71.11427248048753,16.519222406125095 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark03(-71.15154872980152,-34.086266792400906 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark03(-7.134420217945461,74.30727690865282 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark03(71.49235688894964,26.990210621664716 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark03(-71.71936582093278,-2.108061538466958 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark03(-71.72341545434847,-3.489739385600643 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark03(-71.76916768312049,73.6347545691624 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark03(-71.77082768533913,-46.17561583807036 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark03(-71.77996765069447,0.0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark03(-7.199883235521726,2.446260662471076 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark03(-72.07511494217749,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark03(-72.12421111492819,74.31152001350588 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark03(-72.25663101981333,-0.5704152056103685 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark03(-72.2566310233368,45.55304647726219 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark03(-72.25663102951127,-73.82742736126525 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark03(-72.25663103266358,29.84513020920137 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark03(-72.25663150958795,1.5707963267948977 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark03(-72.25663293991389,1.5707963267948966 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark03(-72.34565051878141,-1.4817768405787295 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark03(-72.35101083038037,-25.935472684615107 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark03(-72.3960637639749,-4.576361282898887 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark03(72.47042845036808,-45.10306788994078 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark03(-72.5540383168208,0.0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark03(-72.65481717789315,89.76107987984335 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark03(-72.71334891581729,-36.365237657309414 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark03(72.75990517880561,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark03(-72.80712436850189,9.458714322033558 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark03(-7.301579168871086,-2596.6960560915422 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark03(-73.0435805619704,17.82629329882569 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark03(-73.055298990105,-68.53461441531802 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark03(7.309271295270861,0.0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark03(-73.26287638448127,0.5895002220099173 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark03(-73.27218715114188,0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark03(-7.330102297497097,0.0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark03(-73.37661677213931,-0.4639759249545584 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark03(-73.48087755901625,0.0 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark03(-73.55333261229924,75.25334143358117 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark03(-73.58724168945832,-9.530542999941275 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark03(-73.59879539198317,-12.291469710121945 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark03(-73.74981989008087,-82.32254188245315 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark03(-73.78462462251929,-1.5707963267948966 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark03(-74.10340706107957,1.4468514725219863 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark03(-74.11245747015528,-66.4288717426067 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark03(-74.14852447872325,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark03(-74.25759276692435,88.46281037661018 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark03(-74.39635049742155,18.17539775355547 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark03(-7.447050713172768,47.53082072464861 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark03(7.447817643884207,-55.76419388624911 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark03(7.458218247288627E-19,4.712388980384689 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark03(-74.58435425459268,62.240251802089205 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark03(-74.66257817146776,-0.27717772959184306 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark03(-74.71329578814758,-0.885868428787435 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark03(-7.493596204268546,72.61701646227118 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark03(-74.94143752943307,22.070360875453687 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark03(74.96581891843951,72.55700693708081 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark03(-74.99071248419767,-81.13419805996556 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark03(-7.511597722761021,-141.02928550032723 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark03(-75.19227065585395,-45.24271760556657 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark03(-75.2290496952493,36.461755897228244 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark03(7.525202128216885,0.32877950575759796 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark03(7.52995484539776,-4.547269986450971 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark03(-75.39822392467609,-1.5707963267948966 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark03(-75.39827624488527,1.5707963267948948 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark03(-75.4021392162274,-0.5707730952004827 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark03(75.41318305563829,29.128543944552234 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark03(75.44169930015912,-14.429438838310425 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark03(75.47270787520603,45.47860928800101 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark03(75.48949573653863,-0.5707646798591629 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark03(-75.50826550172974,43.808235445910015 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark03(75.59171716053802,1.2903373434273373 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark03(75.6230209960529,-80.16030859585247 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark03(7.564532585716117,-58.23320581901559 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark03(75.67242787852855,29.72730076855791 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark03(-75.7038823476146,-159.13595721939825 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark03(-75.78216522066346,-1.5707963267948963 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark03(75.80798063604708,50.69525013999174 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark03(75.8197189258275,1.2624935315387262 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark03(7.593128400560794,-88.2254475339279 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark03(-76.06877838730723,76.75375512632206 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark03(-76.07640515469865,-1.5707963267948966 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark03(76.12762003000402,0.31204690115022193 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark03(-76.19491617278331,0.015089787117330838 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark03(76.19594553831678,31.859259212752647 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark03(-76.25311767185255,1.5707963267948968 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark03(76.25988506737063,-2596.9348884127603 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark03(-76.31279631747803,-21.33492487965665 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark03(76.32550643748687,0.0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark03(76.33583229005706,100.61102704277283 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark03(-76.38190811962872,0.0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark03(76.40556289506182,10.2556510459098 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark03(-76.46506367200779,-1.5707963267948628 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark03(-7.652662884761382,73.66501328134568 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark03(-76.56733270757346,55.70908114052756 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark03(-76.58789090815448,0.0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark03(76.59149892099526,3.141592653589793 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark03(-76.62894858187674,-9.835952361187253 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark03(76.70430685482009,-4.635890964444144 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark03(76.76170270126775,68.92112747268843 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark03(7.677231273659615,-75.5749740464699 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark03(76.78015790618576,0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark03(76.88895987166248,1.0010693793797 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark03(-76.91388710840081,4.440892098500626E-16 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark03(76.9690200129467,1.3795048309460256E-12 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark03(76.96917633378447,-2543.0822854604876 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark03(-76.97916201456931,-15.718105269568344 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark03(-76.98865888807202,100.0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark03(77.03007028956239,-92.8809521054452 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark03(-7.703719777548943E-34,-54.977993508133885 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark03(77.05148166012788,-31.59278598835779 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark03(-77.17149171217467,-14.836939723639802 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark03(-7.717314312831128,43.181834762807625 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark03(-77.1887101560728,100.0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark03(-77.28076046416426,-1.5707963267948966 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark03(-77.30745367928859,0.0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark03(-77.34445643658243,17.179490611073618 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark03(-77.38489055929624,-0.4682149292495287 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark03(-77.44771205877784,-47.605634670809366 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark03(-77.56906678140285,-33.986617128177315 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark03(-7.757420947672795,-90.88717979624883 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark03(-77.6467378562451,-44.463273554138986 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark03(-77.76201194106665,-56.548667764616276 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark03(-77.81624341211631,67.04870479387355 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark03(-78.0155694151583,-86.76503442370449 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark03(7.802942789402725,61.26105674500097 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark03(7.807443678596229,56.50212980923803 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark03(-7.808393343928643,117.811319561057 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark03(-78.13760537971054,4.2284544104728505 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark03(-78.36160779030001,72.96232551265805 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark03(-78.36207935994284,-38.86731440455329 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark03(78.37858458378503,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark03(78.39303359653252,-82.56890088315043 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark03(78.41648416823674,0.0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark03(78.45306536700684,-0.05754269872070002 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark03(78.47656845709315,-0.2227894316281896 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark03(78.53651970906631,4.7156856110632095 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark03(-78.53859668789843,0.5649338223392265 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark03(-78.53980248806647,-48.69470138949219 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark03(78.53981633087547,-73.82742519851242 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark03(-78.53981633974482,-1.5707963267948966 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark03(7.853981633974483,-100.0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark03(7.853981633974486,0.0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark03(-78.5398163397575,-1.5707963267948966 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark03(-78.53982094176907,1.5707963267948966 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark03(-78.5403046213465,-67.54423513706017 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark03(-78.68059875284963,-12.606721032818498 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark03(-78.80517121199824,23.554695602116 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark03(-78.83621865769149,1.5707963267948968 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark03(-78.84528837377762,2629.3213664006466 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark03(-78.90713654786319,-0.036128752271013705 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark03(-78.96095883698791,5.212388985609198 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark03(-79.02812313313316,6.712388980384691 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark03(-79.21205075309118,-28.454433943060486 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark03(-79.36746174012376,50.24948762136766 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark03(-79.53154129403335,44.18465707642882 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark03(-79.55701305313134,44.790512488717404 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark03(-79.55714043768047,53.66623751869418 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark03(-79.63348501508261,66.14077605572064 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark03(-79.95791600969753,75.68708968403246 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark03(-79.96201944751854,55.09038341259131 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark03(80.09713798072752,0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark03(-80.12064322409435,-25.4729267500544 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark03(-80.16024773595775,-4.031414437341297 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark03(-80.35018603143591,0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark03(-80.35253609385704,87.7226708731969 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark03(-80.91294190483859,-47.85706665115926 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark03(-81.01640247308418,-1.5707963267948966 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark03(-8.105713553033752,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark03(-81.20725825213985,10.447992487059931 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark03(-81.40847175683203,-101.73127130880547 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark03(81.63815035542794,-25.05335235131855 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark03(-81.68140899333287,86.39379797349058 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark03(81.68140899333463,-1.5707963267948966 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark03(-81.68926398377255,0.5698790030443025 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark03(-81.68927287305517,14.429205785652513 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark03(-81.68935444330614,-14.429436009754355 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark03(81.73175572447121,44.085783961688065 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark03(-81.77017463178336,-99.65744824754204 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark03(81.77788066123586,-1.5707963267948968 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark03(-81.82460141754088,-0.29616970137051524 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark03(8.182683666632801,-57.291769604356176 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark03(81.82949776646572,-1.5707963267948966 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark03(-81.89878626578992,86.91113234715647 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark03(81.95351666134403,189.7942478741731 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark03(-82.00017382366387,0.5002750756593173 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark03(82.00910846985431,-21.117659425774317 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark03(82.02402258562027,-61.63809849022476 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark03(-8.205677431738195,-78.75211699358233 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark03(-82.09262239297682,-46.45620687125411 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark03(-82.17076979566582,-84.01731951396488 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark03(8.218111224539637,5.919055716614433 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark03(-82.186496435348,1.5707963267949019 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark03(82.23251933995971,88.30752249079407 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark03(-82.2550614070449,-46.58901179483117 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark03(-82.29048497237885,1.5707963267948966 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark03(-82.30924075445111,-0.009370370994465135 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark03(82.37143076520488,1.5707963267948966 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark03(82.40613750724853,-112.23267423178869 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark03(82.4661712170556,-16.815203117775013 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark03(-82.50604967193937,0.0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark03(-8.255424380696333,39.32812996912721 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark03(8.256941331649012,-82.80277124694841 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark03(-82.59650873118392,0.0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark03(-82.5968660551023,-83.94108835841301 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark03(-82.6358964471246,-78.75477282152852 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark03(82.63823171270155,93.98231942421074 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark03(82.74553394874661,77.42579426691918 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark03(-82.75461467003917,0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark03(82.8006120234117,13.559275018832182 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark03(-82.8348083139678,97.40600112205354 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark03(82.9374766270762,2647.7654270057615 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark03(-82.97632646264208,60.13435620808053 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark03(-82.99837197286595,1.570796326795005 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark03(-8.304538743427402,67.5451375152862 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark03(-83.21501941199395,24.783700368343496 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark03(83.25220532012746,0.0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark03(8.325805113573217,-1.6027697761854967 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark03(83.28255754039188,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark03(-83.29498514969062,-92.67698328089891 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark03(-83.30240082579641,-1.5707963267948983 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark03(-83.31128552139029,-40.01012536232021 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark03(-83.3187792801013,-1.5707963267948948 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark03(-83.32811354714563,29.80736677705931 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark03(-83.39286739893315,-11.787201707171604 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark03(-83.47435958279338,-45.46975534707623 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark03(-8.347976135613944E-4,249.756617910237 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark03(-8.361810532971178,-9.932606859766075 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark03(-8.383078348916118,0.8933050406011692 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark03(8.395022792648014,-1.042294280421018 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark03(8.399043605272128,-1.5707963267948983 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark03(-8.400153603184119,-2.595420684380158 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark03(-8.410855824993078,52.18586779708501 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark03(-84.2174225371855,16.17360629382543 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark03(-8.421767273369232,0.0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark03(-84.32800542075101,-1.5707963267948972 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark03(84.3283392046554,-2610.3088078352953 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark03(84.39467712051714,-1.5707963267948966 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark03(-84.40039107393814,95.79750717241308 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark03(-84.4158262765432,-28.818500616303567 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark03(-84.4302247889261,-1.5707963336916535 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark03(84.44473722187558,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark03(-84.45200679820564,73.45643251064136 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark03(84.50019512497738,-1.5707963267948966 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark03(-84.5194984578179,-1.5707963267948966 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark03(-84.54023741486625,81.92498386183769 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark03(-84.60769316428897,72.30303278063192 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark03(-84.6152822989944,0.0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark03(-8.465748082723934,-1.5707963267948593 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark03(8.470329472543003E-22,-1.5707963267948966 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark03(-84.79287725483763,90.4126981096008 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark03(-84.82300125176711,1.5707963194313552 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark03(-84.82300164691341,0.0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark03(-84.823001646913,-64.40264939859027 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark03(-84.82300164691793,-48.6985950090952 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark03(-84.8230016469244,-1.5707963267948963 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark03(-84.8230016469408,1.5707963267785117 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark03(-84.82300927631948,-1.5707963267948966 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark03(-84.82300927862111,-1.5707963267948966 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark03(-84.93233523847775,-1.332797300812973 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark03(-85.05029838608306,-1.5707963267948966 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark03(-85.07702233047144,0.5653458493255977 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark03(-85.12130588972313,0.0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark03(85.23941868213561,73.30877347241429 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark03(85.37098410031155,87.05908646388423 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark03(-85.41226691860689,-50.6223263964394 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark03(-85.50532569229267,0.0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark03(-85.51295017195503,-68.96160087962676 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark03(85.5405103599864,0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark03(-85.54700780199924,-72.48743826889496 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark03(-85.55331077529691,-30.575439337475526 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark03(-8.566230336854687,-1.5707963267946177 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark03(-85.81726202910325,0.0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark03(-8.61437879904965,0.3197778122004721 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark03(-86.3517368215983,-2636.7382042319323 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark03(-86.40409691998117,1.5707963267948912 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark03(-8.643928934157913,-16.070655964729667 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark03(-86.44080288403097,-0.3344464454423629 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark03(-86.55467799820016,-13.376740214425254 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark03(-86.72752143982883,-43.549557441840236 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark03(8.673617379884035E-19,1.5707963267948977 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark03(8.673617379884035E-19,-76.97683251294994 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark03(-86.83762836126861,-88.4084246880635 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark03(-8.724191314245861E-6,-32.98671789468269 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark03(-87.28565700173868,0.0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark03(-8.73290112280128,22.90441965719235 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark03(-87.63790612119242,-0.08303959289906557 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark03(8.790663787442583,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark03(87.96459433031654,-1.5707963267948977 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark03(-87.96466678245052,-1.5707963267948966 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark03(-87.96557086301426,0.0 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark03(87.9655715682535,164.93794361716672 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark03(87.98142859456188,1.5707963267948966 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark03(88.03807340236006,16.469371750826 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark03(-88.05515782687337,25.299902814750155 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark03(-88.14064181071203,-1.5707963267948966 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark03(88.18990711760406,-1.3454835097050424 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark03(88.21791755023892,97.53331106852963 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark03(88.23005592814422,48.35573974486715 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark03(-88.27768165029953,-4.734907692202774 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark03(-88.37649675889983,-0.18516876314443964 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark03(-88.41323351138072,1.5707963267948968 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark03(88.44105868342358,-96.12016627613153 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark03(-88.51651505926806,78.35856715953827 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark03(-8.851787152768736,-1.5707963267948974 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark03(8.853981633974485,16.821412381644944 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark03(-88.55255700480515,-16.079098485424083 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark03(-88.57021801606894,-2.7910597076792683 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark03(-88.58996522808923,-31.88329411504853 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark03(-88.69234909086157,73.18196582144199 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark03(-88.78758417704924,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark03(-88.8112249034193,0.03000069489793315 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark03(8.881784197001252E-16,100.0 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark03(-8.881784197001252E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark03(8.881784197001252E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark03(88.88864955497593,-8.523822545100117 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark03(89.00410591048845,136.67400744355032 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark03(89.0636323776705,17.48554681970373 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark03(89.21748599149956,-4.712388980384023 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark03(89.22304716172962,-30.575103077997852 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark03(89.39448462777726,-6.450424005532352 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark03(89.40210093688034,100.66425460530215 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark03(89.46926355798118,31.509285150090093 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark03(-89.47147252962682,13.710671432516321 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark03(89.51878630200241,0.0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark03(-89.52757049096864,-72.36350079703337 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark03(89.53575007794804,6.430172426964028 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark03(89.53620531869512,0 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark03(-89.6192604230169,-2.4330942713219126 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark03(89.63357468173645,-0.03755531142011447 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark03(-89.66848918754543,-33.922142002410936 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark03(-89.6698244864518,-30.94430898471319 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark03(-89.68202486695222,0.0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark03(-89.72284411584475,0.0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark03(89.73404576782787,-1.5707963267948983 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark03(-89.73628295823117,-46.922997472924834 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark03(89.73680038246484,68.14381717324704 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark03(-89.78397145479857,53.15849428353702 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark03(89.78660575364691,-45.68561109459574 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark03(-89.83891650463188,-2581.252938027905 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark03(-89.85012014933591,1.5707963267948968 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark03(-89.85980604810551,85.99674461655698 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark03(-89.88176419086606,-100.0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark03(89.92342277957817,-80.2022658229074 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark03(89.92989943176832,-10.56822926342015 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark03(-89.94206578947312,3.1897832776074405E-6 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark03(89.9920438742479,-25.589394475657137 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark03(-90.01601871562193,1.5707963267948983 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark03(90.01616030934764,0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark03(-90.06524916740082,1.5707963267948966 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark03(-90.20628996819771,-46.75888157283673 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark03(-90.28705066989097,-2.390450729701112 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark03(-90.28812618530591,-61.82028516748807 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark03(-90.43711582277503,60.433183888775716 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark03(90.55836667197619,-32.56785532281394 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark03(-90.58364503321961,7.694765467368211 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark03(-90.58564122294548,-14.181063822869884 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark03(-90.59699283297631,70.37553722991173 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark03(-90.62482910055994,-1.5707963267948966 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark03(-90.6423195694818,1.5707963267948966 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark03(90.66988225934651,-85.32093295561656 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark03(-90.69482974520068,-22.793773772391006 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark03(-90.77529099267362,-1.5707963267948966 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark03(-90.78039479721235,36.63515517427274 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark03(90.86480565613903,-0.12160548602644178 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark03(-90.86866133545495,1.5707963267948912 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark03(-90.89213440009328,-39.262450454242924 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark03(-90.926143878819,44.04801772995524 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark03(90.97197541881371,-51.168161062187025 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark03(-91.10456378589097,0.0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark03(-91.10613353774002,1.5707963267948717 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark03(-91.10618591709076,54.97799350813389 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark03(-91.10618678039657,32.91226456197675 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark03(-91.10618693759746,-58.11946409140997 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark03(-91.10618695410399,32.98672283063904 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark03(-91.10667527132235,-111.51609419246114 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark03(-91.11090764790488,31.76185872662421 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark03(-91.17086334038012,-74.64615207299565 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark03(-91.2453520221442,-10.547833094680216 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark03(-91.35374439956063,88.18705581925775 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark03(-91.4219247961601,5.028126822451425 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark03(-91.42517981822986,-88.45192318601023 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark03(-91.4287655834648,-28.274333882308138 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark03(-91.50675984250995,5.212388980453336 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark03(-91.58385697008788,-21.305016952730547 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark03(-91.79701362347535,15.729790795201609 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark03(-9.183549615799121E-41,1.5707963267948966 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark03(-91.84487523842625,-64.4159224733462 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark03(92.07633157392178,30.24946269959034 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark03(-92.09300935872648,78.2394534558021 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark03(-9.211550936295914,-24.334483752628472 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark03(-92.12440937282534,-59.038409361410245 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark03(-92.33221718100782,-58.12440945158389 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark03(-92.40501821345937,-15.608642739576531 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark03(-92.55016681511053,29.513203800736363 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark03(-92.57803587801132,-0.0989474028875802 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark03(-92.67698328088731,0.0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark03(-92.82813741137659,-16.813410273407214 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark03(-93.34287911106746,-74.78230641694495 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark03(-93.39717210311413,-2625.3541814543887 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark03(-9.34527626748877,1.5707963267948968 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark03(-93.51939709264892,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark03(-9.353745067612303,1.5707963267948966 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark03(9.424769574552512,-4.712387916028365 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark03(-9.424777955672111,29.845130209105225 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark03(-94.24777960718407,45.560905977052016 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark03(-94.24777960769377,1.57079632679487 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark03(94.24777960769404,1.5707963267948988 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark03(-94.24790167898773,-1.5707963253604766 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark03(-94.24790170945266,1.5707717733222626 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark03(-94.24790171132811,-98.96016907825243 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark03(94.24790171906002,-92.67698328069758 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark03(94.36510264709561,7.806501005046897 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark03(-94.37231878270521,3.552713678800501E-15 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark03(94.3871963455043,70.18059371425053 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark03(94.47909993699058,0.24593159973724454 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark03(94.49819463448151,45.06304545637307 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark03(-94.5293573093136,1.5707963267948966 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark03(-94.61765474538831,37.056590742750046 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark03(94.63629349330316,-79.26658468558728 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark03(-9.474438688531658,21.02151986900935 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark03(-94.81454714427304,1.5707963267948966 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark03(-94.82848290066272,66.115537379117 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark03(-94.86557365277635,-77.59389730501414 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark03(-94.88187320560426,-1.5707963267948966 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark03(-94.89002986407954,-0.05252206235440418 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark03(94.91548225066005,41.959252625943826 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark03(94.93041863199028,-84.21139615726064 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark03(94.93223139233646,-47.43875067068431 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark03(-94.93425348750156,-5.729463887434383 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark03(94.99663029897297,1.5707963267948966 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark03(-95.03152357267746,-61.84100849799032 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark03(-95.0388897501577,135.5219802481019 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark03(-95.10882152299916,14.429273605681445 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark03(95.1118689583113,0.0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark03(-95.16525354233252,0.49258630800729614 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark03(95.21279859896251,-78.92983146214034 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark03(-95.21830929657914,-15.82324420695991 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark03(-9.53030662027372,-1.4652676672905565 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark03(95.34547151330105,3.6725668506982316 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark03(-95.35275524450329,73.9110811167096 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark03(-95.36331231852012,0.0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark03(-9.536778862949175,1.5707963267948968 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark03(95.51760268721713,-2597.6758680498397 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark03(95.54619083674186,86.5170631841236 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark03(-95.56784427123137,0.9198274272632307 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark03(-95.58767262631574,4.475529854007421 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark03(95.63964514965464,-14.429805213944299 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark03(95.64091088887933,94.42544465330316 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark03(-95.72779325837911,-2583.1487000639167 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark03(95.75337534160168,-1.0194315056493575 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark03(95.76245854964077,64.28682023468718 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark03(95.7634176453568,64.89380672295181 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark03(-95.92132637490305,1.4487417323891378 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark03(-96.0018490049563,-85.5464814259249 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark03(-96.00340768058777,-1.5707963267948966 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark03(-96.0662061568899,-17.71915718505109 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark03(96.2747901042409,70.88750550046933 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark03(-96.44839629963178,1.5707963267948966 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark03(-96.58059090746333,-0.7120581563449662 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark03(-9.668862601903712,0.0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark03(-96.69256073031171,40.47658690165795 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark03(-96.69801747962525,0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark03(-96.80413697446156,44.030542539936626 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark03(-9.683507708209671,10.995574287567205 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark03(-96.84428798978537,69.34823246826329 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark03(-9.695891549846653,-0.020024987496576885 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark03(-9.70122101820543,65.60745708021972 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark03(-9.709797381429304,0.0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark03(-97.17966145085757,2.3700912899151927 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark03(-97.27923033464819,-1.6809382534316655 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark03(-97.32258907088583,60.88703630600821 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark03(-9.73529917712035,-0.030564957814549425 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark03(-97.3887557477383,-39.269908169675 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark03(-97.38936592168821,-29.84513303786406 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark03(-97.38937226128229,1.5707963267948966 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark03(-97.40141920672596,-72.38411428428347 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark03(-9.748922751809804,41.73677715407397 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark03(-97.5083541832848,-37.853723430056135 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark03(-97.52247444072968,99.0425779935251 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark03(-9.767691505107564,-33.569661402831834 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark03(-9.770619948370038,-0.3689675817196357 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark03(-97.73781946932183,0 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark03(-97.97853349132374,-26.785873104591175 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark03(-98.05140267290294,33.20420632142193 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark03(-98.16391564943486,93.5874427235575 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark03(-98.23946107893644,-1.570796326794897 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark03(-98.29719232229031,-44.142216532901884 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark03(-98.3127912890001,-13.986660355619264 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark03(-98.38615834644456,6.7540115426602005 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark03(-98.38865855919909,-3.141592653589793 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark03(-98.52822854697642,32.301373327615096 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark03(-98.53280719275898,-1.5707963267948966 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark03(9.85658128022115,85.64616291864644 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark03(-98.57889464017231,78.92903901570355 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark03(-9.860761315262648E-32,0.0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark03(-9.860761315262648E-32,-36.19081551628287 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark03(-9.867683612098476,0.0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark03(-98.75279316178283,6.0758098808839325 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark03(-98.78212760774272,1.5707963267948966 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark03(-98.88214011370032,-2622.8823793790752 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark03(-98.88958728355219,12.824514259874789 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark03(-98.93146965343163,77.29118512011836 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark03(-98.96114236683972,-0.005178922678484743 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark03(-99.011679678961,0.0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark03(-99.15822172719339,-0.7302768931808455 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark03(99.43516247765655,58.271799374001375 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark03(-99.51298141523357,-22.793880882911893 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark03(-99.51386730415099,0.0 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark03(-99.52440101095982,-2516.806800852767 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark03(-9.976146359492939E-12,-0.5687331902159861 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark03(-9.97876666008639,-78.84316700238034 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark03(-99.9791893885392,0.0 ) ;
  }
}
