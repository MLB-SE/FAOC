import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(0.04910087223434356,-29.54935547460247 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(-18.15869238124732,58.39639580072256 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(76.3184141920461,93.06299546802592 ) ;
  }
}
