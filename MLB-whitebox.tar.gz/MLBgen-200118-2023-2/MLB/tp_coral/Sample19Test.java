import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(-1.0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(-1.000000000000007,-0.055528053633029234,44.34153434058282 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.01153635564177713,-0.9613693976477369 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.028607920289669797,-8.22093438103823E-19 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.0607811668414419,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.06221385637057797,-3.898088833856001E-14 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-1.1102230246251565E-16,-0.9999999919680876 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-1.5237372794658966E-16,-0.9999999999999998 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-2.220446049250313E-16,-0.9840180075394255 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark19(-115.55750260267834,-0.049253825354855785,-0.6080975291838655 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark19(-11.55899168493444,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark19(-11.645653121067287,-0.044390777341288046,-0.02693858487267442 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark19(-12.045148797986243,-0.049614830895322676,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark19(-12.409882525068632,-8.406941835510662E-5,1.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark19(-13.831937628431533,-0.034020323987054235,0.9999999978582585 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark19(-16.05117348264949,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark19(-17.095505593841214,-1.2355448397841732E-15,-1.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark19(-17.480449922210667,-1.1E-322,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark19(-20.747019984845338,-0.0016274667116366048,1.764625752017821E-8 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark19(-22.094529827673192,-2.7755575615628914E-17,-0.08886887983327046 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark19(-22.538639689675065,-0.0367455185902775,0.36634566330007023 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark19(2.25690638030909,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark19(-2.272643669856846,-1.1102230246251565E-16,-0.7271611944262919 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark19(-2.359981965111018,-0.049391071701515174,-1.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark19(-26.009372899923182,-0.05731174463885365,-58.543944041946 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark19(-26.37102230525352,-31.32982676592681,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark19(-29.377446460174497,-0.06156941635338874,-0.9999999999999994 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark19(-30.16076911145852,-0.006555949840061456,-17.298623311616637 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark19(-30.533229624425914,-0.05943410472544303,-1.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark19(-3.2278000928290407,-0.021449663474896047,-6.9097619536172346 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark19(-33.025785197444684,-0.025584148985653053,-0.7071067811774856 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark19(-35.18451419646249,-2669.7720343856627,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark19(-36.559025953706126,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark19(-40.072333758862804,-0.011363961113015936,-0.09346134050715811 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark19(-40.10926222334517,-0.02429700689157542,-0.11509494115111352 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark19(-40.32646168683306,-0.06140194879071041,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark19(-41.43002939351536,-0.028156607657820937,-1.0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark19(-41.84331001733015,-0.027905853676885917,-0.5512556865683721 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark19(-43.070906540753185,-1749.5491495847364,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark19(43.81392281125051,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark19(-45.96549878388814,44.54497463202756,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark19(-47.06364117910338,-0.055639398564157526,6.428323557301908 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark19(-48.27964992897539,-0.02477845069313439,-0.4612595905140072 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark19(-49.93677019374601,-84.95358129919295,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark19(-5.161489644477466,-0.062382593621570365,-1.0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark19(-52.888115549862704,0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark19(-53.23000139310294,-0.3993169935559422,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark19(-53.82546403870094,-0.012207575620116795,-9.442772165504746E-57 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark19(-54.90496383913159,-1.3877787807814457E-17,0.9999999999999998 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark19(-57.39846786254812,-5.551115123125783E-17,-38.948205267258345 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark19(-59.86728742430841,-0.0271101374592844,-0.5531575674378321 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark19(-60.061696882079104,1.6940658945086007E-21,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark19(-60.270852108917076,-0.0037495361544080813,-0.9999999873628223 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark19(-60.88746316253539,-4.762502032357221E-4,0.0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark19(-63.36612191578972,-55.26662272773191,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark19(64.84931011921253,0,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark19(-67.47787427848861,-0.04874722408577847,-0.2427886106112851 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark19(-67.98227541398919,-5.536687455051955E-16,-1.0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark19(-69.43618931797151,0.0,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark19(-70.15675620743934,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark19(70.45923855252022,0,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark19(-70.9599766659998,-0.01965911257281769,-0.9999999996019772 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark19(-71.37458983871402,-4.079914467069734E-4,-1.0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark19(-73.06649741578131,-0.054289757588642226,88.2286821818695 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark19(-73.84730327393379,-1.7763568394002505E-15,-35.519239847279025 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark19(-74.25369759094299,-0.06052985129400956,-0.06608487346084359 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark19(-7.865390533058848,-8.357525313807008E-16,-1.000000022704822 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark19(-79.04695119301869,-95.6219601389616,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark19(-79.81768598877127,0,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark19(-80.49474968657307,-0.01993017011721314,0.9999999999501703 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark19(-84.50893789280367,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark19(-84.51420623844223,-8.881784197001252E-16,-0.021708331292558114 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark19(-84.87541838811379,-0.009334727088645023,-0.7917465257371434 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark19(-88.24246132933922,-0.053708400978973364,-29.163401211578105 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark19(-88.44937549258518,-0.06240893967343382,-0.722033352843864 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark19(-91.35046186767279,-1.9146356581167578E-4,-0.5366902146948658 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark19(-98.93000710693966,-1.0,0 ) ;
  }
}
