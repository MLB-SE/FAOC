import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.011759986917894594 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.021867358925419467 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.023584764654913215 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.07441349717399248 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.19351508281415875 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.20411196056429048 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.2088735363352754 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.22122526949546284 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.24536753133506295 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.24653019137856802 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.26527180193734523 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.27080123106580345 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.2711966331745259 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.3090590264444444 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.31351498316124093 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.33881016724497215 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.3471073416153132 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.36365959536554726 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.38603404195258406 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.3919272219156511 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.40313793432910927 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.4088717080522173 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.43303400447427975 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.4761158281286697 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.4854149759440105 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.5232274901832739 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.6040806842196815 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.633148875663565 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.6690930841599396 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.7309431640143913 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.7886638637373551 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.8187366756083492 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.8590058084218697 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.8812094961824215 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.9013285323790541 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.910018522379417 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.9293461291619991 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.9582432790837601 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.9818914535339331 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.013382722726433 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.041235865260006 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.050259783838598 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.141216453736291 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.14462734008481 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.189942570986105 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.194415947345291 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.206686734074879 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.30457155566053 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.310366144142066 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.3367387168648 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.354155952244753 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.0405978051003757 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.409106803706663 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.45439409517212 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.475128401661891 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.504622964224055 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.528263959644988 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.536074683164045 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.552492995192779 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.600753545960373 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.609976799806844 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.627899392402071 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.635419859313515 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.679942913450603 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.688171467873303 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.693080841810513 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.701192588722932 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.711085240314901 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.72548308580717 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.0762993079126915 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.854225175143824 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.875902734337402 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.880342149109893 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.887389545912612 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.902770184874 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.940220068226552 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.946980348405305 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.98085464216281 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.014049141759784 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.131323191699138 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.1335895331341 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.152156884322778 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.164672118500718 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.181010021189223 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.188327017112528 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.205818083769486 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.246594189827249 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.24908693869537 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.289212396400103 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.377317857813637 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.396790395023942 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.404471175427688 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.407098159882963 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.44993897001629 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.1462259550438176 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.473467830390575 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.1525366912859027 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.527637941218742 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.537440334334235 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.567191160514682 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.575876362616881 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.609545311927903 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.619181935583867 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.668859336968438 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.694499052438061 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.704490365767768 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.73026366361718 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.741478618359395 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.750849568658367 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.795714895277953 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.830331646672292 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.830721890114447 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.898719614955368 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.906266863935926 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.912213930685482 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.998736292111062 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.005442375334809 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.014350424681751 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.02059317855182 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.027734238468256 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.044023937611087 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.052167614714733 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.2055471938375604 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.061526051070757 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.083995811056909 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.108541472565548 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.119805229852403 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.189634220966155 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.199020070867533 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.2047763496723 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.246218444340485 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.25072010239397 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.325632124992111 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.378484344621384 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.403644594940545 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.40688073791523 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.414975366574808 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.527993079861034 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.252895303334057 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.646864951759824 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.721801064014329 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.724029024182258 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.776772301001941 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.79458684554649 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.809398149179898 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.82936914060717 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.905716911299862 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.907300325235 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.944209077084295 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.953600944532326 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.95839140801418 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.976195297230689 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.990607420195047 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.057439345939613 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.108198356364483 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.119688425482252 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.130878507136316 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.146322906083725 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.1861730639733 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.22905440122355 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.244850335725161 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.24775358371491 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.311287193480382 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.316680637927632 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.317468637615406 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.32888280790263 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.361004290804757 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.382957641772222 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.464544204247005 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.467383379153432 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.4951522920354 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.55264969774521 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.579951263888361 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.581911934325959 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.626263769462966 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.642376845142664 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.646974460835708 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.651965704765189 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.674416277614696 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.705458734446978 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.715413500201464 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.742008450456751 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.765677007402516 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.777514134775487 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.78072257794993 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.8021525879537 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.810655671394102 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.846046120080999 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.853442757511786 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.858340928773472 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.861926917063187 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.867170061685869 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.932084814581373 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.062917530939629 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.065046794235386 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.072228256487463 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.088629071854157 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.103609798914135 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.111605073919804 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.147423013964215 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.164917048056623 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.172753965054355 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.173726528763538 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.178366637464947 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.186861411020189 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.220336519438732 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.4282559651718856 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.409572604241433 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.414892004644628 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.418995217108773 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.449836272274922 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.4473429975541166 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.474213996788848 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.517721188095578 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.557799397741007 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.600002765332661 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.4615382269739285 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.62289986808922 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.664073980556338 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.674160398943485 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.694392436720932 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.709543251658914 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.74355252791068 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.751916840901941 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.772460520378544 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.4778372277761065 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.4787727569096631 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.810119978827103 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.838898284885232 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.900964021387935 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.909814038656549 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.93660302991087 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.4948691739014066 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.970087950159638 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.4981492910474543 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.037524130216283 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.062118818042109 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.083034219315053 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.10119358866649 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.118240586325498 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.126223516717957 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.136064954119831 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.1500612265325 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.151548896374734 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.5181424652111417 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.203637466624585 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.21428682575096 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.217288648389669 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.231766246831512 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.290340207703323 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.291739489068476 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.304010393965783 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.311091122584912 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.322354964871423 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.39723862674245 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.403478094386472 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.406377570572303 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.435366637959703 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.439027070434605 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.470295265743843 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.479948025236538 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.482122106042766 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.48243571328807 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.5510755803236407 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.542195330216813 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.544074844928218 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.55878213267603 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.556418259423097 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.593285652144488 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.608054701472085 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.617278521706112 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.636996131075875 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.640784909969767 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.5647809540084978 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.648433925166813 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.700615830517918 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.703336180463467 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.725771754948696 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.751539866117568 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.781057417704744 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.804566028707342 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.5839163208922713 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.883607212217441 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.890169803479438 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.918793507687695 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.006090093072586 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.03296930464748 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.039729957637405 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.6044554890799532 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.05657929949416 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.07192982703299 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.122661726029676 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.182615461746508 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.23767547322366 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.25774932798936 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.260082251054513 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.275586366620274 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.277743283249336 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.30045036172166 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.326149741477593 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.327848477165603 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.351840407332958 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.376068397080303 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.412506312563124 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.4595539033253 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.508581664627613 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.519649355682347 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.728832141017833 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.746648318412156 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.819286092738466 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.836788226154624 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.859540085568113 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.6909410836413201 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.91096569978596 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.925921408540304 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.937998767976154 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.94075109759939 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.955917003556124 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.965866523906612 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.99699462859192 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.004768458972592 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.02970757619447 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.029940659999127 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.031089365046824 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.03849696414501 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.706859974659693 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.114606440935518 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.12325157402283 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.218451033802978 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.22024421962149 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.23089833791471 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.259334703422653 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.348874279654126 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.354106773347127 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.386393722762577 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.7401713805120522 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.41847676209531 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.517508144315343 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.527354403138588 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.52873750974892 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.58040937905818 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.612905672815188 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.620153669824873 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.65828653620916 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.669550164102944 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.683666178331947 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.70217283011968 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.70361760394978 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.718001726440164 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.719421379035637 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.753240241264436 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.774088512727744 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.77982872408117 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.791756970814276 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.821909475669955 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.82530176474178 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.85005847975583 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.864143806306203 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.788662940265226 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.887535208695866 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.90985104377549 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.92270355429028 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.7999681844213171 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.00938115423787 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.074368270761283 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.11596891462625 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.120299535996537 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.124874095718496 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.8197767081408927 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.21258996192094 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.25787299391699 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.28171293111653 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.28851440339689 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.29077244295931 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.357559976950427 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.36622791359119 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.44347245211469 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.606122590243388 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.627745668907053 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.659007246056646 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.722462001832767 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.735662653685935 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.8759712014055197 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.760564872656687 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.781456303153462 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.789786934383883 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.80878578929432 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.813033653562613 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.826473232534283 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.848997921076503 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.86464282421811 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.86476875659646 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.916345101838928 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.93708448580051 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.93906771113167 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.02524806640045 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.075891278693177 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.125299749856424 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.168046691267236 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.176424764099977 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.208811596333703 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.217795960968104 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.9237815352528571 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.280281889576443 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.28294144451084 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.29731808408779 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.298996941357814 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.9327367291669333 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.33560101587676 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.373720930379918 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.383559875655493 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.43030688517102 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.45001092523991 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.480936669615346 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.499001875619058 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.503611559936246 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.51483758150445 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.577637204743453 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.578499427785573 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.9620134617075706 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.65973963062278 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.675354400427665 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.9721726193956357 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.73820768756434 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.750481029421337 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.773716981760742 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.830136930127182 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.848196367208033 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.856687847472855 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.91795080241377 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.923794553137157 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.953359799226973 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.989544250498994 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.997147178288003 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.01872435599003 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.00216105987883 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.023066886910513 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.0774825399521 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.08823605928754 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.119831568854025 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.161974495516958 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.229811141427987 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.35681586230345 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.43485456378849 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.441929246365802 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.487544827271336 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.527214971006515 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.575581770537553 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.579065205109416 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.0581704175073554 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.587100278780653 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.591029791710298 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.600553048635618 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.61140507586265 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.664995247000803 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.672590456849193 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.71878502472792 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.72779051169185 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.800455424543145 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.81573448388974 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.849475482093908 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.9117651497521 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.926379668812856 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.952558128467132 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.101234562856561 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.07918924957977 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.085417033761075 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.09358537646311 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.109832646722452 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.14097329063 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.16856687041448 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.19815979040321 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.21763799443069 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.22754615052176 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.277368608811713 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.31837192779942 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.320807879736975 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.32493574488683 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.133110639021396 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.33968012976672 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.340623895188145 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.383062023256215 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.1425147286908413 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.438920144739953 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.466550838895103 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.47696849642162 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.558680753410016 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.560286631356178 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.56665211577777 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.57696536221829 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.594923809799127 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.686403276601453 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.69012849994239 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.7196313926044 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.746532013370995 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.777251470003222 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.796404513888533 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.815244017043952 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.1926659493423983 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.95556142514856 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.99294388717989 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.204454048145422 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.080606854539383 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.090902722940115 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.099681801005772 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.14039357709241 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.17181494403242 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.229072222341557 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.27066323575893 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.294902471829417 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.330221671593065 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.362622882930623 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.37024179982059 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.384399095731865 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.43536466798912 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.43936845687935 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.464895019224215 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.47146117340246 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.48097547302052 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.494006770281388 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.50040552340957 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.50523782491274 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.54010275241221 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.576359467905036 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.58210387591015 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.669835851266782 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.68643875807892 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.69986748387258 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.705191973598104 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.71382542840152 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.71620691822463 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.730357129262742 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.75608017399513 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.27998884332834 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.88381637278829 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.894093459601763 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.898401829506938 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.916202094442497 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.91929733465514 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.972597686258013 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.2978555526656805 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.047596526420506 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.082269894489073 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.08713010887051 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.106818420040426 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.169111551416293 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.181830205081596 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.219062820931953 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.23340791680792 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.29673777510692 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.30762462754592 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.315973778217597 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.324908181303414 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.342212070261212 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.398172741401297 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.422414743549496 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.441743624571146 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.445168779416463 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.51054168610756 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.517576926657128 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.632049027719248 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.63477179656563 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.65441538870978 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.3669850769355065 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.688096414348436 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.6898220516142 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.71219369208444 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.717259916362536 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.729605518579717 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.74227402596776 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.743649324901412 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.767826328923533 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.794832052665015 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.828265501297736 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.841508358482884 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.848693341131863 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.850831457279668 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.870852329385713 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.887158990667018 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.3931488274079697 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.93283767894323 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.944688690673146 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.97906516463091 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.001497710025532 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.019128429722954 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.032258758653995 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.05834820774156 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.10860085943405 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.11928190487332 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.1668383959271 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.4168230146264023 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.169926926247328 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.18815348392988 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.21619232174217 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.25503338731758 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.275327110155658 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.427969681119407 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.28554847486349 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.31689873592127 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.324183393239025 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.344057863791903 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.363273002309256 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.366694741455603 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.4467520703498735 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.469866706609466 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.4492881422527546 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.527389021748093 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.56307803999283 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.57971408566955 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.647621464989754 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.652336732646347 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.6658423604172 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.68188639707158 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.471413842155229 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.4719245017359412 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.734059116339594 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.736833344203376 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.840169674383674 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.8485269630075 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.874397372222035 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.88873456630283 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.895622477965333 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.92008602934561 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.95184300555846 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.9621247263796 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.001570047053917 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.01717704175364 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.5062668523698477 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.0733040620903 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.106518947089555 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.108667150610174 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.124097835389804 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.154767566778972 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.162481324428313 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.162727404817133 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.17376132434461 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.22592584045941 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.230798030486113 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.30120513862937 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.326001974389982 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.336226050173266 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.351431428431354 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.537249101741196 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.42347293810836 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.44814723807613 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.479712028568983 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.4799293305787 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.513745571330276 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.515669138970495 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.523193033092255 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.544640530328962 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.5548818084577505 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.562962388687424 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.567652002006895 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.647400249614833 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.65601164921381 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.676765416911167 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.67819092763574 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.68466646316368 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.574581318594454 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.75349972300154 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.755930096510937 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.771491988080314 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.84251379096129 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.88326748399949 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.89861552075412 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.929050427343043 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.937666509279822 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.945456796343166 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.965972513447056 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.979359667559507 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.034552642076633 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.6042313817911804 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.10336534806011 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.104649493887862 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.14330909645723 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.152144858504784 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.159967131844965 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.174075899517987 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.177793208979722 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.19499465986081 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.235632456295164 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.266109131904074 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.275229434989214 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.627806486315194 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.282187934841872 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.295265953435745 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.30228732272562 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.307429234023544 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.307538861000694 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.32261337055428 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.343774791067418 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.353030030089798 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.388857146880127 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.639690980930709 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.63987428399642 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.6399168955374392 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.400956200393438 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.408505235593196 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.410105303093616 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.454730469480552 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.472934541334652 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.479656558354165 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.53045445555044 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.58653751277444 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.64694771287867 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.655082518103825 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.688014050182346 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.70815846652212 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.712076595109167 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.720895529770544 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.75670293742634 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.81398371744548 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.88961765665408 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.68953986865084 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.922317215203307 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.956590030760182 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.97757403589742 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.98004591931395 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.982953026262052 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.003997596885696 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.011065065010257 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.7023236801137784 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.025100818629724 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.03550165164306 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.04554429466232 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.078608802802123 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.097799165816255 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.112763643347265 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.166525156845395 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.23356484102122 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.270914338248758 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.730742307496655 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.314685558398665 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.353344228877702 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.413422309754225 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.7418351953083118 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.744204022304018 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.458879097049916 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.50107706323601 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.527025211833745 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.60316419922613 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.650154757209606 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.651765269924923 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.651820923549835 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.665745697049744 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.696508722000573 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.70986209103164 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.7727693037963235 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.7410020438964 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.744257848533024 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.809799555233 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.89515620454044 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.904417844593837 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.904867183572193 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.973424953204955 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.800814668188849 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.801679591178967 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.04755394232015 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.0609881412 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.073372308580048 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.085914525803958 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.087402917056664 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.125732517635043 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.129286653923685 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.133674050487983 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.138736566767193 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.142883407231906 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.186064497646782 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.234126764528696 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.2844831931764 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.286659883448763 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.8323531273559723 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.334586384562925 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.381706822247367 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.403806815080017 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.4975973953822 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.850411857943726 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.509968066167772 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.537008272829326 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.5821295164437 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.599819559512937 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.60891387345299 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.61017790116496 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.86517631465928 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.8680713740415484 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.8695416364393083 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.710855235260937 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.719228130419935 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.72325101829061 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.727864390977103 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.74030034211998 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.775351079926395 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.783769851831863 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.793926625713368 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.833302265900656 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.85038716292412 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.852473945083318 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.893292684730227 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.957686088293542 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.01499010768714 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.02235945766472 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.04982320369838 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.064164231512905 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.100813869009585 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.130575520967767 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.147746009234893 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.157772345943897 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.166915111830164 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.920547117977918 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.233018787147103 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.26331521358931 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.27165333823514 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.288376954176897 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.322818463562882 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.328926150984216 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.343364884997996 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.9353734060701697 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.400704591530413 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.43610629095221 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.45583788446575 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.46604646712501 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.485131845711294 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.50472830487294 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.52046527457432 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.54963422105952 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.55903490077813 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.956746714451313 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.57849182593864 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.58184589294231 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.586332229804754 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.9592516797642503 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.59995275153031 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.601474099020166 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.60179815229496 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.669253561420874 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.689968917519977 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.719508047013306 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.7780128277157 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.825315319711535 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.836334951248247 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.845639874874536 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.988981918976492 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.893961567151095 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.905644554636936 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.91465679133951 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.933830416189295 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.95414865428681 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.966238863523216 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.97595031360312 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.0214172759661 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.056099023966993 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.070737349043526 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.081565140366465 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.094779015573764 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.15184416561536 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.168373946823166 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.179729163944202 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.205944781925126 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.219632694134816 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.24016803302358 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.27599580185965 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.340367053736955 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.372928395856164 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.37840041103162 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.404431945886486 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.41414762239532 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.437197226701244 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.452508904098693 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.537648192586005 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.566157790198133 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.57946973979297 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.58168086763027 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.623995293503484 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.636943634513656 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.733369819693962 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.78037317991003 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.0814879110195774E-33 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.89978089744659 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.0903205259259465 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.911095938751316 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.93255804084521 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.0975289765946314 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.98770773779995 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.002423669282322 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.04262428111548 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.04466640484462 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.077745815645443 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.079582470421414 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.086709961987907 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.10328220050104 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.14312196848168 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.163938453099377 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.18979608018104 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.119585196567698 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.22783395947961 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.269086350682954 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.28310734998732 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.287028215519257 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.290375266660988 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.347746876594655 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.383690319169673 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.393136831049787 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.466244363442854 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.49109221009823 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.587525246930667 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.605567186954488 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.646115463393215 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.65677568126719 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.71493907611452 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.72490474306872 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.764762506542297 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.78256397873244 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.786246718970787 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.80825811805738 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.861556823321706 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.887859320687383 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.888216370998705 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.925960703120253 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.938627086856997 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.950078156477275 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.950402724863352 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.958381804492703 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.1958480886406164 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.982288158571166 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.056738762318645 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.08305674636189 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.09854022040773 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.101627480744895 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.1371497161101 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.189347761113424 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.27440567537083 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.30509387515926 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.314649122163175 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.2347575163670825 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.39160003330721 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.4270485540535 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.252271183087771 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.5475869139986 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.58945428698783 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.61289735163213 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.61686567451629 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.63562519936103 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.652471343891534 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.68996915651489 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.69560132406566 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.75072780654662 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.76470757285317 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.77002206734616 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.82023876008124 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.2853592440156234 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.86357549451584 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.2890018471453857 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.92389957822262 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.939132144693104 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.2984591349840713 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.99962211802739 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.01271763461972 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.014362369011366 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.0352283806163 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.15093186316342 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.15292161265957 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.16142279095425 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.168857590009 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.171019880825696 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.20181167615135 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.220842405530405 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.228882408967436 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.24827649542989 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.293798478292544 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.32970804163848 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.411406246298185 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.42748095418979 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.467068927422304 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.48272979261364 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.48274788194023 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.50667742356843 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.51203410467379 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.52574939204014 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.353147784057839 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.55362644447844 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.5591889551433 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.57532581164946 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.63755086574986 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.64681715668118 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.65455245926722 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.665204324894304 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.695142984067346 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.734622631155815 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.74174278824216 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.742593460365214 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.374322470768803 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.79418856890295 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.83014114768304 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.86894036907397 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.86976105334851 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.90755014285452 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.90843022689735 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.92216950946394 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.970563036426896 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.00697851519905 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.06370509654883 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.08092908394946 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.115791843713296 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.17969236051212 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.18200090718871 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.23679614381339 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.27073944091478 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.27183761020058 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.27646995630505 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.288123571149626 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.31054954349359 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.33837450505122 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.34069418612688 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.36581663576975 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.39156604593849 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.418673082429834 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.475336102376815 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.489393481226614 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.49840032264153 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.55189689615112 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.56532599207674 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.58007742569234 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.5970095420427 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.464383694647651 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.690265296884974 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.70488929988396 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.71150247206694 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.729891402807 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.7435782997735 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.812478505563476 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.819761509812565 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.86675256871139 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.87405611903391 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.89167342291992 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.89661988056838 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.915194883755746 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.96606582275368 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.96834086653155 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.97575641422954 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.98320551498489 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.084932347606085 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.12584518023503 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.13577935247574 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.1363714451947 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.157429669868165 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.17759405369962 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.24282159376153 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.26106736872059 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.28251008284451 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.287144643039994 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.3080904418958 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.32376269949053 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.3338160977235 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.5343818076875095 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.38914883054632 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.408643881023664 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.41464625289939 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.43811291777858 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.45564394858198 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.46395914854071 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.5477237944358393 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.4811217957713 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.53491488966078 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.5548156772620985 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.59757072153235 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.59808082090193 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.5626376297103803 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.63249341560093 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.70067912717802 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.72054412015595 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.77501353650912 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.7750621479902 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.78956092537169 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.80277826598926 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.81382088653507 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.857400163343584 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.89047234933214 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.90190852118917 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.96640362090717 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.97016877106083 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.98067792761381 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.99966011157758 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.00799673650019 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.014983514208176 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.04014130084332 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.05305848674165 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.062201698790616 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.06790887914379 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.6079768643660657 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.09972798340206 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.14738199296952 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.172237134834596 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.17490154066678 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.19737162484229 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.23841184428183 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.247303139479456 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.251627751635816 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.2595985696202 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.27910313488349 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.325767296284226 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.32648262203391 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.33515476136575 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.33716646062144 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.34244667944915 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.35902326496734 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.43248633257843 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.45106572543948 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.46309624759392 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.464032703034064 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.49693286903304 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.524014441957206 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.59042229452767 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.6594789108648627 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.618942981462595 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.63691727601821 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.66518104490801 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.67355763327491 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.676312537315226 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.716601926522216 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.733253130957145 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.75930578818449 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.824727199950225 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.89260526520335 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.907648392507085 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.927094614451846 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.93082382852311 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.93685404984115 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.948971308008936 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.95265321491268 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.95285185758947 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.96860419444607 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.70122545283202 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.02417482069005 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.050252179687405 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.0531632328903 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.05373287564755 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.070189559368735 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.08586547460471 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.13028134959047 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.13860848144803 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.155526488118 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.172587706745716 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.18510616577546 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.19780772495651 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.7258552117399404 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.263578571050495 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.263882337303954 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.27596573118019 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.29140553280084 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.733449087320892 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.34633650396082 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.366505172272824 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.36712018390922 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.36813097224587 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.369735277659984 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.380329807439104 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.38068343874188 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.38619111954409 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.41371732203325 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.47611440823453 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.554014252476065 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.56705982928064 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.57262795731566 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.59076019641792 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.59960320036022 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.63476816995115 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.66512133168156 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.66748747631945 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.681285788869886 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.70219165883073 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.72536361833752 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.74476227953429 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.82157577072307 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.88905259532838 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.89970504775566 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.90457436214207 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.908308800921795 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.93762974593526 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.96532086844895 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.99152928740879 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.005056017999614 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.007970662206006 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.03076157504562 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.8045063092692573 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.09986571862161 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.12177296425661 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.14265509912049 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.162624253389055 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.167565314378194 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.18779108747119 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.18913910260997 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.19092510803852 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.20578139880262 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.824767059193306 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.25151121094657 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.28788060060819 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.3062494430936 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.34947133167268 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.36779528121954 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.382331624179145 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.401989143313145 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.422751530104506 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.445354511722044 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.46369383470925 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.64444691243738 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.709650809616704 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.751707334285854 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.859187476316805 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.860721669974765 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.889560100263076 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.97732459001353 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.06265306044973 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.909207297450081 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.10347386907092 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.12003057558599 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.12259252699604 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.1298548204823 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.16613831488425 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.2267077093569 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.23721533230577 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.28581126414261 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.316547198610685 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.32615097264409 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.932682146836086 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.3344567957284 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.35219536865062 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.35649098628442 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.38236653876086 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.391930387823024 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.39446866639067 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.41663366267394 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.42662537012627 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.47806758978323 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.520208224193134 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.5371995704648 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.54212455854127 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.55519116694208 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.564949970825516 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.57097617639829 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.59536442366775 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.60054750965853 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.60485798410156 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.60732516118453 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.63010756401357 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.65739840809104 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.684077266098974 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.74918068719961 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.749838409658025 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.978486626445175 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.810009165518224 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.81960890115539 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.82878901713593 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.9831722608061995 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.83839143116923 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.961516708205956 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.00753843055409 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.00834952939578 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.021357377385435 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.0302107397186 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.04716155710288 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.077210246215536 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.013701094876836 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.14484592779522 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.16989649444618 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.178841648526145 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.1856150045174 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.22361033180999 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.23428902480426 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.24696361795004 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.276474576283185 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.28515947732012 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.28721119584782 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.30553117845883 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.3126231658979 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.031881891382 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.33621387170092 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.3445649932062 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.036530623635784 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.375309297874054 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.41936529471044 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.42670600090445 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.43454757002796 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.44734564196028 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.4819640507059 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.51902591147882 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.58864067653356 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.59224147044888 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.5945768280322 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.59845890819733 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.60842204983284 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.642541075500645 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.066440059481508 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.67823638483779 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.74779781242328 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.751806452850815 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.799173283092415 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.81377014741791 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.82201564772676 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.84286155193582 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.84729860408372 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.85048945671341 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.939457160640266 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.998521624498686 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.03238287154562 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.05728793652534 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.12831286987459 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.14990007613979 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.19714999062127 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.24921992544539 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.27178689992201 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.31520744882009 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.319642378008645 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.356674485346545 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.37005149632067 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.37074755853458 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.37180282717552 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.37239284532526 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.39484350261387 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.40388432243258 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.466572129640376 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.46855240384622 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.48424123785486 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.487985405232266 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.49565328416611 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.518901115278275 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.55876698553986 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.57541369726423 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.58341491548598 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.597949507298225 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.600860707107 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.67229735958045 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.67789089828664 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.694604749063366 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.710025376165774 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.710316402582336 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.73370331595807 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.77891414267363 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.79197763455864 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.182291425406518 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.82528010466635 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.843079745284896 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.872673804312235 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.88194081571759 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.89639003594501 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.905786087410846 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.91609446593223 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.91771829527027 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.937669776908784 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.9393010304353 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.19397547552461 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.94223432329536 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.196556503915062 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.199185787812269 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.00871419101735 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.03660854251545 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.04752803363397 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.06111618970696 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.062472811341856 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.08038448942706 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.09023207953506 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.17023277281504 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.20015733654614 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.20415165394675 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.223913978545035 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.27364300889083 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.315072387400775 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.33976106674731 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.35980664856651 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.38223933668011 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.4132492307421 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.43870026220697 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.58726811913207 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.61951635426699 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.647873684896624 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.66469131261981 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.69077100028411 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.720825234465075 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.741526211020165 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.75792475345237 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.87260295265894 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.90882863928556 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.92398193436948 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.9264333403611 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.927017758048855 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.94432349811481 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.94788547280444 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.97138742594206 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.977287433588614 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.98318088754216 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.99948949401817 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.034798100129464 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.07677210904415 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.308578169215124 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.091149723046215 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.0960100962072 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.16750828551801 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.18126189940059 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.20150792276489 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.320255513653137 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.24178033083121 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.324716517939976 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.27310074986972 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.286614437091565 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.36329036405666 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.37087284357561 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.399518458133144 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.40889992066146 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.46436869200447 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.46729551921986 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.4700658698234 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.48172699805741 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.496226252600835 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.505055210475675 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.353385381424175 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.6007798682599 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.62976880918743 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.63506694299948 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.649411207890054 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.65543825896954 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.693149373334975 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.75797206740684 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.75809568171587 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.773621892803675 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.77821545346463 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.80089796423228 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.83197209518139 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.87871728228785 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.903426415689026 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.91636727634418 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.91675678611442 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.946809609906424 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.983202663315566 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.98982956816233 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.02066890628875 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.0598922764672 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.184080300217474 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.204873052658215 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.25479952622307 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.28095380335686 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.28450728565765 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.30125382739851 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.34603096973564 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.347617469189984 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.36320024071938 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.379433597535 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.39851620044897 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.43020520640268 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.44752151661784 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.54639000627145 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.563881019328356 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.456964645890579 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.606920328224305 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.63800179444386 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.64279693307729 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.67070920542595 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.76433038462824 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.79575834256462 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.82191321573828 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.48631342137908 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.90461927841116 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.91138929095941 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.491640561230398 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.921524898087874 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.493095423904478 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.950197610673335 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.95086311893899 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.952119056741125 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.95735079061325 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.96297595642622 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.969077048014185 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.97674628386523 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.99667370606477 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.01272685060081 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.0284152460249 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.0418179679577 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.05001740989933 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.093963649724 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.097962279709904 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.511629366414766 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.11919402936337 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.12618906224286 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.132101504333974 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.13800396332255 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.15652999998827 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.175424326921345 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.21523309602489 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.22341424201104 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.253820936251124 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.36186935358448 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.50860025143395 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.51395731050647 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.563252359016374 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.601020734581695 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.61733759986244 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.62938801268142 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.671815776872606 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.677367259495824 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.68453330615965 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.695093207076255 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.570954225936788 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.77005596857291 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.577692619824987 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.806488297024785 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.83357477712262 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.590548498882811 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.92128795154762 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.05051393941613 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.138518494144144 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.139966212042836 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.157740132183235 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.20241591445209 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.627622254122187 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.280959002157275 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.32408925554186 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.33082366675065 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.39457757232093 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.4065058613756 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.439720260046194 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.447151692881675 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.45100070228088 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.49663072554917 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.53346006556123 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.540455671707726 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.545446378235745 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.552712064346565 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.577380504185385 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.58569779021175 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.64809009816007 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.64974176585628 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.676744063404115 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.670476585539916 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.70572469585545 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.80640518644219 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.81473204118467 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.8223999605264 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.91343701110624 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.96034229895321 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.698315160553818 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.99724501770912 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.99988971259452 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.01045324966007 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.01057164709439 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.05252220822427 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.05686847551986 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.07250954691733 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.15264762572593 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.154208570954204 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.184273157210946 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.191951260881204 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.20766304316517 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.21169629723649 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.2189029061054 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.26538838390739 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.297498891911104 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.42932077931079 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.45224532003027 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.525848589795494 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.53556910723562 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.54414416620691 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.54557310043377 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.64935748946895 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.6756925549231 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.68640677128657 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.73518173458668 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.76133725828397 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.77290971372432 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.77588261792594 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.807553012289695 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.83454881051708 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.838978924832865 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.887963454130265 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.89209034686388 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.90367359464196 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.907118521067325 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.91812863745613 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.925822087740656 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.793224930855217 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.954532394100056 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.95863597096704 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.98694173996279 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.034164088117336 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.8045603082212125 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.06634477086125 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.106758361974244 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.12112460004321 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.146485048396 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.16452820603132 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.817627001382789 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.223662402177546 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.230497720060875 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.364307792217346 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.390090329629246 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.446520204348346 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.847701475466778 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.5367985429197 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.548590723819004 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.553406810116975 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.586150545712115 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.59472658987598 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.60513494956813 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.861313565524924 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.629395224197495 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.661740534888565 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.68205024694534 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.7026583229921 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.72112636020487 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.75169517737512 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.75524038511063 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.784551618799554 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.818526638787674 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.83441257898467 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.86973372191314 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.9195174398116 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.978530290317735 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.99232873316321 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.99709062619668 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.044221983642174 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.045450514715625 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.04919236143872 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.05807820671115 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.09910269175051 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.12213133214565 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.18456026542557 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.188473833233815 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.192538227924445 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.23168230224408 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.258254562839035 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.34773289638101 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.39102421687611 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.392853344278656 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.405732537891026 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.41422266460147 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.43619905905115 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.46021926885067 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.462533233896465 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.46511299209877 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.472757740740825 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.950813630190638 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.52815934111774 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.967904878056856 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.69176287168815 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.74460298538696 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.76037607644977 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.85938275468158 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.987747724452916 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.91225269869724 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.9974893274551135 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.98340626333155 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.01111996386336 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.05725785259534 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.058731022020034 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.07044121777129 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.09636772218096 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.12469335547507 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.13617024343493 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.1422870531552 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.15350816188939 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.16503519829083 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.18324110303054 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.21521292059619 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.230079014118004 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.23973810865265 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.25509902868579 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.30833239285659 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.349928675753745 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.38337595199964 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.3857570345303 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.469623711661704 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.47043940581788 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.47830807111184 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.50144174988238 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.513983441968534 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.051940092047019 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.528695362753396 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.056180569670914 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.57254715711785 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.587112051538455 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.062682052078642 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.65572111001513 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.69828249915291 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.74337216073535 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.074551607459284 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.749205062662426 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.75131001893749 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.75823152254093 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.77063373361072 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.78477289912677 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.83995179596914 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.85487501760531 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.91589378927981 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.93763806718579 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.939704923313165 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.9505480315704 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.957721216543426 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.96394107757287 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.97230998427411 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.979848972850306 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.98321512608046 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.109673335593044 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.11185501459068 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.15396967280353 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.15524578121074 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.1585321359292 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.169315710075615 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.170570228630076 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.2156389945124 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.2203439139167 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.226559621486764 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.239929185073876 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.26800252304247 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.31996294573498 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.37105042144066 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.37743105027599 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.3841436786864 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.39666046733027 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.500790113623296 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.53244749568382 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.54979260224084 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.55840362765125 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.61784487658683 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.63238186656525 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.64845909975504 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.76741065716666 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.77547842980403 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.77692918225512 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.79556230080957 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.799894653037626 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.80499202868538 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.83771320455259 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.84392067290911 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.8446598673012 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.88754396397221 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.91644137663695 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.92273117555353 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.9283563371713 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.930202343126886 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.938799184977505 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.94770948858975 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.97297404035248 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.02873075600698 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.058529919932916 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.08387530564054 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.0931074580165 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.09875805853883 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.132848434023636 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.17115428533879 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.24208399091441 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.26017434340315 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.32227086846737 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.335432193182754 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.33682177183099 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.34560439232965 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.4185859000772 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.42877589994204 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.243691793906507 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.459863836622 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.487161075788414 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.49559814363949 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.53014898234656 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.54053989738778 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.56351465713951 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.65814447010799 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.66691855243894 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.72807203572414 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.740994971301205 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.742410447640474 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.75662768888027 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.8152905028749 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.841199674004024 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.284251844534026 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.860349507085694 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.883887310333535 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.89142776467419 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.901154745177315 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.939039660918176 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.95945783947473 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.303247774292203 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.03479965233644 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.04156019226911 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.061838295641394 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.09179178220462 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.1458475612214 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.150308165966706 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.163450120611856 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.20708866782897 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.21944570654571 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.2347671862057 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.325218952911143 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.27518168139926 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.310856396254216 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.312689150866845 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.32267150509826 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.32896255871442 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.33517587771113 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.33857454982693 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.360331043727285 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.36803353451971 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.37170019467583 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.377435487815106 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.38191993693868 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.385564373471595 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.411346534523815 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.431290768851 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.4731254001307 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.54318821422191 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.545622776835565 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.55913216350186 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.56214277675857 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.356458512973418 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.568662953072455 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.5709591485682 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.61639422815823 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.63658927543147 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.66412037758146 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.68425187594947 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.7260216187798 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.731191100344276 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.748362675606984 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.76034482347407 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.7640553977071 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.79034323339287 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.841244056465754 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.861401805672585 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.386711460660294 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.86794645554416 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.87286614057092 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.90966956564844 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.392352897017133 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.93135649528475 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.942246626390975 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.394253067722758 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.9520746128842 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.952391875999496 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.99562670007445 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.01075507764974 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.01599356065137 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.401936246167011 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.05465264903002 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.080920737562785 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.08107483585034 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.410523774131406 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.12387565091581 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.12605155814556 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.146977292248266 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.17714729851988 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.310967107868095 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.350720437297475 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.35418653370574 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.369080988251284 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.37988040801631 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.393321356784455 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.39686028940647 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.410449618183264 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.42167190261837 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.43181157277639 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.45252812078807 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.52810060774236 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.5379780376628 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.5639510977435 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.58648610743062 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.58911374600894 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.628859779885694 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.64667893169357 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.65043254710342 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.65770337122855 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.67088584262312 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.71196652111965 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.75038015215159 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.76573371215525 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.806285815536036 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.480848582156696 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.82315597852081 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.823655927998736 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.83443343651517 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.83869007576661 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.87498077859259 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.87525603909362 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.88048019726259 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.96303267584894 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.504006926044497 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.06311878729151 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.08283807802685 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.124691160907034 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.13033730171717 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.19050392298117 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.29025224002828 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.290275933957055 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.320607542880154 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.38947162388859 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.46007205412033 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.49279213638862 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.495091050540246 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.50009581862667 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.510966236650376 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.57793419181829 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.593927059295446 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.6062946004888 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.609349087272555 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.61643865360138 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.66615500730669 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.568535698811218 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.705268176511446 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.727040158973004 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.733265895741944 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.84189641045627 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.85037742182954 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.86978685343884 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.87595149439002 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.91762858452376 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.940893989337816 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.02279852840826 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.0678954868546 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.14592051927472 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.15751599424532 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.175410029511056 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.223279059573 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.22409896367977 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.26736688310652 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.26814309317423 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.6271177461362925 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.28664528566263 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.44149222809916 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.44898302828334 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.463079897825594 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.48503786636307 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.655305357532697 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.58091023090013 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.659049739048001 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.59517587686378 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.660155139154327 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.60625535084414 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.608860558681265 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.61286702250834 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.6197004494434 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.63704053731211 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.740009101089804 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.74170654879287 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.78098634633082 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.680742142173827 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.82060803228779 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.682149547755458 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.85331927900836 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.923005157440045 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.924134863381816 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.92913147636829 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.989114884081204 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.03315134853939 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.106869602436674 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.1450050471515 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.18327926738187 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.19565675500864 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.20638334093498 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.21744344245143 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.23427430607533 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.24968435291014 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.260221059427565 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.27298616758789 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.28054919158725 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.29318137972561 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.734923206051448 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.3714425267682 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.374269121811714 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.40762058573841 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.40906977374598 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.40915461478669 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.742651769873277 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.74302029993801 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.43243186573097 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.463270359315246 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.464837895934465 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.533193362403345 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.54063765974193 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.56706237707683 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.571158306373185 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.579684789613864 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.64944237987524 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.652337230244854 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.68507191799694 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.769436631223712 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.75836468514075 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.8143320368852 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.784751377464232 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.786066306936675 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.895777411783975 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.90858464492037 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.91544289181483 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.93061768743093 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.95465276846041 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.96159938445531 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.97374479497401 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.01048441603049 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.070168656073015 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.073209477990886 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.09006310052107 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.094817944215805 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.152993755478064 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.823940048245376 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.27101852017176 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.29194222341785 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.292656648830274 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.832261164882738 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.3390568437973 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.34633304966847 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.36700565687401 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.8371386526941365 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.42618984620982 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.433090353404246 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.503466088269576 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.52804952627575 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.53321199681463 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.55182220131836 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.861183553815593 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.864432447424164 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.74247036264988 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.7518024432216 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.79035648251438 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.84567240431966 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.85570163813274 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.875259182610804 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.931144788726584 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.9376498085229 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.945909933042 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.99233363433767 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.05753812863268 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.095414171258184 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.10943486629596 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.11670109803462 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.128309741333226 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.18815237464845 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.26796465731292 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.927624044523711 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.344740245627506 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.40121567574543 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.94245780629474 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.42516626226235 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.42823839927167 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.43076985047562 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.452007777034076 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.45439212026615 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.454946508352016 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.46271571177528 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.49487079319271 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.49501347614448 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.51002466727768 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.53080844840739 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.54524667888814 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.567732101885525 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.57535720673992 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.58862532184468 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.62212741263737 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.63488009139215 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.67859240188529 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.969979389482518 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.971363673001392 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.72100750440428 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.732961968065325 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.973337619329456 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.77426024278094 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.9793530548884775 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.805303932329814 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.876442741297794 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.889356612418744 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.9922936809741145 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.928129404403016 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.9464933368308 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.997537962842898 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.01502956270226 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.018561497563397 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.193324005254276 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.195847517217715 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.030036010704137 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.34344206495068 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.38704401570691 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.41671555343577 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.43338001457179 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.44223494176655 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.46786204645147 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.495337012109765 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.516267933401565 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.516823390253215 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.56118462620144 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.604780102321 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.61347798862175 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.64412966358279 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.65480156594478 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.72214313789761 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.07453001043956 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.77412012040113 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.78275921054362 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.78388928330276 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.80549190321869 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.82403554215998 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.82639595223669 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.83960893847647 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.84570425946152 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.88523823543872 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.91533084003078 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.91889202643175 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.930208433428135 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.953631146021635 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.95367012742765 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.99418743441787 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.02026464100278 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.04259350423056 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.06776942578587 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.07232814303551 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.07471556636228 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.13396172066887 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.16824648679986 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.172423211931545 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.18113738588751 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.18344244171388 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.19628321601236 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.19892462243492 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.228624467996774 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.26532452713285 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.28950793915391 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.295031491056086 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.299654964475096 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.30227113789084 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.32677605804173 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.33095965929143 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.36772793015719 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.369631504296194 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.437917104429786 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.514617448787234 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.55687298632504 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.55709256055943 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.57480011525074 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.62809271857981 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.634695184323206 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.66069088778714 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.676628213667904 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.68121703166156 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.74089829032796 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.74505198463491 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.756055547270726 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.77047367723119 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.78258543205975 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.78432889383332 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.81405224019942 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.81600317853295 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.833041453881485 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.84524967124341 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.86252669629935 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.87579349109564 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.90808783254356 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.91240533494504 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.9311280686633 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.94816493965656 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.9837853769454 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.991240593029495 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.19971802497497 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.01982850015193 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.203169286304416 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.0438192450453 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.055343155230226 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.07966047224287 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.1411175970344 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.16504839706592 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.16990451081714 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.18219455969525 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.19373539722972 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.239535556951495 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.26359508545429 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.26714298694047 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.273047745911406 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.27406172645358 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.230994998299735 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.34765831975646 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.235530048915308 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.4063054869447 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.4088113674466 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.41539396685347 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.42593940413907 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.47397798244003 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.49928686202133 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.55768065775311 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.56258402859742 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.601686262750825 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.6166035061192 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.62064924811557 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.62699419506681 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.659311798448634 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.718693215428885 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.72717356664357 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.742425842382275 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.75338786931446 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.761870561044745 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.76793240127161 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.277698762910575 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.80521809107083 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.866367188693715 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.286740436735116 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.8901549515438 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.92383832435557 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.940946393036114 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.9502060454719 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.95838462658408 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.023053938449756 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.0620719682893 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.06847290933748 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.08735462333224 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.0946561615436 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.1139196997214 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.148701348505675 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.17054110060531 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.31784989020791 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.188975027276626 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.26974824964064 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.31052797319796 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.315381659332395 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.33345315697534 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.33507946324841 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.36346632422225 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.38122379179547 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.433644619495254 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.529679173111056 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.54849806524905 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.59003616486121 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.63142781940616 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.65708065302882 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.749711228932426 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.75200286677367 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.755869971589306 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.7619479438682 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.76199893464505 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.76830574449468 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.770137380316136 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.378156140859616 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.78360385150439 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.81771105526397 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.87621648002608 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.88376100372199 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.92842293664081 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.945407079164475 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.94603108771433 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.9652002251228 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.971091241625984 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.98678961824351 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.00166023312104 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.06392991589294 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.0892730598469 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.0893764942064 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.1232336705917 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.13565359942149 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.17485442747054 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.2011058350799 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.21735630306924 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.25236334998561 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.3083749665536 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.31255920289752 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.3203701784643 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.32088003254819 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.32272959584174 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.34334220673179 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.35154741713372 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.3660910493954 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.37546002385204 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.39417949156052 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.40770389104253 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.46702170553647 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.54587979416564 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.55716925443502 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.5643237988236 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.58338010718842 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.61475592771065 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.61690382420981 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.61715211409793 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.64535494474222 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.66912055842657 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.467791398642419 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.67831821197001 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.67849825308447 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.70420909887716 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.72452358241425 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.73274723659884 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.47558226667509 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.79391421863863 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.8038138734833 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.80912540281338 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.8093987852314 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.8772853939351 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.491043541428795 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.92178148325976 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.95909829298049 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.97644921276462 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.982095672111 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.500740058713546 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.03856406538551 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.06242119787885 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.06381295233385 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.07104426282089 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.09804555427401 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.10087842956882 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.12980949931779 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.1338707314035 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.17552633848022 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.19108622813621 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.2944395376867 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.31879125717504 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.39601260993895 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.40842122751371 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.42029941981136 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.4329195862571 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.44860138006669 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.46934634144401 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.48605001134464 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.50266088686001 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.56008622033691 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.6125761675736 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.61373986534412 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.67153874663379 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.68506412499484 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.6865853224856 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.71690854382683 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.74438895586681 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.7806235010525 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.80794796124016 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.84300981710409 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.84371310076978 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.84719369485671 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.8500946316289 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.87728015673422 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.88539559009207 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.96574288062722 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.98536778553499 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.99300410008213 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.00360022136357 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.00609626031152 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.02651173847727 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.06756035368757 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.0750223873944 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.08799281453884 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.08821727885304 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.09807812924367 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.1082248626709 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.14381263551937 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.617319165541957 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.17441115931095 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.19400328288927 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark36(0,0,66.20608300762362 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.21501185732052 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.22291779202592 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.26452085169024 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.32069238854612 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.3493053423455 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.376694371301 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.38574056424173 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.3896796110723 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.640235125055668 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.41942078901704 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.45327373560036 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.647554490128186 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.5097243874379 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.5472875750638 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.56623414872763 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.58068444392393 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.63908237855804 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.71442142660217 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.71563002161051 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.673643430648539 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.76358342056409 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.79425801996577 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.84067772091365 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.88455011563863 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.68880598163264 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.92976945556124 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.95177839435398 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.97698547128704 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.699468940091151 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.0292189043759 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.0522002878249 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.06845697236301 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.0699099623881 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.10423929036409 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.11669234575493 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.13865109202901 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.14693118530208 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.16143783749047 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.1953233970169 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.21728594651648 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.27494548450512 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.30894403246268 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.33151060850591 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.34554927710039 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.35065366166083 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.37117673036153 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.3843963488273 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.40475827454888 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.44118491172794 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.54770590436488 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.57196011138156 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.58923609733799 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.6131932661607 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.6326149385774 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.6326522144953 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.69937960882149 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.78201347978583 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.83103418132184 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.83983796182626 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.85461793228922 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.86984611478321 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.87616608523312 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.00436736868002 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.00893676094807 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.02263143496752 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.12848207706048 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.12888009106317 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.1678891580183 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.18436959168055 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.19568190757685 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.25383733091712 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.26972359421623 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.31732494115015 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.338546149448 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.41579362951279 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.43959491980974 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.47980951926947 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.486884592855 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.850361154565832 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.5627370926388 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.56484566888376 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.59521288800696 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.66645227259403 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.69536478643386 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.74869488002726 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.879825873078886 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.84575465823096 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.88416104166066 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.92045240441396 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.97701038800435 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.900787350087853 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.05785137269369 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.06059504325216 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.07280109509017 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.0801972519327 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.16814187270421 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.17471146308591 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.17989169673632 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.2027422289534 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.20691749562882 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.921213377141427 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.23642213574121 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.2675636578219 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.29137750031984 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.31893771441575 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.3203049559898 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.32834941939421 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.35080673531793 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.39429232340652 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.41248473957037 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.43127769467168 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.46126426657653 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.4810770505558 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.49044399311603 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.50540013431606 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.50636518069922 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.519175801063 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.951997717485185 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.954333256644048 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.55911496001683 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.56269340710675 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.6209678911817 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.63695963955212 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.64377019504582 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.65111810152706 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.6569180629939 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.66837885831731 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.71416714945727 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.975174248057783 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.983050377639003 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.83315883190409 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.83332258158734 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.98697531737804 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.88328283396294 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.94154463788234 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.94258182317415 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.00283972049448 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.03937908399666 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.05584334749588 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.07834385093415 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.09254700954976 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.09944702519797 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.11468661790663 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.17367542425961 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.18793006959028 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.19020811665237 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.19223406517708 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.19604245388693 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.23874323502577 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.28938270376015 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.033544484518188 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.34681956328959 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.036431237552037 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.37360631655898 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.4093477750304 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.40985825721675 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.4276355205647 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.045298542666359 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.47003097339342 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.49167035436277 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.54342131615314 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.5802966744059 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.60153930501625 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.65343526408543 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.66811955920396 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.70985540212777 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.071543523679452 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.73191025979786 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.80483670177918 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.81024818592299 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.81722218881185 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.83506937080746 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.8493170433014 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.84960750963563 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.85722126589984 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.87027460315605 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.91747848520174 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.092859686878938 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.93915789121208 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.94036326633204 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.9514294774223 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.98116601188498 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.98527726742776 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.0141393426612 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.03419461715177 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.05578083063065 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.06052387814566 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.12953829850967 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.13254678275327 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.13675811101963 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.15937950943771 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.22823923699193 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.36747044050449 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.142893528830484 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.4393692158927 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.44604251678516 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.48050815431377 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.56172603037707 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.5844386405098 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.61484721052969 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.64356885901877 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.65757305156346 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.67349011327171 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.70299978153727 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.70379833984464 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.73579327200952 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.746924962452 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.83593639331443 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.87017018234532 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.87218811036522 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.92807035306853 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.192981553120404 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.98123562931491 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.199008247696142 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.0053308408232 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.02546175163114 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.04412626003524 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.05749069153227 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.12515601778031 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.13870074470942 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.16261326783172 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.22430068108045 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.32362815743582 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.32795842439481 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.37773908999344 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.45365792408356 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.247532257356397 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.54573357520395 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.54778803747051 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.57615339785409 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.2584621226286 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.59939634087638 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.260406339388609 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.261403545490779 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.62309458436502 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.263291358172651 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.63877890576205 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.65195700133017 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.66584141739192 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.7006917298991 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.72962708766006 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.73237266510316 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.74219527121552 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.75002122802383 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.7614941479313 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.82123201471853 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.282858180973648 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.84386279730893 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.8854446771738 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.9264179933815 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.94140636558922 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.94488628223684 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.99089369084439 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.99560089090713 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.02343027822087 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.06143856368308 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.06353387813431 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.08793771605244 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.1782388354348 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.19400934203165 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.20181244724495 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.23658500312622 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.24477820760819 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.25135096105437 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.3137505491707 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.332700906250935 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.33739976753162 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.34785487286162 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.39071667566512 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.4091569578051 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.43081275263357 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.4429234344669 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.45200529410307 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.45552368411433 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.3540969871623645 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.5412265228573 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.35496442251366 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.56519264444574 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.57130102563694 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.360565311311333 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.60725900234402 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.67779914408183 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.69221726017639 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.7073925206034 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.75966091542023 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.38018624491707 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.8241645958743 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.384005600580679 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.384383799841004 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.8552951269725 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.87984849605502 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.91477664135904 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.95500128062443 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.96114288380005 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.98228843820407 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.99309400117355 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.01959723479916 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.403786026707721 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.04935775099115 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.406062799624166 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.07815165462551 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.08480593522933 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.08798034704552 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.12889767008136 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.17389783038439 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.18672461241906 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.2863936390052 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.29080711695329 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.29862774493586 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.3159182312775 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.42270839573808 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.44724346553309 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.4588227917961945 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.6529856637429 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.66934183934784 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.69838819873354 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.70704801037702 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.72571330672116 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.78138363576339 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.479260507137681 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.79304131315025 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.79655877637225 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.81998652741126 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.84989342467432 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.90957890413853 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.91613678384905 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.91876278757512 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.92423939457878 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.94324656936854 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.95542917529394 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.97265238127737 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.97308291251645 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.0008137803581 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.513115309714436 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.14376184421133 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.51791631334082 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.183095492971 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.18987377121826 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.19606467403652 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.52035447673272 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.2252333370695 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.23707826744538 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.2512731599686 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.27835788073598 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.36097314609809 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.39732732143733 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.4251602153113 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.547734102390663 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.51041987860035 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.519439282509 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.52702440546575 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.58003020364762 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.61407179763575 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.62435690383676 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.66781873098742 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.68920690561532 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.72159412192623 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.79829150550859 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.84466868828765 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.87726355121481 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.89351090843223 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.96938302823695 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.00972458061969 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.02156118891551 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.03055847202067 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.04930978698508 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.09082089152412 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.1396823891733 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.18467782742519 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.19270545999336 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.23739948692088 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.25909520933376 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.27409081240526 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.35181250704377 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.36394423867728 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.638851110603099 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.46106296045744 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.46571260823521 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.4958895134288 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.50079400286454 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.54123334882992 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.54708832832307 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.56401220836011 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.58295224582585 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.58413542941678 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.59662703703316 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.61445668937286 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.62709087388313 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.65002948204733 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.7018647458197 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.71349887418685 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.672108233148478 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.72894380023622 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.73775629311955 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.77822164608074 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.80870889594786 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.84726374549061 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.86903550095661 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.689656126765371 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.92390804992893 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.9592280737206 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.97489553291447 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.01599898567378 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.01671235304566 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.03061047844768 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.07527175134615 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.07919725729803 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.09525679775695 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.1627785980328 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.17448257427921 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.718115204917268 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.18115839245307 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.19159042849253 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.2558529769718 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.27060923851828 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.31621250498534 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.32430047755805 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.33163039220426 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.35732329043503 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.36263455131088 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.36892550818588 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.37561210182199 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.40989033187753 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.43004071738181 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.744237348401256 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.46521151985944 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.47853243220388 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.49653535079088 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.49676388763096 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.761633275004456 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.63946074801106 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.65650857322808 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.69777627563204 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.85707309988767 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.787741011289384 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.91156635631673 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.96414358470432 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.96674516560938 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.98034085378765 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.00479728335674 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.801945398509517 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.02372772937912 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.04750295999764 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.04823697217482 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.06033937255852 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.13988456638488 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.15392712234276 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.16401951097107 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.16825650565069 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.17056567115665 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.17141863130443 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.17910838594642 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.20045505246647 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.20325119913196 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.21280411894097 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.2375249892583 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.25308126745563 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.28983826023034 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.29259630937614 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.36980486856109 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.38983555593359 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.43677051073297 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.46182111656677 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.47238546965846 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.48227682472957 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.49744868366572 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.50695871130615 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.5164831118739 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.51649072428874 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.5170973251238 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.52604577570352 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.52933272945478 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.55902074420675 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.856904111490067 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.57640239399066 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.59891786762884 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.61092200826283 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.65286954932563 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.66460264972999 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.67808020296519 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.70456714876244 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.75445057563331 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.8763542835742015 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.82598154619302 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.82899994823016 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.84638780810764 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.85064948563294 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.85697101811708 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.89127205597453 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.92052154501499 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.92383675069738 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.95899424028309 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.99330290931223 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.0176210510844 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.1050009168011 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.1229137426663 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.912311400912486 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.12354910642219 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.1269926663812 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.18311724196055 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.22891797844844 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.23176376772028 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.23402531263453 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.23407645896219 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.923899115104049 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.92392024675334 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.30909984354153 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.34062697836784 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.38325395227272 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.3896994015777 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.40103492406774 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.4189059557753 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.44351649165861 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.48915863719819 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.52995383557916 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.953380701848616 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.55094512589464 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.61043005357396 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.64103003761771 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.65681265851535 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.69441331248129 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.972485659429694 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.75236438579401 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.75420494720072 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.75520277066148 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.80449056849002 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.81303715764585 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.83618860005812 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.85619901161299 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.86058618767797 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.91094431013877 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.9357142073904 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.997614790733067 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.99475321711913 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.001704593591086 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.01863392524216 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.06011514943476 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.07968400675753 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.08994397925701 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.1181082830918 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.14910039567498 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.16403527159288 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.18441302388271 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.21848739541817 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.23804596382539 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.24295702382128 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.24761027005651 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.34769459435327 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.42259118634618 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.4442120463898 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.47585760836644 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.050278071999315 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.53547466122856 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.056435935620925 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.57994538252899 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.58880902261345 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.60170619380497 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.64358941433296 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.65302122382833 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.65897573851257 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.71320297087605 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.072664058190739 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.72931324694319 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.73483660809664 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.73865013113107 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.75080574134196 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.75464728879969 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.75633039287935 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.78771917888012 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.85015597639212 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.85760153986179 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.89331189573872 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.89647939538038 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.09528553399288 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.1054195636243 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.16884786406584 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.1892537594787 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.19920309844804 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.20745855475231 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.31113138519592 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.33191235234705 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.38756408939165 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.42293189240881 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.44129039478321 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.50770603703792 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.53631611922705 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.593486087188 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.61059206748695 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.63275186502806 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.6331650825922 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.71923392122787 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.72195497699883 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.7699531897852 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.78271198473345 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.78906907481752 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.81964121827652 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.83431233504923 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.94144427773801 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.96061858947297 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.198043471916904 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.02115781168018 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.03197518232781 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.06056080451793 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.0911369764648 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.09437429121895 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.11391420732035 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.12699569297072 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.12789965376317 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.14507235050272 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.25040628617111 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.33549263816201 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.34618003834571 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.38119583626022 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.3815457747884 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.39494829463729 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.41313771219637 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.24477347670394 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.45821213531224 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.4668301435494 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.50767200134646 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.6324631289598 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.64788437772614 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.65657967031099 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.66008179616367 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.6788808606766 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.68498960968205 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.75043605346667 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.755887882485 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.769304262056 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.77628657986642 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.80297977389901 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.81111246114654 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.81432618146405 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.83941405763169 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.8622898561182 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.86861427643721 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.87843000080086 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.91056736741938 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.9218651374045 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.92594437501191 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.296155129404852 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.99112435052179 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.99968958897648 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.01425467714098 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.03681561948959 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.04040993043355 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.05335344366668 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.05614648029325 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.09797440834345 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.12500268983167 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.18217537667294 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.1985886755746 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.20275538750568 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.322855086666408 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.323160567054046 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.24388505767249 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.324708335442693 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.2648171657201 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.29000536723252 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.31359210979015 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.38792238889646 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.3906994803473 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.39469035178222 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.44891643090627 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.47684434212314 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.48328539417966 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.49654631846086 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.4972359875504 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.50715713680205 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.51925278061441 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.57597545875895 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.58665098422237 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.68213686857578 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.6929313309135 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.70805903407994 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.73476909205957 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.78769308240537 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.79719538893261 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.82322061954883 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.87940839757853 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.93073907198348 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.393658466647167 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.09344082979662 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.12584135203613 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.12645384000126 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.15950357233407 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.20220958740543 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.26492056888881 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.27950241783857 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.28072086096807 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.28875556370082 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.3481377112131 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.36366132529629 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.40403424131857 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.440323942626 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.44624413051636 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.451635247107632 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.57098613372209 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.58940625229852 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.6023056644622 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.71568119445814 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.73123600586834 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.73946528222602 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.74140575896098 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.75036606667874 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.75860975157339 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.76245839682 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.78105977568362 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.78598258746607 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.79089770912096 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.79558357336145 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.80662394767538 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.84597116077548 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.87063291732689 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.87132271929121 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.89691379666753 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.91585791298522 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.92325538572835 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.92405645980602 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.92693863485212 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.93112442244015 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.9873911416269 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.00179275992225 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.02217402085981 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.03279955481293 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.05537449803344 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.05830739711256 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.17830095547865 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.21295127535478 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.523299437466775 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.28209861033717 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.29486604523409 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.32648335361661 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark36(0,0,85.33362346342295 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.34356243981685 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.40482787394099 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.43269567232167 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.4468935479812 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.44795311946689 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.47920227473142 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.62037691245699 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.62506743100502 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.65182313516499 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.72515344677625 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.736276517388 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.75211750617062 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.7539174223341 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.77021841329413 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.78552996023245 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.81245822766019 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.87270695773785 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.87618429091405 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.588926866787844 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.88956674919422 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.90884783510154 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.91184859656018 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.9207896957322 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.92816483132364 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.95719959904591 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.598089450780066 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.99997422686877 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.01710144960026 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.0688330906626 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.07757474033069 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.10256216751309 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.1129962748744 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.11651819633248 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.1501490385827 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.16490563027853 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.23727905614692 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.25742512327113 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.29436166429436 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.30264140422297 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.324327872053 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.34074711185988 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.41898259432156 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.420189565547 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.46559717395587 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.49827715880838 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.5368932604348 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.56500808119961 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.58085067925671 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.59873551033871 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.61790827403296 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.66577821126107 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.66724175863767 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.68841468635347 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.6700501420532 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.71286877318582 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.75658232072254 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.75760753106745 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.75855619459534 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.78156709687985 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.80240150239558 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.82145904333005 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.869376739745 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.690824671485515 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.98807220845022 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.99543559112266 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.02665836781631 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.02835393117441 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.04908509279113 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.70539450476116 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.706525555348492 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.08385368528042 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.09249305049642 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.14336410195122 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.15112584326977 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.16753103167345 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.17870925186739 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.20983807019135 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.26292479010147 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.27255222101175 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.29090436624429 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.35062671955565 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.38238912384062 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.39882013479472 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.41071440759049 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.41492925454631 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.43833488072632 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.46549924576014 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.49326518046168 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.5047366182859 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.753742321368406 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.55491424530047 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.59021019220536 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.60057715286138 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.762283563714462 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.6342715906395 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.64845603834392 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.65224551288185 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.65597667585654 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.6611824477043 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.67977041693985 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.69062821282355 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.70382150948126 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.7055274596896 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.72216505350052 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.74409705807578 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.78859880819039 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.78863624510262 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.79529932331019 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.85165029972579 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.85863055421783 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.88477717908943 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.88917989747821 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.89606679171122 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.797832946134548 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.00935223588262 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.0097363203898 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.01527819006674 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.01815868221644 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.0340774425231 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.0401429267406 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.07586664112085 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.0779240483595 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.11108465197981 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.11343326586625 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.11730050494886 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.11868337644924 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.12382304962627 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.13979947874854 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.18024447588222 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.19001406021034 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.20261324112724 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.22587104865201 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.24065073995678 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.26121021170785 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.26379892398714 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.27250885733537 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.27822437105476 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.34772022316861 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.35046294686548 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.37351668838913 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.39234610786639 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.839453009351587 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.40946539991457 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.4105110955086 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.41228926768233 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.42968205795447 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.4956296556451 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.50565874289524 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.52399533386534 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.85418416575321 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.54580356339775 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.56326583214332 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.56333889534346 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.5847936246133 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.619201269718 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.63451114116336 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.67937862843223 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.71934379931652 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.7526965384845 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.878503450916469 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.81634808385486 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.840176175907 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.87644894372634 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.888715112793918 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.93458594209895 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.97926780615285 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.06809966776392 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.09696728287888 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.11691306313834 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.11894033180215 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.16356306162585 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.17755881314537 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.20350146083476 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.22665600083583 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.23304357834584 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.25742479827133 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.3317210369013 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.33370312368109 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.33633271410075 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.37296505454506 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.94397560508402 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.4421143390002 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.462290671832 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.47226610193661 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.4940355815664 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.4955287108833 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.56205399562583 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.56504153868667 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.60487828631616 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.67143540015705 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.6719617537787 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.967581654702045 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.73257860710406 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.75368713314415 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.7587932705457 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.76342710913852 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.76821328608187 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.76973920979243 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.78570133487322 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.80920505878551 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.81165600709132 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.88599385771926 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.90806440771904 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.91425628552221 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.92547198667968 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.96913225464012 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.97657393727141 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.999484178348709 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.999614659463575 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.02583874296958 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.0337823372273 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.04030153104114 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.07855244111116 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.1013875728708 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.1376878670961 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.16075940791926 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.20427888274413 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.2089983587598 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.21835394879739 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.23704270784833 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.25059271740466 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.32865664592012 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.36201877498604 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.37314420652669 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.3887749405915 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.03958050227341 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.042704661322716 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.42861535162965 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.4643681360441 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.46623914550185 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.479721586468 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.51648313237881 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.52274617303482 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.5271536400433 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.58717230630472 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.6016833545594 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.61730380764645 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.63307810306172 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.63825165256839 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.65707653733644 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.67266351871963 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.67737338958135 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.69319320843196 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.70714943326057 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.72140416574639 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.07339160734584 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.75127989435944 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.75324845576405 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.78865607563247 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.7980240434662 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.83861217843403 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.84919201435858 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.85600908274432 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.89075900853176 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.9043216032817 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.92822283046263 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.09290608412519 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.93010571728341 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.9491456623557 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.095637932545685 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.09812225196876 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.08879415407051 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.12806788257737 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.13580583639663 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.16396595422482 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.17232385733011 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.19205242766631 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.23910623035096 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.25010268619107 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.25172688131462 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.32018772225119 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.132144413657599 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.32900381607678 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.34527316522411 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.34659927072946 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.38026501399071 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.44791365251564 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.46459368968851 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.49411343882727 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.52022569110406 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.52333388923381 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.52572919502353 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.62494425852026 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.64048703088494 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.6532288960285 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.66553916977713 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.67308023493985 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.70685232966949 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.72682163147132 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.73260731271316 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.73750062181372 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.77639695138086 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.78737874132872 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.79635601290947 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.180328991354813 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.81564370551669 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.82793751587299 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.85551496689992 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.86003821683069 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.88622818231968 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.89534228776938 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.89666365728363 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.90510172959792 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.91121433698407 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.94926092118558 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.97484246260828 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.0163388328173 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.07211437663547 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.07898783182016 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.11430137584537 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.12436042487937 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.1252251170194 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.221443274200979 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.23733511766655 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.24749942380903 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.27280550419626 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.239194292293078 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.40510696101181 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.42609647569515 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.44133363410016 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.44820483245995 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.45350959182976 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.246658342049201 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.47341675506175 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.4895032843607 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.5015636546087 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.53683707556515 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.58792726198362 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.63773717676757 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.66743758489015 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.67618020443382 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.69077296887953 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.71020641316687 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.72850526714006 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.73451188469942 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.73673687982753 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.273934294499696 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.77024382655819 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.78768932746897 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.793233021131 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.83792578968475 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.85850765386279 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.86953840804155 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.91944764049613 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.9269973971995 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.93482926630776 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.9363004684477 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.93898578462777 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.94943040020091 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.99115265035421 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.00037613128545 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.15284454577039 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.18694575423628 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.2187010831038 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.22638653757225 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.22855134113024 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.29244073397803 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.32873484251287 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.33054719359674 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.34270741601283 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.35036196033192 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.42872436309196 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.4560523264607 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.46585427120293 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.46832970264897 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.47341147390414 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.51726817288721 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.52507097487903 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.53217176850335 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.58840871397192 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.59384501761447 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.60874832954067 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.62135831353045 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.65341068766459 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.67151009624254 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.67151950236932 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.67664535443242 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.6776464302399 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.68281111613477 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.68643520824142 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.372690215656121 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.81007191202733 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.81654296451845 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.82867632544183 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.84839392877069 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.86364716425557 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.87344805057293 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.87473465128483 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.91098292017111 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.95913269661679 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.98939282649519 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.01719327623937 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.02515674137442 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.03453424140773 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.03743595395045 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.09883085217277 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.13942848700079 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.17697071767999 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.2484154858693 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.42801994941999 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.428551793425626 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.31518155710437 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.33869030531712 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.36298781540408 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.3775176192095 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.38914348613446 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.3893898902091 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.39551929542864 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.40840746550654 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.51349515948648 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.52325415217919 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.55409663660963 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.57356117484386 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.61603366559983 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.63033046844087 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.63196351821195 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.63395702925578 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.65401365800146 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.67449063854411 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.71935267723211 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.474123226093994 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.7512395569392 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.76425184736183 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.80063980545907 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.8215262561799 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.83043083861116 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.853861795332 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.85875879797044 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.87208770784063 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.00055394313524 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.01298442568375 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.02253977147804 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.02644415211357 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.02703937288139 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.05928499783016 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.0738814399643 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.09458211981121 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.12709044233247 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.13358247514469 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.14366784635972 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.16712281996638 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.17337795099839 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.18670210088027 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.19221440849938 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.2288266732049 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.26829658912315 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.2767486575802 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.31879850770599 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.32137733278614 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.32344726856088 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.36558300736884 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.45102910990013 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.4767185299834 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.53255005517724 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.5543155650198 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.55478164692319 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.560675382215095 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.61246184995925 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.61878661475644 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.64488478376609 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.65173498159876 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.565970892652615 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.6671589031794 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.69760692983577 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.70061438959424 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.7242512419495 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.74198447899039 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.75764482147025 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.578864169893691 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.82738997606728 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.83111864880766 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.8482732794481 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.91310564932118 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.92129082097698 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.92804170441181 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.92971425728598 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.94585881268272 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.96136564323325 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.97986469445404 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.00509160153902 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.01507288027602 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.02448358667644 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.02898403219776 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.11243073545117 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.14264179440129 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.23923295098274 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.27342333722223 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.27804069389443 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.33990258893913 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.35501048034092 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.37550092494722 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.38166851173821 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.38636859354213 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.43468196660162 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.45927965566439 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.48183575572284 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.48531078486207 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.5320592584042 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.55065403353196 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.55546120647756 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.5598573881347 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.5975724429449 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.63604829945498 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.664681326186809 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.66223298884337 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.66891654921524 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.67372711256303 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.69459473025086 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.77537645408154 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.677886129506746 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.7964433677166 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.80453350014564 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.88021768325483 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.92555215246617 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.92797091341117 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.92850704866014 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.92961774598147 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.93518046109655 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.93686266566952 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.694277304116355 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.9537555147661 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.96262213116825 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.98646631913076 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.99224874222392 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.9946079901018 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.99522830525235 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.07058103730357 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.0964858241729 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.09759068311661 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.15639777295064 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.17013592556786 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.17129019168782 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.20535078592565 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.23960056636191 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.4009747216998 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.42638307466851 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.53752792901314 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.57176446490492 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.59807183286249 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.60320637666213 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.63372831203331 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.6345104467783 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.65539321004195 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.66459064644812 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.66660426662293 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.68851644434555 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.71406117555455 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.781193582513836 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.78191664554737 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.84272789826123 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.85407241097444 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.87068846145807 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.89189319771418 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.9282646905951 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.97958420780988 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.06307894213484 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.09212083549666 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.12115694074241 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.12469982680052 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.15989696296825 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.16428592192645 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.16549160583341 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.19964870121203 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.22877722754846 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.27810064706067 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.3121348170532 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.38966195384327 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.4220882320999 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.46311729972138 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.47918921906098 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.4872723089528 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.50406374524994 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.50836258649755 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.5336474887844 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.55180484629923 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.855462097878046 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.56361246871326 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.58120134596928 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.59324906525745 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.66065005522653 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.75309203666053 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.75348178303318 ) ;
  }

  @Test
  public void test3659() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.79966225598073 ) ;
  }

  @Test
  public void test3660() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.8032013793606 ) ;
  }

  @Test
  public void test3661() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.8296555924475 ) ;
  }

  @Test
  public void test3662() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.84571217998894 ) ;
  }

  @Test
  public void test3663() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.87119514433375 ) ;
  }

  @Test
  public void test3664() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.87916256959937 ) ;
  }

  @Test
  public void test3665() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.89738083991485 ) ;
  }

  @Test
  public void test3666() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.90291396852753 ) ;
  }

  @Test
  public void test3667() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.93195575149383 ) ;
  }

  @Test
  public void test3668() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.93318564454184 ) ;
  }

  @Test
  public void test3669() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.893733196336669 ) ;
  }

  @Test
  public void test3670() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.97428719903863 ) ;
  }

  @Test
  public void test3671() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.98039381732463 ) ;
  }

  @Test
  public void test3672() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.02648665271549 ) ;
  }

  @Test
  public void test3673() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.09249303780553 ) ;
  }

  @Test
  public void test3674() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.09569968574291 ) ;
  }

  @Test
  public void test3675() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.11526113391879 ) ;
  }

  @Test
  public void test3676() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.11983729994816 ) ;
  }

  @Test
  public void test3677() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.13315592882921 ) ;
  }

  @Test
  public void test3678() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.914749767528804 ) ;
  }

  @Test
  public void test3679() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.16822923734672 ) ;
  }

  @Test
  public void test3680() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.20220693738709 ) ;
  }

  @Test
  public void test3681() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.920287807668387 ) ;
  }

  @Test
  public void test3682() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.22061681684325 ) ;
  }

  @Test
  public void test3683() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.23919009013396 ) ;
  }

  @Test
  public void test3684() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.929711315521715 ) ;
  }

  @Test
  public void test3685() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.31683348314415 ) ;
  }

  @Test
  public void test3686() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.34204551221701 ) ;
  }

  @Test
  public void test3687() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.38638589429335 ) ;
  }

  @Test
  public void test3688() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.41763358327054 ) ;
  }

  @Test
  public void test3689() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.41795240691742 ) ;
  }

  @Test
  public void test3690() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.43298917116073 ) ;
  }

  @Test
  public void test3691() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.43664685845867 ) ;
  }

  @Test
  public void test3692() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.944788524843332 ) ;
  }

  @Test
  public void test3693() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.45161213260654 ) ;
  }

  @Test
  public void test3694() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.46812323849723 ) ;
  }

  @Test
  public void test3695() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.47172604341404 ) ;
  }

  @Test
  public void test3696() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.48831807212206 ) ;
  }

  @Test
  public void test3697() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.48958401986717 ) ;
  }

  @Test
  public void test3698() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.56481928302779 ) ;
  }

  @Test
  public void test3699() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.57301061567651 ) ;
  }

  @Test
  public void test3700() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.57356115738175 ) ;
  }

  @Test
  public void test3701() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.63241914524133 ) ;
  }

  @Test
  public void test3702() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.76440905390125 ) ;
  }

  @Test
  public void test3703() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.7659981567725 ) ;
  }

  @Test
  public void test3704() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.7876605859153 ) ;
  }

  @Test
  public void test3705() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.8125382570483 ) ;
  }

  @Test
  public void test3706() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.82611137857896 ) ;
  }

  @Test
  public void test3707() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.82782181001195 ) ;
  }

  @Test
  public void test3708() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.85090775910166 ) ;
  }

  @Test
  public void test3709() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.86551423231913 ) ;
  }

  @Test
  public void test3710() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.8781582277892 ) ;
  }

  @Test
  public void test3711() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.87932612058039 ) ;
  }

  @Test
  public void test3712() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.88323665498386 ) ;
  }

  @Test
  public void test3713() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.988557948232213 ) ;
  }

  @Test
  public void test3714() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.989070657130597 ) ;
  }

  @Test
  public void test3715() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.91777627258969 ) ;
  }

  @Test
  public void test3716() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.97283291491392 ) ;
  }

  @Test
  public void test3717() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.97879649583767 ) ;
  }

  @Test
  public void test3718() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.98214907315644 ) ;
  }

  @Test
  public void test3719() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.98962246032161 ) ;
  }
}
