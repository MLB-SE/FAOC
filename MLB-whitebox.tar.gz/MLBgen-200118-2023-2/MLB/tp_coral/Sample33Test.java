import org.junit.Test;

public class Sample33Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark33(0.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark33(-0.49903374447356674 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark33(-123.059184146399 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark33(-1.232595164407831E-32 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark33(13.046097182194316 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark33(-13.799121957999816 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark33(-15.60681024811683 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark33(-1.570297444993943 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707963267948961 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707963267948966 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707963267948968 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707963267948983 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark33(-16.143749541540195 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark33(-185.35396846914645 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark33(-22.264620457440188 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark33(-22.435918320319715 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark33(-2.43755471468279 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark33(-2643.8432962258485 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark33(-2647.4291830106063 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark33(2.7755575615628914E-17 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark33(3.141592657315087 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark33(-3.1415926684910804 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark33(-3.1415928920083727 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark33(-3.141600282984325 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark33(3.141635754252405 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark33(32.338940443340846 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark33(-32.71853978348405 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark33(-3.6279994784178484 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark33(-3.6379705582803012 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark33(-374.849525776456 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark33(-40.84195065141207 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark33(-47.58468707580072 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark33(-47.6056793102741 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark33(-51.56318799021218 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark33(-54.91421856266532 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark33(60.57602919856956 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark33(-62.38709499708517 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark33(-65.84899058285272 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark33(-66.06402423503279 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark33(-66.46383682060362 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark33(-66.49586359975599 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark33(-72.49011047523481 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark33(-75.1136417472568 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark33(-801.84971731344 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark33(-82.19674364494884 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark33(-8.502575770094168 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark33(-85.43859524962872 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark33(-86.74040766611834 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark33(8.881784197001252E-16 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark33(-92.57281423845987 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark33(-93.60633511184533 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark33(94.45065062408844 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark33(-96.01879621313694 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark33(-98.21786563107524 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark33(-98.23557922377748 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark33(-98.89072011345468 ) ;
  }
}
