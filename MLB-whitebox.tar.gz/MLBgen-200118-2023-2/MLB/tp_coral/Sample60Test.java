import org.junit.Test;

public class Sample60Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.006817036585131192,-28.89411210533504,71.10588789466493 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.00951920112172544,58.915119538407666,25.868293730988924 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.01444905706337174,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.022273192909051283,-61.716253102155896,42.45317636524619 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.03151275899678119,-98.06352296909613,28.599232038345463 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.038152785650911625,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.04727495440378937,43.844507877588995,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.05255393584863517,-19.927489295768048,0.0788256013329528 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.0549915475133563,-1.3292716808764418E-79,2.2227587494850775E-162 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.43373135948848773,-1273.9477481215658,1043.801132738178 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.8800077213799445,-1284.8027297162469,1207.942274333966 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.9999999999999964,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-100.0,-0.15873868033327937,0.3526760265252508,-3.4953359050141177 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.1102230246251565E-16,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.1102230246251565E-16,0.0,-6.233430081390353 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.1102230246251565E-16,-3.944304526105059E-31,100.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.1102230246251565E-16,40.05701223822796,-23.400237414710034 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.1102230246251565E-16,-94.30213879520124,0.16708165676302428 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-12.596615850904058,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark60(-0.012663832665381847,-100.0,-2.7755575615628914E-17,-19.243058278860744,0.024499916504865382 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-1.9259299443872359E-34,-2.7755575615628914E-17,-45.20736784102531,0.03472338043620837 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-2026.6887001137816,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark60(0,0,2.465190328815662E-32,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark60(0,0,2.506788327513007,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-2617.2660144902457,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-27.240719822338548,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-32.55315837935632,-0.04193633544011166,-6.604163603885523,0.2378491940781629 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-32.63479332177859,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-3.6112259901767345,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-4.440892098500626E-16,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-4.440892098500626E-16,-46.291457271499056,8.277420669469862 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark60(0.0,4.711932674054086,-0.25667609348259113,-7.347633138475348,0.04005273568773482 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark60(0.0,47.82557964250683,-0.008018980572901707,0.0017929042230883023,-25.939166979311903 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-50.65725298725574,-0.002648151923101036,-44.109861262420054,0.030940188845669025 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-62.5408911329847,-0.055963040391880325,7.105427357601002E-15,-29.17367856750287 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-6.618050029181035,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-72.14026912358423,-0.05448965166661453,-4.480854785593699,0.27093469324878416 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark60(0,0,84.25287334880056,85.90359339406083,57.70497471779987 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-8.526577731287066E-4,-74.6374307580318,30.623006066178107 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-90.11465367035329,-0.02926226928564757,0.15598303068307312,-10.070302647128623 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-9.322854525259672,36.071418155556444,-44.427234564258036 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-94.8314570685502,-0.013172092499965208,-16.723079104598646,0.09392985089467931 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-9.624816907925832E-15,-29.516985411147726,5.622530892603603E-14 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark60(0,0,97.33570051693283,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-9.900999236591565,-0.007139188446547536,0.05347944302178155,-29.076446108144953 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-99.98693056953383,-0.04962218964262831,0.004604830490800055,-45.114118979989165 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-99.99605849296954,-0.0029276038109533726,0.12018480779046,-13.069717574067221 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark60(0,100.0,-0.016414633027731496,-0.12998450023282926,12.084489488987296 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark60(0,-100.0,-0.038062770185770034,1.4956640328245783,-1.0502334029029612 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark60(0,-100.0,-5.551115123125783E-17,0.17922537510077774,-5.302057865904635 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark60(0,-10.038953390009127,-1.1102230246251565E-16,0.056026056283243975,-28.0368891012712 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark60(0,-10.417148686890926,-0.7136251200615215,9.598495228101601,-10.389556000730854 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark60(0.11862738603945466,-26.555450395885074,-0.049150085754374274,0.7551208213149972,-2.0088567572433447 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark60(0,-12.674834767450424,-0.0760748782132856,1.3877787807814457E-17,-1743.209041256257 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark60(0,1.4189321929519405,-0.0203108794370658,-3.631027110870036,0.21887558825039122 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark60(0,16.38256154279737,-0.029201455542875145,1.8029774598054706,-33.14810766890851 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark60(0,-1.6617891611488034,-9.288949068794324,2.1579172514724263,81.11141972367432 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark60(0,-16.762616911080634,-1.1102230246251565E-16,0.21197041919864718,-7.395693216818639 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark60(0,17.451649302443826,-1.3877787807814457E-17,-0.053746968471909184,0.053746968471903855 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark60(0,-17.749648284649084,-99.45088318008688,-57.11941987313103,36.86975706708341 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark60(0,18.819395455750637,-5.551115123125783E-17,-100.0,0.001562466067509205 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark60(0,23.532432726529983,-0.010653545727334013,-41.88342438258826,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark60(0,-25.653610843825835,-0.0194552743621628,0.049494967977780746,-16.07714392086897 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark60(0,2.6331056946541747,-0.018510594688850718,2.8421709430404007E-14,-2.1126481551147815 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark60(0,-26.47354137925947,-0.015540645642321705,-0.5844032977857183,0.5844032977857101 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark60(0,-2.8421709430404007E-14,-0.06246849148078082,0.11601764386641134,-0.11601764386641134 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark60(0,-32.92235276294339,-0.0037672246863103,6.657285982165471,-8.228082308960367 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark60(0,-38.86251607263142,-0.007712595990207516,0.0377381271028423,-35.72984435692805 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark60(0,-42.225598347066935,-0.003713245435096574,-7.882213873291406,0.11586272197096759 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark60(0,-43.28470331386701,-0.007511556505219619,-13.14216253047848,0.09468221695425039 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark60(0,-45.99631065372541,-0.03975436771323129,0.2563616747302356,-4.852830460608521 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark60(0,-53.418094464962465,-0.04902499091915735,0.06624116250505874,-23.106421047129135 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark60(0,-63.16687406617048,-0.05614063934607776,-1.7549705748096778,1.7549705657704842 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark60(0,-6.457559274499746,-0.009770212579567153,7.391925396172923E-5,-7.391925396172906E-5 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark60(0,65.94218770152861,-0.04766588590160059,0.09626679073996572,-3.2378594443297626 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark60(0,-6.683265041936304,-0.011423089930281682,-1.253942425186445,0.09672109700668208 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark60(0,-67.34279766822434,-0.06048339566835153,-4.12756873092646,4.127630441777257 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark60(0,72.72383389651789,-0.05644495989638655,-0.07794707848364624,0.07794707848364622 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark60(0,-79.6222118693043,-0.008514494071892644,-1647.7880535800646,6.938893903907228E-18 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark60(0,81.98768573001303,-0.051133852360288695,0.18734479146936586,-4.828937445059159 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark60(0,93.60405580177739,-0.011383003393626592,-7.328017147395477,0.211448681411323 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark60(0,97.48959431565763,-1.3877787807814457E-17,0.005337163279356151,-62.85860537236184 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark60(0,-99.51424520682035,-0.01981358736095082,-31.38810629963579,5.22999557639181E-4 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark60(-100.0,100.0,-0.0046890049976487935,0.19639969863529205,-3.53362204743764 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark60(-100.0,100.0,-0.011845883947485604,-1.5612555144413305,1.00611098712883 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark60(100.0,-100.0,-0.9431937809117189,-3.3251545662892683,1.8251545662892685 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark60(-100.0,-100.0,-6.164953360180266E-4,0.01659586497275431,-4.361187273052595 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark60(100.0,43.438525233030504,-8.673617379884035E-19,0.38540013878847473,-4.027388097076198 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark60(100.0,-4.770717299569995,-1.1102230246251565E-16,-10.306991587134608,0.09423691450114888 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark60(-100.0,-82.65685616241976,-1.1102230246251565E-16,-41.90878094426184,3.333931117700806E-5 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark60(-106.94400807021105,-13.851708158250034,-0.047489826597880744,0.04124688618502027,-28.937328637297206 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark60(-11.990558368365278,1.0046542657745756,-0.03963719007168138,0.43322848916886125,-3.6069136245766513 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark60(-14.027990098416224,76.59904392889855,-0.0504427008439014,1.7763568394002505E-15,-91.72517076858486 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark60(14.831820371899672,7.304565412055326,-1.1102230246251565E-16,4.20192931065262E-5,-9.557760630000203 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark60(-1.6543612251060553E-24,99.5344988500806,-1.0339757656912846E-25,-1.0382928127618682,-8.390488556632775 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark60(-16.919932830821534,1.3979518849656287,-0.02438345021488518,0.17794892623213376,-6.6137021963878055 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark60(-1.88079096131566E-37,100.0,-7.669367393823437E-10,-22.63145712143607,0.06940765317788877 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark60(-19.708277877462656,0.07160594671227116,-5.551115123125783E-17,-37.86973885727595,6.896334791449671E-15 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark60(20.168065136642383,72.26498375924189,-0.05259946462982157,0.609783750903589,-4.747859386810998 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark60(24.72256652146277,19.15124070783682,-5.551115123125783E-17,1.7763568394002505E-15,-4.091068117033425 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark60(30.566824853767667,-36.128947843283605,-0.05870460586996007,0.09835683625715319,-15.97038280784087 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark60(-34.236721312045916,-81.2034303262976,-8.85720533683346E-25,0.01569319879946806,-23.287450945790347 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark60(3.883144274624603E-15,-14.25477722887796,-0.007842554632988386,-4.914809166153913,0.3177187575691553 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark60(-43.424410713631644,78.14043984378687,-0.03168126165006324,0.041538891466815664,-37.8150754545654 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark60(-45.611602407948666,-57.723502119906456,-1.1102230246251565E-16,-2.5404752352167224,-1.6014775787987392 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark60(-46.95207099958202,47.980179508120656,-0.03825411549346083,-2.071633484397758,-1.0756673823212846 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark60(-47.13412726590389,100.0,-0.03368353995615303,-13.314783260438901,5.551115123125783E-17 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark60(-50.407819931093066,-82.15221606883316,-0.02717759049414989,0.03294951046133576,-47.672827450292885 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark60(-53.20032099892056,-55.111841781208405,48.245306557352706,11.342067880003583,-23.063814409531602 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark60(-54.1195258881792,10.554487537047962,-0.010327906700188474,0.05309483844329459,-29.584727496110375 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark60(-57.72200928494562,31.95057720521538,-22.30322848200241,-23.143673242965534,33.43822154426769 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark60(6.182743542810586,-1.2589236009353098,-0.04621569146456038,0.04384408666927442,-35.82686848157534 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark60(-62.24118307336437,-57.27534726547601,65.89254234110999,-92.1214716047774,9.795909908440109 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark60(-65.27039686814554,48.15491632672304,-5.551115123125783E-17,-25.93086660462803,8.723314277023775E-4 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark60(-66.5746704691784,-63.39125753727568,-0.004434119059819469,-4.059699481481627,0.12976927936662208 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark60(70.8854514584556,100.0,-0.062370392307970965,-72.7719738560713,1.2951111278414196E-6 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark60(-72.20780046893728,-37.618726608278216,-1.1102230246251565E-16,0.025074673853314716,-57.83147152298512 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark60(74.93560813182063,0.44180705176302126,-13.93204084654927,77.65254975825843,-82.57541289928794 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark60(85.78029019922411,53.515442793901286,-0.013878895802009456,0.0063918020377112805,-10.501022103255067 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark60(-96.32685450797413,99.29730613319109,-0.0039882096218684035,-25.630314843147655,0.04587907422308929 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark60(-9.793741908228752,-94.26580358947676,-0.0021410162025574803,7.076488441332346E-5,-85.36136897693751 ) ;
  }
}
