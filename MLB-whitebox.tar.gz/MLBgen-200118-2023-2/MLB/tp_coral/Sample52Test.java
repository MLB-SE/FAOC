import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.018537470786431927,72.2050270950804 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.02638834922425646,-3.9227561551266765E-8 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.049392171232373716,1.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.05232282413624645,1.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.05484665394357081,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.09279171447944101,2193.178699675033 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.09570728498890489,1.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.09977254555759085,-33.98041399194847 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.11598832036988131,0.9666696370555169 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.1161544424048715,-1.0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.14384781137695052,-1333.4625630189098 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.14770743126802444,-0.0656266639369063 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.15916117346759145,8.369160674421897 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.16209632908865051,5.551115123125783E-17 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.1626280064174062,-1.0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.17003340044939463,1.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.1791235994493638,-0.8393731619723579 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.1970493168370906,-35.78561378171314 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.19728217959162192,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.2118085376541785,0.9999999999999982 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.24223276449257242,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.26440271712928576,-0.033071059769269565 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.2799107121777442,-0.9999999999999978 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.32171390064825955,61.20837444838759 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.3579600003668144,2357.5894451471995 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.37157879851245473,-68.52844020364563 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.38759102899510023,-0.983061116687877 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.41590405711754486,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.4268721161577158,-55.220662454321484 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.44721343045183937,11.399744029586696 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.4602945208162308,91.15573437211668 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.4665318655366484,-82.82525333176152 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.48740068346228504,19.925290735356505 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.4904835695395816,-0.017204750544436306 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.5509679816082684,-31.15112405574905 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.5557812104337785,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.557105639705063,-1.000563936513553 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.5609356110773263,-1.000000000000006 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.5653453672994794,-6.6174449004242214E-24 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.5714386179450122,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.5746033923603804,0.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.5834472826466948,0.8221863504276092 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.6110731476102467,-1.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.6223643607556777,-0.06255252818832145 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.6363491407964853,-1.0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.6512091725425807,37.67456519779179 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.7034525417596228,86.24161413915658 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.7198203914046275,1.0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.746747608012373,-1.0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.7849122178331643,-64.32357289271746 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.8483278333964361,24.474435614380425 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.8567041164978781,-0.08789434152242848 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.8754978987964609,0.6179905626235389 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.9141960206382546,-1.0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.9306785862944231,1.0000001226756978 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.9327541551564077,-1.0000000095881392 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.9535665367752607,-10.203748575355398 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.9546346926407949,1.0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.9642307112260794,1.0000000017429103 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.981790506077733,0.0069444263767222125 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.9886785646018642,-1.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.994869018730185,-52.686135849550205 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.0088637040828912,0.0625525254352883 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.0505627900825566E-5,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.0582629376170303,-0.3898265465311983 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark52(0,-0.10655537822576466,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark52(0.0,1.0741436562368596E-19,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.0783698483679711,32.13442632473994 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.0791660195252728,-1.0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.0793656840576633,-50.49830591408722 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.0798778996495226,-41.654054330330524 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.1211084549645134,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.1403347249304936,0.3326985917097006 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.195478433289313,-0.9999999999999993 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.2457663327341053,-2267.4640698786125 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.2687303963748588,-37.836564468659326 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.2842492558990168,0.9999999999999998 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark52(0.012941424727281998,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.3086530190185308,-1.0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.3238734688662108,58.613146598850875 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.329757624385735,-1.0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.3331388987927308,0.45543837021825695 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.3660276406404595E-8,100.0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.3699706249071033,-1.0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.3706807018801612,1.0000000000000058 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.370686439410078,1.0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.3776768656655358,1.0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.3886377963938714,-0.3472703201662479 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.3892389127773708,-1.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.413133183101525,-1.0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4234142006191621,58.24334194886664 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4432791976004424,0.9975562760395122 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4445958148799463,1.0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4622090189893697,75.10996107143436 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4634690406517628,100.0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.470783482983387,0.9308146103343627 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4866684061039184,1.0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4871946592183503,-0.9623842407557256 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4898536609942283,-0.9739835324476193 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4928586752379127,-0.9307483773224473 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4931708884340043,82.56351100692838 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4941382278617847,76.28424355791297 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4973990490779285,1.0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999403624389,-48.96903277265193 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999995569047,0.7625046413520334 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.499999999999988,1.0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999999964,-97.46540642264799 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999999982,-1.0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999999987,-40.1784941920283 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999999991,-0.2244957248327309 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999999991,83.59393034430724 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999999996,-1.0000000000014155 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999999998,1.0000000000001956 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.7756659007410676E-15,1.0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.7763568394002505E-15,-0.9999999999999999 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-2.0423550578442055E-9,1.0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-2.220446049250313E-16,0.7285081784482641 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-2.220446049250313E-16,-75.18130199214085 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-2.220446049250313E-16,9.104419837890877E-159 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark52(0,-0.2862757629276854,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-3.550433974764491E-16,0.0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark52(0.037376913078588814,-0.09138418631707168,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark52(0.04069001143425835,-0.7414624384446382,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-4.128169478603263E-8,1.0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-4.235129859939687E-4,0.820518685730657 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-7.077353807828086E-5,-1.0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-7.105427357601002E-15,-97.86816580306794 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-7.3227383490997605E-245,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-8.570699455431612E-10,0.5178612445331745 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark52(0,-0.87341570673936,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-8.881775287813964E-16,-0.03869515027609231 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-8.881784197001252E-16,6.84097733505933E-14 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark52(0.10036969378018101,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark52(0.10289742439963617,-0.24226287043015038,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.0408322690690568,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.0476863740785518,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.048911014885915,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark52(-0.10524554599193414,-2.0548797961198572E-9,-18.371563085686446 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.0760148065970379,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.0E-323,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark52(0.11050724852487687,-0.14018766561813817,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark52(0.12442898364946586,-0.8773371343029988,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark52(0.12889949640055853,-1.431137657852105,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark52(0.13292486606179788,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark52(0.13689799333825636,-1.3401018063431565,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.4052034897219636,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.5,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark52(0.1625396961459888,-1.3502745227772417E-8,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark52(0.18261755310717917,-0.7652655991945831,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark52(0.18373489407656507,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark52(0,1.9294458244127242,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark52(0.19651665662088424,-0.7603694214201027,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark52(0.21451486721875312,-0.5477251862253274,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark52(0,-25.49920149911577,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark52(0.25639091669205705,-1.3904528854639713,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark52(0.25753348617152483,-0.30674663900519006,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark52(0.2621330497249507,-8.635713142075306E-8,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark52(0,-2735.6518241676017,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark52(0,-2736.104525278587,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark52(0.30449274907822893,-1.2222833811351352E-5,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark52(0.3467438371492642,-5.843606874673352E-8,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark52(0.3486220354895915,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark52(0.3677771789627382,-0.7779358633933591,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark52(0.3685640733996962,-1.0041801044178622,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark52(0.3723782006566978,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark52(0.37595668078208,-0.16189522181106497,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark52(-0.3776816463593755,-0.2540747357831851,-43.326672686337474 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark52(0.3927248069887934,-1.499999999999989,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark52(0.39503323340649743,-0.5054206491171531,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark52(-0.4003310188893016,-1.2388888663973017,-0.0625525256792228 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark52(0.4007445049017093,-1.2119010819481288,0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark52(0.41294854238658196,-0.9880585176281733,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark52(0,-42.51992750722167,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark52(0.42558367765232674,-1.208583845835463,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark52(0.5169528161766681,-1.0311641567791234,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark52(0.5249380526334213,-1.0486955372738436,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark52(0,-52.895452559803125,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark52(0.5303184878744519,-0.7149045828544613,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark52(0.5336139223795513,-0.961819616728941,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark52(0,-5.464143082671832E-19,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark52(0,-55.19087709218158,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark52(0.5717525865955952,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark52(0.5734927401176857,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark52(0.5910451904107348,-0.056921144690345926,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark52(0.5928024782690364,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark52(0.6293652190264822,-0.5011995748956526,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark52(0.6449190878760032,-1.407757786984386,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark52(0,-64.68434611908438,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark52(0.6540261066471892,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark52(0.678929340592461,-0.1676818063014025,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark52(0,-69.12355084427229,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark52(0.6938318713255538,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark52(0.7302338676102447,-0.2875887077079929,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark52(0,74.45492094688728,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark52(0,-75.5993648574912,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark52(0,-7.703719777548943E-34,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark52(0.7953464898109293,-4.388357443983418E-9,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark52(0.7959599018976137,-1.2820201633886086,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark52(0,-7.989783627634381,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark52(0.8315938895616727,-0.31387895758102846,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark52(0,88.24787002825514,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark52(0.8848127417701289,-0.5332873493874093,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark52(0,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark52(0.9061237155377171,-0.019406448165601997,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark52(0.9076641400872931,-7.949521653991679E-6,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark52(0.91111867846476,-0.9574919001324469,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark52(0.9164707406241916,-0.013627428860112282,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark52(0.9485244449636383,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark52(0.9763082949933066,-0.8805734499784279,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark52(0.9772519457055893,-0.7514105455077811,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark52(0,-9.860761315262648E-32,0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark52(0.9897540369357368,-1.398228800372969,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark52(0,-99.284675459574,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.005623989855364164,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.01298222512610725,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.01907574543791135,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.026397004579592535,0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.027039664987155893,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.028771449101903435,1.0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.0468885723055259,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.04775346924880419,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.05340324525759238,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.06427804829328548,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.07018015957283108,-20.938974551121333 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.07211325408006666,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.08404026731012208,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.08491393664136138,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.09774413549153416,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.11491149716252805,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.1606718428013595,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.16169440516915415,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.16701540393169384,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.17787814517800962,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.19731259210333527,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.20595496201420893,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.2107972517033743,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.2108742755086413,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.2347150712037207,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.23749005744661145,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.23828820785773594,0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.24071765259056555,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.24998698517147658,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.2949119297818321,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.29497047149069644,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.297133185726399,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.316811197831473,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.32870118562915296,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.3500699592194978,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.3546509232110106,0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.3618956843375223,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.37075964447281073,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.37171783266789504,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.41196200274639505,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.43520202537782987,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.43526938273506627,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.49187400351361266,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.5173051838109188,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.5481492031497411,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.5818688622573056,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.6035584757160051,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.6166165069157131,-0.9607942510221102 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.638860260571235,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.6423130538576157,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.6678366590457444,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.6937211125511777,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.6989629791873402,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.7500044922305238,1.0000000000000009 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.7614572709928579,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.7639862166226259,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.7724243083498319,-100.0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.8050519043717133,0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.8494573831036991,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.8625491410052456,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.9268867409026513,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.9525582568301458,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.9671510132231421,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.9693236166089437,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.9895512857547644,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0117565576631868,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0361559604956545,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0560544444502762,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0654072903477965,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0754470603397976,0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0980898981443416E-8,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.1475723562981415,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.1563930017215966E-8,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.186481297907599,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.2188837091988827,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.2335351765062315,0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.2384898629991703,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.2510039779599966,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.258283210757773,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.2643296524535629E-9,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.300625530051133,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.307264784248928E-9,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.3080320952059463,-0.9994192019975892 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.3220719571425432,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.3323554430668796,-63.78173489688817 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.346981129834159,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.349797408670082E-15,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.349887339760244,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.3665338735297763,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4181495054557964,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.432623335232978,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4426910844610719,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4459041789843415E-9,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4983701956434566E-8,0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999967485105479,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.49999999989331,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999147,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999538,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999831,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999938,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.499999999999996,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.4999999999999982,1.0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.4999999999999991,1.000000000006795 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.4999999999999991,-1.0000000000285758 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.4999999999999998,16.259560175673638 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5673561757168442E-5,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5882299610066153E-7,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.6349497573645094E-6,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.6543798668460658E-7,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.6599787890550926E-9,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.7648525031366039E-15,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.7763568394002505E-15,55.71443970015332 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.882134863355003E-6,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.912437505982633E-9,-100.0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-2.1887027869305856E-4,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-2.218788678228027E-4,1.0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-2.3904430400417766E-5,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-2.6082523050128968E-5,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-2.940718320977569E-4,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-3.107337700040753E-8,100.0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-3.71113095247811E-5,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-4.260223814841891E-7,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-4.420659699135017E-9,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-5.064705666543183E-9,0.0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-5.7685336999180265E-5,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-6.25757379143046E-16,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-6.63790218354908E-8,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-6.756501799871912E-4,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-7.33929055551261E-16,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-7.449511506791031E-10,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-8.587037823745936E-10,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-9.624919773708373E-6,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark52(10.034106388597479,-1.4132748782754772,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark52(10.040413381493522,-7.037171854787456E-4,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark52(10.053976542554437,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark52(10.125658831707213,-0.8707403235654225,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark52(10.137073728065552,-0.6586172662003766,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark52(10.189182235988,-1.1218205772722172,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark52(10.198179753494799,-1.28517868342675,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark52(10.204173595617469,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark52(10.27655649553219,-0.0037933197260429097,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark52(10.283721395286776,-1.4795899914431527,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark52(10.318853739959238,-0.3702307193194514,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark52(10.323384252561226,-0.9384802874458984,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark52(-10.331285354664788,-1.4999997971261572,4.962290632656365E-7 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark52(-10.374373914550432,-85.46037484044658,14.419454538018044 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark52(10.395667342505185,-1.4999999999669063,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark52(10.409726742272369,-1.487238838164373,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark52(-10.425400462894167,-5.502156726721578E-5,0.6565535879036648 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark52(10.425889138992412,-0.32169637781963767,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark52(10.458686940125332,-0.63370129439107,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark52(10.477421712216923,-1.0266085543361134,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark52(10.492656640935621,-0.28564890751023597,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark52(1.0522644587521097,-1.4999999999724483,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark52(10.539712729319685,-0.023158349373203824,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark52(1.055047259489041,-1.4585698306694717,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark52(10.600209889340661,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark52(10.602435543037194,-0.7196380534722518,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark52(-106.57817289380259,-0.8785168917015757,1.0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark52(10.662734665078318,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark52(10.713233824340662,-1.3632348707989195,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark52(10.73154821279951,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark52(10.77610943645955,-0.32339137329828027,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark52(1.0799186826764782,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark52(10.807245672812321,-0.245100914500875,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark52(10.872640170864528,-0.38606105648823785,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark52(10.894352252353098,-1.0158925550362755E-5,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark52(10.901092960266492,-2.8558746356337774E-8,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark52(10.912484552990952,-1.4220508366689217,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark52(10.930959956252687,-0.21068203894533716,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark52(10.946763156011045,-1.4999999999731253,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark52(1.1015661093611868,-1.3560623316771672,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark52(11.059633135160169,-0.9728387382659491,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark52(11.065083958409616,-1.2189681710285099,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark52(1.1102230246251565E-16,-0.7772491441598184,-0.036113115771375465 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark52(11.11961298019088,-4.0552712922893566E-10,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark52(1.113827926566202,-1.1701145973903295,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark52(11.140679920835694,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark52(1.1141635363554978,-1.354722215932361,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark52(11.283084508445285,-1.4185816534066276,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark52(11.313265319750379,-0.482651226937727,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark52(11.392021592161328,-0.9438487964252005,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark52(11.402968908358178,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark52(-11.433354912437082,-0.805636354615433,2359.030375445759 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark52(11.458677097696679,-1.1257727698001059,0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark52(11.49431267087742,-0.09127878581433668,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark52(11.538033151429687,-0.12304806443190719,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark52(11.547986923082618,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark52(11.550011579187093,-0.36139879286098847,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark52(1.1565872241555013,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark52(11.568991339913836,-0.8168271719517182,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark52(11.572817779716786,-1.446499515340547,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark52(11.580354141262418,-1.1608764099524356,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark52(11.65735457558121,-0.942985021966507,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark52(11.728114904184721,-0.007348878374079493,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark52(11.766459043004218,-0.3254811990890687,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark52(11.82373123815239,-1.0537796579560563,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark52(11.849250930432024,-0.1331843929832898,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark52(11.876768026223592,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark52(1.195439044951121,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark52(1.196789324298905,-0.530780476211318,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark52(11.989720836508031,-0.47151245857983004,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark52(12.078783658630158,-0.0370226138888384,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark52(12.078857218817006,-1.3648702793549616,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark52(12.081620715671384,-0.5686474714226435,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark52(-12.109889884817399,-0.12492784851109556,-30.767334461902706 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark52(12.136987454945977,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark52(12.1478522904888,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark52(12.17906683058661,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark52(12.224044236143314,-1.2068434696150376,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark52(1.2226688108919754,-1.2012549590826076,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark52(12.23121806301593,-1.4939968089069706,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark52(12.273632562871006,-0.009810084614434444,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark52(12.297224920080014,-0.3572899857283953,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark52(12.304576589006274,-0.06516856968707074,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark52(12.308808053421245,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark52(12.391584707113365,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark52(12.405690309438642,-8.580541217462423E-9,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark52(12.46248380262287,-0.04630410116445858,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark52(1.2464320512983313,-0.9165008625718842,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark52(12.487220970835477,-0.735994781050406,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark52(12.4961840631818,-1.1311582007426262,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark52(12.509708536840193,-0.625810543754309,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark52(12.537448479026253,-0.7382296880541392,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark52(12.63165274068884,-0.2927930399047788,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark52(-12.652974751516457,-1.2243442098507136,-0.016291370334436894 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark52(12.658688078096787,-1.094979672544242,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark52(12.65992890988521,-0.5420413603565208,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark52(12.67771278083843,-0.07757544917352671,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark52(12.688026658881654,-0.8115075148794677,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark52(12.706680663501754,-0.9540581296177209,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark52(12.766337160128913,-0.7148103790435247,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark52(12.868509305492239,-0.11434450130405693,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark52(12.872279610904116,-0.01173760339953045,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark52(12.886804976876986,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark52(12.888579590430751,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark52(12.903051024782371,-0.1214134800555291,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark52(1.2924697071141057E-26,-1.3691232506412485,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark52(12.9499027641085,-0.5679810714839011,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark52(-129.88542478237238,-0.721532633943462,-1.0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark52(13.01952690133767,-1.431131711423589,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark52(13.031342000405008,-1.093783125312095,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark52(13.056293348392458,-0.052532640215400384,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark52(13.057245507963517,-0.7811226134417583,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark52(13.070121755319988,-1.2443006940308974,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark52(13.073196533045195,-0.9223432262055202,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark52(13.08530597886353,-1.0801216744787112,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark52(13.08864978201862,-1.2258890023232283,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark52(1.310747756760433,-0.1786846153940338,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark52(13.114031698868317,-0.79176009571105,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark52(13.131688397574976,-0.5121366044865763,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark52(13.230663784836972,-0.9836159301502239,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark52(13.233451681917714,-1.1157564583166428,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark52(13.25567426765176,-1.499999999505168,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark52(13.263194898128233,-0.8105475563501652,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark52(13.273413308466402,-1.4522327594348212,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark52(13.36379850961815,-0.11577890956983627,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark52(13.37056504578291,-0.0012915450561438852,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark52(13.402283384579093,-1.4999999999630682,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark52(13.439924762544011,-1.489898116700377,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark52(13.452134503371969,-0.06336547666467432,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark52(13.499190236180054,-1.4999997164119316,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark52(13.513261197051715,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark52(-13.526185981865908,-1.4310394820188925,-1.0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark52(13.541961431277741,-1.0901718812005594,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark52(13.542215906125008,-1.1980525565428675,0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark52(13.59586894549146,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark52(13.60137897105625,-0.3384898081385046,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark52(-13.605126873396916,-1.1541120133282812,1.0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark52(13.637197347354,-0.9670629273581852,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark52(13.642610827934476,-0.5446881482399419,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark52(1.3693334804641064,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark52(13.707346548940958,-1.2886059110962123,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark52(13.749056396482942,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark52(13.801042367968591,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark52(13.808875824179665,-7.105427357601002E-15,0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark52(13.8579939997542,-0.385341386098915,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark52(13.868638876231277,-0.8560455312527382,0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark52(1.3875654935186112,-1.4024922894096759,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark52(13.879519950169623,-0.7627648705305319,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark52(13.931886562904598,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark52(13.955916841296045,-0.04806156428274733,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark52(14.047016061219933,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark52(14.050238107851726,-1.341060490783704,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark52(14.08536471771582,-1.499999999999985,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark52(14.11030889442267,-0.20624897341438775,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark52(14.113784316909545,-1.3242447551882024,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark52(1.4155148149896153,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark52(14.186234007666698,-1.03773452646924,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark52(14.206561030305998,-1.376874712052393,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark52(-142.63542932874557,-0.45420192036174,1.0000000000000004 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark52(14.268742118664818,-1.4918010789594005,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark52(14.269156599212208,-6.986865949863757E-7,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark52(14.272483807779352,-0.08803442981511189,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark52(1.4301155368637097,-0.3566469763131277,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark52(14.309948764127594,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark52(14.378154923951868,-0.6646819013295744,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark52(14.394289311936646,-1.3337129755053105,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark52(14.395847764047076,-0.8572677714938577,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark52(1.4409646365196096,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark52(14.421709341377252,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark52(-14.537659649835657,-1.7763568394002505E-15,-8.37419605317696 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark52(14.612695964603219,-0.10076141162480745,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark52(14.613100326603856,-0.6256376779079744,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark52(14.61663580621217,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark52(14.689647551650182,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark52(14.698933769843059,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark52(14.717869913819513,-0.8491011647022759,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark52(14.733288533248055,-5.298986007148356E-10,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark52(14.73376739907279,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark52(14.759444116963593,-1.4382173653207957,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark52(14.759532124620307,-0.28736913520169294,0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark52(14.769194354597325,-0.014249961223938179,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark52(14.790955269924105,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark52(1.4804855390623857,-0.43879923403369264,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark52(14.83238960644163,-0.9372034533989577,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark52(14.839530453333657,-1.48841787460324,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark52(14.877370631000232,-0.5033393322635953,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark52(14.882968451795648,-0.29495526613410883,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark52(14.890316179327371,-0.230895880599423,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark52(15.008262789567517,-0.5757823684745276,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark52(15.03353014917964,-0.18540807537335158,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark52(15.045353986769136,-1.3689384256939143,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark52(1.50664866400985,-1.3388546512271848,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark52(15.10126058935684,-0.0630129786730258,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark52(15.109522101291901,-0.5663195148486491,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark52(1.5113294762784435,-1.4999999995673896,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark52(15.131742409603149,-40.373524843384615,-65.4043139658753 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark52(15.138141476945123,-1.2492935142601604,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark52(15.17417007803962,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark52(1.517737390589886,-0.0344249648496362,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark52(1.5183864763827475,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark52(15.19025348685554,-0.6387206838700785,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark52(-15.225260229360776,-1.4999999988980086,46.42878002643647 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark52(15.255046967554463,-0.3011270052194206,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark52(15.267886365377564,-1.4522063568416428,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark52(15.281406134265175,-2.6167887034269595E-7,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark52(-15.306460256488116,-1.1029638511644908,0.07408133638875825 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark52(15.314880422771466,-0.10251911640574929,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark52(-1.5356895374291261E-238,-1.2555041502720605,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark52(15.36569634431882,-0.3101585052898801,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark52(15.378997893402556,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark52(15.393643743875444,-0.5038262787718892,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark52(15.404569184129064,-0.0379453660526918,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark52(15.453027513082347,-0.2155137650805763,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark52(15.454881548391105,-9.891368461309314E-5,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark52(15.469617221877566,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark52(1.5488944722353253,-1.0676208585579468,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark52(1.5569736253298316,-1.380943193176563,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark52(1.5570003764988734,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark52(15.605371154176908,-1.2083459372038448,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark52(15.61558963632595,-1.2934789812628793,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark52(15.651584411180977,-1.1996882665110213,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark52(-15.711454012633018,-0.4950311280037038,0.9999856860557289 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark52(-15.807937693119172,-1.4430652358528524,-1.0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark52(15.830736892176635,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark52(15.87483031193213,-0.3381573173555381,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark52(15.883761916579274,-0.7284301697593543,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark52(15.959445458474704,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark52(16.00918269325279,-1.4999999833016275,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark52(16.017214957960533,-1.372273891816718,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark52(16.01847841139798,-0.08530199382066428,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark52(16.02511283973662,-0.5704807518952855,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark52(16.029720036753908,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark52(16.051230295718568,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark52(16.06285759758812,-1.222540431763621,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark52(16.063602264996174,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark52(16.073804201755813,-0.16179379211089445,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark52(16.07945357749354,-0.2254553157818151,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark52(16.080709342456,-1.5056080540990357E-7,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark52(16.13961281938196,-7.822493083192429E-7,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark52(16.145908296383908,-0.24859883731167542,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark52(16.16208882486358,-1.4999999999065046,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark52(16.250030287106313,-1.499999999639227,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark52(16.268093175958583,-0.8603281296510659,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark52(1.633145492492691,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark52(16.36687725021565,-1.2168931948981778,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark52(1.6418147205193505E-288,-1.316863676909849,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark52(16.418918457024702,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark52(16.484937627544287,-1.4609685594117917E-7,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark52(16.490989691200358,-0.6120171891721067,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark52(1.6586596337336346,-1.2147474934008216,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark52(16.596624793471435,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark52(16.59866359433883,-1.4186319814956683,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark52(16.61663331789542,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark52(-16.70173505093142,-0.05260972556147803,-1.0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark52(16.722444190970435,-0.06452633124015827,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark52(16.73201253925302,-0.7830762768025055,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark52(16.8518737151782,-0.16870592275639051,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark52(1.700837699865211,-0.7001573187098131,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark52(17.024815466174914,-0.9529286170648561,0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark52(17.029383625654795,-0.5055117367316636,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark52(17.03288936144227,-0.7227375993075214,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark52(17.069609497205505,-1.31038926563971,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark52(17.076211452069344,-1.105017457106002,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark52(17.09942379310914,-1.2488079260082827,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark52(17.11341384034287,-0.343852789791117,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark52(17.13876484324529,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark52(17.142030061625977,-0.26233898226539054,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark52(1.7185607072764526,-0.6790825795628876,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark52(17.204017953602914,-1.0026597261409957,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark52(17.252130331148265,-0.9970006795767832,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark52(17.276518915461132,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark52(1.7328069438449134,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark52(17.33488120517947,-0.7525995867875486,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark52(17.35859209238626,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark52(17.407564632039275,-1.20858690379514,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark52(1.740761897632237,-0.9236962696473938,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark52(17.438338440082717,-1.384633146983434,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark52(17.456966847747353,-0.1297712493990073,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark52(17.492393076100825,-0.3470999837011277,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark52(17.516252812148153,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark52(17.53338470307395,-0.8991827569130706,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark52(17.588181692478216,-0.020700391512419536,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark52(17.637037112090994,-0.5845077888352552,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark52(17.69959292763525,-0.7772946887290573,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark52(17.706516095439227,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark52(1.7763568394002505E-15,-0.7803200334709472,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark52(1.7763568394002505E-15,-1.0945239305054988,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark52(17.800201151697536,-0.7938214001618374,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark52(17.816154231686298,-0.05967921538391446,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark52(17.823446016959423,-0.947406822684357,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark52(17.839728948370066,-1.3303382374017527,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark52(17.86896397825725,-3.875374122786115E-9,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark52(17.876466367877804,-0.1542988872426344,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark52(17.984748196149567,-0.20919411835602755,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark52(18.010794896857064,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark52(18.03684751122097,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark52(18.054597667923872,-0.6887618708718968,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark52(18.05946853505452,-0.750476488267242,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark52(18.064085766539023,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark52(18.09117928008211,-0.3000078162140344,0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark52(18.094967129220876,-0.9822823729062264,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark52(18.23707245960904,-0.36426720461588746,0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark52(18.237146526229964,-0.21885721702502337,0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark52(1.8335808501175728,-0.00781597921868471,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark52(18.337876872687776,-1.1519629032890688,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark52(18.35448645098782,-0.7558277718451478,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark52(18.40555734852285,-0.7563860430529721,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark52(18.415721061573606,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark52(18.41808284889437,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark52(18.47247232580061,-1.3155528524531093,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark52(18.52657470048116,-0.16868707173937109,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark52(18.52680679938468,-0.2074014650262006,0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark52(18.577347442956523,-0.8974185351856363,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark52(18.59209857297502,-0.5670580767596096,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark52(18.65856923779498,-0.6068944706623398,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark52(18.664029191148806,-0.34961246094593434,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark52(18.692261933345254,-0.5647021192445498,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark52(18.7159235034254,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark52(18.754160882347847,-0.7933730327645412,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark52(18.78861207826895,-0.28538054113643696,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark52(18.804143637853883,-0.3983338674634812,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark52(-1.8807695124032402,-1.2635671600221603,-1.0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark52(18.811605552448142,-0.7070495984450957,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark52(18.845100773519547,-0.620003440125156,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark52(18.850191389743202,-0.6213874447522694,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark52(18.886392864954587,-6.10471418715154E-7,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark52(18.92444153886619,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark52(1.8954452527697345,-1.2126581327775756,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark52(18.976718112583768,-0.9691651011078832,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark52(18.995546421264635,-0.784750679855577,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark52(19.06037445456552,-0.6289401410234348,0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark52(19.098815889699154,-1.0675997240342951,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark52(19.109906964248708,-0.05581039282201017,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark52(19.15163736611676,-1.0744818075577838,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark52(19.172564613853325,-1.3120782136861138,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark52(19.185412419438563,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark52(1.9191601882464226,-0.34511032377710515,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark52(19.226180320579104,-1.3964478933031046,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark52(19.246242473855915,-0.3689806100335731,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark52(19.297339612615644,-1.4999999999999858,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark52(19.316134961713473,-1.7350948564007096E-7,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark52(19.374075398984196,-3.143259349884871E-7,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark52(19.421554500975574,-9.03683192907857E-8,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark52(19.429363885247433,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark52(19.461055834320035,-0.1562050255834606,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark52(19.478995787551284,-1.4883150377692598,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark52(19.557249013396245,-0.7422710949905849,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark52(19.568383889301916,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark52(19.58810224322945,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark52(19.605865750628595,-0.4785750559867212,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark52(19.614459970347973,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark52(19.68138645404639,-0.007562173778837557,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark52(19.689002325969255,-1.3748887029371168,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark52(19.698684760702868,-1.4050752279523264,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark52(19.707769197965533,-0.2318726969539,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark52(19.83397060535009,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark52(19.863570292843107,-0.11182282087114004,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark52(1.9885943962931094,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark52(19.93488415825804,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark52(-19.964745362137663,-1.1670912253932926,6.766051035332694 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark52(1.9978056795420827,-0.6345683962873867,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark52(19.98737057025393,-0.8788622049358707,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark52(19.988904141587646,-8.608044380722181E-7,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark52(20.061118946276224,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark52(20.177140947271287,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark52(20.21564094005359,-0.2516174792031096,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark52(20.218117530411867,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark52(20.233732231506217,-0.23534400849346182,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark52(-20.250253305772578,-0.6653589879414761,-33.39851284936677 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark52(20.26306364173449,-0.9796994735202662,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark52(20.312130544237107,-1.3755495291178672,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark52(20.335136413291035,-5.522515277099052E-6,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark52(2.0392641497057156,-0.9963734923907835,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark52(20.444036876112243,-0.7344159780452166,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark52(20.47390592070262,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark52(20.49451510399601,-1.4841756592767363,0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark52(20.50972503730013,-0.8908825740804502,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark52(20.527647385609882,-0.17582136939138104,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark52(20.531831190760315,-0.37093026303306686,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark52(20.53431661829677,-0.5827583273692356,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark52(20.54723662273956,-0.8387660531141634,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark52(20.660080766775366,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark52(20.68488169317881,-0.7491546423953963,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark52(20.696273768435475,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark52(20.706547458980168,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark52(2.074696046004938,-7.599031642844846E-10,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark52(20.753867209490842,-0.6570303831657922,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark52(20.760180543104596,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark52(20.76976341072937,-0.0011525579604280563,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark52(20.774266504684036,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark52(20.885399153659435,-0.1090070445258462,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark52(2.092204426858757,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark52(21.024996036671396,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark52(21.050376515088814,-0.016832747971553985,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark52(21.054146479875953,-1.4999999279149652,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark52(21.18218657952509,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark52(21.205885138540392,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark52(21.272872092253436,-0.5889866957120917,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark52(-21.28031149501644,-0.34088685563076915,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark52(21.447520982056904,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark52(21.457823278029167,-1.1898103615952622,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark52(21.496121726822054,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark52(21.586177016111876,-0.7092362764127955,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark52(21.58749367609857,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark52(21.59745103989843,-0.06126731594460466,0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark52(21.6113467646597,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark52(2.1645197373831593,-0.22207462515941856,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark52(21.675377930156635,-0.5666472072316094,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark52(2.1694094766291983,-0.5755478386327244,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark52(21.70996663359569,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark52(21.712285024392365,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark52(2.1785996297999617,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark52(21.84728996884806,-0.18454779298413315,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark52(21.853315645680524,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark52(-21.88685432919705,-6.197394342428945E-16,70.72625959367602 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark52(2.1921934944033126,-0.3017736600155132,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark52(21.961258202698573,-0.4122334849197365,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark52(21.970747254315512,-1.4594307123282846,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark52(-21.972330968351677,-0.5630591694016804,0.5710396901196817 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark52(21.991934434232846,-1.2944909366986268,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark52(22.0190995179357,-1.2300551538093485,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark52(22.050942198108842,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark52(22.055208224739616,-0.8158669759744699,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark52(22.059962197435883,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark52(22.081978090468922,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark52(22.08892566035101,-1.3598118360163571,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark52(2.2096499918511695E-10,-0.8317959669033466,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark52(22.11971793478304,-1.2713540886333448,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark52(22.12188446528028,-0.1306879555611661,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark52(22.13612320312454,-1.4987925572664214,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark52(22.140416289000257,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark52(22.14506333196637,-1.4999999999999343,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark52(22.169252538962354,-0.9209626988641155,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark52(22.182218314447926,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark52(22.193947020605663,-1.0176905002669598,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark52(-22.21721931004441,-1.3561138561016208,-1.0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark52(22.231553556397834,-1.48469312348467,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark52(22.234750594623122,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark52(22.25229046530734,-1.106531471315762,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark52(22.29709252120699,-0.5086124526108478,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark52(22.373153503296493,-0.6964678068711359,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark52(2.2405187001873488,-0.8054812194335796,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark52(22.405443021666144,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark52(22.448362039154905,-0.14121556174451078,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark52(2.247836184392881,-0.8330003912186881,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark52(22.484158575324006,-0.9614060409897516,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark52(22.486175379952428,-1.1764778756757654,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark52(22.503654640251725,-0.7940543882932332,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark52(22.51821998221044,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark52(-22.523952867163526,-0.08331680195016934,0.051232066175514485 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark52(-2.2527622052743395,-0.10154582883205832,-0.9999999999999996 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark52(22.53152298440233,-1.0850186991774784,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark52(22.54003665330508,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark52(22.551048806551947,-1.2664866639207646,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark52(22.60392878891028,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark52(22.61221037789977,-1.3604158138243507,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark52(-22.61875455026536,-0.26396313546373396,0.003929191148632105 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark52(22.64595887424668,-1.4628939281464487E-4,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark52(22.646618913431467,-0.16683330257189333,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark52(-22.836147372813613,-0.9421003846630579,1.0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark52(22.879788845943395,-0.5375586911695918,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark52(22.887911015893664,-0.905892442036318,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark52(22.924307152216752,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark52(23.017837375791018,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark52(23.062771595409767,-0.897167149786684,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark52(23.062985047845206,-0.2594600649339923,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark52(23.088096991016457,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark52(23.11845700271347,-1.4194255500907256,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark52(-23.121268043590895,-1.4999999999999982,-0.8423403905532514 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark52(23.228322434592457,-0.835864210945239,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark52(2.3277798671672087,-1.428403626904597,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark52(23.288882449685815,-1.011553046819032,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark52(23.315076547404345,-0.16999338869608405,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark52(23.36130871041148,-0.46744802470793445,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark52(23.457195447951918,-0.21937002941654216,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark52(23.45769642380433,-2.2703888009242258E-8,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark52(23.46293713865798,-9.548168446883351E-9,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark52(23.46945484357545,-0.7312492292101851,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark52(23.627029661386942,-0.06320624222313143,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark52(23.663904790896083,-0.7186302270337195,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark52(23.70567518051618,-7.105427357601002E-15,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark52(23.721950840564347,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark52(2.3722059034845984,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark52(23.73504605076945,-0.19321792831672546,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark52(23.871172974058968,-1.4999999998898605,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark52(23.923707265340965,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark52(23.927953506770066,-1.1428984049203192,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark52(23.98618017861631,-1.309024853900878,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark52(24.011770976086936,-1.2197062823254512E-8,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark52(-24.058955506691007,-8.360940484491469E-10,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark52(24.064854351825332,-1.226068488914438,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark52(24.13861579205623,-0.02107974707155144,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark52(24.16469486453738,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark52(24.167869517992553,-4.6753324156623486E-7,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark52(-24.176247559035048,-1.3552266123029795,-1.0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark52(24.211538103350005,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark52(24.228664676394544,-0.4144028199688563,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark52(24.247624949260768,-0.09168857502301922,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark52(24.251951208650496,-0.9642710717304315,0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark52(24.276838181949103,-0.28203679054446384,0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark52(24.322089071473414,-0.19114682797610794,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark52(24.336504755453305,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark52(24.355068000315224,-0.9094908036385805,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark52(24.357192552848076,-0.2798025005392901,0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark52(24.360110936574415,-0.3768412069649958,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark52(24.38869273391417,-0.17210701284086838,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark52(24.390820567530994,-1.3640605256272318,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark52(2.448791848813414,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark52(24.523991472424285,-0.7347756332503224,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark52(24.585652479157464,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark52(24.64477521374453,-0.05471076776680611,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark52(24.67653662717275,-1.2898715735067725,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark52(24.680280941205645,-2.4798325856444477E-16,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark52(24.70603340870892,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark52(24.781505637999345,-0.9888378711548267,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark52(24.794822328331122,-1.4525877713648265,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark52(24.799390285208972,-0.1129821894599301,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark52(24.807166231276646,-0.6558748715683174,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark52(24.84315789781519,-1.1307644550615947,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark52(24.899013608975082,-0.06770747332169991,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark52(24.96542092708613,-0.768293868827632,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark52(24.984543704933323,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark52(24.99252522640541,-0.4631218853409762,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark52(25.02187323437724,-1.0960189295584115,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark52(25.035203489878484,-0.3688915453380366,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark52(25.057824232652624,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark52(-25.081570853111046,-0.5967756358448474,-0.12205625317958968 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark52(25.08240765180479,-0.24959385345753426,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark52(25.134677895464307,-0.0033654360119254162,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark52(25.14811183603249,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark52(25.152119574502805,-1.2806476492378747,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark52(25.192821259812433,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark52(25.21812288723503,-1.44744994639347,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark52(25.22063660974308,-1.4999999999999147,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark52(2.5221684226568613,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark52(2.5229869262214586,-2.2695973974411657E-6,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark52(25.263297907764183,-0.2710687900100748,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark52(25.297782055192513,-0.8122355680442581,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark52(25.314376536431627,-0.791013499999951,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark52(2.53472471735169,-0.96951943302259,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark52(-25.349555806760108,-0.77736900495321,-1.0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark52(-25.37495615212069,-0.9835882361167917,-61.649080627943874 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark52(25.396391715523823,-0.140284289749941,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark52(25.42752249667734,-0.3273095744092984,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark52(25.471283742395514,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark52(-25.529058054641144,-1.4602859694488592,1.0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark52(25.56582160779304,-0.7758897982263742,0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark52(25.609108338377325,-1.3727481265205417,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark52(2.561720400041518,-1.574034588010266E-6,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark52(25.631270190634027,-0.3086743139598753,0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark52(2.565978858579143E-16,-9.60832242664527E-9,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark52(25.72171155280472,-0.4974243897844417,0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark52(25.744499723576137,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark52(25.79880781315212,-1.4999999963075445,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark52(25.803507734444025,-0.9317819257705651,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark52(25.821003336260684,-3.706508841411848E-9,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark52(25.82782046969217,-1.499999999999993,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark52(25.869325104541883,-1.0309987883209288,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark52(25.912149179033534,-0.3640226181464534,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark52(25.918738393596215,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark52(25.998967801721577,-1.4413045566563212,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark52(2.605009906872672,-0.001953949864248009,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark52(26.054313222419864,-0.9665932832718722,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark52(-26.095642824160837,-1.4999666143330077,-0.9999999999999998 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark52(2.6124191296878205,-0.14684384603692013,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark52(26.197175323851646,-0.20006533127834514,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark52(26.237788344802865,-0.3016485926014383,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark52(2.626259511268671,-0.38050637417678956,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark52(26.26685631321064,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark52(-2.6275264668884404,-0.6888810593039612,1.0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark52(26.289094280195613,-1.1956342775208526,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark52(26.294784711980498,-0.040935356894656806,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark52(26.33599197941904,-1.054023247518778,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark52(2.635816826535311,-5.8381988762089766E-8,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark52(26.37283650840439,-0.02445843369596723,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark52(26.397849813650204,-0.024560919558840336,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark52(26.43751115299266,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark52(26.530029283966968,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark52(26.552508918701733,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark52(26.592076250459115,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark52(26.59638938564268,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark52(26.597849207228947,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark52(26.635851625346703,-1.324908849273136,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark52(26.722975572154752,-0.47270265738047423,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark52(26.739383686131525,-1.3258806632430118,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark52(-26.753834473136692,-1.4017454163585783,0.7060821416103431 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark52(26.761971386264307,-0.9739392626679999,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark52(26.762008684031045,-0.19896286087726356,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark52(26.79825796118223,-8.868674389040003E-10,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark52(26.86663074932522,-1.1743832311872282,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark52(26.9279411746501,-0.01787374503216431,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark52(26.95015912153093,-0.5072103457949597,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark52(26.95206570099567,-1.1394673842322904,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark52(26.977301196576107,-9.52006820024442E-9,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark52(26.98928089198354,-1.391145161427204,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark52(26.993783521188618,-0.09856444267792597,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark52(27.000703030629964,-0.2933654708654627,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark52(27.04604102175989,-2.892971410186658E-8,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark52(27.061334991474713,-5.402081139382077E-8,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark52(27.116355129757938,-0.11062821416296975,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark52(27.15931511795528,-1.3426459153322526E-9,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark52(27.16148118475643,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark52(27.16913894779853,-1.0450126145765943,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark52(27.194053404414667,-8.919681152815478E-10,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark52(2.7350961715732476,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark52(27.35211322074042,-0.3345152212528567,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark52(27.361420479259465,-0.07036482955775625,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark52(27.377188040352166,-0.6335216629016172,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark52(27.402034524966858,-0.8141978582263221,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark52(2.741733140767934,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark52(27.4756857220885,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark52(27.479148492725386,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark52(27.51277527387333,-1.136349951608537,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark52(27.522386456274752,-1.0826235512826985,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark52(27.52352073673667,-0.6745110007693,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark52(-27.532156973115647,-0.10315385093930965,1.0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark52(2.759940172551879,-0.09035979726322729,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark52(27.60674250944119,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark52(27.61831988422702,-0.6720682203865405,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark52(27.622905540014855,-0.640738372191238,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark52(27.645667661848577,-1.1094018185667096,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark52(27.653938203671117,-1.0438938434776883,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark52(27.671596243444284,-0.19672014269034782,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark52(27.683844072925652,-0.5870908681332553,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark52(27.68567291351394,-0.39620398076913765,0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark52(27.724192202219015,-0.671104016171149,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark52(27.745711594773205,-0.25209601582792485,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark52(2.7755575615628914E-17,-1.2046196066208943,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark52(27.77438264712677,-1.4255076497429222,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark52(27.8239642043352,-0.6623588463820091,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark52(27.884116226173134,-0.3321767573290799,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark52(27.903719977256834,-0.20832217170380574,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark52(27.9241905693751,-0.9599456124627403,0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark52(27.967363835709836,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark52(-27.97376084345122,-1.1102230246251565E-16,1.000000000112869 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark52(-2.8107191577917376,-0.4509061422929932,-34.871687749942026 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark52(28.155349410082803,-1.499999995839579,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark52(28.19499071876497,-0.5281109198175841,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark52(28.242268849190424,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark52(28.265625073370302,-0.757721767367503,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark52(28.27033098532675,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark52(28.27801413782105,-0.019803180393318277,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark52(28.292183120516256,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark52(28.297377191284966,-1.328880313087573,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark52(2.833043517869504,-8.621327860843293E-10,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark52(-28.369171770270302,-0.160775138846998,20.882605929994654 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark52(28.388611094602396,-0.9940867062773577,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark52(2.8408987511746155,-0.3437974445980636,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark52(28.426355280343362,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark52(28.453035808898278,-0.09229780975071833,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark52(28.45521626704894,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark52(-28.466790626106842,-0.9533828444893118,-0.5589750671679745 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark52(2.8475626221107433,-0.34345454442768997,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark52(28.51591960497936,-1.4760251668444646,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark52(28.518014633114632,-0.20138849667737113,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark52(28.537994369044526,-0.3450970855338191,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark52(28.558585854958466,-0.3058692625869526,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark52(28.563125505269028,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark52(28.63583927190146,-1.3695287014042492,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark52(28.63758748128535,-1.1660978753658764,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark52(28.642745931031868,-0.20682544347350706,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark52(28.65184208081453,-0.5253118355180995,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark52(28.71179564655887,-0.03599040528347189,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark52(2.8729458526934524,-1.3127686297026913,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark52(28.773976306464675,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark52(28.776777014110372,-1.4999999997029343,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark52(2.878426520051505,-0.14128041974547578,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark52(28.78803056601535,-0.8250235278402407,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark52(28.8412652475412,-0.39675699462260616,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark52(28.873371983376728,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark52(28.93178656955545,-0.18995583201048016,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark52(28.9394474400384,-0.8967929388469286,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark52(28.954905114583596,-0.39728105615754394,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark52(28.969701278326596,-0.23075051313493056,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark52(29.011795113292013,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark52(29.048760366161872,-0.36463873734589036,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark52(29.0594183325868,-1.4466712239619703,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark52(29.065288222395083,-1.2040446994498437,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark52(29.13591414152332,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark52(29.150714724066713,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark52(29.161300225794832,-1.1959298090225872,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark52(29.1780027752759,-0.314016185711103,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark52(29.17906966145344,-0.8552271996042435,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark52(29.191486121406456,-1.2915308191787434,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark52(29.22755494200527,-1.0148579912403168,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark52(29.230426102546446,-1.4174175543527312,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark52(29.252981531211137,-0.9880268391937834,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark52(29.25308010125267,-6.556593292441735E-10,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark52(29.285231257970736,-1.3560497037479142,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark52(29.425591177501786,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark52(29.43184528281171,-0.8576947851843344,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark52(29.432987912076214,-0.41181574436076973,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark52(29.536078304364136,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark52(29.538961124204157,-0.11199744208129125,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark52(29.54570411534462,-1.4058224140518383,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark52(29.675298787974185,-0.22531399547648567,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark52(29.692796643234004,-1.214303531867553,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark52(29.726211708530116,-1.2668140673935788,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark52(29.799127153067154,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark52(29.819281572809047,-0.6390228175185309,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark52(29.854719949242423,-1.4999999999999716,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark52(-29.856290826092792,-0.3168665375674351,-51.336237667926575 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark52(29.878431474490412,-0.7116315483368982,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark52(29.895936710802967,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark52(29.98662467073757,-1.4171401539454875,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark52(-29.998450853070636,-1.2905554232963319,0.910574861930031 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark52(-30.019765824245084,-0.3149981064064653,-98.33570124275725 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark52(3.00328984960265,-1.4999999885282143,0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark52(30.094245981424848,-0.7669242717627096,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark52(30.136595432309605,-0.13539348157328446,0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark52(30.158307124850612,-1.0872266503720738E-8,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark52(30.173996346886774,-5.3900958385916907E-8,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark52(30.17683430709127,-0.5063190068032215,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark52(30.21280501738761,-1.8303034061859782E-9,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark52(30.285878008841294,-1.4921981039604164,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark52(30.292780451654885,-1.2082466614855154,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark52(30.30924521145336,-0.6229603966292719,0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark52(30.312892773957525,-1.4762611940659163,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark52(3.032276279023918,-0.0013820401056394704,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark52(30.33709394608229,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark52(30.37245657724901,-0.30007039974537975,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark52(30.382325647437426,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark52(30.39461896821422,-0.04633312610727758,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark52(30.406918129462866,-0.3721892196509202,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark52(30.415228607817397,-1.499999999999997,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark52(30.421932492064656,-0.9671127866518714,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark52(30.43843980380693,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark52(30.56042962224271,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark52(30.562680875430004,-1.0564164325932666,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark52(30.581195922491343,-3.76308768377583E-6,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark52(30.613973994095005,-0.14476628049260754,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark52(30.62048058507733,-4.5534827404332995E-10,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark52(30.624673868920752,-0.06220283439078463,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark52(3.0711240004985996,-64.01932651479777,-33.091967902203294 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark52(30.763564821873956,-0.8926288469689156,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark52(30.816488931553693,-0.2601157010150217,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark52(30.825510404690988,-1.184169407639244,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark52(30.832687544650142,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark52(30.930102064356248,-0.5238985923297399,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark52(-30.94961200991766,-0.016802399432450803,1.0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark52(30.953614970751488,-0.5194929499443379,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark52(30.968700083476563,-0.5362650666969104,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark52(3.1049404899137825,-1.4999999913196411,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark52(31.054960898197493,-0.8452941168485495,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark52(31.063767550456504,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark52(31.08355463808114,-1.3050100653443256E-5,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark52(3.1105049732380428,-1.1376445715694108,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark52(31.163407006036152,-1.1271723472133723,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark52(31.167771497902194,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark52(31.182546323868223,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark52(31.211481035533183,-1.305229551297459,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark52(31.26582542827029,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark52(31.27119055776486,-0.1198753289085801,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark52(31.405106342276383,-1.4493685867704533,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark52(-31.42664276568745,-0.8043021318037561,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark52(31.510641992239123,-1.4999999990618396,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark52(31.527161356725628,-1.234251805103395,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark52(31.53866866466717,-0.15806928682715782,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark52(31.56058677801255,-0.7705032336774016,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark52(31.57223039226764,-1.3583076841568753,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark52(31.57431686906026,-0.0329261033766134,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark52(31.585274963471687,-3.259364136395843E-9,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark52(31.62004022547876,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark52(31.630645622763552,-1.3550061577460704,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark52(-31.64589995764834,-0.765739301956625,-8.720059256063024 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark52(31.66976152397288,-1.0046461635887747,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark52(31.69528974944069,-0.03651899597217323,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark52(31.696446651422338,-3.9790728853855186E-7,0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark52(31.71895267961044,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark52(31.796812981909596,-0.30501657749888533,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark52(31.817492361356983,-1.2960192993774047,0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark52(31.901547961817098,-2.4865429391581086E-9,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark52(31.937093736021403,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark52(31.972213290007403,-0.32744442206005947,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark52(31.979723082895816,-1.3755750338000965,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark52(32.0083455931248,-1.2475863759531052,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark52(3.208251939937207,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark52(32.10573199768824,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark52(32.11631941364254,-0.21076790800497047,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark52(32.150469395052085,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark52(32.192822595773805,-0.027902298049610863,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark52(32.2209303566746,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark52(32.226853363983054,-1.2950515056015348,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark52(32.241935722361404,-0.6081427190291748,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark52(32.273590887431794,-0.18813621477261977,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark52(3.240420451709904E-95,-0.3113021143435582,-7.24454326306137E-71 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark52(32.41481625981882,-0.15706268100367135,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark52(3.2445655405006946,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark52(32.45086117008532,-0.31453822878098636,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark52(32.47534669649982,-1.243461768359996,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark52(32.55520070869818,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark52(-32.59119337947223,-0.5832568302952978,2375.263118030076 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark52(32.61406511643146,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark52(32.62217690971125,-2.1178093746132556E-4,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark52(32.626980136424635,-0.8969666535765572,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark52(32.650265224444155,-1.1511295411171147,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark52(32.68540729497343,-0.4137004132306905,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark52(32.7326559547939,-0.5129241879014799,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark52(32.740673806904844,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark52(3.2807089313462825,-0.5055683356937757,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark52(32.82748038507145,-0.4588709456897373,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark52(32.86402120788706,-0.029661859706610727,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark52(32.90974327152942,-0.4051436325166775,0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark52(-32.94135936816279,-0.8078194151455542,0.9999999999999964 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark52(3.2978773162169763,-0.252242812546339,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark52(32.994359887948406,-1.2455772646260215,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark52(33.11027003000493,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark52(33.1486102904897,-1.499999999999984,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark52(33.14931427634386,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark52(-33.1742677226271,-1.4999999998993927,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark52(3.318490330752425,-0.7401247972229186,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark52(33.25064332079279,-0.015998651691276677,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark52(-33.310602174116326,-1.4999999999999996,28.538702220588334 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark52(33.34639606264846,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark52(33.3515128563406,-0.6223047695238133,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark52(33.36472414440186,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark52(33.410095730522045,-1.3954234738146614,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark52(3.3436672318027263,-0.7752101678165948,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark52(33.441524642789204,-0.3628529608087945,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark52(33.48839802303468,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark52(-3.3492223247480126,-0.2189918118781531,-6.849703957961452 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark52(33.50549643668333,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark52(33.51420136609333,-1.4999999999421623,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark52(33.52772025104713,-0.3904549535323172,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark52(33.53475614972015,-1.440622099426355,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark52(33.556772920436174,-0.6292595796874663,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark52(3.35751925609749E-10,-0.3823402602204038,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark52(3.358061017012659,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark52(-33.583098722755665,-0.9008273255991099,1.0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark52(33.60699313147069,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark52(33.65061572204749,-0.5544367062642834,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark52(33.68313657763312,-0.06787737781862457,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark52(33.696664989052096,-0.6456720893056414,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark52(33.702873432253426,-1.274484934922423,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark52(33.73929901529934,-0.5382997809265646,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark52(33.7609414228161,-0.37999957420776553,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark52(33.775494651539674,-0.15548507805206135,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark52(33.77644724850123,-1.0958064416772886,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark52(33.778270958334645,-0.5703845039972464,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark52(33.86420190191333,-0.696879508787597,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark52(33.88232392541289,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark52(33.92466155066797,-0.4471614421265493,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark52(-33.94126481626103,-1.1734145013767823,0.5887137836353649 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark52(33.95550572021088,-1.1434965847473677,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark52(-34.005905442648555,-0.28544350860511036,1.0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark52(34.018189588549916,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark52(34.115364455184476,-1.4999999999999432,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark52(34.164160410347385,-1.4983413485470432,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark52(34.18786034448527,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark52(34.23263011700647,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark52(34.25830018450235,-3.4281488973741464E-8,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark52(3.4261762858494507,-0.3791025713827878,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark52(34.286463663407005,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark52(34.36663202681575,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark52(34.37136474048194,-1.056888315038007,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark52(34.40094775014052,-1.4075268557594338,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark52(3.4473122073213323,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark52(3.4484101182451212,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark52(34.58303507634809,-1.2951653275758273,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark52(3.470393686776842,-0.0759153171026632,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark52(34.72418673724624,-0.360778285564213,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark52(34.726775451715966,-1.3786043315576135,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark52(34.73387421193593,-0.46840751735584263,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark52(34.74437196189523,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark52(3.476021110710267,-0.17073726776691883,0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark52(34.76360037111169,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark52(34.815602723210155,-0.19309383508336753,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark52(34.818604510284814,-1.0074515654670506,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark52(34.888320400386355,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark52(34.91375367740471,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark52(34.930743114035835,-1.0508396843664252,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark52(34.93390298248411,-0.5344179764749888,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark52(34.98042175381937,-1.0817980196429886,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark52(34.98338499964672,-62.38444633404254,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark52(34.99129642739632,-0.7585682295384797,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark52(34.992498744734235,-0.29055341590438966,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark52(35.03245929000548,-0.32902140978399075,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark52(35.09545919953953,-1.2268051408598608,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark52(35.14875930456795,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark52(3.5173787057541928,-1.4999999994537663,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark52(35.185570103419685,-0.8471025206982203,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark52(35.221836814756784,-0.7997356927392669,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark52(35.22589607553218,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark52(35.263534645169514,-3.237457797522115E-9,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark52(35.38395141246406,-0.29279399505284687,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark52(35.43982747538783,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark52(35.44619764484942,-1.4522273624089763,0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark52(35.45449914875954,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark52(35.52403508451252,-0.6511951449263762,0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark52(3.552713678800501E-15,-0.16199743698882907,-0.5654541630837598 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark52(3.552713678800501E-15,-0.16327116836264377,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark52(3.552713678800501E-15,-0.45505734742237713,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark52(3.552713678800501E-15,-0.5319489934138959,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark52(35.53326216263247,-1.3712951842339294,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark52(35.54340235811162,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark52(35.59977306370781,-1.4999999861366793,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark52(35.61722066100111,-1.4999999999997264,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark52(35.62191953761035,-0.41984785808897307,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark52(35.63878601135481,-1.2070007731157508,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark52(35.65643281411219,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark52(3.567199727988137,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark52(35.698353986869506,-0.10676041697507799,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark52(35.70149563463889,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark52(35.728375942705675,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark52(35.76510354976773,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark52(35.78857459159431,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark52(35.832707594034375,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark52(3.58427448089995,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark52(3.584999406786533,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark52(35.85045727161929,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark52(3.58947488664166,-0.06239779639175247,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark52(3.5897078465896044,-1.0863678239331362,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark52(35.904033860848415,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark52(3.590710738881441,-0.6859488343338995,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark52(35.94108484315345,-0.4583319469069398,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark52(3.598040519971164,-0.5943817557150908,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark52(3.5992361914833833,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark52(36.00766055378835,-0.5001027951639343,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark52(36.009751041843984,-1.038512461300141,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark52(36.04511588595226,-2.8088088745093396E-9,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark52(36.06224378125468,-0.4171129947958998,0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark52(36.07410864377039,-1.3538681109040267,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark52(36.108739682340484,-1.340863096633238,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark52(36.11821824093252,-0.4782401659832445,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark52(36.14345266902882,-0.1605697157543542,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark52(36.1487176952117,-1.051849151590073,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark52(36.188370495674036,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark52(36.22719577332047,-2.5069668739407583E-9,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark52(36.22865515070254,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark52(3.6245244714921228,-23.909334594806523,-92.47427910009014 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark52(-3.6265799878836313,-0.4658004416900514,-0.9999999999999147 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark52(36.28788128744878,-1.0149412244452352,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark52(36.29452604498107,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark52(36.31078599689522,-0.8281461999774733,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark52(36.373864883082405,-0.31433242689555563,0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark52(36.40033449066368,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark52(36.40600484003272,-0.5580279832249145,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark52(-36.48810029921763,45.74435302280068,93.70884253929987 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark52(36.504794331472965,-0.4187980073033932,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark52(3.656966464645876,-0.7171282594908897,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark52(36.57556004461934,-4.506686336425687E-9,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark52(36.577412329221886,-0.2692252109999971,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark52(36.61728500288831,-1.3269405263232847,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark52(36.68965885985267,-0.18544589572325476,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark52(36.72182485555397,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark52(36.74534735660717,-0.10730947138373947,0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark52(36.7681603897178,-0.33281674583624765,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark52(3.679250676746477,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark52(36.807966514325244,-0.20629589070497703,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark52(36.82964533542054,-0.21397970047397052,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark52(36.83047183349791,-0.5766670165743086,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark52(36.865428872073295,-0.024187425430955756,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark52(36.87228578624752,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark52(36.87438492507955,-1.4258660408691137,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark52(36.900955036365474,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark52(36.91380756468618,-0.3382738805462395,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark52(37.014745555591986,-1.4713607737469783,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark52(37.037020544615075,-0.6817138416028907,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark52(3.704988613989613,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark52(37.08064301536788,-0.7382676336761551,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark52(37.19681386297282,-0.2126624127104001,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark52(37.205423025089004,-1.4056527620367458,0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark52(37.27478012793001,-1.0941876875353267,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark52(37.29713640626129,-0.0956827022434874,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark52(37.31670612824565,-0.6584961338089528,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark52(37.31909894335913,-1.1495142061515864,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark52(37.32371259869262,-1.0430222870390136,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark52(37.39665978310412,-1.4999999976773621,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark52(37.44196590976756,-0.5345505718578067,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark52(37.50548893172734,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark52(-3.7547149567424234,-0.016633774292181047,1.0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark52(37.56998666643477,-0.33579066596910834,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark52(37.58240874272957,-1.1063111066816822,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark52(37.600954981783445,-0.7505336232931548,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark52(37.64960864837178,-0.915328140864375,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark52(37.68293724451304,-0.5295366788155569,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark52(37.71673482944752,-0.7846104631857713,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark52(37.73574538956026,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark52(-37.74239087701574,-0.06624692678620056,0.0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark52(3.774992412581649,-9.459123006949864E-9,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark52(37.80203745499523,-1.3998321111791716,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark52(37.9005655672058,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark52(3.7950652169393777,-0.7105169699890616,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark52(3.7956117626925447,-0.9637267331964083,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark52(37.99350958485622,-0.5428538706985222,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark52(3.8011790990924936,-0.8746471719096718,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark52(38.05758494690857,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark52(3.8067493083259762,-0.9774987617650339,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark52(3.8224634570834635,-0.08887783792167318,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark52(-38.242593731178,77.87828714033117,-25.26476697031235 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark52(38.253802906070405,-0.6885844762854574,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark52(38.265470523325604,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark52(38.27520827567964,-0.3351392569248153,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark52(38.27643931377435,-1.4999999999999698,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark52(38.292315184015195,-1.119817580713594,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark52(38.29258819687132,-1.3686437647523877,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark52(38.30744730235076,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark52(38.33430312738477,-0.5909924514297273,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark52(38.36384467044596,-1.1788152112984505,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark52(38.370817307452505,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark52(38.37359227289605,-0.3655811336681549,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark52(38.39281567620776,-1.0331373342421912,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark52(38.42297906316679,66.64186486907548,19.28056323749705 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark52(-38.450449438031775,-0.011217038295697535,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark52(38.45822100565749,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark52(38.46763753738171,-1.2597725963119166,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark52(-38.48472949116473,-0.16770640857319563,36.39413541778396 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark52(38.519291388650885,-1.0019672594741376,0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark52(38.564641084597326,-0.7148001610762407,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark52(38.59568019345758,-0.7472445313191542,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark52(3.860026953255714,-1.499384856876231,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark52(38.63502801900546,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark52(38.63920388596067,-0.3966503350305367,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark52(38.670078021496344,-1.4999984107195414,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark52(38.685437285605246,-0.08831510589623942,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark52(38.69664209104551,-5.8804053346985E-10,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark52(38.70360981278425,-0.7277825897802598,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark52(3.8792968574669118,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark52(38.81438969491029,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark52(38.82542795611593,-1.1694989586568774,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark52(38.84248560098561,-0.4489698354013285,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark52(38.891985671285454,-2.221764368924021E-9,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark52(3.8913028551777415,-1.172245949814863,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark52(38.913295182667454,-0.9514367166194901,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark52(38.94502304231218,-6.446618796255958E-8,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark52(38.982638240317186,-0.2639275156534113,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark52(38.9896900225331,-1.1661244611968442,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark52(39.069127645298295,-0.09063818692488534,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark52(39.15364541358909,-0.13168229277811183,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark52(39.215268436567584,-0.2824452198655045,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark52(39.2786064823504,-0.46972905008936516,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark52(39.299418764994385,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark52(39.3227592720271,-0.22347172024682527,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark52(39.329718599482426,-1.2245780043536345,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark52(39.33679534869589,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark52(3.94430452610506E-31,-0.9520644675423543,-3.944304526105059E-31 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark52(39.4585555101249,-0.05547349044322657,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark52(39.53109846177267,-1.3739036537842866,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark52(39.5685775092871,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark52(39.606526927229055,-0.5118907281860565,0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark52(39.63503912073855,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark52(39.642106926325425,-1.3567529920111667,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark52(39.64279169797484,-1.0123962313198547,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark52(39.65810992016793,-0.19441582992890005,0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark52(39.66982559834489,-0.855585235376769,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark52(39.66997266795501,-1.497529852157458,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark52(39.68610482219148,-1.0911685649100722,0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark52(39.73447296751015,-0.9185403339307174,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark52(39.75957181802923,-1.405209468560336,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark52(39.76539066352448,-0.1322601571701334,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark52(39.77559295190804,-0.8374586011190104,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark52(39.782088529894736,-1.0809375325074317,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark52(39.83408656939838,-1.2902837028198872,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark52(39.875928237481276,-1.4999999999999751,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark52(39.908379090374545,-0.9951667256864526,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark52(39.911843453200476,-1.2104830576067478,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark52(39.9184528835838,-1.1466557417222358,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark52(39.93877747358661,-1.2813519933042103,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark52(3.9941645132450816,-1.0622994546064675,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark52(39.98503187017826,-0.06870750547998838,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark52(40.01403719564607,-0.919270172063209,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark52(40.03120741090831,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark52(40.046812173629405,-0.8816087691042327,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark52(40.08220194559817,-1.2610563142134268,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark52(40.09958525295403,-0.5021861152761466,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark52(4.013157975255367,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark52(40.17695277295111,-1.0208608883086931,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark52(40.19054350898193,-0.0070715755114916234,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark52(40.22703252765262,-0.3408740614070893,0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark52(40.25439248312218,-6.458670407959875E-10,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark52(40.27629221850074,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark52(40.28000365618314,-0.5104932435345855,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark52(4.031156551568827,-0.0923745153724555,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark52(40.33816822627759,-1.4705354818943892,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark52(40.41224841440737,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark52(40.4441048939757,-1.4999998818468265,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark52(40.44714554538825,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark52(40.46415143959798,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark52(40.465080811725215,-0.4961741004072593,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark52(40.4797475819157,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark52(40.5090294870505,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark52(40.604097141342706,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark52(40.619178555390135,-0.775122114475991,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark52(40.663786911331755,-0.3457492643629525,0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark52(40.693434681964845,-0.7666072271817846,0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark52(40.70987018837974,-0.25007115122317014,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark52(40.78594687210392,-0.11228846780917578,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark52(40.81697375419383,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark52(40.82047547592478,-0.38584978494840527,0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark52(40.83955171070616,-0.17849257273321584,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark52(40.8585882189532,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark52(40.89427116272418,-1.4635941569025945,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark52(40.895623761915175,-1.3418273456060348,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark52(40.904727413500495,-0.0021175091618008458,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark52(40.933858016140164,-0.4146870144857884,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark52(40.9544896999046,-1.4999999999999591,0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark52(40.97064637478513,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark52(40.97067388773149,-0.12293061780965786,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark52(41.01881315684264,-1.2998905031163281,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark52(41.03927632045122,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark52(41.107383002532096,-1.0860288973524064,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark52(4.11302144065877,-0.9398425150369308,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark52(41.15382719316011,-0.617195274304164,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark52(41.16156951833296,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark52(41.21425757574693,-0.6396255013536147,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark52(41.235435091287215,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark52(41.24407307058628,-0.029374926319222977,0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark52(41.29023089318524,-0.2836687845947157,0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark52(41.296229479021626,-0.22245744916553456,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark52(41.31385648267897,-1.4166760472896307,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark52(41.33909776585683,-1.1548750599580395,0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark52(41.36942810776873,-0.04875992890168934,0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark52(4.141177908444433,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark52(4.146539769652449,-1.4999999999998712,0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark52(4.147746915238482,-3.021129261125582E-4,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark52(41.4912144538539,-0.6476120886785424,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark52(41.52656260131141,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark52(41.61906346986021,-0.15246583183939322,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark52(41.625500727932376,-0.002201102450278634,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark52(41.67351012121954,-0.8239588271687102,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark52(41.68020823367178,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark52(41.68603681708015,-0.023087929805259755,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark52(4.174342400710536,-0.4581134871361485,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark52(41.764344980671694,-0.46223628831815045,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark52(41.83892156606129,-0.2685530076192606,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark52(41.8485881769886,-0.26272400782762884,0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark52(41.86429659380701,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark52(41.89253799399638,-0.5077679989353936,0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark52(41.9846333966332,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark52(42.060210145421465,-0.7283012614055218,0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark52(42.18045572407887,-0.08788316574987148,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark52(42.222333765846244,-0.02373728775126316,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark52(42.2247871923813,-1.3992346426806885,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark52(42.27015131649723,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark52(42.28209662567677,-0.21854546139104603,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark52(42.288743088532016,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark52(42.3278641058928,-1.3960974613320412,0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark52(42.345055365666155,-0.7701318118544833,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark52(42.41522990972773,-2.010301528038017E-9,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark52(4.2434460977925,-1.4423788812991203,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark52(4.244218867878118,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark52(42.54614107214081,-1.1593062788169557,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark52(42.555770884885746,-1.4412201016840421E-5,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark52(42.6313865213846,-0.6295207305044115,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark52(42.632295643723666,-0.572891466565971,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark52(42.666770701698056,-1.1794800417793323,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark52(4.26995059419481,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark52(42.709605974123356,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark52(42.7467957235784,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark52(42.81424167164337,-0.17958706646510825,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark52(4.285016932473269,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark52(42.860087702663364,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark52(-4.28859514489336,-0.5543664783855647,-1.0000000000598892 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark52(42.903536459099705,-0.5790596552837353,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark52(42.91598216106394,-1.1770669064204355,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark52(42.92355973162984,-0.8501451360904884,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark52(42.954922898617355,-6.917587145548324E-7,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark52(42.956233538351626,-1.1590465078271013,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark52(42.980416367243606,-1.056559637077548,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark52(4.300269296144094,-1.4354946988699044,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark52(4.3005781798697456,-1.2493945702123141,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark52(43.01086081620639,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark52(4.301414510189467,-6.990055835066125E-9,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark52(4.304221609164144,-7.363057608510207E-6,0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark52(43.144157883187226,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark52(43.151519908118075,-1.4999999999446947,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark52(43.15678081340852,-0.011798331493245051,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark52(43.17993026290776,-0.33465622201577894,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark52(43.18299935542518,-0.6764094129687126,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark52(43.23050234144475,-1.0734450642829785,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark52(43.23918197627006,-0.2657416569915858,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark52(43.313049278206364,-0.3317701364376671,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark52(43.31392505026241,-0.03876931511031145,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark52(43.33411523738647,-0.1940041917331885,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark52(43.343503119422024,-0.0221474503157022,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark52(-4.3368086899420177E-19,-0.9686434815034259,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark52(43.42856906439454,-0.5712278495740177,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark52(43.473420813201244,-0.44382953609036147,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark52(43.49044990629389,-0.19058776335909045,0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark52(43.505820346130854,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark52(43.51127614349889,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark52(43.53628783293908,-0.8861139862565831,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark52(43.5436768935501,-0.12248934951036006,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark52(43.61837847664851,-2.060258126374133E-6,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark52(43.62976204793091,-0.8774834195477439,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark52(43.65784943144345,-9.339164873751795E-6,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark52(4.37586772489211,-0.14478311934804822,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark52(43.8389916716626,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark52(43.840684391869246,-0.8472229762773169,0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark52(4.386637379288729,-0.5728926828394216,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark52(43.9532740574825,-0.02700107154957543,0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark52(-43.9609752153349,-0.6438518679720706,-1.0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark52(-43.96213651616168,-1.4158767838782587,0.3375852054444275 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark52(43.988463230832664,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark52(43.989023184814556,-0.3184296417565613,0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark52(44.019425862452806,-1.2390703340654543,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark52(4.418534785185586,-0.18146367250772932,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark52(44.19182354759125,-0.37641667518150035,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark52(4.426454477623778,-7.311227505749953E-8,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark52(44.27505942076883,-1.4999999999999805,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark52(44.28066980005525,-1.4658173158239496,0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark52(44.337108039849625,-0.5544955107309733,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark52(44.378606673655526,-0.028556116186354785,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark52(-4.440892098500626E-16,-0.5335762435710232,-1.0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark52(-4.440892098500626E-16,-1.1261969378111136,1.0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark52(4.440892098500626E-16,-1.4686660362875419,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark52(44.52991922395328,-0.17526938184742802,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark52(44.59692220173607,-1.2085197316808447,0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark52(44.63101072558294,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark52(44.631369544437774,-1.2222519558058593,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark52(44.645792367258146,-2.7066621779563573E-9,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark52(44.67520709024299,-1.212820832035888,0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark52(44.69335940164227,-0.07462573718714945,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark52(44.73299478884903,-0.7154199464042676,0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark52(44.78234750195608,-0.3874289416968004,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark52(44.81319327733837,-0.4225332256502412,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark52(-44.84362001944345,-0.6141752703916898,-1.0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark52(44.87788736272077,-0.5038261767907954,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark52(44.893964311893164,-0.8835797577055471,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark52(44.91269500969617,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark52(44.919179412213055,-1.0718794098647386,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark52(44.93210671998034,-0.2677010160665595,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark52(44.954465216092046,-0.4695014957885064,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark52(4.497572784031737,-6.8309058490086305E-9,0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark52(44.999541404237874,-1.4999999999999978,0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark52(45.08494288871202,-1.2080068892469882,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark52(45.1174982071436,-0.09759716001682439,0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark52(45.12287235182896,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark52(45.14363539066187,-0.044453144624386765,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark52(45.196684566962745,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark52(4.525068105446977,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark52(45.2890392652065,-0.09950808916209608,0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark52(45.29135426432828,-1.499999999999968,0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark52(45.34399435570356,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark52(45.35081777267209,-1.2602821352346898,0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark52(45.376976163599466,-1.4571193301686804,0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark52(-45.38375967878996,-0.559098280764893,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark52(45.38503352059799,-0.5698004794392091,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark52(45.385816121055136,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark52(45.39031948204112,-0.010617846286754329,0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark52(45.43565928416217,-1.243018629818195,0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark52(45.4421364086697,-0.8996654056860429,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark52(45.45303289838526,-1.3974851457956048,0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark52(45.468035294558184,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark52(45.55582096832118,-1.4972927872100896,0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark52(4.556926039709421,-0.22332415656096316,0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark52(45.583966519619466,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark52(45.645171203660965,-0.47382602101487237,0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark52(45.65750696885344,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark52(45.73898695491977,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark52(-45.8371238698382,-0.8279718589858902,-1.0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark52(45.860999134597904,-0.8326209280773842,0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark52(45.92761082012012,-1.2038578118440828,0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark52(45.96982325370979,-0.18134496542309478,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark52(45.97637951150455,-0.19120152009214275,0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark52(46.074266488796596,-1.063083862114707E-4,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark52(46.07643041045044,-8.44483855826943E-9,0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark52(46.089654209013,-1.4402683378032484,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark52(46.0962720498986,-1.1381845732560676,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark52(46.11897219738296,-0.31046460066459347,0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark52(46.167381878810716,-0.2530224218834576,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark52(46.18085079470025,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark52(-46.18287472838198,-1.2023878867614288,-0.011586389584199885 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark52(46.23161677883593,-0.5585129563550097,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark52(46.268973277598434,-0.26178551481670276,0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark52(46.27534284917927,-0.22317485428003037,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark52(46.3376830728921,-1.5855552415339472E-9,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark52(4.637789696821148,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark52(46.38662807536707,-4.16653766729964E-9,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark52(46.39369610437077,-1.1093670168791903,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark52(4.639396533753807,-1.4613774186396058,0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark52(46.40124234772185,-0.11119398167282668,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark52(46.46635258250096,-0.21518175354525226,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark52(46.503816223405465,-0.9134646772224067,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark52(46.54914812894156,-3.0016623252655513E-7,0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark52(46.564892939009326,-0.5530841116186984,0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark52(46.578712374563736,-1.4099874064294475,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark52(46.65883278064581,-0.0210169084504912,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark52(46.65934411747092,-0.194529301560669,0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark52(46.67904079101535,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark52(46.743629144542915,-1.4999915717353391,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark52(46.745155531058565,-0.4411133134670327,0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark52(46.763651627092266,-1.7944192456713803E-8,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark52(46.76547091960894,-0.2597541807115714,0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark52(46.79451200149339,-1.114796507531831,0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark52(46.83448854241158,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark52(46.87803460188507,-0.6112171955165546,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark52(46.908726370063704,-0.22190462010567558,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark52(47.016217006345144,-1.1701819993928604,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark52(-47.04794344525485,-1.2570741816186533,0.05460124497956542 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark52(47.04922052261634,-1.4999999999999876,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark52(47.09178193999895,-0.07850129581469989,0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark52(47.11416024014367,-8.293166583651561E-9,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark52(47.122967651954355,-1.135177263371645E-4,0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark52(47.12832154063224,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark52(47.12962097306638,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark52(-47.24353213596294,-1.2617026604535657,-0.6310218519706252 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark52(47.26917393237486,-0.8264441808859604,0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark52(4.735034461554875,-0.2820284502776502,0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark52(47.38239308995483,-8.843089717561739E-5,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark52(47.40625604757477,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark52(47.433108811217174,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark52(4.744642698002494,-0.40470439890523435,0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark52(47.48202117842186,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark52(4.7484471216435935,-1.4999999999999303,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark52(47.51932991426128,-1.3472722948087377,0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark52(47.56323316805049,-1.3503893511181602,0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark52(47.618155331889966,-1.1985685467072327,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark52(47.63586415672291,-1.3561432357297876,0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark52(-47.64541143281542,-4.369330798929509E-7,0.0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark52(47.707801694317425,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark52(47.71644681131838,-1.1745330948256765,0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark52(47.74646233126602,-0.47919099208667243,0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark52(47.76605266965926,-1.09413186960064,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark52(47.8393851460188,-0.1626924939042237,0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark52(-47.85839754008936,-0.028043083789073497,5.421010862427522E-20 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark52(47.88293679596178,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark52(47.92224349003456,-1.3105152310243828,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark52(47.95158796593188,-0.31385966387133796,0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark52(47.967101606962935,-6.496826058550192E-9,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark52(48.09072365047209,-0.4345518127952186,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark52(48.103099786620824,-7.2803578855998175E-9,0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark52(48.1043105359947,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark52(48.159183941456774,-1.4998283152896352,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark52(48.16511294801035,-0.14716517747925897,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark52(48.16648710318495,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark52(48.22976008013796,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark52(48.25991844423413,-2.51480131914818E-6,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark52(-4.826332517243583,-0.2979453279772731,-0.3620892721026136 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark52(48.28422587552947,-0.4732977097069977,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark52(48.28925479877454,-0.757549999840208,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark52(48.32942248960458,-1.070452382026839E-5,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark52(4.840096241105377,-1.4999999860530744,0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark52(48.463606592939634,-1.4420287700979257,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark52(48.56700840551133,-1.4363000536665256,0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark52(48.59141235511135,-6.191906574595078E-9,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark52(48.64004159706778,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark52(4.865030329566673,-1.55612335483302E-8,0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark52(48.69980343991801,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark52(48.70112024378511,-0.07334735838917084,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark52(48.79836678641789,-0.4467808607830914,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark52(48.84999876022791,-0.46861706775053324,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark52(48.850457940380494,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark52(-48.922272345379916,-1.7764256462626878E-15,0.0015805744223966744 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark52(48.99467014039145,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark52(49.082270341950974,-0.6736905954391297,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark52(49.08744073287058,-0.7508626819474884,0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark52(49.15707819765431,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark52(49.18065939120833,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark52(49.18740021140706,-0.3618266872024236,0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark52(49.23764441239197,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark52(49.277409663112024,-0.53739996224013,0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark52(-4.930380657631324E-32,-0.6180917290844342,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark52(4.937224734644047,-0.9359467326160287,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark52(49.396449232791916,-0.14878756909150678,0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark52(49.39712928656701,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark52(49.4266452597815,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark52(49.43253442171981,-0.6196090398219285,0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark52(49.46346954519686,-0.14563825635744276,0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark52(-49.50033942323935,-0.02589619088633403,-0.9999999937532322 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark52(49.50632695677538,-0.13255690794940422,0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark52(49.564553707958595,-0.6294325398635764,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark52(49.73111969742766,-0.2213923412772889,0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark52(49.85866199428145,-0.36879937744794233,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark52(49.8850505718714,-0.6093753678137828,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark52(49.88769918416358,-0.5468581392852627,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark52(49.969896712228746,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark52(49.97051800751649,-0.5677432057953098,0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark52(49.99537755422483,-0.9085754310601963,0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark52(50.01202790273228,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark52(50.07011058914003,-6.17371797635416E-10,0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark52(5.009080248547491,-0.6171064174875482,0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark52(50.10455177863234,-0.8935099152666033,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark52(5.0247383300224895,-3.66600363750088E-9,0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark52(50.25663626203999,-1.3657043195206442,0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark52(-50.2956384572516,-13.599686958384922,-13.901106990293542 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark52(50.296156407681906,-1.4999999999999902,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark52(50.33627086791782,-1.383025961010432,0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark52(50.37973283456677,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark52(50.437593443404495,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark52(50.47887389840042,-0.883036391906785,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark52(50.49869892174473,-1.0908101942243604,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark52(50.512773932169154,-0.6809961571258896,0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark52(50.52312360163706,-0.38955675874537654,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark52(50.53216527661121,-0.3586006457111619,0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark52(50.6138312881381,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark52(50.63505673757124,-0.02050446836944475,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark52(5.06400944418391,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark52(50.66483522656944,-0.1628958518989947,0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark52(5.069237736485825E-17,-0.14180491148761382,0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark52(5.070102592082847,-0.8623908145000407,0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark52(50.81859400514836,-0.7444835808117956,0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark52(50.84275620767505,-1.4645592091716195,0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark52(5.085484881031505,-0.051590768638190704,0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark52(50.904966395229636,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark52(50.90950725195984,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark52(50.91569139329849,-0.7226636418789072,0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark52(51.0240079624344,-0.31120722725574235,0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark52(51.077216806083555,-1.1828399395170663,0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark52(51.13170324773995,-0.22729259709481653,0 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark52(-51.14883913472924,-1.160768887792841,-2430.6028436547585 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark52(51.17252455598418,-0.44948833772927843,0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark52(51.195582643475774,-1.191689254417415,0 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark52(51.20546207705256,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark52(51.31912671396651,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark52(51.3251803158181,-1.0592940476774397,0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark52(51.44599259475652,-1.199837643322553,0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark52(51.47406963474688,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark52(51.49384868977904,-0.04288209153058631,0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark52(51.501243075436065,-1.027628805576731,0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark52(51.518959699910084,-0.20160365306765193,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark52(51.52244717831175,-0.3680774726750684,0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark52(51.587567067511145,-0.086448235971463,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark52(51.60576199984312,-0.05006553228770855,0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark52(51.6937754129394,-1.0811878858007984,0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark52(51.739417093156035,-1.3840954104804357,0 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark52(51.82435331442582,-0.19673595494932172,0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark52(51.826548351710045,-0.9193077656248789,0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark52(51.83867890748352,-0.1976240564421608,0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark52(5.185812981455243,-1.2688740609136329,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark52(51.89033838943084,-0.09146581026544531,0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark52(-51.94729191676442,-0.18449855180526914,0.0018304802221851427 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark52(51.95503242239667,-1.1555309372020677,0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark52(52.01531389233365,-0.25990241282728377,0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark52(52.0331632608204,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark52(52.065688406437204,-1.295521140691605,0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark52(52.07076767963846,-1.1479854618740188,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark52(52.07108217070467,-0.9837282694357021,0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark52(52.07405793858563,-0.17884011198892047,0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark52(5.210919159677331,-1.0000994429854253,0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark52(52.11607417615804,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark52(5.215917397877663,-1.0203695232547805,0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark52(52.20927521033136,-1.499999996517339,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark52(52.223882063420746,-1.4607946716690976,0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark52(-5.233861874643722,-1.2213497330491947,-80.33655822034027 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark52(5.234796654421123,-4.4001507712970956E-8,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark52(52.36666195291315,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark52(52.38144720063569,-0.32045492424547667,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark52(52.40838829378897,-5.237542712246861E-6,0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark52(5.244097807130601,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark52(52.4483932581834,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark52(52.50020347439991,-0.2394611393510001,0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark52(5.2514956961133805,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark52(-52.52372082376354,-1.499999962919017,-1.1704190886730496E-97 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark52(5.26296600680139,-1.4025654184611018,0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark52(52.67981521995691,-0.49928517689969537,0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark52(52.723187020700635,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark52(52.751105814069646,-0.6041927383033221,0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark52(5.279392263892973,-0.8141479127519448,0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark52(52.794372267926335,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark52(52.81419137164903,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark52(52.81620696289181,-0.03208373259393227,0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark52(52.832546674932615,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark52(52.88726012657244,-0.5069146055609348,0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark52(52.914582343619145,-0.05678884036869647,0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark52(5.296616373368147,-0.5511134247054201,0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark52(52.971838690117465,-0.3177532797046183,0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark52(5.29719446623308,-0.9578698847181657,0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark52(52.99490306930906,-0.26828921866296973,0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark52(53.015286486481585,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark52(53.01770948272856,-1.0010796912027953,0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark52(53.07618419109501,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark52(53.08121485181765,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark52(53.106831130539035,-0.04868915806960058,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark52(5.314845537783167,-1.3147351860771634,0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark52(-53.15087390380027,15.963684420236234,99.78772103776029 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark52(53.18445336740804,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark52(53.21874525961249,-0.07583695969625914,0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark52(5.322355330297441,-1.499999999999929,0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark52(53.237782979253296,-0.2565545579238493,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark52(53.242243090560805,-0.8109404936097491,0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark52(53.25863805819739,-0.3716503835142563,0 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark52(53.282182031827034,-0.7079676975417613,0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark52(5.33151465916346,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark52(53.36621030261405,-0.9910791529676821,0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark52(53.396618099365384,-1.3691455804705157,0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark52(5.346723738501341,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark52(53.486813729237014,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark52(53.62537548625923,-0.342695342021865,0 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark52(53.62988641246485,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark52(53.63815945827909,-1.3697989765180378,0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark52(53.6556564858045,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark52(53.69689017854167,-0.6195704024919051,0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark52(53.70070752507788,-1.3835292390316056,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark52(53.70556729720391,-0.24812088586067574,0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark52(53.71074181848679,-2.7151712764909236E-8,0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark52(-53.73114672611343,-1.4816845430126477,46.35243635628771 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark52(5.380943090832849E-6,-0.6534503085723596,0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark52(53.83836747133034,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark52(53.85721412064348,-1.179061254175119,0 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark52(53.86294690600528,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark52(53.93716663630644,-1.4526065179385022,0 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark52(53.94877640950355,-1.335373886026808,0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark52(53.9904743568671,-0.8917462570876324,0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark52(54.016040861002665,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark52(54.02536707858263,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark52(54.031087376213776,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark52(54.03254599285171,-0.7442184236882845,0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark52(54.066180229032874,-2.2776015991151907E-8,0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark52(54.111289809207136,-1.4999999994349806,0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark52(54.11532514682226,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark52(54.11536938291561,-1.1376868946111764,0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark52(54.18938894692502,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark52(54.20937427443482,-0.12318663550425413,0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark52(54.23127724643589,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark52(54.263429249563664,-1.1595137506629971,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark52(54.264565079786905,-0.5255938664843498,0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark52(54.286041527368326,-0.7434410640838376,0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark52(5.432363385841947,-0.004857710537462423,0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark52(54.353984293365954,-0.4498839087980855,0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark52(54.37374930924457,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark52(54.43335206915961,-0.7672065464695592,0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark52(54.459784192910625,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark52(54.461311693386364,-1.314749159486605,0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark52(54.481374808873596,-1.284004846527706,0 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark52(54.49162073098469,-0.9858208525912886,0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark52(54.49949120484007,-0.4259853058701637,0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark52(54.50544135352581,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark52(54.51054118966147,-1.1601442339061379,0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark52(54.55030750867175,-0.004863007212378534,0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark52(54.56067682499318,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark52(54.56929569660551,-0.9063358178591634,0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark52(54.63335185762991,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark52(54.65410320392962,-0.6303679604881527,0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark52(5.466767086363987,-0.48386171862236016,0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark52(54.6858138213658,-0.04866448741795715,0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark52(54.69648856390941,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark52(54.73079225366081,-0.5419534782878941,0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark52(54.738473361388586,-1.4682506677635825,0 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark52(54.88278082614571,-1.4306742192637123,0 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark52(54.8919876799668,-0.06451994189788479,0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark52(54.93208556602818,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark52(54.94700122943863,-8.271594231256235E-5,0 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark52(54.97937686824258,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark52(5.497984809933882,-0.8729420155916061,0 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark52(55.01888444643566,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark52(55.03110118660431,-5.174598607169209E-6,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark52(5.504240420127289,-1.1359601045724281,0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark52(55.049697556467535,-0.2977695688862019,0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark52(-55.05332516201097,-0.3082396467976538,4.692484150809172 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark52(55.053962891651224,-0.7167239851292919,0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark52(5.507967954224796,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark52(55.10622485187352,-0.1654947306927257,0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark52(55.120835730894356,-1.343744811807492,0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark52(55.124692816790855,-0.4978957437705276,0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark52(55.14498843581376,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark52(-55.14608363867508,-0.4756247618435978,-94.35069881601201 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark52(55.162195678130935,-1.4392930581061323,0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark52(55.19279891205478,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark52(5.525536106549424,-1.0734653616906766,0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark52(55.27481085384278,-0.885506731565677,0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark52(55.33247814582664,-0.39342474859724763,0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark52(55.36481384619781,-6.42858990744509E-7,0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark52(55.40058828774244,-1.4999999999999858,0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark52(55.4075487630997,-0.10905719857824914,0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark52(55.46241043718041,-1.0871807529230182,0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark52(55.490521471476214,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark52(55.50583158541397,-1.4999999999404265,0 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark52(5.552181308342725,-0.2784659780166727,0 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark52(55.525857500661544,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark52(55.648097205054896,-0.5564791469823867,0 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark52(55.728544563541504,-1.2124803746463273,0 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark52(55.750229562622636,-0.4535280779336698,0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark52(55.76388490757792,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark52(55.77517574237504,-0.7838692650745913,0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark52(55.8342048626712,-0.2678880015708973,0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark52(55.925125252161735,-1.2321277875420549,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark52(55.936224260069956,-0.7911258601596615,0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark52(55.97119874849298,-1.524864851528577E-7,0 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark52(55.97847255801517,-1.2810231811695594,0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark52(55.982153569896916,-7.440158716164604E-10,0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark52(56.010042049039185,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark52(56.033890341279914,-1.2232307335268402,0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark52(56.059511687103026,-0.6577020051324061,0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark52(56.13353791487981,-1.256649528556462,0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark52(56.16886761855517,-1.0526843214543806,0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark52(56.18071052742039,-0.9047991342273605,0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark52(56.20639956730606,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark52(56.21574864637441,-0.8965465928757617,0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark52(56.24167896166483,-1.1419892070534843,0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark52(56.24803273895043,-1.4733578192053187,0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark52(5.625154675997848,-0.2772940415964283,0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark52(56.28311226707606,-1.3816723921937495,0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark52(56.41157058601544,-0.22852269407384362,0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark52(56.44705031020942,-0.8802050330936879,0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark52(56.454912260321635,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark52(56.45646764389093,-1.08851756651209,0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark52(56.47947906539463,-1.1323660181695496,0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark52(56.54916196889664,-1.499999999999996,0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark52(56.56812940784343,-1.438938944791408,0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark52(56.58715587157656,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark52(56.62912570146102,-0.6004972875246875,0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark52(56.63140030982131,-1.201074738335099,0 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark52(56.705238798595474,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark52(56.76746674880428,-1.3020591984934566,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark52(56.820695416677154,-0.23180581863719496,0 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark52(5.6854383675724876,-0.5897176297767572,0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark52(56.901846647929034,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark52(56.90345424323823,-0.9017740551194962,0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark52(56.94523074396398,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark52(56.968481919819425,-1.1754378665333292,0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark52(57.00923564163128,-1.0193267892914832,0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark52(57.00945705041843,-0.33652574315989536,0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark52(57.07037103950671,-0.7576742537081701,0 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark52(57.08160711589835,-0.5867738970004189,0 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark52(57.131587928167235,-0.7671624498527669,0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark52(57.13935275787108,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark52(57.15090997374321,-0.09509095894672101,0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark52(57.159158950884645,-0.2639623741973557,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark52(57.20638910815836,-0.5511716071108032,0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark52(57.26384331223886,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark52(57.27069420941302,-1.173232367796757,0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark52(57.34074619795777,-1.3232797964991931,0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark52(57.34387146131564,-1.4326509249050972,0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark52(57.39776615599584,-0.16632820022085149,0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark52(57.428761411748795,-2.7747476937419987E-4,0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark52(57.43807824945176,-1.1000056404339347,0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark52(57.47515418331729,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark52(57.54959818488663,-0.5087505463502827,0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark52(57.58288916745974,-1.2073989238117504,0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark52(57.69374610013704,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark52(57.69552652287982,-1.4016314338759344,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark52(57.708049628895274,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark52(57.709080100204204,-1.408289676668284,0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark52(57.712022579127485,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark52(57.726273915036295,-1.0877215359251982,0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark52(5.7772722336701205,-0.34388058469310334,0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark52(57.775520133249216,-0.44579562160969033,0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark52(57.78901539029832,-0.6238222957127517,0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark52(57.80819830373684,-1.2259506923094694,0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark52(57.82286919990233,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark52(57.8293370137896,-0.23933612455738407,0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark52(57.849251471049456,-0.2075685774702407,0 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark52(57.86893869854585,-1.15649373189749,0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark52(57.879806348347806,-0.3088085807865579,0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark52(57.88461764593819,-1.1474699806856563,0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark52(57.88978475365869,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark52(57.96953943205247,-0.41274534503427596,0 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark52(57.97273155120257,-0.04833952635610217,0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark52(57.99467974127319,-0.38983473829348303,0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark52(5.8016710397191157E-216,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark52(58.01938858798684,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark52(58.032994855110495,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark52(58.04612735640265,-0.3103444966228892,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark52(58.117732814161194,-3.771073778593934E-8,0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark52(58.21522386708221,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark52(58.23446349962279,-0.1547813694416793,0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark52(58.24532036415049,-1.4999999985680683,0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark52(58.27742687309743,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark52(58.302510213798854,-0.013449288174962834,0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark52(58.31782688650412,-0.04545816754989307,0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark52(58.32022004572124,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark52(58.34644364422513,-1.2729030800249745,0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark52(58.350033206908705,-0.03696855082591699,0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark52(58.45711802903121,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark52(58.46207158213468,-0.33535951352125815,0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark52(58.50041586362761,-0.6245860868063176,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark52(58.571086485595124,-0.028422281632570545,0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark52(5.877231563301746,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark52(58.921562402244035,-0.7934534109944478,0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark52(5.899266221049496,-1.1176344621400283,0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark52(59.027161328282844,-0.6972431573585842,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark52(59.030042401339244,-0.29586874882505754,0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark52(59.03997393787296,-0.45421096922355214,0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark52(59.070205581867384,-0.9956477307122285,0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark52(59.07561603644014,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark52(59.10576503463514,-1.1173847221754176,0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark52(59.109231067104815,-0.25354231323303633,0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark52(59.12969987694294,-0.6355972114924384,0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark52(59.14119337178283,-1.4239213919889906,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark52(59.145459775418495,-0.23474989656687306,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark52(59.219941667487205,-0.001815270584746731,0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark52(-59.241402470255785,-2.6952205065788056E-7,2.889574608052376 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark52(59.30636218599378,-1.4582254819998635,0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark52(59.36664689140712,-1.3010219865662247,0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark52(-59.40010114350861,-1.1059727340531949,-1.0 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark52(59.40512394555287,-1.2426405376661847,0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark52(59.41434649956199,-0.02880207400943809,0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark52(59.432210213188284,-1.418277295607548,0 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark52(59.48057549508391,-1.1590846805956927,0 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark52(-59.56483094754426,-0.9882685834202611,-1.0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark52(59.59046980401189,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark52(59.60080441857468,-1.1884317310791914,0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark52(59.601087138140485,-0.05734934573623418,0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark52(59.61509966299528,-1.1268123772793572,0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark52(59.64054429796954,-0.2619958398130392,0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark52(59.66610209984523,-0.12541434503654614,0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark52(59.687463826010344,-0.6607697912839283,0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark52(59.696707623807384,-0.9254048024945938,0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark52(59.698874269036,-0.5352521769776359,0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark52(59.70310199799317,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark52(59.70391950241167,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark52(59.70899217547343,-0.7224071925696867,0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark52(59.72513207755904,-1.4863247962028088,0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark52(5.972925352209978,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark52(59.74492967192848,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark52(59.751679004017575,-0.04155917122283981,0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark52(5.975554698102081,-1.4999999988658588,0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark52(59.7570789517453,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark52(59.82474530853453,-0.6504499249276688,0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark52(59.88322738347591,-1.0324528081507172,0 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark52(59.92657378214332,-0.9746944525975465,0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark52(59.95475889768568,-0.20683739662672837,0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark52(59.990578422676975,-0.6468398309430805,0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark52(60.051303094274914,-0.20063396688991442,0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark52(60.063585987236536,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark52(6.00869281609305,-6.305938476505923E-6,0 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark52(6.010194837516317,-1.341737709941171,0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark52(60.121567349041676,-0.022295747033961328,0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark52(60.21490704305888,-0.3789474035077447,0 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark52(60.25694133334032,-0.05489401758090828,0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark52(60.27591107051754,-0.1705637817016584,0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark52(60.28287181823501,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark52(60.300154896071604,-0.02709409688680431,0 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark52(-60.37612702977049,-1.3422653133895084,-0.06231969749823828 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark52(60.4315802790512,-2.3117899050613493E-9,0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark52(60.45332345681342,-0.25698462245992637,0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark52(60.518354792647635,-1.4386012319863417,0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark52(60.54216886379345,-4.40647516735781E-7,0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark52(60.58603204625072,-1.1227388223712609,0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark52(60.58950742717288,-3.0211337685928172E-9,0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark52(60.59653180301456,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark52(60.632844542715866,-1.37813284873775,0 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark52(60.64089634477022,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark52(60.77026619870486,-0.9626314586097351,0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark52(60.84694299340845,-0.05200981583442932,0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark52(60.858980780133436,-0.3518448715005057,0 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark52(60.87426397452433,-0.0035095986766754406,0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark52(6.088596321310021,-1.0628478491887008,0 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark52(60.999329087562955,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark52(61.01469675182781,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark52(61.02472703372521,-1.4999999999999978,0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark52(61.03194362228675,-1.1806733906370095,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark52(6.114231122828755,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark52(61.14880922786109,-7.848024939925686E-10,0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark52(61.154462689521324,-0.19196216092254303,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark52(61.157920367560706,-1.0613813774678902,0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark52(61.17581372576461,-1.023412016933892,0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark52(61.18111784970998,-0.18764708264309787,0 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark52(61.19654851099528,-0.2122442857356872,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark52(61.200590437367765,-1.1637930761823725,0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark52(61.2054184561083,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark52(61.29406532004786,-0.39321397888485876,0 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark52(61.36280009029292,-0.40486657615880406,0 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark52(61.36331485037645,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark52(61.37962824739856,-0.28866788024619006,0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark52(6.138444394415564E-7,-1.140697821680012,0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark52(6.144432565841691,-0.965306878379522,0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark52(61.47033427965236,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark52(61.48256041743614,-1.138037293040521,0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark52(61.51069045924061,-0.5173041138732195,0 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark52(61.52901811739055,-0.3793349356943594,0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark52(61.54077832757153,-0.507034026053347,0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark52(61.5566278776237,-0.6251916741940344,0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark52(61.56543500088904,-0.9468876045669763,0 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark52(61.65324055461441,-1.34080255321672,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark52(61.69642779940216,-1.272025737196281,0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark52(6.1722553334572865,-28.013751670194466,-23.332985259862227 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark52(61.73985164441308,-0.4184974134316519,0 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark52(61.7484964035854,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark52(61.758322280080414,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark52(61.808160029997595,-1.3993941875978533,0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark52(6.182906124767953,-0.20207798053635845,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark52(61.833723402890946,-0.6927282256106245,0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark52(-61.84869098946126,-0.23603882371388885,64.83884977101955 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark52(61.85288422086248,-0.0778316909465353,0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark52(61.855648622938574,-0.12666126000091227,0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark52(61.93782966230535,-1.1826943934569898,0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark52(61.94691806020328,-1.402307910872163,0 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark52(6.1974271660570395,-1.4526036343352313,0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark52(61.97983390418338,-1.1107020853443976,0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark52(61.98157731415276,-0.8649938550444176,0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark52(61.98311516398411,-0.18218126239082144,0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark52(61.98800080624605,-0.23025232798720197,0 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark52(62.02178785518084,-1.1909316301345125,0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark52(62.06109156663413,-1.1694687306580107,0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark52(62.0691803378603,-1.2470988372336267,0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark52(62.0701900220904,-1.2175625448039216,0 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark52(62.07375793545796,-1.1231280013591085,0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark52(-62.08726523590283,-1.4815894409146042,0.9999999999999986 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark52(62.15248887508677,-0.013447540469124553,0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark52(6.2187975843988,-0.91219681744903,0 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark52(62.225445349720445,-1.0799170298053034,0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark52(62.231214947026956,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark52(62.24415158668876,-0.16146959504707326,0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark52(62.28040209984508,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark52(62.29421989261209,-0.4209204105290292,0 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark52(62.307110525717405,-5.4106685355771E-15,0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark52(62.42576054859933,-0.15378381754041826,0 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark52(62.46409001985714,-0.9512786841087575,0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark52(62.47857352533546,-1.4025718429017786,0 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark52(62.49355842802943,-0.7271081324515336,0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark52(62.63335975609107,-1.4999999999999662,0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark52(62.67218902339886,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark52(6.272035505028597,-0.21052118563353872,0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark52(62.73092784508759,-0.23308363497773144,0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark52(6.273391919296333,-6.202077002618494E-10,0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark52(62.767495485292386,-2.945433409939001E-5,0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark52(62.82534573056931,-0.10198651937035708,0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark52(62.86309736209737,-1.5349351772154777E-9,0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark52(62.87082148547415,-0.9956735844579008,0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark52(62.924255620328324,-0.019522423652341553,0 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark52(62.92701910697432,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark52(62.92936567124767,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark52(62.93491451401454,-1.4974105644960085,0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark52(62.96709462669516,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark52(62.97218628576013,-0.18802318548520347,0 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark52(62.979673199186365,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark52(62.98193354641066,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark52(62.98692498430617,-0.25450574981270613,0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark52(63.06316639678286,-0.1831823435501032,0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark52(63.081021444150565,-0.9866011929836986,0 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark52(6.3108872417680944E-30,-1.4678296844464191,0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark52(63.13360767515107,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark52(63.13476886419377,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark52(-63.17512907699845,-1.1138957011122368,47.51891856874329 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark52(63.23064787653822,-0.15388365525033443,0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark52(63.31058405908391,-1.4570355062765195,0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark52(63.46968589797288,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark52(63.48874234136103,-1.0125170187455776,0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark52(63.51201946429666,-0.018216944059467277,0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark52(63.53004294489267,-1.473637303921806,0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark52(-6.355330326194587,-0.4537193987291859,-1.0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark52(63.57159626079597,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark52(6.358725108437303,-1.3200909897761162,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark52(63.63802209205477,-0.4949468814522895,0 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark52(6.3655813396104435,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark52(63.68783756593092,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark52(63.69839199575427,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark52(6.3757178519386795,-1.0734613710129417E-5,0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark52(63.757732195346534,-0.46540674334048776,0 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark52(63.77418405681203,-0.3263082358526374,0 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark52(63.806300253122544,-1.181254354212175,0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark52(63.83580376791983,-0.6436970266092195,0 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark52(6.385739105172149,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark52(63.86067233272178,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark52(63.96783614218619,-0.733498171963161,0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark52(63.983302478024655,-1.4066681314127667,0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark52(63.984338896858105,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark52(64.06870040551217,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark52(64.07132153945184,-0.6714875626732382,0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark52(64.07662699099201,-0.008033696421979679,0 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark52(64.12969505256912,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark52(64.18807835439281,-1.2076982033374573,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark52(64.21518136760363,-0.10076004243624936,0 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark52(64.22476145552756,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark52(64.26584396176828,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark52(64.30300717753215,-0.18479092423960447,0 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark52(64.3379599447023,-0.445971898631101,0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark52(-6.43465447809032,-1.499999294310298,-0.9999997643796273 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark52(64.36397130157138,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark52(64.36583345965768,-1.208513312185648,0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark52(64.40299841864373,-0.24294169896244,0 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark52(64.40804967562897,-0.42154409544752736,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark52(6.442164211582694,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark52(64.44779363073752,-1.336713845801186,0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark52(64.45017901548741,-0.6631039585490299,0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark52(64.46545901287769,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark52(64.47900497126275,-0.05742560540744002,0 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark52(64.48374298789753,-0.6443703301311183,0 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark52(64.50878832886258,-0.046702618786777735,0 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark52(64.5498013748745,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark52(64.56476345489355,-0.8021857386699893,0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark52(64.62778047040165,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark52(64.65791993634198,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark52(64.69166326716157,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark52(64.73647777818623,-0.379467155029919,0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark52(64.74905219250786,-0.48923661698803755,0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark52(64.75764814876968,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark52(64.81070527160708,-0.9065312827668066,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark52(64.81992276093806,-1.3303032383496536,0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark52(64.90174539743813,-0.284924186372038,0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark52(64.913475709886,-0.02422307934722042,0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark52(64.92084696574983,-0.8474390653596346,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark52(64.9365600975502,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark52(64.9547972600729,-0.12768080646909397,0 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark52(64.98168444792393,-0.07483596987168184,0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark52(65.00903611460303,-0.9877360181261616,0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark52(65.02338536662828,-0.6121460124956913,0 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark52(6.511500190465313,-0.8167806486849116,0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark52(65.2683984063685,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark52(65.33923346695708,-1.5465265788027846E-4,0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark52(-65.38083608558551,-0.9849569744550717,0.27651329896557975 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark52(65.3996662204788,-3.987290806594171E-8,0 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark52(65.41149120329472,-1.2841434426517377,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark52(65.43306941694425,-1.209805535372961,0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark52(6.54522106987892,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark52(65.46450256857673,-1.3626215744687231,0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark52(65.46916494407506,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark52(65.47431537755074,-0.9164855135964913,0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark52(65.48664970177899,-0.8436314742342006,0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark52(65.49661425568438,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark52(65.54875531058636,-1.4999999999999538,0 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark52(65.56946451995357,-0.40476059594266545,0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark52(65.65635731371384,-1.2004968198452168,0 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark52(65.66388527028445,-1.37692310820184,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark52(65.67773827917222,-0.4770704550046929,0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark52(65.80584069394138,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark52(65.8216350606038,-1.4810387172950445,0 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark52(65.82669235016903,-0.045162467261533834,0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark52(65.82835716939005,-0.3304973259680306,0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark52(65.84728914407489,-0.9086544920599833,0 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark52(65.85367363159614,-0.7995028037568659,0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark52(6.58666811569551,-0.907001020947332,0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark52(65.89011738567945,-1.3348620677647536,0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark52(65.90056964806607,-1.1160161341358252,0 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark52(6.5914921304943555,-0.2205355513899161,0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark52(65.92647818223759,-1.300900767912203,0 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark52(6.595883359985518,-9.209385798548198E-10,0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark52(65.97905307309998,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark52(65.9822099704898,-1.3082833601655977,0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark52(66.01338877960214,-0.5221428672716206,0 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark52(66.04262547666627,-0.5364316599333314,0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark52(66.05928008506356,-0.7613519656718001,0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark52(66.10056900911601,-1.2320082062115603,0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark52(66.13039297840248,-1.4221658754986208,0 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark52(-6.614455000043718E-15,-0.19577447324070218,-1.0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark52(66.18599049463919,-0.7374862501665316,0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark52(6.6187379347440185,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark52(66.20155750935405,-1.2334797486553555,0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark52(66.22905512850421,-4.9057498173301407E-5,0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark52(66.23571353953551,-1.051690229610682,0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark52(66.28539105261359,-1.3334260039395385,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark52(66.30626697984326,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark52(66.39367563229536,-0.7728888392954687,0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark52(66.48034978427003,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark52(66.48171907574795,-0.5401002635387187,0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark52(66.49643268446067,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark52(66.53869514842042,-0.7230247376260817,0 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark52(6.661971598929114,-1.1094392076678758,0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark52(66.69461463332033,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark52(66.70316086588315,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark52(66.7098860864335,-1.3885469591235449,0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark52(66.74118995550364,-1.499999999999961,0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark52(66.76493951257281,-0.040425961848884695,0 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark52(66.77065961823638,-1.4706681807423614,0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark52(66.82682397502089,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark52(66.85571276391647,-0.7242660247832625,0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark52(66.8738322746767,-0.6573328248647812,0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark52(66.87429429303216,-1.2982036970036657,0 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark52(66.90218668476098,-0.2874608732578522,0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark52(66.97068781417448,-0.3375643107378802,0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark52(-66.97789890937334,-0.9326073651520915,-1.0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark52(67.02369729501345,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark52(67.02975162131659,-1.2423932555564625,0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark52(67.08181280157663,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark52(67.09649271444164,-0.07519476333410795,0 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark52(67.1029485171234,-0.9197966323926288,0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark52(67.10933363322012,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark52(67.2688322866426,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark52(67.2890190129352,-0.10826227783386022,0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark52(67.30794434199295,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark52(-67.38835687234527,-1.436066322509717,0 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark52(67.40227124374013,-0.019705329040199088,0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark52(67.42460146677082,-1.272016980343448,0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark52(67.43758475167948,-1.3407365624748186,0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark52(67.46675618480646,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark52(67.47425045522354,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark52(67.5428660697348,-0.6634948425157007,0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark52(67.55474220854106,-1.1986783401568173,0 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark52(6.756775372848379,-0.9918471628496865,0 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark52(67.56798852442398,-0.5770567675948683,0 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark52(67.59574150094562,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark52(67.60101540189505,-4.7301313929026705E-6,0 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark52(67.61164592486645,-1.1679219253805453,0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark52(67.62816866397878,-0.717850793098366,0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark52(67.71238597589226,-0.6778908617198693,0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark52(67.7273115459347,-0.6133031196741143,0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark52(67.79217820929725,-0.7633402498119743,0 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark52(67.8054582951344,-0.4661201243637288,0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark52(67.86292536620692,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark52(6.79007602703733,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark52(67.90961393810035,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark52(6.799052199213222,-0.5149955522844749,0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark52(68.02844783937266,-0.9920043195513295,0 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark52(68.07069768178017,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark52(6.817428672824576,-1.3258411431472623,0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark52(68.17469304731958,-0.25029503298339595,0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark52(68.21967596976991,-1.4397186659472612E-8,0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark52(68.24290786038614,-0.41109233407884815,0 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark52(68.24937321844416,-1.3598503972416314,0 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark52(68.26926334505804,-5.871915759500819E-5,0 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark52(-68.27789564919185,-1.1102230246251565E-16,1.0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark52(6.833876099552953,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark52(68.43983676552193,-1.068341092488903,0 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark52(68.44820121348997,-0.2905572775772658,0 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark52(68.55208161655077,-0.6819346574940202,0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark52(68.61159410624623,-0.40464855828512464,0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark52(6.8641132587821785,-0.39344930012195045,0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark52(68.7695225465956,-0.08935505189019022,0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark52(68.79712131137694,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark52(68.81879269681664,-0.23192699475989742,0 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark52(68.85604687017042,-1.3773034413603051,0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark52(68.87333770229779,-0.1386602309298155,0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark52(68.88948723379133,-1.024578158903688,0 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark52(68.94894912696638,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark52(68.98746372743584,-0.0022718162403980026,0 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark52(-6.901760462452109,-0.2569580786594887,-0.6331312404951754 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark52(69.05471214629722,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark52(69.10750644444437,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark52(69.13026198113974,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark52(69.21095920226628,-0.9725791814624358,0 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark52(6.923008521321597,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark52(69.27096582655648,-0.4369624574604103,0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark52(69.31392340443662,-0.7674738668638525,0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark52(69.36240600795239,-0.19485614229761739,0 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark52(69.46748210235717,-0.20536706099632385,0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark52(69.52737963509828,-1.0484157056571766,0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark52(69.63744865296354,-1.1744606982128225,0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark52(69.65068902663694,-1.4350229521039797,0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark52(69.72147820263524,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark52(69.77787514882328,-0.2898141571996007,0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark52(6.978606336571431,-1.0667221987142212,0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark52(69.82163853462822,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark52(69.82207889145741,-1.2895067783738146,0 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark52(69.83735993895172,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark52(69.84137779336174,-1.4569448044060813,0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark52(69.8896805788382,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark52(69.89068870041275,-1.0422224963168008,0 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark52(6.990223729533255,-1.0912260062083194,0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark52(70.01149469606611,-0.45656082050047675,0 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark52(70.04078267834547,-1.1720780322021707,0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark52(70.15475367084187,-1.3854807270682201,0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark52(70.1959114279903,-0.3766342700636874,0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark52(7.022560536208449,-0.3889024745387206,0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark52(70.25470437813209,-0.9491976251803809,0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark52(70.29942521961196,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark52(70.3506522207841,-0.002609458519454715,0 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark52(70.37836393065905,-0.7850875537690875,0 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark52(70.38291702303039,-0.3124358167640233,0 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark52(70.38768304553143,-5.072812974934623E-6,0 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark52(70.4141085577303,-1.1351934876315586,0 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark52(-7.04590999474193,-1.433887208045228,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark52(70.53657602961306,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark52(70.5880266669432,-0.001969569921890457,0 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark52(7.0615753503022685,-3.7005319039271955E-9,0 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark52(70.661236454288,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark52(70.68670258607847,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark52(-70.70788959491185,-0.11682796699171047,0.06255252671072516 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark52(70.7105692572027,-1.2473581703746675,0 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark52(70.80363766779887,-1.3924315664255826,0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark52(70.84571264854142,-0.4562276395753102,0 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark52(70.88225597604544,-0.31684584780068903,0 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark52(-70.91878442793295,-1.4999999999999993,1.0 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark52(70.93873420830144,-0.25407773998076877,0 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark52(70.94184154448351,-1.0821179705454068E-6,0 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark52(70.9830991794254,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark52(71.02413952484866,-1.2117614166140527,0 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark52(7.103483070579176,-1.4999974102063276,0 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark52(71.04494116439909,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark52(7.105427357601002E-15,-0.4173513504744051,0 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark52(7.105427357601002E-15,-0.8835759465221056,0 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark52(-7.105427357601002E-15,-1.486599437893844,-0.8486621789405249 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark52(71.06290838547542,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark52(71.06638025874213,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark52(71.08515550848921,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark52(71.10192521873776,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark52(-71.17341690254024,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark52(71.17866155262996,-0.817560325856622,0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark52(7.1183970261196094,-1.3949647560260559,0 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark52(71.28544220051435,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark52(71.32103577834835,-0.705531313121468,0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark52(71.45788657269108,-0.18157127126735162,0 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark52(71.48233072070036,-0.7776902502168053,0 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark52(71.51863004374519,-1.0487977536072508,0 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark52(71.55987059910791,-1.3254132822956137,0 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark52(71.62445023003076,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark52(71.65753736232793,-0.9628467465855124,0 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark52(71.71207857484181,-0.4674777091655713,0 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark52(71.7471848918646,-1.0572356272967056,0 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark52(71.76277302893445,-0.1724083035291848,0 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark52(71.79937816549432,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark52(71.81408903425978,-0.5771764346803305,0 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark52(71.84158186535865,-0.6636613892328596,0 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark52(-71.86369541352074,-0.4238610716451987,-0.5896235878654128 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark52(71.88589474057468,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark52(71.91851362013011,-0.7731281221098224,0 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark52(71.93577918987083,-0.3504941277612943,0 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark52(71.94542525796516,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark52(71.96411408743703,-0.5844642080307008,0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark52(7.197724067802483,-1.3073291810747065,0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark52(71.97956529605273,-1.4549441708447546,0 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark52(72.0441018602497,-1.2081958180942873,0 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark52(72.13513534353592,-1.0056674802530687,0 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark52(72.14308387519074,-0.3060974569326649,0 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark52(72.148086932306,-0.7391307255435299,0 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark52(72.19790635599233,-0.19363211145835146,0 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark52(72.2088541523954,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark52(72.22109486981057,-0.3946831530253192,0 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark52(72.24448919819042,-1.2029330791640405,0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark52(72.25194088404328,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark52(-72.34776274243234,-1.4999999999999996,-1.0 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark52(7.235109354681953,-0.3627155952192278,0 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark52(72.37977624781219,-1.275627347583665,0 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark52(72.43741729020647,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark52(72.47517429214959,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark52(72.47681811273134,-1.1380506386688722,0 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark52(7.248005076398302,-1.2621321158397794,0 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark52(72.5077873564676,-1.3043383461201636,0 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark52(72.51965375182382,-1.0890676325914785,0 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark52(72.55976357998534,-0.03954208582992257,0 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark52(72.57579679032057,-0.8752402804849435,0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark52(72.61545147496601,-1.7578508959303356E-8,0 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark52(72.63206791900765,-0.44558195570714076,0 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark52(72.65810754940242,-0.382677559839955,0 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark52(72.67118781874925,-0.8312518601350494,0 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark52(72.83537148608738,-0.07664156550203456,0 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark52(-72.83558872149234,-0.7969894698023677,1.0 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark52(72.84859115704177,-0.4817154954962932,0 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark52(72.85493744267961,-0.9963088000339084,0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark52(72.91667003887807,-0.4182329764256481,0 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark52(7.292408909356581,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark52(72.93985120709766,-1.352486102379582,0 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark52(7.303417829231483,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark52(7.305863879426133,-7.415191286684313E-9,0 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark52(73.09687213993847,-0.14801278774238824,0 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark52(73.20853447513588,-0.8225059896983659,0 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark52(7.321382390664269,-1.4994511989750685,0 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark52(73.22631592605924,-0.7256814201703075,0 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark52(73.32110822815856,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark52(73.44778372616116,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark52(-73.46640702808273,-0.17139091679011642,-1.0 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark52(7.349942209513529,-1.499999999999904,0 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark52(73.51511249541997,-3.180780847090109E-7,0 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark52(73.55568584149648,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark52(73.5915136249576,-1.2103159017459006,0 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark52(73.62370994225412,-0.21389584783901228,0 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark52(73.65578799971004,29.674440090399173,0 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark52(73.66842272221416,-0.8997763324338184,0 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark52(73.67949469036043,-1.8814125652459708E-8,0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark52(73.69894924217607,-1.28136469371623,0 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark52(73.70492846028188,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark52(73.72241685816485,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark52(73.7228221054338,-0.6768657848962363,0 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark52(73.75135876147786,-1.4687605839039322,0 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark52(73.9046376741114,-0.09651755841941889,0 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark52(73.94912320433342,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark52(73.95311950097064,-0.38869135273464916,0 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark52(73.96434759055327,-6.88046643161575E-9,0 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark52(73.97645608515884,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark52(7.398689862679902,20.44272517156527,47.83366000784858 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark52(74.07026453752292,-1.205037906353951,0 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark52(74.09437572925094,-2.6798111761661526E-9,0 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark52(74.11200524039323,-0.8064991560681714,0 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark52(74.14359767621272,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark52(74.15307857062987,-0.3005693125683405,0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark52(74.21991357983727,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark52(74.28871891619877,-1.3027311022231916,0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark52(74.291745037167,-1.3350778242355053,0 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark52(74.41298161712731,-0.04919378024618279,0 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark52(74.44196732898224,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark52(74.49211113878346,-0.06698157289487305,0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark52(74.54296767769067,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark52(74.56220473236112,-1.4559167030181997E-5,0 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark52(-74.58844748447495,-0.16021376288217892,56.99838319578416 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark52(74.60346050856404,-0.22313147848622594,0 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark52(74.6114071969292,-0.4108976507297015,0 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark52(74.70261110455851,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark52(74.70507375754624,-0.49310314862492,0 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark52(7.48489955350766,-0.35963810591627765,0 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark52(74.84943113571515,-1.2573383101864932,0 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark52(74.89458804493117,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark52(7.492457329732559,-1.3794841992329836E-7,0 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark52(74.97774717790934,-2.255122051557104E-6,0 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark52(74.9793674217992,-0.871889328573161,0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark52(75.01771543390315,-0.44807581820527353,0 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark52(75.0357622900764,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark52(75.18626122746832,-1.0992032593956282,0 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark52(75.19251849431102,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark52(75.24837347822825,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark52(7.527616173969804,-1.2020987853800205,0 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark52(75.28953597434085,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark52(75.31784378666697,-0.5128327753421369,0 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark52(75.31841837875041,-0.1670079968884095,0 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark52(75.33591740668501,-0.22519763367560547,0 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark52(7.5357098323216,-0.9882083493352987,0 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark52(75.37565114639311,-1.0449818359833944,0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark52(75.37706150894087,-0.7736619827476754,0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark52(75.38544119035424,-1.451621623530997,0 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark52(75.43233808052807,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark52(75.44147370888328,-0.39293874767357195,0 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark52(75.45235265570787,-0.08803083716879279,0 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark52(-75.45742791965175,-0.892994146868401,5.421010862427522E-20 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark52(75.49704797269038,-0.5979463665716906,0 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark52(75.50536009223276,-0.46064310361932015,0 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark52(75.51025365722614,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark52(75.52578663737427,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark52(75.53595212116687,-0.5622402166910376,0 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark52(75.59786059846067,-0.17306136927617644,0 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark52(75.60022380685265,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark52(75.62354596400928,-1.0232876645477518,0 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark52(75.6514854630536,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark52(75.76168116796055,99.83452015010917,21.432771809177396 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark52(75.76826401899035,-5.649157349125552E-9,0 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark52(75.79569971141461,-1.4829602777172113,0 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark52(75.83091563105607,-1.129194183466862E-15,0 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark52(75.87306720317176,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark52(75.9335764351475,-0.41459680970899626,0 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark52(75.94004226753324,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark52(75.98479013966686,-1.2736542676186806E-9,0 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark52(76.03700976684357,-1.4999726002452403,0 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark52(76.05430903459887,-1.4824926949859654,0 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark52(7.610357159522904,-0.14196572340352118,0 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark52(76.13101283054777,-0.7264911747597761,0 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark52(76.1459324099315,-0.1093546052963914,0 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark52(76.16364087023416,-0.8541816951837262,0 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark52(76.20238661249255,-0.6265160911097101,0 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark52(76.24977200959368,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark52(76.33482129867,-1.3797960778360903,0 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark52(76.4008255610112,-0.6966021956000716,0 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark52(-76.40714635219953,-0.7336631563074221,1.5910950782768367 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark52(76.50606675629567,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark52(76.5362223650457,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark52(76.55685976734686,-8.3733052196467E-6,0 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark52(76.5991617232844,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark52(76.60157255164746,-1.0925419871972384,0 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark52(76.62722363544451,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark52(76.70351231140572,-1.4103294239592223,0 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark52(76.70962588402493,-0.02544457337086365,0 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark52(76.74944406314967,-0.7967736137013901,0 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark52(76.75584349917057,-1.235527846708888,0 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark52(76.76047606261398,-0.9367544547246505,0 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark52(76.80925472014512,-0.6819894075579058,0 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark52(76.81165107983398,-1.1511750952209638,0 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark52(76.90461259435594,-0.0819655314240687,0 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark52(76.99959536325571,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark52(77.00694154949846,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark52(77.08172936305604,-1.0392471602909825,0 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark52(7.7082001783461465,-1.2263801464833364,0 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark52(77.13007079353414,-0.07843887437454977,0 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark52(77.13554998223151,-1.3553586472664434,0 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark52(77.18856110746793,-1.1771195301770625,0 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark52(77.26116235132083,-1.3653409017906097E-5,0 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark52(7.727706400447687,-0.23119629513237872,0 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark52(77.31589544405301,-1.2443341405235202,0 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark52(77.36445588353558,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark52(7.736692403639637,-0.41444106251430846,0 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark52(77.37598565383193,-0.3635015241079138,0 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark52(7.742849791997564,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark52(77.46208051346144,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark52(77.48053956895086,-0.8999683447931885,0 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark52(7.75199045768116,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark52(-77.52624658216503,-1.497328687979281,7.820637090558988E-149 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark52(77.54147556433594,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark52(77.57046946507705,-1.9493607545951598E-8,0 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark52(77.61533520538738,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark52(77.62610677434876,-0.43290773693434514,0 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark52(77.64610831680349,-0.48919179723814743,0 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark52(77.67203232948526,-0.7889056895407167,0 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark52(77.7590419513923,-0.019639496657634842,0 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark52(77.82815942443418,-1.042940784674741,0 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark52(77.82881261655658,-0.15431197519823314,0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark52(77.83235423788645,-0.46354751981760334,0 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark52(77.85314518002659,-1.1214818374620623E-8,0 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark52(77.9409209528076,-0.1793346311130648,0 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark52(77.94607887454197,-0.7222666448333683,0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark52(-78.0747808192299,-0.7701671730581694,0.9999999999999982 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark52(78.08866287786432,-1.3074814314258079,0 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark52(78.09626976128189,-0.1549934924820242,0 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark52(78.13774001256114,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark52(78.14218718646339,-1.357351354368646,0 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark52(78.17166552703617,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark52(78.20389255743792,-1.2851957456633887,0 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark52(-78.20552303649053,-1.0868509484459405,100.0 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark52(7.822737010593045,-1.3102332369943577,0 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark52(78.2583644541968,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark52(78.27985463782875,-1.1955412768395872,0 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark52(78.33629519850051,-0.9922693207467234,0 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark52(78.33783559943447,-0.7203430398039501,0 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark52(78.35192863598121,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark52(7.840772779676058,-1.2434806798691411,0 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark52(78.40838740374804,-0.9872900802012246,0 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark52(78.41712435970666,-0.8646269839137262,0 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark52(78.43952167650198,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark52(78.53936934806202,-0.2873606268501032,0 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark52(78.56208244081924,-0.19535509101218906,0 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark52(78.57473875562181,-0.8794936352535956,0 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark52(78.61153572155052,-0.36508558480964126,0 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark52(78.66067169886227,-0.3500687495217196,0 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark52(78.82270685662846,-0.7063452547196825,0 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark52(78.82983747144777,-1.3994929216591743,0 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark52(7.883969896998394,-0.3603023142266104,0 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark52(78.88935924625903,-0.5667980337806569,0 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark52(78.91846124549144,-1.0916112936356228,0 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark52(78.9530673248497,-0.492262871489181,0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark52(78.96688704870436,-0.7911699005264552,0 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark52(79.0163262989069,-1.4661219632899654,0 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark52(79.04862674450321,-1.3337933763016165,0 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark52(79.05665409359571,-0.08477921161678592,0 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark52(79.06038705356085,-1.1557652061308792,0 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark52(79.08135417422946,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark52(79.08397112595787,-0.0991786839367782,0 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark52(79.09979501288795,-1.499994791770852,0 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark52(79.12028440322615,-0.5955686365839095,0 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark52(-79.17586825120071,-1.4479652103384737,-61.212511642292085 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark52(79.18957636795221,-0.48166626298715753,0 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark52(79.25755756508471,-0.2725514777708895,0 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark52(79.28695773071648,-0.09255329625292763,0 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark52(79.28993181249987,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark52(79.31006361790494,-0.2972161964657888,0 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark52(79.39067517718622,-1.0030732822992843,0 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark52(79.40551805727509,-0.9792494585942872,0 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark52(79.41111258427524,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark52(79.4216121587115,-0.04475029312834777,0 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark52(-79.48960568176665,-0.21821543672645305,-1.0 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark52(79.49184592095847,-0.9521087135263029,0 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark52(79.50353425835327,-0.4842773101918918,0 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark52(-79.5251294729535,-0.45472468382920095,-0.9999999999996447 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark52(7.954856408807669,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark52(79.56134981593635,-0.45599633402446216,0 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark52(79.58296345614596,-0.7439778604973533,0 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark52(79.60437263094698,-0.7387969663797422,0 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark52(79.60674116057515,-1.499999999999992,0 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark52(79.65101950935801,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark52(79.69727172498989,-0.48316971537555276,0 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark52(79.75373330834813,-0.7833864809357716,0 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark52(79.77555195294644,-1.4958847729791949,0 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark52(79.85751323907617,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark52(79.8619036912979,-0.6736296300736943,0 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark52(7.987522519515958,-0.1963279410190984,0 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark52(79.8950639933357,-0.22419762540475707,0 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark52(79.90742086971909,-0.0748471390559653,0 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark52(79.91441783091852,-1.229614543394547,0 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark52(79.94152385912017,-0.7087812052697914,0 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark52(79.94576418416167,-0.2706940940583342,0 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark52(79.96142288336864,-1.3369194310118668,0 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark52(79.99109032404161,-0.9493201533202447,0 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark52(80.03297323989894,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark52(80.07231672548608,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark52(80.10972397716057,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark52(80.12577286383582,-1.1444971597801104,0 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark52(80.19907579070842,-0.066352483268291,0 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark52(80.22803155167827,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark52(80.24312915700102,-1.307412790589392,0 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark52(80.24575613946399,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark52(80.31139821157117,-1.4550302083745539,0 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark52(80.33279662434168,-1.4602088506362065,0 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark52(80.3607226980441,-0.42006081944735585,0 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark52(80.40715481009593,-0.5528070681137186,0 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark52(80.44994644977996,-0.8490752460019335,0 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark52(-80.47768584986197,73.90051954837188,-98.71342970971291 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark52(80.49089690580865,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark52(80.51018245519421,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark52(80.52345064856345,-0.9913887360721105,0 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark52(80.60029235731679,-1.0697123338878365,0 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark52(80.80222733425994,-5.20412956108378E-9,0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark52(80.82457770919419,-1.2351891740976555,0 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark52(80.85766361905306,-0.6216403089220277,0 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark52(80.86400809964877,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark52(80.8917090054203,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark52(80.9361119567603,-1.4949976258741676E-15,0 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark52(81.02409497994714,-0.2493492314710366,0 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark52(81.04846061124906,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark52(8.105643261770041,-0.501072844567204,0 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark52(81.06286072206117,-1.293949693646784,0 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark52(81.07382158645277,-0.6169911605577596,0 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark52(81.16150433962733,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark52(81.19801700582957,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark52(81.22808084626536,-1.4323038259080363,0 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark52(81.25169272677316,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark52(81.28133168682234,-1.4999999999999751,0 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark52(8.12850313442138,-0.6436878343382735,0 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark52(81.34370201703209,-1.499999999999961,0 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark52(81.46728079805368,-0.9316863315308014,0 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark52(81.50119463394887,-1.4456039102474056,0 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark52(81.5229527138246,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark52(81.55558180612886,-0.09439536842446182,0 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark52(81.57521954404137,-0.6904018883051481,0 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark52(81.72801786824257,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark52(81.73697827238132,-0.2982471119270471,0 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark52(81.79284664905998,-0.9768738922571609,0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark52(-81.80855869810532,-0.8254657593614197,0.0 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark52(81.81330189211064,-0.571520364656922,0 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark52(81.8291186569877,-1.0355350251127964E-8,0 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark52(81.8631577482448,-0.3336502142851785,0 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark52(8.187646246141531,-0.9062792016193459,0 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark52(81.97409374455717,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark52(8.200813408015549,-0.8847571405778956,0 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark52(82.04876819029938,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark52(82.05871454501369,-0.08822852561845451,0 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark52(82.05935994692244,-0.7893625593249713,0 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark52(82.10023877160708,-1.4413376135931344,0 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark52(82.10318186337713,-0.21113464980552799,0 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark52(82.1334827548896,-0.06170225289474751,0 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark52(8.220798048735745,-0.012707730102520909,0 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark52(8.221955884586734,-0.7813092916831437,0 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark52(82.22363361844467,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark52(-82.27859808476086,16.09440848394523,74.69477911287458 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark52(82.30226208889633,-0.5007712710686381,0 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark52(82.30294074694301,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark52(82.30494429305091,-0.13270037598182594,0 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark52(82.31158034225058,-1.3346933952811355,0 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark52(82.31525816095369,-4.138952183717351E-9,0 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark52(8.234285225453334,-1.3339493716317352,0 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark52(8.238800078342567,-0.4308367118609535,0 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark52(82.39353519218443,-1.072874892647647,0 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark52(82.44861048823465,-3.8738087952648913E-7,0 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark52(82.47751557082783,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark52(82.47927658501342,-0.721663244609509,0 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark52(82.49203836108791,-0.43604786257967776,0 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark52(82.62256406846691,-0.5802896791146637,0 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark52(82.62362644588008,-1.4999999999321558,0 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark52(8.26399816037231,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark52(82.65576546516112,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark52(-8.26583546426265,-1.2888424053758567,-1.0 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark52(82.70018136795122,-0.26949909598075017,0 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark52(82.70264024174264,-0.22902620535344925,0 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark52(82.70880145666592,-1.2875683574581416,0 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark52(82.7230869060482,-1.0381029525169594,0 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark52(82.80021357153387,-0.45664019271707923,0 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark52(8.290108247856637,-1.15183869705054,0 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark52(82.9140843428643,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark52(82.95424024206005,-1.1648071707962853,0 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark52(82.98285068869723,-0.022247609595042128,0 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark52(83.01825183681632,-0.6170492847265514,0 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark52(83.01949184224239,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark52(83.0607595907507,-0.792096485126466,0 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark52(83.09635938465135,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark52(83.10885271419764,-0.03980919118297144,0 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark52(83.12206491910413,-1.3925413591461773,0 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark52(83.1995271269623,-1.1069021559222563,0 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark52(83.26761744822664,-0.3343298610510299,0 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark52(83.31318112969171,-0.5959261805712117,0 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark52(83.3214574889494,-1.4999999999394331,0 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark52(83.4239952897243,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark52(83.54557942254402,-0.5805908748952024,0 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark52(83.58273081142619,-1.121673208971747,0 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark52(83.64773925825429,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark52(83.66434736718111,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark52(83.68756254825936,-1.3887601484052539,0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark52(83.7085407013407,-0.6868866906920545,0 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark52(83.76174596726764,-0.26297237886305425,0 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark52(83.78121425338549,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark52(83.85231373531799,-0.0030424025673184583,0 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark52(83.94375471988059,-1.1382869936412254,0 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark52(83.96473003730947,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark52(83.97738902540294,-0.6368599933460933,0 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark52(84.08745353249282,-0.9486200636310116,0 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark52(84.13110303387592,-0.9790611374107154,0 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark52(84.17264941745671,-0.7044186281552011,0 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark52(84.18781726402707,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark52(84.25877008891257,-1.475962758133307,0 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark52(84.32464636108017,-0.026812856800745848,0 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark52(84.35358324762186,-1.4819768404801363,0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark52(84.36130775932342,-0.06336678474152357,0 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark52(8.438586517541523,-0.5032074953800976,0 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark52(84.41559658267471,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark52(84.42725396993694,-0.2709483823455061,0 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark52(84.45118977390497,-0.07936633539410934,0 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark52(8.447473088868318,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark52(84.51200845494286,-0.11383600285697008,0 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark52(84.53101362558809,-1.4114508461340065,0 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark52(84.53212518497023,-0.4937023311696429,0 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark52(8.453651733950423,-0.1535711509196659,0 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark52(84.58307192844183,-1.0364514079589897,0 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark52(84.58523664504305,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark52(84.59174188269691,-1.1560172632300976,0 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark52(84.60891674124366,-0.6956242740270902,0 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark52(84.62359808333204,-4.049735112166209E-8,0 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark52(84.62921420391575,-0.49949493027847325,0 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark52(84.64515318471922,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark52(8.469323112054168,-1.3017779073965832,0 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark52(84.73476599910182,-0.09052734020518471,0 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark52(84.73477207902451,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark52(84.78095287999247,-38.37070479200864,75.75918352082496 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark52(84.81339243153246,-0.526570862272326,0 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark52(84.83964789458264,-0.4059785207428881,0 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark52(8.48636279213191,-0.020104342364263776,0 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark52(84.92978231045512,-1.1207026846394044,0 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark52(84.96114300894902,-0.7365804827087743,0 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark52(85.00289941935786,-0.03736488157102791,0 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark52(85.00712918057519,-0.2261843863689279,0 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark52(85.00880825176824,-0.4493236844074521,0 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark52(85.15138942152095,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark52(8.519719617337202,-1.4934805606415493,0 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark52(85.2396482864074,-0.8276366797024943,0 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark52(85.3652256307164,-0.9413165970550103,0 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark52(85.41434738705235,-0.11652876162194281,0 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark52(85.42369656869879,-1.1510545689069815,0 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark52(85.44334536013743,-0.7288702255711504,0 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark52(85.46167949583244,-0.4002088067392644,0 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark52(85.49934142304598,-1.3679341022994984,0 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark52(85.56106441009894,-0.6442956481308642,0 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark52(-85.61171554781374,-50.62453839309819,-33.904368884012825 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark52(85.61591702368696,-1.1243504345274644,0 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark52(85.64226178969679,-1.255913716389711,0 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark52(8.571015944583625,-0.787379349503662,0 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark52(8.576927406113597,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark52(8.586163374660671,-1.2605460789093272,0 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark52(85.86339337979366,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark52(85.86638865169215,-1.3643529693244503,0 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark52(85.8765336292212,-1.4411655525669187,0 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark52(85.88347169070157,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark52(85.92127956731312,-0.8039839377614778,0 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark52(85.9374732422068,-0.13242778073096062,0 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark52(85.94645871696956,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark52(85.97651003624617,-0.4194873486394708,0 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark52(85.98243234145221,-0.18000134494264586,0 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark52(86.04403170528704,-0.4695678462794497,0 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark52(86.05718695139598,-0.2969113659452489,0 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark52(86.0665746604576,-0.929466422992332,0 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark52(86.09344150429179,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark52(86.14196213463018,-0.029201454584127262,0 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark52(8.614226798321994,-0.20175960782868785,0 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark52(86.1593380224929,-1.4348723679003927,0 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark52(86.17846272214723,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark52(8.625020289085867,-0.9266498514451484,0 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark52(86.3039315485504,-0.7192268413278988,0 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark52(-86.31688461946558,42.76013935706325,60.136504696067675 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark52(86.32068148618936,-1.0579801850954595,0 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark52(86.35961435230152,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark52(8.637040585948313,-0.8016665132840615,0 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark52(86.40091532988819,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark52(86.4439771936751,-0.4869794544985808,0 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark52(86.4840343486442,-0.5347208742641385,0 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark52(86.48537880604337,-7.467996769013033E-9,0 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark52(86.4888015789422,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark52(86.5345297073211,-1.3892831330350404,0 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark52(86.54915001195013,-0.015933194851866783,0 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark52(86.7226773423729,-1.3321529150731952,0 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark52(86.80471674564095,-8.510742943102475E-15,0 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark52(86.82366919951234,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark52(86.86906665936766,-0.24190604313264652,0 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark52(86.91604176284214,-0.18980095380248851,0 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark52(8.6916947597938E-311,-0.018455111134938917,0 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark52(86.98937107102921,-0.30794079365375393,0 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark52(-87.0412017805836,-1.4999999999999991,0.9999999999999991 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark52(87.06972111370425,-1.1871807083099242,0 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark52(87.1088920863258,-1.2591725650180194,0 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark52(87.16071342565536,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark52(87.25786564516665,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark52(87.28480075289409,-0.23942425371083242,0 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark52(-87.28772336745003,-0.8628445630667301,93.03224136618384 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark52(87.36767897761092,-0.03927394860839073,0 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark52(87.46513633171665,-1.4585390790786696,0 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark52(87.46903691231174,-1.277985901384847,0 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark52(87.46963916605321,-0.924699860144214,0 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark52(87.48553215585738,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark52(87.48683090772455,-1.4814187972145074,0 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark52(87.48772881751671,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark52(87.54392945018208,-0.11571987279472751,0 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark52(87.58456966730591,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark52(-87.59512778587998,-0.5382739107403198,96.58204687260641 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark52(87.61119980772477,-0.09243061960163068,0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark52(87.64957190589524,-1.4264277068556632,0 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark52(87.67397929677108,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark52(87.70342075292524,-0.7251339165058481,0 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark52(87.70679146965114,-1.0816244301979605,0 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark52(87.71900324929618,-0.2572086509422995,0 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark52(87.7761241987983,-0.6642304904238756,0 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark52(87.78539984132928,-0.48483814440378126,0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark52(87.79702411611657,-0.42283284086285433,0 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark52(87.84097770224611,-0.17459431780236767,0 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark52(-87.84988567548517,-1.4700452632873153,-2453.98691100958 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark52(87.86870770122218,-1.2430069248114872,0 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark52(8.797164840029238,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark52(88.00194780597974,-0.05774212386715949,0 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark52(88.0051526506576,-0.7150568546329628,0 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark52(88.03128092436734,-0.7915167951808877,0 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark52(88.09998206857145,-0.8534258539298709,0 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark52(-88.10992889947798,-1.4698567347093048,-0.4760344501802505 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark52(88.13026725941194,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark52(88.16550294966717,-0.3171459041547493,0 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark52(88.18943242940964,-1.462533450846041,0 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark52(88.23957958155334,-0.16549401464128072,0 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark52(88.31042313952753,-0.8798826709380836,0 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark52(88.31550275759713,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark52(88.33496827069095,-0.5911261595071551,0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark52(8.833554074474698,-0.30759765798214406,0 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark52(88.37362654136075,-1.127307652528419,0 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark52(88.48684195225127,-0.7819775730831418,0 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark52(-88.5377160806355,-0.0014789965553537662,0.9999999999999996 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark52(88.56278378755906,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark52(88.56471398773958,-0.3365335291935945,0 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark52(88.67424879552719,-0.5931059211594514,0 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark52(88.68878034537732,-0.5244484096974844,0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark52(88.69193323802105,-0.16975976967626782,0 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark52(88.70404722448376,-1.4911018390723996,0 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark52(8.881784197001252E-16,-1.2916485425001611,0 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark52(88.82614229834337,-0.563285589985469,0 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark52(88.86176746556569,-1.4268913772736216,0 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark52(88.9204513709335,-1.2973019928471317,0 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark52(89.05792399125869,-0.07342990014424788,0 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark52(89.09057369770622,-0.7349776645501258,0 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark52(89.15553547532683,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark52(89.15974479436287,-0.5087822439841574,0 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark52(89.16418035573938,-0.017057653829432473,0 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark52(89.18300805871391,-1.4278882132568658,0 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark52(89.18782932519439,-9.563194037749544E-10,0 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark52(89.2992737713682,-0.2989497415033594,0 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark52(8.930355881270188,-1.2937565084542189,0 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark52(89.32524967349975,-0.0021987805271478397,0 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark52(-89.39097703631185,-1.3939172551901322,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark52(89.39842652261424,-0.5634682480278173,0 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark52(89.45608704649138,-0.035442592531147454,0 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark52(8.947032564638263,-0.26598227892269577,0 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark52(89.47300702092039,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark52(89.47421366753491,-0.6010319610900434,0 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark52(89.495304891261,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark52(89.57419212885517,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark52(89.62624635432584,-0.31908653775872153,0 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark52(89.67758695517387,-0.6141658763439657,0 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark52(89.69152044977551,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark52(89.7295585909979,-0.042107366791753364,0 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark52(89.7476128447291,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark52(89.78838815757118,-1.4007788425969072,0 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark52(89.81600289433473,-0.9495410018212948,0 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark52(89.84751326614656,-0.4315638398186348,0 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark52(89.9299267316164,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark52(89.95036602131944,-0.45305594702941526,0 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark52(90.13419073445684,-1.188437203072823,0 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark52(9.016312839017004,-0.5732489254497608,0 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark52(90.16677410225203,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark52(90.17933949498311,-0.7764484245726866,0 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark52(90.22604603035197,-0.5140076457410299,0 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark52(90.25128338283544,-4.820522727784475E-9,0 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark52(90.2866255239668,-1.2507326036156632,0 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark52(90.30224115763278,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark52(9.037188879396197,-0.009580572879482219,0 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark52(90.40825876289907,-0.21007661304817304,0 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark52(90.41257276448457,-0.28360552185804117,0 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark52(90.41825625825783,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark52(90.44679549770376,-0.3997376146785143,0 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark52(90.51099509104446,-8.083369312370945E-7,0 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark52(90.51310578139336,-0.14056173306746889,0 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark52(90.58880883808737,-0.0768742573186394,0 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark52(90.60645322850431,-0.3667242687629617,0 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark52(9.067111850851628,-0.41384276270507137,0 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark52(90.70772782775188,-1.089012302497343,0 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark52(9.07565869301537,-0.32318201237428923,0 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark52(90.77225954782307,-0.2126840881462579,0 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark52(9.090578644616386,-0.8070437420775018,0 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark52(9.092376089482125,-0.36780193432800234,0 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark52(90.94942546131679,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark52(90.98044668780629,-0.22431099781955033,0 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark52(91.02307829655481,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark52(91.02888671050846,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark52(91.05454299464978,-0.9414929861285088,0 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark52(-91.06779165909728,-8.881784197001252E-16,0.43908660287642753 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark52(91.19269362903611,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark52(-9.121860067584027,-1.6780440166697494E-8,-1.000000014919069 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark52(91.31639150556609,-1.467225214183914,0 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark52(91.35952654176077,-0.77801129582733,0 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark52(91.36489976092054,-1.0752246302522934,0 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark52(91.366198314929,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark52(91.37050663607789,-0.37374515139579145,0 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark52(91.47335167641423,-1.4999999999706355,0 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark52(91.48370601630941,-0.017196399656902193,0 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark52(91.4905986475446,-0.6495867932155805,0 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark52(91.56909029583193,-1.2681511208928784,0 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark52(91.61668733068797,-1.015378186187912,0 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark52(91.6510006912842,-0.8877252043769959,0 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark52(91.65993791369002,-0.41419762962212214,0 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark52(91.75937856901112,-0.8274227096616045,0 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark52(91.7676483716005,-0.8586669468529986,0 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark52(91.77594977946447,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark52(91.77866474960038,-1.1592770874633862,0 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark52(91.78622467001148,-0.3004126770456135,0 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark52(91.79919237205581,-0.9740115465294703,0 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark52(91.80092993694095,-0.03270912010736993,0 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark52(9.180228903283444E-16,-1.0349802201307343,0.20462962166280524 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark52(91.82011252141163,-2.6937590531469933E-7,0 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark52(91.84905879038311,-0.41607639667011215,0 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark52(91.877054373767,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark52(91.88561782723994,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark52(91.8910852930976,-1.02860237649341,0 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark52(91.92110789441153,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark52(91.98353216894797,-1.1301780885550592,0 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark52(9.19860806065856,-7.041429787401867E-8,0 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark52(91.99323359202174,-1.3255419851871793,0 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark52(92.00728760728245,-0.5037914879177929,0 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark52(92.1298562822638,-0.9282015943328421,0 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark52(-92.14631192371678,-1.3625693136994244,91.11838880472482 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark52(92.15263302854294,-0.2264008114259779,0 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark52(92.15717121707269,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark52(92.20449082600862,-0.740767693097939,0 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark52(92.23784798616549,-0.9745583203414583,0 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark52(9.22641382375139,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark52(92.27353041185992,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark52(92.3853023190157,-0.4186126046648089,0 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark52(92.46310352054388,-0.09654199455280654,0 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark52(92.53353979999872,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark52(9.25478083286169,-1.4999999999127025,0 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark52(92.58015132724887,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark52(92.6344424758127,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark52(92.64632830284916,-0.6207482576321945,0 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark52(92.77491386955359,-0.027478859649460452,0 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark52(-9.2781300105329,-0.4543475973418054,1.0 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark52(92.83189943283807,-0.6588604449419371,0 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark52(92.83368899732417,-0.23528740859899244,0 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark52(92.85340016895853,-1.102333406278601,0 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark52(92.89499055166648,-0.24641203092496217,0 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark52(9.31371892933997,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark52(93.15163965213476,-0.29216341816608393,0 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark52(93.16007388663027,-1.2449530622234413,0 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark52(93.2589861090849,-0.8000895446158651,0 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark52(93.26010785212773,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark52(93.31735884929842,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark52(93.32437880550569,-0.7735196707071541,0 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark52(93.32505223152185,-0.29636963455573095,0 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark52(93.33176052177016,-1.70465657101884E-15,0 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark52(93.36543253838553,-0.35466208613499894,0 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark52(93.36696559399806,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark52(93.38104077804888,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark52(93.54329552463119,-1.194670630841216,0 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark52(93.55147929076927,-0.15090615829242893,0 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark52(93.57759082303991,-1.4794781343869046,0 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark52(93.63201268158903,-0.4108595232364891,0 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark52(93.64774319873695,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark52(-93.7202067440242,-1.4999999999999991,-54.821155194992194 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark52(9.377374740360398,-0.0014967644491586966,0 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark52(93.77456243597734,-0.1921199386411292,0 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark52(93.85968886833004,-1.1648820416871075,0 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark52(93.86566223959102,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark52(93.9035979699961,-0.6580237790043526,0 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark52(93.93488130206065,-0.7503349222007643,0 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark52(93.95455305614493,-0.56011141166594,0 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark52(9.397230834756812,-0.4046698968785023,0 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark52(93.97892158683956,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark52(94.01494390746723,-0.27380518699000156,0 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark52(94.01542198153581,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark52(94.23982769118726,-0.5024565929782023,0 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark52(94.354531806517,-0.1821386176356583,0 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark52(94.4168707177775,-1.1253527091665978,0 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark52(94.50377044677506,-0.6719270061705496,0 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark52(94.51303435755801,-1.4485147107314709,0 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark52(94.59041543001959,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark52(94.59662754298148,-1.33863917882932,0 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark52(94.68218514565692,-0.2987816943497563,0 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark52(94.70146752055027,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark52(9.478681021915136,-1.0429232072822288,0 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark52(94.87377489840131,-0.056916352429336126,0 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark52(94.89240055035236,-0.5498345134351308,0 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark52(94.90011370503197,-0.059947386685855975,0 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark52(95.08130590908311,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark52(95.10655557494829,-0.5793121637713163,0 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark52(95.13943643423477,-1.2463860679180359,0 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark52(9.515993854472967,-0.7850350621190341,0 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark52(95.16018429705042,-0.37959815726341084,0 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark52(95.21482380995235,-0.23854672218119788,0 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark52(9.52529334110497,-1.462573606583411,0 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark52(95.26038302659745,-1.4999999999998899,0 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark52(95.2655741192077,-0.8240583365832759,0 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark52(95.29677881947919,-1.0393200867667562,0 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark52(95.34543930715822,-1.0818218953981056,0 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark52(95.42030817579612,-1.1992725114153586,0 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark52(95.45461461619277,-0.6811545455559376,0 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark52(95.48340703072398,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark52(9.550759676775819,-0.7037056176042378,0 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark52(95.57576910545083,-0.4312612952905104,0 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark52(95.64409682338527,-0.39761777187809244,0 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark52(95.66345516110327,-0.08441921325137569,0 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark52(95.73158862259032,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark52(95.73827655498945,-0.8640721944282319,0 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark52(95.80173093562607,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark52(95.83220360432603,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark52(95.8452251633071,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark52(9.586865801750701,-1.499678185997877,0 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark52(95.9063622936992,-0.22020115615399383,0 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark52(95.92997549128415,-0.79247094398667,0 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark52(95.95195980685207,-0.1705350967312107,0 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark52(96.01904098276071,-1.396080395389319,0 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark52(9.607187303303675,-1.4671626300776963,0 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark52(9.608419644583847,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark52(96.10491656492067,-0.05226656961514209,0 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark52(96.18408809160937,-0.638661334042439,0 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark52(96.20806181503772,-0.4554603928559544,0 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark52(9.623588526057238,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark52(96.30780666667911,-0.357473021510299,0 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark52(9.635203626928881,-4.136655164970817E-9,0 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark52(96.39505692558811,-1.1356013457354237,0 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark52(96.48332021041911,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark52(96.55943329836529,-1.1121555933810185,0 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark52(96.56368827846872,-5.233536826220544E-10,0 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark52(96.58155357824921,-0.43536411383458073,0 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark52(96.59735136306034,-0.5967980328753839,0 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark52(96.61219514409868,-0.6128532588486642,0 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark52(96.64495277466945,-0.5369248847895687,0 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark52(-96.66663800022073,-1.4880802660542098,-0.027524630967102767 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark52(96.72965148830971,-1.2131700303849016,0 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark52(96.77171281122213,-0.5218609598352488,0 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark52(96.79563934478261,-0.317071193402664,0 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark52(96.88150690065706,-0.816160479925852,0 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark52(-96.96440233448638,-0.7129258889576375,0.3291271978037913 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark52(9.701060709052776,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark52(97.02232226047437,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark52(9.70816032729735,-1.2741901449309676,0 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark52(97.09693352462781,-0.21749948746057157,0 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark52(97.10896679919983,-1.0484591206229643,0 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark52(97.16361117244418,-1.1545738622871955,0 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark52(97.17149098736806,-1.280260408007737,0 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark52(9.721882115982481,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark52(97.29364277937151,-0.758903214075751,0 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark52(97.32975562186385,-1.3661385102954284,0 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark52(9.737406396987055,-1.4835428946081919,0 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark52(97.54610313186934,-1.2060678296301708,0 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark52(97.6224580272335,-0.838641158032388,0 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark52(97.65800788387696,-0.45852012869313796,0 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark52(97.67865576007301,-0.9130212246194489,0 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark52(97.68106142207901,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark52(97.68219102730436,-0.2179019000306397,0 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark52(97.75136435385926,-0.4469105775679232,0 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark52(97.75233387719877,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark52(97.77351966652745,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark52(97.7945004091981,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark52(97.85849420872964,-0.8118395936307241,0 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark52(97.85973699601269,-1.0657402614964173,0 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark52(97.8931237045677,-1.1854566805966158,0 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark52(97.94552082624818,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark52(97.98552761578085,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark52(98.00912700807928,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark52(98.02176787801761,-1.3904793350327367,0 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark52(9.8062182318549,-0.3825829867218715,0 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark52(98.1449259012542,-1.4086136219397591,0 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark52(98.15647883699475,-1.1490574309781711,0 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark52(9.816312731765592,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark52(98.28627754459062,-1.4999999903342378,0 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark52(9.83210696024021,-0.3218096384174203,0 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark52(98.32144723495036,-0.27876435109367426,0 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark52(98.3333995203697,-1.3877787807814457E-17,0 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark52(98.38889371197521,-1.3406754537720502,0 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark52(98.42736635965903,-1.0091266698553936,0 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark52(98.48606854473178,-4.5824322326231067E-10,0 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark52(98.58523271249118,-0.21319652793926802,0 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark52(98.65211979078126,-1.0989361042666927,0 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark52(98.66678626894301,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark52(98.70095095048589,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark52(98.776544270588,-0.1831653913917819,0 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark52(98.81817926203053,-1.0310093859922276,0 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark52(98.8477829942216,-1.412622335507689,0 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark52(98.89497446469194,-0.3162101858774644,0 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark52(98.91737387707676,-0.06876207723911487,0 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark52(9.892031269478707,-1.0977455108404133,0 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark52(98.9210371633196,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark52(98.94876871842465,-0.19179857107909193,0 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark52(9.901114813083737,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark52(99.0246317867857,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark52(99.04911053643454,-1.289454015395687,0 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark52(-99.0708624388243,-0.9591027654169094,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark52(99.09232905133183,-0.2020252392385089,0 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark52(99.18154648511205,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark52(99.19836718572316,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark52(99.3040843198489,-1.0015504225420757,0 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark52(99.32170728455031,-0.5559866275546224,0 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark52(99.36399532419478,-0.2123735360567196,0 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark52(99.37316546240737,-0.22381768693637022,0 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark52(99.38869229457313,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark52(99.5052122784738,-0.6350797519208076,0 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark52(9.95248775058866,-0.9267723439303592,0 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark52(99.55989407577277,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark52(99.60036238259096,-0.06874463101145523,0 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark52(99.61017256844823,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark52(99.6272651753712,-1.469076275493066,0 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark52(9.966321660741656,-0.4826116396512896,0 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark52(99.70127718061619,-0.297836291331361,0 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark52(99.82270705567686,-0.8159347158949828,0 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark52(99.86845968492005,-0.24887761233860317,0 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark52(9.98721509357641,-0.2820898482462656,0 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark52(99.93009113354518,-1.3634797457394683,0 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark52(99.98780293158364,-84.41563068291056,-99.42764287235875 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark52(-99.99999999993773,-1.4999999998760547,-51.24390575866049 ) ;
  }
}
