import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
//    0.6780120990395335;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(-0.0010537389183074158,-218.1831214896473,-8.501400128908045 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(-0.001085765330237176,-47.7226021274378,-1.250312335071337 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark05(-0.0011197353506124598,-0.2983905184088226,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark05(-0.0011898452273247165,6.776263578034403E-21,1.5707963267948966 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark05(-0.0012284764194708774,-22.05405771780109,-60.92871951514718 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark05(-0.0012978016054265207,-1.5707963267948966,2332.0724235453727 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark05(-0.0013310643682954558,-22.43637490627907,-1.3172498091323916 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark05(-0.0013315268825179916,-4.3368086899420177E-19,-0.10681806916013038 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark05(-0.0014064783943799244,-0.04244230332391547,0.0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark05(-0.0015577482712471776,-1.5707963267948961,-6.283185161168858 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark05(-0.001576414528056744,-0.0028949570764065847,-50.036672757425826 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark05(-0.0015925329650878783,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark05(-0.00168197678735201,-6.0834930121445114E-210,31.472142101974722 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark05(-0.0016857875226806032,-98.79164258039485,-0.1574311947292386 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark05(-0.0019270156634214257,-0.6756069815157915,-75.37477774561263 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark05(-0.0019349571987852757,-0.6093585296615819,1.7763151738657645E-15 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark05(-0.001958800782243482,-1.3431077906050015,-55.35837750782975 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark05(-0.001962638867410512,2.7755575615628914E-17,-57.29989727249839 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark05(-0.0020025161079167964,-1.5707963267949054,1.5707963267948966 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark05(-0.002050897150523874,-1.3623128144000587,-8.103981634347864 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark05(-0.00217926942628749,-1.5643324085617207,-42.91121457023715 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark05(-0.0022221036240442998,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark05(-0.002239220135510724,-9.472882385569893,7.853981633974583 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark05(-0.0022881708381596866,-1.5707963267948966,-53.63780907685823 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark05(-0.002538616079700529,3.1494051552711118,1.5707963267948966 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark05(-0.0025524406016869208,-0.4599919273732871,0.4318996192395721 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark05(-0.002586536355967395,-1.5707963267948966,94.73545236836486 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark05(-0.002619505492972165,-1.5707963267948966,4.712388980411659 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark05(-0.002638692857101771,-1.1705967120081533,50.693304451934324 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark05(-0.002677984574929737,-1.5707963267948966,28.027262160223927 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark05(-0.0026805198913394113,-1.5707963267949,1173.6270519716359 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark05(-0.002884271614551112,-0.0233491817993822,13.952178048597673 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark05(-0.0029170081967554297,-15.780449033007821,-8.571450032597877 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark05(-0.002970491920559981,-1.5707963267948963,-86.49949690481434 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark05(-0.0031262247563354816,-67.54210406052108,-29.724971190826043 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark05(-0.003152218681058723,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark05(-0.0031627037308362706,-4.396524564492837,-1.5211737626895383 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark05(-0.00320383040153391,-66.96412896205655,90.0704954602577 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark05(-0.0032910640121232015,-4.3368086899420177E-19,71.66309979912214 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark05(-0.0033528319939098855,-1.5707963267948966,37.95434429303078 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark05(-0.003363158880657481,-1.5707963267948966,-40.49901384421238 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark05(-0.0037248416531445263,-1.5707963267948966,-53.72940406328617 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark05(-0.0037492752362788245,0.01728606268059501,-60.88178549282929 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark05(-0.0038911943605068324,-1.5707963267948966,-46.60205529066241 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark05(-0.0039042387785812593,-1.5707963267948966,-0.5750342682639094 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark05(-0.003968004632170757,-0.04007702995928569,6.314436490852145 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark05(-0.004207263050068834,-60.41291680377976,-3.14940515371709 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark05(-0.004215742383606517,-0.10163487859131039,29.33114327808362 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark05(-0.004500254601174764,-0.5931044560225267,-49.978773563752576 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark05(-0.004519996067858058,-1.5707963267948966,79.73261427652173 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark05(-0.004665544207638099,-1.5707963267948966,-57.37655728159795 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark05(-0.004768803374677726,-98.30622844882816,-66.19227112547478 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark05(-0.004816721829315065,-67.2021370065909,-1.5707963267948966 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark05(-0.004820226052914389,-66.4183103617996,7.853981635229362 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark05(-0.004963552806503253,-0.14928589334664263,-2.0790819531289798E-112 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark05(-0.005295461399386561,0.03627731671411341,-79.00018076474358 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark05(-0.005306572392791642,-98.44093959473801,0.6429962567229195 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark05(-0.005346793082745202,-0.27856664404960085,-91.71851198075375 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark05(0.0,-0.5594075941440987,32.52189994114873 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark05(-0.006189291895852933,-1.5707963267948932,-0.24815444390185348 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark05(-0.006741822827772331,-15.798024613685484,41.25280424651194 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark05(-0.006940532045979817,-1.5707963267948966,83.27014017366817 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark05(-0.007134841859836968,-1.5707963267948966,-1.5707963267938303 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark05(-0.007194213493157076,-91.35781947544956,-122.86981113934729 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark05(-0.007229951271790409,1.2647933579161117,0.14341394222322015 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark05(-0.007382662040144492,-3.556413999176124E-161,42.56835544824755 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark05(-0.007558553788880568,-1.2268116486889207,70.70296322932302 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark05(-0.007692595844651873,-135.30025188202106,-9.54152800135943 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark05(-0.00775043957903871,-3.4985700830140725,1.5707963267948948 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark05(-0.007808090863468289,-1.4166914484477937,16.86188059831706 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark05(-0.008048005703243162,-1.5707963267948966,-77.6427516516097 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark05(-0.008114330131088594,-1.5707963267948966,8.139395012305044 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark05(-0.008120314886160385,-0.24849060801287154,19.433781451241302 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark05(-0.008172122605607714,-41.948865885039325,-8.853981626957298 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark05(-0.008318601970849215,-17.25543643726934,-42.88946804352564 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark05(-0.008540986892154856,-98.94597332126499,-58.319364194398204 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark05(-0.008585056877758873,-47.12388980384704,-27.475098549039416 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark05(-0.008617053511833252,-1.5507389031693644,-1.472339146670866 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark05(-0.00913001171535864,-1.5707963267948966,739.9619425765145 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark05(-0.009176680871566683,-1.5707963267948966,-6.283185856220527 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark05(-0.009398660408822939,-0.36359168692251376,-66.44286142935617 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark05(-0.009738950710136893,-1.5707963267948966,-77.53970093054124 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark05(-0.009877189172921741,-167.70175704400046,-3.403782736656595 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark05(-0.009967801369575702,-1.5707919930413874,-157.60000268330768 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark05(-0.010220362975348115,-105.18745230419165,73.34004422484047 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark05(-0.0102249179426371,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark05(-0.010276979447011876,-1.5707963267948966,31.77834281118919 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark05(-0.01088782107129467,-1.5707963267948966,-82.28734534544476 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark05(-0.010916712295994141,-1.5707963267948966,23.21064003488081 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark05(-0.010930622160024536,-1.5707963267948966,-2288.4610653622503 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark05(-0.011474942077994932,-205.20914218380256,-783.4519735602812 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark05(-0.01163714708730076,-1.5707963267948966,-39.1064140443935 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark05(-0.01165492451996819,-3.4561657293935752,39.059065615020444 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark05(-0.011944575650432644,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark05(-0.012009671672245493,3.1415926535897953,-53.50600637036623 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark05(-0.012124969457956325,-35.4178371563777,-100.0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark05(-0.012136764872872977,-0.41576322421179257,-1.5707963267948966 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark05(-0.012202452303076455,-97.69186191290352,46.069648359700324 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark05(-0.012404802774286267,-129.79414604131958,123.06314050487325 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark05(-0.012605719149595927,-1.5707963267948963,-1.4447541141987026 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark05(-0.012635610541096024,-1.5707963267948966,17.07838564869832 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark05(-0.012676517338243395,1.1102230246251565E-16,11.834761486358694 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark05(-0.012956974261954371,-9.663020566291978,0.0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark05(-0.013184042799715072,-8.767237396033612E-193,54.27297607204388 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark05(-0.013237476684046205,4.273657208769915,-0.03498084023617998 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark05(-0.01335108073106217,-1.0362854552774508,-26.896137240459495 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark05(-0.013490427646759118,-3.141592654059639,-13.569649366359698 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark05(-0.013706971228162779,4.14162880779133,4.14159265367593 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark05(-0.01418222200416297,4.141592653589795,4.290293697757724 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark05(-0.014461619655131895,-35.94764572362682,-78.17123450324445 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark05(-0.01450173286286438,-10.375314920335095,-78.26867283834264 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark05(-0.014699723233510712,-0.5181640664965169,0.4777740223036927 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark05(-0.014821393386722354,-48.488543784930506,-0.2899558948574992 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark05(-0.014852398316155393,-1.5707963267948966,-4.9569176510071274E-119 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark05(-0.015135612023017053,-98.94831957119986,-77.53956692073594 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark05(-0.015208421654875792,-79.90278857687113,-1.5707963267948628 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark05(-0.015475449622396675,-48.54489602699115,1.488912188166445 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark05(-0.015592605609788812,-1.5707963267948948,133.913358949321 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark05(-0.015965848941593322,-469.2231635941428,-9.147064803606042 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark05(-0.015967663815286956,-85.0588520298102,8.673617379884035E-19 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark05(-0.015969648186067754,-0.5538545758670815,0.0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark05(-0.01613401436907186,-0.6682565320306635,0.0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark05(-0.01626388519108002,-1.570796326794896,59.91828186590581 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark05(-0.0164599266721457,-0.04400444561710248,40.19465409927912 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark05(-0.016473417372671658,-1.505278074245832,83.25263157717193 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark05(-0.01648024460439027,-0.004547677129199904,97.01453372888335 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark05(-0.016820372726087603,-92.87283555143247,7.163374072948033 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark05(-0.01720761714163701,-1.5707963267948966,-1.5707963268959204 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark05(-0.01725259483399999,-1.4546320373184911,-94.73300127123751 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark05(-0.01727952640408026,0.13598784540380426,-0.4296692550186206 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark05(-0.01751079826825326,-41.30867090568168,-34.75194101678227 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark05(-0.017731440628791173,-0.07947766954379831,-2.8048673465677396 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark05(-0.0178253766338764,-1.5707963267948966,18.012504335716173 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark05(-0.017993185792075317,-15.871366133978174,1.5707963267948966 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark05(-0.018164443798549267,-10.392939442010652,6.537344979897295 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark05(-0.018186216138068034,-35.6216136726157,21.668735243643727 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark05(-0.01826401128291799,-6.776263578034403E-21,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark05(-0.018550269094382288,-35.10033400111049,-4.571450292000795 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark05(-0.01858258502573951,-1.5707963267948966,22.258152772037853 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark05(-0.01858740871515341,-1.5707963265519902,49.90124670113843 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark05(-0.01859044141891114,-1.5707963267948966,72.26378948820137 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark05(-0.019113919624263762,-3.9621302006836583,80.11061266653972 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark05(-0.019225631397270522,-1.5707963267948966,-8.103983033041862 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark05(-0.01939039852796362,-84.91722064360228,-65.44188195570881 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark05(-0.01945518535732088,-22.105258197251562,-3.1438215675374113 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark05(-0.01955608227591039,-4.005692073522486,-44.097738922367796 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark05(-0.019608277014120497,-0.17083151087532644,0.0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark05(-0.01978385238400024,14.575674078367925,13.819702311761937 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark05(-0.019926658824773735,-1.3845928256410764,-42.91021771542498 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark05(-0.020546590724915603,-7.930508972348868E-13,241.179072151125 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark05(-0.021156633340478567,-28.397025471422815,73.65944705515938 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark05(-0.021296184695491285,-78.94025638464899,43.9854549472546 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark05(-0.02136791864879242,-4.4026272858551673E-134,11.974804335450447 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark05(-0.021583393933759937,-66.43114082114401,0.0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark05(-0.022179256049958664,-72.4943589772315,-1.5707963241654759 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark05(-0.022220584853882754,-0.829708155277691,-623.5736446475605 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark05(-0.02226389251990138,-1.5707963267948966,-47.97250053023951 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark05(-0.02244488342244655,-66.2546916517375,-1.5112978455015729 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark05(-0.022743461615708133,-0.20666246988177697,-86.973915695498 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark05(-0.02297676375578175,-1.3935408392310291,-66.32635954819075 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark05(-0.02309149070906145,-41.89603472067569,89.57380114386162 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark05(-0.02331502495130966,-9.554019061996543,0.0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark05(-0.02339696707377946,-0.07276106106191282,75.83036006794251 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark05(-0.023612679407089,-124.03161509140521,-0.060204969564143784 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark05(-0.02367685737703107,-1.5707963267948912,-22.749577914867213 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark05(-0.02395514614492434,-22.34406713317753,-6.284325324211783 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark05(-0.02409861941674272,-1.3504039382417248,51.83617032584695 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark05(-0.02414534114107059,-1.5707963267948966,16.313801230651105 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark05(-0.024170362650619278,-0.831118559007307,50.82029340290624 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark05(-0.024299873406576467,-0.6928097552790097,-38.89663919072184 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark05(-0.024533795058551477,-16.080554075757533,0.4485922159657521 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark05(-0.024734481802340724,-41.0606373667171,-78.76958054324008 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark05(-0.02501794707411993,-10.3168832555591,1.5707963267948966 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark05(-0.02509114593258794,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark05(-0.025119052316454265,-47.34526830782985,-79.8976771397295 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark05(-0.02557239660537986,-0.5350657732498616,-0.33239831824871374 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark05(-0.025617440386133547,-54.59397251460018,-20.42037197589958 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark05(-0.025842789833585615,-1.2655903679812863,-1.5707963267948966 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark05(-0.026003195499507976,-5.421010862427522E-20,-75.40948768778563 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark05(-0.026021965516864684,-1.5707963267948963,23.215789235785337 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark05(-0.02603704955055565,-1.5707963267948948,-1.5707963267948963 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark05(-0.026221175326627114,-54.58705351121065,10.387744013581438 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark05(-0.026893460825624688,-1.5707963267948966,-1.4985547874289984 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark05(-0.027120587568633114,-1.3626790616855193,-50.1659385763013 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark05(-0.02729601035472825,-80.07437092685632,-1.5707963267948966 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark05(0.02808426889819628,-3.3243310903826386,-1.5707963267948983 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark05(-0.028270982800853273,-72.70226313956738,-0.3802178193047779 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark05(-0.028544567492269926,-0.9435344811485842,-46.49886128323213 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark05(-0.029156859293478644,-0.0411697617287053,60.28266493447717 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark05(-0.02954907118092127,-67.03981953142076,-1.492556604874018 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark05(-0.0297195318700673,-79.90128185345947,-1.1691127417610654 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark05(-0.029730187181933987,-1.5707963267948966,6.938893903907228E-18 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark05(-0.029758079111693217,-41.82491705240075,49.864371977098514 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark05(-0.029862554678451506,-53.999689328191195,-1.5707963267948963 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark05(-0.02993157579612287,-1.5707963267948966,-164.68481362255582 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark05(-0.03034352289080053,-1.5707963267948948,-1.5707963267948948 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark05(-0.030378084973262498,-0.1081087240898011,-88.31658080573928 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark05(-0.03079996276644925,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark05(-0.031105239668089812,-286.3848617589345,-56.27105059421446 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark05(-0.03137044477095545,-1.1160887722358221,-83.77021898837108 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark05(-0.031489549324547284,-1.5707963267948966,23.853165544658772 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark05(-0.031839460819054394,-1.570796326250556,-48.769446143760966 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark05(-0.03194328310925063,-0.650298299685287,67.29757177052632 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark05(-0.032004068259925446,-0.06330408815843191,-50.26330492235937 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark05(-0.03201740215768201,-48.11080554190073,-35.6207025265374 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark05(-0.032177354860996155,-1.5707963267948966,6.6034054867739185 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark05(0.03225081309984992,-1.5707963267949019,100.0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark05(-0.032452810270680234,-1.5707963267948966,22.019115922078853 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark05(-0.032619420140691524,-66.4277274504294,22.227583300222378 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark05(-0.03264395383731,-1.5707963267948966,-21.85113778098399 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark05(-0.0326461414095891,-1.570796326794877,21.40447666067702 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark05(-0.032799051865039903,-1.5707963267948966,8.630945267370187 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark05(-0.03316013969866882,-3.718756276244534,0.45477793152757273 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark05(-0.033458229662896986,-1.5707963267948966,59.821682644833 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark05(-0.03357887611020496,-1.5707963267948966,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark05(-0.03368231399100807,-0.4494821288325732,15.708022528746223 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark05(-0.03377221301492247,-47.36155044515352,61.06269399368552 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark05(-0.033827112760791485,-1.3521959801678312,-10.750705524939931 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark05(0.03394830269967846,-1.5707963267948963,-1.5707963267948966 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark05(-0.03476655912547456,-53.545315840254325,-160.78431479101036 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark05(-0.0348881223193845,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark05(-0.035451124579838,-0.6368135359306422,-75.50470169540779 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark05(-0.035495754114504514,-4.062850215085078,86.48826225563909 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark05(-0.03551303406315248,-0.4107797162030374,0.0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark05(-0.03553883628527933,-47.427766365413504,1.513180674887617 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark05(-0.03628281701472614,-10.135475708807409,97.86732634361067 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark05(-0.036309512527835874,-0.6638453575933658,44.11272990241185 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark05(-0.03661165752875015,8.673617379884035E-19,1.5707963267948966 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark05(-0.036617378005073364,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark05(-0.03662762997776686,-1.491516052799116,0.0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark05(-0.03671689048289746,-1.2754821091569086,-12.737470830951763 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark05(-0.03734204353051319,-1.5707963267948966,-27.6893004218435 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark05(-0.037553702080727114,-1.570796326794891,51.48314036137657 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark05(-0.03757386827213194,-16.35514859639791,-42.624619793817 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark05(-0.03758980174544101,-0.7209141652647933,1.4715789432255706 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark05(-0.03760514892066524,-35.75665205528327,94.73319303718105 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark05(-0.037607059919483765,-1.5707963267948966,-97.40960170194485 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark05(-0.037891475387618764,-1.1708151526654076,3.1420809362937097 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark05(-0.03792730017718482,-47.89724441913699,-1.5707963267948966 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark05(-0.03797027599489411,-41.88737384030474,-3.142086351821131 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark05(-0.03806382903110029,-47.15260875618152,-6.287091849141438 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark05(-0.03832148118890322,-1.4675902063824289,16.272527960407388 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark05(-0.038944021406934495,-10.611462780552777,-1.5707963267948966 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark05(-0.03897775820996284,-1.5707963267948966,-6.695253507946845 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark05(-0.03900619108212687,-1.5707963267948966,-1.570796322576958 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark05(-0.03932237692798041,6.435694067727664,45.480885994503595 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark05(-0.03944256619889612,28.70353755551614,4.756759000334398 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark05(-0.040204182475016156,-67.39233259547908,-1.5707963267948966 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark05(-0.04034171875808329,-1.5707963267948966,-1.5707963267948957 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark05(-0.040878805539719676,-54.52111873280976,35.741918252829876 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark05(-0.04127318762803303,-92.28325326466312,-10.805156571148657 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark05(-0.041290935743595436,-54.76445200476937,97.7995315093542 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark05(-0.04138127556267943,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark05(-0.041733903904410896,-54.968729765311174,86.00207812615932 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark05(-0.041787167086167226,-1.5707963267948966,-42.15325140628499 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark05(-0.04185901841022465,-3.141653715035378,-83.02998517238235 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark05(-0.041922066772158956,-1.5707963267948966,57.02616763562426 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark05(-0.042286095817780006,-85.62606977529109,-1.5707963267949019 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark05(-0.0425024276537828,-1.5707963267948966,-41.99346550247465 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark05(-0.04261091147176302,-224.4619128583249,66.31797160090878 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark05(-0.042614654177609915,-92.03773733275366,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark05(-0.04267063531986515,-0.6143120854534251,-1.5707963267948966 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark05(-0.04273899701947212,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark05(-0.0431902081536733,-97.99887940710339,238.7285643193624 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark05(-0.04326823490257531,-0.8881667697131718,-3.0846974273316917E-179 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark05(-0.04358556277308855,-1.2474176807016306,-1.6058464081929458 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark05(-0.043716233519057734,-10.523129231247793,-73.16798070849444 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark05(-0.04383213319852163,-66.0141975512584,-66.43811248214782 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark05(-0.04519572368433062,-1.5707963267948966,81.84623513741306 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark05(0.045614487586474045,-3.169691982167702,-75.12326066056147 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark05(-0.04591731761035463,-35.32791026519734,5.1573664508252355 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark05(-0.04643687555192365,-1.5707963267948966,-8.15140194831347 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark05(-0.046744610694943504,-60.95155432416585,-71.3570508241627 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark05(-0.04694506762865025,-104.44714509575032,6.495339499007365 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark05(-0.047070698961175626,-0.378770024030396,-0.8860361766466754 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark05(-0.04744347661526749,-1.879323023042806E-17,4.712398792157286 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark05(-0.047862810076224484,-78.86891186655963,-0.15678803521456075 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark05(-0.047981533794671606,-65.98563111620587,-23.325907317344857 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark05(-0.04805442175869696,-60.14574884915913,-86.31751987204528 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark05(-0.04837563312149157,-0.12639346186059428,90.79790077736172 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark05(-0.048823748647861626,-1.5707963267948966,46.016763891436355 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark05(-0.0488794195286803,4.14159265432803,-60.18328829155229 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark05(-0.048913556565030464,-59.84534211190613,-73.82011033554328 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark05(0.04892245094857033,-8.881784197001252E-16,-88.33038444972476 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark05(-0.0492167769072878,-1.365072988548493,63.01079038730518 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark05(-0.049616613393435594,-0.024308720648274967,0.9153218877403181 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark05(-0.04971310184070887,-1.4884526120265418,-41.96763623115618 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark05(-0.049731161660975076,-60.93160996633868,-141.33543706121966 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark05(-0.05004036434033049,-0.02223435639470519,44.34392093279112 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark05(-0.05040863543258417,-35.10149582652674,60.90369254574503 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark05(-0.05082244785604935,-43.494556455467894,22.837329555474952 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark05(-0.050893069494664656,-1.5707963267948966,-98.66096671118223 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark05(-0.050932907364983404,-1.5707963267948966,8.344619121664941 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark05(-0.05099442453297154,-16.071934318117812,61.03004910756753 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark05(-0.05164807349472808,-3.1448533303753696,1.5707963267948983 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark05(-0.05183404342950266,-1.5707963267948966,-34.388293603895555 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark05(-0.051859153241731404,-0.26612665190253726,-5.498157297144331 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark05(-0.0519430582594643,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark05(-0.05244538637028515,-98.68080838330317,3.1415928921035716 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark05(-0.053630166895563075,-7.105427357601002E-15,-63.47626006383919 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark05(-0.05383645213460561,-1.5120178335148484,0.0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark05(-0.054359321341856566,-61.0734563503114,-60.702791830559086 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark05(-0.05460485471386188,-67.3253359452139,-97.84819303141946 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark05(-0.05480828970644391,-54.59727756407142,0.0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark05(-0.05502684383188023,-78.90373713199001,-78.12605284258814 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark05(-0.055630343503557014,-1.5707963267948966,15.821359974134097 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark05(-0.055670680242751666,-48.54495492073661,-17.985968831229272 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark05(-0.05569502874350855,-1.5707963267948963,1.5707963267948966 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark05(-0.05602421409862449,-1.2950148183280445,0.26639683244769347 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark05(-0.056326217928187816,-4.198676748098748,-60.3336061410828 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark05(-0.05653959279302163,-0.6999423299857719,0.2365333863143138 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark05(-0.056709939670150374,-60.963926854404015,-49.687186005090254 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark05(-0.05672271594614098,-1.5707963267948966,16.140385117690954 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark05(-0.05676027036043241,-10.447601273713515,-3.209465247941509 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark05(-0.05682753926743171,-0.019478877689287504,-1.5707963267948966 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark05(-0.05687405191129502,-9.035033458057932E-4,1.5707963267948963 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark05(-0.05687963169558762,-0.9686520543768204,-6.41156977478604 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark05(-0.05694934673031572,-0.24365653446042934,-98.81524723799569 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark05(-0.05719299194484198,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark05(-0.05730308787614403,-72.67985860309777,-55.50937062618616 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark05(-0.05808055805601903,0.137911680497682,83.39480895520431 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark05(-0.058368275099413086,-0.2404445258714186,-55.48201161924682 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark05(-0.058421229534078085,-1.5707963267948966,-57.25336838810677 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark05(-0.058476894508858235,-97.98675431943697,81.89863390138458 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark05(-0.058485000267275766,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark05(-0.05869461469411273,-35.10258692895188,-13.981864006637494 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark05(-0.05899644065892992,-1.5707963267948966,-13.776397231611085 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark05(-0.05943835170364409,-84.85024404088026,1.5707963267948983 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark05(-0.0595440200596564,-0.7091191906119473,-10.177865817717567 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark05(-0.05981283977969693,-78.76171992714646,32.337257268717806 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark05(-0.05989731739208565,-35.530815918805644,-1.5262416658966795 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark05(-0.06022670750602632,-1.5099883927050042,88.3090074296229 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark05(-0.06037249720189636,5.551115123125783E-17,-1.5707963267948948 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark05(-0.060751369848356024,-1.270229705185876,-82.12444707910974 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark05(-0.06095689388949425,-1.2835996102828757,0.0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark05(-0.06116119382591667,-124.02826315564411,-1.5707963267948912 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark05(-0.06116463215620627,-0.022117007602942988,-1.5707963267948966 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark05(-0.06167858683358369,-53.66789239318385,-34.74800236512676 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark05(-0.061724488642671854,-1.5707963267948966,3.8899507962454166E-17 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark05(-0.06223609045057459,-78.57774701862621,-67.93622912387963 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark05(-0.06229445412087607,-1.5707779392034902,-898.4833689455396 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark05(-0.06234496960826308,-66.4329969214616,22.12208821887431 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark05(-0.06248794706817836,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark05(-0.06254539720563601,-155.48407583985374,-32.41876761425229 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark05(-0.06273871921251184,-73.2151181541312,1.04511192277157 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark05(-0.06274126070779103,-3.141603455565247,0.0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark05(-0.06299079948704922,-1.5707963267948966,59.26668374922443 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark05(-0.06309447708473541,-13.711082213015999,-0.2606132497708079 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark05(-0.06315268278514763,-1.5707963267948966,-81.62300554484479 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark05(-0.06342422279355608,-16.147108303168213,1.5707963267948966 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark05(-0.06348695972622659,-40.97327788276766,-17.977193374194947 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark05(-0.0637574143831614,-3.552713678800501E-15,-66.48384388447772 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark05(-0.06395498570273035,-16.06521688837835,1.5707963265707898 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark05(-0.06401792325512953,-21.992125137628555,-0.004548471965898704 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark05(-0.06424905933729641,-35.63657693461302,-8.198643936739593 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark05(-0.06428570792999522,-48.43298628432832,73.79153883960349 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark05(-0.06452538701278222,-42.40276907699243,-15.113546724361811 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark05(-0.06542816421011466,-35.90064978902208,20.44409789857535 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark05(-0.06561763491195713,-1.5707963267948966,50.59863000564394 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark05(-0.06564326273879563,-1.5707963267948966,-1.551178345806403 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark05(-0.06608591513392666,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark05(-0.06608766822331961,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark05(-0.06635865407155467,-92.47331492038546,-73.76905067117316 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark05(-0.0664005185247086,-1.5707963267948966,-50.76683272283195 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark05(-0.06673039569061655,-3.2553493726401967,-42.15627732413849 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark05(-0.06690509745173141,-1.5707963267948966,23.709203058115563 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark05(-0.06693002197203664,-1.5707963267948966,89.84552725327669 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark05(-0.06702698150835618,-48.645715199266874,-54.74347419855324 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark05(-0.06727418946046276,-0.025647641611339006,210.48670774748962 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark05(-0.06738624441256076,-1.3897214635211401,-54.977871437821385 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark05(-0.06752144377363349,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark05(-0.06770722649519413,-72.72247015892677,-1.57079632679487 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark05(-0.06808577572993986,3.022934626172821,13.252145064761287 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark05(-0.06810310062030711,-36.047950483479745,23.216352054193592 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark05(-0.06818802134689052,-0.6357334015873604,-3.1436110331635896 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark05(-0.06888009691353773,-1.5707963267948966,-80.94309175421776 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark05(-0.06897981141603626,-16.428696181218953,-42.02135462655185 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark05(-0.06904734856378128,-72.99163554089246,-8.704357983749714 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark05(-0.06926264198023141,-10.658964409223675,-1.5707963267948966 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark05(-0.06932048851939598,-78.69937518525207,-0.32630324110260456 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark05(-0.06963879348591978,-85.04149275244276,1.570796317638306 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark05(-0.07008492845410197,-0.012163824985771725,-42.785362793508924 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark05(-0.07026082524365727,-909.2941617545674,1.5707963267948983 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark05(-0.07035200803287464,-78.74686524387862,29.13256958911863 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark05(-0.07040340020388966,-1.5707963276015309,1.5707963267948966 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark05(-0.07095562127329998,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark05(-0.07278188558211432,-66.52104244606792,56.056519102123204 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark05(-0.07288181580945396,-9.945370108719317,62.47514478099066 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark05(-0.0730502864594455,-1.5707963267948966,-39.887828218441705 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark05(-0.07307244910480715,-1.0824674490095276E-15,0.0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark05(-0.07321333584541599,-54.50925107168867,8.336788316797017 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark05(0.07321827040780564,-0.2782778766081459,21.190665114076396 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark05(-0.07332797691796798,-4.423818272415559,-31.003363691446253 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark05(-0.07336458403585222,-0.34306480732327793,-56.54866776455041 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark05(-0.07416870310199494,-16.550021747251876,-4.141592653589863 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark05(-0.07457569323034505,-1.5707963267948966,29.936400633900156 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark05(-0.07464027359418668,-35.08139371452077,-1.5707963267944436 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark05(-0.0746773793439246,-1.4523303432123038,1.5707963267948968 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark05(-0.07605448724042325,-0.3040946722008892,-89.88791874044999 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark05(-0.07627784680416644,-15.88284940137484,-20.95938539861212 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark05(-0.07630430384440649,-8.470329472543003E-22,82.1065387986852 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark05(-0.0768627701453517,-67.22947249659872,-60.87006999967143 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark05(-0.07701252849653883,-48.34281721374869,-1.5707963267948963 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark05(-0.07711063685912833,-98.36189524609145,1.5707963267948966 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark05(-0.07736549695842819,2.1684043449710089E-19,-1.5707963267950191 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark05(-0.07775612431959482,-1.5707963267948966,1.9742063534922827E-177 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark05(-0.07856346766128496,-112.0422359082484,77.98640718718073 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark05(-0.07952038556606755,-1.5707963267948966,-84.80656846729863 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark05(-0.07994383431131087,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark05(-0.0799961544455224,-1.5707963267948983,-8.384946109687164 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark05(-0.08075811097887745,-22.498678135641647,-42.181470601196565 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark05(-0.08140202922260285,-1.148387571894197,52.18588044787299 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark05(-0.08153722102188757,-1.0182063848036813,-43.12617298359414 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark05(-0.0818323218893116,-1.5707963267948966,-87.96557086305585 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark05(-0.08196388430025316,-1.5214795012417164,-1.570796326794893 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark05(-0.08223576638593733,-1.560176762420787,-55.50178416102844 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark05(-0.08228434302172039,-66.2502640439746,83.37843357929523 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark05(-0.08235135240255446,-29.792316872182667,-1.5707963267948966 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark05(-0.08243042230610442,-595.2882828276862,209.1250598686522 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark05(-0.08245496749555074,-3.143786119554986,-7.524753110849955 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark05(-0.08264891607432476,-0.8123649815086501,0.18101773921803804 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark05(-0.0830380442576651,6.938893903907228E-18,-11.9504697523572 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark05(-0.08313139090119492,-1.5707963267948966,-0.07103450020893042 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark05(-0.0833662669307157,-10.323314044899433,34.085494488428054 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark05(-0.0836952847521576,-4.9355158837307067E-178,1.5636549055163382 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark05(-0.0839775110057917,-73.06244787566547,98.976488067932 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark05(-0.08404751742445826,-1.266211360320943,0.0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark05(-0.084094135588201,-1.5707963267948966,-1.519418626294998 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark05(-0.08409524031580556,-1.5707963267948966,1.224725330801657 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark05(-0.08413344199215224,-72.54699949637302,-1.511548587634885 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark05(-0.08419675621242145,-0.9904075100516486,-142.94798575549672 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark05(-0.08442458072282276,-54.608806962716585,-7.075638897700443 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark05(-0.0848013251459363,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark05(-0.0849887753788342,-1.5707963267948966,-44.243597680768076 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark05(-0.08519665458589654,-91.677067830089,-53.96755821221569 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark05(-0.0851997298401821,-0.9784551548292812,-2.4677579418653533E-178 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark05(-0.08555776292313233,-1.5707963267948966,21.13140472720194 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark05(-0.08601174402496001,-0.17841151193626162,-97.11491320076466 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark05(-0.08610384060607323,-1.5707963267948966,1.5707963267948957 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark05(-0.08621365340444298,-10.127313625224488,-76.97078649454625 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark05(-0.08654750780223885,-1.5707963267949019,-24.122826933859827 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark05(-0.08737354789569829,-1.1321625824595856,-63.643799831364724 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark05(-0.08750287796866209,-0.6164137735416552,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark05(-0.08761507375167174,-0.35982303694735784,14.523523440045063 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark05(-0.0881611121797986,-1.5707963267948966,-36.94415248338198 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark05(-0.08816752014033832,-0.44985918832932736,1.5707963267948966 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark05(-0.0887792140654489,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark05(-0.0888119639799637,-1.5707963267948966,88.06287256257026 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark05(-0.08997560219890327,-66.27514616087433,0.0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark05(-0.08998089840674356,-0.011336844267339339,4.712390878966798 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark05(-0.090032603913494,-22.39523489578627,-4.712389177918456 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark05(-0.09023992560296995,-1.5707963267948966,0.37301629895428723 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark05(-0.09101310062158147,-97.82051590426771,-717.1337165286493 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark05(-0.09135950358953127,-53.508017923597656,67.13071975919529 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark05(-0.09154748165853634,-48.39747495915538,512.4956784059963 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark05(-0.09235399561202252,-16.323516540387068,20.30897471382731 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark05(-0.09249795514647019,-35.76993485892339,-41.71853690342357 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark05(-0.09283357816405235,-1.5707963267948966,22.092697032363702 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark05(-0.09285493865272154,-1.5707963267948912,-54.33094460525891 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark05(-0.09332181056589542,-16.89309663949382,-47.494032860603674 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark05(-0.0935834977241878,-104.8866995869726,5.141592734197109 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark05(-0.09379742788337875,-1.2980104697988115,1.5707963267948983 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark05(-0.09436462665916434,-135.1143590243475,-1.5707963267948983 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark05(-0.09464323006991769,-1.5707963267942497,82.77871580135661 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark05(-0.09484673278533132,-1.3241514222635853,-3.920195868954785 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark05(-0.0949889729519311,-0.34693554363629175,-16.72342777384547 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark05(-0.09515236805421351,-1.002378104028324,83.45041877735822 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark05(-0.09593428004706354,-7.044203657368268E-133,60.05882118994605 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark05(-0.09626707621381515,-34.74115685395536,-1.5707963267948966 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark05(-0.09651409724696053,-1.4469250390730826,49.99001941945431 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark05(-0.09667098029385679,-0.49507537530096385,-16.02957587680661 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark05(-0.09669382245161352,-4.440892098500626E-16,36.13628880889215 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark05(-0.09681490187639726,-0.8607403272964503,-81.15484662723885 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark05(-0.0968315015447221,-41.89868114217471,-51.017504271229896 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark05(-0.09691545868053106,6.429385846267878,6.296055617856715 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark05(-0.09738461493176997,-66.90464465324564,18.996738590139373 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark05(-0.09738517364376166,-1.5707963267948966,3.1494209777042337 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark05(-0.09742181825363043,-0.1834607469841404,89.91057305286802 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark05(-0.09751153634547804,-0.29772189580757474,-43.502803600915605 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark05(-0.09774226772656876,-60.80424871541163,-1.4228969226492547 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark05(-0.09774440564669995,4.3368086899420177E-19,-12.543306890735705 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark05(-0.09808357350131547,-0.3216585559115118,1.5707963328462407 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark05(-0.09819669151323102,-0.6367317686315248,1.5707963251541328 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark05(-0.09844718944504494,-1.3881623808067907,-14.137166941154069 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark05(-0.09848873639682149,-85.65187640107087,-0.39900190011464154 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark05(-0.09866116234271849,-36.03823761250976,-13.935750470834492 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark05(-0.09886972937958693,-1.5707963267948966,-53.10548636939891 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark05(-0.09909302924875085,-0.4913453148290774,84.38786095013197 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark05(-0.10059718639467441,-41.073067358942204,28.068176766396117 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark05(-0.10070038394740399,-1.0172359859566362,14.225289234094383 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark05(-0.1015065348552785,-1.5707963267948966,80.6338032877677 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark05(-0.10158017016424054,-29.61840502302688,-1.5496640356046465 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark05(-0.10176945091658329,-1.5707963267949094,13.279178674921317 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark05(-0.10203960925701339,-3.269273710071622,92.21641070862842 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark05(-0.10268386447633601,-6.842277657836021E-49,45.097108878223395 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark05(-0.10293804363691206,-35.93149081324212,0.0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark05(-0.10295467827985319,-10.25672141596364,78.52976210679131 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark05(-0.10304732119640103,-1.5707963267949019,82.61137214878758 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark05(-0.10332045627747344,-72.53199283699288,-1.5707963267948968 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark05(-0.1036227004830188,-105.15476337766971,9.632265479165719 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark05(-0.10423342106550323,-15.923657705935994,-1.5707963267948912 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark05(-0.10445574426881118,-1.5707963265736145,99.01716252677213 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark05(-0.10494088458674322,-0.6708566605617087,-55.22334852513191 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark05(-0.10545333043497526,-98.07003997475636,85.52798067141194 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark05(-0.10552282045052307,-66.62110686055684,-0.16610438882608186 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark05(-0.10558998677017373,-1.5707963267948966,15.773920177390579 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark05(-0.10656576807893695,-1.5707963267948983,-1.5707963267948966 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark05(-0.10694337305600832,-1.5707963267948961,39.25493193152038 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark05(-0.10742023891770051,-9.626619915869789,-7.432324155321815 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark05(-0.10744422045208668,-1.4243552296664934,168.55984782291426 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark05(-0.10769530426528244,-186.63068705331347,-22.114655896330653 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark05(-0.10894008749343113,-54.62323492447793,26.493306030902353 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark05(-0.10895364683344155,-1.5707963275220225,101.85238893064023 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark05(-0.10937445444706917,-35.43531634989894,4.5522099189454387E-159 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark05(-0.10944618389594435,-60.77921883639364,29.570604985050778 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark05(-0.1100376874099853,-47.90706794561236,-0.07585754369759316 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark05(-0.11039343046716525,-1.5707963267944514,-49.72216024443388 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark05(-0.11057342436326323,-35.52589628793916,21.970411292777626 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark05(-0.11058979645574704,-59.69050456375479,1.5707963267948966 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark05(-0.11121189822795166,-1.4734565494558636E-15,-69.59080303903417 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark05(-0.11170026345402491,-47.44104852497764,-73.16589536794278 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark05(-0.11199345378048317,-0.8072808591216291,4.712389861185198 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark05(-0.11199677689739929,-98.4100992271603,0.0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark05(-0.11212321373704046,-21.99114857512857,-98.55828156488205 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark05(-0.11213455026631584,-3.1415928920090286,46.187600581594864 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark05(-0.11220465782492084,-66.72560137639269,-23.025515761602563 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark05(-0.11293485535651748,-1.5707963267948983,-806.5016902800971 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark05(-0.1129674190474344,-1.4566826448354113,14.430430950452674 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark05(-0.11308154048298662,-0.810805333142907,54.33621731648857 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark05(-0.11332005628348417,-34.84182385997562,-25.99863605418058 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark05(-0.1137875115556586,-1.2180054485432128,-3.149405153589884 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark05(-0.1139649011946631,-1.5707963267948966,1.5707963345527631 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark05(-0.1140313772953685,-72.8298682439455,-12.57304721387979 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark05(-0.11464105181669426,-1.5597030872249678,566.4519799361909 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark05(-0.11478740724336778,-1.5707963267948966,-27.95419377028174 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark05(-0.11493170393907237,-0.012118304085678523,-28.13236724983348 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark05(-0.11493386747778346,-0.018085587181351323,4.1415926537762555 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark05(-0.1151669266094757,-16.14106442277953,-12.369738480931616 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark05(-0.1154768832472075,-4.137829757039716E-17,53.02225755316889 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark05(-0.11610571310029683,-1.5707963267948966,68.55230486292491 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark05(-0.11673682250964801,-1.5707963267948912,-56.5802461061025 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark05(-0.11676104752931708,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark05(-0.11709474856282798,-1.5707963267948912,-28.255390373652816 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark05(-0.11808463681800449,-1.5707963267943619,112.57861455803831 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark05(-0.11847649310784125,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark05(0.11868050989986345,-1.5643056424644992,1.5707963267948912 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark05(-0.11911405661242389,-1.5707963267948963,29.034908859701602 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark05(-0.12011485544471388,-4.522862495591326,-1.5707963267948963 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark05(-0.12024063258897222,-15.851447315433681,2415.280476638081 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark05(-0.12068398350346372,-1.5707963267948966,16.58023317891118 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark05(-0.12079237735299606,-1.5707963334723174,-91.05304002422743 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark05(-0.12089372548485162,-1.5707963267948966,26.315050846724663 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark05(-0.12092360789508057,-60.67310555782363,-22.041307816915136 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark05(-0.12098521243388038,-59.72502483209902,-20.68255984445564 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark05(-0.12103886139493064,-1.093128101274175,-94.13631172189147 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark05(-0.12107182555926205,-48.21632971850943,100.0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark05(-0.12154605806455518,4.148248458467161,51.19120465975243 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark05(-0.12191991423741451,-0.40671544146223687,-41.2566612434345 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark05(-0.1219541318580962,-1.5707963267948966,-29.941471125335312 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark05(-0.12291716686690635,-9.491330705834564,6.2532067590337235 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark05(-0.12297878201804358,-0.501968956403497,-0.5276883592805999 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark05(-0.1236300119912267,-1.8033161362862765E-130,0.0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark05(-0.1238642989893815,-3.4927705466681154,-130.34407868011095 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark05(-0.12392927491629005,-1.1541712053574595,0.7342914599846715 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark05(-0.12410912591926826,-66.83632211236882,-102.8443826907212 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark05(-0.12415761002628489,-168.4473175939529,40.38218188556789 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark05(-0.12455950929662322,-28.280839188716342,-1.448535269391783 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark05(-0.1251047454871971,-2.3265257954256993E-15,1.5707963267948966 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark05(-0.12596214147878942,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark05(-0.12598968896629897,-0.0015949598167469374,-8.103981643972007 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark05(-0.12651884253827603,-0.9918077961712971,-3.1421283271067124 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark05(-0.1272306075627757,-1.3099311382571877,-0.8677762162486111 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark05(-0.12772617239448358,-3.1437421034170594,20.940740214740117 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark05(-0.1277727550823884,-1.5707963267948966,-72.94360612295189 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark05(-0.1279597389521583,-9.501612412431832,-0.27041958448808145 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark05(-0.12849155065898157,-1.5707963267374152,38.39908025856096 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark05(-0.12860049601239817,-1.5707963267948966,-25.882215679579048 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark05(-0.12878546154096732,-186.48586848532895,-109.95577516619049 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark05(-0.12903592105251324,-0.8190177804133683,37.18741401914201 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark05(-0.12911348563529046,-4.566674841228362,-181.9544376708102 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark05(-0.12952701747789397,-1.5429046980301364,-107.99675114448115 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark05(-0.12978007253356794,-1.5627751354261463,-1.5707963267948966 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark05(-0.13007988493266706,-3.143546207874035,1.5707963267948966 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark05(0.13051371932753578,-1.5707963267948963,-89.6842752521429 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark05(-0.13066306399067973,-0.5174693200018068,1.4746474651406105 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark05(-0.1309515684951823,-22.568046551461883,-4.118524717275177 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark05(-0.13120624450573606,-1.5707963267948966,41.08229267098324 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark05(-0.13127523373344002,-42.13831643802523,-8.104359268169961 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark05(-0.13213866669106267,-1.5707963267948983,-13.66332855896303 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark05(-0.13223195155030015,-1.5707963267948966,7.013459981314116 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark05(-0.13255761589677273,-104.8597292779776,78.5015644186806 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark05(-0.1325713097779726,-1.5707963267948912,71.85176522280918 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark05(-0.13327325299948797,-41.90907790268452,-146.64237764348556 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark05(-0.13355588918110306,-66.00687269124282,-48.3786391614904 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark05(-0.13364874546687908,-1.5707963267948966,26.89753128413206 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark05(-0.13371285635714175,-72.39273858831848,-7.859018320021682 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark05(-0.13383537248592614,-0.10598079449402864,-44.16621168723982 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark05(-0.13455455314567644,-5.551115123125783E-17,-0.09462800120487584 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark05(-0.13585333606463268,-15.837496338196043,-67.4400128714727 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark05(-0.13619650117985582,-1.5707963267948966,-82.5402252839392 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark05(-0.13641905827646378,-28.94142445622341,-1.5707963267948966 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark05(-0.13689307954246033,-1.3151650299311721,-71.49115207925507 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark05(-0.13733128298566777,-1.5707963267948948,86.44979697582224 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark05(-0.1373674506324064,-0.505990723659955,100.0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark05(-0.1378011762337532,-1.333854293914806,-27.910125059307155 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark05(-0.13825804668870087,-0.030926238630679993,1.993461051254702 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark05(-0.1384680706821368,-3.1416231711721205,-16.342802377394417 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark05(-0.13881417776146704,-61.19463929945443,81.70376604228507 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark05(-0.13890533638901914,-47.46255410635521,-1.5707963267950977 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark05(-0.13983652865728696,-3.1416095556946515,-67.92181300087408 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark05(0.13991012816772386,-9.487573838686009,211.7648112087694 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark05(-0.1399302248600164,28.70353845865576,67.14779451829259 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark05(-0.1401452873198808,-42.37325024572661,3.1415953562173993 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark05(-0.1401762904331193,-1.5707963267948966,60.02954077555859 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark05(-0.14046245306044916,-0.5200288262182217,-6.381966547067368E-4 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark05(-0.14094441689383871,-3.1435457787021615,1.6025175170016261 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark05(-0.14175043617205552,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark05(-0.1421341489871848,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark05(-0.1423601388435429,-1.5707963267948966,-56.67465264677401 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark05(-0.14316509332566874,-1.0881012393131062,0.6164431855598538 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark05(-0.14333331707145192,-9.978205294320432,110.68099895273826 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark05(-0.14382232693964658,-651.8365223211899,33.06426117423649 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark05(-0.1440282357745516,-1.5707963267948966,74.70931852878704 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark05(-0.14409342260240182,-67.32722559116257,-1.5707963267948966 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark05(-0.14463798570204212,3.1416001584037585,-25.70592164783005 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark05(-0.1449581032814531,-40.89258564953357,0.0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark05(-0.14564173929478016,-1.5707963267948968,-1262.5112213850205 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark05(-0.14590578093990544,-1.5707963267948966,66.37802367900713 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark05(-0.1459394448859267,-98.0210648053618,170.91053031034352 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark05(-0.14629268233350182,-1.5707963267948966,12.971387055417614 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark05(-0.14632979505524257,-47.464199098828544,-23.005244927929795 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark05(-0.1463828441592745,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark05(-0.1466540842049517,-0.11221808192314008,-3.1746410307849966 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark05(-0.14674089819477842,-35.49903003480708,-89.72213569213837 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark05(-0.14715285896482044,-192.3566026806559,-0.9093395022017035 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark05(-0.14719606611235747,-9.5968500020806,112.6016013636548 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark05(0.14818874615038824,-3.239086002072828E-7,-8.70453739495646 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark05(-0.14834340372540863,-0.4920544456147665,64.91724917807251 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark05(-0.14901602295713337,-5.318716302760444E-4,86.1975270641062 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark05(-0.14917954982520473,-1.5707963267948966,-83.38698181464888 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark05(0.14985564601266801,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark05(-0.15014825389474132,-48.42217323882467,20.86624214609246 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark05(-0.15118540405180148,-0.043920257761650344,26.703537555513243 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark05(-0.1516385992083139,3.2311742677852644E-27,-75.77847726521676 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark05(-0.1526456437130116,-1.5707963267672853,40.794504666972486 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark05(-0.15307179206260657,-34.61714348587405,1.5707963267948966 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark05(-0.15313902347874264,-1.5707963267971214,141.09412889586983 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark05(-0.15319756214851488,-42.00194700318916,1.5707963267949019 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark05(-0.15330304526603378,-1.5707963267948983,0.01990888946832567 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark05(-0.1536505596931379,-1.5707963267948806,-46.54330484362646 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark05(-0.15453784951895644,-9.919818236808496,-1.5707963267948881 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark05(-0.15459155954209725,-1.5707963267948966,-95.5568215242051 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark05(-0.1552676098424981,-1.5707963267948966,-2.497147008972363 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark05(-0.15581893836947036,-0.1435208231734333,-50.22639943312637 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark05(-0.1562734474486197,-1.5707963267948966,-45.54089578891411 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark05(-0.1563228677311297,-98.52052218750762,-19.213931588604027 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark05(-0.15642756064415997,-1.5707963267948966,13.616862779926308 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark05(-0.1564992664253566,-59.80441140067943,-110.79177950990052 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark05(-0.1570923132701796,-0.22864988453121615,24.269287102319442 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark05(0.1571965846786775,-1.5707963267948966,48.92147550616985 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark05(-0.15790859438607213,-66.50832933577894,1.5707963267948966 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark05(-0.15832731452115825,-1.5707963267948966,10.344786319589488 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark05(-0.15986639346365694,-1.5707963267948966,33.38310969763875 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark05(-0.1599542320986217,-98.93606082414715,42.87405071302227 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark05(-0.16025737989575073,-1.5707963267948966,-25.136917281163385 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark05(-0.16130964782622542,-1.5707963267948966,9.424900034015232 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark05(-0.16211318343088005,-1.5707963267948966,78.02281552162582 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark05(-0.1622362738587334,-42.09901975184187,118.82496022071035 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark05(-0.1623200516099822,-3.1435457785898615,81.82039692206754 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark05(-0.16242539597571393,-6.681911775230489E-52,-9.530724307112553 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark05(-0.16253528370701797,-72.44798627711887,77.04010317055929 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark05(-0.16259348705842103,-35.71094811221825,22.181147695376495 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark05(-0.16284958911907943,-1.5707963267948966,63.455435668454214 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark05(-0.16329911384731194,-0.19576587416095817,-65.10141254165131 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark05(-0.16334244142359022,-3.141592689170797,139.33861759963216 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark05(-0.16338094084431995,3.469446951953614E-18,83.26830695134203 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark05(-0.1639048790465764,-1.5707963267948966,-80.75240059552 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark05(-0.16437486219029634,-1.3633985851485375,1.570796314318811 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark05(-0.1647556481961648,-1.5707963267689724,24.219689519372064 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark05(-0.1649689404497252,-98.85945609975171,67.88128465456619 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark05(-0.1649704638295818,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark05(0.16502815922702033,-98.07278167849603,41.42707229231195 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark05(-0.1651984173126689,-154.34151233732157,21.6446949301519 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark05(-0.16535595999482902,-0.018817403647951102,-78.26658052761273 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark05(-0.1668591132721554,-0.03661428584895543,76.64087391882883 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark05(-0.16687386414716754,-1.5707963267948966,-64.95295794511944 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark05(-0.16702916775421156,-4.591396729824071E-4,56.30118322062239 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark05(-0.1677192506482319,-1.5707963267948966,-83.47878540436452 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark05(-0.16806286361660894,-54.65628267248553,-2.4294190083990888 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark05(-0.16816622780553347,-3.1420809393762568,-1.5707963267948966 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark05(-0.16863390291687352,-1.5707963267948983,28.49785900042562 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark05(-0.16868065444873717,-1.5707963267948966,28.0593618292781 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark05(-0.16907918314154252,-66.84998944490928,60.143455433823675 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark05(-0.16961209827343965,-0.15113683509002443,1.5707963267948966 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark05(-0.17060996593883737,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark05(-0.1707756747652363,4.1415926549018085,-84.99619664316901 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark05(-0.17141789132742924,-73.21327101122068,59.2126850551016 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark05(-0.17163106245761883,-10.005684953107789,23.51015619037821 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark05(-0.17191378691296816,-85.04591116285383,67.52249451813825 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark05(-0.17228634142060073,-66.43148934850764,-73.82742735936014 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark05(0.17281224993148783,-0.00954577391706124,-141.254969743371 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark05(-0.17291589163354004,-15.72707841943988,0.6846752893930558 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark05(-0.1739724497710733,-1.5707963267948966,-1.5707963268554581 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark05(-0.17405959657553893,-98.71076382149985,685.435601559382 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark05(-0.17441601553518793,-1.1102230246251565E-16,7.418412301374843E-68 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark05(-0.17492376954984004,-0.06778153429750855,984.4446939966404 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark05(-0.17496880727647401,-35.09167985937111,148.02654173741394 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark05(-0.17498326141250253,-1.734723475976807E-18,20.02189737720296 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark05(-0.17520767617567745,-1.5707963267948912,-90.95794538476827 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark05(-0.17525430704678327,-248.19953808171576,-0.2199738950062697 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark05(-0.1752551405146299,-1.5707963267948963,-3.141623171169045 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark05(-0.17600001518515182,-1.526452111566725,-19.316125378363004 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark05(-0.1761724749394518,-1.5707963267948966,27.381025689862895 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark05(-0.17639366506257725,-0.4109570925158952,49.68592046284673 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark05(-0.17675605906848668,-1.5705427241830372,-619.2792387375854 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark05(-0.17676101051626225,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark05(-0.1777021833914721,-1.5707963267948966,261.42178205860216 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark05(-0.1784572291498458,-1.5707963267948963,27.934448839320716 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark05(-0.17872969173370257,-41.55340110371783,1.5707963267948966 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark05(-0.17911696742908248,-0.3253741495809825,-10.631182246378955 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark05(-0.179510236678943,-3.5460134233929243E-15,-1.3918978863537292 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark05(-0.17985870355481537,-47.90240163072341,-6.497131103528062E-114 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark05(-0.17989108618500274,-0.06964229165986968,98.47359152518743 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark05(-0.18037476763100724,-34.96919513521056,-82.29531045677614 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark05(-0.18111710224574873,-1.5707963267948966,3.212793148076136 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark05(0.18199016967785642,-0.5547076308818478,-28.144482762077878 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark05(-0.18306698513555072,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark05(-0.18309081265570343,-42.3339782581359,6.3571127961267475 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark05(-0.18350236706455633,-0.05444742276579684,-3.1416125200447342 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark05(-0.1840798323178327,-1.5707963267948957,35.70837691614355 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark05(-0.18506155873444818,-47.55810813355972,-31.275748930870716 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark05(-0.1855163205873016,-1.5707963267948966,-69.16631721038922 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark05(-0.18691043499784063,-47.64504798565455,-42.825799697735434 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark05(-0.1869447555841737,-16.289147875966226,-3.1415931566766897 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark05(-0.18696897142058333,-34.66517501553799,42.08937091903786 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark05(-0.18715581283594243,-0.17756195057442836,-32.05058670324806 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark05(-0.18837240108654252,-1.5707963267948966,83.0178375371267 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark05(-0.18927765286892845,-98.86812768266442,-0.7082581105585262 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark05(-0.1895761129955953,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark05(-0.1907341589435495,-161.18819938415226,85.13503142633272 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark05(-0.19081842325877463,-128.96228383765958,-0.07671603312130064 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark05(-0.1908591145027062,-1.3266916102101198,-5.141592667538498 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark05(-0.19118858238844366,-48.48231738340762,67.54424205218055 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark05(-0.19308159981643996,-0.01850258939425143,90.68909458286959 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark05(-0.19349605974971384,-1.5707963267948966,-19.845333020744565 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark05(-0.19356736661734972,-66.44211876053494,-19.05990030590121 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark05(-0.1937291722406682,-1.5707963267948966,43.53746738593711 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark05(-0.1945546220836558,-0.13639700758298157,0.0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark05(-0.1951770836774318,-61.201382200112796,46.46343880726326 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark05(-0.19560066083978028,-66.23036206800111,1.5707963267948966 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark05(-0.1956609090649249,-0.9335171261884334,-17.53886441185699 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark05(-0.19611501545236004,-47.51703923768863,36.23313886859317 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark05(-0.19652833998970545,-0.36268102689149606,6.345685315504826 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark05(-0.19751512399666815,-1.5707963267948966,-32.21338806229457 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark05(-0.19777011598064087,-858.632113154394,0.0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark05(-0.198309931612364,-78.83125524879091,83.40521714221843 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark05(-0.1984324765133812,-0.7908549480539797,-91.05875870390467 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark05(-0.19851002089539566,-0.23048343662247975,-62.95092494414489 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark05(-0.19854432683254686,-22.321187232001222,51.65147593354499 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark05(-0.19857650559708742,-1.5707963267948912,42.67121107145712 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark05(-0.1990479391041604,-1.5707963267948966,-61.29806295858798 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark05(-0.19919584291078074,-48.44816060692191,-1.4324776455041515 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark05(-0.19970570370156893,2.710505431213761E-20,0.0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark05(-0.19999928132448277,-1.5707963267948963,-32.948431978333275 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark05(-0.2002682906357076,-0.2416141858674049,0.0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark05(-0.20027484056831518,-1.5707963267936598,64.32544967839796 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark05(-0.20053872003154363,-36.11154593742105,-4.712389166241936 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark05(-0.2005522309369046,-4.40983438699341,-1.5707963267948966 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark05(0.2011966486450376,20.629125015343746,-33.52423950112376 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark05(-0.20164967131404732,-98.76437573818092,-139.2300124454045 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark05(-0.201933966545111,-1.5707963267948686,-1.5707963267948966 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark05(-0.2023295752666172,-0.16140278164933797,-58.2595979892208 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark05(-0.20344146893985085,-0.05251006741838663,0.0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark05(-0.20465187433357307,-400.5446280448883,39.179276432034605 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark05(-0.20484581200039112,-1.5201308922797252,95.3148047776637 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark05(-0.20557033969315436,-1.5707963267948963,44.73001185384132 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark05(-0.20602074878776397,-2.1684043449710089E-19,-18.575756615592724 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark05(-0.20643766117558648,-154.1883724659535,-133.7756469236727 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark05(-0.20674646722673592,-1.5707963267946219,-48.75411524054748 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark05(-0.20710297199231362,-1.5707963267948966,70.75288322750603 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark05(-0.20773434620305245,-1.5707963267948966,9.586209292434873 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark05(-0.20784117425443804,-1.5707963267948715,64.48807821877 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark05(-0.20790386070856623,-236.79870777185397,16.60660015038976 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark05(-0.20848038091504587,-91.70297217461426,-98.71995573119294 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark05(-0.20885710476039643,-59.734276845717325,-3.142120500532348 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark05(-0.20943906692230455,-48.09817906551508,-16.13328188095298 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark05(-0.2108552851379823,-1.5707963267948966,61.61309629615451 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark05(-0.2111377178313425,-1.5707963267948966,-1.570796326794897 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark05(-0.2115027089146404,-0.31704849730131873,1.5707963267948968 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark05(-0.21182075535268652,-1.5707963267948983,-110.82009329829532 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark05(-0.21184067168857873,-66.37235035234075,-33.262933365463226 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark05(-0.2128326742413001,-1.5707963267948966,61.505027059753786 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark05(-0.21358397869589524,-0.29499029704693575,56.021667728494194 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark05(-0.21414581851269432,-1.2899040872292824,-0.3949761395753476 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark05(-0.2142180285226089,-9.517363681395654,-73.3268423516766 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark05(-0.2148951062293733,-5.293955920339377E-23,22.415564007853206 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark05(-0.2154620220819365,-1.5707963267948906,-27.881684267989186 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark05(-0.21577742308852876,-60.98011343518361,-38.28316123306041 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark05(-0.21579038199407577,-98.67153100327442,15.852914200190936 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark05(-0.21581707234995817,-1.4375546938614994,96.77625630669576 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark05(-0.2160003066052854,-4.141592683674985,-49.827562588306805 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark05(-0.21618539778004595,-676.1074424173221,1.5707963267948966 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark05(-0.2163491113371248,-526.1603327565831,116.45068266498362 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark05(-0.21664981082314302,-0.007535629122711954,-14.1150243116072 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark05(-0.21667580968997024,-1.5707963267948966,-89.55099381490142 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark05(-0.21671571812503032,-1.4949920300816615,85.82434247859675 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark05(-0.2169129651389462,4.1415927197461935,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark05(-0.21792008146858444,-66.91300245905782,162.97418136942696 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark05(-0.21895560254815882,-98.43740285689873,-0.04109058327040679 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark05(-0.21972574914255794,-1.5707963267948966,78.2274695579011 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark05(-0.22014193499103582,-63.28864026335288,55.046246742431116 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark05(-0.22033381692924917,-3.3888513039789956,-44.00079704312083 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark05(-0.22047460699480326,-78.92120886638298,4.959233554673624 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark05(-0.22059744721060356,-97.92347455902815,1.5707963267948966 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark05(-0.22075914093871715,4.141592653590396,0.0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark05(-0.22122062360587574,28.703537564670004,-1.5682893742129136 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark05(-0.22149546938512793,-1.5707963267948966,85.83540788845562 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark05(-0.2215223958345822,14.431836356346345,2.220446049250313E-16 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark05(-0.22156509927077273,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark05(-0.222108298737617,-98.93627377987619,31.446914584432733 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark05(-0.2221150968678245,-1.5707963267948912,-10.557980992368542 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark05(-0.222265070506468,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark05(-0.22239216467205927,-59.8167592159212,-0.45529864633194644 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark05(-0.22311062830984665,-10.851845568595905,-0.48748095389774904 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark05(-0.2231512091267752,-1.5707963267948966,4.712391183235264 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark05(-0.22359863800771126,-122.99981492114206,2.9712350453029843E-7 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark05(-0.22364350698475344,-54.77970585906194,4.226769389061453 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark05(-0.2238336776601719,-85.00000970285741,-17.70176233349494 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark05(-0.2247600679768726,-135.65304950669307,4.712389101217956 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark05(-0.2251471492203787,-1.5707963267948966,-61.23511398679747 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark05(-0.22551047627638163,-0.048684647005304726,83.43772301716423 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark05(-0.22582761716592537,-3.1435532436080815,48.714080055782595 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark05(-0.22617643246467267,-98.77369502757223,0.0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark05(-0.22620286241222054,-2.220446049250313E-16,-21.698260942003575 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark05(-0.22656000536557339,-15.770283114682641,95.48674341927165 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark05(-0.2266940165876046,-9.861539409797986,-3.1415928920083758 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark05(-0.22684899723978202,-3.919906215840115,-31.446106728753563 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark05(-0.226920924510142,-66.58654726616885,86.22957310985394 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark05(-0.22787469532736349,-0.8447302581011894,-1.5707963267948966 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark05(-0.22792851734207176,-1.5707963267948966,36.151922859551135 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark05(-0.22844626139384105,4.930380657631324E-32,10.104215929029209 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark05(-0.22867551673635092,-1.1102230246251565E-16,1.9564208078775005 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark05(-0.22879619365914217,-1.5707963267948966,25.06071994162538 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark05(-0.22888184903000808,-41.91111792711469,-0.940319308973617 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark05(-0.2293953190686527,-1.5707864486847887,-1.570796326794893 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark05(-0.22949765794444857,-1.570796325597842,-1.5707963267948963 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark05(-0.2307517177359486,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark05(-0.23086068977553964,-0.004809323010856631,7.410932722313703 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark05(-0.2312805947213077,-0.23281573643750253,581.1926847384025 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark05(-0.23132591024570717,-0.01217537290398174,-32.94408873229693 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark05(-0.23175748476324637,-374.8423451417195,-133.49614121994804 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark05(-0.23185703983122607,-1.5707963267948966,83.49542926096223 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark05(-0.23216559327252162,-1.5707963267948966,-1.570796326794895 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark05(-0.2326196823902515,6.4321177166050925,-42.77070795457749 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark05(0.23268332244661064,6.884802781201673E-6,113.6723472527331 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark05(-0.23287846736110712,3.1420809863293697,85.28040466389899 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark05(-0.23295691071343866,-129.4214950065791,1.5707963267948994 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark05(-0.23373567780883753,-16.16063734535334,0.025974237449369837 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark05(-0.23381631694157706,-123.84360737035279,-119.08829107070609 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark05(-0.23483803731205982,-41.94757730156601,0.4661880710013729 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark05(-0.23484389222403929,-4.2044985982422105,-1.5707963267948966 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark05(-0.2350330175486096,-0.5172847238475793,-55.030333030923174 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark05(-0.23503976776546676,-35.05262278766709,-85.00953221502343 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark05(-0.23543168232157766,-48.65281423435985,-41.97979266115512 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark05(-0.2356642772749238,-1.5707963267948966,85.69956495896005 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark05(-0.23651069496702493,-1.5707963267948966,5.141592653601162 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark05(-0.23673870534460495,-1.5707963267948966,20.83355480388434 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark05(-0.23694259952338959,-1.4367133177619766,58.16070027125526 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark05(-0.2376061886982874,-3.3881317890172014E-21,1.5707963267948963 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark05(-0.23806586013732295,-0.2351022355528013,-97.79873890196369 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark05(-0.23834936365269085,-41.65727772252309,21.51806237626281 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark05(-0.2384805259091186,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark05(-0.23948269807852618,-3.1416536887460436,0.4590221369996439 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark05(-0.23985836535790417,-0.43732103134061884,-21.42123308850863 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark05(-0.24083346006670459,-73.05887116160092,-30.561870588748107 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark05(-0.2409245865641101,-1.5707963267948966,-47.69792031687896 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark05(-0.24099844057710657,-28.36546060534366,-31.41592653589707 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark05(-0.2416755303703499,-9.690987998932261,-3.1438024591329454 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark05(-0.24172601674152477,-1.5707963267948963,60.35367025810117 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark05(-0.24199258264900184,-0.7846887670925788,5.266575222308118 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark05(-0.24215262046315394,-0.08862301580502804,-47.552035285141635 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark05(-0.24258874428647925,-1.5707963267948912,-0.9452876450202202 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark05(-0.24288426685414186,-1.734723475976807E-18,-1.5707963267948966 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark05(-0.24297282289699784,-22.3345494905558,32.18638882464714 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark05(-0.2431490962849142,-1.5707963267948966,12.448911468267383 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark05(-0.24349757301023678,-0.7163523026525382,23.932425544766517 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark05(-0.2435410265959549,-1.1269150072834717,57.63390209353747 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark05(-0.24436359992152087,-1.5707963267948966,-8.103982211152665 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark05(-0.2446536317220942,-72.62667036628595,-95.74542622081607 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark05(-0.2447617814818538,-35.85711670725762,6.296885339731044 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark05(-0.24576354606421114,-3.141592653591939,51.10915357577403 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark05(-0.2458832422236954,-1.5707963267948966,-1.41263700388479 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark05(-0.24617782334217003,-0.09405356711975466,1.2234461497387912 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark05(-0.24685594198187177,-0.9158046150588192,79.20614076763026 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark05(-0.2475467059288713,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark05(-0.24778652127514983,-1.5707963267948966,9.986365305970534 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark05(-0.247796914553735,-1.5636631441681415,-57.420470133398325 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark05(-0.24820451571289898,-85.03429715733162,-3.525454953729936 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark05(-0.24832023381911666,-1.2486244492743794,48.28981498766063 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark05(-0.24848390681380303,-1.5707963267948966,-64.05385458075312 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark05(-0.24874411684106984,-1.9721522630525295E-31,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark05(-0.24974376541787488,-1.5707963267948966,96.81486520323024 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark05(-0.25001508294358504,-9.665701969952408,0.0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark05(-0.25097430859502157,-66.99600689996788,-0.27618615805610514 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark05(-0.25103319060791374,-1.0665850966381925,763.0602265288819 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark05(-0.25134945024270366,-53.40707558786366,-26.855819440679667 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark05(-0.2514273711668126,-28.286069893301217,-65.91364775307082 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark05(-0.251679617520431,4.141592653627369,2.220446049250313E-16 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark05(-0.2518179057966511,-1.5707963267948966,78.78180142906274 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark05(-0.25188991725356047,-3.964171452912339,159.06938506153529 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark05(-0.2518953800391196,-1.5707963267948966,33.58640945426048 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark05(-0.2519233321698505,-1.5707963267948966,-78.48740833076072 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark05(-0.25245679266318133,-1.0039766198560391,72.49844813623035 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark05(-0.2525326293025664,-1.5707963267948966,3.1494051535914465 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark05(-0.25264448517672683,-47.22659018460375,0.2771053618141231 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark05(0.2526862339487822,-1.5707963267948966,50.900073398478966 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark05(0.25279779785121936,-21.99114912889194,66.97632749576653 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark05(-0.2532571598650799,-17.2685394102937,-1.5707963267948966 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark05(-0.2534394214225886,-1.5707963267948961,31.98282586316544 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark05(-0.25347602071944086,-1.5707963267947609,-112.93574213589321 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark05(-0.25367235685255307,-42.4067212098342,-70.15069945119984 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark05(-0.2542079642642783,-91.10618910851535,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark05(-0.2543094506551398,2.710505431213761E-20,-1.5707963267948966 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark05(-0.2547089296685693,-1.5707963267948966,40.44311442925368 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark05(-0.2551575679599221,-1.5707963267948961,-122.84645926566631 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark05(-0.25555543924315516,-66.49353649311445,27.811536181841014 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark05(-0.25606959819063635,-3.1416039634521855,71.6365403544616 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark05(-0.25612006675701315,-1.5706985420234607,707.7056153131183 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark05(-0.256638042454568,3.141592653589797,-1.5707963267948966 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark05(-0.25668100757442563,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark05(-0.2571662029353912,-1.5707963267948966,44.158002572955354 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark05(-0.25848740248469404,-41.67963379540473,49.66110842044756 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark05(-0.2586630546577333,-0.43512804254402626,-28.969875344374202 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark05(-0.25866766148889475,-91.94921131630731,-22.271585471180913 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark05(-0.25939219056151186,-1.5707963267948912,-94.27905471412878 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark05(-0.25940555150832534,-66.037394484135,-86.14668040455405 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark05(-0.25994944199854647,-60.568664373446275,-66.6873421833415 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark05(-0.2603116088636961,-66.72508146850849,-88.9554818744501 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark05(-0.2607314813508338,-1.5707963265538,-0.21394934132557353 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark05(-0.2608352605845019,-91.49367051966037,-1.5707963267948966 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark05(-0.2614268696741888,-1.5707963267948966,39.01760342744135 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark05(-0.26174646498381077,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark05(-0.26175222415393984,-1.5707963267948948,-13.322382497454385 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark05(-0.2619050548941986,-1.509690356075012,-6.287091729268505 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark05(-0.26242930883044085,-1.5707963267948966,96.29440438860257 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark05(-0.26302081098843033,-36.070378077289725,-79.16528351813699 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark05(-0.2631314923683803,-15.864466209619827,46.352636949606136 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark05(-0.26394477791385756,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark05(-0.2639629857086041,-16.201195671551382,0.842321604231125 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark05(-0.2642421207659775,-1.5707963267948966,0.5642701521206535 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark05(-0.264464564918151,-35.56259996314749,-7.842552283234424 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark05(-0.2649412511649416,-78.7968482353603,9.39423869167851 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark05(-0.2653586813277534,-682.6781859683022,5.94872278976031E-4 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark05(-0.2656234341102163,-1.1369766850291314,-0.16082807935071172 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark05(-0.2663081306853025,-7.105427357601002E-15,119.17269632808859 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark05(-0.26710295866721356,-1.534948082900638,27.823300008872437 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark05(-0.26722035894047735,-0.6496046448851792,-1.4879953198560485 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark05(-0.26726048130107405,-732.9851506973989,-190.5140980637719 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark05(-0.2673822480969701,-1.5707963267948966,8.62451673479056 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark05(-0.26752433894154565,-98.9025865318443,1.5707963267948966 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark05(0.26808266444852513,3.157742081132462,-56.10532198542124 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark05(-0.26827635974609776,-1.5707963267948966,-48.1702903412673 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark05(-0.26830796282588215,-1.5707963267948948,19.335263145640322 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark05(-0.2693632024765453,-1.5707963267948966,-57.49894208989799 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark05(-0.2695384238827866,-1.3297587695001145,-5.347173662238213E-7 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark05(-0.26976690219819305,-1.5707963267948981,-112.6817961503881 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark05(-0.26987868172543866,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark05(-0.27128738579952516,-1.3940355120721015,-55.83553735202222 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark05(-0.2723355300896414,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark05(-0.27247568982971915,-664.4459202549247,-8.142828284494446 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark05(-0.2730913128212602,-1.570796326794874,-70.49196950019072 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark05(-0.2735182511109018,-97.96338121910335,-63.249291148782106 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark05(-0.2736892226944046,-0.5598778945102136,8.234173244160178 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark05(0.273696930676098,-1.2852371292011493,-168.1784277582041 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark05(-0.27543057181500885,-1.570796326555705,70.78955195505456 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark05(-0.2755735135164601,-3.9512114910691665,54.385045037674004 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark05(-0.2758102694573702,-0.732165013867884,65.72939645383556 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark05(-0.2768083398202911,-3.1416538865583687,-75.55236021306956 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark05(-0.2772375699308018,-0.016564007936743376,58.438357247893734 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark05(-0.27741120479044845,-1.5707963267948966,47.3746183421552 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark05(-0.2780688804578234,-1.5707963267949054,61.46260119219414 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark05(-0.2781645522722808,-1.1186621955522922,-1.5707963267948966 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark05(-0.27851716592827114,-1.5707963267948966,-71.66165358838188 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark05(-0.2796992846093474,-1.5011565880519635,0.0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark05(-0.2801083044973874,-0.05263380061575546,0.0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark05(-0.2802980215713725,-34.816055006845644,1.5707963267948966 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark05(-0.28046845022217326,-0.005942577798859216,-73.88053934623349 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark05(-0.2805330153360117,-1.5707963267948966,-76.63937609696157 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark05(-0.28113774043293727,-254.68111384608838,-0.09665271695628098 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark05(-0.28132673008429177,-1.5707963267948966,11.138812596150956 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark05(-0.281507542082859,-1.2615362788268918,21.08036641350381 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark05(-0.28157029045966886,-1.5707963267948966,16.88941878453834 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark05(-0.28188955357892453,-1.0243203206180738,0.0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark05(-0.2825503233464644,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark05(-0.2828599289236372,-66.9691746861572,0.0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark05(-0.28404998725880054,-1.5707963267948966,97.48867894260694 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark05(-0.28449154044096936,-0.053117470786678084,6.28318530717961 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark05(-0.28488404013833935,-1.5707963267948912,-32.469410907835226 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark05(-0.2854997156440921,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark05(-0.2856143692098561,-1.5707963267948983,-26.627862379270898 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark05(-0.28568592610272275,-4.4485187196764,-55.08182566763953 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark05(-0.2858849608344621,-9.56471616191271,-2.7480952210166225 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark05(-0.2869094855131067,-16.953987627169386,-22.407073522704597 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark05(-0.2873709733903964,-22.41182247229547,1.5707963267948983 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark05(-0.28752999037453914,-1.5707963267948966,66.2154059933102 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark05(-0.28781871482165305,-3.9769802713797615,0.0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark05(-0.287875421506352,-67.14528260785927,-1.5707963267948966 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark05(-0.2882029032168666,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark05(-0.2883442547807341,-0.27002552773866706,46.04389061293378 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark05(-0.28853666289057484,-4.681366408331838,-1.570796326792317 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark05(-0.2891185115536984,-47.408053015735696,0.30468178542544055 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark05(-0.2896913710723225,-84.82300164692448,0.621088915042591 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark05(-0.2906288739584266,-97.68423509442032,3.1420809604426774 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark05(-0.29080854793161215,-1084.1334958122336,91.2158040032057 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark05(-0.29083158700953504,-10.283414326920862,-65.64880034437269 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark05(-0.29087886095924687,-73.1835755811932,10.53155961830356 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark05(-0.29138708703470223,-1.3997881098445615,44.20208657143282 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark05(-0.2915559964100394,-1.503092160532589,-90.79633871008843 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark05(-0.2923834107632613,-0.5378697012085883,-78.43592274788857 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark05(-0.2935065803822071,-1.46925596171738,66.35291294159732 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark05(-0.29355087597280083,-2.220446049250313E-16,-36.07217432667375 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark05(-0.29426998281723393,-1.5707963267948957,-100.0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark05(-0.2950432420039171,2.1684043449710089E-19,41.97156960107279 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark05(-0.29518375381603157,-16.00698039007616,10.478609395077948 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark05(-0.295242000601682,-67.06695137874806,-1.5707963267948966 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark05(-0.29659754205757205,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark05(-0.2967006467106495,-48.453423371508386,44.2393398592743 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark05(-0.29704737777537044,-1.5707963267948966,-33.2013518934047 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark05(-0.297269999638086,-41.3174075079265,-9.797136563545877 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark05(-0.2978687180245604,-16.047676987310833,1.5707963267948966 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark05(0.2994620127020283,-0.6737906656075767,0.1134654688082371 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark05(-0.2994688503805967,-0.039128911544828004,26.703537555513243 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark05(-0.3006704376381466,-0.25231214115449774,159.13894229158944 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark05(-0.30068038774551314,-0.5252285720068343,-42.80678697592319 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark05(-0.3010021579759866,-1.5707963267948961,50.71115915967294 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark05(-0.3016032100342503,-1.5707963267948966,-58.80056777344117 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark05(-0.30199414074826947,-1.570796326806158,46.59138572547967 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark05(-0.302504622410913,-1.5707963267948966,50.576289441066216 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark05(-0.3025102320704356,-1.075416154131539,-572.7640264284435 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark05(-0.3027010330121179,-1.3129466871536708,-0.5026736825978446 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark05(-0.3038515579458476,-1.5707963267948968,-21.457523449869583 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark05(0.30435180946390783,-1.5707963267948966,-148.63181631244436 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark05(-0.30469518117555167,-10.14994377426493,16.646592219568547 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark05(0.30523189671162665,-1.570796326794896,-17.967150067436748 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark05(-0.3052674821692257,-16.550355537160023,-1.5707963267948963 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark05(-0.305522234383942,-160.77571177000502,48.76058520348852 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark05(-0.3057737920862224,-1.1462825695618688,-77.25855211421553 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark05(-0.3058957307202155,-98.24477395284136,1.5707963267949197 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark05(-0.3063174521731442,-594.5642798369223,22.634119849797784 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark05(-0.30691612293469145,-1.5707963267948428,1.5707963267948966 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark05(-0.30764144342173605,-1.4027957539103684,-72.95969275739876 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark05(-0.3078020507438303,-60.856983204102434,0.8878344566020095 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark05(-0.30805310319311174,-41.58817151931257,89.53539062730911 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark05(-0.30919999506769,-1.5707963267948966,9.481581808393951 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark05(-0.3097166311096113,-69.50046607420377,-66.50219927029406 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark05(-0.3104350022243806,-1.5534151276477532,0.8422863680025999 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark05(-0.3107967271656029,-61.11710694826889,-80.93616519897174 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark05(-0.3108897804803198,-3.145267183267971,-90.31181461709895 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark05(-0.3111128097852592,-0.46373220228031187,10.496105805299509 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark05(-0.31155041411092843,-35.64214935967124,-1.5707963267948948 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark05(-0.31189002341558614,-66.40043294114369,56.29036186440163 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark05(-0.3119898607945465,-4.064474237058929,0.2131404820327097 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark05(-0.31239849087335647,-0.24093935044372217,12.56637096258977 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark05(-0.31281123075938133,-129.78957453429717,-37.35130351211836 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark05(-0.31291139384512534,-1.562073540616861,1.2924697071141057E-26 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark05(-0.31295076191128274,-1.570796326794749,-1.5707963267948966 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark05(-0.3129772131137877,-1.3869765014714088,-56.189181234686004 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark05(-0.31409927117142117,-3.5857207048831534,4.35656997058796 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark05(-0.3142620173701034,-78.882738461864,73.99702397898201 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark05(-0.31451732340107724,-1.5707963267948966,-79.07923213026764 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark05(-0.3146491931235622,-0.35987899211271496,78.54382212543504 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark05(-0.3148451820118092,-224.41987038483717,3.1416216098212013 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark05(-0.31492312328368194,-3.266592653591197,51.1479680563034 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark05(-0.3151092784314689,-1.5707963267948966,-50.63229156384157 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark05(-0.31565022064543236,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark05(-0.31588413193426845,-1.5707963267948966,-76.17362230739036 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark05(-0.316286843837743,-29.140125300649174,-1.5707963267948966 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark05(-0.316368128266447,-3.3920027800816257,-1.5707963267948983 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark05(-0.31698302796674227,-61.03502160705312,0.0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark05(-0.31701797713058444,-0.005560404918969432,-1.122775090843157 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark05(-0.31717354785614305,-1.5707963267948966,77.37917293790625 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark05(-0.31726774371270916,-0.5701313644256217,88.31544212416432 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark05(-0.31736955860479865,-16.0434412628553,1.5707963267948912 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark05(-0.3175772402626859,-0.31772996974266043,-31.080753705377155 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark05(-0.3181447038841162,-54.807275169377334,27.92463277157284 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark05(-0.3181568546280744,-0.2652874503733532,8.111646953622342 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark05(-0.31935014871675804,-79.15783245009558,-1.5707963267948966 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark05(-0.31936538616864846,-98.08038817139906,1.3809448967556461 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark05(-0.3194854989897804,-0.9386167543790864,-32.16892616924255 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark05(-0.31958451700550017,-0.34044234932026285,-35.31015291549343 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark05(-0.31961624991359133,-1.230910286343076,-10.89367252947255 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark05(0.319967942673803,-0.001391538647359157,180.06613341820452 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark05(-0.3201475229486528,-1.5707963267948912,144.9678471523216 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark05(-0.32094426057368924,-1.5707963267948966,0.313955835595555 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark05(-0.32132853662376515,-54.48091543275363,53.30083982779252 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark05(-0.3225854947598992,-0.4207291062084858,0.0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark05(-0.3231572240629681,-7.703719777548943E-34,-78.25160005504154 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark05(-0.32374719518635753,-1.0836592024589038,21.489615114367275 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark05(-0.3239180164076434,-47.565916656484156,1.5707963267178338 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark05(-0.32395251335957154,-1.5707963267948934,0.03508892811332066 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark05(-0.3242337576916612,-1.5707963267948966,-12.600322581940866 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark05(-0.32436140091515064,-0.3774927338168433,-0.5582639752436672 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark05(-0.32439769981619504,-86.10140479872457,-73.052715206534 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark05(-0.32488390565029984,-0.866167754741106,0.13750682660275854 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark05(-0.32540154351760925,-66.8857420954748,55.21289700195447 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark05(0.3263088756560458,-29.75391171018418,-79.87831577700429 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark05(-0.3265330792417588,-1.5707963267948966,-9.562203248815286E-4 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark05(-0.3267331848674701,-35.878363826832704,4.141592653610839 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark05(-0.32700703204169634,-0.5566941393389434,20.801854180971333 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark05(-0.327286825894677,-66.70750911989906,98.77904860060539 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark05(-0.32779514543353383,-1.5707963267948963,83.44563916130315 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark05(-0.32793175608640185,-1.2262144676539077,50.1702128368882 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark05(-0.32811151383344705,-65.97350676491074,-68.58575077587288 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark05(-0.3286818650862724,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark05(-0.32868298480447994,-4.257412743175323,-42.24034681707947 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark05(-0.3289512905721171,-0.2242360575514107,8.10398163507408 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark05(-0.32903583222649524,-1.5405581736167493,99.50490150459242 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark05(-0.32903889758283356,-0.9082590318445583,21.78914662292219 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark05(-0.329411230352155,-54.93137057071537,-52.559990225908315 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark05(-0.33047779770485874,-4.310972409801459,-85.26501864853515 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark05(-0.33081206583769796,-1.5707963267948966,-61.102243081748824 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark05(-0.3309969348318764,-47.52957972961971,2.288456563867072 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark05(-0.33118016071309586,-72.44635206993853,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark05(-0.3312717203223343,-15.983505584758163,-4.301154883620374 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark05(-0.3314964243986793,-0.06314667552908133,0.0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark05(-0.33167369991052936,-1.5707963267948966,-56.92263743694848 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark05(-0.33213660171945913,-1.5707963033654462,-29.055719235833806 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark05(-0.33294974683676165,-3.1522799316429984,-169.19738406881194 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark05(-0.3339903588362816,-41.60435053650729,64.21324067265547 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark05(-0.3341256492820286,-1.5707963265287035,-95.95369503984162 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark05(-0.3342501720878017,-0.5058265179660826,26.452191993014985 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark05(-0.33427471413848653,-10.184106884530781,-78.47748400310209 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark05(-0.33494312466316273,-1.487500069105902,84.60707035675075 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark05(-0.33558970824222545,-60.97674427505649,-72.05033781694057 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark05(-0.3361373818055275,-0.2989589281137729,20.587447386705843 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark05(-0.3362651160105977,-3.1416597085084748,1.1193935530656631 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark05(-0.3363606772021186,-1.5707963267948966,0.6794825719928717 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark05(-0.336457217760011,-0.04887924300686105,-1.575061303058794E-8 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark05(-0.33732331475378663,-1.2233960707179492,55.279552376478 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark05(-0.3375863141080238,-40.89058527828211,92.49161263195495 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark05(-0.3376047995476943,-42.34468611325859,-15.723588281648649 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark05(-0.3388013407154622,-0.009195986128017896,28.234954727492408 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark05(-0.33885279061444123,-0.20659157253449653,358.22182590835087 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark05(-0.3388979051311437,-6.497131103528062E-114,65.51037026890997 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark05(-0.33911217481836087,-98.05599045283215,23.525957141178736 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark05(-0.3395541664043291,-1.5707963265430958,84.5288931835111 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark05(-0.3398871833029768,-1.5707963267948966,-1.5707963147953063 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark05(-0.3399666516663191,-41.53616897841957,95.40040922182288 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark05(-0.3402343741622582,-42.23587681747985,15.908642908744014 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark05(-0.3406485271898685,-1.5707963267948961,54.450300720242126 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark05(-0.3408944226571078,-1.4769438671065842,-51.61738089748387 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark05(-0.341246505160938,-98.1865441200104,-7.853981637424168 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark05(-0.34242966899246596,-1.5707963267948912,-21.972432425714757 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark05(-0.3432330209622394,-1.5707963267948966,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark05(-0.34327945707333773,-1.5707963267948966,-97.71373285638852 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark05(-0.34383835060943146,-1.5707963267948966,47.65506585190301 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark05(-0.3449255877402574,3.3087224502121107E-24,-14.375762282421114 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark05(-0.3450432593799714,-1.5707963267948948,-1.5707963267948948 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark05(-0.3450871245954561,-3.8097163028916965,-0.0018885240256185042 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark05(-0.34528608152887785,-3.1416870944797073,-26.821315519421006 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark05(-0.3457328223233631,-41.50599684686142,26.630830491632672 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark05(-0.3461377205872096,-1.5707963267948966,54.84639884986073 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark05(-0.34661142159655556,-1.4892500264431616,-6.298810374742246 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark05(-0.3467822889961815,-73.04521705378531,1.5707963267949054 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark05(-0.3474152349783317,-1.314709768377932,-1.5707963267948983 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark05(-0.3482453129977472,-1.5707963267948974,26.13166503597067 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark05(-0.3491501313122182,-36.01274458925412,1.570796326794896 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark05(-0.34945770205465654,-1.5707963267948613,55.68215683736033 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark05(-0.34959019490366317,-60.937174736878404,-65.40415550184605 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark05(-0.3496344434189806,3.1415942832336983,-0.9275575653239787 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark05(-0.3496385248478194,-28.609309399347296,-1.5707963267948966 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark05(-0.34990294257008336,14.532889704174963,-0.2693894621074605 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark05(-0.3499597929168845,-60.36733491457198,-53.634856367286474 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark05(-0.3500411865403375,-35.0273001636902,-139.83226864945027 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark05(-0.3503000342750065,-1.5707963267948966,-37.865518768666 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark05(-0.350344222509249,-1.5707963267948966,84.62710811137245 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark05(-0.3510983996964954,-1.570796326383178,34.22636135068579 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark05(-0.35120182366812325,-2.220446049250313E-16,-1.016464269932429 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark05(-0.3513482410596404,-1.0907612891992216,78.8216237660074 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark05(-0.351477824622305,-0.48294735640277153,59.64114083908345 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark05(-0.35187008915397544,-1.4780317786446895,8.104078248851769 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark05(-0.35212999238084797,-141.47150508068415,-95.82530119672421 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark05(-0.35223708846399904,-463.1188849512167,90.01364797523135 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark05(-0.3527407180147156,-0.0015214910678785498,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark05(-0.352861118051392,-1.5707963267948966,-58.04155311445813 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark05(-0.35345256381190243,-1.5707963267948966,68.62511810331375 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark05(-0.35347903729718055,-1.5707963267948963,5.4795233725210076E-194 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark05(-0.3535683741675546,-1.5707963267948966,69.38478505700493 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark05(0.3537640153868068,-0.03666121086286183,74.24104649378683 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark05(-0.35380874781070815,-48.68300113463213,1.5707963267948966 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark05(0.35393359349233033,-1.0104877090112099,-42.307624133075706 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark05(-0.3544530227236299,-3.1435749861643143,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark05(-0.35477704137091326,-1.5707963267948966,-82.2509142795875 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark05(-0.35486829056758573,-1.5707963267948966,-38.107724831581805 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark05(-0.355676876927542,-128.83182771407272,-35.43109823003829 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark05(-0.35677210359388056,-1.1825876895714504,1.5707963267949054 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark05(-0.35746757536635587,-53.95892714766883,-92.3211200061361 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark05(-0.35769200455408495,-1.5707963267948983,17.40010447236486 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark05(-0.3581650901363,-0.3855806439752491,33.88869650237138 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark05(-0.35829856431307316,-1.329472301945445,-112.90938065567755 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark05(-0.358350554967927,-73.24723011360074,-39.10687124224295 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark05(-0.3587754923881861,-54.571501632995705,132.44079039557602 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark05(-0.35905916103830676,-73.19550703110457,-59.18547764074946 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark05(-0.3592013940364835,-66.21178624865982,-1.7365302730352168E-164 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark05(-0.35946323824490145,-1.3281003849645945,-41.494437475058234 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark05(-0.35980013524912624,-1.5707963267948966,42.0985140378646 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark05(-0.35994248727088274,-98.52393757381088,-1.5707963267948966 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark05(-0.36021288569616516,-1.5686787092530432,11.256094708985149 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark05(-0.3603271643604198,-48.38852729798,99.72315578586795 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark05(-0.3607027717850997,-142.5694995455492,-60.10813112587324 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark05(-0.3609974872945969,-53.95753299064207,-42.90180510109121 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark05(-0.36192488397670325,-0.9605710043040631,-12.224979724456846 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark05(-0.3620371759935268,-1.5707963267948961,-40.88546485345233 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark05(-0.3628515774155865,-1.5707963267948966,-25.976877031957212 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark05(-0.3629260150413929,-1.5707963267948966,72.66544082720752 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark05(-0.3634013998581403,-0.16624545182551037,0.0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark05(-0.3636786763063924,-0.019057651896884565,42.921993656148516 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark05(-0.3638277162839388,-0.0314464067205831,1.880641328044021 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark05(-0.3640250528462126,-1.5707963267948966,36.109085033506034 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark05(-0.3644832258723252,-1.5707963267948966,26.037937349859575 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark05(-0.3654952495916027,-41.77772296684398,76.16163617898111 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark05(-0.36551596769199923,-1.5707963267948966,-11.096288937577238 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark05(-0.3658101286116141,-1.3877787807814457E-17,-0.0076380816952177355 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark05(-0.3660710884727381,-1.5707963267946379,100.0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark05(-0.366190783679145,-1.5707963267948966,-84.47992343055535 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark05(-0.36636173631725444,-35.13746444384586,117.92961565866142 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark05(0.3668679062351531,5.421010862427522E-20,61.153038085881256 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark05(-0.3669290395040232,-1.5707963267948966,-31.154010277328723 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark05(-0.36771119563838167,-0.05923054375687897,4.809733010386975 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark05(-0.3681935980731118,-1.5707963267948952,-84.43088459349222 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark05(-0.36852641605335656,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark05(-0.36853225601217154,-61.07413314318442,27.86472630533534 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark05(-0.36862598154528564,-78.85119431549745,-76.77129790262723 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark05(-0.3688076995053109,-1.570796326794877,-55.33091852699538 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark05(-0.3696368911305786,-1.5707963267948966,7.257821274408292 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark05(-0.36973662407705254,-48.68614642454895,-90.81847698859681 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark05(-0.36997629142188204,-0.4353215311783448,174.35861207238526 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark05(-0.3705749323339873,-72.41008542307115,-100.0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark05(-0.370744968203936,-117.41004229941394,55.482832069457935 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark05(-0.37089063921614085,-0.36796292766448346,71.57773839115063 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark05(-0.3710559071586191,-0.4227871861313504,-133.91779158082215 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark05(-0.37177743732079094,-3.5546775920010116,-26.23818785939146 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark05(-0.3718156216215929,-1.5707963267948966,82.52721314605328 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark05(-0.3722164890203372,-1.5707963267948966,90.6360534891425 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark05(-0.37238849729430207,-1.5707963267948966,-10.539568517255557 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark05(-0.3728233474870759,-0.2766577051178288,45.459194789204204 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark05(-0.3731998348619452,-1.570796312598278,-1.5707963267948966 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark05(-0.373348934501328,-3.141600344467743,-1.4967523420708984 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark05(-0.37365347606247545,-1.4330142570975983,29.911465644710375 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark05(-0.37404034191420893,-3.141592654355844,93.07054558964263 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark05(-0.3741566835215879,-1.5707963267948966,-37.6991118446179 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark05(-0.37484153984821234,-41.71590716204343,-0.08651825852239192 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark05(-0.37564459009438167,-154.0303019190723,31.43886210328833 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark05(-0.37585413230714304,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark05(-0.3763414807330947,-1.41789786385349,111.84367843370521 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark05(-0.3769552978271081,-1.547739722113729,1.5707963267948966 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark05(-0.37822851666664276,-3.2717552593524393,-60.70971785863284 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark05(-0.37892482979175923,-1.223818507948324,-85.24010181871839 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark05(-0.379558492370339,-6.359756853414292E-4,0.0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark05(-0.38033032887015583,-0.7119336509204741,1.5707963267948966 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark05(-0.3803776573918477,-1.3425989186450806,56.88338527377846 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark05(0.3806693887779419,14.4309983702055,-19.36794364526351 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark05(-0.3807696378580876,-41.78353369871577,78.10177226210985 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark05(-0.38115668763336563,-67.18286610894376,-1.5707963267948966 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark05(-0.3811859579043057,-1.1776989164409921,503.96331079331173 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark05(-0.3828561682820679,-61.21287591452264,8.10398189052661 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark05(-0.38308139905065275,-72.58276294802299,-56.402190221930496 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark05(-0.3840617213593518,-35.1748485506004,-127.09308033044154 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark05(-0.38485518350393316,-111.47497615812303,-98.20403160067872 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark05(-0.3849908315800216,-1.3181172236906433,-55.074580743640254 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark05(-0.38526459087823867,-0.08168076894882956,-53.962044073720655 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark05(-0.38529120262680294,-16.107813759478432,-183.21471184119616 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark05(-0.38562077830157193,-1.5707963267948966,70.71579568341937 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark05(-0.3858936109594402,-0.8170374498284227,98.23853701340649 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark05(-0.38625727188747394,-73.20871457535054,-66.71586009925646 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark05(-0.3864189032830696,-0.11714351086558994,-1.5707963267948966 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark05(-0.38757211506636097,-0.1888911415647519,-1.119858056105238 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark05(-0.38807646299415993,-3.1494051535903917,-66.04473756887296 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark05(-0.38876377165251413,-66.26700577733294,65.60116268400589 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark05(-0.3887803775843751,-1.5707963267948966,6.5839565277576115 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark05(-0.3891177803812063,-85.26959834193838,-42.57616566031975 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark05(-0.3894616838384332,-98.22212077085113,362.4276142535603 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark05(-0.3905249997428796,-1.0770930164967982,34.091444944418754 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark05(-0.39101382752562014,-35.89487716451267,-1.5707963267948966 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark05(-0.39115874841632264,-3.1415926535970695,-1.5730036628546449 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark05(-0.3922286659566936,-53.65004684460382,-89.23191465255555 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark05(-0.3925973570759299,-15.882429608454899,78.9818575323111 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark05(-0.3926393689145158,-9.590909196167244,118.10752129720052 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark05(-0.3932803556357216,-0.5625265060462304,46.79059180762158 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark05(-0.3936325171631297,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark05(-0.39417829708974284,-1.5707963267948966,11.630903696379022 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark05(-0.39510858823440476,1.922701587099257,-89.97098157941159 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark05(-0.3952656534401193,-0.1209168914579486,203.20279411405068 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark05(-0.3957147389530159,-0.5193756499054192,-6.283257054831725 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark05(-0.39597012512160934,-1.5707798004576983,-1.4179623506538332 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark05(-0.3961940460906864,-61.18091846947299,-1.5707963267948912 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark05(-0.3973660385268205,-1.5707963267948966,648.4917479930263 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark05(-0.397637039438397,-1.5707963267948912,-90.4288308369457 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark05(-0.39798262070619517,-34.70672417846984,-72.63310372118698 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark05(-0.3990517756490477,-41.60120719516766,0.7834858927612534 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark05(-0.39905391478409286,-60.902094069828664,3.3943016868860774 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark05(-0.399086706957089,-3.801396171065431,0.0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark05(-0.3993356023272767,-1.5707963267948966,-327.58457048576986 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark05(-0.3996516744651327,-1.5707961155022863,71.34667527957863 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark05(-0.3999597129140839,-1.5707963267948963,-6.2881916497462225 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark05(-0.4001237795739268,-154.78742005978552,-8.421188409019663 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark05(-0.4006439090960381,-3.2462374352390784,-29.299380171367815 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark05(-0.4009980393467556,-41.93920392843131,146.3137638773938 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark05(-0.4010628855697582,-5.293955920339377E-23,-42.10972903486892 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark05(-0.401211215369867,-1.5707963267948983,-90.07577846648145 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark05(-0.401798014751379,-48.39896535788323,-25.57068942993902 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark05(-0.4030653859952947,4.357089281467525,-98.16757633251443 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark05(-0.4031344338642977,-1.5707963267948966,24.373260416080736 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark05(-0.4032431602703155,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark05(-0.4037242213953234,-91.25100355022934,-1.5707963267948966 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark05(-0.40421152395440185,-35.203567870955425,0.0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark05(-0.4052602994479537,-1.5707963267948966,146.20772390292936 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark05(-0.4056266212296691,-1.5212739957881216,4.141603107334409 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark05(-0.40590558026520474,-36.013275633477036,35.06383478544517 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark05(-0.40619736275293294,-2.220446049250313E-16,57.86968332839362 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark05(-0.4069076933733478,-1.5707963267948966,-1.5707963267949054 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark05(-0.4083190933184335,-41.95739717632334,31.513036233279117 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark05(-0.40846797798671786,-4.1755973694987614E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark05(-0.4108907788949781,-1.5707963267948966,-5.720141799708742 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark05(-0.41111752307004273,-0.7904115468282235,1.5707963267948963 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark05(-0.41118234364204176,-1.5707963267948966,92.82408435878286 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark05(-0.4126487345064831,-1.5707963267948966,-11.642886689245406 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark05(-0.41269417538802294,-1.5707963267948966,57.55866209190995 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark05(-0.4128158946098558,-53.854050195886856,-48.4818699106148 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark05(-0.4134600028173774,-1.5707963267948966,-6.283439861604986 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark05(-0.414707618036422,-98.24061523955507,-61.1031692923927 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark05(-0.4148646256056272,-22.574901908121184,-1.5707963267948948 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark05(-0.4151874670200806,-41.837762788617795,-98.8986778186646 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark05(-0.41591413493954615,-42.05866654852628,147.22803877950034 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark05(-0.4168497354883369,-66.5567219383347,16.89217398899779 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark05(-0.41687570144844127,-1.216088590494495,41.23018152785488 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark05(-0.417257682147838,-4.0864865178241985,-183.5642339669503 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark05(-0.4174947773746043,-1.5707963267948966,-12.850434632877466 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark05(-0.4180172952421474,-3.1416002935390948,0.0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark05(-0.4187411850519927,-47.12486638544939,-61.05084004625505 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark05(-0.42028868506550043,-41.064650333473566,-26.10411470221466 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark05(-0.4203000248082229,-28.28727323628624,-20.631267289820272 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark05(-0.4203096805053942,-0.25464343859257776,78.73299769350155 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark05(-0.420779509650252,-1.5564574477695965,-0.33522674362769067 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark05(-0.4208719427775792,-0.4416193584911987,85.61793540927579 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark05(-0.4208906364183458,-1.5707963267948948,-58.69454012527845 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark05(-0.4209103660734313,-42.09465239642277,28.06113340294172 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark05(-0.42117854967652646,-84.85425164695528,-22.97784196078105 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark05(-0.42140837622912175,1.7250249970823334E-8,63.90520230718417 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark05(-0.4218036528353336,-1.5707963267949019,-27.98161284813534 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark05(-0.4219471650452258,-80.05833131324002,-10.206247566264004 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark05(-0.42208426724817594,-73.3339256434566,-28.63383346935997 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark05(-0.42212773203833065,-1.570796326777722,-55.31435616179452 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark05(-0.4225912956383082,-85.0366356592791,-89.99413194439975 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark05(-0.42343529674632047,-15.886507777599483,1.5707963267948966 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark05(-0.42346901528291325,-0.16547018661095947,67.83627581383041 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark05(-0.42348465715520633,-41.43216481135945,-1.5707963267948912 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark05(-0.42360732170556137,-1.5707963267948966,-33.34728561573057 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark05(-0.4236282677565782,-98.16959154600231,-63.44972066353396 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark05(-0.4238837435715045,-9.97774076332658,8.354290841033787 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark05(-0.42419242736621904,-167.58478883784232,49.878753127255806 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark05(-0.42570137853857926,-73.17904410810632,-37.79537967614232 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark05(-0.4265721919123533,4.141592653589801,1.5707963267948983 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark05(-0.42681151132367834,-72.81552455624269,48.79445596672961 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark05(-0.42757537514630617,-1.0180257594019189,-45.37515736210232 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark05(-0.42787727571528783,-60.83122609991949,86.39379797371932 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark05(-0.42829474381378985,-66.98254134763494,-56.083666617988136 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark05(-0.4286986128676829,-3.4080366107260116,15.513510528873354 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark05(-0.4293974846751749,-1.5707963267948966,-37.1849323699635 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark05(-0.4308061628190165,-1.5707963267948966,-38.74212646462405 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark05(-0.4309693062445348,-4.052069852915125,28.109144800518486 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark05(-0.43136733918728787,-1.532574350698879,26.118779844917256 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark05(-0.43188097815607185,-1.5707963267948963,45.04224464434867 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark05(-0.4321403165900393,-0.9936659854589037,-14.13734633572121 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark05(-0.43297079484850115,-1.5707963267948966,-91.10618369122837 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark05(-0.4329755951505605,-4.346472877540933,-53.56125246101701 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark05(-0.4330096424668006,-1.7763568394002505E-15,-62.80971522438483 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark05(-0.4330287799905417,-1.5707963267948966,6.283201373577803 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark05(-0.43305409534318695,-0.9382861320372229,26.703537555513243 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark05(-0.43357640312919987,-1.5707963267948966,-90.04206253687869 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark05(-0.4340099767690018,-1.5707963267948966,56.070815964125565 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark05(-0.43436688027944453,-1.1192576655720459,22.291113139658478 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark05(-0.43502649189564446,-1.4789988508896201,86.59208477590738 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark05(-0.4351017740874813,-1.5707963267948966,38.13395349794078 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark05(-0.43548146403474397,-47.39174686434788,35.33199826178725 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark05(-0.4356196503917807,-2.194735531241227E-15,1.5707963267948966 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark05(-0.43608143186477977,-61.135283893268856,-1040.7314013242442 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark05(-0.43661234193159526,-1.5707963267948966,7.5589972380033 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark05(-0.43796875025862214,-1.5707963267948966,-51.00782748294498 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark05(-0.43881438064793343,-66.32696701487743,-0.18618268331544297 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark05(-0.43929522879923977,-1.5707963267948934,-37.24151310995643 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark05(-0.43994347504723536,-0.8005434955325351,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark05(-0.44084618481659277,-66.52743731797953,-16.902748951526817 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark05(-0.44170786295357367,-0.5923278000239905,-48.697137622067245 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark05(-0.4418221836123166,-10.20803742907207,-96.05421746237181 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark05(-0.44182396253294876,-1.5707963267948966,87.21989887196321 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark05(-0.4419015420211913,-5.2757017179932544E-18,-71.68706614532232 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark05(-0.4427924618951044,-1.5707963267948948,1.5707963267948966 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark05(-0.44296436602632216,-9.569466050022865E-26,-96.28995992845888 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark05(-0.44393031588633053,-47.34856265015219,0.0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark05(-0.44632151909748413,-1.5707963267948957,-85.90053131747842 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark05(-0.446800915512196,-3.157217653606321,-54.72574263741032 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark05(0.4468468010377363,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark05(0.44698143925311246,-53.749342670894535,-0.5553151944661221 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark05(-0.4479609351706167,-3.267807459478572,-0.23318016028446564 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark05(-0.44820924859283207,-36.1067751390099,77.17363320094995 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark05(-0.4483765638568132,-29.48253961894071,-16.52582942285366 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark05(-0.4488617649761425,-1.7763568394002505E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark05(-0.44905203531135796,-1.1602678501658044,64.42290671261337 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark05(-0.4492536610632136,-708.1292316346766,-12.279653330867944 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark05(-0.4507320361123668,-3.894289103679526,-31.23498316826309 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark05(0.4509676316561543,-0.617552856824023,22.89036734525321 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark05(-0.4518869586640847,-28.364753968165786,-9.792726848433281 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark05(-0.45198857551967253,-1.5707963267948966,49.652595537850004 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark05(-0.4526418259257621,-0.7461955056170924,32.428879843145836 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark05(-0.4534863596273754,-67.92228122632591,84.61669950045184 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark05(0.45394286991508165,-1.2324009305919061,20.66721445010012 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark05(-0.45484575239208624,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark05(-0.4548892112029561,-0.5738471290357654,-44.09214008960969 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark05(-0.4551082009700873,-1.109220569436907,181.9015146714894 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark05(-0.45567401638365823,-3.9902529081712714,1.4354297881803115 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark05(-0.45625152441836825,-48.32176907024812,-100.0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark05(-0.4565346736526267,-0.5267712794028947,100.0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark05(-0.45717510140821915,-499.53796117318933,-0.13748120493515614 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark05(-0.4576143421820973,-0.35171564291204116,-1.5707963267948974 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark05(-0.4585662706300643,-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark05(-0.4591557393494732,-61.03467698802286,49.57042087610856 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark05(-0.4592399746542336,-1.5707963267948966,-36.69218507476011 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark05(-0.4598248297398905,-34.86280864562966,-10.849394074415672 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark05(-0.45993051806126317,-28.71030182742389,-1.5707963267948983 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark05(-0.45999212255695365,-3.552713678800501E-15,0.0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark05(-0.4603141577767129,-34.91779145479674,-25.132756997653917 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark05(-0.46092896575374853,-35.59016613590272,-6.53318530717963 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark05(-0.4613437016290201,-1.5707963267948966,13.532265303829618 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark05(-0.46157369629020206,-0.7585693160526201,764.9438463833496 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark05(-0.4620151006852573,-1.5707963267948966,-1.7449879728058448 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark05(-0.46227510452568493,-1.5707963267948963,20.246923357531763 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark05(-0.46311671435338475,-1.5707963267948966,1.5707964886845542 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark05(-0.464448967976138,-9.487278375691991,-1.5707963267948983 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark05(-0.46474864580227404,-42.40774530462603,50.08312115376728 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark05(-0.4649261279651262,-1.5707963267948966,-38.12324972168009 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark05(-0.4653662484734169,-0.2065141268736035,-47.91450681078318 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark05(-0.46668646670040315,-1.4576435715789045,31.54036847338594 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark05(-0.4678699089400937,-72.85857686864887,64.36430231084248 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark05(-0.4681108736152445,-22.48871191045832,1.5707963267948966 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark05(-0.4683051756231341,-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark05(-0.4686102444775695,-1.5189946377739536,-69.8319580290862 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark05(-0.4690528514706702,-66.31955652225511,-57.93661561105546 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark05(-0.4693575158226749,-1.5707963267948966,14.3277892125532 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark05(-0.46944270476409855,-1.47052895283732,42.68682678473269 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark05(-0.4702658923566485,-10.64089560708392,-0.18474113765574995 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark05(-0.4705863939087498,-0.5014305179447823,1.5707963267948983 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark05(-0.47077687948336333,-16.108403595064487,-83.19855729130337 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark05(-0.4711695675398375,-0.23109275471432866,-61.12326888631163 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark05(-0.47143585788271214,-1.5707963267948966,-51.79475767688972 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark05(-0.47146838857090856,-0.03731972061594038,5.310512105894325 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark05(-0.47192298408864547,-1.5707963267948966,34.855235509183935 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark05(-0.4721910194339217,-28.359432278043528,1.5707963267948983 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark05(-0.4724431046449489,-1.5707963267948966,52.42297037299967 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark05(-0.47313589462480365,-4.278287073621389,-418.2796292835981 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark05(-0.4737156060907075,-130.26441512098546,-42.89843676419426 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark05(-0.4740838087683649,-40.984583817855615,168.075753918814 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark05(-0.4749592636861846,-1.5707963267948915,0.0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark05(-0.47586388937324653,-41.86702561161037,100.0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark05(-0.476445125179261,-1.5707963267948966,-0.11578068413574683 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark05(-0.4765211591092303,-0.30481985250437804,-57.951228590906034 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark05(-0.4780249679460699,-61.25627085617822,8.103981649905455 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark05(-0.4786644439561769,-161.06087230160966,0.0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark05(-0.4790532667089593,-1.5707963267948983,-2542.811358243569 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark05(-0.479706531666956,-35.4834674385324,-68.24984703453931 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark05(-0.48040240000963197,-3.1416002829907175,-6.858495145087943 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark05(-0.4804554218213869,-0.32691334660851895,-19.683843694059846 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark05(-0.48054498889160324,4.141631206618119,-0.9838127195509252 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark05(-0.48120295506721944,-0.021114988468663526,-777.0096019819862 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark05(-0.4814482401634356,-1.5707963267948966,50.55984473623434 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark05(-0.48247347811846764,-166.54592000311968,1.5707963267949054 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark05(-0.48272245293589433,-3.714494435042371,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark05(-0.4827535546987614,-92.49418770634165,-568.7184739271912 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark05(-0.483016220303394,-10.962095984552137,-1.5707963267948966 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark05(-0.48426016179140996,-0.001156721401662189,190.70060278402292 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark05(-0.48447260859167507,-1.5707963267948963,-47.17650903539708 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark05(-0.4847513590270598,-15.959673409728381,-42.09701940880586 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark05(-0.48549385106936427,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark05(-0.48554661351669176,-35.93022041461428,-36.14664500948552 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark05(-0.48565329643805066,-0.1976742141685689,-3.143545785260816 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark05(-0.4868474400104956,-9.543256166919324,-84.33033612764692 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark05(-0.4873937257726908,-61.01945605316232,29.55727565967078 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark05(-0.48779219200063617,-41.85214824906394,84.81314678760276 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark05(-0.48843664696186756,-1.5707963267948983,-66.97634325089909 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark05(-0.4888970816458736,-0.7554958635232591,1.5707963267948966 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark05(-0.4900926212573513,-405.81643544717923,76.59415828290136 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark05(-0.49084719226100104,-3.141678773790478,-1.4042385836967497 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark05(-0.4917511616402546,-0.3225367488025674,-27.032394259308983 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark05(-0.4924348476128535,-42.20213824958498,82.39236451501978 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark05(-0.4927895322165412,-34.86934116036362,-19.77278356603053 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark05(-0.4929116449828115,0.51987619362872,712.2822155205149 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark05(-0.49301153707799195,-78.90752840467202,-94.69582718900082 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark05(-0.49312998282546516,-0.5926136056390116,-49.99574678783342 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark05(-0.4931884281572394,-15.896998707607262,76.18228806902991 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark05(-0.49334647792537845,-1.5707963267948966,-20.42035237270077 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark05(-0.49359326144599003,-76.24468382365703,28.179459001014955 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark05(-0.49365478984562194,-664.3022689614334,55.27265897198974 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark05(-0.49366141534202956,4.141592653589795,-21.547331282463706 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark05(-0.4943391272416912,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark05(-0.49458229799441117,-1.570796326794896,21.608028918728163 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark05(-0.49481531206919604,-1.5707963267948961,18.82749072936563 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark05(-0.4953068485371692,-0.2679552665879467,27.805808658515318 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark05(-0.495588951907669,-1.5707963267948966,-10.739311208395137 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark05(-0.4957206141478271,3.2361909599734417,-1.5707963267949125 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark05(-0.4959200090085025,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark05(-0.4968020570891505,-3.3085408769989932,85.62317947501097 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark05(-0.4980839600248074,-1.552593628748274,17.09982931337482 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark05(-0.4984495542920775,-1.5707963267948948,-20.380910506920465 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark05(-0.49879926396046637,-61.026463052220414,-78.0811642833603 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark05(-0.49882017317761873,-10.05286584922273,27.96411083579344 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark05(-0.4991914301727009,-1.5707963267948983,-1.5707963267948966 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark05(-0.5026946347219633,-35.07016733766058,0.0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark05(-0.5029113239725592,-1.5707963267948966,-4.2214778377672175 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark05(-0.5040966991511527,-9.488861113002931,77.11901151483487 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark05(-0.5054238986444288,-1.4817253519479614,20.616169678581283 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark05(-0.5055325825549952,-1.3552527156068805E-20,1.5707963267948966 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark05(-0.5057088956476044,-17.009187374347857,-1.5707963267948966 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark05(-0.5059357853200941,-9.649670031808714,27.028436264491084 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark05(-0.5067647333430585,-1.5707963267948966,-44.59681242975066 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark05(-0.5072585986333099,-5.452026589839766E-23,-0.18953478410345842 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark05(-0.5075327648558932,-1.5707963267948961,-1.5707963267948966 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark05(-0.5075704404555268,-1.5437445382388286,0.0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark05(-0.5077648966045238,-7.105427357601002E-15,95.02973865678959 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark05(-0.5080690390701634,-35.75814864176216,26.711277030738685 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark05(-0.5084356467468254,-22.46601005211049,-58.87550936017925 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark05(-0.5087652020219977,-3.171761311563337,55.24606396174694 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark05(-0.5099257363581183,-1.5707963267948966,-2.010646280939531 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark05(-0.5099665966119772,-3.615137352105574,3.1504849043336005 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark05(-0.5111491084337364,2.1684043449710089E-19,-84.59087102472206 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark05(-0.5116647119409223,14.434563655990566,-87.66846086855982 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark05(-0.511904913210162,-54.414956516794824,-77.11234716655717 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark05(-0.5122666771339308,-78.74610750215837,56.443510659079806 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark05(-0.5128546500106328,-0.8169606799366783,86.38714005218381 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark05(-0.5134236224298339,-97.86622161513625,26.752832775061023 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark05(-0.5138041058370383,-15.886460080694278,44.55861073839543 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark05(-0.5145000206903241,-1.5707963267948966,-48.029673822561264 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark05(-0.5154520830184692,-1.0494988869966448,-34.861652437162675 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark05(-0.5164187179682358,-73.23247362316556,42.411500823462205 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark05(-0.5166299795052336,-3.143545778590102,-6.853525829138963 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark05(-0.5166569326163162,-0.0926972233848562,-29.663062671099752 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark05(-0.5171418499586724,6.430019447622411,1.5707963267948966 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark05(-0.5171528607742077,-53.50495876312641,-176.01636586292884 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark05(-0.5174711419798819,-5.293955920339377E-23,-1.5707963267948966 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark05(-0.5179772786243444,-73.03155925302171,-100.0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark05(-0.5188837176613019,-0.7996106400583225,-55.33552888922128 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark05(-0.519034627762208,-15.937090433393166,-8.137924211783172 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark05(-0.5194918606657775,-1.5707963267948948,-81.50200737118034 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark05(-0.5199539816706638,-1.5546456087631282,1.5707963264616798 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark05(-0.5205603063088587,-10.246767606658167,-43.159988822050146 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark05(-0.520979106910497,-8.881784197001252E-16,1.6472184286297693E-83 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark05(-0.5215551071189957,-72.48909355666956,-140.8015012003274 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark05(-0.5216362486083225,-98.64701672675984,28.565511842079815 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark05(-0.5224135741366542,-72.44467025189171,-70.2186037519811 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark05(-0.5227659756247397,-1.5707963267948966,-20.50391719240652 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark05(-0.5238165408194465,-1.5707963267948966,6.6882809230837665 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark05(-0.5248379307946811,-0.012217286297558668,24.000691595593963 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark05(-0.5254433871299682,-1.7763568394002505E-15,-31.98737785562207 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark05(-0.5257159858536603,-97.66291133312596,77.21024366685441 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark05(-0.5262034811621862,-1.2633161200191105,7.856789993339173 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark05(-0.5266726078391797,-73.75075275284689,-42.57164029453682 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark05(-0.5271613916708837,-1.5707963267948966,35.79717883301342 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark05(-0.5273157605245804,-1.5707963267948966,5.071230831664762 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark05(-0.5273219437252197,-41.45784707526035,21.514976887042764 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark05(-0.5273790669834932,-1.2770534659403405,-55.304119806078766 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark05(-0.5282233653062949,-73.20635818643642,5.503475874686983E-4 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark05(-0.5286895129547885,-1.266181410632206,97.02451311880719 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark05(-0.528691064889656,-97.84618411233326,42.69876079883693 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark05(-0.5287083354000699,-167.69777096695796,-98.86775581145528 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark05(-0.5291262389768931,-15.921943662485385,-0.6743813956749216 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark05(-0.5294010244804893,3.1494051540423036,141.8126855287896 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark05(-0.5295382592880697,-1.5707963249084256,1.1198618585031913E-15 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark05(-0.5298775809541496,-9.568645078740971,114.12836371712575 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark05(-0.5301189600907471,-0.05653845055828584,79.86009823921448 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark05(-0.5310228407089808,-22.414028930210762,-73.05128594200795 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark05(-0.5313842894721467,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark05(-0.5315107771520542,-73.49613677282412,-56.05512021239771 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark05(-0.5319776337687104,-154.00535578482493,6.283517034095382 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark05(-0.532403645287701,0.18333467396886363,88.91934517275726 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark05(-0.5327300892329877,-0.9242521011070096,-73.37830405585593 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark05(-0.5330965959326477,-4.68867206415166,-506.44752509393965 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark05(-0.5331847754063933,-1.5707963267948966,13.040378040441542 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark05(-0.5336202078447757,-1.5707963267948963,-51.02518798368263 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark05(-0.5360432370929618,-28.714553630825517,-3.1435457785899836 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark05(-0.5370331841467438,-23.126533935415154,-1.5707963267948966 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark05(-0.5374272673773156,-1.5707963267948966,136.6627520482212 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark05(-0.5382711324414606,-1.5528116627424708,90.6559196886198 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark05(-0.5389943536080632,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark05(-0.5397261439805983,-1.5707963267948957,-45.63599285807611 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark05(-0.54044760568883,-1.5707963267948912,44.92214000401401 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark05(-0.5411046040290072,-97.97252775106224,22.913833841515043 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark05(-0.5414777134527232,-1.5707963267948983,1.5707963267948966 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark05(-0.5416699465187739,-5.551115123125783E-17,-47.53628238607622 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark05(-0.5430363397727199,-1.5707963267948966,-0.034391111901846516 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark05(-0.5438100299537745,-1.5707963267948948,1.5707963267948966 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark05(-0.5438455370730708,-53.61365523881666,-54.15436411634685 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark05(-0.5444165961665042,-41.103274331276495,-85.75198600347466 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark05(-0.5446479790753062,-0.8705714415524262,41.13959197366104 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark05(-0.5453685728399158,-1.5707963267948966,-50.27031121725618 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark05(-0.545410552650064,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark05(-0.5470406314831263,3.1420809552730433,1.5707963267948966 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark05(-0.5473004970248244,-0.23339921173052147,59.635565569616034 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark05(-0.5479093195161827,-0.3820371716531852,43.858302549124716 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark05(-0.5497363416008754,-35.754762473216296,55.40889339058208 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark05(-0.5502037084818377,-0.6478801512589866,3.266592657341968 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark05(-0.5504105657831169,-9.549422286582228,0.0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark05(-0.5508958545693675,-1.5707963267948966,-51.71811752630136 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark05(-0.5512450543155892,-1.5707963267948983,-27.116934456018654 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark05(-0.5521178589022347,-9.514749074987819,-32.87429775921437 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark05(-0.5523411341427443,-10.160080812008204,-13.987152129510179 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark05(-0.553228716531847,-1.4479929768558302,71.80152228125755 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark05(-0.5537074038456837,-4.01774406558452,-580.5765281705343 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark05(-0.5537320467808371,-1.1144567988491474,-65.57506509641914 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark05(-0.5540164581076479,-0.055322871559366715,14.137401341438762 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark05(-0.5561346525102948,-155.31849667824864,3.099186590264736 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark05(-0.5562524622425317,-3.2665926554189433,1.5707963267948966 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark05(-0.556498723393003,-123.37222331805079,-135.38514039478682 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark05(-0.5565566554212932,-3.1415929485675096,112.03819525788984 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark05(-0.556931160268898,-10.612960743085926,-73.55337735196255 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark05(-0.5570127072134823,-0.693172679100494,-35.72277181484549 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark05(-0.5571181707960978,-1.5707963267948983,1.5707963267948983 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark05(-0.5575058423748369,-1.3432868013930204,38.36771977577929 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark05(-0.5576600180043696,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark05(-0.5578873610229134,0.5141540010410439,-55.71639004513881 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark05(-0.5585970472412001,-1.5707963267948966,47.17557443825227 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark05(-0.5606870123307043,-2.220446049250313E-16,0.0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark05(-0.5608400122735419,-42.00145178139434,42.764542191634 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark05(-0.5617090315294455,-84.91876538127771,-1.5707963267948968 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark05(-0.5619710466530605,-0.12359789627819551,-78.79000199784696 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark05(-0.5630040430873784,-98.59793153216748,-28.736032579802824 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark05(-0.5632416477655587,-0.5810247733236716,-55.51331100558294 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark05(-0.5640493138575807,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark05(-0.5642543176504506,-97.69472840731484,1.5707963267948966 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark05(-0.5647088714958154,-0.4817028733950921,42.87540512442625 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark05(-0.5652811636047859,-0.66833986188631,1.5707963267948948 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark05(-0.5660106246691463,-4.440892098500626E-16,-50.71851675229365 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark05(-0.566589737199015,-41.733969756133675,-96.22469055307408 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark05(-0.5675586588220788,-10.266098536521795,-158.78732326058184 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark05(-0.5679729793786735,-1.5707963267948974,-6.062100055495961 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark05(-0.5680154090842462,-0.43969448694503,98.46450871289656 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark05(-0.5686073218481802,-72.82901254575492,-83.45806272342585 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark05(-0.5694904324042417,-35.89801988714452,84.51903241659643 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark05(-0.5699895287353794,-1.5707963267948966,44.83843796816947 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark05(-0.5700673794111478,-92.8842194552957,-0.24979226764696733 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark05(-0.5701571851602756,-22.14565790863279,-34.84033947028937 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark05(-0.5703718593376264,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark05(-0.5713433391559467,-73.22982808489553,85.72812448238727 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark05(-0.5714320184419629,-1.5707963267948966,22.785041149445696 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark05(-0.5722644235673693,-1.5707963267948966,23.459774262875584 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark05(-0.5724827456859041,-1.2038908228674978,50.07688804314596 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark05(-0.5730275014491437,-1.5707963267948966,-78.51876623780791 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark05(-0.573893325043664,-4.672604986767183,-513.5511895030436 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark05(-0.5739163303136081,-24.403834982985103,-78.03810945161308 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark05(-0.5741572190155081,-3.14159289208499,67.34165736898537 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark05(-0.5751062179091814,-53.43676689929755,6.283249654405549 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark05(-0.5759676027014209,-41.1877955352832,-16.03651338724596 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark05(-0.5760592738671731,-243.41644125731145,1.5707963267949019 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark05(-0.5760631896352298,-1.5707963267948966,-6.283205485576224 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark05(-0.57608735374282,-4.799029804466019E-240,-12.83258127129572 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark05(-0.5763174081112445,-1.5707963267948966,-4.7123889803847545 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark05(-0.577300130116205,-93.80042658707318,-9.659950162649992 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark05(-0.5803065609053162,-1.0944085694144194,3.1415926535897967 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark05(-0.5806057880850065,-73.51970741930292,-9.812211677564193 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark05(-0.5806978276790691,-1.5707963267948966,10.374708014303557 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark05(-0.5808108598490742,-9.647455127067051,26.870121923035846 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark05(-0.5809265397400891,-1.5707963267948966,1.5707963267948912 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark05(-0.5815608221120497,-1.5707963267948966,-0.034143720794893584 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark05(0.5818866743371842,-24.626767567236783,46.550428135740674 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark05(0.5825079629836267,74.8113212991245,-89.72288661035768 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark05(-0.5834439327799167,-0.7630180447323848,-1.5414620025059933 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark05(-0.5839490063497791,-72.4724530419084,-66.57988210362699 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark05(-0.5839529660044205,-0.42230317762980196,0.0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark05(-0.5844827809508486,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark05(-0.5846255577632228,-1.5707963267948966,-28.379039566353924 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark05(-0.5848869159400039,-36.43073530252758,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark05(-0.585662213150779,-0.4783779968997095,71.57487843543674 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark05(-0.5859059684644915,-1.5707963267948966,-34.03339965646232 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark05(-0.58724025036532,-15.820882989747375,92.01717329471725 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark05(-0.5875532799567121,-0.7750437080949306,12.568323739359199 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark05(-0.5878260875601911,-161.05260123645485,35.86445742178742 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark05(-0.5881657835471006,-3.1415933147162933,-97.93608210778491 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark05(-0.5887789690656013,-73.64882675686644,-295.005050356412 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark05(-0.589568889986421,-78.96704443026039,79.10116842235149 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark05(-0.5903514340779532,-122.74760750402153,54.08994970823881 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark05(-0.5906481330778064,-2609.7289152557364,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark05(-0.5907715391215045,-1.4767272074149524,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark05(-0.592032489895299,3.469446951953614E-18,-21.875979355482112 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark05(-0.5932709360443554,-0.4273596861071738,-8.103981637139166 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark05(-0.5933357975193121,-2.2958874039497803E-41,97.8260460560869 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark05(-0.5939007726852137,-0.3752073603821048,35.3271019740121 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark05(-0.5944550528837943,-1.5685038589985445,60.54919857881353 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark05(-0.5946265919663747,-1.5707963267948966,78.7462542549611 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark05(-0.5949952774651506,-16.079659747454713,-34.75870958090664 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark05(-0.5950845443732669,-0.2608464547616923,19.52663479182482 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark05(-0.5960307766631769,-0.36247956540683496,-62.83655761681735 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark05(-0.596963745323589,-1.2559935698522176,0.038158028090407754 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark05(-0.5989227715519726,-66.36583965305228,-75.93679031128582 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark05(-0.5995249990031227,-0.11972487882890834,8.965809199465703 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark05(-0.6008666941150509,-105.19370116439676,103.76815580473112 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark05(-0.6012328459219654,-66.42308862896672,1.5707963267948966 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark05(-0.6018461108842815,-1.5707963267948966,1.5707963267948961 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark05(-0.60207678619827,-48.62995364202705,63.348222308234654 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark05(-0.6021476402374122,-1.5707963267948957,1.5707963267948983 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark05(-0.6033116517180706,-1.5707963267948726,-125.83702932574519 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark05(-0.6033194658055728,-1.5707963267948948,1.5707963268861098 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark05(-0.6035376878512437,-67.00933867605607,-118.1291358120152 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark05(-0.6036126096918466,-3.447984734948477,45.21763329427754 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark05(-0.6038516405869849,6.56420335739393,6.2842697848156 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark05(-0.6039663045514683,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark05(-0.6041754627089926,-1.5707963267948966,0.239892497254804 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark05(-0.6046750826808402,-3.7492420347390774E-242,-1.0920590620511712 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark05(-0.6050015969553378,-8.881784197001252E-16,-76.02425711627352 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark05(-0.6053265381783095,-0.04826543637102793,0.0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark05(-0.6062591271919588,-41.53828649760127,25.672666635016185 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark05(-0.6063733119589081,-10.99320902914313,-55.4690335447342 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark05(-0.6065063971176414,-0.03751812826149417,-65.05216300503692 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark05(-0.6074448515671635,-47.372496913875594,19.709866556622032 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark05(-0.6074565449127679,-1.322796720642252,-1350.0240695702146 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark05(-0.6093968728574397,-66.37566355049015,0.13534597245164992 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark05(-0.6105390738401661,-161.20036074208684,90.68948551361049 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark05(-0.6115946392170084,-0.001066430276404962,-569.0763104287229 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark05(-0.6130929776932855,-0.33007816772808773,-78.30784131052545 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark05(-0.6130938471747421,-1.0939403558643157,-78.7116456673574 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark05(-0.6133952382163832,-1.5707963267948912,16.191138239291547 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark05(-0.6137402928118414,-16.6906370276313,-21.33458396084487 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark05(-0.6139736440022618,-47.29338681279337,21.44951944234907 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark05(-0.6147846337339058,4.141592653598299,-12.122047226318664 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark05(-0.6147884830510348,-1.0178975097881953,15.571754905723218 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark05(-0.6148811572445231,-550.285059773166,39.44909748469624 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark05(-0.6154008792549615,-29.278802357101874,-3.6592085610967757 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark05(-0.6154460396095902,-66.40122957944716,-488.0834644134541 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark05(-0.6161875576932989,-0.04335027134925314,28.980975478766016 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark05(-0.6165975694407106,-34.557519427906904,85.55566205619813 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark05(-0.6167886097183852,-10.191304699295387,59.59626327106156 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark05(-0.6169943525840549,-1.1102230246251565E-16,-1.5707963267948983 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark05(-0.6180985958637785,-67.0968776541584,-1.1233137713820565 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark05(-0.6187703773122983,-53.6956703256281,-3.476194400479164 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark05(-0.61999814096362,-381.3208287102748,-54.24153981384656 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark05(-0.620126303526702,-1.5707963267948966,-1137.0794745627568 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark05(-0.6207301961146479,-34.92876991233135,52.7887384026915 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark05(0.6209717554662368,-1.5707963267949268,4.712498145802104 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark05(-0.6210374656840001,-0.4494274971650398,89.5353906273091 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark05(-0.6219051653697901,-174.33949208318452,-3.0577662301742135 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark05(-0.6221474389694098,-97.40009643894535,0.0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark05(-0.6222730097357152,-168.03139549917046,4.712389001600785 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark05(-0.6223122716635672,-73.224705821827,34.92206012077959 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark05(-0.6229736324089636,-2.0525514761408765E-17,-6.283330708278674 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark05(-0.6249731225198892,-35.841201215679405,-97.08673398230827 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark05(-0.6258871945412636,-36.03415946893446,-3.325038948230201 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark05(-0.6280162600723247,-54.48302957775197,0.0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark05(-0.628528155465176,-0.3954910241820989,-2.618799083791539E-8 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark05(-0.6285492391265203,4.141593646352848,51.32633191694468 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark05(-0.6288606996713975,-72.46113487530997,-6.28813128613283 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark05(-0.6288884319399624,-1.57079632672043,-100.0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark05(-0.629593942475168,-1.4245794439836945,-79.66710362661912 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark05(-0.6306800775262993,-47.2534568470131,86.7248715748722 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark05(-0.6310544569919985,-4.04120373475385,26.703537555513243 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark05(-0.6310755206512653,-34.65308347356472,96.65428850129948 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark05(-0.6324400442861271,-0.9872533913894357,54.4675043181324 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark05(-0.6330563525318191,-97.8440733207665,-453.1269405538913 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark05(-0.6332963187072683,-35.18789301013399,42.61928615446711 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark05(-0.6345802188785967,-4.3049588332739E-16,23.312109414337577 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark05(-0.6352343539735774,14.813981966066692,144.54311749116437 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark05(-0.6354518527125417,-98.89786092082697,-8.95317250566617 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark05(-0.635454360931929,-1.5707963267948966,-1.5213361770141267 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark05(-0.6359228396480843,-61.16128047632071,-48.247587361975164 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark05(-0.6365679568366858,-0.9949144621625367,181.02004429296431 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark05(-0.636849244832125,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark05(-0.6370353436543594,-22.34633358130217,-6.283189324570181 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark05(-0.6370431406046371,-3.4764679559311302,5.1416588962456 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark05(-0.6371295261920265,-15.707963267948967,83.40137639426193 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark05(-0.6378540126894863,-1.5707963267948966,81.1820600174427 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark05(-0.6381802902402698,-1.5707963267948966,30.584884177192574 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark05(-0.6394606612552847,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark05(-0.6395717177845324,-1.922478747137316E-10,71.18424060690602 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark05(-0.6396244653028309,-15.77283104945314,-43.5528318632016 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark05(-0.6401473226632071,-1.5707963267948966,-38.39029294939016 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark05(-0.6407656439074237,-59.74548368671653,1.5694017749021445 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark05(-0.6426163888247414,-1.5707963267948966,-1.016546773491218 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark05(-0.6430917938105438,-78.71132834191829,-78.0430970195051 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark05(-0.6431092318168665,-0.5857936390850755,-38.91390941597799 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark05(-0.6436252810881906,-6.7711864483149735E-15,-35.385816713668845 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark05(-0.6436884904191686,-1.5707963267948966,51.570623387355596 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark05(-0.6439648450531564,-59.893580909594995,3.1415926540597345 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark05(-0.6451007319526536,-1.145787412153907,-1.0792378378375351 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark05(-0.6451708934552398,-795.7809546141765,-113.79429999110114 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark05(-0.6455090364153352,-1.5707963267948966,0.9541486637479065 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark05(-0.6460554432069014,-0.04666561133890812,0.0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark05(-0.6466663387806197,-48.02651837490573,-174.57770945756306 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark05(-0.6470490925352976,-48.27251825793222,-12.652731142195535 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark05(-0.6472603085732463,-67.25615512339729,-0.0017239469195754233 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark05(-0.6474821343706325,-41.544704127326426,25.623815345869446 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark05(-0.6476412762197015,-34.58916763094274,1.5707963267948966 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark05(-0.6476538274082421,-2.191809349008403E-193,8.17775659209363 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark05(-0.6477751278248178,-607.7595234689766,66.83224111055038 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark05(-0.6480599868484624,-0.6984500781383098,-534.9288355936244 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark05(-0.648288618524447,-3.552713678800501E-15,-42.329597700515656 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark05(-0.6502340659157481,-61.06312621261702,-0.2167976969847726 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark05(-0.650922472563416,-1.5707963267948966,-81.55660407636532 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark05(-0.6524038823623376,-0.2912277806076693,-23.25354666720925 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark05(-0.6525642960781184,-1.5707963267948912,1.5707963267948966 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark05(-0.6539108646393864,-0.03627353020093565,-6.283246342336426 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark05(-0.6540441081575927,-0.9368370233670305,-80.11061266653972 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark05(-0.6556104646432008,-386.57784820727454,-1.5707963267948966 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark05(-0.6569190562424397,-0.5490057455163913,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark05(-0.6574422683936856,-4.261218993498524,-82.80339063136289 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark05(-0.6581872861290285,-1.5707963267948966,93.18942336473651 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark05(-0.6581937206067412,-3.4057546637832017,0.0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark05(-0.6585012550594835,-3.8449549907072154,42.677017320306476 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark05(-0.659272034590404,-98.91993556362198,92.1470814392715 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark05(-0.6595504086959703,-16.71318175367516,-55.26754295540268 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark05(-0.6597541485564682,-23.48257678123024,-1.5707963267948963 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark05(-0.6604105769969988,-1.5707963267948966,5.023017753545023 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark05(-0.6608196156828086,-1.3341312824242626,67.07936294404603 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark05(-0.6613057266835735,-3.157410800206222,-12.568917428724562 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark05(-0.6616374230219548,-98.7311999639765,8.105736540291831 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark05(-0.6618326927885685,-22.249047972878728,-21.232137522768234 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark05(-0.6618903444115772,-1.5707963267948966,-43.392274859767575 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark05(-0.6619509303384534,-1.356336911016023,-15.228057234535658 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark05(-0.662766213036504,-0.6833422421830101,8.33144344016037 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark05(-0.6635660925411098,-1.2419778136186364,-69.31673808690437 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark05(-0.6646308027793963,-0.127187087268544,82.68049610167799 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark05(-0.6650412633947962,-1.5707963267948966,39.64567683025862 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark05(-0.6651442507305871,-73.09548773213635,-152.65629675949555 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark05(-0.6665961119350214,-0.20416817390752234,182.1715319699953 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark05(-0.6667392574445928,-1.5707963267948966,-23.81757824108695 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark05(-0.6669166737526055,-59.92908288725407,-92.69121292423014 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark05(-0.6687129432692203,-9.975909197868162,-34.895353526612 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark05(-0.6691172341558237,-1.5539585645144234,34.92320978101017 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark05(-0.6698592363421995,-3.141601360722142,1.5707963267948941 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark05(-0.6703851372535475,-10.080154460201776,-90.40683774751415 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark05(-0.6705528823040237,-53.85655996594332,-54.18995161587078 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark05(-0.6711994767878784,-1.5707963267948912,1.5707963267948966 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark05(-0.6716513725347011,-98.61918698109861,-6.283200610678523 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark05(-0.6723274929197909,-42.3650509484592,6.344854593289123E-117 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark05(-0.6730997081173236,-160.98135213416361,25.37089099437027 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark05(-0.6733931987436758,-73.2431548549444,61.947991161484936 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark05(-0.6742409869839605,-1.5707963267948963,-92.78375628228324 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark05(-0.6747829755193959,-0.035490855149967526,-42.53650142579516 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark05(-0.6770027022161683,-1.5707963267948948,40.3880575794273 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark05(-0.6775104498688509,-111.09370905642794,227.0775534152829 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark05(-0.6775551346647459,-0.15804680055273446,-764.114175388397 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark05(-0.6778109339054053,-3.1416580834946446,79.10758867663266 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark05(-0.6786839645476429,-1.3698661231815803,-8.103981881900701 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark05(-0.6802665563823131,-0.4113767173513676,-100.0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark05(-0.6806138018467249,-1.5707963267948966,17.15730855190365 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark05(-0.6812402625080105,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark05(-0.6820596485875114,-84.92245201962592,86.16611475276689 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark05(-0.6826905253319921,-0.2914099578336412,1.5707963267948968 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark05(-0.6827829738612063,-49.209664964821556,-24.205036490437692 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark05(-0.6835371505861579,7.571517920309508,-65.58351386750974 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark05(-0.683747812907617,-0.08200448175230622,88.98795723927714 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark05(-0.6839386275597176,-1.5707963267948966,89.76445039529233 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark05(-0.683975406512799,0.2646227352035798,27.814451641229546 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark05(-0.6859003055601534,-54.45651314743028,-34.71495792789676 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark05(-0.6867277208371079,-1.5707963267947431,-25.30633129998931 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark05(-0.6872003475543559,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark05(-0.6872936269893195,-53.420770425018596,-100.0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark05(-0.6885150206955196,-16.75881050034553,-229.9404855116905 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark05(-0.6885868731331383,-0.308934425763739,-41.294217794870924 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark05(-0.6894326206290401,-1.5707963267948966,-59.975536945514904 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark05(-0.6897804321897807,-66.23450788148057,8.925146408802753 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark05(-0.6908587735569469,-4.287244102812714E-16,-86.71951030064706 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark05(-0.691156416781011,-67.49253313877024,-48.09178194339256 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark05(-0.6915197262842598,-78.74338650629893,158.14317553902998 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark05(-0.6916718045884526,-1.5707963267932452,-89.64327322784399 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark05(-0.6927278800853702,-1.5707963267948966,7.758834508415676 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark05(-0.6932306956407146,-0.3076708813283576,-26.130541160985302 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark05(-0.6933236985505138,-35.71766896015588,381.68627284385093 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark05(-0.6947844215986887,-413.0173056383832,1.5130433261085705 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark05(-0.6961816331255283,-3.5289087884153116,-1180.3574128303917 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark05(-0.6967104178933898,-0.27143211030192665,-41.13495349795085 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark05(-0.697683425134677,-0.4677235479391092,1.5707963267948966 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark05(-0.697793039948341,-47.478717881831116,-7.931068241611404E-118 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark05(-0.6986002627410859,-550.0607221035272,138.84401168888138 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark05(-0.69871953680786,-9.60332716940608,73.34705602585026 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark05(-0.6987905794617744,-98.77881938405179,21.78566668317741 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark05(-0.6991965557519535,-1.00836582583177,-325.1539024552769 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark05(-0.7004239376543372,-1.5707963267948966,66.74245449547662 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark05(-0.7008497092745638,-1.5707963267948966,-34.1550066978251 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark05(-0.7012289043728556,-1.1140114852860248,-64.14785608522625 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark05(-0.7014890424994934,-73.70144326339899,-462.88169242777064 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark05(-0.7018742407827285,-0.03163325491871256,-13.082562506987784 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark05(-0.7022974409192971,4.147939848228849,105.65646776539475 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark05(-0.7031211160275544,-0.11991141100696612,54.08369732234904 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark05(-0.7032217995931518,-1.5707963267948963,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark05(-0.7032462317746063,-0.12242130255903713,27.838543186415052 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark05(-0.7035196574767042,-167.4591773958787,47.565614316688084 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark05(-0.703709070799373,-0.299975769908143,1.5707963267948966 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark05(-0.7068854775133637,-1.5707963267948841,56.03392976422083 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark05(-0.7090233074200288,-72.95934632433273,-23.482643929143237 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark05(-0.7091529812426658,-53.560638668678415,0.0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark05(-0.7094282716731581,-67.57945565090282,4.683658484468201 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark05(-0.7101137690824473,-1.3684160079403196,1.5707963267948966 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark05(-0.7106975172303436,-42.35420911270214,-100.0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark05(-0.710771094011576,-5.0052077379577523E-147,-62.1420855238081 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark05(-0.7110417946020314,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark05(-0.7110428235636232,-1.4311879814062012,25.13274313626704 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark05(-0.7118052441777998,-23.344553665587924,-9.70406688270866 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark05(-0.7122342776010744,-0.962633222012926,70.35233164833588 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark05(-0.7123088595379641,-1.5707963267928535,-0.8231195519851913 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark05(-0.7123795865456191,-179.24853257433662,40.96817491999063 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark05(-0.712963821194549,-1.5707963267948912,-72.99308610197177 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark05(-0.7131296244099691,-66.531314732603,12.931592834953832 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark05(-0.7134396703380804,-65.97344572538567,55.217059873952564 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark05(-0.7138072338529555,-3.141657003058962,-7.867078450643027 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark05(-0.7139603530961743,-1.5707963267948912,-1.5707963267948983 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark05(-0.7140631909021806,-167.86558747568114,49.77026220576158 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark05(-0.7142515209109908,-3.7526369456720032,1.5707963267948966 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark05(-0.7151660498506087,-66.73060962293012,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark05(-0.715325982971776,-47.450945702920414,3.2323357138628808 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark05(-0.7157602183876389,-60.88553277679244,1187.0812694635354 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark05(-0.7160390682815447,-10.410141025143432,1.5707963267948966 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark05(-0.7161029903655964,-10.091924123098664,-0.010747013552460143 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark05(-0.7163255576495783,-0.8004672453803376,-75.36673966732471 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark05(-0.7173316333389435,-66.78288680416466,-97.74019926930603 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark05(-0.7174824058424338,-35.67134563767955,45.614568387989124 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark05(-0.7194278991694744,-456.8041857445306,-72.8712382045321 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark05(-0.7198819182244257,-98.78328223817137,31.078075051453844 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark05(-0.7198841100010729,-1.1240539326071224,-7.618048819818981 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark05(-0.7198944866212997,-1.5707963267948593,-34.26211023147674 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark05(-0.7201050367895476,-1.2145337763009323,15.292784605173376 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark05(-0.7201141020404446,-1.5707963267948966,18.00249910756068 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark05(-0.7214558239863923,-9.63156160018115,0.0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark05(-0.7214924254264314,-21.99827043052578,-33.42027430570252 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark05(-0.7215192556957684,-3.887961117994388E-12,116.33241256202294 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark05(-0.7226703582724339,-1.5103299527966767,-54.75554147515251 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark05(-0.7228480723645153,3.1494051536920122,-97.9458301298458 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark05(-0.7238768344216662,-47.80241930381999,-1.5707963256470094 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark05(-0.7242045177794446,-66.30649875758908,3.3087224502121107E-24 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark05(-0.7244458518894455,-1.5707963267948966,0.2704394091393644 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark05(-0.7247211432917287,4.141592653593371,42.84375213508671 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark05(-0.7249910400267985,-1.5707963267948966,-34.28319130767133 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark05(-0.7253040634562878,-3.603619972579267,-387.9409620644885 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark05(-0.7255541894702002,-0.09151668260106642,7.853981962658584 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark05(-0.7260112906857937,-1.2169873687453614,1.5707963267948966 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark05(-0.726283746849943,-78.74289748359953,82.21507500404178 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark05(-0.7266791948359597,-67.28007179704595,-129.27536291279762 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark05(-0.7268416117378425,-130.21692685316594,-111.52684753981966 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark05(-0.727913308895517,0.8826602002786046,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark05(-0.728728173389932,-0.8412908331478861,33.37126504608642 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark05(-0.7293622301270454,-29.786284753450587,-92.15006216389821 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark05(-0.7301872952449311,-53.643009694774335,0.0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark05(-0.7308755522384685,-7.644879304398991E-16,98.06040467569406 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark05(-0.7312161994982872,-16.814670674890323,-3.149405269385549 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark05(-0.7312809859544466,-3.7464290452968783,-66.91930967742358 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark05(-0.732559701561702,-66.94868776865322,0.8118890482363982 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark05(-0.7328030798698164,3.142080951151255,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark05(-0.7333246702768423,-47.89160554564925,-42.28917584706768 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark05(-0.7333607153867625,-42.26044807031191,44.14072237567899 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark05(-0.7337087590224851,-0.3722636832472342,-116.28432610131199 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark05(-0.7337128916066153,-67.15546935793652,-84.50660762709599 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark05(-0.7339711753228406,-0.07720813999016429,-1.5707963267948966 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark05(-0.7345408994232354,-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark05(-0.7352702673688825,-0.3725491638050934,52.41352635635817 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark05(-0.735805297295979,-98.86312742167385,-96.38585586646566 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark05(-0.7361397737293275,-1.5707963267948966,1.5680165230489767 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark05(-0.7365183335175681,-3.8473538029422687,-8.103981656728148 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark05(-0.7373431535984452,-54.55164184892916,75.8978016568762 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark05(-0.7377634171067948,-61.15118416218168,-57.25761418759785 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark05(-0.737946499343697,-0.06174835589860517,1.5707963267948966 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark05(-0.7385300446360016,-22.966288985729662,-1.5707963267948948 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark05(-0.7401567802765818,-0.470115063636218,88.25303695252296 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark05(-0.7406255878046996,-0.15389595177106963,77.9985956693775 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark05(-0.7407614860359506,-1.5707963267948966,52.598169289833635 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark05(-0.7409350488141767,-1.5707963267948966,16.606917059063008 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark05(-0.7409585572459108,-3.9898854283579714,9.440504774732212 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark05(-0.7420687020247263,-1.5707963267948983,-15.723197251969907 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark05(-0.7421531518076854,-1.5707963267948966,97.09115749852978 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark05(-0.7431873877735921,-0.22721231426262678,27.710997409684406 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark05(-0.7440073571956987,-191.77755965617447,-1.2337692766761599 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark05(-0.7453106418773543,-35.032180201535894,-17.049558549850495 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark05(-0.7478202902909603,-35.08287221546052,-1.1298490227439937 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark05(-0.7489379523821276,-91.91545650563549,-1.5707963267948961 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark05(-0.7490898064972763,-0.10536185216065974,-1.5707963267948961 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark05(-0.7493303458033218,-0.8131683591921806,9.24327547483199 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark05(-0.7493682836690003,-0.5844705806585493,-50.8054875512769 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark05(-0.7496745105115998,-97.83829025340931,-1.5707963267948968 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark05(-0.7496876288637303,-0.93349626663757,8.103981963141976 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark05(-0.7515772832993239,-9.805555573823838,-55.144971878089294 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark05(-0.7524325046840659,-0.31855613634120433,-22.978187372823754 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark05(-0.7525157790845898,-0.09178186016408757,-0.2850702919659229 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark05(-0.7526722981474175,-1.410396132898012,82.5565808276353 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark05(-0.7526726458324179,-0.01638707327138251,20.755180956978045 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark05(-0.753349826850652,-1.5686823525262052,78.32326996393394 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark05(-0.7543783340698296,-53.55089178648901,7.475274994281932 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark05(-0.7554852462848061,-569.0093414151333,-154.16140651254975 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark05(-0.7558050740329149,-60.00266887367894,-48.47712270728526 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark05(-0.7566858721726896,-3.1561487709405682,-79.30851415346633 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark05(-0.7569495361384262,28.703537555513247,60.69811063819333 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark05(-0.757371687238317,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark05(-0.7588098820160774,-15.924991506533544,17.256598823637972 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark05(-0.7591884039299804,-54.579463291735884,-7.853981634229799 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark05(-0.7592381216811369,-1.5340218779027948,-83.55424117307442 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark05(-0.7602251276879313,-0.6159731076960031,-203.16832393254015 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark05(-0.7609247986647296,-1.5707963267948966,4.730005654366069 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark05(-0.761489042740779,-9.952126217010886,5.1415927820668825 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark05(-0.7615015001678317,-0.20824567602092992,-55.2166128002362 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark05(-0.7620922923816049,-91.65610711359122,-1.5707963267948966 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark05(-0.7635163323421182,-3.831930131983029,100.0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark05(-0.7648701668193834,-1.5707963267948841,55.16540705326227 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark05(-0.765211062506529,4.603847135432808,8.342503866014354 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark05(-0.7652645133838882,-130.01417068518748,14.137185009100595 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark05(-0.765474234194226,-53.6670753820963,-42.239065235073724 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark05(-0.7664619970012378,28.703539901833317,-7.853987307346961 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark05(-0.7667419491227212,-1.5707963267948906,-100.0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark05(-0.7687802938858512,-1.5707963267948963,-91.88625528004711 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark05(-0.7712283989800377,-15.740316582621869,593.747229483285 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark05(-0.7721553734222013,-98.88647195233123,87.21374821756059 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark05(-0.7727570694142601,-84.9090794104608,33.404048898646664 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark05(-0.7731637034830454,-1.5707963267948966,-0.03417837600911195 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark05(-0.7739758161575484,-0.9293191551788846,-81.55156218854083 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark05(-0.7742359253649909,-1.5707963267948912,45.58588743470398 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark05(-0.774394503169237,-135.7864424465575,0.19963952042693012 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark05(-0.7745790559944579,-1.5707963267948966,-51.95959558908499 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark05(-0.7746039995800533,-192.08238286582713,-1.5701790844629744 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark05(-0.7746615652423396,-1.5707963267948966,40.75433426870558 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark05(-0.7748610175437534,-1.570796326889382,-27.73841126892887 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark05(-0.7753150259851374,-556.5032527911197,7.072885956362214 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark05(-0.7754529131172436,-0.7622124926063449,-16.032633658341794 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark05(-0.7773340851857422,-15.973770136459962,54.96166060833019 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark05(-0.7780498876011654,-1052.5496784274872,-90.73024996715009 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark05(-0.7781150795786075,-1.5707963267948966,62.19521877871358 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark05(-0.7782794757850279,-92.62748506923803,-0.4382348240836099 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark05(-0.7783246509658575,-1.5151093061058805,-630.6842220585158 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark05(-0.778872557430411,-1.5707963267948966,92.6769832808989 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark05(-0.7789308786651873,-1.5707963267948983,43.46061715959834 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark05(-0.7790128987886451,-47.73833960280696,-49.95212418933676 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark05(-0.7794352587132397,-1.5707963267948966,-0.48896759581245625 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark05(-0.7795464126185863,-35.053463335501995,-0.27736481275385927 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark05(-0.7801741192958391,-1.5707963267948966,-2.6639966923902686E-256 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark05(-0.7804793548482993,-73.10199274751241,1.5707963267948966 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark05(-0.7822366555415536,-1.5707963267948966,3.141600284960332 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark05(-0.7823240395169193,-3.794192644209076,1.5707963267949054 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark05(-0.7825563183724323,-72.38873315682001,54.977871437821385 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark05(-0.7827364021760514,-1.5707963267948966,66.05109783996436 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark05(-0.7835557020636004,-0.8434917270797332,-28.2746618339503 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark05(-0.7841264827308123,-9.850171079659262,-3.571682523206036 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark05(-0.7853950469550096,-28.540094191913326,-1.5707963267948966 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark05(-0.7858587789695568,-47.649129224181564,-210.556211244126 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark05(-0.7876590289201879,-1.5707963267948966,3.2665926535911467 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark05(-0.7884448092733842,-0.9998370280383975,-47.12388980493282 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark05(-0.7886828654751654,-1.5707963267948966,-23.533056359966235 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark05(-0.7898114387481847,-1.45484741575379,-56.818438320523676 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark05(-0.7901053172125359,-1.8033161362862765E-130,-7.31471486120385 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark05(-0.7910035516377469,-0.02776836527443427,-174.47384359096398 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark05(-0.791411419587515,-3.4396927011703458,28.122959023965528 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark05(-0.7922951048448681,-16.865992916863974,-142.35037369578708 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark05(-0.7931262552024864,-1.5707963267948966,-85.68439696029189 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark05(-0.7934441914675701,-80.0829640137719,-1.5707963260019806 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark05(-0.7936206898498064,-1.102815574176617,20.167900339173663 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark05(-0.7939951904763491,-0.553456714054894,34.98232650022861 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark05(-0.7948915611554929,-53.77032594013808,-16.07487300364376 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark05(-0.795110930924065,-0.5575421500402027,87.85476491678244 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark05(-0.7962121157343547,-1.433292081740317,0.2461871837955864 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark05(-0.7969102704363134,-78.92351668316084,15.025887448405939 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark05(-0.7983017685507363,-1.5707963267948912,-37.3160323828126 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark05(-0.7991346896733632,-3.14165683485752,-153.97574245832772 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark05(-0.7993634709933999,-10.35785336416834,-50.74831468956735 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark05(-0.7998065944809397,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark05(-0.7999107597913326,-0.1335758382973613,-22.532769001639423 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark05(-0.8001996284599295,-0.9023468091580537,-42.91684330005144 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark05(-0.8006949163070016,-0.004126908962837356,47.747975802950194 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark05(-0.8016128293121669,-35.152791533161974,-126.72581578624603 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark05(-0.8040737913213837,-9.557430426081552,84.7964723756343 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark05(-0.8058556552103333,-3.8857743063054784,-78.23090882656861 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark05(-0.8058566564587051,-54.56957797642905,9.61262569216844 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark05(-0.8064334977068801,-1.5707963267948966,-0.23340169081192716 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark05(-0.807484620415062,-1.5707963267948966,56.8721053740061 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark05(-0.8088538626093864,-1.5707963267948966,36.55504354573121 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark05(-0.8090160111400033,-42.38912169489804,117.91455671083975 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark05(-0.809314061053663,-22.379652660261115,-48.521239216086485 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark05(-0.8094105324828211,-1.542850602947279,-12.581530224262682 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark05(-0.8099183748472143,-23.217978243406183,-16.293342403699086 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark05(-0.8104535937983623,-9.644479191395698,169.29350901869694 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark05(-0.810538971813391,-54.6947408900293,1.251818130253988 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark05(-0.8113479600897531,-0.29549069094030395,-6.2831892559530385 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark05(-0.8115870120838622,-22.00846270065722,56.10447551366883 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark05(-0.8127177540074388,-1.4414046037731616,-75.73616087593756 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark05(-0.8136614270478236,-1.5707963267948966,27.022942809444643 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark05(-0.8139169416405612,-66.74593154798447,15.171768651036853 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark05(-0.8141676437573238,-0.7740387125085633,-68.99950369069813 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark05(-0.8151243209248433,-48.46074611740908,-4.141600770630147 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark05(-0.8156139046706721,-1.5707963267948966,50.079828087943135 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark05(-0.81695774417812,-40.973090897414835,359.5930184977159 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark05(-0.8170707791862155,-4.14159265367455,-1.5707963267948966 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark05(-0.8189012331141362,-3.415917151957899,64.56557672595567 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark05(-0.8193121659074406,-3.141592653714418,42.00335225697517 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark05(-0.8204716157544119,-7.8545495444763625E-90,-50.218225710111184 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark05(-0.8206382460693854,-98.89766387736371,-7.85398163729182 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark05(-0.820701965910132,-67.74179975789048,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark05(-0.8210163637927224,-3.1415926684909565,56.28589330222512 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark05(-0.8219778530038723,0.6356231587308513,1.5707963267948966 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark05(-0.8230954225159015,-1.5084697948212054,-3.2665960706434176 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark05(-0.8247645237455833,-1.5707963265323543,-27.04840530193081 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark05(-0.8259313095978746,-3.5209898533027513,59.0988967817466 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark05(-0.8262536388743614,-1.1131041822690588,6.754386582641607 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark05(-0.8272953592098559,-66.50272466962666,-3.1417101855669767 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark05(-0.8298697597958284,-35.0881593130486,-1.5707963267948912 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark05(-0.8301337419520841,-1.4988154827930198,-55.505890964215546 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark05(-0.830349855167043,-1.5707963267948966,49.77270848833252 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark05(-0.8304685599640358,-79.72286722700984,-0.21494248865948867 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark05(-0.830563636294332,-1.5707963267948966,204.2003754926357 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark05(-0.830698259344725,-3.3030641150784597,-66.72161717486722 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark05(-0.8328417193699699,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark05(-0.833713561838664,-0.9736312704305048,-33.02520983837833 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark05(-0.8341938061738461,-1.204959932551442E-181,-1.5707963267948983 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark05(-0.8345365970529843,-1.570796326797779,59.72570512759733 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark05(-0.8347267443936097,-42.345170576943495,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark05(-0.8353851529998351,-1.5707963267948966,8.394728445920508 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark05(-0.8362535136357856,-0.03639779104998103,76.88750525687846 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark05(-0.8372907759282213,-66.26300021712476,1.5707963267948966 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark05(-0.8376935801966504,-1.5707963265413183,20.95227161438602 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark05(-0.8380572786848167,-1.2021244720426323,5.928873928547663E-17 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark05(-0.8406986741698859,-1.5707963267948966,27.28689011920101 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark05(-0.8418544298373125,-1.5707963267944416,73.25990002445376 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark05(-0.8419752969906596,-1.5707963267948966,-85.59882810320092 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark05(-0.8421885393810034,-15.809412149717796,-51.002023811361376 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark05(-0.8427265539650058,-0.14179439942442995,-53.714572080681734 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark05(-0.8427339559731166,-1.5707963267948966,-50.875081672009934 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark05(-0.8442617501439659,-128.82038153957535,-343.99347003814864 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark05(-0.8443518410554013,8.470329472543003E-22,0.5331329882487901 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark05(-0.8453948481300695,-1.0842021724855044E-19,-63.66934877616244 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark05(-0.8458359226132482,-3.1415929108567435,10.756096785317165 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark05(-0.8464771568620431,-47.48536078868597,-77.5044388494143 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark05(-0.8467762607211697,-97.78825174518964,40.99402947873578 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark05(-0.848078386833161,-85.1514240025204,-35.259003577851125 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark05(-0.8497928174971725,-0.7096914863516872,-62.98458388245012 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark05(-0.8504824720022142,-1.5707963267947758,-29.038116552496007 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark05(-0.851083416996218,-36.083818500733955,-34.921217147618535 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark05(-0.8511995025407626,-34.75103781820985,-100.0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark05(-0.8514704791104076,-1.5707963267948966,27.16295026149737 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark05(-0.8519946865248478,-23.26104208672584,-29.803860799505323 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark05(-0.8522841922750466,-123.30201341945337,-5.862698088055311 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark05(-0.8528090976173033,-1.5707963267948966,3.1556673206238643E-16 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark05(-0.8528507739952785,-0.5648521298480139,15.555718315222464 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark05(-0.8531985188666551,-1.5707963267948966,-99.96472670813554 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark05(-0.8533952776382281,-60.90689701545224,37.300625574927615 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark05(-0.8535563093419087,6.497131179416368,-36.05315086346348 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark05(-0.8544178208820867,-1.5707963267948966,26.07549444355631 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark05(-0.8548141308866745,-16.132275921755628,749.9421317016131 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark05(-0.8551343279157466,-0.4213736481980398,2.7195225254812483 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark05(-0.8555502095665132,-0.9251955738020271,-67.12713831897094 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark05(-0.8556918965402472,-1.260336980174805E-15,-76.1805668641383 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark05(-0.8557184254010949,-480.7849937071835,1.5707963267948966 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark05(-0.8569456250413197,-1.1663558957634539,-16.886496263228327 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark05(-0.85744563536919,-1.4253623154181847,-10.596942600188832 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark05(-0.8576011596968711,-0.13213597891717024,98.29749387171236 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark05(-0.8578628260506668,-1.5707963267948966,28.750873813594303 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark05(-0.85838495382052,-186.35385213729933,1.2786571477642092 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark05(-0.8591510918664437,-15.96813988455348,98.1327908270855 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark05(-0.860210603490692,-1.5707963267948966,-515.8395658697027 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark05(-0.8608345435117672,-3.8713094500983516,-32.72554772121522 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark05(-0.8620161777696014,-92.51979589288435,-0.07383969522938916 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark05(-0.8640616918909495,-1.5707963267948966,-32.770660957576595 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark05(-0.8646348655025236,-1.5707963267948963,-1.5707963267948948 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark05(-0.8657241575085198,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark05(-0.8663697879402676,-0.8989233929890558,-3.149407228663979 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark05(-0.8671621714083255,-3.6415604976400986,91.2193549213506 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark05(-0.8686626253441738,-0.6559384888372941,22.278241780598968 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark05(-0.8700768978601019,-1.5707963262182083,0.0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark05(-0.8705988221204173,-66.49248375833423,64.33159379823266 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark05(-0.8709158484653869,-0.486647560362851,34.332231890339216 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark05(-0.8716734644940518,-273.470911926553,-16.811449720696782 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark05(-0.8720985789386059,-1.5707963267948966,30.972324017452678 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark05(-0.8728197578610045,-47.912832340000314,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark05(-0.873256646054493,-0.4738057581491016,1.5707963267948966 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark05(-0.8733903454543874,-110.24706472371231,26.28518918198187 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark05(-0.8739283287969536,-0.6478449658244343,3.7420855310188097 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark05(-0.8746872822739487,-0.547248574808486,82.95046673259861 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark05(-0.8758039290600573,-66.57770703822483,1.6632655625031839E-111 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark05(-0.8775335541335249,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark05(-0.8786109825263547,-34.96792043002044,0.5693567417090859 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark05(-0.8789835990286322,-1.5707963267948912,-8.1039816383501 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark05(-0.8793158355230264,-60.92360567160861,240.0588637278977 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark05(-0.8795460306493506,-41.88350452264319,47.16978694023443 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark05(-0.8797149016523759,-1.5707963267948966,1.232595164407831E-32 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark05(-0.8800765568719953,-67.47280185171789,-1.5707963267948912 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark05(-0.8802928156451613,-35.28159663615848,-64.82881063735668 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark05(-0.8806813219290598,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark05(-0.8812700671330431,-1.174734307836733,5.539285726602143 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark05(-0.8822790337689819,-3.1416002829844367,1.5707963267948966 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark05(-0.8836067849800637,-0.1495726406987729,51.81291850919078 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark05(-0.8847713261425412,-1.5707963267948966,-72.60199728396046 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark05(-0.8850794604936196,-47.458699404747385,-93.32880590571922 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark05(-0.8852174290026182,-1.5707963267948948,-27.867671753025213 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark05(-0.8868380720740277,-73.62776641398884,0 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark05(-0.8868977265633068,-7.0383142667919,-140.9781852113802 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark05(-0.8872340844494657,-777.5122622605815,86.57990853642258 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark05(-0.8876793445086808,-1.5707963267948966,8.85398163394911 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark05(-0.8876921864124829,-1.5707963267948966,587.7494256326397 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark05(-0.8881161981898793,-0.24199210094482004,-1.5707963267948966 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark05(-0.8893083194294633,-48.639676477780206,181.89821420583257 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark05(-0.8896577626775009,-1.5707963267948966,-78.19512442021839 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark05(-0.8904171654281297,-1.5707963267948966,0.2470878211926082 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark05(-0.8909113999736332,-1.5707963267948963,21.869838916648867 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark05(-0.8909451488144384,-15.84264975735218,60.48899321927369 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark05(-0.8910978364212275,-1.5707963267948966,-32.426795883361436 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark05(-0.8915993768602135,-1.5707963267948966,-13.350897497929164 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark05(-0.8923262602965405,-1.5707963267948966,39.70994939995589 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark05(-0.8932974387032699,-98.87953403576266,149.18254665095512 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark05(-0.8933440475535153,-1.5707963267948966,45.897878262235025 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark05(-0.8949691143319066,-9.952956795349532,118.10814334231094 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark05(-0.895277103197941,-160.2223482080308,-3.5504766180382487E-16 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark05(-0.8960627562815471,-0.4045717433173929,2.740895113766406 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark05(-0.8978969899695959,-1.5466107296075173,83.5595593651672 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark05(-0.8979298859078395,-1.5707963267948966,78.55544143955275 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark05(-0.8983116479634146,-79.11378294611744,-1.570796326782478 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark05(-0.8985063059066078,-4.049321692100936,-19.341973081005733 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark05(-0.898726654158809,-1.5707963267948966,-90.87181854869127 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark05(-0.8988966829381168,-66.28469897701906,-58.78653245280059 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark05(-0.9003601269325886,-54.6834410534609,40.356995761375664 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark05(-0.9007989069053941,-61.25251517370978,-6.52221171386568 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark05(-0.9015626426481185,-1.2837835758570364,-27.25717826343623 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark05(-0.9016855690677121,-9.424900031084936,-0.9747778408265347 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark05(-0.9017596385296627,-10.796815134099305,-65.43294192217382 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark05(-0.9036203729262908,-98.36798994584518,51.31833268700444 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark05(-0.9045700320963388,-1.257563846416699,-29.473049390422005 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark05(-0.9055342202031207,-0.02797609362035891,-40.869189603619 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark05(-0.9057693811014543,-469.66806872110357,-159.2235429446615 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark05(-0.9062670368032215,-7.105427357601002E-15,-1.5707963267948963 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark05(-0.906808859690246,-1.3310309846368114,-77.88870744761897 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark05(-0.9080071918133124,-0.13419109765979104,1.5707963267948963 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark05(-0.9080978126828949,-1.5707963267948966,55.42219627290066 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark05(-0.9083653625868806,-1.5707963267948966,64.90283528106126 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark05(-0.908549191244294,-91.63956096696765,-1.5707963267948963 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark05(-0.9086920935620227,-53.46075709349083,-100.0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark05(-0.9093551754773697,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark05(-0.9094874280194777,-1.5707963267948966,-65.2647798971848 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark05(-0.9098300870050142,-16.290884473851197,-2404.9415424597687 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark05(-0.9100897669204311,-1.434512159829067,1.5707963267948966 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark05(-0.9101154462677243,-1.5707963267948966,20.778228770210987 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark05(-0.9102823142795788,-47.46884132379923,37.08583221942516 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark05(-0.9107715925776874,-42.09478321721707,-59.88786354625582 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark05(-0.9111868991837928,-28.351420209936904,74.61221206596099 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark05(-0.9113976405304136,-48.568164702961575,-79.11356561479901 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark05(-0.9119917654638412,-0.4609640836580947,54.97789018409578 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark05(-0.9120590233884925,-1.5707963267948983,-95.53003826453876 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark05(-0.912328406897546,-0.9635300310567977,-119.38049748303985 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark05(-0.9129083045903607,-1.5707963267948966,-20.585914609639183 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark05(-0.913178512052486,-0.153924223271156,-8.37761973584542 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark05(-0.913197129410571,-35.20236017354739,69.04011404796947 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark05(-0.9133108909449217,6.645708901457103,3.1495154981057207 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark05(-0.9150332649067252,-98.64646724154191,-84.60893766277701 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark05(-0.915621646587383,-22.59567741863755,-23.09221313156661 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark05(-0.9162391795676887,-48.236838808115614,0.0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark05(-0.9166440876697074,-1.5707963267948966,-65.13450723862671 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark05(-0.9168781111752509,-29.37577502567963,-42.757741446363305 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark05(-0.9173338855718454,-78.82515297261511,42.63145990825761 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark05(-0.9177907163291005,-1.5707963260457949,100.0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark05(-0.9178374448813207,14.433333647304053,-1.5707963267948966 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark05(-0.9179317437518227,-4.330682271570756,-0.5707074520139429 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark05(-0.9194531388185057,-34.83578395552942,-29.057063169965588 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark05(-0.9203589187009689,-48.01707608620926,-1.411733670194307 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark05(-0.92062252586206,-1.3877787807814457E-17,-91.855806232046 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark05(-0.9237334945616151,-29.707322537060723,-1.5707963267948966 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark05(-0.9240620376393777,-1.5707963267948966,-89.6136149790066 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark05(-0.9247561017538658,-0.03544247882223661,75.78615015445848 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark05(-0.9248062088352951,-1.5707963267948966,-4.712388980385975 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark05(-0.9251378404801343,-0.005689113793921209,70.67587032004228 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark05(-0.9257252213924694,-1.5707963267948912,509.93594262197695 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark05(-0.926014841445157,-1.1381451614792373,-32.23981784717205 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark05(-0.926243506045793,-98.20806601380869,-1.5707963267948983 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark05(-0.9266494361838244,-1.5210387169762178,77.37620258468775 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark05(-0.9267298507663171,-1.570796326792376,-3.8326444734734224 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark05(-0.927003212539244,-1.5707963267948966,-35.06016504274307 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark05(-0.9287115040594801,-1.1519674562299849,16.029584467817187 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark05(-0.9300602205127717,-1.5707963267948966,-88.18774865747109 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark05(-0.9311156736422324,-48.25208621434502,58.608416311182964 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark05(-0.9312078771502461,-0.07235227670491512,-55.599550379824336 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark05(-0.9318708527134082,-66.2442671822136,-75.6329189547224 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark05(-0.9323931245934264,-35.572269484356895,-73.08948372618875 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark05(-0.9328870775868463,-47.250997944997806,57.217436578576574 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark05(-0.9342222867315515,-111.40989501705154,-1.5707963267947787 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark05(-0.9343596113473822,-0.30041860738262566,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark05(-0.9361987720592642,-54.06955295513463,-1.5707963267948966 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark05(-0.9362499094538895,-0.0068297352148394275,1.5707963267948983 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark05(-0.9366660205023729,-1.2949830224286898,54.07709833096318 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark05(-0.9367199829819529,-1.5707963267948966,-1.82877982605164E-99 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark05(-0.9370835447874788,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark05(-0.9379052532181159,-3.1421094092254602,-1.5707963267948966 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark05(-0.9380755286415932,-3.6942523665171176,96.27367753696613 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark05(-0.9382988848727076,-0.05928969443320309,169.40909171006777 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark05(-0.9383809782189748,-16.007042281905797,42.860431690707934 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark05(-0.9386898013148016,-1.5707963267948983,-100.0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark05(-0.9397191749491753,14.588617751244385,-46.539777392426316 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark05(-0.9399969759407567,-85.10237030330983,-48.647695470807875 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark05(-0.9421743893198773,-1.5707963267948966,6.406636637926226 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark05(-0.9429018149056904,-73.70708708237356,-3.149405828933924 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark05(-0.9436052791399285,-1.5707963267948963,14.380322243614195 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark05(-0.9438255138977657,-0.8114716114073413,9.500688375832112 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark05(-0.9439705553581472,-1.5707963267948966,51.19445151824544 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark05(-0.9441280912379935,-1.5707963267948963,3.1728474016551393 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark05(-0.9441905734919755,-1.5707963267948983,85.79287595369128 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark05(-0.9445492840683019,-1.5707963267948823,-73.18690633466261 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark05(-0.9450185971971057,-15.823520861354579,10.127996599011603 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark05(-0.9452059649227543,-1.5707963267948966,-82.1003836067841 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark05(-0.9457937482277796,-4.2351647362715017E-22,-59.82814153733949 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark05(-0.9458607482485037,-1.5707963267948983,2379.8911802706093 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark05(-0.946180646515499,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark05(-0.9462783198550843,-0.2146349564655281,11.011487781736355 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark05(-0.9467317578687229,-22.369896327344172,1.5707963267948966 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark05(-0.9468943228340958,-1.5707963266417695,-84.54863197935593 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark05(-0.9469304794682901,-0.0019737429611486057,0.7492607119427922 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark05(-0.947661660668289,-111.16568143137135,-65.56207863748216 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark05(-0.9487018067714867,-1.5707963267948966,-4.712388980384918 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark05(-0.9502361178099288,-1.5707963267948966,1.570784715637275 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark05(-0.9505092321565713,-3.1416833778542395,133.34800507740778 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark05(-0.9507267117935566,-1.5707963267948966,6.254575491439281 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark05(-0.9510800991745694,-0.4193718191633612,20.98293081464296 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark05(-0.9514782107884234,-0.13062163600134633,73.66979053376701 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark05(-0.9522651632763848,-1.5707963267948966,-8.103981633974529 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark05(-0.9526925368444803,-36.07835977243282,1.5707963267948912 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark05(-0.9539395310080989,-1.5707963267948966,-64.92326613146187 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark05(-0.9545066910088019,-41.71793307664133,52.90788850801232 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark05(-0.9551187384007008,-3.1416003898906517,-67.09717392069228 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark05(-0.9561935094659907,-0.00485849490705972,21.991148574780713 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark05(-0.9573710432606262,-1.7927817553502116E-14,42.07047625845543 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark05(-0.957572580658931,-1.5707963267948966,-20.653385041624105 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark05(-0.9579613928887252,-0.15825356638535232,-53.841959230622514 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark05(-0.9589729951892209,-3.141592676011615,100.0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark05(-0.9590046705967351,-4.141592653589841,-1.5707963267948966 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark05(-0.9590867968671319,-1.009948195396769,16.7119501297245 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark05(-0.9591355647050647,-1.5317265630575156,-68.63765261928202 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark05(-0.9593354053472993,-1.4662659659331816,-1.5707963267948983 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark05(-0.9603920329645591,-98.20838759818989,-75.76892249865215 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark05(-0.960476433702675,-135.84950219767865,4.639251627823711 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark05(-0.9613522147215132,-3.886295921697236,83.25220532012952 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark05(-0.9628917163160283,-0.5358421389932655,6.283342437676735 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark05(-0.963162061478414,-54.64892326395601,-79.26149311183867 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark05(-0.9632062474166393,4.141592653705374,51.9540161526739 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark05(-0.9633289920025315,-1.5707963267948966,1.5707963267948957 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark05(-0.9637697877699397,-1.5707963267948966,-56.605177650090376 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark05(-0.9640733240732021,-1.5707963267948957,-2.8675440507909844 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark05(-0.9642662595094492,-67.48838113563237,-1.570796326796493 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark05(-0.964408737829359,-66.48359976277176,100.0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark05(-0.9649129114716147,-47.93802650418087,-3.336852158478358 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark05(-0.9665266402609003,-0.8822864752110248,-98.75047293079733 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark05(-0.9668279995171394,-54.77646303028007,-20.426715201164825 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark05(-0.967774717486023,-1.5707963267948966,38.57497116356234 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark05(-0.9682653092690976,-98.76618834376957,-1.5707963267948963 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark05(-0.9688043879916011,-3.9708087160007706,69.7809188841996 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark05(-0.9703521654559975,-1.1769876788370048,65.06161903216906 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark05(-0.9709213929929486,-1.5116013948040778,44.26515382981 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark05(-0.9726056581631894,-79.01476269836849,28.256272010992433 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark05(-0.9730165057992037,-1.5707963267948966,69.82701921784444 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark05(-0.9734777248890638,-29.063459981908196,-67.04388949701224 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark05(-0.9735482248245004,-2.1684043449710089E-19,50.58913663056519 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark05(-0.9738872398154653,-3.711494229425905,12.72280253298375 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark05(-0.9740943269121601,-1.1164305497284097,12.387563554866546 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark05(-0.975102967959117,-1.0732064055576385,91.05469423263455 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark05(-0.975498928397294,-9.57881107858152,1.9175803555126834 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark05(-0.9757990181288188,-98.39795755657423,1.5707963267948957 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark05(-0.9761011952900919,-1.5707963262147222,72.48455644364944 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark05(-0.9774766410086105,-0.2069205388009127,9.764641956345727 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark05(-0.9775394347065423,-0.014753656854386676,-57.603738439632124 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark05(0.9791673071669338,4.486727091126511,-0.11153222433436527 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark05(-0.9792564427349935,-0.6834327718287877,-86.0974216496534 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark05(-0.979523968355084,-4.141594003792599,-56.24556273092268 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark05(-0.9817130550896784,-1.2211825298710743,-63.49987892751958 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark05(-0.9830276807089188,-469.37616582245744,-211.3914991847372 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark05(-0.9835881107353237,-72.43546084404575,-1.3742466486483425 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark05(-0.9836988489960871,-1.33062765935738,-67.42458343867503 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark05(-0.9838335956259723,-35.52021210369954,59.935717588520255 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark05(-0.9841788251584522,-1.5707963267948948,-12.595003809713933 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark05(-0.9842197050581802,-1.0948350822223034,-82.16046651990992 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark05(-0.984314154062012,-1.5707963267948966,54.69577342991945 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark05(-0.9844039629544776,-1.5699850323420943,-194.79284667246938 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark05(-0.9845192634526092,-1.1315443190764773,-26.784683385281706 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark05(-0.9852259664152341,-1.5707963267948963,-78.81403737970406 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark05(-0.9860358474194457,-15.797552356203411,0.0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark05(-0.9864840947683875,-1.5707963267948966,43.82175901797845 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark05(-0.9878306020475448,-0.03758633120142253,12.57342298373297 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark05(-0.9878806091588042,-4.154699362633792,-53.86769299893997 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark05(-0.9879916203726906,-41.1348504665084,-1.5707963267948966 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark05(-0.9882807212711799,-1.5707963267948932,-1.571538782762104 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark05(-0.990194519379618,-0.3424076787608207,41.045281181578645 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark05(-0.9907951367776338,-53.59281261030554,-38.735592370904854 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark05(-0.9908199622739101,-1.5707963267948966,58.48772293040936 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark05(-0.991225598856103,-1.5707963267948966,23.546473534715147 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark05(-0.9913447189700406,28.703537745193458,-1.5708499794098307 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark05(-0.9916405101073164,-22.86626686473712,-34.89180761232957 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark05(-0.9922197456989061,-1.5707963267948963,-70.13718870514715 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark05(-0.9930820560768924,-34.80905772584756,1.570796329905923 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark05(-0.9932659907063908,-1.5707963267948912,-85.22177059546163 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark05(-0.9935135128870582,-66.44453294972332,3.3636171657662572 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark05(-0.9943272653394868,-0.22427703445529834,-23.561944901923447 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark05(-0.9943555760817949,-0.4045313343072217,3.14160057597976 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark05(-0.9952913678137384,-35.48202912285059,-45.376919632740574 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark05(-0.9955407572559902,-1.386539746997161,42.939845628243404 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark05(-0.9955798490652967,-0.5973732488225403,-1.2343857074355582 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark05(-0.9969577042786426,-54.759415025169794,13.637325256659835 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark05(-0.9970603413260579,-0.09244326231908194,1.5707964596621262 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark05(-0.9989857834044696,-3.141612935912044,9.943457402113664 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark05(-0.9990208376568441,-73.11539061567986,77.86581210608847 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark05(-0.9994451371213879,-0.004351755268824909,28.114031364411517 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark05(-0.9997158928227874,-331.4379897011792,-0.8577980884911022 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark05(-0.9999876834558448,-10.194695126279056,2.5279601991116114 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark05(-1.0006917563239002,-3.2665926535955463,-100.0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark05(-1.0012367805457796,-1.5707963267948966,69.8550968310254 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark05(-1.0013537145214098,-1.5707963267948966,-76.96902546115555 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark05(-1.0020216934318165,-3.1415926684911213,-91.06508721959156 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark05(-1.002063258994708,-60.825734430073034,-72.25772223130862 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark05(-1.0028656569226888,-7.105427357601002E-15,55.468548570009915 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark05(-1.0045196558193012,-0.254025394464764,-20.508630403853473 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark05(-1.0049774730630232,-0.6443828289093179,-35.47710894824662 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark05(-1.0055187374434218,-1.570796326794887,83.09828372255404 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark05(-1.0056865599997311,-41.83749092860931,-94.50726576695921 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark05(-1.005801013208762,-0.5184828936858571,-764.0612059535814 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark05(-1.005939116366453,-135.17360888680824,-60.699237181990945 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark05(-1.0072071654354704,-9.544394385705095,-2.9387358770557188E-39 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark05(-1.0076034290694837,-3.141601602424567,-10.522966498213723 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark05(-1.008028058004757,-66.74718064760611,-10.688855888935336 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark05(-1.0088268434835157,-1.5707963267948912,-1.5707963287246514 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark05(-1.0092298522187535,-10.404550558135071,-3.141592932815425 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark05(10.092369324639222,51.86344416939227,2.9797564728419417 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark05(-1.0108613550775516,0,0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark05(-10.113626437060972,60.04139466042653,24.495544881059956 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark05(-1.0117892287500814,-9.567497046701632,1.3472067844287712 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark05(-1.0121723721122555,-72.93844264882259,20.42035224833488 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark05(-1.0124953044207818,-1.5668375641370111,0.16311772777537126 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark05(-1.013591055541736,-9.53167346227862,-1.5708340666004572 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark05(-1.0138813750468647,-35.046144568930934,-5.4875976117570815 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark05(-1.0145883133469482,-98.31324709187277,56.373778645687 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark05(-1.015043650936692,14.429204206242652,51.63879671340035 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark05(-1.0151248799589454,-1.5707963267948966,-20.707125232179834 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark05(-1.0151347957548621E-15,-1.5707963267948966,78.04124125515315 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark05(-1.0151836861454353,-1.1193439701858359,59.91325915110757 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark05(-1.0154962391238165,-55.57992592469959,-94.95793426449889 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark05(-1.0155112620276596,-1.2225504363220923,41.461513448189365 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark05(-1.015879001950822,-66.22446894796128,1.5707963279088726 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark05(10.159250326598766,-52.948298140281395,34.323474370287755 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark05(-1.0164840159433772,-0.1418433793936913,42.27013142491765 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark05(-1.0175755990873512,-1.4538487760653247,-0.003317453275026999 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark05(-1.0179664180775863,-1.5605551017980228,90.5270428552862 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark05(-1.0180927802766238,-0.2862480750493105,-3.142083419527878 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark05(-1.0187189010068227,-1.5707963267948966,-77.9891227809377 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark05(-1.018973765732086,-1.5707963267948963,19.68224702077137 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark05(-1.0202267027785945,-78.56822735869557,6.8156226658743755 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark05(-1.020370251908659,-1.5707963267948966,-0.3407981491420628 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark05(-1.0204112002310803,-1.5707963267948957,26.831436340649574 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark05(-1.0211473606148633,-44.54705988253431,85.0401029722082 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark05(-1.0220691480650999,-41.84468571993463,-19.364450207266003 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark05(-1.0233839719818003,-0.46264850469320973,39.55699647710421 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark05(-1.0245970671903502,-1.5707963267948966,-25.90395787859252 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark05(-1.024849334813382,-66.5158963557333,-1027.1573881546728 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark05(-1.025087954721016,-1.5707963267948966,-35.636829971209664 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark05(-1.0250922443925858E-17,-1.5707963267948966,12.843691727287279 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark05(-1.0258612200475739,-1.5707963267948966,-799.9722756306963 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark05(-1.0260118495438828,-66.33696847671649,91.15781886759035 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark05(-1.0261151978599515E-18,-1.5707963267948966,18.849555676326005 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark05(-1.0268702260516989,-173.05199597549654,28.01365126548666 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark05(-1.0273140708938782,-15.893357327201148,1118.154065800127 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark05(-1.027558000512357,-3.406704901263812,-538.379740836255 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark05(-1.0276318945925889,-1.5707963267948966,79.58458701715762 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark05(-1.0284861322509045,-35.24744135124178,-1.5707963267948983 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark05(-1.029529531805613,-47.889986118144556,-49.923131991479934 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark05(-1.029728704787321E-6,-1.5707963267948966,202.67498296915633 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark05(-1.0307280363917855,-41.35858849867135,97.43497341588748 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark05(-1.0317884905289816,-110.3638914997676,-23.123464756702433 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark05(-1.0326339876203519,-1.5707963267948966,-69.96070842961387 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark05(-1.0327161995865464,-10.255078246374048,-0.14714120137243167 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark05(-1.0330123523070998,-0.05405151225290645,31.657191073354056 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark05(-1.0339757656912846E-25,-66.80791373229047,-82.74561307519758 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark05(-1.0343347188660181,-17.163053940570606,-1.5707963267948966 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark05(-1.035971382767233,-0.25991928040963386,-26.730797342777002 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark05(-1.0368077211522093,-1.5707963267948983,-27.26561481126318 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark05(-1.037389585640518,-84.89091985690428,-12.896522733454976 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark05(-1.037739392592652,-0.3066351023475763,-61.26105674500097 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark05(-1.0399066672917248,-3.2686858400623797,-15.549292055096643 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark05(-1.0404358001612592,-10.408768525401731,32.195273115476766 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark05(-1.0404954722383906,-1.5707963267948966,-43.72074902788745 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark05(-1.0411632429086657,-34.6332213275721,-632.7071182667622 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark05(-1.042420294936523,-36.08784460070586,3.1816208784762674 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark05(-1.043839416410573,-1.5412398324490306,89.59969952786494 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark05(-1.0447071269108479,-0.21949556343551838,-15.12310931355585 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark05(-1.0449241150798914,-0.15322213320323388,1.5707963267948912 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark05(-1.0455059331930885,-16.409662008837913,-28.349512156703177 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark05(-1.0458345671440978,-0.38142450084818125,49.738530723976076 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark05(-1.045863392006558,-3.144853521925392,84.32196859901843 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark05(-1.0460008320840004,-1.4669197987736404,-6.2831853054612035 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark05(-1.0460762518016904,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark05(-1.0466498780072881,-1.2527011071554763,-1.5707963267948966 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark05(-1.0467263372311073,-0.08417192091917855,0.3907503896537676 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark05(-1.0469116159214753,-41.02276823854321,27.757125005087204 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark05(-1.0477709675988105,-0.49065561146061726,-1.5707963265636804 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark05(-1.0482027932118427,-3.266637621182561,-145.35962542182918 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark05(-1.048680137502553,-122.77971011307972,-5.37776605964673E-7 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark05(-1.0489626948623822,-1.5707963267948966,-77.08262123676812 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark05(-1.0503405678074134,-85.81766893073662,-1.5707963267948966 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark05(-1.0505619637678665,-1.5707963267948963,42.387152908844364 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark05(-1.0507867982009884,-1.1705022052082,83.25220532012952 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark05(-10.513457338883342,-15.678607796093956,-68.42061705015117 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark05(-1.051573371137395,-0.7353379348525095,11.263370717041095 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark05(-1.0521245269854664,-538.2503174178005,20.948699618345145 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark05(-1.0524128597758833,-3.1416233040017016,-56.16664477863391 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark05(-1.0531314173544333,-4.665204025988739,-17.06276516985453 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark05(-1.0535402231420337,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark05(-1.0553178144107943E-227,-35.3263106280785,-70.11736149298952 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark05(-1.056253670071953,-0.26689979940105574,60.80617686410133 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark05(-1.0566092361163482,-1.5707963267948966,1.3990165400283288 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark05(-1.0568798609811112,-4.04632047141758,-1.5707963267948983 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark05(-1.0571158677793697,-1.5707963267948966,2.0474289486220414 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark05(-1.059164696962088,-42.31198894307935,-31.204719365773613 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark05(-1.0597094444957875,-15.78701983895661,-69.96840727783027 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark05(-1.0603726310445651,-0.1568918733248984,145.61787328581823 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark05(-1.0605964949758544,-0.013851878400701387,-70.89443646843577 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark05(-1.0612749490354227,-10.408116507465891,121.66360340248158 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark05(-1.0620888149431527,-73.14522757251477,-1.5707963267948974 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark05(-1.0625043571499508,-0.5642055862963585,-1.5707963267948966 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark05(-1.0634234892875074,-0.015766557320942405,3.1416039355266814 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark05(-1.063487804183659,4.141592653589855,1.663288272805843 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark05(-1.0658839658532173,-185.85661623780186,54.17370596266518 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark05(-1.0663223829094266,-9.991042488876037,0.0 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark05(-1.0667000938178735E-16,-34.908153869490505,1.1581314540283607 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark05(-1.0672493262257288,-48.54530756071245,-46.773002960222264 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark05(-1.0677884182065362,-23.15508777734459,-60.456322138756605 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark05(-1.0679105687080916,-1.5707963267948983,-89.67059655560838 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark05(-1.0681498287149538,-1.5707963267948966,60.268234702989396 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark05(10.683968715339589,0,0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark05(-1.0696570815871191,-66.28868631278658,-23.28529798746115 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark05(-1.0722381576991644,-0.42995187349992675,-42.925175236172265 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark05(-1.0722652078122983,-0.0644864375001154,-0.01781254274809854 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark05(-1.0736528021362193,-3.8515205408794753,-29.534405035624044 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark05(-1.074196469682178,-1.5707963267948957,43.55262104981819 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark05(-1.0754578992793722,-0.5724014731544255,-42.727583591842084 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark05(-1.0760935547163206,-15.723588267949062,-69.7932840223759 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark05(-1.0762590809680241,-1.5707963267948966,78.63778992145824 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark05(-1.0764704826151448,-9.459058061364523,-53.40707884069858 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark05(-1.0765825820276707,-0.5684579907922999,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark05(-1.076725871486706,-1.5707962687268684,56.7014811190134 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark05(-1.0774862675106518,-1.5707963267948974,-71.91549042497849 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark05(-1.0778915959802244,-123.16597037436455,61.700505193339126 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark05(-10.788816589590084,-65.84148723490051,-8.222000627894573 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark05(-1.079302655170114,-0.49589608823434883,1.5707963267949054 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark05(-1.0795652344555713,14.486550492280294,6.299181075246664 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark05(-1.0811271954507844,-67.13313073944072,-65.98165388267081 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark05(-1.081347173629967,-1.570796383876926,57.361279803479256 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark05(-1.0813654898630455E-18,-1.5707963267948966,89.53539062730911 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark05(-1.0821629723444544,-1.5707963267948966,57.44822334336973 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark05(-1.0838047763630376,-84.93339008150606,-87.50307395311403 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark05(-1.0839019810968604,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark05(1.0842021724855044E-19,-66.2535283355517,-0.2732396481562631 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark05(-1.08440219600876,-47.520428542204385,-86.27608135984613 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark05(-1.084469196102236,-1.5707963267948966,-13.994224884741456 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark05(-1.0849893403005444,-0.17357981234703707,-39.84301024561188 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark05(-1.0852645461544983,-100.0,84.53837645344369 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark05(-1.0861214679967717,-92.32363694045117,-111.80735930673782 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark05(-1.0863000818786164,-1.2512278325256811,-50.36494495031014 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark05(-1.0866732960904866,-66.58678091202134,-10.300129830604234 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark05(-1.0871330438818776,-1.1102230246251565E-16,25.717903424508563 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark05(-1.0872102926295744,-0.011703086479427749,8.103981658782615 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark05(-1.0873130843844878,-1.2292638482503886,85.86217546160873 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark05(-1.0885205667269837E-19,-1.5707963267948966,-62.89435309900892 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark05(-1.088691989115374,-1.5707963267948966,556.739747510897 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark05(-1.0887784984455893,-1.5707963267946268,0.0 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark05(-1.0889320520017787,-0.008778513736253157,-66.711941463891 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark05(-1.0892476992351374,-42.40950662848964,9.497606172512917 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark05(-1.0921021442074146,-0.05841387613339462,46.99638274612951 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark05(-1.0929325219754378,2.220446049250313E-16,-100.0 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark05(-1.0930286722994031,-1.166248339238436,71.51224740727159 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark05(-1.0930633296149548,-85.01061171508941,1.5707963267948968 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark05(-1.0943007824528062,-1.5167183640995896,-1.5707963267948966 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark05(-1.0943661141345697,-98.14300664435753,-3.143066626982658 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark05(-1.0946182167345646,-1.564685412149027,1.5707963267948963 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark05(-1.0948810310733719,-53.80527510633241,-0.10592601465541307 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark05(-1.09505863409635,-0.6674192887616653,-9.55641340564759 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark05(-1.0959046745042015E-193,-1.467615164792179,-8.372887798461775 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark05(-1.0959139764141177,-0.474682930019808,-89.02483913978745 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark05(-1.0983384018531197,-35.421195765762825,-1.4441675986863427 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark05(-1.098407099428833,-0.44618090349548467,27.13367655404491 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark05(-1.0990691173994378,-1.5707963267948983,19.358703050914514 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark05(-1.0992293848211585,-1.5707963267948966,6.2831854110012415 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark05(-1.100180517864584,-48.14011759474092,51.71717059381593 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark05(-1.1007347361118012,-29.793001355432303,1.9935716661771357 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark05(-1.1010137793994974,-3.1415926900156266,-0.039385985211733476 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark05(-1.1011398982505876,-111.17988212306234,-141.88152321500942 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark05(-1.1012542945921826,-1.5707963267948912,1.5707963267948974 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark05(-1.1013807362440802,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark05(-1.1014085788559744,-3.199784489113398,-1.5707963267928022 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark05(-1.101472076133468,-0.004178378524260201,161.84886573575952 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark05(-1.1027922173191846,-22.347542942392842,47.12389363810201 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark05(-1.1028949545328244,-1.2372175976027983E-14,0.0 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark05(-1.103501615125668,-0.29727043570409184,5.551115123125783E-17 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark05(-1.103995994218276,-1.5707963267948966,-96.85241943807141 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark05(-1.1040372460590127,-0.8860928363180149,74.06028438235447 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark05(-1.1047736216338002,4.141592655642939,-85.22346330687128 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark05(-1.105754283332523,-1.5707963267948983,-0.5741743805514997 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark05(-1.1064824103044266,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark05(-1.1066547705023395,-607.549168674434,0.0 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark05(-1.1070986867211552,-1.5707963267948948,-1.5707963267948966 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark05(-1.1082143192739744,-98.40250536473205,3.8934355277724873E-208 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark05(-1.1082875500893377,-1.5707963267948966,-55.8065632114271 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark05(-1.1088430728798677,-1.5707963267948983,1.5707963267948963 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark05(1.1102230246251565E-16,0,0 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-0.11129461638310308,-0.05762037123731604 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-0.17524587222838595,55.94020905260809 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-0.6603167966223688,-0.19370092422985552 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.431627633549506,-7.85403933523305 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948841,-4.255607417589005 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948948,-1.6849852926984982E-16 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948963,1.220010461687496 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,17.35873206159134 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,19.91026578659986 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,-62.50116453294188 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,99.9999999999998 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963269756566,-56.9454847734602 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark05(1.1102230246251565E-16,-16.029553543148396,0.0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-3.1415929101870472,78.27978448804551 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-3.1494523206774216,-42.80684306125106 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark05(1.1102230246251565E-16,-34.59097366718396,-26.86316239523999 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-35.29269004160055,66.10287386664272 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-48.60646187682136,1.5707963267948966 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-488.26149623880167,-1.0625463263159387 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-5.421010862427522E-20,60.157967396452165 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark05(1.1102230246251565E-16,-7.105427357601002E-15,64.47672199548114 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,8.470329472543003E-22,0.43892460858192545 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-97.41848227253244,-1.570796326794465 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102450309956655,-42.16451835345252,-94.31274618394853 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark05(-1.1110864937155907,-0.03855123695207486,-36.31270929649746 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark05(-1.1112169252097126,-73.06160485934065,-3.1420809656244217 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark05(-1.1112469973303396,-1.1102230246251565E-16,1.5707959144722718 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark05(-1.111710511232412,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark05(-1.1133057337980627,-0.08117677721767116,6.283323971592582 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark05(-1.1134628962840802,-10.242971890216332,-1.5707963267948806 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark05(-1.1135439508581193,-48.50092475955304,-6.295021633267686 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark05(-1.1138523789746957,-3.172842999797596,-1.0461440795941608 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark05(-1.1140487114432913,-1.5707963267948966,6.29909102526632 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark05(-1.114233750206454,-0.10825162509163877,20.64750427039603 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark05(-1.1144306500593855,-135.09143113113365,-1.0494858051100002 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark05(-1.1147698467888779E-11,-16.5844765008962,-147.71036980360677 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark05(-1.1150124357703683,-0.21527286669026813,-72.71759014175142 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark05(-1.1155012781534746,-1.5707963267948806,-87.74224292117276 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark05(-1.1155569763504736,-84.95499726011786,85.32678676411933 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark05(-1.115627406102261,-1.5707963267948966,-76.96902001294994 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark05(-1.1156613355996434,-3.552713678800501E-15,12.56832379507521 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark05(-1.1157541028527885E-19,-1.5707963267944611,1.5707963267948966 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark05(-1.1160455888046528,-1.5707963267948966,5.497816704755921 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark05(-1.1161496782143765,-1.734723475976807E-18,1.5707963267948961 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark05(-1.1161986242990967E-103,-1.5707963267948966,-66.68660761686503 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark05(-1.1163936682450823,-97.92474825934494,-31.725837652357296 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark05(-1.116849517324322,-48.478715876249,-15.631683895262967 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark05(-1.1171284046891259,-66.00905025444777,-1.5707963267948966 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark05(-1.117561078894468,-9.972058569901833,35.792294845282605 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark05(-1.1175831738795865,-47.143511618144586,1.5707963267948966 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark05(-1.117707282115894,-0.10305937209448555,-41.11444187089344 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark05(-1.1182243133652348,-35.79507226928666,182.14671876822172 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark05(-1.1186610174733793,-29.35958085979236,-85.34442234864011 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark05(-1.1186632131090548,-54.63371752872652,54.39517696302503 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark05(-1.119057073925653,-1.5707963267948828,87.21512427970538 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark05(-1.1193001510029328,-1.5707963267948966,-44.17342229211535 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark05(-1.1201427720305368,-60.70831766708551,-69.99468161422003 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark05(-1.1209993323726621,-1.5707963267948912,38.14217519030234 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark05(-1.1210009276365938,-85.77179073423768,-73.88970602163481 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark05(-1.1218121544891115,-1.5707963267948983,-26.237636471279608 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark05(11.223595044936843,-83.6680870133884,42.25862821155755 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark05(-1.1232331095660626,3.1415926535897953,-91.28490645226347 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark05(-1.1237074362727952,-29.822763730143294,-9.533804539757636 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark05(1.1250577801674397,-1.5707963267948983,-157.63219368918732 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark05(-1.1251611682241185,-1.5707963267948966,-62.339649910684116 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark05(-11.269701596806783,89.59375692618298,22.465182842041244 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark05(-1.127096861824475,-0.019701186114389202,48.42519643752249 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark05(-1.1279176361723477,-1.5707963267948912,-6.283332887105137 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark05(-1.1282394210066222,-10.977573077861493,-1.3350677732362075 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark05(-1.1292616378853628,-1.3838319652454718,29.277455300614847 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark05(-1.1295105843758337,-0.18316284288919793,44.395391005271485 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark05(-1.129698036580793,-42.24906238774526,16.731405700102997 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark05(-1.1308187776420515,4.141592706389742,0.9098709794007483 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark05(-1.1323364447197264,-3.2242980847829354,-0.7681826298627236 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark05(-1.132955473947941,-0.26728272399351677,9.772882385708527 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark05(-1.1329904254626555,-47.13951482089319,11.172322623905444 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark05(-1.1330281822035673,-1.5707963267948948,-45.160284071511825 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark05(-1.133956357974909,-91.44177953993038,-0.7006496016171784 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark05(-1.135139847790161,-1.570796326794877,-73.16384685716042 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark05(-1.1355248973921535,-0.7707114931154178,-97.57685693820366 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark05(-1.1364720145206064,-1.5707963267900988,1.5707963267948966 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark05(-1.1364775994380847,-72.65704468526167,-181.68445875177875 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark05(-1.1369109721351542,-41.98753216562596,-1.570796327132846 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark05(-1.1373826189893625,-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark05(-1.137559685096569,-3.963025288375575,11.82973376526534 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark05(-1.1376245995493957,-0.2842189938741778,-26.703537555513243 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark05(-1.137680789044623,-78.55757050526383,-74.73857073279262 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark05(-1.13801788391202,-3.1415926684913384,20.550141624096195 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark05(-1.1380940517717777,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark05(-1.1397123574139707,-9.232978617785736E-128,25.996206290014705 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark05(-1.1399333780970848,-66.62491131065022,-72.75532293518609 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark05(-1.14204649614662,-1.5707963267948966,-510.01906056100785 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark05(-1.1421245673100957,-1.570796326794877,-35.74055658278901 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark05(-1.1421531361224428,-1.5707963267948966,-77.28819856752223 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark05(-1.142310227106277,-0.1328934405746292,-128.7461727306536 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark05(-1.1424020704212579,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark05(-1.1440071346949927,-7.067945877564426,0.0 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark05(-1.144407839347487,-0.08710226576403102,-45.45056183850698 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark05(-1.145126400763795,-0.7210469600638194,42.68478940795791 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark05(-1.1457408898764103,-84.952430874009,66.9512239314925 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark05(-1.145843184738344,-1.5707963267948966,44.25390699762639 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark05(-1.146175481543736,-0.7791489369113492,69.64923058150367 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark05(-1.1463525203248062,-0.0741468079639872,1.5707963267948983 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark05(-1.1466428545221392,-17.563057126652893,19.749289860274583 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark05(-1.1469030392325834,-123.35236891587253,85.02877038480044 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark05(-1.1489503754395953,-9.529618424179604,26.81785163596809 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark05(1.149106213380332E-19,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark05(-1.1493478599034415,-795.8227741030711,-87.88941286348214 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark05(-1.1498261605898783,-9.56006728426047,32.75748315025298 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark05(-1.150734189372343,-1.5494470768860342,-77.5529934966765 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark05(-1.1511147699436464,-41.48664343044818,28.269668518899437 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark05(-1.1514973619757776,-526.1524195168587,11.719525647867698 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark05(-1.1525760168852432,-48.221293985429526,12.415592400054274 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark05(-1.1526171151867215,-42.15915019201919,88.25171100775418 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark05(-1.1560541150165942,-0.23334376131662615,34.961333631303575 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark05(-1.1582813860264354,-0.0048280045098729905,-8.1214138794100775E-115 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark05(-1.159061889375918E-13,-1.5707963267948966,-2.480804606943867 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark05(-1.159213660424831,-1.5707963267948966,12.285892430826848 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark05(-1.1593859982521673,-1.4036344862449823,-65.22524165982779 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark05(-1.1612031196608255,-86.20149999742885,-1.5707963267948966 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark05(-1.1618762159462654,-1.5707963267948963,29.74283762298225 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark05(-1.1625129500190923,-1.5707963265257183,92.65833144086977 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark05(-1.1626118898607496,-1.570796326794898,-6.288590347068493 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark05(-1.1628241834011686,-1.5707963267948648,32.55061838930877 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark05(-1.1629032837213564,-0.9391242289154421,75.58309802723221 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark05(-1.1637679525042963,-0.003254513666639005,-1.0206182571833147 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark05(-1.1642815311552088,-41.09379656616819,-10.446814860528837 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark05(-1.1655143434647242,-1.5707963267948966,-1.4460578898067808 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark05(-1.1666752281961836,-0.5555953849536582,20.5815970366018 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark05(-1.166712500812844,-1.5707963267948966,83.2524195424788 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark05(-11.67445788890997,35.21259347603089,80.47828009855499 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark05(-1.1675245568248618,-1.5707963267948968,-1.5707963267948966 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark05(-1.167909203431678,-0.07628703556991981,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark05(-1.168251210474952,-1.5707963267948963,-5.141592660204727 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark05(11.697352918673658,43.603680030704226,-69.52823800227475 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark05(-1.1707434969652926,-48.621027041218895,73.76197287114316 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark05(-1.1708175003645904,-85.30057018337011,-42.65677217578806 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark05(-1.170933615559968,-42.361235636342975,48.67291744989785 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark05(-1.1712956860885093,-0.04964998530939715,73.60920908532398 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark05(-1.1716483000454332,-78.58744423765785,-87.09301812126706 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark05(-1.1717173086910693,-1.5707963267948966,11.031595986317086 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark05(-1.1719302080246932,-41.70705890212997,-0.10946219261703694 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark05(-1.1720087477368213,-3.1416028090668155,71.8534163404928 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark05(-1.1726561439506225,-1.1459297093098977,-6.283432591150838 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark05(-1.1729266395775697,-1.2150700931429461,-1.5707963267949125 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark05(-1.1730151971629732,1.1102230246251565E-16,-84.54807501358746 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark05(-1.1734369836104772,-1.5707963267948966,20.603933487452338 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark05(-1.1735109925084177,-16.207269184125973,1.5707963267948966 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark05(-1.1739289006074778,14.487113068125893,4.0326367059390344 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark05(-1.1741945954962834,-1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark05(-1.1743343571946885,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark05(-1.1753229253184525,-0.35910005951358903,1.7770386429989553 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark05(-1.1766991053692576E-16,-1.5707963267948966,43.59013962764354 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark05(-1.1768828333523254,-66.07568619013739,2.9726064867736284 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark05(-1.1772206805104057,-1.5707963267948966,32.921727896806956 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark05(-1.177362212897316,-5.770611636116085E-129,-3.7784493597789948 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark05(-1.1779146600645523,-3.572640651106331,1.5707963267948966 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark05(-1.1780044090965467,-1.5707963267948966,-74.75035982371632 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark05(-1.1783752944717223,-1.0780579109510782,0.0 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark05(-1.178482487855924,-65.97344596381541,-45.84845819579808 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark05(-1.1794954996401303,-1.5707963267948966,-12.597620907660705 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark05(-1.1795378803753849,-1.5707963267948948,-0.13027120958318344 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark05(-1.1799041731081275,-47.364017114198354,1.2170067491613352 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark05(-1.1799067741312812,-1.5707963267948966,41.33964832965789 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark05(-1.181092558734539,-1.5707963267948948,90.89138614620333 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark05(-1.1816456643052071,-1.5707963267948966,-77.98651461473247 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark05(-1.1818614235263263,-54.86974799271739,6.2833124677019345 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark05(-1.1819121522547074,-1.5707963267937914,1.5707963267948957 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark05(-1.1828674666124106,-3.2273626336177625,-1.5707963267948966 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark05(-1.1832727745214906,-60.78098481273535,-1134.0552496859675 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark05(-1.183968578150854,-2.710505431213761E-20,-100.0 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark05(-1.183988750962265,-0.6628721920953659,8.599207015180639 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark05(-1.184118522029866,-3.873516599827795,-1.5707961830670887 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark05(-1.1848358808645014,-0.004844240096546167,-78.59422984966763 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark05(-1.1850975303300988,-0.0031091324143930343,64.90244187722136 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark05(-1.1851209384828199,-54.68078525917428,6.594917835377503 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark05(-1.1851672286144481,-129.6309524427882,-90.60937665693088 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark05(-1.1861771257380993,2.633011975341526,-95.26065575471661 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark05(-1.186414663328999,-0.4801561245104498,-1.5707963267948966 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark05(11.864372328509091,14.530454790138478,-92.2084648215743 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark05(-1.1864484798002257,-92.56474497255516,-9.525415839471629 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark05(-1.1874731678779942,-3.161682939565713,-1.5707963267948966 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark05(-1.1880633580149216,-1.4195520218850013,73.82742735936014 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark05(-1.1882381714596377,-3.797711296417944,-28.00712985141707 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark05(-1.1891227335952639,-73.50822187930392,-56.08368777449619 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark05(-1.1895398164933675,-72.92950898760557,-73.31770711018066 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark05(-1.1904861982594888,-148.1243883793342,-53.80212441571255 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark05(-1.1907395026861165,-0.43739625310679814,1.5707963267948983 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark05(-1.1910550411110719,-47.52951482525965,1.5707963267948966 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark05(-1.1918341810211135,-6.6174449004242214E-24,77.74711550530317 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark05(-1.1922361347122021,-1.5709082420183815,-0.9269596786262884 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark05(-1.1927912431494787,-0.7316483889500489,38.736930411930445 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark05(-1.1934480489149129,-0.41964938855861145,-4.70096123099481 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark05(-1.193775549522769,-85.94003956588607,-42.304383354401786 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark05(-1.1938369744460284,-41.988860128502424,-22.449885241178364 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark05(-1.194154497482442,-22.88999496525048,-66.25685525516542 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark05(-1.1948343792706306,-1.5707963267948966,-19.624248447047915 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark05(-1.1950682081681947,-1.5707963267948983,-1.5707963267948966 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark05(-1.1955254335436791,-9.829145501679477,-167.41323631039631 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark05(-1.1957504598926434,-1.5707963267948966,8.85397400494807 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark05(-1.1960563462962746,-1.5707963267948966,831.1600723019498 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark05(-1.1961629944196013,2.5042253929789644,-1.5707963267948952 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark05(-1.1961693349635876,-2.0679515313825692E-25,-1.2252473422799348 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark05(-1.1963449342393062,-0.049046700753702765,-101.85030302455375 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark05(-1.1975513949122814,-4.368993584915619,-3.3607575816887305 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark05(-1.1977551485143134,-85.0724628019632,16.536158020097787 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark05(-1.1977632420978876,-1.058749793118925,1.5707963267948966 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark05(-1.1979242727784563,-1.5707963267948966,12.56832373943864 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark05(-1.198411987298047,-47.32086400424516,31.760701632845127 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark05(-1.199119634893929,-0.08747976577787786,-43.97303653201516 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark05(-1.199133946074113,-35.2173444729666,16.68031501730566 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark05(-1.1997574511165048E-240,-0.23707365674229752,-69.5907347976725 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark05(-1.2030468369479566,-1.5707963267948963,-82.0054704558864 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark05(-1.2030538054473143,-1.5707963267948966,64.96594423248908 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark05(-1.2033799023347254,-10.041981786999926,67.54424205218055 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark05(-1.203745171245897,-9.582832581677462,-91.96611669017521 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark05(-1.203943153944183,-1.5707963267948966,-1.5707963267948952 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark05(-1.2041918500440199,-85.0243481715515,-66.10586877354667 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark05(-1.2054351149448292E-11,-0.3392112361409403,1.430347970086828 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark05(-1.2054803226229733,-1.561187873037832,24.19505702099194 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark05(-1.2056092704990944,-1.36250238791207,36.95768605310446 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark05(-1.2056858875523488,-1.4644857045639221,350.0829266334226 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark05(12.065019466301678,-33.1745672693246,-78.37358132633847 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark05(-1.2069225914177064,-0.886799130853357,57.1855501430411 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark05(-1.2079357870623049E-15,-16.43122222034485,-1.1292878722785602 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark05(-12.088729652416049,99.47670341132385,-6.721456201370543 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark05(-1.2092762058300481,-10.0958331558286,-1.4137301237514528 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark05(-1.2095720922541795,-41.10241316022743,-66.54217815205911 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark05(-1.2101093004204464,-66.11149443008809,-55.074966737880885 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark05(-1.211381601682266,-1.5707963267948966,33.383777241086925 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark05(-1.2114176909238432,-66.22698057898225,1.5707963267948966 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark05(-1.2114382519791578,-3.141600662626171,1.5707963267948966 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark05(-1.2116726318013054,-97.97863501496835,-6.287091557372753 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark05(-1.2137232385757373,-0.016483950560495925,-91.11852158514571 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark05(-1.2140714389842155,-1.5707963267948966,-93.40019935934185 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark05(-1.2144711245958262,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark05(-1.2149151606645328,14.429231674510234,56.20673682027933 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark05(-12.158826468664017,-34.78995514325436,-89.17330177074656 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark05(-1.2161056740235097,-0.6628029491273802,-42.799278725158054 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark05(-1.2162125324240858,-160.3955706469374,66.44796012049221 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark05(-1.216321376781568,-0.12473516799130241,4.712404372590033 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark05(-1.2166986024289023E-209,-1.5707963267948966,34.05922741336604 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark05(-1.2169075042730688,-3.1419535735235318,42.738765767864635 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark05(-1.2180373373841462,-1.5707963267948966,1.5707963148997568 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark05(-1.2186879120142284,-0.38903408220189306,1.5707963267948966 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark05(-1.2196012731117984E-6,-4.0613089781366725,0.22300548432856906 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark05(-1.220054726346318,-0.0014952970653628744,65.40708243137794 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark05(-1.2209755288214788E-14,-41.37184851688956,-1.5707963267948966 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark05(-1.2209994312985471E-6,-2.710505431213761E-20,-89.60368019102555 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark05(-1.2213690654701819,-9.590974050448217,-737.8601930487914 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark05(-1.224227256272157,-2.220446049250313E-16,50.45368690136084 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark05(-1.2248498423497725,-1.4519554659364944,56.49254402971068 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark05(-1.2258084053625027,-0.05984171202988115,45.75914954540997 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark05(-1.2260411025694764,-66.97436510556658,-56.17287101350731 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark05(-1.2267684005394508,-0.058633118867477366,1.5707963267948966 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark05(-1.226791366616204,-72.42675833879773,-7.853981633974484 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark05(-1.2268712078208575,-97.73147589401857,-18.852863805410625 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark05(-1.2272898044178988,-1.5707963267948957,-57.741372893291434 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark05(-12.275392730267697,13.662494458193322,-56.182645756049695 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark05(-1.2277798980184444,-1.3760569360538417,-0.4708567610273211 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark05(-1.2281186323647684,14.429205234754079,100.0 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark05(-1.2289964725685778,-53.61426793874349,-4.712388980438673 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark05(-1.2292090841504297,-1.1479160431823459,31.867290542954464 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark05(-1.2297356927340521,-0.30460334625267305,1.5707963267948966 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark05(-1.2298024850745657,-1.5707963267948966,-5.468518140861435 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark05(-1.2298810739645576,-98.32196847748345,90.55467609779035 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark05(-1.2302217535304785,-0.35606058627316994,57.85939933727588 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark05(-1.2315922455135377,-1.5707963267948966,-69.54871932453123 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark05(-1.2317415552848625,-0.8840325457161655,100.0 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark05(-1.2325060481608427,-1.445819453388312,77.01691203244457 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark05(1.232595164407831E-32,-1.5707963267948966,-81.72526911552612 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark05(-1.2326332607054127,-72.83662815193836,90.14836476452746 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark05(-1.2326569502074278,-8.881784197001252E-16,100.0 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark05(-1.23376588061127,-34.614329605676716,-5.141592653592962 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark05(-1.233793157966987,-1.5707963267948966,0.6826573231850416 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark05(-1.2341031949299428,-42.39274283384412,-46.38470108053465 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark05(-1.2345372933018206,-4.383618698016806E-193,2.583338001158006E-308 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark05(-1.234734484229231,-4.051353469492708,-179.4049714012241 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark05(-1.2358150534197752,-0.16994589006873978,-46.435946832287065 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark05(-12.358322912625823,-16.647622733362127,67.14957231275207 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark05(-1.235947421321761,-173.2815619002316,23.566187529902706 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark05(-1.2367223670757381,-48.654068704467946,-78.46386180498739 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark05(-12.368799159777438,-76.25093825507845,-94.02510764833256 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark05(-1.2369105338213235,-0.004232474889586474,1.5707963267948966 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark05(-1.2370965555772346,-1.5707963206298272,-42.965273310888634 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark05(-1.2379012290420228,-1.3324007071578012,82.25915028562913 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark05(-1.2385388961660506,-72.49084607728626,-3.1453497699939366 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark05(-1.241631606000848,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark05(-1.2422554169565188,-37.695647413668624,-45.9151119997298 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark05(-1.2434747267721606,-1.2748489029104115,-3.1435502701816245 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark05(-1.2440727790450945,-10.215345706468362,6.509619532097183 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark05(-1.244433472481873,-1.5707963267948877,3.477086101554832 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark05(-1.2444991062687252,-64.29928876080491,-72.61388114162614 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark05(-1.244601008191141,-22.99284165636515,-1.5707963267948966 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark05(-1.2449192458534,-959.0701946895934,89.59508878668356 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark05(-1.2480839003582285,-1.5707963267948983,1.5707963267948948 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark05(-1.248284194843489,-0.9396360658159674,1.5707963267948974 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark05(-1.2487931835307284,-58.95958668643117,0 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark05(-12.490233160605584,-45.339718724251114,44.91950908234119 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark05(-1.2491337008730925,-1.5707963267948966,-12.475898940523315 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark05(-1.2498130210115013,-42.40373964817506,28.31560670389757 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark05(-1.2503492501177413,-1.5707963267948966,832.3503832107167 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark05(-1.2509634799959457,-98.81158550419016,-32.423292032784126 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark05(-1.2513019344894381E-147,-1.5707963267948966,47.95222966787886 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark05(-1.2519747960118417,-2.220446049250313E-16,5.642219724023207 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark05(-1.2519892144813127,-72.92732803086217,23.691233008023033 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark05(-1.2524592807379915,-0.46513899688644145,59.72385969949991 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark05(-1.2526916501799166,-1.5707963267948966,-4.141594715939212 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark05(-1.2530966320489254,-1.5707963267948966,-20.420354644961368 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark05(-1.2543801902623473,-0.2429362783596477,90.41145769329083 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark05(-1.2544120394046967,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark05(-1.2550291288507909,-0.03910912215539304,-1.5707963267948966 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark05(-1.2551691107121863,-66.00469572553018,-1.5707963267948966 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark05(-1.2554990617522188,-1.5707963267948966,91.9214051095654 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark05(-1.2561373623281185,-0.4134087247528846,1.5707963267948966 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark05(-1.256358795465711,-42.21745894351854,21.82045744463334 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark05(-1.2568612625234987,-1.5707963267948966,2.7905235481389474 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark05(-1.2569034395808307,-54.40749728855909,0.5847803255641099 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark05(-1.2569534017657524,-88.48576431785911,-1.5707963267948966 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark05(-1.2585152813821745,-1.5707963267948966,-29.98332971305588 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark05(-1.2586058331977048,-0.016236523856602125,3.371746782659161 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark05(-1.2598769079665202,0.2753627744897148,100.0 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark05(-1.259920183950129,-35.96535119792848,-123.69337313799107 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark05(-1.2602750406147606E-15,-80.01682960303,-1.2871959973110545 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark05(-1.2602777581685491,-425.45747486739714,111.80303252615803 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark05(-1.260471820912602,-0.11987260988010764,20.010442927371034 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark05(-1.2606923673134744,-10.760234707408808,-1.5707963266184524 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark05(-1.26095752735403,-3.4642885118353597,91.05765356212044 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark05(-1.2610194875274119,-3.8797181464834907,17.278759594743864 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark05(-1.2631993301587296,-41.727441016299196,3.1415931214869106 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark05(-1.2635849633715237,-1.5707963267948948,69.3616869199866 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark05(-1.263739864332436,-0.1320902904756165,-1.5707963267948966 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark05(-1.2652989091899065,-0.01188804213644903,29.42203672684846 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark05(-1.2666187887275029,-1.5707963267948966,-28.27020145937893 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark05(-1.2668282837343936,-1.559699187139603,-94.62824233122795 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark05(-1.2674263349092603,-1.5707963267948957,9.534477135012981 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark05(-1.2685634919211257,-1.5707963267948966,-88.60368458975276 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark05(-1.268914290763263,-0.7813460213601324,136.28066921085335 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark05(-12.689271235300879,-32.73243420402477,44.141450365072984 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark05(-1.269451810217005,-0.2716286607954985,-32.716229470905574 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark05(-1.2694568595237896,-59.72026393246278,28.703537671734942 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark05(-1.2704099441559293,-66.08392314426156,1.5707963267949019 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark05(-1.27049123678811,-0.5944776607926456,-49.874705222626936 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark05(-1.2714328902669925,-3.277717864718166,-95.34113778597421 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark05(-1.2715689291629613,-1.5707963267948963,-88.39787566325036 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark05(-1.2720308033056853,-1.5707963267948948,0.2903636540784052 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark05(-1.2721539019291102,-1.5707963267948966,8.840290565194593 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark05(-1.272201033432526,-0.3348104473283261,23.493783370936328 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark05(-1.273204530277674,-0.39543109176450236,18.91667890008513 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark05(-1.27329604265037,0.2027382822740308,-76.94211770858568 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark05(-1.273461029023641,-0.20152026869169787,-5.141592654571179 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark05(1.2739164910665737,-1.5707963267948966,28.607720696396452 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark05(-1.2744802255890615,-42.09206242334107,119.89515571460296 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark05(-1.2748454881868516,-66.07030621947459,-4.141592664588729 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark05(-1.2770544676269324,-1.5707963267948966,-0.2142716500826443 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark05(-1.277403964371359,-0.021908874351662264,-91.10617577111233 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark05(-1.277564918554235,-0.2694575124248494,12.990278125371475 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark05(-1.2777215320461193,-10.504869196708384,-174.01895457234954 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark05(-1.2786371403353978,-111.10055937212869,63.26230787887472 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark05(-1.2792293279396254,-34.98151465710789,-44.40436126267322 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark05(12.804243622191507,73.17549264420816,15.760672455401988 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark05(-1.2810991169084749,-1.5707963266956744,1.5707963267948966 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark05(-1.2813217654344324,-36.04564413140707,-2.3651511146725657 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark05(-1.281945748183969,-135.34536753269776,14.137166963176098 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark05(-1.2825230668168195,-9.956112076558355,-1.3234889800848443E-23 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark05(-1.28337007685318,-1.5707963267948966,-66.45620602344925 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark05(-1.2835945078127282,-1.5707963267948983,53.40527544550736 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark05(-1.284132897461717,-0.13955314802760652,-1.5707963267948966 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark05(-1.285024437067061,-0.019022086338972573,50.22037450262175 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark05(-1.2869834672498204,-0.47374549052777004,1.3952792088964716 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark05(-1.2877455028934213,-1.1226056283496453,-56.04059676336331 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark05(-1.2878402506797628,-1.5707963267948966,19.751565501783897 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark05(12.88088185040634,-30.8410043839922,-12.463417131840828 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark05(-1.2886074353390407,-61.240153934590076,31.419048632586303 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark05(-1.289291360612202,-1.5707963267948966,3.3077462801254 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark05(-1.2901430515904577,-15.7587726206173,39.74052471466274 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark05(-1.2910074538318432,-0.4867740762767911,3.141595880156695 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark05(-1.2910494019197518,-1.5707963267948966,75.59057159865108 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark05(-1.2926885740042662,-154.5064323389418,70.73029281077498 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark05(-1.2930502057542113,-0.07588314665595304,14.138186875330796 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark05(-1.2942910802702507,-1.3006892398884762,84.73131292792779 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark05(-1.29461954782189,-22.90685512735489,0 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark05(-1.2956127966006084,-0.9462938707894173,-68.02711948762222 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark05(-1.2957074648889435,-0.26824859830007997,0.06764423678579046 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark05(-1.2962290849658116,-1.5707963267948726,-26.90378493970475 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark05(-1.296641399070353,-66.96587384326091,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark05(-1.2972296976741058,-0.11911478293594678,-1.5707963267948966 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark05(-1.2973012732678115,-1.5707963267948963,-7.207893417993178 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark05(-1.2973235934378724,-97.4206601713711,18.711206143610436 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark05(-1.2975486785423058,-66.01503234457304,14.150177993625856 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark05(-1.299355693112339,-3.5643267047641096,-25.653790717660492 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark05(-1.3012053664333862,-1.5707963267948966,90.71687052739858 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark05(-1.3025539465778464,-79.20483227327955,-8.805826958324233E-17 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark05(-1.3025858352511401,-0.06757887933021155,28.085933795372924 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark05(1.302807925265167,-78.59188305169234,-10.213641847495552 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark05(13.028817877412962,84.17305365628744,-82.89954948766231 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark05(-1.303502525742967,-66.71580780773733,-19.670967617301642 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark05(-1.3055363866280267,-1.5707963267948966,1.5707968227219888 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark05(-1.307145340184442,-60.99834800076821,1.5707963267948966 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark05(-1.3072501261922536,-98.76189492330836,-80.11061420941468 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark05(-1.3074895266306295,-1.5707963267948966,6.042344579595567E-17 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark05(-1.3075673661629459,-1.5707963267948966,79.00265305933239 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark05(-1.3081273613686493,-66.88727143608561,1.5707963267948966 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark05(13.083175647248126,84.33709249041536,37.484403512653785 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark05(-1.3087806090022127,-1.5707963267948966,35.75777509965649 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark05(-1.3111036691737183,-1.5707963267948966,-71.75865566982307 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark05(-1.3114945387916452,-10.01199795500547,-1.570796326794697 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark05(-1.3114980429209286,-104.67742066577387,-98.89065687836904 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark05(-1.3121250537148383,-48.38773250778955,-0.2869689955638056 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark05(-1.3126001196992911,-35.32671349944172,-1.5707963267948983 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark05(-1.3127177183025034,-1.3900956124118016,-100.0 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark05(-1.312742999758888,-9.504966109221954,48.80555373877956 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark05(-1.3130230964357068,-10.946753882360994,-1.5707963267948966 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark05(-1.3132661375916452,-66.04828929340246,3.141592679834043 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark05(-1.3134517764154804E-287,-1.5707963267948966,-28.260635237256324 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark05(-1.3135471042670162,-0.17480507519874866,0.4591206052624983 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark05(-1.3136873622019856,-1.346386388808202,-57.8403863070585 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark05(-1.3139466413724668,-1.2917118518042472,59.431508286861 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark05(-1.3141277740334365,-9.630118627916538,91.10707331429981 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark05(-1.3149369205091712,-682.2989497563883,-17.161238167572435 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark05(-1.315555431110539,-0.060176459850477544,-78.34919354099783 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark05(-1.3160413709780363,-0.7651913585272692,29.117028749406764 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark05(-1.3162322074686226,-67.03299509244407,-60.838658985152364 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark05(-1.3165336341348255,-61.007482353206655,-0.2990271474260894 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark05(-1.3168054655798307,-41.972389105183424,-4.712398935368145 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark05(-1.3169375636709475,-66.04405269195577,6.833636189357968 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark05(-1.3172950154098577,-1.5707963267948966,0.3953823859240176 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark05(-1.3179810156734726,-0.7974453256539942,42.930466762611104 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark05(-1.3185939765922408,-1.5707963267948966,8.103988952687478 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark05(-1.319449683965028,-1.570796326848357,212.0581164926976 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark05(-1.3195975197527274,-10.035272641763951,4.712388980647223 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark05(-1.3196146166688685,-54.83687292818675,124.23626882647166 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark05(-1.3209822594088143,0.5103464579214595,1.5707963267948966 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark05(-1.3211710376664736,-66.22677478889787,58.119464091411174 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark05(-1.3216109319008584,-1.5707963267948966,-0.7869840702064941 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark05(-1.3216811140014835,-1.5707963267948966,-68.71114240740228 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark05(-1.3223310833577873,-48.631072349275165,27.69752288112889 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark05(-1.3227400254686668,-0.8522972113953191,-39.498410571377875 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark05(-1.3228565112867454,-0.6271181759356192,88.91182406882706 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark05(-1.3228819360931983,-41.7297860455281,-76.81922735345458 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark05(-1.3229027973033816,-1.5707963267948968,48.46469978664956 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark05(-1.3234469788098808,-18.749346724060757,-50.79810753559673 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark05(-1.3234889800848443E-23,-0.8343771084602263,47.13740541052482 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark05(-1.3241351970627215,-1.5707963267948966,41.691865821076476 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark05(-13.244073218368982,-35.64521384725221,-46.36677907929996 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark05(-1.3246610259578226,-35.41988088033397,-8.222794725409564 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark05(-1.3249076685890506,-1.5707963267948966,47.270822461017026 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark05(-1.3250656918470174,-1.5707963267948966,-72.30917261958695 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark05(-1.325331403422593,-1.5707963267948966,15.782278661995463 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark05(-1.3263838934360177,-1.5707963267948948,-64.73466174697488 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark05(-1.3279237942998066,-35.89867197613084,84.82300164692441 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark05(-1.3284240877092857,-2.220446049250313E-16,-12.569717443309143 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark05(-1.3285463892457805,-3.1415929645551284,-98.07148794207731 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark05(-1.3289830767294828,-1.5707963267948966,14.856921218322185 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark05(-1.3290198698590683,-41.39539332529412,-66.201561691748 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark05(-1.3295244035862677,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark05(-1.3302129945036436,-53.55767602525751,-1.8726705418768793E-96 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark05(-1.3302343387484883,-0.3922290529742902,84.52652353996501 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark05(-1.3306173940281383,-1.5707963267948966,-26.168345026998985 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark05(-1.330853295597558,-92.62900029309624,-3.149405161956191 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark05(-1.330976943747043,-10.210309813668104,1.0749119012881891 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark05(-1.3319983461951343E-256,-1.5707963267948966,-2.0436409343386736E-14 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark05(-1.3322634197655225,-0.08588816372637773,-1.5707963267948966 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark05(-1.3327518212354406,-73.073869970863,0.0 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark05(-1.3331519293046612,-1.3561866323557574,77.40500325694103 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark05(-1.333374027666445,-0.5342075250824365,-1.5707963267948966 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark05(-1.3343003462319127,-1.5707963267948966,20.42035226732028 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark05(-1.335722573231213,-72.51960919895528,-0.4599949859571568 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark05(-1.336348274190529,-1.5707963261520055,-73.64320725433001 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark05(-1.3375685722296973,-1.5707963267948966,-14.122655580797954 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark05(-1.3376890555516125,-9.53111415045132,-13.490752110965815 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark05(-1.3378730597761836,-10.771642681037946,-36.084390771355515 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark05(-1.3388803430185654,-1.5707963267948912,-34.433893032763606 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark05(-1.3395735566582516,-10.92594281725328,-59.86967995632578 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark05(-1.341046340747475,-0.1640015224462808,1.3603011247202161 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark05(-1.341258658759921,-16.80891816808134,-1.546527987402975 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark05(-1.3415064070664173,-4.555024604599355,-4.3594680040130545 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark05(-1.3416209144701716,-1.5707963267948963,-78.5319560916802 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark05(-1.3416300469741245,-1.5707963267948966,75.42947369161485 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark05(-1.34394783447157,-91.88785912707809,-48.25961714796993 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark05(-1.3448285399805002,-54.970532161726965,59.36184276359942 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark05(-1.3461773605484308,-1.5707963267948966,6.573444838056905 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark05(-1.346545523588027,-35.80417148963642,75.26497503444236 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark05(-1.3470911258181002,-66.9016321983565,26.478816430553408 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark05(-1.3472316158791735,-1.4914616580841962,25.195365729310744 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark05(-1.347458238204004,14.429212572845799,1.5707963267948966 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark05(-1.3483530050200483,-1.5707963267948966,3.2665929956210524 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark05(-1.349373296298296,-56.874453712266224,0 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark05(-1.3501865222545266,-0.8518847268807703,1.5707963267948966 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark05(-1.3506640408178905,-0.8966908368276263,-22.395634683914643 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark05(-1.3507739153725107,-1.5707963267948948,-32.80444638699032 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark05(-1.352182554457522,-72.78125347418823,84.58616792433594 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark05(-1.3522572729420594,-1.5707963267948966,6.2996613786326146 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark05(-1.352508690178992,-28.369400630697204,-75.66158582036701 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark05(-1.352710201915955,-9.642257324167185,-90.87463745829976 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark05(-1.35290471273355,-796.0170720668852,-56.435143741263424 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark05(-1.3537007710620923,-1.5707963267857876,100.0 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark05(-1.354548321102098,4.930380657631324E-32,-97.98931960226547 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark05(-1.3546643040156583,-0.2963662678745649,-72.3331996514137 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark05(-1.3547385596308448,-1.5707963267948983,43.22196208704776 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark05(1.3552527156068805E-20,-0.494210246947187,-25.676367419412955 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark05(-1.3552527156068805E-20,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark05(-1.3552527156068805E-20,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark05(-1.3557276333151487,-103.78319321964452,1.7161637003588568 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark05(-1.3559579242256228,-41.52312492626446,71.2708161929406 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark05(-1.3560234805075277,-1.0544435361875961,28.413476894591895 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark05(-1.3571684938993056,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark05(-1.357951133967477,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark05(-1.3588188245476776,-1.5707963267948966,6.2835395954798745 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark05(-1.3596537071991268,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark05(-1.3600889491920727,-1.5707963267948966,20.494927232720865 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark05(-1.3604087219314323,-97.88065129515012,0.021306155441643666 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark05(-13.616800323934925,-11.311857476916586,71.43302301162001 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark05(-1.3617220374488426,-72.6061668952251,-72.47845709690674 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark05(-1.3618547696816978,-1.5707963267948966,-57.26028455992676 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark05(-1.3620674880354646,-0.12589378303578905,9.092010475569367 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark05(-1.3622093551897831,-0.7627038731233664,-76.04544756599228 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark05(-1.3624008604396078,-28.77248773669993,-0.646051608848272 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark05(-1.3624154199396064,-60.6984235061759,-6.2831853071786234 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark05(-1.3624789389976153,-3.1572176535897936,-19.19005279868938 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark05(-1.3628001568867427,-1.5707963267948966,-692.6744774910253 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark05(-1.3630554086431983,-35.54299346791477,-100.0 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark05(-1.3631400685579627,-23.43451786661781,-1.5707963267948912 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark05(-1.3633997423986053,-0.0030873259677626774,53.76109664423521 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark05(-1.3640298984221073,-1.4639691907415562,10.36554905572487 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark05(-1.3644959845747735,-1.5707963267948968,-1.3732337727219939 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark05(-1.3648228041595931,-1.5707963267948966,22.365639698112357 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark05(-1.365607904872096,5.551115123125783E-17,36.41503034818032 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark05(-1.366238966241018,-1.156836518073689,60.296349475184655 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark05(-1.3664945087515122E-8,-54.90880996046712,54.43073153381842 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark05(-1.3671152511222915,-41.44878075649483,76.75829121948013 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark05(-1.3675292815537725,-35.6008216249778,-942.1701342526999 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark05(-1.3679728913435704E-17,-1.5707963267948966,75.80888771336802 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark05(-1.3679991420105817,-40.84070449667105,53.43742546762184 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark05(13.681387501588077,3.185592582016824,-55.732010083500036 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark05(-1.368191681939993,-2.5243548967072378E-29,-50.664837117600335 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark05(-1.3697166125477311,-123.05776573256104,644.7229642173047 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark05(-1.369842213145254,-0.4338124486869775,-28.70353755551325 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark05(-1.3698808431302519E-194,-97.9407674285786,20.847556472199024 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark05(-1.3716376101041777E-16,-1.5777218104420236E-30,-1.5707963267948966 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark05(-1.371877096797165,-97.79108013702738,39.07959629905456 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark05(-1.3723848897225597,-73.06498912382183,0.0 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark05(-1.3729450633022253,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark05(-1.3732607267313386,-35.78991229226839,33.56243589310409 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark05(-1.3738878829134848,-60.75977410854051,3.14195010625043 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark05(-1.3740548465911395,-50.203567818371944,-78.65296846004678 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark05(-1.3742004235410823,-60.925673555693905,3.1420809407082726 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark05(-1.3748564601577158E-6,-1.5707963267948966,9.492610863798495 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark05(-1.3755930162252312,-35.68791668423088,0.5994494647180183 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark05(-1.3756343515917622,-9.585812358469298,1.411457204122738 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark05(-1.375650942138762,-1.5707963267948963,-96.50391026112781 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark05(-1.3758210268297398E-135,-41.04909804647866,1.5707963267948966 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark05(-1.3765048486126545,-1.5707963267948966,-74.47864088736542 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark05(-1.3769229232715285,-54.90097699315252,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark05(-1.3773061552661123,-0.363631942660297,-69.48488579738574 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark05(-1.37787879045778,-41.38427081081044,-52.82345683973682 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark05(-1.379284894078193,-3.1415930253253195,-29.6698778512514 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark05(-1.3802898715279222,-72.2566315094025,-42.53697562356806 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark05(-1.3807129053261828,-155.12472857893317,-224.62387808901966 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark05(-1.3810050375442737,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark05(-1.3819809880208174,-98.82151177845877,-1.5398724260437937 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark05(-1.3819826168761244,-0.21334928377954787,-45.50227315826476 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark05(-1.3828215538779602,-0.04927428103635989,0 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark05(-1.3828911128700896,-4.141592675193336,-1.5707963267948963 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark05(-1.383008640672167,-1.5707963267948966,-1.5707963267953649 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark05(-1.3831905521778958,-0.35254758120493573,72.1174051726403 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark05(-1.383263708814253,-1.5707963267948966,18.313209625493016 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark05(-1.3832818477749222,-1.5707963267948966,28.05877256081844 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark05(-1.384064513770781,-0.08497352760307611,-118.94684247614799 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark05(-1.384164234281461,-79.70170905757391,-1.5707963267948963 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark05(-1.3844529088275555,-10.415792441684722,3.720602724063241 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark05(-1.3847732059174036,-1.570796326039518,0.0 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark05(-1.384859942749411,-1.5707963268225344,1.5707963267948966 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark05(-1.3861463296283616,4.141592659850108,-158.0211253669764 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark05(-1.3862554667816938,-1.5707963267948966,-55.927650985138804 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark05(-1.387742646046246,-15.886316072572699,-37.73141043600348 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark05(-1.387778717584758E-17,-1.5707963267948966,78.55544133975579 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark05(-1.3877787807814457E-17,-1.5707955190230667,-44.045426442125816 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark05(-1.3877787807814457E-17,-1.5707963267948966,1.5707963267920848 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark05(1.3877787807814457E-17,-1.5707963267948966,55.16396847286625 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark05(-1.3877787807814457E-17,-1.5707963267948966,5.556896873712694E-163 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark05(-1.3877787807814457E-17,-1.5707963267966727,63.944081215352966 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark05(-1.3877787807814457E-17,-23.459768559185058,-56.31143633840382 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark05(-1.3879952096427677,-3.287300107798881E-7,-73.21142266350242 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark05(-1.3881921580311873,-161.63811397486063,-1.5694394055897574 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark05(-1.3885007119625912,-0.041320529043341554,66.72853155880448 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark05(-1.3886593194850316,-34.95491383046897,22.369631564207552 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark05(-1.3892603372078287,4.141592655164412,1.5707963267948981 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark05(-1.38944570562961,-1.5707963267948966,-5.141592655757592 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark05(-1.3902933801021238,-1.5707963267948966,-28.854003169899855 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark05(-1.3914074726933547,-413.11651796624403,-82.63116396221494 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark05(-1.3915374678892478,-15.948851188345081,-66.68290877386028 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark05(-1.3915914716897568,-98.06487480479318,92.1812623052834 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark05(-1.392002605919194,-1.5707963267948966,-513.1037610294783 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark05(-1.3944554977303474,-1.5707963267948912,-54.74466685113215 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark05(-1.3948058920053512,-1.5707963267948968,-86.39379797371932 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark05(-1.3949860854723466,-66.55516068763329,-3.1685907511693787 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark05(-1.395338196200145,-1.3469871935379656,-7.853981670590211 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark05(-1.3954548423596655,-55.637953559784734,71.34414066347068 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark05(-1.3955199540737087,-9.42481618176844,-129.57688112412526 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark05(-1.3957976320196581,-1.3101224952488186,-4.712389083036129 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark05(-1.395829420306659,4.1415926553563205,96.18668557732164 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark05(-1.3970034491047616,-1.5707963267948966,1.2761554623996947 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark05(-1.397837155450861,-1.3892242184281734E-163,-1.5707963267948966 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark05(-1.3983342641344334,-72.8075112256057,-1.5707963267461122 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark05(-1.3994202530644821,-1.5707963267948966,78.23849323300723 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark05(-1.3994496917246826,-10.01178999192362,-3.1191478338146936 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark05(-1.4008491310642854E-5,-1.5707963267948966,-65.9721467934293 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark05(-1.4010663853690353,-1.5707963267948966,61.84010459161445 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark05(-1.4017005738888333,-1.5707963267948966,88.15698531450425 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark05(-1.401732464830099,-98.7227824515868,-6.283185307179591 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark05(-1.40190930984032,-1.5707963267948966,-45.734976592950034 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark05(-1.402757983365378E-191,-1.5707963267948966,87.41795778722246 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark05(-1.4028462685449314,-1.567037764916115,-12.570723011227388 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark05(-1.4029093664992867,-0.002908408214705241,-100.0 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark05(-1.403041869048427,-1.5707963267948877,691.4480825834834 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark05(-1.4035657071644723,-1.5707963267948912,-90.06823012074271 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark05(-1.4035874443000163,-22.366612968486493,0.0 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark05(-1.4036989439173266,-3.163847603167259,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark05(-1.4037481323385754,-1.5707963267948966,-91.79730403741975 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark05(-1.4046704318621548,-28.34256455330791,41.31878685697697 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark05(-1.4048084879438523,14.490654074777531,3.1416006409082993 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark05(-1.4058565870988007,-1.5707966136562697,4.712391995350789 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark05(-1.4064510072688812,-73.18576133952027,-68.3301333799135 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark05(-1.406713854254244,-1.5707963267948966,1375.8282073655582 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark05(-1.406761769554051,-9.94726062078233,23.271197084856027 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark05(-1.4071221091756394,-0.2377647514995389,25.8391633578295 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark05(14.071259054128234,0,0 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark05(-1.4077400152255757,-1.5707963266359235,-12.696034823739176 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark05(-1.4080615598044073,-0.054545404559994966,-82.48098026030534 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark05(-1.4084023407218318,-1.5707963267948966,3.552713678800501E-15 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark05(-1.4088407314736535E-132,-0.3917628533611407,7.662654212598085 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark05(-1.4097488178241446,-0.5628756842435987,22.640504458435174 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark05(-1.4101055848179525,-16.026494742914615,-7.854308254682248 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark05(-1.4111710125411527,-0.017534232136062682,1.5707963267948966 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark05(-1.4115332849931739,-1.5707963267948966,-0.09830397736819663 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark05(-1.411762223357255,-0.069394352019125,290.5767320554273 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark05(-1.4121775431823762,-66.45709432864393,-32.78744706013259 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark05(-1.4122365571750095,-1.5707963267948966,53.29269408644376 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark05(-1.413427396645941,-10.070407695166205,98.60701851420723 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark05(-1.4135069806356073,-78.93169109407185,26.97196815864844 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark05(-1.413607387024837,-136.18462624010064,-50.140033280084374 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark05(-1.4138639556722608,-8.158242822143226E-16,-41.97692384042603 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark05(-14.142347537444138,35.95445772239674,3.5934729296236014 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark05(-1.414446475177566,-0.11595590186021987,18.655126274637595 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark05(-1.414523215265354,-1.5707963267948966,0.020576253956164976 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark05(-1.4145919269723162,-1.5707963267948966,-90.85433739349492 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark05(-1.4146339536610015,-35.218184341968815,33.47926466579193 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark05(-1.4148736933216288,-0.7002850475571791,-14.43692624875655 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark05(-1.4149064955469282,-1.5707963267948983,-33.46199614208342 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark05(-1.4149498560666738E-73,-1.5707963267948966,49.92823700994091 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark05(-1.4154324605346231,-3.1415926535989485,0.0 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark05(-1.415668467123437,-35.64973916181094,-20.420352248333657 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark05(-1.4160074344362659,-110.29536552675883,0.023774203296309443 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark05(-1.4161208655601838,-167.38314016538834,-192.38421813126268 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark05(-1.4162577872717603,-1.5707963267948957,72.08915914714623 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark05(-1.4163196600090164,-1.5707963267948983,-44.73607342267067 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark05(-1.4167000847553337,-9.547931118461243,0.003806614635537997 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark05(-1.4174608322840616,-42.04405074947408,-56.6230008474815 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark05(-1.4175180776046088,-66.53495702445507,-92.36262472802306 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark05(-1.4179531510238883,-1.5707963267948966,-91.03554588187993 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark05(-1.4190130304544755,-1.175236271711187,44.09408371167689 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark05(-1.4192611512693745,-1.2550213763940234,-64.90908747878935 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark05(-1.41959957469861,-570.0255115550151,-1.5707963267948948 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark05(-1.419796621507873,-1.5707963267948966,9.64932657880345 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark05(-1.420233063522488,-0.7873353104039102,9.60720701048609 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark05(-1.4205393715423538,-66.4724200772065,-0.11175723175987493 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark05(1.420545771074132,-34.62576835852388,1.5707963267948963 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark05(-1.4209560415392746,-1.5707963267948961,12.566378301511984 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark05(-1.4210854715202004E-14,-1.5387012203225314,57.29572595594604 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark05(-1.4210854715202004E-14,-1.5707963267948966,92.32599587776096 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark05(-1.4210854715202004E-14,-16.018170213856678,184.41702612813532 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark05(-1.4210854715202004E-14,-67.4504586529576,-30.781392786285323 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark05(-1.4226271959311385,-0.24434152291915245,140.9113015619539 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark05(-1.4229151865876462,-1.5707963267948963,-9.61838151042654 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark05(-1.4233517393418436,-73.76909664286512,-1.5707963267948963 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark05(-1.4234671988894372,-268.5863802779734,-53.59583121862349 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark05(-1.4239138486391894,-9.586426997261345,0.0 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark05(-1.423932179504172,-0.1007245196690133,2.5626663618343692E-144 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark05(-1.424482733441738,-0.7546445329993562,-3.3662938264047386 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark05(-1.424938992296601,-3.1416632437788223,-90.62062161752972 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark05(-1.4249469718161567,-1.5707963267948966,-3.1420809393102647 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark05(1.4259887626796892,-97.91987881277618,0.9828482152250473 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark05(-14.260028694467735,-16.547828050425096,-90.59464119279352 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark05(-1.4262789831543908E-5,-1.5707963267948966,-28.273542279360033 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark05(-1.4262819502087747,-98.62277829501748,93.75801351212976 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark05(-1.4265681911308894,-1.5707963267948966,0.5686931209947824 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark05(-1.426764949105718,-0.4179128456968959,1.5707963267948966 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark05(-1.4270138325868995,-35.3742278092021,118.00287495303698 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark05(-1.4275124968518031,-0.6704393435638036,-1.4716794157477517 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark05(-1.4287138692476744,-1.5707963267948966,1.570796125473114 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark05(-1.4298811881655116,-98.50627320586638,-31.568640749270244 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark05(-1.4303277380474881,-72.4551443775253,-161.50046841914596 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark05(-1.4304260875396242,-22.48953401623282,-99.520777648106 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark05(-1.4322891273382432,-1.5707963267948966,-1.262508559571418 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark05(-1.4324361417070741,-1.273565669848089,-18.972880355848147 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark05(-1.4327297767184461,-1.026876204289586,13.743787076199421 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark05(-1.4328552189535555,-35.072060325481246,-125.68028199659159 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark05(-1.4329656747061514,-47.33653151795036,47.24040282567993 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark05(-1.4334140394899495,-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark05(-1.4335609527385924,-0.19034814872279604,111.56017287938036 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark05(-1.4335730765362253,-3.7593780357272806,77.32666581317844 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark05(14.344134251415525,29.414679285353742,93.33754343310085 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark05(-1.4346167059940882,-1.5707963267948835,-100.0 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark05(-1.4347681929624008,-3.1420809438420654,-1.5707963267948948 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark05(-1.4355529386731334,-85.02125950157334,95.59702106848783 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark05(14.35570233058705,-49.62862554661478,60.746776594565944 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark05(-1.4364137371961467,-16.1084726457333,-1.5707963267948983 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark05(-1.436482032008196,-3.141592654485124,98.67089903224169 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark05(-14.370089614799866,50.14432618483764,89.74832121180759 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark05(-1.437393177779187,-0.6147409571203184,-42.63270683759131 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark05(-1.4379468591390254,-75.98133146188837,23.286803144846004 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark05(-1.4381963732517704,-1.5707963267948963,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark05(-1.4382078316984226,-1.5707963250883252,-0.7047295972320329 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark05(-1.438409319124536,-1.5707963267948966,-39.17364650210211 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark05(-1.439087413037686,-0.5290343914123827,0.32028350487383317 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark05(-1.439754031129894,-72.5826776873187,-2340.5925865837357 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark05(-1.4410845530718888,-15.723603879370762,66.11142454147775 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark05(-1.4422430990864288,-1.5707963262499225,1.5692501089435709 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark05(14.429204427938103,-1.570792224054937,-0.10201649081064747 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark05(14.429222441287301,2.7755304032578624E-17,92.82440034080079 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark05(14.429232177404032,-7.11960922595071E-18,61.17013833307373 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark05(14.429257153041767,-1.5707963267948963,76.54495901335105 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark05(14.429405891590704,-1.5086238013813544,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark05(14.429507467682598,5.421010862427522E-20,-0.5505708979983606 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark05(14.429548764835182,-3.268703766118951,-83.98814369858772 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark05(14.429657575040054,-1.5707963267948966,-84.68123630632795 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark05(14.429701647669134,-1.570796326794877,26.072085515871 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark05(14.42978082429834,-48.47639289646189,77.20183278646498 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark05(14.430306943074271,-1.5707963267948946,1.5707963267949125 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark05(14.430507551528109,-1.5707963267949,-59.72666785078044 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark05(14.430604375665425,-54.56653260783778,-1.5707963267948983 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark05(14.430748640677315,-3.2666060390328915,54.64201264344191 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark05(14.430941203393516,-1.5707678170425405,1.5707963267948966 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark05(14.431008624491199,-48.361461218683644,10.923858893330166 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark05(14.431137025753785,-1.5707963267948966,4.713077021749725 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark05(-1.4431519861910647,-0.3306327663033901,34.370466935669384 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark05(14.431547050203271,-35.768375050213905,0.30747355714701013 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark05(14.431585496033193,7.835787382851648E-6,-9.502453223657938 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark05(14.431623623884242,-217.18893616793721,-10.428471896667475 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark05(14.431949862284299,-41.58760055684035,-45.25675530906767 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark05(14.43196468762126,-1.5270295299340708,41.70323442366288 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark05(14.43221745054317,-0.7110772624978104,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark05(14.432374285094781,-3.1444715589089225,-3.240542685193513 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark05(14.43264464620691,-35.4777446939148,-21.850995119673954 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark05(14.432981390849136,-3.1416195385255046,42.74952556573936 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark05(14.433604712420028,-1.5707963267948966,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark05(14.434171571342517,-3.1438546185543137,92.0836664056042 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark05(14.43450126393072,-73.40758555646951,-112.6467371679182 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark05(14.434687291391079,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark05(14.435828568562371,-28.284367986066552,-100.0 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark05(14.43609883716352,-174.09834800185422,47.52129151360833 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark05(14.436755590201237,-1.5707963267948963,-32.58920647627596 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark05(14.43691847666274,-1.5707963267948895,100.0 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark05(14.43720152891484,-645.2349353839718,29.194219098219346 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark05(14.438048685648788,4.3790577010150533E-47,-88.78975858422913 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark05(14.439777172874521,-3.1416141397753203,92.38398349807136 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark05(14.439909266268302,-1.5707963267947065,-110.5682266760066 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark05(14.440769533659427,-3.250796962245201E-16,-83.2755139120633 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark05(14.44294510265319,-1.2680929977509396E-4,-64.02520056592496 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark05(-1.4443095867785625,6.835068763248878,1.5707963267949054 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark05(14.446460022813234,-1.556860228843856,-42.854666990251445 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark05(14.449377169033852,3.142120065626497,20.533723982951592 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark05(14.452044319402553,3.1533802810007274,-64.80924164979963 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark05(-1.4453159907926147,-1.5707963267948966,-4.712392569434307 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark05(-1.4453176963549001,-6.938893903907228E-18,8.14353128427918 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark05(-1.4455154823535477,-1.0155873955910373,1.0420130212230436 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark05(14.455391606936267,-1.0670721727772488,-32.98170432887251 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark05(-1.4458593860522921,-1.5707963267948966,95.77440755051555 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark05(-1.4459758548932256,-1.5707963267948966,-40.4882460709509 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark05(-1.445997112990891,-0.2357168646760256,71.24921104688073 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark05(-1.4460834109343454,-1.5707963267948966,38.17933213667442 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark05(14.46626171351253,-48.327362642926644,1.295398056467196 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark05(-1.446787983640658,-0.27129562293003606,75.40213191266132 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark05(-1.4468594423879515,-15.707963267948967,2.0331250373302288 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark05(-1.447086578095643,-0.10490704568377895,8.120164242541357 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark05(-1.4471811150108693,-53.712064277506165,-32.82287656992236 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark05(-1.4472542138162143,4.141592653592198,-14.315736850560167 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark05(-1.4475055174384517,-0.11963846259511227,-14.137211287363737 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark05(14.47542711166328,-85.02726771047838,0.0 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark05(-1.447604109781702,-1.1102230246251565E-16,40.61622218926094 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark05(-1.4482756265316254,-53.68599400751229,-136.23419270710045 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark05(-1.448415387419729,-41.613491296706556,-3.2391009375694466 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark05(-1.4487425471574404,-1.5707963267948966,42.040619719469376 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark05(14.497630065334505,-15.925797716748775,-1.1985574896490023 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark05(-1.4497957920004545,9.598071280184481E-17,54.46875425502515 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark05(-1.4506215917249172,-35.18679602717497,11.975203617341919 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark05(-1.450643456008061,-1.5707963267948966,59.54573448818553 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark05(-1.4507339784065627,-0.033350596211519194,-41.12098039248456 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark05(-1.4509355343732762,-0.11961630825570391,-3.183089343850142 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark05(14.512950337614527,-3.1451806518043,1.5707963267949054 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark05(-14.513786586173282,-59.83797716954753,-60.208555051615534 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark05(-1.4518275564386725,-1.5707963267948966,84.75043589330645 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark05(-1.451952051288142,-4.141592653589844,-92.49563585506495 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark05(14.520498553130949,-3.1575881726508745,-1.0919020911593058 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark05(14.52311879973702,-54.676563531349956,-0.4361410146836091 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark05(-1.4536010953488239,-1.5707963267948912,82.81047966671198 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark05(-1.4552862981904042,-1.5707963267948966,1.5707963267948972 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark05(-1.456302311436386E-13,-1.5707963267948966,48.77800207033055 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark05(-1.4564362755675864,-0.6322370421077905,-6.903109751373364 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark05(-1.4569918769199552,-1.1804152357195994,-28.13058181615175 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark05(-1.4577084581360569,-1.5707963267948912,-11.617283311382494 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark05(-1.4578988108749829,-10.621981981091295,-54.985472275719005 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark05(-1.4591733532636357,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark05(-1.459234684147139,2.815626879044101,1.5707963267948966 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark05(-1.4593096010038846,-22.546802352134847,-47.93668169158927 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark05(-1.4607848583163303,-66.69610175338907,-54.54777295153339 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark05(-1.4610471217730139,-1.5707963267948966,9.856844257051126 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark05(14.614885702864612,14.438188834787326,74.28660691950103 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark05(14.61500591897913,-1.5707963267948966,-97.66672113955208 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark05(-1.4618172802752554,-0.13714941927114555,1.5707963267948966 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark05(-1.4625973379049875,-61.2486047600451,-14.62689200765801 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark05(-1.4627839448921764,-0.6738133111836964,1.5707963267948966 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark05(-1.463059913811378,-78.32176658058836,-6.409094288122489 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark05(-1.4631142526229342,-47.37941381694569,-97.88633225695416 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark05(-1.4633866949913448,-53.7198581708695,3.142080934841889 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark05(14.634009164597707,-3.147457505311006,-0.061586330077490196 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark05(-1.4636785041230362,-0.08633929349985636,-50.05575287023224 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark05(-1.4646753423178667,-1.5707963267948948,5.551115123125783E-17 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark05(-1.4649084602041433,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark05(-1.466026931321136,-3.7215223786337503,-60.76299522398082 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark05(-1.4667653330328552,-53.68363569395813,-54.59024256831355 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark05(-1.4673272597488267,-613.3427359356766,-46.652089208329414 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark05(-1.467945382477353,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark05(-1.4680382193166515,-0.4702935842894883,10.78814675279969 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark05(-1.4684651094255006,-73.34514453827305,-78.83424351869806 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark05(-1.4684674441397472,-1.5707963267948912,63.68860191163869 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark05(-1.4688397379503186,-72.42195367259713,0.0 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark05(-1.469493084603283,-98.89163296538486,1.5707963267948983 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark05(-1.4695621451809868,-61.159857005006415,-57.2082416763422 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark05(-1.4696415238048957,-73.09564681691296,2.9090144881251057 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark05(-1.4699251585936464,-1.5707963267948966,58.08084703375953 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark05(-1.4702527295193144,-1.5707963267948966,147.6548489686357 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark05(-1.4713453257471614,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark05(-1.4718162378355044,-54.75622251969945,-1.1012608615559571 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark05(-1.471901155657158,-42.30984312559955,1.5707963267948966 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark05(-1.47244052432308,-15.758869336350147,56.81118341103507 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark05(-1.4728315744946978,-1.570796326794897,-1.5707963267948966 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark05(-1.4733297249466475,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark05(-1.4737483892831034E-8,-1.5707963267948966,160.2348881351799 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark05(1.4741256780234469,-1.9259299443872359E-34,100.0 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark05(-1.4742233267321003,-0.40805506453221585,-13.145389477542295 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark05(-1.474527967845044,4.141592672029592,1.570796326794893 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark05(-1.4751048699424225,-34.579888644786344,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark05(-1.4751118233232314,-1.5544258255638652,1.5707963267948966 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark05(-1.4769654998975228,-35.86559438377704,-30.28445357636569 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark05(-1.4778393243002117,-1.5707963267948966,-82.21484857859416 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark05(14.778747297685797,2.7838633728477333,85.30781823055895 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark05(-1.4781721950351583,-1.5707963267948966,4.712388995427341 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark05(-1.4785392145075964,-0.19980087363879118,52.70492613888694 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark05(-14.787041570891212,-66.27085672299043,-14.257505211232345 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark05(-1.4789705933898853,-0.0046902631368743375,0.0 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark05(-1.4792592287697242,-72.41678011485766,1.5707963267948966 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark05(14.793577642571634,-1.1408486812030961E-8,184.83543544482268 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark05(14.794395257054411,-1.5707963267948926,-56.42412711012068 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark05(-1.4795674988825267E-12,-1.5707963267948966,6.283189122653216 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark05(-1.4799545065519264,-0.5384329627601986,-0.8109997759040359 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark05(-1.480419151342715,-1.5707963267948966,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark05(-1.4823851209020704,-67.39138508811334,-1.6543612251060553E-24 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark05(-1.4827936621986488,0.22602103266571116,79.66093347045927 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark05(-1.483062093697102,-1.5707963267948966,57.524949591387674 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark05(-1.483166123515682,-0.02333385230025423,-56.30216974465721 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark05(-1.483210719268575,-1.4011521177586705,-1.5707963267948983 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark05(-1.4832348386897072,-48.214434340310895,-22.87736185616005 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark05(-1.4832931188293017,-4.40489474917905,-22.443886727193366 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark05(-1.4833238281577523,-85.04225004216715,10.995574288382251 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark05(-1.4840437360350507,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark05(-1.4843285966172464,-1.5707963267948966,10.62664687429968 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark05(-1.48461706345763,-0.08575647569559097,-5.141592653590678 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark05(-1.4849325495864303,-0.724982516946339,-1.8045591833933992 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark05(-1.485323605450121,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark05(-1.48592483608239E-16,-0.21009308142874636,-0.04156455266274078 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark05(-1.4860584067043385,-1.5707963267948966,1.5707963267949019 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark05(-1.486108573249761,-66.07100341094764,1001.5226597872532 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark05(-1.48644751894323,-91.91686303962223,-0.4559384974095644 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark05(-1.4866873153967608,-28.277165964288628,-78.13624382275586 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark05(-1.486795087742117,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark05(-1.4869202317816392,-0.3302893727249131,-1.5707963267948963 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark05(-1.4875224779664353,-9.938927658117402,88.83857218869943 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark05(-1.4878233254348807,-8.881784197001252E-16,8.159201191591041 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark05(-1.4879214194979886,-54.35326143841793,-9.85542196913584 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark05(-1.4886665468340283,-16.21984232940861,-16.073818931722258 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark05(-1.4899558447834285,-23.479268032392,-66.29937745083583 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark05(-1.4908063324060907,-1.5445620466331356,-21.711296461776612 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark05(-1.4911620676394965,-47.13951507646587,-1.5707963267948948 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark05(-1.4916411644864178,-3.157217654829349,88.99511935675885 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark05(-1.4918630497127534,-0.0186263460156324,-58.66718597901588 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark05(-1.4922825437415241,-3.718993619974185,78.50882494827911 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark05(-1.4922981089637866,-10.20331118736163,44.05430842060338 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark05(-1.492495412182945,-1.5707963267948966,-57.860730462508144 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark05(-1.493176434562143,-98.47568665420897,44.1290731136028 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark05(-1.4932065772826282,-0.05291220437114295,-0.7504121828195345 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark05(-1.4937215374324162,-1.5707963267948966,55.46918012636037 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark05(-1.4941011788134841,-1.4578772833754539,-79.51973221962291 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark05(-1.4943547073304344,-1.5707963267948912,4.506978724836223 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark05(-1.4945948947760834,-0.11041925580429823,-28.957065089194117 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark05(-1.4946006537573722,-1.53279597306967,-61.26105674500097 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark05(-1.4946878951125826,-1.0130894199488802,-86.8048948459128 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark05(-1.4949804345689444,-117.26399740018135,-54.82502055125051 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark05(-1.4950775838486212,-1.5707963267948957,77.98727987698634 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark05(-1.4953193432929515,-1.2656223359299468,89.53539062730911 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark05(-1.4959097042997174,-129.43527741108164,-77.26647864263725 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark05(-1.4965799685476608,2.1175823681357508E-22,2.0155523039808838E-15 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark05(-1.4967626764776845,-97.66812053142557,-15.237475693497768 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark05(-1.4971149292496901,-1.1805007701427879,6.847096850157428 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark05(-1.497584894835454,-1.5707963267948966,-98.60625285945997 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark05(-1.4978004851112021,-1.570796325265661,10.391650334121792 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark05(-1.4978899009921947,-3.845893424808068,6.456177540929389 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark05(-1.4985322328065351,-0.04639865525326787,92.74842703357194 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark05(-1.498934160812631,-1.5707963267948966,40.8025323968815 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark05(-1.4990122818190708,-78.59052771444755,81.13673680555013 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark05(-1.4990437974179833,-1.5707963267948966,-43.220429781365695 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark05(-1.499429560086554,-54.59174661162742,-365.9788797504501 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark05(-1.5005810380576545,-48.646048291575156,55.225263403269715 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark05(-1.5022578557414314,-1.5707963267948966,-14.785759689116864 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark05(-1.5025314700803525,-1.5707963267948957,-1.5707963267948968 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark05(-1.5026375107741006,-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark05(-1.5028286093191927,-1.3261117609740292,45.21103019775318 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark05(-1.5030782989367495,-10.227633135802932,-78.18020026558263 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark05(-1.5038839585068606,-1.5072988421250204,-4.712388988994581 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark05(-1.503999486988264,-1.5707963267948966,51.44719454472943 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark05(-1.504460979857172,-1.5707963267948961,-20.420352248333657 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark05(-1.504688860519385,-42.252540217940734,0.0 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark05(-1.505379347503484,-0.20106841404602716,39.16041255177955 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark05(-1.5055880421184846,-98.55752768814583,6.938893903907228E-18 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark05(-1.506117731089169,-1.5707963267948966,-49.692927407141575 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark05(-1.5064142377308185,-1.0459658837655645,-49.049342283096834 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark05(-1.5068104696804117,-1.5707963267948966,-80.80194332776725 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark05(-1.5068975615210793,-97.86558575881017,56.87952449140491 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark05(-1.5081566895878844,-0.7974349939168368,-2.3408381773460992E-97 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark05(-1.508912827106691,-0.10246819284544872,8.853966549240395 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark05(-1.50952323940476,-73.24509706212447,69.1169918280305 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark05(-1.5097513629470134,-72.63752663740684,-3.1420809348397936 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark05(-1.50978493595656,-3.1435457785897936,87.44078551574057 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark05(-1.5098305627735442,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark05(-1.5108316447211256,-0.34726167574334355,-78.98471626183542 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark05(-1.5124218123264133,-1.5707963267948963,1.5707963267948966 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark05(-1.5125254400324735,-103.67724296197633,76.99498040760942 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark05(-1.512541253577188,14.517887113021622,-6.2873690457523566 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark05(-1.5126328744931081,-1.5707963267948948,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark05(15.130357244345134,-12.547529104760358,-42.823883330355095 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark05(-1.5134751635600523,-72.43209139738279,0.0 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark05(-1.513660039962083,-3.147463050861291,1.5708103027434561 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark05(-1.5146720030722294,-0.4872465508775932,0.0 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark05(-1.5167110982904433,-54.72980353523372,-2.114718572799685 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark05(-1.516908181343926,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark05(-1.5174289752618497,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark05(-1.5176587096414977,-425.4723724127987,-89.3626254982374 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark05(-1.5188132396935108,-1.5707963267948963,-90.03747016343122 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark05(-1.5196099673672423,-0.22229739989110187,8.103988806908188 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark05(-1.5196178092959594,-35.051681774119174,27.868757261228968 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark05(-1.5202103738735958E-5,-1.5693357770626641,113.08823794630635 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark05(-1.5208732530361279E-210,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark05(-1.5210483602184248,-78.8766660245374,-100.0 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark05(-1.5211436188816485,-1.5707963267948966,-28.161678386630214 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark05(-1.521518730382394,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark05(-1.5216006663914854,-185.65521750174457,-116.44953951372331 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark05(-1.5217309259306053,-1.5707963267948966,10.597931554720446 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark05(-1.5219024367661538,-1.5707963267948966,89.16957066680823 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark05(-1.5219999920220113,-0.898774985854664,3.4546640087112195 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark05(-15.220553210963047,-91.82873042326383,-28.862432031440008 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark05(-1.5227927364549951,-0.13965626315878377,89.75977604339712 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark05(-1.5232102401529843,-1.5707963267949152,67.25444124468771 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark05(-1.5236618336891194,-1.5707963267948912,1.5707963267948966 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark05(-1.523706143923417E-12,-1.5176084766921798,10.198328459220262 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark05(-1.5244849296446024,-1.5707963267948948,33.77568257549609 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark05(-1.5247537747773312,-1.5707963267948966,139.88656819454806 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark05(-1.5252222139363756,-72.4396036554312,-100.0 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark05(-1.5253005008712643,-1.5707963267948966,1.5707963269059657 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark05(-1.5254005266669157,-104.40492107356381,-50.580303505514635 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark05(-1.525883851648094,-1.4244029357439703,59.69124041343305 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark05(-1.5260246003122608,4.1415983770625715,1.5707963267948963 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark05(-1.526093619978088,-0.6412035560944425,2.554204090081285 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark05(-1.526174833485204,-72.92052248813224,1.5707963267948966 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark05(-1.526802933254363,-1.5707963267948963,78.42172719819234 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark05(-1.527168111263078,-1.5707963267948966,28.099050999202603 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark05(-1.5277743778496693,-0.7202856752334748,-1.5707963267948966 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark05(-1.5278318973546638,-0.4756143968166262,-88.17962141010429 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark05(-1.5278730459179097,-98.68141142446278,28.875642800248585 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark05(-1.527915015505694,-3.2665926535898038,84.33656332595406 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark05(-1.5279705355622517,-73.5942555591022,-1.5707963267948966 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark05(-1.528587376925696,-0.43661788240858357,38.885906165405444 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark05(-1.5286039729738983,-1.5707963267948966,-18.47174347874143 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark05(-1.5289500797709024,-0.8320003930534228,-465.91104068073156 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark05(-1.5289523238366245,-9.4278232618747,56.200221637876595 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark05(-1.5290079116777957,-3.1435482871879503,1.5707963267948966 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark05(-1.5290129960679903,-0.5775375026855869,58.717580056016956 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark05(-1.5303017751797299,-1.5707963267948966,6.298810383338108 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark05(-1.5307262462940108,-21.997487545328912,-57.202045853193326 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark05(-1.5310729350076464,-0.6194328793351359,-9.603414260268693 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark05(-1.5315698948804557,-167.69884315976978,0.011575404571189551 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark05(-15.31650809646979,33.37878372309234,-34.54952139849135 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark05(-1.5317995124303425,-78.86282043603742,1.5707963267948966 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark05(-1.5323221363671289,-73.59308465982916,-1.0151767349262597E-115 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark05(-1.5323572532724903,-1.5707963267948966,2.778448436856347E-163 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark05(-1.5324436728849495,-79.71946233296381,-625.8932430525165 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark05(-1.5326611264138286,-9.456215775203983,-56.15619422027822 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark05(-1.5327053771696655,-1.5707963267948966,64.33956944138403 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark05(-1.5331732346975366,-330.21137335227155,-1.3535080479370223 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark05(-1.533329943403083,-66.22548099937106,-7.854026327007234 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark05(-1.5339607377480795,-1.5707963267948966,-61.76280589214953 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark05(-1.5340957043241676,-92.43688081451512,-99.49103114863738 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark05(-1.5342586737343424,-1.5707963267948966,118.07754585885839 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark05(-1.534932303838608,-1.5707963267948741,-19.439891435090892 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark05(-1.5353837502557444,-1.5707963267948966,-3.1416002853499316 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark05(-1.5361117243588518,-1.5707963267948966,-79.84372982840435 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark05(-1.5362565433414652,-1.570796326793112,83.36124373745001 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark05(-1.536563066314717,-1.3428077616768581,-32.19333271543891 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark05(-1.5368446209767865,-0.07336853479223558,0.0 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark05(-1.5374546474754915,-1.5707963267948966,-1.5707963267948952 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark05(-1.53761187657149,-9.559124192208323,49.71317347476734 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark05(-1.5376290292859562,-34.98309750402149,1.5707963267948968 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark05(-1.5377411423645586,-1.5707963267948966,-10.995574287564276 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark05(-1.538216749560842,-1.5707963267948912,-64.44745868524095 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark05(-1.5387165374979017,-72.69337211775171,-47.9067500392794 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark05(-1.5389718258519964,-1.5707963267948966,28.63674995049172 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark05(-1.5390690069219322,28.70353755551373,50.34119906740416 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark05(-1.5391227684022861,-1.2751837271071145,-44.876594806984755 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark05(-1.539495750755667,-3.3536911122783692,-21.796780425138934 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark05(-1.5395120262312059,-1.281261298422121,-1.5707963267948966 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark05(-1.5397447465052252,0.8195227843944316,1.5707963267948966 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark05(-1.539974604877564,-10.117572802278525,8.075072296574206 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark05(-1.5400560374956895,6.4329836018958995,8.582022901971653 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark05(-1.540352349746676,-1.5707963267948966,38.09730951670039 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark05(-1.540440268518769,-10.851364225856948,-129.88714285590203 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark05(1.5407439555097887E-33,-1.5707963267948963,81.85577705977079 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark05(-1.54078977004619,-1.36485304661142,62.3172787525297 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark05(-1.5409472322228097,-53.65704897939141,-0.4351320263766938 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark05(-1.541395731223698,-0.21632300468952728,16.7507139221899 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark05(-1.5415180239506543,-72.93067469177078,34.54247633553942 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark05(-1.5416850354423437,-41.529419294841745,-61.61547155679024 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark05(-1.5419268752076365,-1.5048939216424906,0.0 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark05(-1.5423836403529467,-65.9734495400865,76.76596413760365 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark05(-1.5427537411052596,-1.5707963267948966,-53.65838620720905 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark05(-1.542927334561068,-66.23914976925877,-99.81567551691519 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark05(-1.543908283624269,-0.6268872519351412,0.3121610277672229 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark05(-1.544633344296723,-1.5707963267948966,51.17393885839377 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark05(-1.5447761052067748,-53.72193357761017,-1.5707963267948966 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark05(-1.5464873244229873,-0.2942577380283621,1.5707963267948983 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark05(-1.5466767082884032,-66.30210189481069,168.2555060102623 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark05(-1.5474445226926443,-60.82052437766748,-78.54014542958731 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark05(-1.547475014260019,-0.23904132782019508,0.6414921127482287 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark05(-1.5475379204399908,-141.74381638482856,-1.050526621920731 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark05(-1.548164296017548,-1.5707963214016603,42.95965109788706 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark05(-1.5487159215271902,-61.20008620865569,7.264261895724198 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark05(-1.5487727970882024,-0.19576732898142402,6.284162058175518 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark05(-1.548867918692408,-15.761013795347537,-1.5707963267948966 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark05(-1.5490201122723053,-47.37716005068055,-4.1169003771757815 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark05(-1.5492247199002112,-1.5707963267948966,6.476910289698464 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark05(-1.5496167864756374,-1.5707963267948966,38.41802079963301 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark05(-1.5500728778476929,-1.5707963267948966,-25.884184390331427 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark05(-1.5502900928389176,-60.71020624253763,-3.141600450793925 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark05(-1.5504331591659366,-53.45640777395975,30.56641743354115 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark05(-1.550554507980527,-28.357331886390497,-37.00603379091736 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark05(-1.5505910705006183,-1.5707963267948837,-33.94537154356276 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark05(-1.550972570156995,-0.22780352286062877,65.96696105724001 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark05(-1.5510634262469025,-1.5707963267948966,89.7491387967497 ) ;
  }

  @Test
  public void test3659() {
    coral.tests.JPFBenchmark.benchmark05(-1.5519245485093118,-3.1580009000161393,38.78900999439177 ) ;
  }

  @Test
  public void test3660() {
    coral.tests.JPFBenchmark.benchmark05(-1.5527033066807063,-10.59874081234925,-1.570796326763161 ) ;
  }

  @Test
  public void test3661() {
    coral.tests.JPFBenchmark.benchmark05(-1.5528299303121944,1.9721522630525295E-31,42.6091996720529 ) ;
  }

  @Test
  public void test3662() {
    coral.tests.JPFBenchmark.benchmark05(-1.553206985422351,-0.37332008573596787,1.5707963267948966 ) ;
  }

  @Test
  public void test3663() {
    coral.tests.JPFBenchmark.benchmark05(-1.5533631218987762,-92.3908936654286,-1.5707963267948966 ) ;
  }

  @Test
  public void test3664() {
    coral.tests.JPFBenchmark.benchmark05(-1.5536258706740282,-1.570796326794893,-50.08040846702795 ) ;
  }

  @Test
  public void test3665() {
    coral.tests.JPFBenchmark.benchmark05(-1.5536417756813388,-1.5677616912262247,-75.27885813618333 ) ;
  }

  @Test
  public void test3666() {
    coral.tests.JPFBenchmark.benchmark05(-1.5536835814423968,-0.2501778160741824,-32.51394775618506 ) ;
  }

  @Test
  public void test3667() {
    coral.tests.JPFBenchmark.benchmark05(-1.5542422652686225,-42.05844599680277,-1.5707963267948968 ) ;
  }

  @Test
  public void test3668() {
    coral.tests.JPFBenchmark.benchmark05(-1.5543844914853668,-1.5707963267948966,-28.02108398432648 ) ;
  }

  @Test
  public void test3669() {
    coral.tests.JPFBenchmark.benchmark05(-1.5545524804913482,-1.500744253781306,1.570796419596359 ) ;
  }

  @Test
  public void test3670() {
    coral.tests.JPFBenchmark.benchmark05(-1.5546266784748723,-1.5707963267948966,-48.11677791531237 ) ;
  }

  @Test
  public void test3671() {
    coral.tests.JPFBenchmark.benchmark05(-1.5546984333401008,-53.407075587997646,-73.33101684169247 ) ;
  }

  @Test
  public void test3672() {
    coral.tests.JPFBenchmark.benchmark05(-1.5552043882906132,-73.20722437339649,84.81420789873184 ) ;
  }

  @Test
  public void test3673() {
    coral.tests.JPFBenchmark.benchmark05(-1.5555805999930103,-47.58031989440934,1.5707963267948966 ) ;
  }

  @Test
  public void test3674() {
    coral.tests.JPFBenchmark.benchmark05(-1.5556460675139947,-1.5707963267948966,-39.252494023743836 ) ;
  }

  @Test
  public void test3675() {
    coral.tests.JPFBenchmark.benchmark05(-1.555832893655027,-1.5707963267948963,-16.453183978232857 ) ;
  }

  @Test
  public void test3676() {
    coral.tests.JPFBenchmark.benchmark05(-1.5561432662715557,-84.94238021197803,26.14903135637233 ) ;
  }

  @Test
  public void test3677() {
    coral.tests.JPFBenchmark.benchmark05(-1.556399683666402,-67.09132328773114,-0.31902853744574783 ) ;
  }

  @Test
  public void test3678() {
    coral.tests.JPFBenchmark.benchmark05(-1.5565059424176722,-66.47286375072028,-22.2421855811815 ) ;
  }

  @Test
  public void test3679() {
    coral.tests.JPFBenchmark.benchmark05(-1.5568497993282628,-73.68817047104069,-47.921154528213734 ) ;
  }

  @Test
  public void test3680() {
    coral.tests.JPFBenchmark.benchmark05(-1.5570414785762792,-130.10876615575705,-55.33867135058027 ) ;
  }

  @Test
  public void test3681() {
    coral.tests.JPFBenchmark.benchmark05(-1.557275748877246,-0.3774884990471883,-1.2592981683461453 ) ;
  }

  @Test
  public void test3682() {
    coral.tests.JPFBenchmark.benchmark05(-1.5573327183300811,-34.85541411189763,1.5707963255338036 ) ;
  }

  @Test
  public void test3683() {
    coral.tests.JPFBenchmark.benchmark05(-1.557456804294499,-66.32890792424945,0.0 ) ;
  }

  @Test
  public void test3684() {
    coral.tests.JPFBenchmark.benchmark05(-1.5576348335621324,-0.3760284714649146,2.977342436551112 ) ;
  }

  @Test
  public void test3685() {
    coral.tests.JPFBenchmark.benchmark05(-1.557728020436766,-0.3266971169001195,-3.141595078805285 ) ;
  }

  @Test
  public void test3686() {
    coral.tests.JPFBenchmark.benchmark05(-1.5577334676231263,0.13929987511764164,-66.20648589144962 ) ;
  }

  @Test
  public void test3687() {
    coral.tests.JPFBenchmark.benchmark05(-1.5578230236035802,-73.6359865135608,9.155376314298469 ) ;
  }

  @Test
  public void test3688() {
    coral.tests.JPFBenchmark.benchmark05(-1.557929447099476,-0.29686506539606583,-96.06787855890259 ) ;
  }

  @Test
  public void test3689() {
    coral.tests.JPFBenchmark.benchmark05(-1.5584730223104706,-0.7015714024720946,-4.712405731589175 ) ;
  }

  @Test
  public void test3690() {
    coral.tests.JPFBenchmark.benchmark05(-1.5585008096865074,-0.9104635614541005,64.94981629993352 ) ;
  }

  @Test
  public void test3691() {
    coral.tests.JPFBenchmark.benchmark05(-1.5586865891183441,-40.9059964232321,-1.5707963267948966 ) ;
  }

  @Test
  public void test3692() {
    coral.tests.JPFBenchmark.benchmark05(-1.5587469716180058,-59.690544413109514,26.703537555513243 ) ;
  }

  @Test
  public void test3693() {
    coral.tests.JPFBenchmark.benchmark05(-1.5587619077974997,-17.11585723955811,-1.5707963267948966 ) ;
  }

  @Test
  public void test3694() {
    coral.tests.JPFBenchmark.benchmark05(-1.5588992331227791,-35.02660180366624,-22.456016238480316 ) ;
  }

  @Test
  public void test3695() {
    coral.tests.JPFBenchmark.benchmark05(-1.55933498128336,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3696() {
    coral.tests.JPFBenchmark.benchmark05(-1.5597606426863342,-6.114682434411986E-5,1.5707963267948966 ) ;
  }

  @Test
  public void test3697() {
    coral.tests.JPFBenchmark.benchmark05(-1.5599370405332225,-1.5707963267948983,-147.66436437251798 ) ;
  }

  @Test
  public void test3698() {
    coral.tests.JPFBenchmark.benchmark05(-1.56008441408526,-98.4583715835295,100.0 ) ;
  }

  @Test
  public void test3699() {
    coral.tests.JPFBenchmark.benchmark05(-1.560350148377887,-1.5707963267948966,20.42035225100917 ) ;
  }

  @Test
  public void test3700() {
    coral.tests.JPFBenchmark.benchmark05(-1.5603893962216837,-1.5707963267948966,-35.680204039908546 ) ;
  }

  @Test
  public void test3701() {
    coral.tests.JPFBenchmark.benchmark05(-1.5608345097932157,-98.31039495840706,44.08851878283542 ) ;
  }

  @Test
  public void test3702() {
    coral.tests.JPFBenchmark.benchmark05(-1.5611499790167476,-0.36909605216529867,-72.93612954298493 ) ;
  }

  @Test
  public void test3703() {
    coral.tests.JPFBenchmark.benchmark05(-1.5613766054153078,-1.5707963267948966,84.61941159097104 ) ;
  }

  @Test
  public void test3704() {
    coral.tests.JPFBenchmark.benchmark05(-1.5615440251897652,-41.84657182304934,-40.63856423553287 ) ;
  }

  @Test
  public void test3705() {
    coral.tests.JPFBenchmark.benchmark05(-1.5623831979931988,-0.6035816111937422,-42.32835285238 ) ;
  }

  @Test
  public void test3706() {
    coral.tests.JPFBenchmark.benchmark05(-1.5626749227607848,-48.106428148007616,-55.22644101568705 ) ;
  }

  @Test
  public void test3707() {
    coral.tests.JPFBenchmark.benchmark05(-1.5627329636369387,-1.5707963267948966,-22.42339780356909 ) ;
  }

  @Test
  public void test3708() {
    coral.tests.JPFBenchmark.benchmark05(-1.562875371797079,-1.5707963267948966,60.728905193962724 ) ;
  }

  @Test
  public void test3709() {
    coral.tests.JPFBenchmark.benchmark05(-1.5628986954716588,-1.5707963267948966,23.195619953039632 ) ;
  }

  @Test
  public void test3710() {
    coral.tests.JPFBenchmark.benchmark05(-1.563258960410285,-0.04903615374387565,274.7637555361165 ) ;
  }

  @Test
  public void test3711() {
    coral.tests.JPFBenchmark.benchmark05(-1.563304945513084,-1.5707963267948966,83.03592119755892 ) ;
  }

  @Test
  public void test3712() {
    coral.tests.JPFBenchmark.benchmark05(-1.5633914038317116,-16.542799965124487,-119.19858952054221 ) ;
  }

  @Test
  public void test3713() {
    coral.tests.JPFBenchmark.benchmark05(-1.5634629317640332,-1.5707963267948966,-44.10334238674437 ) ;
  }

  @Test
  public void test3714() {
    coral.tests.JPFBenchmark.benchmark05(-1.5635244881747516,-66.74785100315577,-85.84427989612313 ) ;
  }

  @Test
  public void test3715() {
    coral.tests.JPFBenchmark.benchmark05(-1.5636516015278277,-42.23781540329211,15.44861360790871 ) ;
  }

  @Test
  public void test3716() {
    coral.tests.JPFBenchmark.benchmark05(-1.5641085013266773,-3.2957003302831946,-81.42364457654814 ) ;
  }

  @Test
  public void test3717() {
    coral.tests.JPFBenchmark.benchmark05(-1.5641274181117976E-148,-61.134957462333425,-0.04798726656872116 ) ;
  }

  @Test
  public void test3718() {
    coral.tests.JPFBenchmark.benchmark05(-1.5641410034737468,-1.5707963267948966,-1.9947566364533842 ) ;
  }

  @Test
  public void test3719() {
    coral.tests.JPFBenchmark.benchmark05(-1.5641808834291537,-136.39120140195183,-34.808083846662896 ) ;
  }

  @Test
  public void test3720() {
    coral.tests.JPFBenchmark.benchmark05(-1.5641959948819504,-1.5707963267948968,0.12170494966688146 ) ;
  }

  @Test
  public void test3721() {
    coral.tests.JPFBenchmark.benchmark05(-1.5643033927980086,-15.826198642172173,114.01003930385355 ) ;
  }

  @Test
  public void test3722() {
    coral.tests.JPFBenchmark.benchmark05(-1.5643274180773414,-3.159664174104166,0.0 ) ;
  }

  @Test
  public void test3723() {
    coral.tests.JPFBenchmark.benchmark05(-1.564327487037927,-66.38232512266653,-98.09935109802475 ) ;
  }

  @Test
  public void test3724() {
    coral.tests.JPFBenchmark.benchmark05(-1.5644460554653332,-15.771970485789435,21.27238673740112 ) ;
  }

  @Test
  public void test3725() {
    coral.tests.JPFBenchmark.benchmark05(-1.5646040901898246,-0.068289340221745,-41.71486668142093 ) ;
  }

  @Test
  public void test3726() {
    coral.tests.JPFBenchmark.benchmark05(-1.5647670998455074,-0.36642338899516197,8.103982239320851 ) ;
  }

  @Test
  public void test3727() {
    coral.tests.JPFBenchmark.benchmark05(-1.5648029600511604,3.1547858603220913,-83.8859576155412 ) ;
  }

  @Test
  public void test3728() {
    coral.tests.JPFBenchmark.benchmark05(-1.5649462688113114,-1.3550130586936484,65.04289519091773 ) ;
  }

  @Test
  public void test3729() {
    coral.tests.JPFBenchmark.benchmark05(-1.5649772244856661,-0.6673347171028269,7.853986779478087 ) ;
  }

  @Test
  public void test3730() {
    coral.tests.JPFBenchmark.benchmark05(-1.5651332702512235,-1.1886421048195348,22.73218650640537 ) ;
  }

  @Test
  public void test3731() {
    coral.tests.JPFBenchmark.benchmark05(-1.5653714435036477,-1.5707963267948961,15.172393135232753 ) ;
  }

  @Test
  public void test3732() {
    coral.tests.JPFBenchmark.benchmark05(-1.5657161776957602,-41.979806137379974,155.27546221205 ) ;
  }

  @Test
  public void test3733() {
    coral.tests.JPFBenchmark.benchmark05(-1.5658319269831573,-41.72862228168808,-12.597620614740487 ) ;
  }

  @Test
  public void test3734() {
    coral.tests.JPFBenchmark.benchmark05(-1.5659297702724955,-1.5707963267948912,-7.853981633976629 ) ;
  }

  @Test
  public void test3735() {
    coral.tests.JPFBenchmark.benchmark05(-1.5664846511562511,-0.40530642549673346,-42.53650082346426 ) ;
  }

  @Test
  public void test3736() {
    coral.tests.JPFBenchmark.benchmark05(-1.566894913572302,-1.5707963267948966,-52.99323182431165 ) ;
  }

  @Test
  public void test3737() {
    coral.tests.JPFBenchmark.benchmark05(-1.5672044954744475,-1.5707963267948966,-19.526638593843167 ) ;
  }

  @Test
  public void test3738() {
    coral.tests.JPFBenchmark.benchmark05(-1.567528807679551,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test3739() {
    coral.tests.JPFBenchmark.benchmark05(-1.5676729905862927,-9.534429467327541,4.712388980529208 ) ;
  }

  @Test
  public void test3740() {
    coral.tests.JPFBenchmark.benchmark05(-1.567719373259,-1.5707963267948966,-62.32913898191368 ) ;
  }

  @Test
  public void test3741() {
    coral.tests.JPFBenchmark.benchmark05(-1.5677458717391592,-0.37460354062351275,-80.06559581297971 ) ;
  }

  @Test
  public void test3742() {
    coral.tests.JPFBenchmark.benchmark05(-1.5678493625317882,-0.3011286338869238,1.5721679746099522 ) ;
  }

  @Test
  public void test3743() {
    coral.tests.JPFBenchmark.benchmark05(-1.5678695664903426,-29.36337733891066,-3.1494054146192023 ) ;
  }

  @Test
  public void test3744() {
    coral.tests.JPFBenchmark.benchmark05(-1.5678874069309208,-15.994326037379144,23.878742259056793 ) ;
  }

  @Test
  public void test3745() {
    coral.tests.JPFBenchmark.benchmark05(-1.5679900324036697,-73.51911487227505,-1.5707963267948966 ) ;
  }

  @Test
  public void test3746() {
    coral.tests.JPFBenchmark.benchmark05(-1.5684240853677418,-34.926062675892624,-3.1494051559915177 ) ;
  }

  @Test
  public void test3747() {
    coral.tests.JPFBenchmark.benchmark05(-1.5684530145514912,-0.18396458384293013,1.5707963267948966 ) ;
  }

  @Test
  public void test3748() {
    coral.tests.JPFBenchmark.benchmark05(-1.5685351971854848,-73.52168893666787,-3.1416002830195975 ) ;
  }

  @Test
  public void test3749() {
    coral.tests.JPFBenchmark.benchmark05(-1.5688162198079496,-67.31522993186937,-3.142080934842176 ) ;
  }

  @Test
  public void test3750() {
    coral.tests.JPFBenchmark.benchmark05(-1.5688827392668727,-1.5707963267948954,56.2776522100904 ) ;
  }

  @Test
  public void test3751() {
    coral.tests.JPFBenchmark.benchmark05(-1.5688955662931119,-48.471691384290374,1.5707963267948966 ) ;
  }

  @Test
  public void test3752() {
    coral.tests.JPFBenchmark.benchmark05(-1.5690230124963824,-0.6275561567560844,-65.39237694412304 ) ;
  }

  @Test
  public void test3753() {
    coral.tests.JPFBenchmark.benchmark05(-1.5694989287078094,-2.0854083458812832E-7,-149.26562908606263 ) ;
  }

  @Test
  public void test3754() {
    coral.tests.JPFBenchmark.benchmark05(-1.5695132720492633,-0.012126773856173733,-48.948030647713644 ) ;
  }

  @Test
  public void test3755() {
    coral.tests.JPFBenchmark.benchmark05(-1.569547317055628,-54.81906432126206,-147.6296868221745 ) ;
  }

  @Test
  public void test3756() {
    coral.tests.JPFBenchmark.benchmark05(-1.5695596787250226,-9.606153264151173E-4,163.53620919292797 ) ;
  }

  @Test
  public void test3757() {
    coral.tests.JPFBenchmark.benchmark05(-1.5696899606730488,-5.421010862427522E-20,84.63265441037912 ) ;
  }

  @Test
  public void test3758() {
    coral.tests.JPFBenchmark.benchmark05(-1.569710058672787,-60.04058172925502,-9.424900278071165 ) ;
  }

  @Test
  public void test3759() {
    coral.tests.JPFBenchmark.benchmark05(-1.5700374504632022,-1.5648667696882974,-63.74223723046055 ) ;
  }

  @Test
  public void test3760() {
    coral.tests.JPFBenchmark.benchmark05(-1.5700523510248663,-0.06256368492030845,8.104912601415467 ) ;
  }

  @Test
  public void test3761() {
    coral.tests.JPFBenchmark.benchmark05(-1.5701949666484158,-9.571925830941328,0.0 ) ;
  }

  @Test
  public void test3762() {
    coral.tests.JPFBenchmark.benchmark05(-1.570330990871318,-1.5707963267948966,98.21771711099358 ) ;
  }

  @Test
  public void test3763() {
    coral.tests.JPFBenchmark.benchmark05(-1.5704132564091196,-1.5707963267948966,95.25541341690014 ) ;
  }

  @Test
  public void test3764() {
    coral.tests.JPFBenchmark.benchmark05(-1.570439002530681,-1.5660217333504853,6.283925305972937 ) ;
  }

  @Test
  public void test3765() {
    coral.tests.JPFBenchmark.benchmark05(-1.570448244885825,3.14239747545878,48.591713572837236 ) ;
  }

  @Test
  public void test3766() {
    coral.tests.JPFBenchmark.benchmark05(-1.5705174438958542,-1.5707963267948966,4.141946845845171 ) ;
  }

  @Test
  public void test3767() {
    coral.tests.JPFBenchmark.benchmark05(-1.5706036248500044,-42.10737011923642,-54.34407585684262 ) ;
  }

  @Test
  public void test3768() {
    coral.tests.JPFBenchmark.benchmark05(-1.5706064507588464,-0.2404584729376494,-1.5707963267948957 ) ;
  }

  @Test
  public void test3769() {
    coral.tests.JPFBenchmark.benchmark05(-1.5706249081921355,-3.1415926790487103,-100.0 ) ;
  }

  @Test
  public void test3770() {
    coral.tests.JPFBenchmark.benchmark05(-1.5706957529698762,-0.8186660157404642,55.169625654865875 ) ;
  }

  @Test
  public void test3771() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707025074403536,-66.35326474991582,1.5707963267948968 ) ;
  }

  @Test
  public void test3772() {
    coral.tests.JPFBenchmark.benchmark05(-1.570719715695797,-73.35777339302543,-135.65677771726752 ) ;
  }

  @Test
  public void test3773() {
    coral.tests.JPFBenchmark.benchmark05(-1.570759646919459,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3774() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707730176914778,-1.0708840293553772,-16.60313918775449 ) ;
  }

  @Test
  public void test3775() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707751506278547,-1.5707963267948966,54.981364419789074 ) ;
  }

  @Test
  public void test3776() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707859705596279,-73.4240513801072,3.141593273230455 ) ;
  }

  @Test
  public void test3777() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707934151136913,-2.5740665315978024E-5,-12.617632007557276 ) ;
  }

  @Test
  public void test3778() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707949049514758,-7.269119981751472E-5,-6.2844963701716585 ) ;
  }

  @Test
  public void test3779() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707951759734253,-0.003606855610281155,0.0 ) ;
  }

  @Test
  public void test3780() {
    coral.tests.JPFBenchmark.benchmark05(-1.570795743952871,-1.5707963267948966,4.166383068276701 ) ;
  }

  @Test
  public void test3781() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707957918206394,-1.6543612251060553E-24,44.55275554387454 ) ;
  }

  @Test
  public void test3782() {
    coral.tests.JPFBenchmark.benchmark05(-1.570795941432995,-1.3860859776621381,-55.53579364171305 ) ;
  }

  @Test
  public void test3783() {
    coral.tests.JPFBenchmark.benchmark05(-1.570795947159951,-1.5707963267948966,174.00277499144175 ) ;
  }

  @Test
  public void test3784() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707960876569633,-1.5617383107696858,-67.57250959769047 ) ;
  }

  @Test
  public void test3785() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707960967157346,-47.439599320815546,0.3488198002206483 ) ;
  }

  @Test
  public void test3786() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707961330051174,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3787() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707962227511574,-0.9842940293430237,-1.0632227614678769 ) ;
  }

  @Test
  public void test3788() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707962367772585,-1.1102230246251565E-16,0.0 ) ;
  }

  @Test
  public void test3789() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707962846519419,-1.570796504478234,112.63541913458249 ) ;
  }

  @Test
  public void test3790() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796300454484,-0.005176962001864915,45.30877737079636 ) ;
  }

  @Test
  public void test3791() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963097877027,-155.3397615804168,-140.6090521924486 ) ;
  }

  @Test
  public void test3792() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963103730873,-117.26787961129922,42.90850767874539 ) ;
  }

  @Test
  public void test3793() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963128065534,-160.58600877176076,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test3794() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796315006516,-15.86302314711908,0.15791663194801 ) ;
  }

  @Test
  public void test3795() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963161366452,-1.5707963267948966,98.14343325710246 ) ;
  }

  @Test
  public void test3796() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796318820595,-54.515413775138214,-92.583004757056 ) ;
  }

  @Test
  public void test3797() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796321050675,-1.570796326794894,-56.71824388864353 ) ;
  }

  @Test
  public void test3798() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963210539613,-1.5707963267948966,26.860088037379086 ) ;
  }

  @Test
  public void test3799() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963227180406,-0.9652263546516833,-98.16629649343427 ) ;
  }

  @Test
  public void test3800() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963231868192,-103.78756804170614,-94.86359407320133 ) ;
  }

  @Test
  public void test3801() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796323209647,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3802() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963232828732,-1.5707963267948966,145.77762904370041 ) ;
  }

  @Test
  public void test3803() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963237715528,-53.454640435574944,-8.32581278088609 ) ;
  }

  @Test
  public void test3804() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963250585997,-0.022915867461225203,-0.593678818064499 ) ;
  }

  @Test
  public void test3805() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963250700188,-1.5707963267948963,-1.570796326794899 ) ;
  }

  @Test
  public void test3806() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963251745956,-10.035384951210435,89.18216957037767 ) ;
  }

  @Test
  public void test3807() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963252933066,-41.998706821818914,57.62929093332315 ) ;
  }

  @Test
  public void test3808() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963252951704,-1.5707963267948966,-88.1394038746643 ) ;
  }

  @Test
  public void test3809() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963256086306,-28.36447445739191,-0.7229519346343491 ) ;
  }

  @Test
  public void test3810() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963256117978,-54.75729119448076,-20.963108066811273 ) ;
  }

  @Test
  public void test3811() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963256219928,-1.2985836612833301,1.5707963267948957 ) ;
  }

  @Test
  public void test3812() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963257036384,-7.105427357601002E-15,181.20380523948467 ) ;
  }

  @Test
  public void test3813() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963260368787,-1.5707963267948983,-83.34192594485924 ) ;
  }

  @Test
  public void test3814() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963260439328,-1.5707963267948966,-66.00027552601556 ) ;
  }

  @Test
  public void test3815() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963260494748,-34.81774801825479,-1.1785069772924965 ) ;
  }

  @Test
  public void test3816() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963260761921,-1.3205307489348037,36.65677009700093 ) ;
  }

  @Test
  public void test3817() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963261052498,-0.8473061689560164,1.5707963267948966 ) ;
  }

  @Test
  public void test3818() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963261088234,-97.42089885030265,50.019816434395935 ) ;
  }

  @Test
  public void test3819() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326121065,-1.5707963267948966,95.97994052514903 ) ;
  }

  @Test
  public void test3820() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963261881244,-41.56046476929871,27.73510041671447 ) ;
  }

  @Test
  public void test3821() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326216664,-0.17713770385446584,-95.62484263768525 ) ;
  }

  @Test
  public void test3822() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963262347229,-98.01583978852068,-74.87334012095494 ) ;
  }

  @Test
  public void test3823() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963262411768,-1.5707963267948983,39.120173949215804 ) ;
  }

  @Test
  public void test3824() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963262726217,-1.5707963267948966,112.14664325796224 ) ;
  }

  @Test
  public void test3825() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963263420983,-41.21964096783037,-79.69199857131682 ) ;
  }

  @Test
  public void test3826() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326344911,-1.5707963267948966,21.778782708983464 ) ;
  }

  @Test
  public void test3827() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963264320166,-35.33121446159588,174.05741990469562 ) ;
  }

  @Test
  public void test3828() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963264539881,-73.28385377666932,-42.83320939142402 ) ;
  }

  @Test
  public void test3829() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265038505,-1.5707963267948966,-46.36498860579424 ) ;
  }

  @Test
  public void test3830() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265091796,-1.5707963267948966,-1.5707963267949054 ) ;
  }

  @Test
  public void test3831() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265121272,-53.55797465705085,-129.10657481138247 ) ;
  }

  @Test
  public void test3832() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265194453,-1.5028464106536166,21.652793476961005 ) ;
  }

  @Test
  public void test3833() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265288973,-0.3872723148097057,-1.13128632828113 ) ;
  }

  @Test
  public void test3834() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265292377,-41.516376489770586,-32.18625494153713 ) ;
  }

  @Test
  public void test3835() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326529545,-0.10287314685119832,-79.05184521867841 ) ;
  }

  @Test
  public void test3836() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265308977,-1.5707963267948948,-38.11824512764888 ) ;
  }

  @Test
  public void test3837() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265337395,-1.5707963267948795,1.5707963267948983 ) ;
  }

  @Test
  public void test3838() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265365332,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test3839() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265396725,-1.5707963267948966,-5.138820923198736 ) ;
  }

  @Test
  public void test3840() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326540242,-1.2513655262910635,1.5707963267948966 ) ;
  }

  @Test
  public void test3841() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265471805,-0.8267523721389107,-28.968341621184976 ) ;
  }

  @Test
  public void test3842() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326549282,-5.470643690304313E-15,1.5175171436048942 ) ;
  }

  @Test
  public void test3843() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265498852,-53.65001848343823,-1.5707963267948983 ) ;
  }

  @Test
  public void test3844() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265520213,-1.1614698033121167,81.71190851310371 ) ;
  }

  @Test
  public void test3845() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326559446,-0.25442695957562783,-36.09559543237272 ) ;
  }

  @Test
  public void test3846() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265597105,-0.9309845744367714,1.5707963267948966 ) ;
  }

  @Test
  public void test3847() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265789051,-1.4751793614242619,-72.27512578338883 ) ;
  }

  @Test
  public void test3848() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265794442,-73.63588056386773,-1.5707963267948966 ) ;
  }

  @Test
  public void test3849() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265801979,-0.25982446440095086,0.0 ) ;
  }

  @Test
  public void test3850() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265840341,-0.8028222000257699,-100.0 ) ;
  }

  @Test
  public void test3851() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265910718,-1.5707963267948983,1.5707963267948974 ) ;
  }

  @Test
  public void test3852() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265921838,-41.47613925796527,140.66783630733562 ) ;
  }

  @Test
  public void test3853() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266026543,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3854() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266040708,-1.5707963267948375,-42.05256610695716 ) ;
  }

  @Test
  public void test3855() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326608203,-4.070423685959938,-30.975135033204843 ) ;
  }

  @Test
  public void test3856() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266089364,-1.546626450295824,-100.0 ) ;
  }

  @Test
  public void test3857() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266089435,-66.28697104496085,54.56947220807049 ) ;
  }

  @Test
  public void test3858() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266266063,-1.5707963267948963,3.8848262931981203 ) ;
  }

  @Test
  public void test3859() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326627257,-0.10028187492621614,94.11787094285367 ) ;
  }

  @Test
  public void test3860() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266331437,-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test3861() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266337244,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3862() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266347567,-1.5707963267948948,-10.964572052772308 ) ;
  }

  @Test
  public void test3863() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326637168,-10.038740698427475,-50.91540726777667 ) ;
  }

  @Test
  public void test3864() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266435072,-35.29672307061307,78.2392062662791 ) ;
  }

  @Test
  public void test3865() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266471006,-28.352396414454105,-41.02441933634316 ) ;
  }

  @Test
  public void test3866() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266495995,-42.39940388731601,-14.249644682841325 ) ;
  }

  @Test
  public void test3867() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266506386,-22.466248460920347,1.5707963267948948 ) ;
  }

  @Test
  public void test3868() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266515308,-8.881784197001252E-16,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test3869() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326656513,-0.49168806773624346,-50.222307929686984 ) ;
  }

  @Test
  public void test3870() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266569547,-1.5707963267948966,-145.93370168355474 ) ;
  }

  @Test
  public void test3871() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266602263,-48.643653492347724,1.5707963267948966 ) ;
  }

  @Test
  public void test3872() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266624436,-0.46375492083531855,7.588528351104588 ) ;
  }

  @Test
  public void test3873() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266844946,-0.5756063243194628,-95.38477714257125 ) ;
  }

  @Test
  public void test3874() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326684532,-1.4509202991192498,-1.5707963267949019 ) ;
  }

  @Test
  public void test3875() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326692619,-1.3188022139485733,86.22892613408823 ) ;
  }

  @Test
  public void test3876() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266952594,-84.96375401708416,-1.5707963267948966 ) ;
  }

  @Test
  public void test3877() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267023788,-98.74494653168556,174.062310091112 ) ;
  }

  @Test
  public void test3878() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267052472,-4.665773811543634,-0.22271999197929127 ) ;
  }

  @Test
  public void test3879() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267085094,-34.83683721060797,-81.74732178993436 ) ;
  }

  @Test
  public void test3880() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326719068,-1.5707963267948957,-100.0 ) ;
  }

  @Test
  public void test3881() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326719393,-141.58787797295426,-98.15376225489909 ) ;
  }

  @Test
  public void test3882() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267221898,-0.5213453042393735,-4.480702501808437 ) ;
  }

  @Test
  public void test3883() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267356095,-1.2003489703587427,27.15831326817684 ) ;
  }

  @Test
  public void test3884() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267488207,-129.1976890493465,-186.09860022728304 ) ;
  }

  @Test
  public void test3885() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267490466,-1.5707963267948957,1.3906748000670357 ) ;
  }

  @Test
  public void test3886() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267496199,-0.7356183992970446,-1.5707963267948966 ) ;
  }

  @Test
  public void test3887() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267577694,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3888() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326766692,-0.4298431652264234,1.5707963267948966 ) ;
  }

  @Test
  public void test3889() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267677145,-0.69030640255654,42.92107576180226 ) ;
  }

  @Test
  public void test3890() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267712521,-1.480967947961066,-6.07206127676352 ) ;
  }

  @Test
  public void test3891() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326773023,-1.5105174279903524,89.67973237385237 ) ;
  }

  @Test
  public void test3892() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326774975,-3.230189791277578,-29.815682663711193 ) ;
  }

  @Test
  public void test3893() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326779474,-97.83456900873948,-85.94354061339888 ) ;
  }

  @Test
  public void test3894() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267801592,-198.81277543867822,84.54495696395296 ) ;
  }

  @Test
  public void test3895() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267802398,-1.5678297877205374,-4.712885487034623 ) ;
  }

  @Test
  public void test3896() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326782822,-1.5707963267948977,1.5707963267948966 ) ;
  }

  @Test
  public void test3897() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326782834,-97.71467763294375,100.0 ) ;
  }

  @Test
  public void test3898() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267841263,-10.740472605633343,-49.932342632290286 ) ;
  }

  @Test
  public void test3899() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267862937,-47.25950570044801,100.0 ) ;
  }

  @Test
  public void test3900() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326786321,-0.9241183492456467,95.36872199048388 ) ;
  }

  @Test
  public void test3901() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267863727,-0.6141139720612687,29.11482977887241 ) ;
  }

  @Test
  public void test3902() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267879892,-1.5707963267948966,-42.20786512810597 ) ;
  }

  @Test
  public void test3903() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267894782,-98.49799235083279,84.85582330950294 ) ;
  }

  @Test
  public void test3904() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267903187,-16.11708157954051,-132.27437689760177 ) ;
  }

  @Test
  public void test3905() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267907932,-66.70323562071486,-1.5707963267948966 ) ;
  }

  @Test
  public void test3906() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267918326,-34.67352581920535,-20.835695792909767 ) ;
  }

  @Test
  public void test3907() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267923377,-1.5707963267948966,-40.98929383384519 ) ;
  }

  @Test
  public void test3908() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267924743,-204.67432929133116,84.36097007200334 ) ;
  }

  @Test
  public void test3909() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326792697,-1.5707963267948908,15.021563206658904 ) ;
  }

  @Test
  public void test3910() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326793537,-10.08287756375033,1.353241573142475 ) ;
  }

  @Test
  public void test3911() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326793598,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3912() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326793614,-0.483530220308617,-1.5707963267949125 ) ;
  }

  @Test
  public void test3913() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267936442,-9.517735405027363,114.77179343898834 ) ;
  }

  @Test
  public void test3914() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326793836,-173.99768813476553,-71.44517535470196 ) ;
  }

  @Test
  public void test3915() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267941096,-48.6179372206601,89.75641697493799 ) ;
  }

  @Test
  public void test3916() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794114,-42.34380435931621,1.5707963267948966 ) ;
  }

  @Test
  public void test3917() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267941416,-28.6554742522856,-4.058292351400681 ) ;
  }

  @Test
  public void test3918() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267941474,-1.5707963267948966,-8.101512946196642 ) ;
  }

  @Test
  public void test3919() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267941758,-1.5707963267948966,-26.83999247912223 ) ;
  }

  @Test
  public void test3920() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267942495,-1.5707963267948966,54.98754927943438 ) ;
  }

  @Test
  public void test3921() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267943443,-10.617235294340876,7.853981634010842 ) ;
  }

  @Test
  public void test3922() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267943938,-1.5707963267948966,-42.78752020648453 ) ;
  }

  @Test
  public void test3923() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794408,-1.4303923594029015,39.311661553491774 ) ;
  }

  @Test
  public void test3924() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794409,-1.0535559993902042,-25.703201299022098 ) ;
  }

  @Test
  public void test3925() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267944294,-1.5707963267948966,79.14054625235849 ) ;
  }

  @Test
  public void test3926() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267944471,-73.4002320241699,-1.5707963267948912 ) ;
  }

  @Test
  public void test3927() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794451,-1.2457186391713502,1.5676758216635476 ) ;
  }

  @Test
  public void test3928() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267944516,-10.296542121662227,1.5709400049717168 ) ;
  }

  @Test
  public void test3929() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267944638,-1.5707963267948966,63.704392035155905 ) ;
  }

  @Test
  public void test3930() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267944827,-1.5509410983124832,0.0 ) ;
  }

  @Test
  public void test3931() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267945284,-1.5609694639394378,-42.159178273688674 ) ;
  }

  @Test
  public void test3932() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267946177,-1.5707963267948966,-90.94402504438308 ) ;
  }

  @Test
  public void test3933() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267946674,-66.81676047367172,0.2800977932272595 ) ;
  }

  @Test
  public void test3934() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947054,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3935() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947065,-1.5707963267948963,-40.21453364274766 ) ;
  }

  @Test
  public void test3936() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947125,-47.45663508773997,44.013298887748896 ) ;
  }

  @Test
  public void test3937() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947305,-1.5707963267948966,-8.104056680691789 ) ;
  }

  @Test
  public void test3938() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947385,-0.23599871153997753,15.888462350646492 ) ;
  }

  @Test
  public void test3939() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947507,-0.17646008109166722,83.90944362941755 ) ;
  }

  @Test
  public void test3940() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947527,-59.78867798575409,-86.08326621756298 ) ;
  }

  @Test
  public void test3941() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947533,-1.5707963267948966,-60.03362342300214 ) ;
  }

  @Test
  public void test3942() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947578,-1.570796326794896,-18.16213671668614 ) ;
  }

  @Test
  public void test3943() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947598,-3.1435664446173184,1.2524579831257459 ) ;
  }

  @Test
  public void test3944() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794768,-0.011930207280104771,-1.5707963267948966 ) ;
  }

  @Test
  public void test3945() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947704,-1.2700929560594272,-55.703755543429565 ) ;
  }

  @Test
  public void test3946() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947704,-3.318684897678395,20.313569391594214 ) ;
  }

  @Test
  public void test3947() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794774,-73.08757867165349,6.284829049682227 ) ;
  }

  @Test
  public void test3948() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947833,-1.5707963267948966,-21.459431622180574 ) ;
  }

  @Test
  public void test3949() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947949,-1.5707963267948966,-83.56513503809835 ) ;
  }

  @Test
  public void test3950() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947989,-1.5707963267948966,-9.310359156119148 ) ;
  }

  @Test
  public void test3951() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948015,-1.5707963267948966,-76.64095040967194 ) ;
  }

  @Test
  public void test3952() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948095,-124.03409554742503,-53.92834662773126 ) ;
  }

  @Test
  public void test3953() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948144,-0.45756880765606367,-38.259429050490326 ) ;
  }

  @Test
  public void test3954() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948188,-1.5707963267948966,0.4049103102402967 ) ;
  }

  @Test
  public void test3955() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948217,-16.009408547462463,-73.24221426287265 ) ;
  }

  @Test
  public void test3956() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948237,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3957() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948237,-1.5707963267948983,-27.039463647349372 ) ;
  }

  @Test
  public void test3958() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948273,-1.5707963267948966,-26.96548288488572 ) ;
  }

  @Test
  public void test3959() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794835,-1.5707963267948966,51.84905361583636 ) ;
  }

  @Test
  public void test3960() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948406,-0.2962778598486411,90.61229358733647 ) ;
  }

  @Test
  public void test3961() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948415,-98.25736759145546,0 ) ;
  }

  @Test
  public void test3962() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948422,-5.0539682649402436E-175,1.5707963267948966 ) ;
  }

  @Test
  public void test3963() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948435,-0.4877777360234061,-1.5707963267948966 ) ;
  }

  @Test
  public void test3964() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948453,-98.31815402295562,-4.258834746605209E-19 ) ;
  }

  @Test
  public void test3965() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948484,-1.9721522630525295E-31,2367.165322962045 ) ;
  }

  @Test
  public void test3966() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948486,-0.07769083059903514,-99.56917219930914 ) ;
  }

  @Test
  public void test3967() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948488,-0.128321966217314,-1.5707963267948966 ) ;
  }

  @Test
  public void test3968() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948488,-1.5707963267948966,23.22060655701917 ) ;
  }

  @Test
  public void test3969() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948557,-34.83435732652552,47.29009696801407 ) ;
  }

  @Test
  public void test3970() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794857,-1.5707963267948966,12.622890053593352 ) ;
  }

  @Test
  public void test3971() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948573,-86.01476579766717,-1.5707963267948966 ) ;
  }

  @Test
  public void test3972() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794859,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3973() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948593,-3.277698265618996,-93.36588028227726 ) ;
  }

  @Test
  public void test3974() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948593,-41.785878502463696,73.6655019568331 ) ;
  }

  @Test
  public void test3975() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948664,-1.5707963267948966,-45.442976643788676 ) ;
  }

  @Test
  public void test3976() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948664,-15.838150683425042,1.5707963267948966 ) ;
  }

  @Test
  public void test3977() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948697,-85.1695969711165,-54.69376100189739 ) ;
  }

  @Test
  public void test3978() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948735,-53.465948191374636,-88.46045279230432 ) ;
  }

  @Test
  public void test3979() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948735,-97.77673610360026,-97.94495137366208 ) ;
  }

  @Test
  public void test3980() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079632679487,-38.60097590592714,-9.05273511891761 ) ;
  }

  @Test
  public void test3981() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948766,-1.570796326794897,1.5281689670455911 ) ;
  }

  @Test
  public void test3982() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794877,-23.397062816115934,-1.5707963267948966 ) ;
  }

  @Test
  public void test3983() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794877,-97.9426599536351,4.712388984011682 ) ;
  }

  @Test
  public void test3984() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794879,-1.7534474792067224E-192,14.702266478129687 ) ;
  }

  @Test
  public void test3985() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948792,-1.570796326794896,-56.50558698761685 ) ;
  }

  @Test
  public void test3986() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948812,-1.5687097019299323,-1.5707963267948966 ) ;
  }

  @Test
  public void test3987() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-0.4393650094834718,42.715640347072735 ) ;
  }

  @Test
  public void test3988() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-1.5707962989440818,-62.489056208619715 ) ;
  }

  @Test
  public void test3989() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-9.633474931902171,96.58716515657268 ) ;
  }

  @Test
  public void test3990() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-9.840640562500342,-1.5707963267948843 ) ;
  }

  @Test
  public void test3991() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948848,-1.5707963267948966,73.33390399201807 ) ;
  }

  @Test
  public void test3992() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948866,-155.05774547838126,42.88650737681283 ) ;
  }

  @Test
  public void test3993() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794886,-67.14815720978744,-1.5707963267948983 ) ;
  }

  @Test
  public void test3994() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794887,-16.097037374490654,52.07706980270861 ) ;
  }

  @Test
  public void test3995() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948877,-10.034763591957855,0.0 ) ;
  }

  @Test
  public void test3996() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948877,-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test3997() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948877,-1.5707963267948966,-21.895500128252337 ) ;
  }

  @Test
  public void test3998() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948877,-1.5707963267948966,22.57327231015813 ) ;
  }

  @Test
  public void test3999() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948877,-22.482764431110922,0.13743439654574782 ) ;
  }

  @Test
  public void test4000() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948877,-35.1597264088841,59.92208002905221 ) ;
  }

  @Test
  public void test4001() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948877,-54.850552295977906,-4.949458189326004 ) ;
  }

  @Test
  public void test4002() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948877,-66.81801024964822,-1.5707963267948966 ) ;
  }

  @Test
  public void test4003() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948877,-73.81707563472557,-0.689028748599203 ) ;
  }

  @Test
  public void test4004() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794887,-85.42191610677483,-47.7516869125304 ) ;
  }

  @Test
  public void test4005() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948895,-35.90753549494784,34.689271047455605 ) ;
  }

  @Test
  public void test4006() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948895,-3.66857029135177,-31.44657337800739 ) ;
  }

  @Test
  public void test4007() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948901,-10.215222910118433,-17.041574877735023 ) ;
  }

  @Test
  public void test4008() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948903,0.9472363230774477,0 ) ;
  }

  @Test
  public void test4009() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948906,-60.94783765055261,0.0 ) ;
  }

  @Test
  public void test4010() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948908,-0.4291382555987315,7.853981634015038 ) ;
  }

  @Test
  public void test4011() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794891,-1.5707963267948966,1.570796322747513 ) ;
  }

  @Test
  public void test4012() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.02126922894615886,-1008.335337934602 ) ;
  }

  @Test
  public void test4013() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.02367603219549729,100.0 ) ;
  }

  @Test
  public void test4014() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.03687928830829809,40.282415026264204 ) ;
  }

  @Test
  public void test4015() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.08022182691798774,33.7054833054729 ) ;
  }

  @Test
  public void test4016() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.15273889195529555,-0.5375011519804853 ) ;
  }

  @Test
  public void test4017() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.19970795109697853,99.49245767387042 ) ;
  }

  @Test
  public void test4018() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.21501775513258137,-84.73346269937062 ) ;
  }

  @Test
  public void test4019() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.2700767531894428,-91.1967137892441 ) ;
  }

  @Test
  public void test4020() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.2819254172737448,54.846819307939526 ) ;
  }

  @Test
  public void test4021() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.29304937787541174,-35.150754222687944 ) ;
  }

  @Test
  public void test4022() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.3888650432198335,-48.71223994339486 ) ;
  }

  @Test
  public void test4023() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.43420550799785285,-59.95769459639102 ) ;
  }

  @Test
  public void test4024() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.5361740933614177,50.983488178104466 ) ;
  }

  @Test
  public void test4025() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.541981444064085,47.53621733032914 ) ;
  }

  @Test
  public void test4026() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.6830018508432971,-1.5707963267948966 ) ;
  }

  @Test
  public void test4027() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.6957696817806138,-98.67195149871706 ) ;
  }

  @Test
  public void test4028() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.7972733455732607,16.159011091880473 ) ;
  }

  @Test
  public void test4029() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.9017126832828097,7.087328062968098 ) ;
  }

  @Test
  public void test4030() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.9870687096704714,64.01070056071737 ) ;
  }

  @Test
  public void test4031() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.034824827367288,1061.2551233087013 ) ;
  }

  @Test
  public void test4032() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.0687599371523322,0.0 ) ;
  }

  @Test
  public void test4033() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.728635162613678,-55.42832887354798 ) ;
  }

  @Test
  public void test4034() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.087984063761927,-1.5707963267948966 ) ;
  }

  @Test
  public void test4035() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.960837077941122,-186.560443583118 ) ;
  }

  @Test
  public void test4036() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.1045244434336468,73.32663009787422 ) ;
  }

  @Test
  public void test4037() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.1357860755109856,-27.921940557293695 ) ;
  }

  @Test
  public void test4038() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.138591759952071,64.11469235183736 ) ;
  }

  @Test
  public void test4039() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.1694386815475977,22.757745434821516 ) ;
  }

  @Test
  public void test4040() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-117.5658445418066,60.59732117055958 ) ;
  }

  @Test
  public void test4041() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-117.65336616848484,-147.6532919755557 ) ;
  }

  @Test
  public void test4042() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.222586085213294,94.75292724516942 ) ;
  }

  @Test
  public void test4043() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.264644117553063,50.69348695509563 ) ;
  }

  @Test
  public void test4044() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.3165806967374039,45.10885427803794 ) ;
  }

  @Test
  public void test4045() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-136.6359832448403,-28.522423032620637 ) ;
  }

  @Test
  public void test4046() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.3877787807814457E-17,-43.98891478207241 ) ;
  }

  @Test
  public void test4047() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-141.69759956919725,-71.55927784457381 ) ;
  }

  @Test
  public void test4048() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.4300453602260115,62.38340846871685 ) ;
  }

  @Test
  public void test4049() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,14.4292045390443,21.6865131572509 ) ;
  }

  @Test
  public void test4050() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,14.430054996644792,-35.88114804586674 ) ;
  }

  @Test
  public void test4051() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.445171890918345,-88.69746685261813 ) ;
  }

  @Test
  public void test4052() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.458711331390622,-1.3821220754972692 ) ;
  }

  @Test
  public void test4053() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.508350104607731,64.21169239054974 ) ;
  }

  @Test
  public void test4054() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.528735349461811,42.92163951113478 ) ;
  }

  @Test
  public void test4055() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5356895374291261E-238,-77.38454710098335 ) ;
  }

  @Test
  public void test4056() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5374673927323723,54.858271728291925 ) ;
  }

  @Test
  public void test4057() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.56325542640776,-1.5707963267948983 ) ;
  }

  @Test
  public void test4058() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948912,-57.49359494634412 ) ;
  }

  @Test
  public void test4059() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948948,47.267167153730014 ) ;
  }

  @Test
  public void test4060() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948961,33.609097420918914 ) ;
  }

  @Test
  public void test4061() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.570796326794896,-20.727400233542028 ) ;
  }

  @Test
  public void test4062() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,12.169718207314249 ) ;
  }

  @Test
  public void test4063() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test4064() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4065() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,2.4677579418653533E-178 ) ;
  }

  @Test
  public void test4066() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,2.5026038689788762E-147 ) ;
  }

  @Test
  public void test4067() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,27.663933753198098 ) ;
  }

  @Test
  public void test4068() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,4.440892098500626E-16 ) ;
  }

  @Test
  public void test4069() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,46.09113483544732 ) ;
  }

  @Test
  public void test4070() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-53.23518446500519 ) ;
  }

  @Test
  public void test4071() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-54.779091398591454 ) ;
  }

  @Test
  public void test4072() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-58.2947111017752 ) ;
  }

  @Test
  public void test4073() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,6.287091559311445 ) ;
  }

  @Test
  public void test4074() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-6.870738805597611 ) ;
  }

  @Test
  public void test4075() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,71.60420684566219 ) ;
  }

  @Test
  public void test4076() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-75.20693629082491 ) ;
  }

  @Test
  public void test4077() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-75.64178287717107 ) ;
  }

  @Test
  public void test4078() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-75.76781252567085 ) ;
  }

  @Test
  public void test4079() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,77.26032000395179 ) ;
  }

  @Test
  public void test4080() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-77.33466568881664 ) ;
  }

  @Test
  public void test4081() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-77.5666500756341 ) ;
  }

  @Test
  public void test4082() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,88.60832241109065 ) ;
  }

  @Test
  public void test4083() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-89.74229790605428 ) ;
  }

  @Test
  public void test4084() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948968,-36.12880379753506 ) ;
  }

  @Test
  public void test4085() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948968,-69.56447339877789 ) ;
  }

  @Test
  public void test4086() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948983,-21.463099053375714 ) ;
  }

  @Test
  public void test4087() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948983,-27.672568455232664 ) ;
  }

  @Test
  public void test4088() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948983,38.992866724127836 ) ;
  }

  @Test
  public void test4089() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948983,49.80862523136455 ) ;
  }

  @Test
  public void test4090() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948983,-63.31957701482456 ) ;
  }

  @Test
  public void test4091() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267949057,-88.00324401886246 ) ;
  }

  @Test
  public void test4092() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963268453056,8.401917917019091 ) ;
  }

  @Test
  public void test4093() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-15.749618291108092,113.783366089552 ) ;
  }

  @Test
  public void test4094() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-15.872011018233934,100.0 ) ;
  }

  @Test
  public void test4095() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-15.89186924346744,-14.213805031280842 ) ;
  }

  @Test
  public void test4096() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-15.954005318996375,76.2604832730751 ) ;
  }

  @Test
  public void test4097() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-16.10827867445385,0.33506177530399 ) ;
  }

  @Test
  public void test4098() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-16.1139991741385,79.8529570690576 ) ;
  }

  @Test
  public void test4099() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-16.193876179165272,-0.9116766888298217 ) ;
  }

  @Test
  public void test4100() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-16.197758851418534,48.537631960809364 ) ;
  }

  @Test
  public void test4101() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-16.240896299699543,-261.9094949923559 ) ;
  }

  @Test
  public void test4102() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.823927506471951E-4,56.40815052395615 ) ;
  }

  @Test
  public void test4103() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-192.77476616175295,-79.85449065195345 ) ;
  }

  @Test
  public void test4104() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-22.434625148635142,30.91653359295354 ) ;
  }

  @Test
  public void test4105() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-22.488767383156848,1.5707963267955343 ) ;
  }

  @Test
  public void test4106() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-23.311850710856575,0.0 ) ;
  }

  @Test
  public void test4107() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-23.36997172534828,-60.542561115355475 ) ;
  }

  @Test
  public void test4108() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-23.431986739042948,-67.37504780364463 ) ;
  }

  @Test
  public void test4109() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-23.44720925435189,-148.02068746308316 ) ;
  }

  @Test
  public void test4110() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-28.355195141189256,34.1802993277646 ) ;
  }

  @Test
  public void test4111() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-28.53764507889018,-67.47425354020902 ) ;
  }

  @Test
  public void test4112() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-29.33108296995689,-1.5707963267948966 ) ;
  }

  @Test
  public void test4113() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-29.77177314731619,-0.9545424001557713 ) ;
  }

  @Test
  public void test4114() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,3.1415926535897953,-49.93774296259752 ) ;
  }

  @Test
  public void test4115() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.1494051543929245,-123.32070208036475 ) ;
  }

  @Test
  public void test4116() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,3.1495121229908376,-89.634070950301 ) ;
  }

  @Test
  public void test4117() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.1563379373916725,-9.596773912214353 ) ;
  }

  @Test
  public void test4118() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.1756350514186886,-56.35357032292929 ) ;
  }

  @Test
  public void test4119() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.2516359364159584,-67.1443856128879 ) ;
  }

  @Test
  public void test4120() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.3060025406243625,-84.74090914911443 ) ;
  }

  @Test
  public void test4121() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.3124302267639925,61.02659158975039 ) ;
  }

  @Test
  public void test4122() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.337068160908356,-73.91237899754046 ) ;
  }

  @Test
  public void test4123() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.4285850531786863,-23.081444451218943 ) ;
  }

  @Test
  public void test4124() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-34.617260808850254,13.719522388576166 ) ;
  }

  @Test
  public void test4125() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-34.67660654368365,-6.463847109604636 ) ;
  }

  @Test
  public void test4126() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-34.80946165577814,56.690349676810044 ) ;
  }

  @Test
  public void test4127() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-34.90066880806448,-49.51168109828714 ) ;
  }

  @Test
  public void test4128() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.04270462566186,82.55723931930049 ) ;
  }

  @Test
  public void test4129() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.224074860109106,90.86745177852822 ) ;
  }

  @Test
  public void test4130() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.472623755114746,-25.683125842293435 ) ;
  }

  @Test
  public void test4131() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.66007224395582,43.886267565903864 ) ;
  }

  @Test
  public void test4132() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.70290492491836,-88.76783645847098 ) ;
  }

  @Test
  public void test4133() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.76926093110513,-58.15098843703159 ) ;
  }

  @Test
  public void test4134() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.790489489501525,23.561944901923447 ) ;
  }

  @Test
  public void test4135() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.675248187528993,95.21032723369287 ) ;
  }

  @Test
  public void test4136() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.904862516932548,-32.5899461271206 ) ;
  }

  @Test
  public void test4137() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-4.005279750488057,-1.1695487287333162 ) ;
  }

  @Test
  public void test4138() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-40.96242212419049,-50.07368984159337 ) ;
  }

  @Test
  public void test4139() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.24123299620408,-57.62571734706656 ) ;
  }

  @Test
  public void test4140() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-4.1414824535699495,67.9443062075984 ) ;
  }

  @Test
  public void test4141() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.42190297693808,43.02578457915408 ) ;
  }

  @Test
  public void test4142() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.66825150391509,-21.971076338398007 ) ;
  }

  @Test
  public void test4143() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.70763159017548,56.384167988618124 ) ;
  }

  @Test
  public void test4144() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-4.170823503122804,-3.1545417556514668 ) ;
  }

  @Test
  public void test4145() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.85338317905351,78.3108586076738 ) ;
  }

  @Test
  public void test4146() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.946195029566404,9.428684726632662 ) ;
  }

  @Test
  public void test4147() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-42.109923829377806,-22.433201059313504 ) ;
  }

  @Test
  public void test4148() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-42.348916903847446,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test4149() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-4.395229868149173,-56.52737616248764 ) ;
  }

  @Test
  public void test4150() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-4.440892098500626E-16,-81.6505823159419 ) ;
  }

  @Test
  public void test4151() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-4.590294004666196,-55.18109186206971 ) ;
  }

  @Test
  public void test4152() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-47.35766152451903,38.957802645280815 ) ;
  }

  @Test
  public void test4153() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.41159853077009,-56.6966405438783 ) ;
  }

  @Test
  public void test4154() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.44091783506439,41.52739809170881 ) ;
  }

  @Test
  public void test4155() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.50291138065062,0.0 ) ;
  }

  @Test
  public void test4156() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.57118381435804,42.000862670786596 ) ;
  }

  @Test
  public void test4157() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-53.51514015800956,-17.226531858407288 ) ;
  }

  @Test
  public void test4158() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-53.53944754660463,-2.002083095183101E-146 ) ;
  }

  @Test
  public void test4159() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-53.63745018759312,-38.687051979933806 ) ;
  }

  @Test
  public void test4160() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-53.93972148001485,-48.22412188129527 ) ;
  }

  @Test
  public void test4161() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.251678042724194,-91.17321046532973 ) ;
  }

  @Test
  public void test4162() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-60.10811100160123,-60.37302025375533 ) ;
  }

  @Test
  public void test4163() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-60.60805016822752,-98.5341588286814 ) ;
  }

  @Test
  public void test4164() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-60.790871061395954,-28.375987068341814 ) ;
  }

  @Test
  public void test4165() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-60.83412446315542,-50.38165469009472 ) ;
  }

  @Test
  public void test4166() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-61.015911571888395,3.2515077784369026 ) ;
  }

  @Test
  public void test4167() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-61.22434206388543,-73.24496624097715 ) ;
  }

  @Test
  public void test4168() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.31398456975447,18.921654213162753 ) ;
  }

  @Test
  public void test4169() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.67372610832251,-13.74571509614033 ) ;
  }

  @Test
  public void test4170() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-67.02576851374988,-67.02902769983369 ) ;
  }

  @Test
  public void test4171() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-7.105427357601002E-15,-78.14848825230452 ) ;
  }

  @Test
  public void test4172() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-72.32678454096508,-10.55727197263189 ) ;
  }

  @Test
  public void test4173() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-72.46758599895743,3.1416002829846197 ) ;
  }

  @Test
  public void test4174() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-72.97458019192757,80.58266353241729 ) ;
  }

  @Test
  public void test4175() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-73.01302863580523,-82.86997677413893 ) ;
  }

  @Test
  public void test4176() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-73.01593555094401,-44.50912501735565 ) ;
  }

  @Test
  public void test4177() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-73.0610843918462,91.93245245320287 ) ;
  }

  @Test
  public void test4178() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-73.14202010749604,25.97056622894786 ) ;
  }

  @Test
  public void test4179() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-73.21790169903794,-77.22155399696796 ) ;
  }

  @Test
  public void test4180() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-73.63245643597959,-9.93872076397082 ) ;
  }

  @Test
  public void test4181() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-73.65426414934247,-1.5707317960330585 ) ;
  }

  @Test
  public void test4182() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-78.53981633974483,0 ) ;
  }

  @Test
  public void test4183() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-78.54040988446073,25.423412514740182 ) ;
  }

  @Test
  public void test4184() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-79.00824978420309,1.5707963267948966 ) ;
  }

  @Test
  public void test4185() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-84.92848675513308,-579.4938214263075 ) ;
  }

  @Test
  public void test4186() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-84.9747325906675,91.67984391626277 ) ;
  }

  @Test
  public void test4187() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-85.43343253081436,-66.02683411905838 ) ;
  }

  @Test
  public void test4188() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-86.35251015613002,-1.5707963267948983 ) ;
  }

  @Test
  public void test4189() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-91.11485952818566,-73.53474525257187 ) ;
  }

  @Test
  public void test4190() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-91.27011097129517,-42.78175387766119 ) ;
  }

  @Test
  public void test4191() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-91.99010088244918,-48.4094542276552 ) ;
  }

  @Test
  public void test4192() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-92.031020175288,-1.5707963267948966 ) ;
  }

  @Test
  public void test4193() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-92.17670778921763,-16.432996285346775 ) ;
  }

  @Test
  public void test4194() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-92.1868884260657,-1.5707963267948966 ) ;
  }

  @Test
  public void test4195() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,9.424779879130316,94.61631055077697 ) ;
  }

  @Test
  public void test4196() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-9.54711735476366,8.1034797997807 ) ;
  }

  @Test
  public void test4197() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-9.636711883693579,8.805575190321434 ) ;
  }

  @Test
  public void test4198() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-97.39919867646647,-37.63553437957488 ) ;
  }

  @Test
  public void test4199() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-97.41904951272622,-16.04178702840938 ) ;
  }

  @Test
  public void test4200() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-97.67822203137995,-32.32026043147178 ) ;
  }

  @Test
  public void test4201() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-97.74135798395716,-63.57108958237734 ) ;
  }

  @Test
  public void test4202() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-97.75881842078923,-63.579042328394856 ) ;
  }

  @Test
  public void test4203() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-97.94634520952886,0.0 ) ;
  }

  @Test
  public void test4204() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-98.21362632744342,1.570796326794893 ) ;
  }

  @Test
  public void test4205() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-98.23788628446879,-7.711778649682973 ) ;
  }

  @Test
  public void test4206() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-98.51051897632856,-85.20321573002731 ) ;
  }

  @Test
  public void test4207() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-98.74650185978439,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test4208() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-98.80803691977084,-45.424120755429115 ) ;
  }

  @Test
  public void test4209() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-9.937698562239376,-1.5707963267949019 ) ;
  }

  @Test
  public void test4210() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-9.948885598926486,1.5762555442777697 ) ;
  }

  @Test
  public void test4211() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948915,-1.5707963267948966,-100.92245659350866 ) ;
  }

  @Test
  public void test4212() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948915,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4213() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948915,-47.403936641860156,1.5707963267948968 ) ;
  }

  @Test
  public void test4214() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948917,-5.551115123125783E-17,-31.44717654426487 ) ;
  }

  @Test
  public void test4215() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948921,-198.63937893527643,-5.182067555137299E-14 ) ;
  }

  @Test
  public void test4216() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794892,-1.5707963267948966,89.69567425865458 ) ;
  }

  @Test
  public void test4217() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948928,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test4218() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948928,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4219() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948928,-41.3939405121181,68.84384211830044 ) ;
  }

  @Test
  public void test4220() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-1.5707963267948788,62.598360087787086 ) ;
  }

  @Test
  public void test4221() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948932,-1.5707963267948961,-1.5707963267948966 ) ;
  }

  @Test
  public void test4222() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948932,-1.5707963267948966,49.10525427285628 ) ;
  }

  @Test
  public void test4223() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-41.621132304794,136.21977853505797 ) ;
  }

  @Test
  public void test4224() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948937,-0.13900753682827582,-1.5707963267948968 ) ;
  }

  @Test
  public void test4225() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948937,-1.5707963267948966,-1.5707963268052985 ) ;
  }

  @Test
  public void test4226() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948937,-1.5707963267948966,36.95080885216407 ) ;
  }

  @Test
  public void test4227() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948937,-16.16480772356892,1.406564154096679 ) ;
  }

  @Test
  public void test4228() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-98.90467839489392,98.93736346749344 ) ;
  }

  @Test
  public void test4229() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794894,-0.249868352756424,88.18508537190414 ) ;
  }

  @Test
  public void test4230() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948941,-1.5707963266456928,-1.5707963267948966 ) ;
  }

  @Test
  public void test4231() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948941,-1.5707963267948966,53.97804871923231 ) ;
  }

  @Test
  public void test4232() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794894,-1.5556804618389689E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test4233() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948943,-1.0880193641640687,-24.655120544910186 ) ;
  }

  @Test
  public void test4234() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948943,-1.5707963267948966,78.43743913525125 ) ;
  }

  @Test
  public void test4235() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948943,-3.1416546436241872,-12.778543433485375 ) ;
  }

  @Test
  public void test4236() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948943,-48.640661320448885,-3.1415932143669134 ) ;
  }

  @Test
  public void test4237() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948943,-7.105427357601002E-15,91.10619076880154 ) ;
  }

  @Test
  public void test4238() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794894,-5.293955920339377E-23,12.847205623872693 ) ;
  }

  @Test
  public void test4239() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948946,-0.07953665373238794,-0.035734719862319464 ) ;
  }

  @Test
  public void test4240() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.011901035701426043,-3.1938241301004426 ) ;
  }

  @Test
  public void test4241() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.025004593027292188,84.2477672337566 ) ;
  }

  @Test
  public void test4242() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.03722483055458101,3.1416231719257874 ) ;
  }

  @Test
  public void test4243() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.049734149904809045,1.5707963267948966 ) ;
  }

  @Test
  public void test4244() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,0.1054685850005567,6.321571700979977 ) ;
  }

  @Test
  public void test4245() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.1243558580139228,-11.992328185316788 ) ;
  }

  @Test
  public void test4246() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.12983022810797207,-94.90656912177181 ) ;
  }

  @Test
  public void test4247() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.20881045110239083,-96.30252261891523 ) ;
  }

  @Test
  public void test4248() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.21844783191629197,-25.134873691493382 ) ;
  }

  @Test
  public void test4249() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.24730632938634844,-1.5707963267948966 ) ;
  }

  @Test
  public void test4250() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.26557697896591437,23.27871917640583 ) ;
  }

  @Test
  public void test4251() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.2802698145176468,3.960937040843035 ) ;
  }

  @Test
  public void test4252() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.32357175329563914,-1.5707963267948966 ) ;
  }

  @Test
  public void test4253() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.5381666987166609,-55.685209285940246 ) ;
  }

  @Test
  public void test4254() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.5510166414229308,6.454565639031378 ) ;
  }

  @Test
  public void test4255() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.6767218915957686,-475.3804476480116 ) ;
  }

  @Test
  public void test4256() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.9708328852984036,-42.55623599684859 ) ;
  }

  @Test
  public void test4257() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.0014440624249428,54.808669570360536 ) ;
  }

  @Test
  public void test4258() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.057159383587494,-27.081495189189326 ) ;
  }

  @Test
  public void test4259() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-10.851571417611332,-1.5707963267948966 ) ;
  }

  @Test
  public void test4260() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.0939228030795825,-20.20780925029051 ) ;
  }

  @Test
  public void test4261() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.303398633892116,10.160663711939792 ) ;
  }

  @Test
  public void test4262() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.3579297723450279,4.875595360399064 ) ;
  }

  @Test
  public void test4263() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.3755188912599732,-57.24923682049903 ) ;
  }

  @Test
  public void test4264() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.3887757183315648,-53.18441017190013 ) ;
  }

  @Test
  public void test4265() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.429322284166599,6.298810318353245 ) ;
  }

  @Test
  public void test4266() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5410247309353018,1.5707963267948966 ) ;
  }

  @Test
  public void test4267() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5452245571986192,10.258806063359511 ) ;
  }

  @Test
  public void test4268() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267947422,62.87230990542053 ) ;
  }

  @Test
  public void test4269() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948841,-66.50498676120377 ) ;
  }

  @Test
  public void test4270() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948877,-124.10812227907488 ) ;
  }

  @Test
  public void test4271() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948912,38.34801276547364 ) ;
  }

  @Test
  public void test4272() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948948,37.93129330213044 ) ;
  }

  @Test
  public void test4273() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948957,-43.425962138172466 ) ;
  }

  @Test
  public void test4274() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948961,2.3738919364399497E-66 ) ;
  }

  @Test
  public void test4275() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948963,-0.5349662845172084 ) ;
  }

  @Test
  public void test4276() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948963,62.8738037151155 ) ;
  }

  @Test
  public void test4277() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948963,90.11151448574756 ) ;
  }

  @Test
  public void test4278() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test4279() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4280() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-0.531561910305563 ) ;
  }

  @Test
  public void test4281() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-1.0010415475915505E-146 ) ;
  }

  @Test
  public void test4282() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,13.040882169506562 ) ;
  }

  @Test
  public void test4283() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,1.5328940016856234 ) ;
  }

  @Test
  public void test4284() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,1.979247614335467 ) ;
  }

  @Test
  public void test4285() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,2.220446049250313E-16 ) ;
  }

  @Test
  public void test4286() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,28.360286094901486 ) ;
  }

  @Test
  public void test4287() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-29.28951430681829 ) ;
  }

  @Test
  public void test4288() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-35.21412412703002 ) ;
  }

  @Test
  public void test4289() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-67.54424205218055 ) ;
  }

  @Test
  public void test4290() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-76.18582950963136 ) ;
  }

  @Test
  public void test4291() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-84.70085460150955 ) ;
  }

  @Test
  public void test4292() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,88.41814937929277 ) ;
  }

  @Test
  public void test4293() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,89.89391631523904 ) ;
  }

  @Test
  public void test4294() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948968,0.0 ) ;
  }

  @Test
  public void test4295() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948968,-45.940931776337855 ) ;
  }

  @Test
  public void test4296() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948983,62.90980286989566 ) ;
  }

  @Test
  public void test4297() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-15.776188627137955,94.13757470811446 ) ;
  }

  @Test
  public void test4298() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-15.86111987816937,-22.159902481062982 ) ;
  }

  @Test
  public void test4299() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,1.9721522630525295E-31,78.44656740777295 ) ;
  }

  @Test
  public void test4300() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-2.1383633508752524,0 ) ;
  }

  @Test
  public void test4301() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-2.220446049250313E-16,57.909048177110655 ) ;
  }

  @Test
  public void test4302() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-22.26571649800242,78.20671736907354 ) ;
  }

  @Test
  public void test4303() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-23.321280860330514,-1.570796272965329 ) ;
  }

  @Test
  public void test4304() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-23.731699536688886,42.89174305087778 ) ;
  }

  @Test
  public void test4305() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-2.557282527988845E-16,1.5707963267948963 ) ;
  }

  @Test
  public void test4306() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-28.369269243755582,33.02488859743994 ) ;
  }

  @Test
  public void test4307() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-3.1420809348400174,-1.5675046814782707 ) ;
  }

  @Test
  public void test4308() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-3.1435457785901026,16.11781064140463 ) ;
  }

  @Test
  public void test4309() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-3.3021986091885394,1.5707963267948966 ) ;
  }

  @Test
  public void test4310() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-3.3087224502121107E-24,0.0 ) ;
  }

  @Test
  public void test4311() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-3.315617948202659,64.59316483014834 ) ;
  }

  @Test
  public void test4312() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-3.4455499375529968,100.0 ) ;
  }

  @Test
  public void test4313() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-3.4493059005278868,-1.5707963267948966 ) ;
  }

  @Test
  public void test4314() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-34.84281349826956,-79.47845130691769 ) ;
  }

  @Test
  public void test4315() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-34.91014667935035,6.28331167336389 ) ;
  }

  @Test
  public void test4316() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-34.914882349337084,85.16749324917859 ) ;
  }

  @Test
  public void test4317() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-34.95378242609041,-52.53955024034573 ) ;
  }

  @Test
  public void test4318() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-35.53113698243517,0.0 ) ;
  }

  @Test
  public void test4319() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-35.60823509530226,20.420352248333657 ) ;
  }

  @Test
  public void test4320() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-35.68668841064661,1.4866884564664775 ) ;
  }

  @Test
  public void test4321() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-35.88297935489304,64.96129347057273 ) ;
  }

  @Test
  public void test4322() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-35.91145014435896,-19.70206265689656 ) ;
  }

  @Test
  public void test4323() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-36.12457060401222,-60.594169755449215 ) ;
  }

  @Test
  public void test4324() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-40.886475339582276,90.69264558699444 ) ;
  }

  @Test
  public void test4325() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-40.89324081936283,56.134161507697144 ) ;
  }

  @Test
  public void test4326() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-41.40918091446363,-55.91998055076128 ) ;
  }

  @Test
  public void test4327() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,4.141592653589806,55.54461811768155 ) ;
  }

  @Test
  public void test4328() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-41.47838367096121,-20.64077185206512 ) ;
  }

  @Test
  public void test4329() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-41.73375348222677,-95.91556568168762 ) ;
  }

  @Test
  public void test4330() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-41.98954595702858,-52.69228376869761 ) ;
  }

  @Test
  public void test4331() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-42.211571118455815,40.26009142462746 ) ;
  }

  @Test
  public void test4332() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-47.38892816965017,-88.96815415740673 ) ;
  }

  @Test
  public void test4333() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-47.90368724119607,-56.53211161815251 ) ;
  }

  @Test
  public void test4334() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-48.148408276394726,-55.56852956040868 ) ;
  }

  @Test
  public void test4335() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-48.48175999851812,-8.85398176412659 ) ;
  }

  @Test
  public void test4336() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-512.2974784784155,-3.307176570756964 ) ;
  }

  @Test
  public void test4337() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-52.49288139964872,0 ) ;
  }

  @Test
  public void test4338() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-5.293955920339377E-23,-52.805422795994495 ) ;
  }

  @Test
  public void test4339() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-53.485732574688384,-10.685887430164914 ) ;
  }

  @Test
  public void test4340() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-53.67751814286194,-1.3334413065746749 ) ;
  }

  @Test
  public void test4341() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-54.06547736529844,-0.7520286893533895 ) ;
  }

  @Test
  public void test4342() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-54.83754471634903,46.34690713047891 ) ;
  }

  @Test
  public void test4343() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-60.797397084650775,44.03977747104162 ) ;
  }

  @Test
  public void test4344() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-60.85599572764419,-1.3735717597047326 ) ;
  }

  @Test
  public void test4345() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-60.86016228970257,-27.644228005212966 ) ;
  }

  @Test
  public void test4346() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-66.43676377059502,-78.1841265302559 ) ;
  }

  @Test
  public void test4347() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-66.87454167984804,-79.853528392292 ) ;
  }

  @Test
  public void test4348() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-66.92470901738912,1.5707963267948912 ) ;
  }

  @Test
  public void test4349() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-66.94880094617284,-47.64887118711842 ) ;
  }

  @Test
  public void test4350() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-72.97353858439135,71.99296247569478 ) ;
  }

  @Test
  public void test4351() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-73.14090302860166,0.0 ) ;
  }

  @Test
  public void test4352() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-73.82299113631633,-1.2531231249637713 ) ;
  }

  @Test
  public void test4353() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-78.96371694035288,-75.39822611773347 ) ;
  }

  @Test
  public void test4354() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-79.99952054300898,-82.09983834599424 ) ;
  }

  @Test
  public void test4355() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-91.2927828840823,-1.5707963267948957 ) ;
  }

  @Test
  public void test4356() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-97.78525143416783,38.67651912641813 ) ;
  }

  @Test
  public void test4357() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-97.84826471323022,-130.31171312058004 ) ;
  }

  @Test
  public void test4358() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-98.12441652622441,-61.496304507994346 ) ;
  }

  @Test
  public void test4359() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-98.51547026101277,-12.01670685478819 ) ;
  }

  @Test
  public void test4360() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-98.59088038064847,-2465.1230475203984 ) ;
  }

  @Test
  public void test4361() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-98.70143066971266,-88.54799503002621 ) ;
  }

  @Test
  public void test4362() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-98.79153869419784,-2447.690949179077 ) ;
  }

  @Test
  public void test4363() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794895,-0.47291184349050774,13.559328197931663 ) ;
  }

  @Test
  public void test4364() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794895,-1.5707963267948966,-20.339495469958713 ) ;
  }

  @Test
  public void test4365() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948952,14.432791379801834,90.97955239790144 ) ;
  }

  @Test
  public void test4366() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948952,-1.5707963267948966,-70.493194901908 ) ;
  }

  @Test
  public void test4367() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948952,-1.570796326794898,6.283185307179591 ) ;
  }

  @Test
  public void test4368() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948952,-3.4328267109088935,-70.82074991233887 ) ;
  }

  @Test
  public void test4369() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948952,-61.10740032514656,62.848425888586945 ) ;
  }

  @Test
  public void test4370() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948954,-1.5707963267948966,0.29425213669824757 ) ;
  }

  @Test
  public void test4371() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948954,-1.5707963267948966,0.7356396947541197 ) ;
  }

  @Test
  public void test4372() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948954,-1.5707963267948966,11.039728883939187 ) ;
  }

  @Test
  public void test4373() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948954,-1.5707963267948966,71.5074514045265 ) ;
  }

  @Test
  public void test4374() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948954,-1.5707963267948966,-89.14579469495325 ) ;
  }

  @Test
  public void test4375() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948954,-15.96431618642153,49.487133305087006 ) ;
  }

  @Test
  public void test4376() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948954,-66.79423933625557,49.91702779442011 ) ;
  }

  @Test
  public void test4377() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794895,-47.93690113563065,-3.465706499959721 ) ;
  }

  @Test
  public void test4378() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794895,-53.483312609905994,55.03241688368622 ) ;
  }

  @Test
  public void test4379() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.011138415422675954,8.929588994392773E-103 ) ;
  }

  @Test
  public void test4380() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.0993243470204021,3.34810019627349 ) ;
  }

  @Test
  public void test4381() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.10229815137515734,-84.65809868224059 ) ;
  }

  @Test
  public void test4382() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.3099484621767156,64.48729959239019 ) ;
  }

  @Test
  public void test4383() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.4897254438511115,25.7359053496649 ) ;
  }

  @Test
  public void test4384() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.5030214665975326,-66.78454002314912 ) ;
  }

  @Test
  public void test4385() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.7460221407393539,0.0 ) ;
  }

  @Test
  public void test4386() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.8728068084761986,2260.0980435697734 ) ;
  }

  @Test
  public void test4387() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-100.0,0 ) ;
  }

  @Test
  public void test4388() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.0601586442906576,-3.141592668500732 ) ;
  }

  @Test
  public void test4389() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-10.991225062752534,-34.78032023683724 ) ;
  }

  @Test
  public void test4390() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.1265560899488776,-20.39661192713368 ) ;
  }

  @Test
  public void test4391() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.287341860478679,7.889592629982889 ) ;
  }

  @Test
  public void test4392() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.399523028478471,-37.92926347731242 ) ;
  }

  @Test
  public void test4393() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.4138740704269912,-100.0 ) ;
  }

  @Test
  public void test4394() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5375976741838355,0.0 ) ;
  }

  @Test
  public void test4395() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948912,1.3504496889524689 ) ;
  }

  @Test
  public void test4396() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test4397() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4398() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4399() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,34.45574292976162 ) ;
  }

  @Test
  public void test4400() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,4.318137675819037 ) ;
  }

  @Test
  public void test4401() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,-75.74607745845464 ) ;
  }

  @Test
  public void test4402() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,79.18219961357858 ) ;
  }

  @Test
  public void test4403() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-16.098001495618593,33.88320730042537 ) ;
  }

  @Test
  public void test4404() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-16.747349706277056,-1.5707963267948966 ) ;
  }

  @Test
  public void test4405() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-3.2598784224238524,-66.5242949406159 ) ;
  }

  @Test
  public void test4406() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-35.46397236086281,1.5707963267948966 ) ;
  }

  @Test
  public void test4407() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-35.56524332688784,42.636516272982874 ) ;
  }

  @Test
  public void test4408() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-41.55604474519838,-77.06154847402529 ) ;
  }

  @Test
  public void test4409() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-41.583389791931026,4.141592702653867 ) ;
  }

  @Test
  public void test4410() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-47.32137670684335,7.654093630637373 ) ;
  }

  @Test
  public void test4411() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-47.38828323100674,-54.02882042192486 ) ;
  }

  @Test
  public void test4412() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-51.26077133352097,0 ) ;
  }

  @Test
  public void test4413() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-54.45211199201834,69.23327299418384 ) ;
  }

  @Test
  public void test4414() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-78.78952054378026,-1.1255376275546736 ) ;
  }

  @Test
  public void test4415() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-79.87918344444375,-55.030045786217784 ) ;
  }

  @Test
  public void test4416() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-97.43384596709026,-95.04058992910385 ) ;
  }

  @Test
  public void test4417() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-9.860761315262648E-32,70.30253765069878 ) ;
  }

  @Test
  public void test4418() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,0.4625544253638558,0.0 ) ;
  }

  @Test
  public void test4419() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-0.5357936722116691,3.141592655672148 ) ;
  }

  @Test
  public void test4420() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.05406327571389509,0.0 ) ;
  }

  @Test
  public void test4421() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.06752042145077208,1.5707963267948966 ) ;
  }

  @Test
  public void test4422() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.17053761524106636,-2354.089530802147 ) ;
  }

  @Test
  public void test4423() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,0.19011024037240298,-142.54733183248433 ) ;
  }

  @Test
  public void test4424() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.19372476046310752,7.853982402449239 ) ;
  }

  @Test
  public void test4425() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.3109349202218845,51.14746956468924 ) ;
  }

  @Test
  public void test4426() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.37980996759528185,529.3027547530628 ) ;
  }

  @Test
  public void test4427() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.3872403086394589,1.5707963267948966 ) ;
  }

  @Test
  public void test4428() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.5250918388677812,-15.131990376694914 ) ;
  }

  @Test
  public void test4429() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.8208714687287912,2.191809349008403E-193 ) ;
  }

  @Test
  public void test4430() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.9720623026627652,1.5707963267948968 ) ;
  }

  @Test
  public void test4431() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-10.025578309520625,0.0 ) ;
  }

  @Test
  public void test4432() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-10.847820928493299,0 ) ;
  }

  @Test
  public void test4433() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.165330346372185,28.265666718303056 ) ;
  }

  @Test
  public void test4434() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.2024322290703497,-27.971808660267357 ) ;
  }

  @Test
  public void test4435() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.4352104562613077,41.500647002755535 ) ;
  }

  @Test
  public void test4436() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,14.429777380496134,0.2391237493966593 ) ;
  }

  @Test
  public void test4437() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.570796326164647,-88.78676387522917 ) ;
  }

  @Test
  public void test4438() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963266047944,1.5707963267948948 ) ;
  }

  @Test
  public void test4439() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948755,21.409681174667572 ) ;
  }

  @Test
  public void test4440() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948928,100.0 ) ;
  }

  @Test
  public void test4441() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948948,-135.87236802163955 ) ;
  }

  @Test
  public void test4442() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948948,-1.5707963267948983 ) ;
  }

  @Test
  public void test4443() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948948,-4.410781579779517 ) ;
  }

  @Test
  public void test4444() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948963,-1.5707963267948966 ) ;
  }

  @Test
  public void test4445() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4446() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,-10.455815128927119 ) ;
  }

  @Test
  public void test4447() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4448() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,21.661755091650154 ) ;
  }

  @Test
  public void test4449() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,21.768460010772678 ) ;
  }

  @Test
  public void test4450() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,28.0022665503913 ) ;
  }

  @Test
  public void test4451() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,-32.24627605431713 ) ;
  }

  @Test
  public void test4452() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,-44.80129432180445 ) ;
  }

  @Test
  public void test4453() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,-44.84362729405633 ) ;
  }

  @Test
  public void test4454() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,-59.96344866683223 ) ;
  }

  @Test
  public void test4455() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,80.89244577254007 ) ;
  }

  @Test
  public void test4456() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948983,-0.997201338255806 ) ;
  }

  @Test
  public void test4457() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948983,-6.569277457974038 ) ;
  }

  @Test
  public void test4458() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-22.013355276062214,-6.43472765015006 ) ;
  }

  @Test
  public void test4459() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-2600.9793178021732,0 ) ;
  }

  @Test
  public void test4460() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-1.347648218201974,11.98705322104668 ) ;
  }

  @Test
  public void test4461() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-3.5897555962202325,-83.41595592309697 ) ;
  }

  @Test
  public void test4462() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-41.0885808030234,44.71399271239386 ) ;
  }

  @Test
  public void test4463() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-1.4123919777912346,16.89127822005347 ) ;
  }

  @Test
  public void test4464() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-4.133311040547358,0.0 ) ;
  }

  @Test
  public void test4465() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-42.09919988413913,-90.4399127596585 ) ;
  }

  @Test
  public void test4466() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-42.15346187073721,-21.840762626700744 ) ;
  }

  @Test
  public void test4467() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-4.273208426257092,-66.72395201310925 ) ;
  }

  @Test
  public void test4468() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-47.13951480384721,1.5707963267948966 ) ;
  }

  @Test
  public void test4469() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-48.5796034242224,-51.21536183565601 ) ;
  }

  @Test
  public void test4470() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-1.4974780035351996,-17.73330390972143 ) ;
  }

  @Test
  public void test4471() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4472() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-1.5707963267948966,47.40312096645704 ) ;
  }

  @Test
  public void test4473() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-60.77834943055238,-22.234551766222637 ) ;
  }

  @Test
  public void test4474() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-60.789520967389024,49.87336475270331 ) ;
  }

  @Test
  public void test4475() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-61.23741013195558,5.2123891890294995 ) ;
  }

  @Test
  public void test4476() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-66.66522646197784,-1.5707963267948966 ) ;
  }

  @Test
  public void test4477() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-72.3764009213053,-174.44633347512573 ) ;
  }

  @Test
  public void test4478() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-72.76973100327787,35.311445609792706 ) ;
  }

  @Test
  public void test4479() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-86.0483422484969,-29.206780477366415 ) ;
  }

  @Test
  public void test4480() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-9.427213759266706,-47.504678246884026 ) ;
  }

  @Test
  public void test4481() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-98.45078171316608,-44.77247798013481 ) ;
  }

  @Test
  public void test4482() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.001054752098327708,0.0 ) ;
  }

  @Test
  public void test4483() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.019657123465341052,28.06909971637873 ) ;
  }

  @Test
  public void test4484() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.0631170936260462,-15.167351062088883 ) ;
  }

  @Test
  public void test4485() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.13302602312779754,147.64289472333073 ) ;
  }

  @Test
  public void test4486() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.1799302985698038,1.5707963267948968 ) ;
  }

  @Test
  public void test4487() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.21642559475941506,-86.39379797371932 ) ;
  }

  @Test
  public void test4488() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.22081274351819713,55.296955348232935 ) ;
  }

  @Test
  public void test4489() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.22197735384644807,3.1415926694814558 ) ;
  }

  @Test
  public void test4490() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.2431320506662813,-28.160627053878827 ) ;
  }

  @Test
  public void test4491() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.24619655784800715,3.1416004014689793 ) ;
  }

  @Test
  public void test4492() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.293932033055064,0.0 ) ;
  }

  @Test
  public void test4493() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.4642971716422879,64.8974087508098 ) ;
  }

  @Test
  public void test4494() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.5209511733754885,0.0 ) ;
  }

  @Test
  public void test4495() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.5437926862947539,36.055086230022184 ) ;
  }

  @Test
  public void test4496() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.5579186371680454,-3.1415934518600626 ) ;
  }

  @Test
  public void test4497() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.5662020270759186,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test4498() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.5785958301372871,-1.5707957445209753 ) ;
  }

  @Test
  public void test4499() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.5796225723189347,75.23442231981772 ) ;
  }

  @Test
  public void test4500() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.6440807137331168,-42.61889495747993 ) ;
  }

  @Test
  public void test4501() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.8597113158842058,-63.64806469831535 ) ;
  }

  @Test
  public void test4502() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.9752475638471001,-1.5707963267948966 ) ;
  }

  @Test
  public void test4503() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-10.06590816517212,-7.853981634007333 ) ;
  }

  @Test
  public void test4504() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.0357278450043488,0.0 ) ;
  }

  @Test
  public void test4505() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-104.44418004549641,7.747558394883811 ) ;
  }

  @Test
  public void test4506() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.1102230246251565E-16,-5.141644342622174 ) ;
  }

  @Test
  public void test4507() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.112441645434226,20.30098887611929 ) ;
  }

  @Test
  public void test4508() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.1149715512573557,-20.778357834877372 ) ;
  }

  @Test
  public void test4509() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.177898365075916,72.92331681098442 ) ;
  }

  @Test
  public void test4510() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.253463138242454,-65.35836771462539 ) ;
  }

  @Test
  public void test4511() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.2637865636293208,-8.03475493841659 ) ;
  }

  @Test
  public void test4512() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.3069555856667514,-85.15231396302761 ) ;
  }

  @Test
  public void test4513() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.4032642389844525,-42.97880190055818 ) ;
  }

  @Test
  public void test4514() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.4107574052169634,68.23115407504655 ) ;
  }

  @Test
  public void test4515() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-3.141600295829204,62.66708337379008 ) ;
  }

  @Test
  public void test4516() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.4199126008548641,49.935464382349494 ) ;
  }

  @Test
  public void test4517() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.4971317822111267,8.591156921982584 ) ;
  }

  @Test
  public void test4518() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.519067140585154,-58.95902784547128 ) ;
  }

  @Test
  public void test4519() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5398064413357888,12.888111435019688 ) ;
  }

  @Test
  public void test4520() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5553030542164936,-6.283188375445567 ) ;
  }

  @Test
  public void test4521() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5665792505736795,-88.18379566708359 ) ;
  }

  @Test
  public void test4522() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5668194866354217,50.16935014582867 ) ;
  }

  @Test
  public void test4523() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5692064959979275,-80.11061266653972 ) ;
  }

  @Test
  public void test4524() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963204869775,-1.5707963267948966 ) ;
  }

  @Test
  public void test4525() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.570796326658694,27.170163611369315 ) ;
  }

  @Test
  public void test4526() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948841,82.5677297792061 ) ;
  }

  @Test
  public void test4527() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948912,1.5707963267948968 ) ;
  }

  @Test
  public void test4528() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948948,-1.5707963267948966 ) ;
  }

  @Test
  public void test4529() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948948,-95.45734309715456 ) ;
  }

  @Test
  public void test4530() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948957,-25.89939458729341 ) ;
  }

  @Test
  public void test4531() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948963,67.4895015924827 ) ;
  }

  @Test
  public void test4532() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4533() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test4534() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-102.26518671983258 ) ;
  }

  @Test
  public void test4535() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test4536() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-1.5707963267948957 ) ;
  }

  @Test
  public void test4537() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4538() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4539() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-16.55533516315569 ) ;
  }

  @Test
  public void test4540() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,21.107754892191426 ) ;
  }

  @Test
  public void test4541() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-26.904745379460305 ) ;
  }

  @Test
  public void test4542() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,35.79882034504872 ) ;
  }

  @Test
  public void test4543() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,3.9916412987582692 ) ;
  }

  @Test
  public void test4544() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,42.964309675626005 ) ;
  }

  @Test
  public void test4545() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,4.7123889803964305 ) ;
  }

  @Test
  public void test4546() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-47.13004619255092 ) ;
  }

  @Test
  public void test4547() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,48.26151032826395 ) ;
  }

  @Test
  public void test4548() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,49.481893896567044 ) ;
  }

  @Test
  public void test4549() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,50.59635821544439 ) ;
  }

  @Test
  public void test4550() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-51.7251918691064 ) ;
  }

  @Test
  public void test4551() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,66.98701064161574 ) ;
  }

  @Test
  public void test4552() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-66.99046827508776 ) ;
  }

  @Test
  public void test4553() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,6.9017684230514895 ) ;
  }

  @Test
  public void test4554() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,71.82411682682712 ) ;
  }

  @Test
  public void test4555() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,72.84662588060543 ) ;
  }

  @Test
  public void test4556() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-7.853981754572492 ) ;
  }

  @Test
  public void test4557() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,86.08381603685682 ) ;
  }

  @Test
  public void test4558() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948968,-100.0 ) ;
  }

  @Test
  public void test4559() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-15.818986393781756,56.148561049662504 ) ;
  }

  @Test
  public void test4560() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-21.99525658118413,1.5707963267948966 ) ;
  }

  @Test
  public void test4561() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-2.220446049250313E-16,-8.420010078792545 ) ;
  }

  @Test
  public void test4562() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-2.220446049250313E-16,-89.65912154888834 ) ;
  }

  @Test
  public void test4563() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-22.401403841590735,-61.38674179334937 ) ;
  }

  @Test
  public void test4564() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-23.178706048964592,-15.894096871348566 ) ;
  }

  @Test
  public void test4565() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-3.141600282991246,77.24173073024599 ) ;
  }

  @Test
  public void test4566() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,3.141624966243152,-31.456096356201396 ) ;
  }

  @Test
  public void test4567() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-3.2311742677852644E-27,-53.715236528470456 ) ;
  }

  @Test
  public void test4568() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-3.2574163054654437,-42.89700753811642 ) ;
  }

  @Test
  public void test4569() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-3.434290859342525,181.14576566882585 ) ;
  }

  @Test
  public void test4570() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-34.890149656671895,-75.72781612905324 ) ;
  }

  @Test
  public void test4571() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-3.5454329838614513,266.56783861982296 ) ;
  }

  @Test
  public void test4572() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-35.48441150892117,27.732177104443473 ) ;
  }

  @Test
  public void test4573() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-36.04838069974284,0.0 ) ;
  }

  @Test
  public void test4574() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,3.814520137354276E-18,44.077140603356355 ) ;
  }

  @Test
  public void test4575() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-3.8570662248602363,-60.12672775142566 ) ;
  }

  @Test
  public void test4576() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-3.9721811898759013E-16,-0.1056796963829291 ) ;
  }

  @Test
  public void test4577() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-41.421451075911385,0.0 ) ;
  }

  @Test
  public void test4578() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-42.052302198578516,1.5707963267949019 ) ;
  }

  @Test
  public void test4579() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-42.13918463620049,-8.303440267823213 ) ;
  }

  @Test
  public void test4580() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-42.287714865343325,1.5707963267951708 ) ;
  }

  @Test
  public void test4581() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-47.63244974462536,-66.97167401381486 ) ;
  }

  @Test
  public void test4582() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-48.3488600962373,0.0 ) ;
  }

  @Test
  public void test4583() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-53.579714217892935,-86.74073044632988 ) ;
  }

  @Test
  public void test4584() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-54.64060553867867,-1.5707963267948966 ) ;
  }

  @Test
  public void test4585() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-54.839767018855774,81.50591029438145 ) ;
  }

  @Test
  public void test4586() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-59.94581135905726,-16.901271461357396 ) ;
  }

  @Test
  public void test4587() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-61.260894981586304,-9.42477671859671 ) ;
  }

  @Test
  public void test4588() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-66.07375859800827,1.5707963267948966 ) ;
  }

  @Test
  public void test4589() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-3.6735826786066452,77.77730717399308 ) ;
  }

  @Test
  public void test4590() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-72.3162834281656,-1.5707963267948948 ) ;
  }

  @Test
  public void test4591() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-72.43031828560342,1.1591269220898192E-69 ) ;
  }

  @Test
  public void test4592() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-72.47282702929444,-27.138825453594716 ) ;
  }

  @Test
  public void test4593() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-72.83179889234508,1.5707963267948966 ) ;
  }

  @Test
  public void test4594() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-73.04800629092207,9.194036960058867 ) ;
  }

  @Test
  public void test4595() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-73.07396149628644,-31.789021588721546 ) ;
  }

  @Test
  public void test4596() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-78.7865266976052,-6.351252389249964 ) ;
  }

  @Test
  public void test4597() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-91.72794536133652,-1.5707963267948966 ) ;
  }

  @Test
  public void test4598() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-92.27193846456457,-0.24743462964912422 ) ;
  }

  @Test
  public void test4599() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-9.566740932798226,-73.98362411046837 ) ;
  }

  @Test
  public void test4600() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-97.74767399344023,-0.10392687826873555 ) ;
  }

  @Test
  public void test4601() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-97.80675412840586,4.7123892647496435 ) ;
  }

  @Test
  public void test4602() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-9.829140544445046,-48.80783866228347 ) ;
  }

  @Test
  public void test4603() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-98.49934642956724,-20.11502653649049 ) ;
  }

  @Test
  public void test4604() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-9.860761315262648E-32,-63.29117675670237 ) ;
  }

  @Test
  public void test4605() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test4606() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.4605345730743737,1.5707963267948963 ) ;
  }

  @Test
  public void test4607() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-48.325747909327035,84.91892184018106 ) ;
  }

  @Test
  public void test4608() {
    coral.tests.JPFBenchmark.benchmark05(-15.79343777530346,86.5557138963079,-54.8202891020148 ) ;
  }

  @Test
  public void test4609() {
    coral.tests.JPFBenchmark.benchmark05(-1.5793650827938261E-176,-0.003717876710976318,-13.874081614191004 ) ;
  }

  @Test
  public void test4610() {
    coral.tests.JPFBenchmark.benchmark05(-1.5928937876671222E-15,-1.2689709186578246E-116,1.5707963267948957 ) ;
  }

  @Test
  public void test4611() {
    coral.tests.JPFBenchmark.benchmark05(15.950668951427602,68.14563779469756,-0.4178162949367987 ) ;
  }

  @Test
  public void test4612() {
    coral.tests.JPFBenchmark.benchmark05(-1.5987098448407036E-4,-1.5707963267948966,-90.06611809028612 ) ;
  }

  @Test
  public void test4613() {
    coral.tests.JPFBenchmark.benchmark05(16.006467939079158,-3.546555440545518,-0.558422335429043 ) ;
  }

  @Test
  public void test4614() {
    coral.tests.JPFBenchmark.benchmark05(16.012183364777897,56.057991895849995,78.6991359090186 ) ;
  }

  @Test
  public void test4615() {
    coral.tests.JPFBenchmark.benchmark05(-1.6155871338926322E-27,-92.27503632368246,-86.05117839780901 ) ;
  }

  @Test
  public void test4616() {
    coral.tests.JPFBenchmark.benchmark05(-1.6242827758820155E-114,-1.5707963267948966,78.23417415573383 ) ;
  }

  @Test
  public void test4617() {
    coral.tests.JPFBenchmark.benchmark05(16.31000812840935,39.72337873021618,10.626451034208273 ) ;
  }

  @Test
  public void test4618() {
    coral.tests.JPFBenchmark.benchmark05(-1.6418147205193505E-288,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4619() {
    coral.tests.JPFBenchmark.benchmark05(1.6543612251060553E-24,-0.6225533334962824,-56.22078845904447 ) ;
  }

  @Test
  public void test4620() {
    coral.tests.JPFBenchmark.benchmark05(-1.6543612251060553E-24,-1.5707963267948966,-44.044806141611645 ) ;
  }

  @Test
  public void test4621() {
    coral.tests.JPFBenchmark.benchmark05(-1.6543612251060553E-24,-35.013404875200486,-51.755654033996834 ) ;
  }

  @Test
  public void test4622() {
    coral.tests.JPFBenchmark.benchmark05(1.6543612251060553E-24,-61.10241327528072,1.5707964209911207 ) ;
  }

  @Test
  public void test4623() {
    coral.tests.JPFBenchmark.benchmark05(1.660052760836918,-172.7907986110971,20.55950100102592 ) ;
  }

  @Test
  public void test4624() {
    coral.tests.JPFBenchmark.benchmark05(1.6609095909402567,-1.5707963267948966,6.314691113980751 ) ;
  }

  @Test
  public void test4625() {
    coral.tests.JPFBenchmark.benchmark05(-1.675448946631927E-15,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4626() {
    coral.tests.JPFBenchmark.benchmark05(-1.685058985092498E-7,-1.5707963267948966,-2.89217861154325E-6 ) ;
  }

  @Test
  public void test4627() {
    coral.tests.JPFBenchmark.benchmark05(-1.6851300399782774E-15,-35.86827056573347,-45.84360164457089 ) ;
  }

  @Test
  public void test4628() {
    coral.tests.JPFBenchmark.benchmark05(-1.687538997430238E-14,-1.5485337529635097,94.57001325497629 ) ;
  }

  @Test
  public void test4629() {
    coral.tests.JPFBenchmark.benchmark05(-1.6881524013542454E-15,-1.2542251691609752,-1.5707963267948923 ) ;
  }

  @Test
  public void test4630() {
    coral.tests.JPFBenchmark.benchmark05(-1.6898496049402388E-14,-0.041901947558755336,70.82246236571922 ) ;
  }

  @Test
  public void test4631() {
    coral.tests.JPFBenchmark.benchmark05(1.6940658945086007E-21,-98.8592048792861,82.25517293987511 ) ;
  }

  @Test
  public void test4632() {
    coral.tests.JPFBenchmark.benchmark05(-16.96599140607927,-16.083195018176255,6.793860018186166 ) ;
  }

  @Test
  public void test4633() {
    coral.tests.JPFBenchmark.benchmark05(-1.6981986621078526E-4,-66.52471663762847,-33.14330593482622 ) ;
  }

  @Test
  public void test4634() {
    coral.tests.JPFBenchmark.benchmark05(1.7025004215450286,-3.1454229400316494,84.62721086652783 ) ;
  }

  @Test
  public void test4635() {
    coral.tests.JPFBenchmark.benchmark05(-1.704957883129772E-254,-1.8216367419652423E-14,79.04131815788818 ) ;
  }

  @Test
  public void test4636() {
    coral.tests.JPFBenchmark.benchmark05(-1.7054596243642952E-4,-3.1435836345235293,12.579090299370668 ) ;
  }

  @Test
  public void test4637() {
    coral.tests.JPFBenchmark.benchmark05(-1.7123510539128149E-195,-54.14145677724126,-1.5707963267948806 ) ;
  }

  @Test
  public void test4638() {
    coral.tests.JPFBenchmark.benchmark05(-1.7308235451574346E-12,-1.5707963267948966,-27.987668262664855 ) ;
  }

  @Test
  public void test4639() {
    coral.tests.JPFBenchmark.benchmark05(1.734723475976807E-18,-1.5707963267948966,8.379457002581361 ) ;
  }

  @Test
  public void test4640() {
    coral.tests.JPFBenchmark.benchmark05(-1.734723475976807E-18,-86.10320569454551,-98.44386605909304 ) ;
  }

  @Test
  public void test4641() {
    coral.tests.JPFBenchmark.benchmark05(-1.7357111818810781E-4,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4642() {
    coral.tests.JPFBenchmark.benchmark05(17.388743449488175,-58.65733557744495,-29.271020817644853 ) ;
  }

  @Test
  public void test4643() {
    coral.tests.JPFBenchmark.benchmark05(1.7461161825368379,-49.302313254618156,-74.84238732034586 ) ;
  }

  @Test
  public void test4644() {
    coral.tests.JPFBenchmark.benchmark05(-1.7589711727735578E-14,-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test4645() {
    coral.tests.JPFBenchmark.benchmark05(-1.7622607070119208E-16,-1.5707963267948966,-1.8234287826888483E-4 ) ;
  }

  @Test
  public void test4646() {
    coral.tests.JPFBenchmark.benchmark05(-1.7684950632171195E-15,-1.5557071792462789,0.0 ) ;
  }

  @Test
  public void test4647() {
    coral.tests.JPFBenchmark.benchmark05(17.757904853691528,-76.53921500056877,-8.094217208091024 ) ;
  }

  @Test
  public void test4648() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-0.015474355574940207,1.5707963267948966 ) ;
  }

  @Test
  public void test4649() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-0.3164310352538857,28.83117087200239 ) ;
  }

  @Test
  public void test4650() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-0.6706235567071275,-82.81041885123928 ) ;
  }

  @Test
  public void test4651() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-0.7287916839116377,-141.05455453985473 ) ;
  }

  @Test
  public void test4652() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-10.072717299386838,-54.301452612110765 ) ;
  }

  @Test
  public void test4653() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.0604083922133234,20.21306332620471 ) ;
  }

  @Test
  public void test4654() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.0808287211887362,-0.22495357121750856 ) ;
  }

  @Test
  public void test4655() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.181271032597953,-14.603311218277543 ) ;
  }

  @Test
  public void test4656() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-122.69751491113999,238.7610384052073 ) ;
  }

  @Test
  public void test4657() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.5533814308043201,45.5509446391056 ) ;
  }

  @Test
  public void test4658() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.5707963267948912,-78.31907253398572 ) ;
  }

  @Test
  public void test4659() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.5707963267948961,8.310731136696177 ) ;
  }

  @Test
  public void test4660() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.5707963267948966,-53.871490243708074 ) ;
  }

  @Test
  public void test4661() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.5707963267948966,-90.79856301672967 ) ;
  }

  @Test
  public void test4662() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-15.966501794112043,-33.56637882372512 ) ;
  }

  @Test
  public void test4663() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.734723475976807E-18,-1.5707963267949125 ) ;
  }

  @Test
  public void test4664() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-185.36146413683622,44.35074046172326 ) ;
  }

  @Test
  public void test4665() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-22.70161853099402,-1.5707963267948966 ) ;
  }

  @Test
  public void test4666() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-35.76644159190152,50.173834759447686 ) ;
  }

  @Test
  public void test4667() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-4.141592653589794,-1.5707963267948966 ) ;
  }

  @Test
  public void test4668() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-47.42684967762666,42.57715951910083 ) ;
  }

  @Test
  public void test4669() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-78.79439642024674,-1.5707963267948948 ) ;
  }

  @Test
  public void test4670() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-78.80799681660913,56.40022801213054 ) ;
  }

  @Test
  public void test4671() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-98.06147276580164,-1.4205096903555123 ) ;
  }

  @Test
  public void test4672() {
    coral.tests.JPFBenchmark.benchmark05(-1.776356839400251E-15,-2.0E-323,0 ) ;
  }

  @Test
  public void test4673() {
    coral.tests.JPFBenchmark.benchmark05(-1.778206999588062E-161,-1.5707963267948966,-39.762580735296666 ) ;
  }

  @Test
  public void test4674() {
    coral.tests.JPFBenchmark.benchmark05(-1.782019881149276E-15,-23.2003899182549,1.0222973217905484E-17 ) ;
  }

  @Test
  public void test4675() {
    coral.tests.JPFBenchmark.benchmark05(-17.882730519174658,85.19310570998985,5.653261136348249 ) ;
  }

  @Test
  public void test4676() {
    coral.tests.JPFBenchmark.benchmark05(17.900363418744192,-53.548421366072915,5.3497551114781885 ) ;
  }

  @Test
  public void test4677() {
    coral.tests.JPFBenchmark.benchmark05(-1.8172897793878808E-8,-1.5707963267948966,-88.08975415145949 ) ;
  }

  @Test
  public void test4678() {
    coral.tests.JPFBenchmark.benchmark05(18.185077893524436,82.09752489368586,43.984018287619676 ) ;
  }

  @Test
  public void test4679() {
    coral.tests.JPFBenchmark.benchmark05(18.294631722738913,-48.139459428296874,-48.22847361575919 ) ;
  }

  @Test
  public void test4680() {
    coral.tests.JPFBenchmark.benchmark05(18.41542159117236,-49.76954080771259,32.998048409845325 ) ;
  }

  @Test
  public void test4681() {
    coral.tests.JPFBenchmark.benchmark05(-18.570982376556884,-51.84807218134673,30.058135776884598 ) ;
  }

  @Test
  public void test4682() {
    coral.tests.JPFBenchmark.benchmark05(-18.58861225840134,-97.50955009255911,-71.88698896668481 ) ;
  }

  @Test
  public void test4683() {
    coral.tests.JPFBenchmark.benchmark05(-1.88079096131566E-37,-4.3368086899420177E-19,48.72593987241326 ) ;
  }

  @Test
  public void test4684() {
    coral.tests.JPFBenchmark.benchmark05(-19.024003826139577,11.242760832675344,32.83618863489403 ) ;
  }

  @Test
  public void test4685() {
    coral.tests.JPFBenchmark.benchmark05(-1.9235099673320534E-4,-0.44842364310391425,7.853981633974487 ) ;
  }

  @Test
  public void test4686() {
    coral.tests.JPFBenchmark.benchmark05(19.322032773121094,-22.701416537054286,90.932362724857 ) ;
  }

  @Test
  public void test4687() {
    coral.tests.JPFBenchmark.benchmark05(-1.9494525989658636E-8,-0.10923944924856388,0.0 ) ;
  }

  @Test
  public void test4688() {
    coral.tests.JPFBenchmark.benchmark05(-1.9547549363343732E-8,-1.5707963267948966,-78.53724915104793 ) ;
  }

  @Test
  public void test4689() {
    coral.tests.JPFBenchmark.benchmark05(-19.675540564259492,47.44180908691794,72.5754648207205 ) ;
  }

  @Test
  public void test4690() {
    coral.tests.JPFBenchmark.benchmark05(-1.9721522630525295E-31,-1.5707963267947522,-33.885124663192926 ) ;
  }

  @Test
  public void test4691() {
    coral.tests.JPFBenchmark.benchmark05(1.9721522630525295E-31,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test4692() {
    coral.tests.JPFBenchmark.benchmark05(1.9721522630525295E-31,-1.5707963267948966,53.65877400202487 ) ;
  }

  @Test
  public void test4693() {
    coral.tests.JPFBenchmark.benchmark05(-19.793234804728456,-56.635010770308725,-65.1149914241447 ) ;
  }

  @Test
  public void test4694() {
    coral.tests.JPFBenchmark.benchmark05(-1.9992278287509535E-15,-54.67036708270048,9.516437208292277 ) ;
  }

  @Test
  public void test4695() {
    coral.tests.JPFBenchmark.benchmark05(-2.000489588103603E-15,-1.5707963267948966,-50.983382855775474 ) ;
  }

  @Test
  public void test4696() {
    coral.tests.JPFBenchmark.benchmark05(-2.0267291388135217E-14,-1.0637357975978323,89.18460229228677 ) ;
  }

  @Test
  public void test4697() {
    coral.tests.JPFBenchmark.benchmark05(-2.0276558293336297E-31,-1.5707963267948966,54.43477665177565 ) ;
  }

  @Test
  public void test4698() {
    coral.tests.JPFBenchmark.benchmark05(2.027744316257113,1.4549047962259607,8.831424763615487 ) ;
  }

  @Test
  public void test4699() {
    coral.tests.JPFBenchmark.benchmark05(20.515434341177354,87.02386430120418,51.976720268097125 ) ;
  }

  @Test
  public void test4700() {
    coral.tests.JPFBenchmark.benchmark05(-2.053682276574053E-15,-1.5707963267948948,-16.063880861905872 ) ;
  }

  @Test
  public void test4701() {
    coral.tests.JPFBenchmark.benchmark05(-2.0602977233280484,-54.89294030987302,89.40009560917076 ) ;
  }

  @Test
  public void test4702() {
    coral.tests.JPFBenchmark.benchmark05(20.650757838692996,-46.84774613284945,-22.506049928210857 ) ;
  }

  @Test
  public void test4703() {
    coral.tests.JPFBenchmark.benchmark05(20.771465557106254,57.984480271226545,-1.0287117103274142 ) ;
  }

  @Test
  public void test4704() {
    coral.tests.JPFBenchmark.benchmark05(20.825587225873775,73.47140718102327,-31.717884189861195 ) ;
  }

  @Test
  public void test4705() {
    coral.tests.JPFBenchmark.benchmark05(-2.086787005802712E-14,-1.5707963267948966,-76.7424947995992 ) ;
  }

  @Test
  public void test4706() {
    coral.tests.JPFBenchmark.benchmark05(21.02878925164275,49.06338057118262,-45.03348746927169 ) ;
  }

  @Test
  public void test4707() {
    coral.tests.JPFBenchmark.benchmark05(-2.1175823681357508E-22,-1.5707963267948966,1.570796326794898 ) ;
  }

  @Test
  public void test4708() {
    coral.tests.JPFBenchmark.benchmark05(-2.1263993873812067E-15,-60.72491339659555,1.5707963267948974 ) ;
  }

  @Test
  public void test4709() {
    coral.tests.JPFBenchmark.benchmark05(-2.135878865075668E-16,-1.5707963267948966,100.52732838347882 ) ;
  }

  @Test
  public void test4710() {
    coral.tests.JPFBenchmark.benchmark05(-2.1404388173910186E-196,-73.02483135834659,2.3850807710288273 ) ;
  }

  @Test
  public void test4711() {
    coral.tests.JPFBenchmark.benchmark05(21.480719250562146,38.67596555866834,75.05511306228186 ) ;
  }

  @Test
  public void test4712() {
    coral.tests.JPFBenchmark.benchmark05(21.552750500371303,-43.5536315293874,17.82678464732605 ) ;
  }

  @Test
  public void test4713() {
    coral.tests.JPFBenchmark.benchmark05(-21.647808150303007,-3.2165073964441433,-46.30422958521849 ) ;
  }

  @Test
  public void test4714() {
    coral.tests.JPFBenchmark.benchmark05(2.1684043449710089E-19,-1.5707963267948966,-1.2200014202427902 ) ;
  }

  @Test
  public void test4715() {
    coral.tests.JPFBenchmark.benchmark05(-2.1684043449710089E-19,-1.5707963267948966,-12.566860576889443 ) ;
  }

  @Test
  public void test4716() {
    coral.tests.JPFBenchmark.benchmark05(-2.1684043449710089E-19,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4717() {
    coral.tests.JPFBenchmark.benchmark05(-2.1684043449710089E-19,-66.82190911143893,91.9628138001548 ) ;
  }

  @Test
  public void test4718() {
    coral.tests.JPFBenchmark.benchmark05(21.89477453502859,87.77714765968807,35.653590513558555 ) ;
  }

  @Test
  public void test4719() {
    coral.tests.JPFBenchmark.benchmark05(-2.191211692211337E-15,-1.5707963267948966,38.255894163836416 ) ;
  }

  @Test
  public void test4720() {
    coral.tests.JPFBenchmark.benchmark05(-2.191809349008403E-193,-35.57185463644378,59.9179694910365 ) ;
  }

  @Test
  public void test4721() {
    coral.tests.JPFBenchmark.benchmark05(22.00322474756851,84.31439764520604,78.75016539012509 ) ;
  }

  @Test
  public void test4722() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,0.0,0 ) ;
  }

  @Test
  public void test4723() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-0.013609004560515347,58.5090596467261 ) ;
  }

  @Test
  public void test4724() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-0.01789786239500015,5.1415926539882575 ) ;
  }

  @Test
  public void test4725() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-0.061675815700168446,-42.580411578593775 ) ;
  }

  @Test
  public void test4726() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-0.0691261488885726,47.839534628622786 ) ;
  }

  @Test
  public void test4727() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-10.266506791559298,-43.7914957469612 ) ;
  }

  @Test
  public void test4728() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.2864249111531858,-90.60646185841762 ) ;
  }

  @Test
  public void test4729() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.426059191153274,-84.51442638302083 ) ;
  }

  @Test
  public void test4730() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.4848976588129579,-21.75008373005312 ) ;
  }

  @Test
  public void test4731() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.570730174291548,-98.63526742418946 ) ;
  }

  @Test
  public void test4732() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267941076,50.84765773517398 ) ;
  }

  @Test
  public void test4733() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948948,-0.9355200258795884 ) ;
  }

  @Test
  public void test4734() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948963,-8.853981643464062 ) ;
  }

  @Test
  public void test4735() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948966,1.4277518141066738 ) ;
  }

  @Test
  public void test4736() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948966,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test4737() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948966,72.25666155014338 ) ;
  }

  @Test
  public void test4738() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948966,-84.76766559471929 ) ;
  }

  @Test
  public void test4739() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-15.946925680111956,0.0 ) ;
  }

  @Test
  public void test4740() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,2.7755575615628914E-17,0.0 ) ;
  }

  @Test
  public void test4741() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,3.1420809348455014,0.0 ) ;
  }

  @Test
  public void test4742() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-3.1661780254308245,-100.0 ) ;
  }

  @Test
  public void test4743() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-34.87151192666836,-133.746842529766 ) ;
  }

  @Test
  public void test4744() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-3.8946150276177907,92.64792156379275 ) ;
  }

  @Test
  public void test4745() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,4.141592653597793,-69.51606020697845 ) ;
  }

  @Test
  public void test4746() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-66.42067464088815,2.2727446619434195 ) ;
  }

  @Test
  public void test4747() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-98.54353110587395,-21.841018654972927 ) ;
  }

  @Test
  public void test4748() {
    coral.tests.JPFBenchmark.benchmark05(-22.419044462979826,-39.14303619827757,-84.29262864680777 ) ;
  }

  @Test
  public void test4749() {
    coral.tests.JPFBenchmark.benchmark05(-22.442356678844618,96.20891135059671,25.775999010768885 ) ;
  }

  @Test
  public void test4750() {
    coral.tests.JPFBenchmark.benchmark05(-2.2541451703578456E-131,-98.49105890644914,-56.11396550380373 ) ;
  }

  @Test
  public void test4751() {
    coral.tests.JPFBenchmark.benchmark05(-2.2652909610917825E-19,-1.5660010304153706,1.5707963267948966 ) ;
  }

  @Test
  public void test4752() {
    coral.tests.JPFBenchmark.benchmark05(22.687733949693836,-43.09396119528712,-38.42057922382005 ) ;
  }

  @Test
  public void test4753() {
    coral.tests.JPFBenchmark.benchmark05(22.80612926880397,64.82638019027999,-74.6294828578397 ) ;
  }

  @Test
  public void test4754() {
    coral.tests.JPFBenchmark.benchmark05(-23.007869206037284,58.63828461567567,11.903001533751961 ) ;
  }

  @Test
  public void test4755() {
    coral.tests.JPFBenchmark.benchmark05(-2.3115999519981187,0,0 ) ;
  }

  @Test
  public void test4756() {
    coral.tests.JPFBenchmark.benchmark05(-23.27348687636959,30.674780565968604,-14.031752757516955 ) ;
  }

  @Test
  public void test4757() {
    coral.tests.JPFBenchmark.benchmark05(23.281499349696475,94.47050700088289,-93.96944883603 ) ;
  }

  @Test
  public void test4758() {
    coral.tests.JPFBenchmark.benchmark05(-23.42707951942222,-5.337181017811687,-97.89115006108366 ) ;
  }

  @Test
  public void test4759() {
    coral.tests.JPFBenchmark.benchmark05(-2.3466979645393266E-15,-0.16752823832669403,0.7256860004781346 ) ;
  }

  @Test
  public void test4760() {
    coral.tests.JPFBenchmark.benchmark05(-2.349574774547097E-15,-1.7763568394002505E-15,0.10606406392277812 ) ;
  }

  @Test
  public void test4761() {
    coral.tests.JPFBenchmark.benchmark05(23.55600691830884,51.67689103619725,53.756670515199346 ) ;
  }

  @Test
  public void test4762() {
    coral.tests.JPFBenchmark.benchmark05(-2.3640218029878922E-6,-1.5707952106206349,-9.129966070513833E-5 ) ;
  }

  @Test
  public void test4763() {
    coral.tests.JPFBenchmark.benchmark05(-23.804337079109757,-38.80785615614779,-30.266516070813694 ) ;
  }

  @Test
  public void test4764() {
    coral.tests.JPFBenchmark.benchmark05(-23.880481754898966,-26.781713232787197,-85.51993018190657 ) ;
  }

  @Test
  public void test4765() {
    coral.tests.JPFBenchmark.benchmark05(23.887975231708396,54.55293502217489,-45.53553308094613 ) ;
  }

  @Test
  public void test4766() {
    coral.tests.JPFBenchmark.benchmark05(24.003914065828823,81.75637352396711,-24.055096584361067 ) ;
  }

  @Test
  public void test4767() {
    coral.tests.JPFBenchmark.benchmark05(-2.40248911666162E-24,-1.5707963267948966,4.712389223626895 ) ;
  }

  @Test
  public void test4768() {
    coral.tests.JPFBenchmark.benchmark05(-2.4074124304840448E-35,-1.5707963267948966,40.84071975547745 ) ;
  }

  @Test
  public void test4769() {
    coral.tests.JPFBenchmark.benchmark05(24.1078105739454,48.87587940566789,47.5396347654154 ) ;
  }

  @Test
  public void test4770() {
    coral.tests.JPFBenchmark.benchmark05(-24.152653879572966,0,0 ) ;
  }

  @Test
  public void test4771() {
    coral.tests.JPFBenchmark.benchmark05(2.4309550384491057,-92.20091880454471,-97.74468147833558 ) ;
  }

  @Test
  public void test4772() {
    coral.tests.JPFBenchmark.benchmark05(2.4576991484344126,-1.5707963267948966,78.27440830920801 ) ;
  }

  @Test
  public void test4773() {
    coral.tests.JPFBenchmark.benchmark05(-2.465190328815662E-32,-1.0578865894583058,-1.5707963267948966 ) ;
  }

  @Test
  public void test4774() {
    coral.tests.JPFBenchmark.benchmark05(-2.4677579418653533E-178,-1.440667088445499,83.48405769294862 ) ;
  }

  @Test
  public void test4775() {
    coral.tests.JPFBenchmark.benchmark05(2.491345535913142,-2.220446049250313E-16,-19.38163051291086 ) ;
  }

  @Test
  public void test4776() {
    coral.tests.JPFBenchmark.benchmark05(-2.492243062154831E-16,-67.43588448840632,3.469446951953614E-18 ) ;
  }

  @Test
  public void test4777() {
    coral.tests.JPFBenchmark.benchmark05(-24.93834698084754,73.43707540602423,37.7026026265826 ) ;
  }

  @Test
  public void test4778() {
    coral.tests.JPFBenchmark.benchmark05(2.497988016824585,-1.5079849532023117,0.0 ) ;
  }

  @Test
  public void test4779() {
    coral.tests.JPFBenchmark.benchmark05(-2.5026038689788762E-147,-1.338702565400926,15.527002419938363 ) ;
  }

  @Test
  public void test4780() {
    coral.tests.JPFBenchmark.benchmark05(-2.5026038689788762E-147,-16.135801458376317,41.542695308059386 ) ;
  }

  @Test
  public void test4781() {
    coral.tests.JPFBenchmark.benchmark05(25.147630496871656,82.26611494615776,91.92511534919939 ) ;
  }

  @Test
  public void test4782() {
    coral.tests.JPFBenchmark.benchmark05(25.187403985321822,19.005681608377856,-4.588944667972655 ) ;
  }

  @Test
  public void test4783() {
    coral.tests.JPFBenchmark.benchmark05(-2.5240310671675385E-6,-42.30141306673965,-2.079561575892688 ) ;
  }

  @Test
  public void test4784() {
    coral.tests.JPFBenchmark.benchmark05(25.27617334991386,70.05518150861519,66.96932165264954 ) ;
  }

  @Test
  public void test4785() {
    coral.tests.JPFBenchmark.benchmark05(2.5422819705485202,-1.3716623394008187,1.5707963267948966 ) ;
  }

  @Test
  public void test4786() {
    coral.tests.JPFBenchmark.benchmark05(-2.5428029955970065E-16,-0.49403176923588854,0.0 ) ;
  }

  @Test
  public void test4787() {
    coral.tests.JPFBenchmark.benchmark05(2.5485809079025468,-7.127295675859506E-4,-26.638331262271436 ) ;
  }

  @Test
  public void test4788() {
    coral.tests.JPFBenchmark.benchmark05(25.509801933496703,-97.56347201964736,88.49148788356447 ) ;
  }

  @Test
  public void test4789() {
    coral.tests.JPFBenchmark.benchmark05(-2.5609496710892677E-8,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4790() {
    coral.tests.JPFBenchmark.benchmark05(2.564475140920171,-1.5587181589252863,-42.84185641894399 ) ;
  }

  @Test
  public void test4791() {
    coral.tests.JPFBenchmark.benchmark05(2.577262911890583,-1.5707963267949054,-119.99400902088428 ) ;
  }

  @Test
  public void test4792() {
    coral.tests.JPFBenchmark.benchmark05(25.797519895522683,-50.35775387889334,67.7064814694647 ) ;
  }

  @Test
  public void test4793() {
    coral.tests.JPFBenchmark.benchmark05(-2.5918193376647894E-4,-66.34330756154532,-7.853981639393935 ) ;
  }

  @Test
  public void test4794() {
    coral.tests.JPFBenchmark.benchmark05(-2.624862374245704E-5,-67.5418908992751,-1.5707963267948966 ) ;
  }

  @Test
  public void test4795() {
    coral.tests.JPFBenchmark.benchmark05(-2.63122546582062E-14,-1.5707963267948966,-31.415926535897935 ) ;
  }

  @Test
  public void test4796() {
    coral.tests.JPFBenchmark.benchmark05(-2642.198468640887,0,0 ) ;
  }

  @Test
  public void test4797() {
    coral.tests.JPFBenchmark.benchmark05(-26.424306944109887,85.86911738592059,-89.02260251948344 ) ;
  }

  @Test
  public void test4798() {
    coral.tests.JPFBenchmark.benchmark05(2.6469779601696886E-23,-0.16279042927623227,1.0451712005026421 ) ;
  }

  @Test
  public void test4799() {
    coral.tests.JPFBenchmark.benchmark05(-2.6469779601696886E-23,-1.5707963267948966,39.26960523708835 ) ;
  }

  @Test
  public void test4800() {
    coral.tests.JPFBenchmark.benchmark05(2.6469779601696886E-23,-4.0082960507918814,-30.866559241896894 ) ;
  }

  @Test
  public void test4801() {
    coral.tests.JPFBenchmark.benchmark05(-2648.3113328440154,0,0 ) ;
  }

  @Test
  public void test4802() {
    coral.tests.JPFBenchmark.benchmark05(-26.565698231731844,-84.5715892675025,-24.800705517039006 ) ;
  }

  @Test
  public void test4803() {
    coral.tests.JPFBenchmark.benchmark05(-2.6737271692023313E-15,-1.5707963267948957,3.161684082026703 ) ;
  }

  @Test
  public void test4804() {
    coral.tests.JPFBenchmark.benchmark05(2.710505431213761E-20,-0.4026792466120567,-71.49668810623255 ) ;
  }

  @Test
  public void test4805() {
    coral.tests.JPFBenchmark.benchmark05(-2.710505431213761E-20,-1.5707963267948966,97.3894042938107 ) ;
  }

  @Test
  public void test4806() {
    coral.tests.JPFBenchmark.benchmark05(-2.710505431213761E-20,-17.278759594563734,-1.5707963267948966 ) ;
  }

  @Test
  public void test4807() {
    coral.tests.JPFBenchmark.benchmark05(-2.710505431213761E-20,-5.551115123125783E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test4808() {
    coral.tests.JPFBenchmark.benchmark05(-2.71824828918119,6.05988127717994,92.37340284192038 ) ;
  }

  @Test
  public void test4809() {
    coral.tests.JPFBenchmark.benchmark05(-2.7220530032207743E-15,-78.75651209393119,31.564729597896722 ) ;
  }

  @Test
  public void test4810() {
    coral.tests.JPFBenchmark.benchmark05(27.342064617100135,6.30475518131388,48.88629541335675 ) ;
  }

  @Test
  public void test4811() {
    coral.tests.JPFBenchmark.benchmark05(2.747206274620666,-99.48754068784437,-37.366938133921046 ) ;
  }

  @Test
  public void test4812() {
    coral.tests.JPFBenchmark.benchmark05(-2.7492176798518485E-15,-4.157944273548509,-1.5707963267948966 ) ;
  }

  @Test
  public void test4813() {
    coral.tests.JPFBenchmark.benchmark05(-2.7495218376260076E-17,-1.547419661321811,-10.83414760649562 ) ;
  }

  @Test
  public void test4814() {
    coral.tests.JPFBenchmark.benchmark05(2.7514738577634676,-1.034878520508302,-90.19087741512169 ) ;
  }

  @Test
  public void test4815() {
    coral.tests.JPFBenchmark.benchmark05(27.536316157123593,57.115519034142324,-28.382348970355807 ) ;
  }

  @Test
  public void test4816() {
    coral.tests.JPFBenchmark.benchmark05(-2.7605118377313635E-19,-1.5707963267948966,-30.22835406708676 ) ;
  }

  @Test
  public void test4817() {
    coral.tests.JPFBenchmark.benchmark05(-2.7755575615628914E-17,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4818() {
    coral.tests.JPFBenchmark.benchmark05(-2.7755575615628914E-17,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4819() {
    coral.tests.JPFBenchmark.benchmark05(-2.7755575615628914E-17,-1.5707963267948966,72.25663104387687 ) ;
  }

  @Test
  public void test4820() {
    coral.tests.JPFBenchmark.benchmark05(2.7755575615628914E-17,-1.5707963267948966,-78.42338036362919 ) ;
  }

  @Test
  public void test4821() {
    coral.tests.JPFBenchmark.benchmark05(-2.7755575615628914E-17,-66.51608444151069,3.469446951953614E-18 ) ;
  }

  @Test
  public void test4822() {
    coral.tests.JPFBenchmark.benchmark05(27.81704587442782,-13.345064491114414,-64.80210337850542 ) ;
  }

  @Test
  public void test4823() {
    coral.tests.JPFBenchmark.benchmark05(-2.7870953705636836E-15,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4824() {
    coral.tests.JPFBenchmark.benchmark05(-28.470170852210416,-26.129606039090987,-35.66663110614017 ) ;
  }

  @Test
  public void test4825() {
    coral.tests.JPFBenchmark.benchmark05(28.54497734471525,49.475031132820135,-27.647321354490842 ) ;
  }

  @Test
  public void test4826() {
    coral.tests.JPFBenchmark.benchmark05(-28.70042166469571,-28.97983809469207,-54.53516256512996 ) ;
  }

  @Test
  public void test4827() {
    coral.tests.JPFBenchmark.benchmark05(-2.8704837273947912E-5,-1.5707963267948948,-50.26571464646467 ) ;
  }

  @Test
  public void test4828() {
    coral.tests.JPFBenchmark.benchmark05(29.013520355301893,7.529356771316344,-26.603604307959273 ) ;
  }

  @Test
  public void test4829() {
    coral.tests.JPFBenchmark.benchmark05(-2.902563894710766E-15,-1.5707963267948966,0.0878694048997094 ) ;
  }

  @Test
  public void test4830() {
    coral.tests.JPFBenchmark.benchmark05(29.339181675748847,12.711217156354152,26.506199616023764 ) ;
  }

  @Test
  public void test4831() {
    coral.tests.JPFBenchmark.benchmark05(29.370372514466936,49.0749491062426,70.93346494512537 ) ;
  }

  @Test
  public void test4832() {
    coral.tests.JPFBenchmark.benchmark05(-29.47964492715404,-53.316214226291756,-17.121023891888683 ) ;
  }

  @Test
  public void test4833() {
    coral.tests.JPFBenchmark.benchmark05(-2.9483050663330627E-9,-1.5707963267949054,1080.6123596231016 ) ;
  }

  @Test
  public void test4834() {
    coral.tests.JPFBenchmark.benchmark05(-29.659182641894063,93.62406702009608,-40.129001163125366 ) ;
  }

  @Test
  public void test4835() {
    coral.tests.JPFBenchmark.benchmark05(2.9669193011252903,-1.5707963267947598,173.99299748765043 ) ;
  }

  @Test
  public void test4836() {
    coral.tests.JPFBenchmark.benchmark05(-2.967364920549937E-67,-0.015669646064803183,88.19723802031768 ) ;
  }

  @Test
  public void test4837() {
    coral.tests.JPFBenchmark.benchmark05(-2.9711450427223355E-16,-1.5707963267948966,-13.153866740856685 ) ;
  }

  @Test
  public void test4838() {
    coral.tests.JPFBenchmark.benchmark05(-29.86190739681831,-35.34055503370206,-3.410504373278627 ) ;
  }

  @Test
  public void test4839() {
    coral.tests.JPFBenchmark.benchmark05(29.89643045208578,-32.528237190791856,-6.3795977882107735 ) ;
  }

  @Test
  public void test4840() {
    coral.tests.JPFBenchmark.benchmark05(29.95955662753539,-24.84199385796964,13.551379443238048 ) ;
  }

  @Test
  public void test4841() {
    coral.tests.JPFBenchmark.benchmark05(-30.014613086766516,31.827364436527205,46.7910393187143 ) ;
  }

  @Test
  public void test4842() {
    coral.tests.JPFBenchmark.benchmark05(-30.017052542920027,-32.35373704683995,-23.455142946894767 ) ;
  }

  @Test
  public void test4843() {
    coral.tests.JPFBenchmark.benchmark05(-3.009265538105056E-36,-1.5707963267948966,6.283185266438353 ) ;
  }

  @Test
  public void test4844() {
    coral.tests.JPFBenchmark.benchmark05(30.44781873385719,51.392256479963606,-64.52615834848088 ) ;
  }

  @Test
  public void test4845() {
    coral.tests.JPFBenchmark.benchmark05(-30.537285655858398,-63.826643438634264,90.45744733675997 ) ;
  }

  @Test
  public void test4846() {
    coral.tests.JPFBenchmark.benchmark05(-30.578389224326074,-66.85850961451452,65.35708862115027 ) ;
  }

  @Test
  public void test4847() {
    coral.tests.JPFBenchmark.benchmark05(-30.590785330010135,47.51716345206157,38.45522254513699 ) ;
  }

  @Test
  public void test4848() {
    coral.tests.JPFBenchmark.benchmark05(3.0737755648647496,-78.67192923681515,1.1393810194650835 ) ;
  }

  @Test
  public void test4849() {
    coral.tests.JPFBenchmark.benchmark05(-30.754470682829037,-4.853963327951206,-78.13962138443682 ) ;
  }

  @Test
  public void test4850() {
    coral.tests.JPFBenchmark.benchmark05(3.0822587750000223,-1.5707963267948966,-1.5707963267949054 ) ;
  }

  @Test
  public void test4851() {
    coral.tests.JPFBenchmark.benchmark05(-3.0846974273316917E-179,-1.5707963267948966,-9.697635830070794 ) ;
  }

  @Test
  public void test4852() {
    coral.tests.JPFBenchmark.benchmark05(-31.026627345899314,-30.327993404054382,7.121672942492353 ) ;
  }

  @Test
  public void test4853() {
    coral.tests.JPFBenchmark.benchmark05(-31.163230124465002,-90.76626312693162,-46.575530735410965 ) ;
  }

  @Test
  public void test4854() {
    coral.tests.JPFBenchmark.benchmark05(-31.185884301714452,-95.10688243148522,32.052198721327215 ) ;
  }

  @Test
  public void test4855() {
    coral.tests.JPFBenchmark.benchmark05(31.426367501572514,96.58691650714567,89.2308987495087 ) ;
  }

  @Test
  public void test4856() {
    coral.tests.JPFBenchmark.benchmark05(-3.1587301655876523E-176,-1.5707963267948966,98.15315375555511 ) ;
  }

  @Test
  public void test4857() {
    coral.tests.JPFBenchmark.benchmark05(-3.1699128717324054E-15,-1.0864709463880722,-1.5707963267948966 ) ;
  }

  @Test
  public void test4858() {
    coral.tests.JPFBenchmark.benchmark05(32.17241418811216,14.677277648199322,60.24863590562691 ) ;
  }

  @Test
  public void test4859() {
    coral.tests.JPFBenchmark.benchmark05(3.2192646755527643,-1.5707963267948966,4.5272183851043035 ) ;
  }

  @Test
  public void test4860() {
    coral.tests.JPFBenchmark.benchmark05(-32.32279572764287,-63.190625553263004,30.69169292130732 ) ;
  }

  @Test
  public void test4861() {
    coral.tests.JPFBenchmark.benchmark05(-3.2359739031057044E-4,-1.2125162587942524,22.23448517556966 ) ;
  }

  @Test
  public void test4862() {
    coral.tests.JPFBenchmark.benchmark05(-3.2381547210793596E-15,-98.55439553888343,-3.633874571040411 ) ;
  }

  @Test
  public void test4863() {
    coral.tests.JPFBenchmark.benchmark05(-32.406969088961475,-34.72594122099247,97.9218369510177 ) ;
  }

  @Test
  public void test4864() {
    coral.tests.JPFBenchmark.benchmark05(32.47026326836436,24.26396122531105,-39.15360473122291 ) ;
  }

  @Test
  public void test4865() {
    coral.tests.JPFBenchmark.benchmark05(-3.248565551764031E-114,-79.14596372448142,-1.5707963267948966 ) ;
  }

  @Test
  public void test4866() {
    coral.tests.JPFBenchmark.benchmark05(32.59904285148994,19.48358691262537,20.95158315973964 ) ;
  }

  @Test
  public void test4867() {
    coral.tests.JPFBenchmark.benchmark05(32.66307081427135,-81.89120436210406,-51.682008805558425 ) ;
  }

  @Test
  public void test4868() {
    coral.tests.JPFBenchmark.benchmark05(-32.74943171443414,-14.212481359070878,-42.70888828476238 ) ;
  }

  @Test
  public void test4869() {
    coral.tests.JPFBenchmark.benchmark05(32.75803670832792,4.658625104310914,-87.74097543586261 ) ;
  }

  @Test
  public void test4870() {
    coral.tests.JPFBenchmark.benchmark05(32.895238354136865,-36.18319165794548,-31.617785950022153 ) ;
  }

  @Test
  public void test4871() {
    coral.tests.JPFBenchmark.benchmark05(-33.05123097694292,0,0 ) ;
  }

  @Test
  public void test4872() {
    coral.tests.JPFBenchmark.benchmark05(-33.073338591431494,-6.877512312311396,76.79403352079152 ) ;
  }

  @Test
  public void test4873() {
    coral.tests.JPFBenchmark.benchmark05(-33.137622705770895,-89.59862765190283,-18.593806965164333 ) ;
  }

  @Test
  public void test4874() {
    coral.tests.JPFBenchmark.benchmark05(-33.22775993686875,-15.64776235123739,55.09694416046116 ) ;
  }

  @Test
  public void test4875() {
    coral.tests.JPFBenchmark.benchmark05(-3.3299958654878358E-257,-1.2093688019900743,1.5707963267948966 ) ;
  }

  @Test
  public void test4876() {
    coral.tests.JPFBenchmark.benchmark05(3.3347104559181786,-9.487277960769397,-9.371350561841263 ) ;
  }

  @Test
  public void test4877() {
    coral.tests.JPFBenchmark.benchmark05(-3.3450786304697075E-4,-1.5707963267948966,-1.5707963267948952 ) ;
  }

  @Test
  public void test4878() {
    coral.tests.JPFBenchmark.benchmark05(33.678423700245844,77.681085564438,-84.99852135514601 ) ;
  }

  @Test
  public void test4879() {
    coral.tests.JPFBenchmark.benchmark05(33.701386893130746,30.866061098007577,-48.91975407011764 ) ;
  }

  @Test
  public void test4880() {
    coral.tests.JPFBenchmark.benchmark05(-3.380567457074552E-15,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4881() {
    coral.tests.JPFBenchmark.benchmark05(-3.3881317890172014E-21,-0.6580499939710251,31.94815985378628 ) ;
  }

  @Test
  public void test4882() {
    coral.tests.JPFBenchmark.benchmark05(-3.3881317890172014E-21,-1.5707963267948966,1.5707963267948961 ) ;
  }

  @Test
  public void test4883() {
    coral.tests.JPFBenchmark.benchmark05(-3.3881317890172014E-21,-1.5707963267948966,-25.132990409269187 ) ;
  }

  @Test
  public void test4884() {
    coral.tests.JPFBenchmark.benchmark05(-3.3881317890172014E-21,-35.82118778051608,1.5707963267948966 ) ;
  }

  @Test
  public void test4885() {
    coral.tests.JPFBenchmark.benchmark05(-33.98272646787386,-53.96377278154294,7.375958855437332 ) ;
  }

  @Test
  public void test4886() {
    coral.tests.JPFBenchmark.benchmark05(-34.15403869305966,94.57442388163909,-84.07766085912354 ) ;
  }

  @Test
  public void test4887() {
    coral.tests.JPFBenchmark.benchmark05(-3.4247021078256297E-195,-1.0858052184289928,0.0 ) ;
  }

  @Test
  public void test4888() {
    coral.tests.JPFBenchmark.benchmark05(-3.4247021078256297E-195,-1.5707963267948966,-32.78787381595181 ) ;
  }

  @Test
  public void test4889() {
    coral.tests.JPFBenchmark.benchmark05(-34.63208260164852,38.10294686420724,17.045929547197034 ) ;
  }

  @Test
  public void test4890() {
    coral.tests.JPFBenchmark.benchmark05(3.468721173738911,-66.88548908306447,4.174988038428614 ) ;
  }

  @Test
  public void test4891() {
    coral.tests.JPFBenchmark.benchmark05(-3.469446951953614E-18,-0.017647197275286713,72.65983878126565 ) ;
  }

  @Test
  public void test4892() {
    coral.tests.JPFBenchmark.benchmark05(3.469446951953614E-18,-0.6634058091471969,48.99135656744154 ) ;
  }

  @Test
  public void test4893() {
    coral.tests.JPFBenchmark.benchmark05(-3.469446951953614E-18,-1.5707941205384768,106.75536133606056 ) ;
  }

  @Test
  public void test4894() {
    coral.tests.JPFBenchmark.benchmark05(-3.469446951953614E-18,-1.5707963267948966,33.708353788084324 ) ;
  }

  @Test
  public void test4895() {
    coral.tests.JPFBenchmark.benchmark05(-3.469446951953614E-18,-1.5707963267948966,-50.616667105404275 ) ;
  }

  @Test
  public void test4896() {
    coral.tests.JPFBenchmark.benchmark05(-3.469446951953614E-18,-60.006800783168,-35.34509009853336 ) ;
  }

  @Test
  public void test4897() {
    coral.tests.JPFBenchmark.benchmark05(-3.469485920528171E-18,-1.5707963267948966,-15.707963167279694 ) ;
  }

  @Test
  public void test4898() {
    coral.tests.JPFBenchmark.benchmark05(3.4742089363082584,21.360829745864237,72.8302381162699 ) ;
  }

  @Test
  public void test4899() {
    coral.tests.JPFBenchmark.benchmark05(34.80951570331413,72.40940135248394,75.37209297688352 ) ;
  }

  @Test
  public void test4900() {
    coral.tests.JPFBenchmark.benchmark05(-3.484046547936245E-5,-1.5707963267948966,89.57489771842043 ) ;
  }

  @Test
  public void test4901() {
    coral.tests.JPFBenchmark.benchmark05(34.94100681169115,-99.31144171842075,56.47806733427137 ) ;
  }

  @Test
  public void test4902() {
    coral.tests.JPFBenchmark.benchmark05(-35.12468345493147,15.946805201284945,14.301350401479908 ) ;
  }

  @Test
  public void test4903() {
    coral.tests.JPFBenchmark.benchmark05(-35.28962275140903,-35.460190726211025,-11.339479228240634 ) ;
  }

  @Test
  public void test4904() {
    coral.tests.JPFBenchmark.benchmark05(-3.544680084464238E-15,-4.3368086899420177E-19,4.863611426232993 ) ;
  }

  @Test
  public void test4905() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-0.5011771571947918,-161.91924192730534 ) ;
  }

  @Test
  public void test4906() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-0.6076514249082043,-38.18113548078272 ) ;
  }

  @Test
  public void test4907() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.2980811790102136,10.910441906523683 ) ;
  }

  @Test
  public void test4908() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5605543762817617,1356.6328472292334 ) ;
  }

  @Test
  public void test4909() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948855,-59.23322503107277 ) ;
  }

  @Test
  public void test4910() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948948,100.0 ) ;
  }

  @Test
  public void test4911() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948963,24.16727562189469 ) ;
  }

  @Test
  public void test4912() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test4913() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948966,-17.147053002575905 ) ;
  }

  @Test
  public void test4914() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948966,47.946229795591165 ) ;
  }

  @Test
  public void test4915() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948966,-51.527925625383865 ) ;
  }

  @Test
  public void test4916() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948966,-57.621761057637165 ) ;
  }

  @Test
  public void test4917() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948966,-77.00163258519804 ) ;
  }

  @Test
  public void test4918() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948966,80.124004050812 ) ;
  }

  @Test
  public void test4919() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948966,92.66470941768046 ) ;
  }

  @Test
  public void test4920() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948966,-98.16203999040405 ) ;
  }

  @Test
  public void test4921() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-17.10982371782275,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test4922() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-35.13438465457341,-31.427754236278417 ) ;
  }

  @Test
  public void test4923() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-3.552713678800501E-15,1.839295729863355 ) ;
  }

  @Test
  public void test4924() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-3.8316176503773107,18.94121330607924 ) ;
  }

  @Test
  public void test4925() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-3.9461114821921655,2.781367524199979 ) ;
  }

  @Test
  public void test4926() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-42.26973031703607,0.0 ) ;
  }

  @Test
  public void test4927() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-47.32169638077713,2443.913956704592 ) ;
  }

  @Test
  public void test4928() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-53.428248978678184,-84.66755366519949 ) ;
  }

  @Test
  public void test4929() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-60.6187515651464,-53.54623235453006 ) ;
  }

  @Test
  public void test4930() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-7.105427357601002E-15,0.0 ) ;
  }

  @Test
  public void test4931() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-73.29526896978925,-0.05374834236796802 ) ;
  }

  @Test
  public void test4932() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-9.660868192238283,-1.5707963267948912 ) ;
  }

  @Test
  public void test4933() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-97.71489359831953,-18.927218232000122 ) ;
  }

  @Test
  public void test4934() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-98.52915122187545,-89.82052830791126 ) ;
  }

  @Test
  public void test4935() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-98.5346867427004,51.74746261102982 ) ;
  }

  @Test
  public void test4936() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-98.94506464072575,0.0 ) ;
  }

  @Test
  public void test4937() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-9.970063314427895,894.6145619272053 ) ;
  }

  @Test
  public void test4938() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800589E-15,-1.5707963267948966,-98.9624289059897 ) ;
  }

  @Test
  public void test4939() {
    coral.tests.JPFBenchmark.benchmark05(3.608966674596388,93.25584606077652,42.576467053715476 ) ;
  }

  @Test
  public void test4940() {
    coral.tests.JPFBenchmark.benchmark05(-36.27925156734007,32.52106182773008,-88.91886957078825 ) ;
  }

  @Test
  public void test4941() {
    coral.tests.JPFBenchmark.benchmark05(-36.36873032402506,70.96994924425394,-69.86234583340547 ) ;
  }

  @Test
  public void test4942() {
    coral.tests.JPFBenchmark.benchmark05(-36.476704387847626,-23.23852303652329,58.39997380723568 ) ;
  }

  @Test
  public void test4943() {
    coral.tests.JPFBenchmark.benchmark05(-3.649261867596658E-4,-1.5707963267948966,177.4855580805893 ) ;
  }

  @Test
  public void test4944() {
    coral.tests.JPFBenchmark.benchmark05(-36.51458432969583,76.57395080071817,47.156853639417136 ) ;
  }

  @Test
  public void test4945() {
    coral.tests.JPFBenchmark.benchmark05(-3.662082275256906E-14,-1.5707963267948966,-10.163963866226345 ) ;
  }

  @Test
  public void test4946() {
    coral.tests.JPFBenchmark.benchmark05(-36.795945926596055,0.05310713442214876,85.06539980320358 ) ;
  }

  @Test
  public void test4947() {
    coral.tests.JPFBenchmark.benchmark05(-36.807382497352116,37.23452337484031,-89.00661854147802 ) ;
  }

  @Test
  public void test4948() {
    coral.tests.JPFBenchmark.benchmark05(-3.6921947261312216E-7,-0.48515005742449907,-3.142365691593009 ) ;
  }

  @Test
  public void test4949() {
    coral.tests.JPFBenchmark.benchmark05(36.92622213713159,28.138043158033526,-98.11279422108623 ) ;
  }

  @Test
  public void test4950() {
    coral.tests.JPFBenchmark.benchmark05(3.726584068696059,-3.1444381083471806,-4.230835229521716 ) ;
  }

  @Test
  public void test4951() {
    coral.tests.JPFBenchmark.benchmark05(37.79912847858091,-26.325646355905818,-77.31937560332574 ) ;
  }

  @Test
  public void test4952() {
    coral.tests.JPFBenchmark.benchmark05(37.86468770811277,-35.76778340508618,-68.50639784561517 ) ;
  }

  @Test
  public void test4953() {
    coral.tests.JPFBenchmark.benchmark05(-38.01577985308406,-28.877020400524287,-65.35336713010436 ) ;
  }

  @Test
  public void test4954() {
    coral.tests.JPFBenchmark.benchmark05(-3.8021831325903196E-211,-0.8320242693279314,-72.86154857217367 ) ;
  }

  @Test
  public void test4955() {
    coral.tests.JPFBenchmark.benchmark05(38.06575287349233,-82.99521188976968,25.047939435229296 ) ;
  }

  @Test
  public void test4956() {
    coral.tests.JPFBenchmark.benchmark05(38.124740954929564,86.23797975647943,-88.40470154819423 ) ;
  }

  @Test
  public void test4957() {
    coral.tests.JPFBenchmark.benchmark05(-38.25799276695789,50.54290848293323,-63.179281685286995 ) ;
  }

  @Test
  public void test4958() {
    coral.tests.JPFBenchmark.benchmark05(-3.840240010095084E-15,-1.5707963267948966,80.16640622106576 ) ;
  }

  @Test
  public void test4959() {
    coral.tests.JPFBenchmark.benchmark05(-38.45849211220547,35.959546189004726,12.79872624947889 ) ;
  }

  @Test
  public void test4960() {
    coral.tests.JPFBenchmark.benchmark05(-38.52665873537584,17.054413982348365,-76.46730974014908 ) ;
  }

  @Test
  public void test4961() {
    coral.tests.JPFBenchmark.benchmark05(-3.8558717841646146E-180,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4962() {
    coral.tests.JPFBenchmark.benchmark05(-3.883372420846052E-15,9.37368083027235E-18,0.0 ) ;
  }

  @Test
  public void test4963() {
    coral.tests.JPFBenchmark.benchmark05(39.353670438317465,-35.53057825325068,62.1183616506693 ) ;
  }

  @Test
  public void test4964() {
    coral.tests.JPFBenchmark.benchmark05(3.944304526105059E-31,-1.5707963267948966,78.81793722096202 ) ;
  }

  @Test
  public void test4965() {
    coral.tests.JPFBenchmark.benchmark05(-3.965534120805702E-118,-48.13508216814585,38.807511841274746 ) ;
  }

  @Test
  public void test4966() {
    coral.tests.JPFBenchmark.benchmark05(-3.986877980439027E-205,-22.368806965125998,0.0 ) ;
  }

  @Test
  public void test4967() {
    coral.tests.JPFBenchmark.benchmark05(-3.987878225387677E-6,-1.5707951767554942,-4.843005180443329 ) ;
  }

  @Test
  public void test4968() {
    coral.tests.JPFBenchmark.benchmark05(-4.004166190366202E-146,-0.17444403763581917,-1.5707963267948912 ) ;
  }

  @Test
  public void test4969() {
    coral.tests.JPFBenchmark.benchmark05(-40.08178856608995,-24.35956295314294,-12.278812314662076 ) ;
  }

  @Test
  public void test4970() {
    coral.tests.JPFBenchmark.benchmark05(-40.21022853483078,63.42319573183775,-24.06229198614922 ) ;
  }

  @Test
  public void test4971() {
    coral.tests.JPFBenchmark.benchmark05(-4.0389678347315804E-28,-1.5707963267948966,75.37920963895236 ) ;
  }

  @Test
  public void test4972() {
    coral.tests.JPFBenchmark.benchmark05(-40.84102619678755,-95.0990547775234,91.34329355753411 ) ;
  }

  @Test
  public void test4973() {
    coral.tests.JPFBenchmark.benchmark05(-4.0935409343943304E-17,-1.5707963267948966,1.5707963267949054 ) ;
  }

  @Test
  public void test4974() {
    coral.tests.JPFBenchmark.benchmark05(-41.06072487024872,-62.242574925908656,-41.877741988880615 ) ;
  }

  @Test
  public void test4975() {
    coral.tests.JPFBenchmark.benchmark05(41.11672938364691,8.409694334974887,-20.7149477383836 ) ;
  }

  @Test
  public void test4976() {
    coral.tests.JPFBenchmark.benchmark05(41.156989149224756,97.02935572063598,-78.87567225488696 ) ;
  }

  @Test
  public void test4977() {
    coral.tests.JPFBenchmark.benchmark05(-41.19420895142425,-8.242576599650931,28.817829735832163 ) ;
  }

  @Test
  public void test4978() {
    coral.tests.JPFBenchmark.benchmark05(-41.206821702705355,23.92395400303144,-35.86161683396966 ) ;
  }

  @Test
  public void test4979() {
    coral.tests.JPFBenchmark.benchmark05(41.35470075934191,78.42232276357163,88.15614512616082 ) ;
  }

  @Test
  public void test4980() {
    coral.tests.JPFBenchmark.benchmark05(-4.1624948318597947E-258,-1.5707963267948966,-56.49235078857684 ) ;
  }

  @Test
  public void test4981() {
    coral.tests.JPFBenchmark.benchmark05(-41.8333823896561,-51.511066322632715,-86.7144188256622 ) ;
  }

  @Test
  public void test4982() {
    coral.tests.JPFBenchmark.benchmark05(41.84868657637088,-24.296578906828785,-28.297636707298565 ) ;
  }

  @Test
  public void test4983() {
    coral.tests.JPFBenchmark.benchmark05(-41.84890002693851,88.69445418187527,93.71947228649728 ) ;
  }

  @Test
  public void test4984() {
    coral.tests.JPFBenchmark.benchmark05(4.197574156491086,-79.64124449535895,-31.924362019183448 ) ;
  }

  @Test
  public void test4985() {
    coral.tests.JPFBenchmark.benchmark05(-42.10756590189635,-73.96692428017056,-76.1181549770725 ) ;
  }

  @Test
  public void test4986() {
    coral.tests.JPFBenchmark.benchmark05(-4.21673329128924E-16,-1.570795816969227,25.132472720997615 ) ;
  }

  @Test
  public void test4987() {
    coral.tests.JPFBenchmark.benchmark05(4.2351647362715017E-22,-61.18048965570724,-90.33531733061729 ) ;
  }

  @Test
  public void test4988() {
    coral.tests.JPFBenchmark.benchmark05(42.39886365881057,-61.09599931622125,-46.41452577145928 ) ;
  }

  @Test
  public void test4989() {
    coral.tests.JPFBenchmark.benchmark05(-42.501467491812875,-79.59363397650323,59.016100547473116 ) ;
  }

  @Test
  public void test4990() {
    coral.tests.JPFBenchmark.benchmark05(-42.539625745290756,84.06203327270515,41.599979531964095 ) ;
  }

  @Test
  public void test4991() {
    coral.tests.JPFBenchmark.benchmark05(42.635382870889,-23.407016178118184,33.81204613732268 ) ;
  }

  @Test
  public void test4992() {
    coral.tests.JPFBenchmark.benchmark05(-42.71058917657899,-88.98467323251677,84.63158244749755 ) ;
  }

  @Test
  public void test4993() {
    coral.tests.JPFBenchmark.benchmark05(42.74240068693811,-12.726599184848709,7.03602778846826 ) ;
  }

  @Test
  public void test4994() {
    coral.tests.JPFBenchmark.benchmark05(42.9390776775694,51.15571860080931,-11.54098975785314 ) ;
  }

  @Test
  public void test4995() {
    coral.tests.JPFBenchmark.benchmark05(-43.09026854207212,-9.695756660411774,37.83108054551877 ) ;
  }

  @Test
  public void test4996() {
    coral.tests.JPFBenchmark.benchmark05(-4.3368086899420177E-19,-0.7852909186064991,-36.61578089280468 ) ;
  }

  @Test
  public void test4997() {
    coral.tests.JPFBenchmark.benchmark05(-4.3368086899420177E-19,-1.5707963267948966,-36.12831551675712 ) ;
  }

  @Test
  public void test4998() {
    coral.tests.JPFBenchmark.benchmark05(4.3368086899420177E-19,-4.002091178499413,81.76372620716262 ) ;
  }

  @Test
  public void test4999() {
    coral.tests.JPFBenchmark.benchmark05(-43.66518874388963,-0.11166126596076253,-81.56060735331909 ) ;
  }

  @Test
  public void test5000() {
    coral.tests.JPFBenchmark.benchmark05(-4.397459825347909,47.49348472123154,29.55634472289944 ) ;
  }

  @Test
  public void test5001() {
    coral.tests.JPFBenchmark.benchmark05(-4.4086425149558245E-6,-10.568444627351015,-9.96300634215892 ) ;
  }

  @Test
  public void test5002() {
    coral.tests.JPFBenchmark.benchmark05(44.252323468730964,-43.01093985612609,0.5569426341647699 ) ;
  }

  @Test
  public void test5003() {
    coral.tests.JPFBenchmark.benchmark05(44.277752272216816,33.69229127384489,57.43949254010161 ) ;
  }

  @Test
  public void test5004() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-0.73739335217833,14.972725140045826 ) ;
  }

  @Test
  public void test5005() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-0.9073238711526896,-7.853984246128549 ) ;
  }

  @Test
  public void test5006() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-1.3728672936121211,1.5707963267948957 ) ;
  }

  @Test
  public void test5007() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-1.5707963267948948,1.5707963267948326 ) ;
  }

  @Test
  public void test5008() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-1.5707963267948948,87.68739860629606 ) ;
  }
}
