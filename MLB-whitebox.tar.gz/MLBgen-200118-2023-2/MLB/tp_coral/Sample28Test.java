import org.junit.Test;

public class Sample28Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark28(-0.02234633445583256 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark28(-0.05802876190779216 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark28(-0.06974080778469727 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark28(-0.06987538436121099 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark28(-0.08300919931303952 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark28(-0.1642045938429817 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark28(-0.17557302024187038 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark28(-0.195052313736781 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark28(-0.19560095591262439 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark28(-0.21519441851414456 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark28(-0.2658656498979042 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark28(-0.2669661207902436 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark28(-0.2834870501908142 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark28(-0.31842567662725685 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark28(-0.3506511577730578 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark28(-0.3589919820835945 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark28(-0.48337501779724334 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark28(-0.5088418252402676 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark28(-0.5439462410229652 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark28(-0.5462471223993219 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark28(-0.5852173896910671 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark28(-0.6534335525733468 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark28(-0.6892005286316447 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark28(-0.7162465933546969 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark28(-0.737245564087246 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark28(-0.741220108147985 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark28(-0.7532156340863878 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark28(-0.7694976586377464 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark28(-0.7770164242320021 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark28(-0.8342927448522772 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark28(-0.8849885522844545 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark28(-0.9031671441197346 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark28(-0.9843213189196547 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark28(-10.00722246382901 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark28(-10.031836095554226 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark28(-10.034385988199631 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark28(-10.041005582615824 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark28(-10.0955294556923 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark28(-1.020725284539779 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark28(-10.21257630154902 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark28(-10.24896873636196 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark28(-10.260747472007267 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark28(-10.277775470534948 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark28(-10.281691792666734 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark28(-10.286919521155795 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark28(-10.315881363283381 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark28(-10.326171588288432 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark28(-10.348010617096932 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark28(-10.413773180446697 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark28(-10.46461773322271 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark28(-10.495149577648405 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark28(-10.509175680463414 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark28(-10.518658439698854 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark28(-10.524824256543468 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark28(-10.529700480692568 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark28(-10.551322846669223 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark28(-10.556435482061644 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark28(-10.623555489907815 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark28(-10.63630152956631 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark28(-10.647548393115699 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark28(-10.676493446845498 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark28(-10.68280117335918 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark28(-10.700159471735574 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark28(-10.748486144463286 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark28(-10.806893170569111 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark28(-10.839402280497552 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark28(-1.0936186439072912 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark28(-10.937546859421914 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark28(-10.966561681639647 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark28(-11.001951324744724 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark28(-11.008941443673663 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark28(-11.032359605571457 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark28(-11.060576983176588 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark28(-11.082980695575387 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark28(1.1102230246251565E-16 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark28(-11.106686801757675 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark28(-11.114480725319709 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark28(-11.124511223462747 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark28(-11.161317557462993 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark28(-11.16669182614713 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark28(-11.174873555603753 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark28(-11.181861170788338 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark28(-11.194243723004945 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark28(-11.247200812232848 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark28(-11.277615714125488 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark28(-11.280075188363043 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark28(-11.32532764026952 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark28(-11.333575471270933 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark28(-1.133508321463708 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark28(-11.3617546933731 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark28(-11.366902291459908 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark28(-11.372434365009013 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark28(-11.374763938779736 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark28(-11.376231891846956 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark28(-11.415000308411564 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark28(-11.436454677579718 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark28(-11.438942309231194 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark28(-11.4743837404055 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark28(-11.503865467754167 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark28(-11.529992072036464 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark28(-11.530611155073544 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark28(-11.533349345580575 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark28(-11.54573337794362 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark28(-1.1564721116473322 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark28(-11.638424196280098 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark28(-11.65316800050853 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark28(-11.654372423434637 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark28(-11.692718361802278 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark28(-11.711929065545277 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark28(-11.748933523432626 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark28(-11.761821795985355 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark28(-11.789866487036903 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark28(-11.815560811076509 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark28(-1.1888548835877373 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark28(-11.910491393280267 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark28(-11.913024591278742 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark28(-11.940313437770243 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark28(-11.98500617138356 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark28(-12.00676041653199 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark28(-1.205267414926297 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark28(-12.070173627206884 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark28(-12.078591511546492 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark28(-12.142380879621811 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark28(-12.147161198521502 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark28(-12.16055752380798 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark28(-12.16419526795896 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark28(-12.165203225520841 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark28(-12.192685479016887 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark28(-12.207121512078174 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark28(-12.218679338091462 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark28(-12.224545974064753 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark28(-12.242299284017903 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark28(-12.282794408304397 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark28(-12.285191134527025 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark28(-12.331921495181717 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark28(-12.353123117960862 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark28(-12.357716916241586 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark28(-12.361205960703444 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark28(-12.36744954294575 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark28(-12.375090336875715 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark28(-12.38910741798749 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark28(-12.415323107229 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark28(-1.2440643318385298 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark28(-12.44412863496531 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark28(-12.450920486243817 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark28(-12.495808727249852 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark28(-12.50219287589303 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark28(-12.528448139451882 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark28(-12.530853774193247 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark28(-12.599648237950078 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark28(-12.617136262606408 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark28(-12.639396052431252 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark28(-12.677399783334394 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark28(-12.677859203755219 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark28(-12.855611896189131 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark28(-12.955414969945906 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark28(-12.989472295773112 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark28(-13.019172621106677 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark28(-1.3022173187773518 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark28(-13.051098037090398 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark28(-13.063702555714968 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark28(-1.3121397532280383 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark28(-13.126664528922234 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark28(-13.127684332829688 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark28(-13.134896879018527 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark28(-13.14342163999352 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark28(-13.174853530236376 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark28(-13.200256885507727 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark28(-13.290183572008772 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark28(-13.339291004498136 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark28(-13.422384599636842 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark28(-13.43233419046635 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark28(-13.435945870497207 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark28(-13.50582361871244 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark28(-13.524614434396582 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark28(-13.530137148449214 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark28(-13.534668202071813 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark28(-13.540094462007772 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark28(-13.569802459962219 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark28(-13.57719547518515 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark28(-13.579823103907856 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark28(-13.582586979056742 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark28(-13.594877237264626 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark28(-13.65030873832768 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark28(-1.375015067677893 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark28(-13.76436784381599 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark28(-13.766590818607625 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark28(-13.77597783102189 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark28(-13.777930465339239 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark28(-13.813828016483924 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark28(-13.863755867623155 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark28(-13.893975323874841 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark28(-1.3899620120379979 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark28(-13.900769532822395 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark28(-13.923528449924504 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark28(-13.931204321901731 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark28(-13.935468165025028 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark28(-13.945521500941908 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark28(-13.98771165284154 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark28(-14.021940753287893 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark28(-14.036293775853935 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark28(-14.061652751862937 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark28(-14.06472737216491 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark28(-14.073392577543189 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark28(-14.08831953011402 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark28(-1.4101357929145593 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark28(-14.161601803838565 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark28(-14.188770248415892 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark28(-1.4190416141659483 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark28(-14.192635110847803 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark28(-14.19400150624557 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark28(-14.204316821485591 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark28(-14.232223716761155 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark28(-14.238167217917223 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark28(-14.239566735578691 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark28(-14.26381204634562 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark28(-14.31632747282336 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark28(-14.364290587341571 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark28(-14.431228916515181 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark28(-14.441868549782683 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark28(-14.469442259444776 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark28(-14.525174261735074 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark28(-14.525741384796802 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark28(-1.4566643514338722 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark28(-14.576550391917607 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark28(-14.620530127573957 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark28(-14.678896436760127 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark28(-14.731131783717856 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark28(-14.753470686042675 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark28(-14.75494945485731 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark28(-14.776032740487551 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark28(-14.791578266025567 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark28(-14.792504216073581 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark28(-14.824548106403086 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark28(-14.831546996266567 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark28(-14.881205647996197 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark28(-14.895067410415791 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark28(-14.915912109317603 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark28(-15.003412036914995 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark28(-15.01656178614678 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark28(-15.050652731926178 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark28(-15.069665101537112 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark28(-15.076757395894006 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark28(-15.109140994689454 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark28(-15.125968570103396 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark28(-15.191448328395964 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark28(-15.234312256964117 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark28(-15.248334837710601 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark28(-15.273401715254124 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark28(-15.295188920938202 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark28(-15.362217540526714 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark28(-15.404285225424516 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark28(-15.424890616377638 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark28(-15.426618204074671 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark28(-15.470007626278544 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark28(-15.480342541385113 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark28(-15.521115971372026 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark28(-15.532245549945372 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark28(-15.559523548323 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark28(-15.56968738263349 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark28(-15.606862662531839 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark28(-1.5640319145568782 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark28(-15.65578630522424 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark28(-15.665677183239325 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark28(-15.683251349756162 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark28(-1.569703334868521 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark28(-15.706078943211324 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark28(-1.5714506221368794 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark28(-1.5743601849720505 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark28(-15.746685738423906 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark28(-15.74727723048099 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark28(-15.820883133110655 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark28(-1.5856853838316596 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark28(-15.866873410377607 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark28(-15.891131271552311 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark28(-15.90998110338704 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark28(-15.962085199877023 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark28(-15.996350294218175 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark28(-16.110271417354255 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark28(-1.6112192663632356 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark28(-16.18222513325118 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark28(-16.224863943345284 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark28(-16.25646539178564 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark28(-1.6258131504401234 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark28(-16.324544969097744 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark28(-16.32549336062401 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark28(-16.3560609920536 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark28(-16.391463273765524 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark28(-16.398078454701093 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark28(-16.40302396960533 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark28(-1.6407149814793485 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark28(-16.464367737026592 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark28(-16.479007972506594 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark28(-16.490447782107978 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark28(-16.510936880339685 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark28(-16.52189004751807 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark28(-16.529256182278786 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark28(-1.6553173748087886 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark28(-16.553305687889036 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark28(-16.571175473269733 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark28(-16.58446029597964 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark28(-16.5910487111026 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark28(-16.61002432862624 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark28(-16.64019755929172 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark28(-16.642379408917265 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark28(-16.64748538178091 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark28(-16.705476551563066 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark28(-1.6733553710587898 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark28(-16.879399661446 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark28(-16.9136779084986 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark28(-16.92498568602852 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark28(-16.926592752667702 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark28(-16.93055165799879 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark28(-16.93913809943666 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark28(-16.976107562049393 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark28(-16.989479356198544 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark28(-17.00962086497897 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark28(-17.059448884010436 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark28(-17.12955321669429 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark28(-17.1921770183816 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark28(-17.222926206963464 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark28(-17.265527100154898 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark28(-17.29420512978588 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark28(-17.358060580286462 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark28(-17.454822810911423 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark28(-17.47929699393056 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark28(-17.500698025002492 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark28(-17.590548831157562 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark28(-17.603593455937272 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark28(-17.604307599514925 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark28(-17.644741180155293 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark28(-17.648085006264026 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark28(-17.671137087153312 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark28(-17.676675660748998 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark28(-17.704794479444843 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark28(-17.759163816826145 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark28(-17.765017723254587 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark28(-17.791430632659228 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark28(-17.797896903286173 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark28(-17.81158067834386 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark28(-17.820255232478118 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark28(-17.860562629699217 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark28(-17.894842307480445 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark28(-17.998182060980383 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark28(-18.013548782453185 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark28(-18.031398474176342 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark28(-18.05911064468522 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark28(-18.089021994520536 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark28(-18.105786928621526 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark28(-18.13529799992307 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark28(-18.1673684226015 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark28(-18.178203916297477 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark28(-18.19377254227068 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark28(-18.225348539508218 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark28(-18.23827854108346 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark28(-18.238638643815037 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark28(-18.254905054169072 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark28(-18.259904708176848 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark28(-1.827029857524849 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark28(-18.276307586504544 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark28(-18.3209163724879 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark28(-18.33363775006805 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark28(-18.34892492272698 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark28(-18.408156512038573 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark28(-18.42125105101384 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark28(-18.429771527177152 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark28(-18.439350572364205 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark28(-18.46778898194077 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark28(-18.502602310134648 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark28(-18.51387725933759 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark28(-18.521985394834275 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark28(-18.547695645247913 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark28(-18.666896683192263 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark28(-1.8708582021958193 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark28(-18.711161726394337 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark28(-18.72774313089394 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark28(-18.758435658117875 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark28(-18.801642097212962 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark28(-18.80840443246963 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark28(-18.81186126425189 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark28(-18.82721918448169 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark28(-18.840762883522615 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark28(-18.85053868489817 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark28(-18.872799614864476 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark28(-18.899485724401387 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark28(-18.925572693865902 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark28(-19.00894584825204 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark28(-1.9016784171194132 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark28(-19.017132496640542 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark28(-19.038354343623737 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark28(-19.044319547539374 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark28(-19.048846687918797 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark28(-19.080602334205295 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark28(-19.08143898070236 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark28(-19.10629502060746 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark28(-19.125268081472896 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark28(-1.9203061483973585 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark28(-1.92034815478155 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark28(-19.204889877859713 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark28(-19.21933046478432 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark28(-19.226981371530044 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark28(-19.228185377901298 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark28(-19.25484802730844 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark28(-19.276968685385526 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark28(-1.9285959870939138 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark28(-19.31228723449601 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark28(-19.333670209238193 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark28(-1.9400660764997042 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark28(-19.42471000847634 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark28(-19.44309824698722 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark28(-19.479032529722204 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark28(-19.503166696775807 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark28(-19.51453601929734 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark28(-19.538778315643484 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark28(-1.9636863811051626 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark28(-19.74603009353173 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark28(-19.75434325353656 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark28(-19.9195368575446 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark28(-19.953867498166986 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark28(-19.95595676162243 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark28(-19.993135452007493 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark28(-2.003988634388378 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark28(-20.047404148019183 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark28(-20.065606283490254 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark28(-20.08982812835613 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark28(-20.10241365046174 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark28(-20.118512664215828 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark28(-20.28452865277808 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark28(-20.363463082242077 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark28(-20.375294425301178 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark28(-2.048382813039325 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark28(-20.493133006740777 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark28(-20.518708784207206 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark28(-20.520045283163824 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark28(-20.52302359725377 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark28(-20.564000443823687 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark28(-20.602440238115832 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark28(-20.634209496866234 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark28(-20.650715898653743 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark28(-20.657325116706815 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark28(-20.663011265008777 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark28(-20.67858822711554 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark28(-20.69411926152047 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark28(-20.69907854834534 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark28(-20.705146968127423 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark28(-2.073864231193582 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark28(-2.0759964584898114 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark28(-2.0768412522401434 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark28(-20.77879378426435 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark28(-20.787882318632995 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark28(-2.085132537430084 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark28(-20.854424662101707 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark28(-20.871565649001326 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark28(-20.909969492883747 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark28(-2.0978158637398963 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark28(-20.98018469463618 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark28(-20.985784910890786 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark28(-21.00771598267886 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark28(-21.045333036361143 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark28(-21.069384203964916 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark28(-21.078283796930222 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark28(-21.101265935346333 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark28(-21.12321422807581 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark28(-21.204032508782845 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark28(-21.23982332917342 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark28(-21.24788475190455 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark28(-21.24870777061578 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark28(-2.132348508612324 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark28(-21.348477795674242 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark28(-21.42623298863073 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark28(-21.437355991874085 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark28(-21.45856502174894 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark28(-21.48927847333293 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark28(-21.499815138085182 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark28(-21.56529417810937 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark28(-21.574718382784397 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark28(-2.1583079161105587 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark28(-21.58798041508861 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark28(-21.601233183770148 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark28(-21.607324941350555 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark28(-21.62863158304947 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark28(-21.669671033114085 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark28(-21.673416366438943 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark28(-21.71596591175964 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark28(-21.717485402977715 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark28(-21.724721976361778 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark28(-21.734958441924974 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark28(-21.81734060601906 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark28(-21.83521751885648 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark28(-21.921862730345225 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark28(-21.93799772952731 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark28(-2.1954403178053354 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark28(-21.956308238924933 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark28(-2.196838034906264 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark28(-2.2009316486542048 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark28(-22.021843175578454 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark28(-22.033901294536193 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark28(-22.058636350739434 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark28(-22.10220278453987 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark28(-22.14918948444297 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark28(-22.155043206880933 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark28(-22.190790667626487 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark28(-22.210174266127197 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark28(-22.210248185483024 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark28(-22.21907899898588 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark28(-22.235382112660744 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark28(-22.23615394097851 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark28(-22.24332976598093 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark28(-2.225514526466725 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark28(-22.260924298654857 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark28(-22.31114844393798 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark28(-22.344449560949258 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark28(-22.357125066682656 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark28(-22.37428540736562 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark28(-22.39058229171569 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark28(-22.394006427770833 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark28(-22.415105172828035 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark28(-22.435053296528366 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark28(-22.43892087493353 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark28(-22.440771371075414 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark28(-22.455758320106824 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark28(-22.484280574948272 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark28(-22.506760877803373 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark28(-22.52097336841679 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark28(-22.53139752476821 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark28(-22.533151918419918 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark28(-22.548785287482673 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark28(-22.559796409246943 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark28(-22.595933513045367 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark28(-22.60078424687677 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark28(-22.630620255371326 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark28(-22.644235746941604 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark28(-2.267500855111095 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark28(-2.2685171689366115 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark28(-22.68880942287545 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark28(-22.689591363541922 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark28(-22.70361498317139 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark28(-22.731194056548375 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark28(-22.74319544934704 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark28(-22.767471624922635 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark28(-22.781872545061475 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark28(-22.85478820500539 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark28(-22.882407218286644 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark28(-22.88962372236047 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark28(-22.893371496555815 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark28(-22.898426312023588 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark28(-22.90863230111397 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark28(-22.9150826791992 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark28(-22.970948557986404 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark28(-22.97470403237874 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark28(-22.981197589427055 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark28(-23.000632177879794 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark28(-23.100853685860898 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark28(-23.12537418617093 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark28(-23.14040006553215 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark28(-23.14428067214847 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark28(-23.159444484487878 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark28(-23.170246767664437 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark28(-23.200717730005522 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark28(-23.23786049452754 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark28(-23.23861471253241 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark28(-23.238980749052047 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark28(-23.2597301009625 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark28(-23.26517871372411 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark28(-23.281509705119532 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark28(-23.283679718276744 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark28(-23.36212864472516 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark28(-23.47052222310313 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark28(-23.526937934940122 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark28(-23.547774542889613 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark28(-23.583804920098416 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark28(-2.360418060085294 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark28(-23.61438195810861 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark28(-23.62211672710488 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark28(-23.622760064874655 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark28(-23.62861827299261 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark28(-2.366210201635326 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark28(-2.3681837216433195 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark28(-23.698146356546303 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark28(-23.70376234943376 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark28(-23.74702448828809 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark28(-23.757900752400147 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark28(-23.797589588813707 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark28(-23.83028117764951 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark28(-23.838881733962538 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark28(-23.864008288077684 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark28(-23.963752505675615 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark28(-2.3976028576052784 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark28(-23.990394755313645 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark28(-2.4073124057432125 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark28(-24.20178010298646 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark28(-24.203941149514407 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark28(-24.211558685036522 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark28(-24.22972991244545 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark28(-24.276864074775347 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark28(-24.316010197901463 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark28(-24.380984021616698 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark28(-24.381645389327304 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark28(-24.38179549775188 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark28(-24.387190204932935 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark28(-24.40127170887243 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark28(-24.431284414653305 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark28(-24.444343224487227 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark28(-24.457701687211667 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark28(-24.462080760301433 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark28(-24.4893193851848 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark28(-2.4507254863707146 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark28(-2.461676364369495 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark28(-24.62407401720121 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark28(-24.65073828495916 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark28(-24.657455137390016 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark28(-24.6663559763537 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark28(-24.68461517854479 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark28(-24.7080478747516 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark28(-24.710756733653014 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark28(-24.715785609149307 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark28(-24.750619907380255 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark28(-2.475261828464184 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark28(-24.833875156425165 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark28(-24.8342004325784 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark28(-24.842562180084983 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark28(-24.846264505462656 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark28(-24.84879148441692 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark28(-24.88350480008343 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark28(-24.89423211998401 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark28(-24.938351985680242 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark28(-24.94340853602901 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark28(-24.981043073509298 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark28(-2.5058865496630887 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark28(-25.0860319503371 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark28(-25.10009122518673 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark28(-25.11782638656497 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark28(-25.119342405708352 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark28(-25.132983333029358 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark28(-25.199971488776995 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark28(-25.218995555114574 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark28(-25.22686084734444 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark28(-25.239448934866004 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark28(-25.255084741826124 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark28(-25.286321097919682 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark28(-25.288429299952526 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark28(-25.297975132114914 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark28(-25.307698305463504 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark28(-25.310865545966493 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark28(-25.36918649278452 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark28(-25.379532684737313 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark28(-25.4072835302767 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark28(-25.488822952170764 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark28(-25.51233857583202 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark28(-25.541596112262965 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark28(-25.567250565714446 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark28(-25.578282032319308 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark28(-2.5605154061792916 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark28(-25.61417550507265 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark28(-25.616521991785874 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark28(-25.641768362379054 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark28(-25.684305751343643 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark28(-25.69454712849452 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark28(-25.76273293093398 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark28(-25.768719533771005 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark28(-25.786849442585066 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark28(-25.787113818401124 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark28(-25.795664597849168 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark28(-25.87550011677979 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark28(-25.87723839902108 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark28(-25.880227496372427 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark28(-2.5908737416236107 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark28(-25.926501355486025 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark28(-2.59683366514885 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark28(-26.012397860761098 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark28(-26.03410856279811 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark28(-26.084740600777508 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark28(-26.096036038878736 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark28(-26.12246995121093 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark28(-26.17619623578655 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark28(-26.185641297765343 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark28(-26.22907615230328 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark28(-26.2895022438844 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark28(-26.304533035546854 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark28(-26.470201454853196 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark28(-26.4872606814387 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark28(-26.49528811245274 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark28(-26.495364289707084 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark28(-26.513920863780086 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark28(-26.519512466836176 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark28(-26.538362196751734 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark28(-26.578589763058673 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark28(-26.58975616733285 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark28(-26.614776682503845 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark28(-26.617598830474435 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark28(-2.6651460303400683 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark28(-26.65994824679545 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark28(-26.670440416861823 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark28(-26.670965363436054 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark28(-2.6684108972833798 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark28(-26.687356464667914 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark28(-26.6878075492301 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark28(-26.712388479129956 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark28(-26.72620030565018 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark28(-2.6730223150331085 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark28(-26.75292441428256 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark28(-26.79658583842675 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark28(-26.804115759158577 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark28(-26.806758182628187 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark28(-26.885692545127867 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark28(-26.895145101912405 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark28(-26.911060841978028 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark28(-26.980037970616195 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark28(-27.026037646199683 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark28(-27.058265323135757 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark28(-27.08326662729175 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark28(-27.09330645090904 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark28(-27.14607472752928 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark28(-27.15503876613539 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark28(-27.240857330893945 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark28(-27.243137793357008 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark28(-27.245614489216493 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark28(-27.257160058564665 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark28(-27.31179470902778 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark28(-27.3249359319735 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark28(-27.39236070171596 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark28(-27.402872978101954 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark28(-27.40530466921591 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark28(-27.428013995702287 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark28(-27.446388714383602 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark28(-27.462845361535543 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark28(-27.469205365356927 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark28(-27.47894292098721 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark28(-27.47993595849188 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark28(-27.48423299846081 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark28(-27.495326351454793 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark28(-27.50574939699726 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark28(-27.518041082965965 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark28(-27.524884280064896 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark28(-27.534136061770127 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark28(-27.56259483796515 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark28(-2.75810592382291 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark28(-27.583821031572867 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark28(-27.586206905407053 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark28(-2.7593064699232457 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark28(-27.630560101248605 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark28(-27.67518490494922 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark28(-27.679997441261463 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark28(-27.686000807668492 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark28(-27.706406362688682 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark28(-27.729489873433707 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark28(-2.7752729890978145 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark28(-27.821386646414737 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark28(-27.970282592431502 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark28(-27.971517449307328 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark28(-28.05976860695219 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark28(-28.05990888750914 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark28(-28.081721733646248 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark28(-28.10132051495053 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark28(-28.129701122565564 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark28(-28.142015147532334 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark28(-28.203848570056508 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark28(-2.8203851896955427 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark28(-28.22055835477242 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark28(-28.24690578384464 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark28(-28.261794812398747 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark28(-28.265755765525057 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark28(-28.294473671895474 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark28(-28.339461016893353 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark28(-28.36758958271095 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark28(-28.38651976643807 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark28(-28.400892733368607 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark28(-28.423402487215 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark28(-28.50241324326248 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark28(-28.5116275124212 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark28(-28.517026460407436 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark28(-28.5526833136081 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark28(-28.57645826698389 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark28(-28.661288626495264 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark28(-28.71189353266388 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark28(-28.726700411018186 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark28(-28.745457998401733 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark28(-28.74916899442161 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark28(-28.839331807535757 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark28(-28.874831731043372 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark28(-28.917248582544303 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark28(-28.957399893580344 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark28(-28.969589429621422 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark28(-28.99754519371065 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark28(-29.019181325696096 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark28(-29.07614699663563 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark28(-29.094819350955106 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark28(-29.113580166137808 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark28(-29.122560394847923 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark28(-29.17181013585592 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark28(-29.18239141476934 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark28(-29.255127409700222 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark28(-29.300200709354172 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark28(-29.320048959063016 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark28(-29.330067140620102 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark28(-29.334097032120127 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark28(-29.392528037282474 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark28(-29.403606691070692 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark28(-29.45820531055972 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark28(-29.463726053452888 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark28(-29.464812150523898 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark28(-2.9549661591439644 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark28(-29.58824043814478 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark28(-29.59083877431472 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark28(-29.698115054883246 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark28(-29.714602931130102 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark28(-29.7414320573546 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark28(-29.76531156226403 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark28(-29.76560687168812 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark28(-29.79904081983524 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark28(-29.839320076675136 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark28(-29.843035977245734 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark28(-29.858540441612917 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark28(-29.873059909027916 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark28(-29.880034268380285 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark28(-29.9337004214468 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark28(-29.938356874231232 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark28(-29.95096963278783 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark28(-29.951697219155577 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark28(-29.98395421192157 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark28(-30.00147182830544 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark28(-30.016028252673337 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark28(-30.054918119191186 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark28(-30.073997776512556 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark28(-30.145335706791656 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark28(-30.218472346986317 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark28(-30.21894222852947 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark28(-30.22710124478614 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark28(-30.2321708341579 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark28(-30.23454744824714 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark28(-30.235090919434242 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark28(-30.242325884834997 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark28(-30.24571694848362 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark28(-30.250392647443334 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark28(-30.26650855588167 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark28(-30.314767885498767 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark28(-30.3445687728277 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark28(-30.34471815355289 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark28(-30.356704622725346 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark28(-30.366652341469376 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark28(-30.37505508055294 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark28(-30.398201405184636 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark28(-30.450810847616296 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark28(-30.451030904845823 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark28(-30.46764990706245 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark28(-30.48426259052937 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark28(-30.48508577242235 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark28(-3.051252379137111 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark28(-3.056739998646279 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark28(-30.576137945191874 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark28(-30.582503644520003 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark28(-30.601212780272903 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark28(-30.606096620651527 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark28(-3.0607209906694948 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark28(-30.627703094506813 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark28(-3.064093807095688 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark28(-30.69079263429721 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark28(-3.0722290872779183 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark28(-30.73956278795464 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark28(-30.756664615421215 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark28(-30.772605645171325 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark28(-30.82085640800709 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark28(-3.089455393675962 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark28(-30.952465221553126 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark28(-30.953129348653334 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark28(-30.986829801461056 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark28(-30.99796957744077 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark28(-31.001195533279002 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark28(-31.006160073872138 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark28(-31.011239310331632 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark28(-31.02115801089387 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark28(-31.163448656832585 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark28(-31.19338952451109 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark28(-31.204697668439522 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark28(-31.205759696969366 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark28(-3.1218527331223385 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark28(-3.122270008758221 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark28(-31.23842176212959 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark28(-31.25237450175584 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark28(-31.28529536624147 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark28(-3.129393466511459 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark28(-3.133120308913732 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark28(-3.1358216719646634 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark28(-31.42955826378835 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark28(-31.43148471693553 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark28(-31.488413365467324 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark28(-31.49374497606638 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark28(-31.509039937241056 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark28(-31.509575136586875 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark28(-31.54038062665056 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark28(-31.548242782627597 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark28(-31.616968343428127 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark28(-31.659196637628327 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark28(-31.711447810599097 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark28(-31.777210047297473 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark28(-31.806399993418836 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark28(-31.845870275557473 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark28(-31.85366750355672 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark28(-31.907746939677466 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark28(-31.927199709478614 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark28(-31.9433792226165 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark28(-32.0497764275884 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark28(-32.09570655676086 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark28(-32.1015895923947 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark28(-32.11082335486006 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark28(-32.1161078560519 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark28(-32.12398545155477 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark28(-3.2145571659077774 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark28(-32.175625486423925 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark28(-32.19460940865844 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark28(-32.24574306137373 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark28(-32.265346533705184 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark28(-32.27850525152162 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark28(-32.28663166900003 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark28(-32.301711517354576 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark28(-3.23287773086129 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark28(-32.343931177579435 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark28(-32.374843036879824 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark28(-32.44572346431612 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark28(-32.45660213683959 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark28(-32.48492352015455 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark28(-32.50604567481297 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark28(-32.52726141996949 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark28(-32.56199425882542 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark28(-32.57446646692776 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark28(-32.58494919033723 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark28(-32.619646179204054 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark28(-32.80551515378414 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark28(-32.8428790997328 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark28(-32.84934902014369 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark28(-32.91524789168652 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark28(-33.00470563583555 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark28(-33.12214174709129 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark28(-33.16145676751729 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark28(-33.17331905383341 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark28(-33.208334071364405 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark28(-33.233583252071014 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark28(-33.23599804460471 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark28(-33.24830514258237 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark28(-33.26847990961153 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark28(-3.328408184065637 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark28(-33.3265194666257 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark28(-33.33348296482241 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark28(-33.351079318782425 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark28(-33.35905406364532 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark28(-33.38103853331715 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark28(-33.40225117990663 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark28(-33.487643924281855 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark28(-33.52676172185258 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark28(-33.52920427676003 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark28(-33.533488763682556 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark28(-33.53534500877291 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark28(-33.55672245490835 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark28(-3.3637796896666288 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark28(-33.658059324194696 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark28(-33.70474880783088 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark28(-33.7055382555542 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark28(-33.738479622283336 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark28(-33.75755530153907 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark28(-33.77345730167234 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark28(-33.78021161866404 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark28(-33.78900934903477 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark28(-33.801981289221004 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark28(-33.80396589550192 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark28(-33.82723941404035 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark28(-33.84613192296773 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark28(-33.87569030546527 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark28(-3.3924237891062035 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark28(-33.92646276491024 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark28(-3.3985810342314693 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark28(-34.022029785639816 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark28(-34.03646586383513 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark28(-34.03730757742282 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark28(-34.048059682206386 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark28(-34.05991692293895 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark28(-34.10012130757718 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark28(-34.102224266820656 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark28(-34.11399757845459 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark28(-3.4158024545922956 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark28(-3.416326349835572 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark28(-34.2169582858302 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark28(-34.23807941726092 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark28(-3.4244558574659294 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark28(-34.29469926262843 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark28(-34.30593045843584 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark28(-34.319977916997345 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark28(-34.32717837206947 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark28(-34.32873295407781 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark28(-34.3476081762463 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark28(-34.35994099787962 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark28(-34.36866761050237 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark28(-3.4371222250491087 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark28(-3.4381695114121413 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark28(-34.4122817474952 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark28(-34.43541040380944 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark28(-34.44074789839296 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark28(-34.47780056663933 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark28(-34.543964908701795 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark28(-34.554910791840854 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark28(-34.56815775574191 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark28(-34.63181273738756 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark28(-34.64849431008004 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark28(-34.653290806754015 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark28(-34.65637838720038 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark28(-34.691110229942495 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark28(-34.772060064726176 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark28(-34.90609431415817 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark28(-34.939389037190224 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark28(-34.956181017676286 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark28(-34.956491697357905 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark28(-34.96416182377146 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark28(-34.966670089332055 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark28(-34.96880312904631 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark28(-34.98509989923669 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark28(-35.00301533075441 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark28(-35.023714973235826 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark28(-35.07509229826576 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark28(-35.08128316790797 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark28(-35.10358595779577 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark28(-35.11651755318235 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark28(-35.212496066506134 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark28(-35.219436815369235 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark28(-35.23909466561686 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark28(-35.26488395449492 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark28(-35.28155823951562 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark28(-35.286145332981775 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark28(-35.296398613986085 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark28(-35.36128889322477 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark28(-35.39357903603218 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark28(-35.420978312056036 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark28(-35.435404588191915 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark28(-35.479603525706025 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark28(-35.557600960092444 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark28(-35.59197955430943 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark28(-35.62996997803039 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark28(-35.6626251609744 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark28(-35.66833780380851 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark28(-35.69928594068075 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark28(-35.76036807555276 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark28(-35.8280997589802 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark28(-35.85300004270984 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark28(-35.85874388089127 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark28(-35.86598796108005 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark28(-35.871187649379934 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark28(-35.93282981925272 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark28(-3.594552118479882 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark28(-3.5950680373988178 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark28(-35.96488908013522 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark28(-35.992616073932 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark28(-36.01236685759561 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark28(-3.601826431623607 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark28(-36.01948907698025 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark28(-36.02094244336915 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark28(-36.04953056040281 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark28(-36.06596341592096 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark28(-36.07284552237087 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark28(-36.16963640635254 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark28(-36.1781891445448 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark28(-36.19873361991024 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark28(-36.212051869761154 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark28(-36.21408776186455 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark28(-36.22146434358704 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark28(-36.22704511646964 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark28(-36.25674103556082 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark28(-36.280302935000734 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark28(-36.28239134271942 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark28(-36.31596606017846 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark28(-36.31598731328043 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark28(-36.31815042552229 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark28(-36.33178975566196 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark28(-36.336016547635566 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark28(-36.34205106896269 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark28(-3.6361607189697907 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark28(-36.373427050661135 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark28(-36.37601187773936 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark28(-36.387419165124115 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark28(-36.4098446415094 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark28(-3.641759497297727 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark28(-36.439175315237904 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark28(-36.46272683512053 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark28(-36.51584952244609 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark28(-3.651611575224152 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark28(-36.53761437059737 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark28(-36.55929644315259 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark28(-36.56091764860072 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark28(-36.56317916933738 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark28(-36.57030497876133 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark28(-36.59864961952213 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark28(-36.62872308909122 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark28(-36.73297819001047 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark28(-36.74154216227667 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark28(-36.779544778727804 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark28(-3.680024747081845 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark28(-36.801538807162906 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark28(-36.83828587812765 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark28(-36.85135846379486 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark28(-36.86600403114628 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark28(-3.687704755266992 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark28(-36.9001379773737 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark28(-36.91822538873091 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark28(-36.921286598138295 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark28(-36.94772079558493 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark28(-36.98364731786754 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark28(-37.00537073566057 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark28(-37.02098453089562 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark28(-37.02465558866206 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark28(-37.08009464184163 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark28(-37.089760130363445 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark28(-37.09061014021682 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark28(-37.129309164418075 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark28(-37.13560002715104 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark28(-37.138243294482635 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark28(-37.14897835234985 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark28(-37.15514424739632 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark28(-37.189958237171815 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark28(-37.19188632617529 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark28(-37.201085837320804 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark28(-37.219019777273886 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark28(-37.220794562334206 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark28(-37.23141268480117 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark28(-37.238308604465885 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark28(-37.245654723657 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark28(-37.247525616949126 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark28(-37.25088317124383 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark28(-37.25550332781382 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark28(-3.7289433870085986 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark28(-37.309137479064745 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark28(-37.330951936407786 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark28(-37.35383834125954 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark28(-37.35394769497693 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark28(-37.41422572735995 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark28(-37.43094170098513 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark28(-37.44195945780693 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark28(-37.4491220770208 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark28(-37.457249114865945 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark28(-37.49428408073769 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark28(-37.498821115101855 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark28(-37.510513064862614 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark28(-37.52566141664906 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark28(-37.54702185743133 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark28(-37.57477866988819 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark28(-37.61253553070498 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark28(-37.6621147985855 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark28(-37.71527868845228 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark28(-37.757695161046925 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark28(-37.76724204728434 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark28(-37.814973363644256 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark28(-37.854389275077295 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark28(-37.87389958522787 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark28(-37.878974155176536 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark28(-37.89434296175167 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark28(-37.90450061681858 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark28(-37.926459220877206 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark28(-37.9637230413282 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark28(-37.97853452123834 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark28(-3.798600151824445 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark28(-38.055226626266816 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark28(-38.118892139174655 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark28(-38.16252946771846 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark28(-38.24005051069217 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark28(-38.26560973802238 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark28(-38.277866207132895 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark28(-38.34567383196723 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark28(-38.39606606868542 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark28(-38.398833507352116 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark28(-38.39954357741948 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark28(-38.43910718718031 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark28(-38.456814712420595 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark28(-3.8460024161280444 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark28(-38.47967581346605 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark28(-38.501685453244924 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark28(-38.53931039403962 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark28(-38.55325271442484 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark28(-38.56131070168776 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark28(-38.56963905513564 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark28(-38.58399510385981 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark28(-3.8612815859210343 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark28(-38.62233554125902 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark28(-38.62274430355044 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark28(-38.709892101839216 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark28(-38.72304720857067 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark28(-38.72864372541933 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark28(-38.78427051863582 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark28(-38.79553164089704 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark28(-38.80186379414559 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark28(-38.87055058869387 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark28(-38.87730608682429 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark28(-38.89872392723986 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark28(-38.98144880041101 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark28(-39.007477239741476 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark28(-39.015976681136365 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark28(-39.018026440377504 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark28(-39.03040060410876 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark28(-39.03825964044532 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark28(-39.03896215265308 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark28(-39.07222541812037 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark28(-39.088959517662644 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark28(-39.12879092401855 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark28(-39.14106767497534 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark28(-39.16081625484216 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark28(-3.920315434586442 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark28(-39.25147450922142 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark28(-39.266989344285676 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark28(-39.281732412836654 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark28(-39.31250445297319 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark28(-39.3500453004864 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark28(-39.35248995328848 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark28(-39.352892017108786 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark28(-39.41086403130423 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark28(-39.41809189202567 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark28(-39.42769922469351 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark28(-39.46698691624151 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark28(-3.94898487918924 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark28(-39.50982420313658 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark28(-39.55956282691837 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark28(-39.61721466125952 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark28(-39.624456586940916 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark28(-39.629674023159225 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark28(-39.63375843792387 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark28(-39.692112644819574 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark28(-3.971263638597989 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark28(-39.776579968190376 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark28(-3.983507800135058 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark28(-39.84225519427167 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark28(-39.853337284400055 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark28(-39.867086317947575 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark28(-3.9881342846086056 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark28(-39.929261509370264 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark28(-39.93035257643267 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark28(-39.9363268613097 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark28(-39.94429727279227 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark28(-39.99110872387488 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark28(-40.034582599083215 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark28(-40.06432819747761 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark28(-40.071226378922084 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark28(-40.086243990088136 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark28(-40.087193056167905 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark28(-40.14063580296037 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark28(-4.014903059682922 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark28(-40.19454495164347 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark28(-40.20256475171673 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark28(-4.02390796584686 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark28(-40.26419801220984 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark28(-40.271108217126915 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark28(-40.2739931972591 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark28(-40.32488497728801 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark28(-40.3529668373459 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark28(-4.038116588405515 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark28(-40.4512702623671 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark28(-40.49305765301794 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark28(-40.495983885948746 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark28(-40.522643339076225 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark28(-40.5359346002546 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark28(-40.561530193721154 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark28(-40.600726730456586 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark28(-40.64346088227593 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark28(-40.648203185685404 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark28(-4.065441483985396 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark28(-40.711936609833835 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark28(-40.76060301924274 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark28(-40.773270804548844 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark28(-40.81479577794367 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark28(-40.82637295374636 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark28(-40.857776686736315 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark28(-40.896161207942505 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark28(-4.0910721679801725 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark28(-40.91478985477595 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark28(-40.992745682359136 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark28(-41.00479428753383 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark28(-41.030404691848865 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark28(-41.05098041189201 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark28(-41.08639049487059 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark28(-4.122580685862246 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark28(-41.24191195822438 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark28(-41.24418722985301 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark28(-41.2686931614187 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark28(-41.29855617435692 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark28(-41.41132224633173 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark28(-41.467615320177195 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark28(-41.539285528627204 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark28(-41.54854925248148 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark28(-41.55177830539165 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark28(-41.55975684371826 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark28(-41.57541105355873 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark28(-41.57599048474263 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark28(-41.584862408360834 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark28(-41.6024074711004 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark28(-41.61390307320892 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark28(-4.162239019736774 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark28(-41.62440669488301 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark28(-41.64642305007262 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark28(-41.69568589787114 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark28(-41.72835854093988 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark28(-41.72982133210758 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark28(-41.73078355361029 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark28(-41.825550782491064 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark28(-41.91714328562899 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark28(-41.95217882187228 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark28(-41.95930752301338 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark28(-41.98355075949891 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark28(-42.001016558096296 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark28(-42.02634132614942 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark28(-42.069252963138524 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark28(-42.07374342959043 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark28(-42.09674510262265 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark28(-42.11332763087465 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark28(-42.12785916170301 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark28(-42.1530928756293 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark28(-42.201033392713306 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark28(-42.22129497237137 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark28(-42.26729205657305 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark28(-42.3430232785728 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark28(-42.35261385071556 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark28(-4.239782313580108 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark28(-42.411717496311965 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark28(-42.43253859136627 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark28(-42.438517513050236 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark28(-42.482538528751704 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark28(-42.5008053235731 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark28(-42.51751271805835 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark28(-42.55618952513609 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark28(-4.257079275396961 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark28(-4.257699080789763 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark28(-42.63689508820703 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark28(-42.640748605534576 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark28(-42.65307265502501 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark28(-42.66776437426094 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark28(-42.71297887775396 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark28(-42.72074396010173 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark28(-42.8063885790968 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark28(-42.81372818071449 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark28(-42.82340371441753 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark28(-42.83647209171089 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark28(-42.844081941194375 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark28(-42.86072537813374 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark28(-42.86604921768844 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark28(-42.87206914005952 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark28(-42.914125558957174 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark28(-42.95283209188927 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark28(-42.984479597377124 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark28(-43.003239484358666 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark28(-43.010827064266536 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark28(-4.302113453383001 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark28(-43.039138982473425 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark28(-43.05127266695161 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark28(-43.052282552115685 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark28(-43.074069248119095 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark28(-43.08248299771555 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark28(-4.31087104751893 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark28(-43.11839170337195 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark28(-43.138773267160424 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark28(-43.141002922741365 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark28(-43.17641703372246 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark28(-43.22497124528755 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark28(-43.226197306422364 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark28(-43.22964975175398 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark28(-43.230185251262384 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark28(-43.35819647585526 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark28(-43.36108139377814 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark28(-43.396563234637654 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark28(-43.397048967818705 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark28(-43.40270069825891 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark28(-43.40726682986613 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark28(-4.3419229498726395 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark28(-43.46008557462393 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark28(-43.48178679942245 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark28(-43.48198933348324 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark28(-43.48487813338946 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark28(-43.49939951731076 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark28(-43.51218914794255 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark28(-43.515799667975315 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark28(-43.54087440712908 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark28(-43.556339833837534 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark28(-4.3560091503956215 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark28(-43.574399671417254 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark28(-43.581426209170445 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark28(-43.58523442998907 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark28(-43.61865150144588 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark28(-43.62655049152413 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark28(-43.656748250920344 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark28(-43.66823454986528 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark28(-43.679685819768224 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark28(-43.73428086199888 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark28(-43.740352977636185 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark28(-43.7461864691753 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark28(-4.37513130271185 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark28(-43.76126622281211 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark28(-43.789134080210566 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark28(-43.82085651961578 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark28(-43.83637260001842 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark28(-43.84330727700869 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark28(-4.395292819176504 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark28(-4.396196575258955 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark28(-4.407673997311761 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark28(-44.081632285941 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark28(-44.097572043842234 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark28(-4.410479150213533 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark28(-44.19274454461306 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark28(-44.201508423687756 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark28(-44.2213615156126 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark28(-44.22298356432724 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark28(-44.23607626076831 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark28(-44.30527012983294 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark28(-44.32446268509449 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark28(-44.34291520119624 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark28(-44.36349174302994 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark28(-44.39050963404385 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark28(-44.465207622730006 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark28(-44.47466824970636 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark28(-4.448275171533169 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark28(-44.48789754952052 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark28(-44.49970005304766 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark28(-44.52657230812211 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark28(-44.53910617826844 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark28(-44.548944527228485 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark28(-44.57401610617162 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark28(-44.58457759081571 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark28(-44.644212301525975 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark28(-44.64914694575395 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark28(-44.69946940838236 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark28(-44.716333005185206 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark28(-44.73538403496278 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark28(-44.753944123695554 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark28(-44.75579385789861 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark28(-44.760575982144644 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark28(-44.78772760275484 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark28(-44.788227378245615 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark28(-44.79548826992823 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark28(-44.86656706466241 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark28(-44.88510774450485 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark28(-44.896164484231946 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark28(-44.91729284110768 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark28(-44.95304496450905 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark28(-44.979346575987854 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark28(-45.00077743765616 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark28(-4.508569565039551 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark28(-45.09105085706167 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark28(-45.10269009975514 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark28(-45.13775002254867 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark28(-4.514954460898537 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark28(-45.16433671711329 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark28(-45.18525052421798 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark28(-45.19511672983123 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark28(-45.22270640188255 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark28(-45.29380194829373 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark28(-45.302261488849794 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark28(-45.34677129979015 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark28(-45.37408945255672 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark28(-45.37637208898959 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark28(-4.539226878929142 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark28(-45.392962133624714 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark28(-45.46583305259371 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark28(-45.47356901292912 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark28(-45.497744550882246 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark28(-45.52044384221474 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark28(-45.559503744285365 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark28(-45.57615368599297 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark28(-45.59041601952125 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark28(-45.62723036662661 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark28(-45.65503641060358 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark28(-45.670286853217036 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark28(-45.67763266293876 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark28(-45.680610880216555 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark28(-45.683611640640784 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark28(-45.704520584535025 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark28(-45.720091381875896 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark28(-45.74671389076268 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark28(-45.85482882210796 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark28(-45.85510227968974 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark28(-45.86432331998485 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark28(-4.589609049993925 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark28(-45.90417031358971 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark28(-45.94301474185451 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark28(-46.003525884352946 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark28(-46.04126799592447 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark28(-46.05079202630489 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark28(-46.055061624562214 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark28(-46.13643822273244 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark28(-46.143292348296214 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark28(-46.17030137479485 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark28(-46.19103744505529 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark28(-46.226420838379646 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark28(-46.23832101392813 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark28(-46.35323029916998 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark28(-46.41212111454838 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark28(-46.43071179887875 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark28(-4.646497504925165 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark28(-46.48787105370451 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark28(-46.51980073785038 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark28(-46.58091935594677 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark28(-46.662010156377406 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark28(-46.66490660195657 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark28(-46.676637615228 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark28(-46.68678128656136 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark28(-4.670990348435893 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark28(-46.717319929481164 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark28(-46.72849629445943 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark28(-4.673554105948412 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark28(-46.735868731744176 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark28(-46.74318056729114 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark28(-46.758655921326394 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark28(-4.684638501526933 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark28(-46.93484643187882 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark28(-46.94181651749829 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark28(-46.94528810615901 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark28(-46.96449043655857 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark28(-46.98781761024116 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark28(-47.01486311692078 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark28(-47.03536325052162 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark28(-47.062983389842984 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark28(-47.12613093217411 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark28(-47.230984794125284 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark28(-47.26005326044562 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark28(-47.28687623981613 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark28(-4.728885077247639 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark28(-4.730442568239852 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark28(-47.30849928816636 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark28(-47.32273980535828 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark28(-47.343070436753806 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark28(-47.34330582097526 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark28(-47.38744255718612 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark28(-47.38761074991036 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark28(-47.44028463909933 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark28(-47.44058896813148 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark28(-47.45140057808148 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark28(-4.745269962921526 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark28(-47.45486520570776 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark28(-47.46158953502453 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark28(-47.48363137167233 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark28(-47.53870038262065 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark28(-47.55699806253353 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark28(-4.758331065531735 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark28(-47.58946878217558 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark28(-47.61066157044229 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark28(-47.63915828299859 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark28(-47.684029400272564 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark28(-47.702551376652536 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark28(-47.70986225497229 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark28(-47.73657356117875 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark28(-47.76162892854949 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark28(-47.84782686630899 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark28(-47.8659108423928 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark28(-47.94518091187137 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark28(-47.945721683165885 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark28(-47.97838273006305 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark28(-47.98388445949304 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark28(-48.00702611613246 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark28(-48.04502920179141 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark28(-4.807781167021076 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark28(-4.808520557913809 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark28(-4.810429506908449 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark28(-48.14618626206324 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark28(-48.17000946194805 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark28(-48.18359362996119 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark28(-48.23458596982428 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark28(-48.24792192341696 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark28(-48.26641434452126 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark28(-48.308905659261626 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark28(-48.33856829066563 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark28(-48.340891259902996 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark28(-48.342119515514085 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark28(-48.360556263658275 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark28(-48.371626073668935 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark28(-48.38614753509483 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark28(-4.841317282050326 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark28(-48.418212939667086 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark28(-48.41996350826903 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark28(-48.42573543746553 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark28(-48.4397095819697 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark28(-48.491229971375915 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark28(-48.49674593135831 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark28(-48.497144371020354 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark28(-48.50041929726858 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark28(-48.50165539146369 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark28(-48.52991767754455 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark28(-48.542248607914004 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark28(-48.60183505194344 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark28(-48.65361396571546 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark28(-48.6736336776989 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark28(-48.739534299631806 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark28(-48.741718140248395 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark28(-48.80261182398007 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark28(-4.8808881980495045 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark28(-48.81273479936772 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark28(-48.8649501712112 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark28(-48.913200875727945 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark28(-48.954286309976915 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark28(-48.99336255001603 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark28(-4.899510231376539 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark28(-4.9065334481903164 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark28(-49.08360693653799 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark28(-49.10812329226941 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark28(-49.160033694380445 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark28(-49.190816911281665 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark28(-49.19446775830325 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark28(-49.22455764592857 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark28(-49.26178048126311 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark28(-4.926626110603365 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark28(-49.26692327039088 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark28(-49.28909237101959 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark28(-49.29903832890159 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark28(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark28(-49.31856515415032 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark28(-4.934141987079201 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark28(-49.34441373289866 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark28(-49.37450701941501 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark28(-49.39642237069193 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark28(-49.42122784629524 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark28(-49.43491130992963 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark28(-49.435026833377904 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark28(-49.44138616651821 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark28(-49.521204365010306 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark28(-49.581667163365026 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark28(-49.6007027566347 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark28(-49.60306117477364 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark28(-49.60644606982838 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark28(-4.9625388358015385 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark28(-49.63681008854235 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark28(-49.648457881822125 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark28(-49.67628085445459 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark28(-49.681375726843726 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark28(-49.69566477036595 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark28(-49.703060635334296 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark28(-49.72648514162037 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark28(-49.74308724788929 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark28(-49.76835128018982 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark28(-49.78208357783451 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark28(-49.802695529860166 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark28(-49.82045165172677 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark28(-49.82161579964222 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark28(-49.83186809059414 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark28(-49.856702624203784 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark28(-49.869319523008215 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark28(-49.92614992345554 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark28(-49.929212811973024 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark28(-49.941638001385535 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark28(-4.99824730423353 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark28(-49.98757267248466 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark28(-49.99066735839983 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark28(-50.067152516953215 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark28(-50.09536597644437 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark28(-50.12170046379563 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark28(-5.020351645333918 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark28(-50.208023459538566 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark28(-50.21065170158676 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark28(-5.021934407803968 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark28(-50.240874611547866 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark28(-50.249000475423024 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark28(-50.253110148337775 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark28(-50.28898919186355 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark28(-50.32101794771384 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark28(-50.32565200560024 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark28(-50.344177708372875 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark28(-50.34919265836266 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark28(-50.41127045664429 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark28(-5.043417729131065 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark28(-50.43619960957897 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark28(-50.44862468523203 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark28(-50.58120511318156 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark28(-50.602195971876625 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark28(-50.622030088472194 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark28(-50.653916297967584 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark28(-50.69560130670783 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark28(-50.70584181226687 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark28(-50.71918033456342 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark28(-50.753537011527825 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark28(-50.75928073415048 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark28(-50.76044351553504 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark28(-50.845432475911466 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark28(-50.84691666607117 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark28(-50.91151859819851 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark28(-50.91416866981484 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark28(-50.918218718004326 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark28(-5.092031069887668 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark28(-50.92863530717633 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark28(-50.93349393230364 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark28(-50.946316092533465 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark28(-50.965614180641225 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark28(-50.9805263426627 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark28(-5.101911346294401 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark28(-51.090969361308105 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark28(-51.113000335470325 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark28(-51.12040721648514 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark28(-5.116530009445427 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark28(-51.193889045456544 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark28(-51.2539410617231 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark28(-51.28838037531123 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark28(-51.300023159528884 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark28(-51.305950458815055 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark28(-51.317671176789425 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark28(-51.341329033925916 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark28(-51.34888533409936 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark28(-51.36314416859737 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark28(-5.136325364433688 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark28(-51.36785613233214 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark28(-51.382457967802694 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark28(-51.405049912642966 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark28(-51.425826387789144 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark28(-51.48123987368909 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark28(-51.48215823679641 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark28(-51.488816441396736 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark28(-51.509734234797655 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark28(-51.65373154787181 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark28(-51.67106740858549 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark28(-51.69513895570405 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark28(-51.707129684300355 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark28(-51.831225039574555 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark28(-5.186712681724018 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark28(-5.1906126703499496 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark28(-51.926000168041384 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark28(-51.926014370980525 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark28(-51.93564912084019 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark28(-5.194125148914949 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark28(-51.944863768086826 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark28(-51.98775468181174 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark28(-52.08108049553051 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark28(-52.104930867791225 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark28(-52.113070843484465 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark28(-52.115452534910325 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark28(-52.13299801634168 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark28(-52.16190980975608 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark28(-52.226116990904444 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark28(-5.22682004035255 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark28(-52.27028988116822 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark28(-52.29723056796891 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark28(-52.30380761774007 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark28(-52.44767567123265 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark28(-52.47028121597768 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark28(-52.49920752991426 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark28(-5.249923807518428 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark28(-52.54190646572876 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark28(-52.57451813988689 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark28(-52.57492885083794 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark28(-52.59264532571848 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark28(-5.2592855523853785 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark28(-52.599141656027996 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark28(-52.612625114926416 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark28(-52.630572278305834 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark28(-52.66182722530826 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark28(-52.672900851572905 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark28(-52.720009596296414 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark28(-52.734509985897816 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark28(-52.7477812001659 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark28(-5.276330091673628 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark28(-52.78322538266331 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark28(-52.85387893583782 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark28(-52.88564826728657 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark28(-52.887465266056054 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark28(-52.92488808739173 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark28(-52.93856441225555 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark28(-5.305388304395933 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark28(-53.070265018951915 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark28(-53.08899918356522 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark28(-53.17977361599651 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark28(-5.31847132950864 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark28(-53.22080097224398 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark28(-53.220934759763594 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark28(-53.237682154840726 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark28(-53.23775855042068 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark28(-53.25167761220555 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark28(-53.32766908803976 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark28(-53.33683622108407 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark28(-5.339889486242242 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark28(-53.52895008289644 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark28(-53.531235153776095 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark28(-53.538721724894685 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark28(-53.56390591772391 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark28(-53.57268637618484 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark28(-5.357639668849885 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark28(-53.59831919325811 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark28(-53.64217797175952 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark28(-53.676720543840204 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark28(-5.373313060934819 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark28(-53.73737894019788 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark28(-53.75003647720822 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark28(-53.75568756963147 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark28(-53.76690184813027 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark28(-53.814727315470215 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark28(-53.85129503293484 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark28(-53.86310725433252 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark28(-53.86682948535635 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark28(-53.868940096808515 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark28(-53.89111164633631 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark28(-53.92102487194117 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark28(-53.95344709437009 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark28(-53.96931013858395 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark28(-53.98822617905468 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark28(-54.04455178267058 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark28(-54.087620067105924 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark28(-54.10128397085141 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark28(-54.149904916171664 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark28(-54.17641148359624 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark28(-54.19222760667897 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark28(-5.420960737152953 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark28(-54.23375516539504 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark28(-54.24262894012442 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark28(-54.25016221652572 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark28(-54.290001313715905 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark28(-54.29290839869707 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark28(-54.30123636996769 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark28(-54.30582356633469 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark28(-54.31617345460751 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark28(-54.32161501377324 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark28(-54.350225491384975 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark28(-54.366199962181064 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark28(-54.4433898847235 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark28(-54.45080656865669 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark28(-54.45881984273229 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark28(-5.4464674137041555 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark28(-54.48756313852918 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark28(-54.50143896265685 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark28(-54.51050921308569 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark28(-54.514597565660324 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark28(-54.5332087924606 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark28(-54.53365956090184 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark28(-54.553441241970326 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark28(-54.594781334111595 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark28(-54.62755215498485 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark28(-5.46360223025502 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark28(-5.465056582613471 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark28(-54.658520358445585 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark28(-54.68029995316057 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark28(-54.69069200772123 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark28(-54.70424462017491 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark28(-54.753677677256654 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark28(-54.76755819307109 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark28(-54.78116350893805 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark28(-54.82089925064773 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark28(-5.483871304954263 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark28(-54.84142620035279 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark28(-54.87477836332615 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark28(-54.90884478189155 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark28(-54.925131812154014 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark28(-54.92734535857542 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark28(-54.96555981090696 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark28(-54.97294918495326 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark28(-54.98197491797314 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark28(-55.0045329645126 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark28(-55.01768136209711 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark28(-55.047580906285674 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark28(-5.506844014026143 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark28(-55.0750811638212 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark28(-55.09300647484674 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark28(-55.12601596378677 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark28(-55.12613465847998 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark28(-55.209594097557634 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark28(-55.26889280017557 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark28(-55.29355989086937 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark28(-55.30217719746457 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark28(-55.347290729610265 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark28(-55.3537636153367 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark28(-55.3634450104318 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark28(-55.41535568410845 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark28(-55.43382418522755 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark28(-55.44501351840121 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark28(-55.45594176329658 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark28(-55.4973946578776 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark28(-55.50149567839166 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark28(-55.501672333045484 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark28(-55.54139793644668 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark28(-55.543312596557094 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark28(-55.54505472192746 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark28(-55.55783874993718 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark28(-55.564877107630274 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark28(-55.576533031883216 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark28(-55.5791996099243 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark28(-55.58163555109674 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark28(-55.63958614083975 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark28(-55.639781235152405 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark28(-55.67715243976732 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark28(-55.70489843459545 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark28(-55.71057050595443 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark28(-55.71350546016616 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark28(-55.74005712858716 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark28(-55.74241682504648 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark28(-55.76384353155597 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark28(-55.76507300227138 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark28(-55.76890159639309 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark28(-55.77436768036203 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark28(-55.7796971398693 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark28(-55.838262886305536 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark28(-5.5854736360226696 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark28(-55.89949286467417 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark28(-55.92614993071508 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark28(-55.94315319020509 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark28(-55.94769013639063 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark28(-55.98523597268053 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark28(-56.05432455919757 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark28(-56.07058054666108 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark28(-56.085048270657346 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark28(-56.10470009438411 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark28(-56.10515624847308 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark28(-56.15068143418303 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark28(-56.18626963434124 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark28(-56.32283256570461 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark28(-56.32627952278955 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark28(-56.33554252040498 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark28(-56.422871177257704 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark28(-56.47040136017032 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark28(-56.55101772181415 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark28(-5.667270726902743 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark28(-56.68192648247978 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark28(-56.69222370239944 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark28(-56.71170331018593 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark28(-5.672415012040361 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark28(-56.72947737509415 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark28(-56.75370348847464 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark28(-56.76224735409998 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark28(-5.683632715906086 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark28(-56.86058074433391 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark28(-56.87807270204601 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark28(-56.910173726009305 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark28(-5.691123511695295 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark28(-56.93245708263965 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark28(-56.97770205122177 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark28(-57.04887410059156 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark28(-57.124957004981106 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark28(-57.16471304458097 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark28(-57.19593753895922 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark28(-57.2232679655714 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark28(-57.25953725360422 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark28(-57.26741044952273 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark28(-57.284573425050624 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark28(-5.729449735172281 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark28(-57.337924271325804 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark28(-57.342791412894954 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark28(-5.737013040625612 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark28(-57.37467114679331 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark28(-57.38163248892714 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark28(-57.38435495776859 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark28(-57.39654440026614 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark28(-57.41230591278024 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark28(-57.4555025133644 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark28(-57.4608425922829 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark28(-57.46367596412356 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark28(-57.51758212905778 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark28(-5.752010566744076 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark28(-57.54590511081374 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark28(-5.757679983518088 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark28(-57.610193564863344 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark28(-57.621100563572995 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark28(-57.62401003431796 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark28(-57.63922876690766 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark28(-57.6697005916279 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark28(-57.6746434946481 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark28(-57.677831316828 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark28(-57.691666493071494 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark28(-57.74091678458883 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark28(-57.7737768878861 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark28(-57.77531658669286 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark28(-57.805362429882415 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark28(-5.780803686413407 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark28(-57.818211650308896 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark28(-57.82231790534338 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark28(-57.86831228248519 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark28(-57.87974800460445 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark28(-57.90557578886104 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark28(-57.96875654840943 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark28(-57.99251631182574 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark28(-58.014827143035006 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark28(-58.02931455564646 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark28(-58.0352116732088 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark28(-58.08021791826856 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark28(-58.16093599997061 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark28(-58.17488984618093 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark28(-58.18119921033811 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark28(-58.214802243567206 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark28(-58.24322683290934 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark28(-58.24604056913183 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark28(-58.25701244420871 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark28(-58.26019350986324 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark28(-58.283228311054614 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark28(-58.287735070559265 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark28(-58.29599488216035 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark28(-58.29750105590203 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark28(-58.300158515209354 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark28(-58.309850697406 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark28(-58.362888951072534 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark28(-58.36392266323198 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark28(-58.3905958065726 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark28(-58.40678736061948 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark28(-5.841716320724075 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark28(-58.42920099720861 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark28(-58.43314159839539 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark28(-58.47205421947124 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark28(-58.476932046133534 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark28(-58.50388534893727 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark28(-58.50693329963039 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark28(-58.527956723440425 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark28(-58.59462816855077 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark28(-58.60286224697595 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark28(-58.64915405072087 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark28(-58.69894221479031 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark28(-5.870301535880728 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark28(-58.70698349592336 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark28(-58.71633098109683 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark28(-58.74337723361825 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark28(-58.758942659214554 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark28(-58.78557766591497 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark28(-58.81399832178174 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark28(-58.84023555179239 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark28(-58.88584166222073 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark28(-58.91608356475846 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark28(-58.935254144791635 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark28(-59.01041283410488 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark28(-5.9015745411553695 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark28(-59.01787881458984 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark28(-59.02772548556992 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark28(-59.04888121448635 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark28(-5.905807164264985 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark28(-59.149333306369 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark28(-59.17570619497914 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark28(-5.918090990241254 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark28(-59.185858008431325 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark28(-59.20230514251719 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark28(-59.20272187139886 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark28(-59.20816202162176 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark28(-59.22666158888419 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark28(-59.23971963726957 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark28(-59.24219489280156 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark28(-59.25150127956049 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark28(-59.25456902033537 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark28(-59.26092745850331 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark28(-59.26991126975092 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark28(-59.28783052828099 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark28(-59.342291024174145 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark28(-59.397171169956444 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark28(-59.42646172154507 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark28(-59.438622200090194 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark28(-59.478149240241216 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark28(-59.4941094664033 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark28(-59.503169614024266 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark28(-59.503438693578524 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark28(-5.950902166214476 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark28(-59.554257174906546 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark28(-59.55592584336842 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark28(-59.58993715199201 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark28(-59.59370681693981 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark28(-59.731739908553536 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark28(-59.73656749307994 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark28(-59.73699949103022 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark28(-59.74218407542185 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark28(-59.807809215857645 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark28(-59.812810978305286 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark28(-59.815494241574015 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark28(-59.84759693524495 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark28(-59.91797077128762 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark28(-59.93990316790294 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark28(-59.95171058282025 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark28(-59.952157899781724 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark28(-59.96876135396254 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark28(-60.02477847816334 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark28(-60.029764676783095 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark28(-60.04388930452702 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark28(-60.07264464933555 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark28(-6.00733622448044 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark28(-60.07639481128098 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark28(-60.08473117078099 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark28(-60.10583336412152 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark28(-60.111498930720366 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark28(-60.11164084833518 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark28(-60.140880762576884 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark28(-6.014528508058277 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark28(-6.015749858725499 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark28(-60.16829927440246 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark28(-60.18420249170211 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark28(-6.020454488506076 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark28(-60.21375689773778 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark28(-60.22385303102382 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark28(-60.23145351858303 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark28(-60.24028414873648 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark28(-60.244056938606484 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark28(-60.26133004240932 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark28(-6.027071906317218 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark28(-60.29560568930488 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark28(-60.303169188451974 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark28(-60.30542008570063 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark28(-60.36651735255298 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark28(-60.391792477512496 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark28(-60.41975018201331 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark28(-6.046996534556953 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark28(-60.48464700226588 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark28(-60.52644460129788 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark28(-60.54036462316583 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark28(-60.55384489735105 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark28(-60.58904385721713 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark28(-60.60178431826668 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark28(-60.64307549308876 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark28(-60.6917843639895 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark28(-6.082586027814415 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark28(-60.843330266441306 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark28(-60.92566243100941 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark28(-60.94168755408737 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark28(-60.98517550873983 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark28(-60.98710296731744 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark28(-60.99111776476445 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark28(-61.038293705855985 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark28(-61.05306188012107 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark28(-61.06017811922324 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark28(-6.106959478585949 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark28(-61.09864083312247 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark28(-6.110668926774338 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark28(-61.11663206585505 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark28(-61.13746964602748 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark28(-61.14961812347375 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark28(-61.171901114441575 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark28(-61.17196990750029 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark28(-61.18341950829142 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark28(-61.20426090818971 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark28(-61.25000575700914 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark28(-61.3373109067904 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark28(-61.341085633529204 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark28(-61.34641323985215 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark28(-61.36560821483521 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark28(-61.38077773524506 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark28(-61.396689750391495 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark28(-61.427880060779174 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark28(-61.43027872596611 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark28(-61.43934790693686 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark28(-61.513452473573516 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark28(-6.1627251950388455 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark28(-61.64631262691969 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark28(-61.65195353615145 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark28(-61.65254254790196 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark28(-61.661589670143655 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark28(-61.74768963482149 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark28(-61.77701526738502 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark28(-61.80322726883782 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark28(-61.83167346359695 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark28(-61.83205098287583 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark28(-61.83898422416711 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark28(-61.879188288714325 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark28(-61.88724202681799 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark28(-61.89477529628482 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark28(-61.90089168245498 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark28(-61.91723037148549 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark28(-61.92241722052596 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark28(-61.9367585542834 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark28(-6.195537496724455 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark28(-61.969836299358775 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark28(-62.005607542832244 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark28(-62.022367676255286 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark28(-62.03216706150852 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark28(-62.03451196985617 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark28(-62.0764107175414 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark28(-62.08521196272949 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark28(-62.09245017017282 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark28(-62.18129943334125 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark28(-62.18229273836069 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark28(-62.23091345895975 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark28(-62.240313732315535 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark28(-62.24940415506299 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark28(-62.27322774081632 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark28(-62.28288455467768 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark28(-62.43128927664181 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark28(-62.4374814926514 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark28(-62.44309237573296 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark28(-62.45759718425394 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark28(-62.48816676868047 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark28(-62.51624258426198 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark28(-62.52553030882191 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark28(-62.65203152290244 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark28(-62.65696576131177 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark28(-62.65731993476036 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark28(-62.70687270947548 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark28(-62.710389426806316 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark28(-62.75041579247607 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark28(-62.785941934399084 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark28(-62.938372414489876 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark28(-63.06023642450798 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark28(-63.083508698291354 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark28(-63.127502600273864 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark28(-6.312821967724247 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark28(-6.31382690618058 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark28(-63.14803557151194 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark28(-63.15861264464304 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark28(-63.16942891172872 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark28(-63.17743415756751 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark28(-63.204739654932965 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark28(-63.279996953182405 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark28(-6.335194680882509 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark28(-63.37814272208866 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark28(-63.39028254775132 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark28(-63.42846672763787 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark28(-63.474858246368385 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark28(-63.60366648249438 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark28(-63.61482920294193 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark28(-63.62901578987059 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark28(-63.63923997225631 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark28(-6.363950565163364 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark28(-63.6985953303344 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark28(-63.69885443401229 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark28(-63.70357635563331 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark28(-63.705279615936085 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark28(-63.705398675564126 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark28(-63.71029168620272 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark28(-63.722507687528164 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark28(-6.382189042207685 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark28(-63.85637901601824 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark28(-63.874508305090714 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark28(-63.90979056348953 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark28(-63.94803360899062 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark28(-63.975508688468 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark28(-63.99846669560316 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark28(-64.0278869009841 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark28(-64.04203026425884 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark28(-64.05553442514721 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark28(-64.11882334924837 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark28(-64.15928863745926 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark28(-64.265892408875 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark28(-64.29562141228398 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark28(-64.30413676811469 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark28(-64.34079879764329 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark28(-64.36462473347721 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark28(-64.38233722518203 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark28(-64.40238955594775 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark28(-64.42540837325339 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark28(-64.43161876367543 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark28(-64.4985214666249 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark28(-64.51605826190453 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark28(-64.51931163044011 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark28(-64.52969334816525 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark28(-64.55078622143057 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark28(-64.5749137014831 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark28(-64.59633539322303 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark28(-64.62506713383007 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark28(-64.66407964685487 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark28(-64.69389804586214 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark28(-64.71904156933425 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark28(-64.7224098244184 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark28(-64.73857245538031 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark28(-64.77049019150257 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark28(-64.77296783770535 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark28(-64.81795458992477 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark28(-64.85182979336702 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark28(-6.487888854358431 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark28(-64.8954469354753 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark28(-64.94086330984683 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark28(-64.9462464069532 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark28(-64.98225788701632 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark28(-64.98763465894126 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark28(-65.01742786783478 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark28(-65.02826569272162 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark28(-65.03246743257019 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark28(-65.05874508802543 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark28(-65.0738220048223 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark28(-65.13242615595198 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark28(-65.13911125749661 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark28(-65.14126763818476 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark28(-65.1510112242045 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark28(-65.19440483083743 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark28(-65.20608106812398 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark28(-65.23138186232065 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark28(-65.25277819793816 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark28(-65.29031577876027 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark28(-65.29414030092038 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark28(-65.31991197248124 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark28(-65.32976332359655 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark28(-65.33111135855285 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark28(-65.37383164505121 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark28(-65.40904143994455 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark28(-65.52162464696002 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark28(-65.58241829476935 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark28(-65.58826297450098 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark28(-65.6041252906687 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark28(-65.62756662571795 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark28(-65.6342916435304 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark28(-65.6653381830385 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark28(-65.75379468751512 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark28(-65.75674440026339 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark28(-65.7989140501052 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark28(-65.84916580516125 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark28(-65.8637873467294 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark28(-65.88317930408034 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark28(-65.89025590901576 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark28(-65.89920140765284 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark28(-65.91134096989427 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark28(-65.9164163979957 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark28(-65.9388258891851 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark28(-65.96425169423969 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark28(-65.98625519312083 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark28(-66.01451973230041 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark28(-66.03311675251618 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark28(-66.07172215377011 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark28(-66.08503797494583 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark28(-66.09473147171268 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark28(-66.10444198306935 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark28(-6.612089192062527 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark28(-66.14351289878977 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark28(-66.14949680181468 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark28(-66.2017299126943 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark28(-66.21200388921358 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark28(-6.62612317054807 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark28(-66.2857989514583 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark28(-66.29404485562239 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark28(-66.29560699755474 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark28(-6.629909525918663 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark28(-66.29993618549663 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark28(-6.6339470105772875 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark28(-66.38223513404483 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark28(-66.43604813480638 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark28(-66.47889028737129 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark28(-66.49966289693262 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark28(-66.50240030168175 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark28(-66.54789832746475 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark28(-6.654932350253873 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark28(-66.5887313239168 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark28(-66.59360605698197 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark28(-66.66975668138255 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark28(-66.71237916449093 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark28(-66.74649297080417 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark28(-66.82290597554362 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark28(-66.85439621128486 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark28(-66.8591942146203 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark28(-66.90019476949188 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark28(-66.9337816957063 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark28(-66.94183242940919 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark28(-66.96067484035032 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark28(-66.96761814771197 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark28(-66.98515500344186 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark28(-67.0037466116031 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark28(-67.01235702859648 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark28(-67.02519387469523 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark28(-67.02782990559376 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark28(-67.12814757493283 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark28(-67.13495870122395 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark28(-6.713763941697962 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark28(-67.16660575429938 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark28(-6.717811300636555 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark28(-67.1843330393782 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark28(-67.21043534903183 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark28(-67.26297356952836 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark28(-67.29680092515315 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark28(-67.31280331009094 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark28(-67.32307677707888 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark28(-67.35107836006411 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark28(-67.36602640619367 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark28(-67.379690258716 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark28(-67.43109651624869 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark28(-67.46890572729865 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark28(-67.52140872482966 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark28(-67.53173397396554 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark28(-67.55974665053914 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark28(-67.57429650691596 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark28(-67.59849819910804 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark28(-67.60175281422758 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark28(-67.60368388815874 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark28(-67.64521253132287 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark28(-67.65327216028933 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark28(-67.67091129505359 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark28(-67.67367304795366 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark28(-67.6790616681036 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark28(-67.69957531774207 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark28(-67.70220939022943 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark28(-67.71292376530104 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark28(-67.72455207174113 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark28(-67.72595578977825 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark28(-67.73467992623081 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark28(-67.74928883962642 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark28(-67.75038804049728 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark28(-67.75685502500639 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark28(-6.778039838914523 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark28(-67.78166688462207 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark28(-67.82946907541027 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark28(6.79201892112529 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark28(-67.93050950141577 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark28(-67.93763521277924 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark28(-67.94983937384063 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark28(-67.96704645634367 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark28(-68.02072291943064 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark28(-68.0310011388807 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark28(-6.803953119766888 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark28(-68.04737168190682 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark28(-68.10046018655163 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark28(-68.10372853057947 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark28(-68.14336847375723 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark28(-68.16621346223704 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark28(-68.196566596522 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark28(-68.2427589319467 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark28(-6.825987385669734 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark28(-68.27344038406349 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark28(-68.29262463921009 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark28(-6.830146191570165 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark28(-68.49368740032668 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark28(-68.51396177135277 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark28(-68.54840116160095 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark28(-68.55114425700579 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark28(-68.62951733860838 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark28(-68.67057839516961 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark28(-68.70108877923668 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark28(-68.70573752403331 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark28(-68.71184469627995 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark28(-68.71664010982133 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark28(-68.82707563611842 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark28(-68.82896730724556 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark28(-6.886360798334607 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark28(-68.87301407622415 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark28(-68.87984866333278 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark28(-68.89233741931744 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark28(-68.91755436949481 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark28(-68.97078279989033 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark28(-68.97343886656337 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark28(-69.0150277750688 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark28(-69.0256541373091 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark28(-6.903324506760498 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark28(-69.04063799415263 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark28(-69.04722970144684 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark28(-6.90601809005986 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark28(-69.06535787346897 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark28(-69.06618906841504 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark28(-69.07141605771002 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark28(-69.07656985801074 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark28(-69.11883707664914 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark28(-69.13913349237086 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark28(-69.14728433173266 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark28(-69.17567078429185 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark28(-69.1827721427137 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark28(-69.243026571531 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark28(-69.296486442452 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark28(-6.931421469833495 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark28(-69.36201246172882 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark28(-69.37811036806214 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark28(-69.41021569598784 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark28(-69.4241352584489 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark28(-69.43072824715699 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark28(-69.4584364895322 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark28(-69.47947729039842 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark28(-69.48037210744218 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark28(-69.49424002179848 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark28(-6.951671101549977 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark28(-69.54499735017457 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark28(-69.54865147919848 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark28(-69.56250197292577 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark28(-69.56465796720461 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark28(-69.57232238168785 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark28(-69.58646633570055 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark28(-69.64046170918778 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark28(-69.6478632947986 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark28(-69.66977288398344 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark28(-6.9676584479169605 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark28(-69.67908995094152 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark28(-69.68279325423323 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark28(-69.77109160655384 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark28(-69.8377783674508 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark28(-69.84062589760502 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark28(-69.86237264576482 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark28(-69.87695771874085 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark28(-69.89659230533005 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark28(-6.996756496646128 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark28(-69.97037178796276 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark28(-69.99309807137921 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark28(-70.000868645349 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark28(-70.00382085279075 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark28(-70.0211254080935 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark28(-70.05534841926134 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark28(-70.1476947491346 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark28(-70.20164954770189 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark28(-7.020869628554976 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark28(-70.23622936715373 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark28(-70.24499615488374 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark28(-70.2803354642819 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark28(-7.029785373011947 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark28(-70.34717043357509 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark28(-70.37820866506269 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark28(-70.38595769310191 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark28(-70.40509358901073 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark28(-70.41391670186849 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark28(-70.44756946285695 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark28(-70.45966053766521 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark28(-70.4974418194038 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark28(-70.50491780577511 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark28(-70.57265886132154 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark28(-70.59794789530363 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark28(-70.60103355963712 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark28(-70.67952869439821 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark28(-70.70132048036385 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark28(-70.71330947222097 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark28(-70.73817260461121 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark28(-70.75309342972218 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark28(-70.76297649613157 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark28(-70.83713195883954 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark28(-70.86519453883665 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark28(-70.94667505365517 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark28(-7.098690759519073 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark28(-70.99609540973762 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark28(-71.00078251153971 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark28(-71.0220580557307 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark28(-71.08035329499391 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark28(-71.12196583684195 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark28(-71.14245952224184 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark28(-71.16189868633768 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark28(-71.19002237595504 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark28(-71.22513161202019 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark28(-71.22673734857085 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark28(-71.24396096767683 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark28(-71.25669428365553 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark28(-71.27619880266067 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark28(-71.30663081635021 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark28(-71.3584087404709 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark28(-71.36092198569048 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark28(-71.38495993983938 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark28(-71.41323833778142 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark28(-71.43523580615039 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark28(-7.145213014173407 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark28(-71.46816755915472 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark28(-71.46930021028616 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark28(-71.50890966086598 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark28(-71.54141103220309 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark28(-71.55603399650472 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark28(-7.156544092633155 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark28(-71.58931093426074 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark28(-71.66492306188223 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark28(-71.69268786989771 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark28(-71.70167179753228 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark28(-71.73376628260273 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark28(-7.173685617846033 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark28(-71.73689110984486 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark28(-71.7757745500577 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark28(-71.87625588903364 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark28(-71.89875889661846 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark28(-71.90535345166545 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark28(-71.92214811742552 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark28(-71.94459478040642 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark28(-71.95014638237917 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark28(-71.99096518574773 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark28(-71.99203039643879 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark28(-72.00154644941293 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark28(-72.08317939941998 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark28(-72.0890363241796 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark28(-72.16264575698652 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark28(-7.220723669261446 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark28(-72.26092635411831 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark28(-72.30031394444336 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark28(-72.33445207996422 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark28(-72.3923422045633 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark28(-72.43052049219108 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark28(-72.47723771443353 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark28(-72.48907064304825 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark28(-7.2508901031147985 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark28(-72.52842859213347 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark28(-72.54071270650155 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark28(-72.56496827137494 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark28(-72.57132809965823 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark28(-72.5725728512844 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark28(-72.58510092490329 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark28(-72.5895885229072 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark28(-72.79980552972465 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark28(-72.8057260982743 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark28(-72.81565412528077 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark28(-72.82039004566185 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark28(-7.2840242532822685 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark28(-72.88732038080087 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark28(-72.91438289915297 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark28(-72.91541709550755 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark28(-72.95209192185828 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark28(-72.95446325570403 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark28(-73.01146958850143 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark28(-73.02522427431286 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark28(-73.09147125125335 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark28(-73.10002034462104 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark28(-73.10211964208126 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark28(-73.10882857914503 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark28(-73.1329433239497 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark28(-73.14362547882097 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark28(-73.18030710110011 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark28(-7.32378839245618 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark28(-73.25534990588366 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark28(-73.27263534308571 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark28(-73.28555620319317 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark28(-73.30953848811043 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark28(-73.31996168361704 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark28(-73.3217868403681 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark28(-73.36232254004464 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark28(-7.340388686539995 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark28(-73.40590386600188 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark28(-73.42197470062983 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark28(-73.43151635889214 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark28(-73.47838122450045 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark28(-73.48506644089481 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark28(-73.48945013254504 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark28(-73.49115350968943 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark28(-73.56272010024554 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark28(-73.56565881515544 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark28(-73.65081532497459 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark28(-7.368165603561238 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark28(-73.68698807596728 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark28(-73.70480412284817 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark28(-73.75226521085341 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark28(-73.80480492812998 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark28(-73.82214311798182 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark28(-7.38264799199338 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark28(-73.83847536780002 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark28(-73.84425464961149 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark28(-73.85285586460967 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark28(-73.8551643941475 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark28(-73.91183859922418 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark28(-73.91519563079797 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark28(-73.92795424219057 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark28(-73.93470361486054 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark28(-73.95960706685173 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark28(-73.96837801063607 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark28(-73.96935145345076 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark28(-73.97915920155651 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark28(-74.01170580548919 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark28(-74.02316153016588 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark28(-74.04731299079701 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark28(-74.09308851198952 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark28(-7.4111310072710666 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark28(-74.3175121968389 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark28(-7.436335928440101 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark28(-74.37467038358167 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark28(-74.41319750186348 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark28(-74.44190601285521 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark28(-74.45919860206602 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark28(-74.46117945575975 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark28(-74.46318941473686 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark28(-74.49441334876275 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark28(-74.5018645381788 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark28(-74.53452885668419 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark28(-74.54104721949066 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark28(-74.54588921691712 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark28(-74.59996880154102 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark28(-7.460398067629953 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark28(-74.64054135728615 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark28(-74.64862574680646 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark28(-74.64883693054199 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark28(-74.66578014160703 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark28(-74.67375509998809 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark28(-74.68536616285249 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark28(-74.69770742224688 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark28(-74.69857776335675 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark28(-74.74614059976761 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark28(-74.7906748398972 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark28(-74.79643207186646 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark28(-74.80835258756929 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark28(-74.81152464740913 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark28(-74.82952659818605 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark28(-74.99926712102918 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark28(-75.0443336235391 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark28(-75.07914813032275 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark28(-75.08359102906144 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark28(-75.08889635730554 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark28(-75.10110923118367 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark28(-75.12033054690338 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark28(-75.14159195620111 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark28(-75.15117266050271 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark28(-75.24575849590971 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark28(-75.25216755500786 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark28(-75.28127352096766 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark28(-75.2879635271913 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark28(-75.35211839117662 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark28(-75.42938438975031 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark28(-7.546923585864931 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark28(-75.49403502617582 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark28(-75.51650733282489 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark28(-75.52005638300132 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark28(-75.52173148440002 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark28(-75.57298104450211 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark28(-75.59690083952768 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark28(-75.6076929160385 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark28(-75.63278856254684 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark28(-75.646141486793 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark28(-75.65323688976167 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark28(-7.568230048456741 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark28(-75.6854667972765 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark28(-75.77779913361184 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark28(-75.78040337748853 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark28(-7.580434588336345 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark28(-75.85109883193728 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark28(-75.85601409001356 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark28(-75.89532340490597 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark28(-75.8977221975538 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark28(-75.90834574575052 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark28(-75.92794061371976 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark28(-75.93928156803626 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark28(-75.94165429019613 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark28(-75.95276795889151 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark28(-76.00948483513346 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark28(-76.02220886576967 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark28(-76.0224872230362 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark28(-76.066465648504 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark28(-76.09818860917417 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark28(-76.11734442626943 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark28(-76.1327738363258 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark28(-76.13447038038464 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark28(-76.18375716438528 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark28(-76.18427861553127 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark28(-76.24928480783203 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark28(-76.2513490664767 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark28(-76.27948864076903 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark28(-76.29453506560553 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark28(-76.30380644325857 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark28(-76.32148891632104 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark28(-76.43529158877092 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark28(-76.4562198754597 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark28(-7.6470148603565775 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark28(-76.47309382239358 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark28(-76.49535963767974 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark28(-76.54680888453757 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark28(-76.59227830589062 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark28(-76.59791512869873 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark28(-76.61515589575046 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark28(-76.61715960498867 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark28(-76.62534839548532 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark28(-7.667046411137775 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark28(-76.7013088105111 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark28(-76.72014126465888 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark28(-76.780792333325 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark28(-76.79789753953389 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark28(-76.81137580711182 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark28(-76.83728160689107 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark28(-76.89696787545125 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark28(-76.89778341918607 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark28(-76.90473789856689 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark28(-76.90845553061882 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark28(-76.94619442629332 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark28(-76.9940015186932 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark28(-76.99741548400507 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark28(-77.00820052584965 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark28(-77.01868511809491 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark28(-77.0325646084008 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark28(-77.04451907440875 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark28(-77.04627897340785 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark28(-77.05871569517507 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark28(-77.07772705053134 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark28(-7.711528702738065 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark28(-77.19688668756916 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark28(-77.21493237256934 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark28(-77.21602003316369 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark28(-77.23877916041735 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark28(-77.26172502696753 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark28(-77.28859587545412 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark28(-77.32717711557353 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark28(-77.33508362006769 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark28(-77.35815436344802 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark28(-77.36007914990742 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark28(-77.3602640698611 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark28(-77.379708794444 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark28(-77.4165709103226 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark28(-77.43946239206551 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark28(-77.43983021159006 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark28(-77.44170121408598 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark28(-77.4617087384353 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark28(-77.47139321553294 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark28(-77.519457702647 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark28(-77.52821218853497 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark28(-77.55344338699209 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark28(-77.59578163309367 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark28(-77.60664708778475 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark28(-77.60673847791878 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark28(-7.762267765474377 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark28(-77.67479381622104 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark28(-77.67846640977866 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark28(-77.73781635179382 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark28(-77.73975372198139 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark28(-77.7676146158071 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark28(-77.81094100157615 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark28(-7.7851730700754445 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark28(-77.85844020591644 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark28(-77.87564658453951 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark28(-77.88299765193082 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark28(-77.88664771713457 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark28(-77.91796450568451 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark28(-77.92968105581937 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark28(-77.93530737496219 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark28(-77.99621787656844 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark28(-78.01867061534594 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark28(-78.02692811362326 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark28(-7.803715386645791 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark28(-78.06845338771083 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark28(-78.07443063299498 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark28(-78.0980557554532 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark28(-78.18051451486339 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark28(-78.19012129980251 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark28(-78.31615080946064 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark28(-78.33607959900262 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark28(-78.35551389965562 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark28(-78.36265395150983 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark28(-78.38112264399024 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark28(-78.38773518993693 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark28(-78.429488415321 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark28(-78.43156294775679 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark28(-78.44174352848952 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark28(-78.4673203649208 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark28(-78.46831288937331 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark28(-78.47079715094748 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark28(-78.4733153150883 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark28(-78.47665699126046 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark28(-78.4817863388114 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark28(-78.48584719630642 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark28(-78.54101226414073 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark28(-7.8547231889157985 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark28(-78.56681788829056 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark28(-78.57103418376582 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark28(-78.57453020711931 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark28(-78.60989981343852 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark28(-78.61701334541216 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark28(-78.61759754364985 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark28(-78.6434090714225 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark28(-7.864450934294439 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark28(-78.65523071360727 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark28(-78.69157664820861 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark28(-78.7190366427894 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark28(-78.71985878779537 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark28(-78.72435121673328 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark28(-78.72511670771573 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark28(-78.72653992320537 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark28(-78.78690647284682 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark28(-78.90498501987707 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark28(-78.98603733208472 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark28(-79.01762431882212 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark28(-7.902027977037477 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark28(-79.04064511954294 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark28(-79.04927663058108 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark28(-79.05765798458377 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark28(-79.07489142709254 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark28(-79.10212988271262 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark28(-79.1113713094422 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark28(-79.12299005812424 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark28(-79.1236554557054 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark28(-79.12708545691984 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark28(-79.16346131110771 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark28(-79.18175947302984 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark28(-79.20150354193585 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark28(-79.2394944150847 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark28(-79.27188039081874 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark28(-79.38520551321588 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark28(79.39547984451593 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark28(-7.94274047025354 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark28(-79.45969223220379 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark28(-79.48724063523221 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark28(-79.54944464156719 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark28(-79.55453061975346 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark28(-79.61466857577233 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark28(-79.6747558655918 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark28(-79.75732413980943 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark28(-79.77487152127185 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark28(-79.78186267152353 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark28(-79.79276408937068 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark28(-79.80566791907502 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark28(-79.84455635501234 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark28(-79.90839746959269 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark28(-79.90890493337113 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark28(-79.91301477854282 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark28(-79.92724312503154 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark28(-79.95908318941245 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark28(-79.96601536971622 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark28(-79.96981315945592 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark28(-79.98415603040432 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark28(-79.98485366137353 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark28(-79.99650653501054 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark28(-80.03376913633247 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark28(-80.035189886583 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark28(-80.04034553857022 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark28(-80.08979708244993 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark28(-80.10082630577753 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark28(-80.1192010599974 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark28(-80.14506746149183 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark28(-80.30716439376107 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark28(-80.31895522437196 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark28(-80.36911457196776 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark28(-80.37449650752126 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark28(-80.38616013032347 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark28(-80.4174602384 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark28(-80.41910247335417 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark28(-80.43617978773656 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark28(-80.44775272818438 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark28(-80.4681623558907 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark28(-80.52007845576652 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark28(-80.54386402011183 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark28(-80.59400767901491 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark28(-80.66202273017764 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark28(-80.6636954108735 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark28(-80.7141055378634 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark28(-8.072251914647183 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark28(-80.73078552001358 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark28(-80.73652591037879 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark28(-80.74202450645046 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark28(-80.74386577354629 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark28(-80.75666759399894 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark28(-80.77720263563609 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark28(-80.78846178997907 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark28(-8.080288753534461 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark28(-80.88859729966399 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark28(-80.89698753941327 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark28(-80.89736192153742 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark28(-80.91592351203194 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark28(-80.92714456527332 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark28(-8.094525938830444 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark28(-80.97972596292415 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark28(-81.02476231516025 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark28(-81.0401427073021 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark28(-81.07614770227977 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark28(-81.09235681899722 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark28(-81.11325025334875 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark28(-8.111757998676381 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark28(-81.13144787374353 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark28(-81.15057326470041 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark28(-81.192041731913 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark28(-81.20148184027653 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark28(-81.2174463122312 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark28(-81.23725147210695 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark28(-81.26317866144717 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark28(-81.3200857053041 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark28(-81.32330858674408 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark28(-81.36914734397732 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark28(-81.39483080729117 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark28(-81.43212056522657 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark28(-81.45715292386564 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark28(-81.54905592730617 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark28(-81.55697212075839 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark28(-81.61335358222948 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark28(-81.62513455325147 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark28(-81.67690652535808 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark28(-81.68961226868603 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark28(-81.69882436806859 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark28(-81.72658141961269 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark28(-81.73069537537769 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark28(-81.74729634283395 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark28(-81.77632625722111 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark28(-81.8049248964638 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark28(-81.82416255230444 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark28(-81.85728634646337 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark28(-81.86881084597204 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark28(-81.9042041543177 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark28(-81.91935783362578 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark28(-81.92141403756041 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark28(-81.92758358109091 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark28(-81.93008555767548 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark28(-81.93313604585721 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark28(-81.93673672994323 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark28(-81.95893069473459 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark28(-82.0038383563983 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark28(-82.01000374719625 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark28(-82.01362727251278 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark28(-82.0641534124191 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark28(-82.12513927152165 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark28(-82.14809955878475 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark28(-82.16498879555303 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark28(-82.18639801003278 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark28(-82.22056407528044 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark28(-82.22366714716658 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark28(-82.27548682910917 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark28(-82.2899233523556 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark28(-82.32047394690525 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark28(-82.33607567047616 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark28(-82.4876636826198 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark28(-82.49840320214095 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark28(-8.2523615426838 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark28(-82.53009922245693 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark28(-82.56031489380624 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark28(-82.66288111887775 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark28(-82.66930487900376 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark28(-82.68052441109919 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark28(-82.6989008126287 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark28(-82.69921285615551 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark28(-8.271257709624152 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark28(-8.271546817071311 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark28(-82.74631511804938 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark28(-82.74929914485844 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark28(-82.75252874354686 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark28(-82.75692405546005 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark28(-82.76493672922916 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark28(-82.8216106168508 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark28(-82.89776257516408 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark28(-82.92025726606529 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark28(-82.92115684148935 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark28(-82.93772446689694 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark28(-82.98478697782794 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark28(-8.30285774428468 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark28(-83.03157968831141 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark28(-83.03754533805557 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark28(-83.11489248042562 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark28(-83.1258720886576 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark28(-83.1829650117659 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark28(-83.18780122547018 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark28(-83.22406453486605 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark28(-83.24846937614876 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark28(-83.27636261801361 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark28(-83.30993773060551 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark28(-83.32077703823214 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark28(-83.34099366176493 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark28(-83.39740145898557 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark28(-83.398277590195 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark28(-83.41365137686618 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark28(-83.43678748642267 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark28(-83.44394725229131 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark28(-83.45145884811117 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark28(-83.48696754447866 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark28(-83.49616037560996 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark28(-83.57252568467783 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark28(-83.5790802309931 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark28(-83.59865578497055 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark28(-83.60057291865542 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark28(-83.6335381443134 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark28(-83.63814988926862 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark28(-83.73802890786038 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark28(-83.82424454256996 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark28(-83.82865467860617 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark28(-83.83099786869809 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark28(-83.83853272063651 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark28(-83.8561561470641 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark28(-83.86984300666612 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark28(-84.07283123124208 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark28(-84.11331400370744 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark28(-84.14386894670301 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark28(-84.14634115923133 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark28(-84.15419763359714 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark28(-84.16407343680288 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark28(-84.1754248708425 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark28(-84.21277451560938 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark28(-84.21570873873345 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark28(-84.23995252455907 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark28(-8.4259135826737 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark28(-84.34416533897011 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark28(-84.35302941360791 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark28(-84.38550532851397 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark28(-84.4378729894353 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark28(-84.51423084205653 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark28(-84.5601766604336 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark28(-84.56895403085487 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark28(-84.63408744056393 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark28(-84.66638875676864 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark28(-84.66755075959405 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark28(-84.67558319387652 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark28(-84.70415549391157 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark28(-84.77194910542345 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark28(-84.78223380323062 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark28(-84.79568376134188 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark28(-84.81714079043601 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark28(-84.88634104777131 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark28(-84.89290425709062 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark28(-84.90211004711539 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark28(-84.90291201288956 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark28(-84.91073240968514 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark28(-84.91300587624164 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark28(-85.11146849233944 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark28(-85.19481891090201 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark28(-85.30161560106558 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark28(-85.3034959385382 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark28(-85.31321951248061 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark28(-85.37315951365574 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark28(-85.39799496285924 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark28(-8.542754670034029 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark28(-85.43088978216542 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark28(-85.46089637822098 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark28(-85.53004365875528 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark28(-85.59344456955067 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark28(-85.60991870982564 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark28(-85.65344374368387 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark28(-85.69299859114597 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark28(-85.73781140238532 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark28(-85.75993045638236 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark28(-85.77183363024213 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark28(-85.79903369751759 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark28(-85.79937548218996 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark28(-85.80317144055056 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark28(-85.81477674107036 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark28(-8.582396035591373 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark28(-85.82616756624392 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark28(-85.90137422203752 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark28(-85.90301462957277 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark28(-85.92865590181167 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark28(-86.030944877362 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark28(-86.07272156601344 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark28(-86.0987405793643 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark28(-86.10131989970667 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark28(-86.10780279633848 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark28(-86.12100556550541 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark28(-86.15675914509666 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark28(-86.176984848698 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark28(-86.17946376127192 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark28(-86.19414844274273 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark28(-86.20625531392395 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark28(-86.22379315023949 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark28(-8.631397692882501 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark28(-86.31829696342066 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark28(-86.3522042295795 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark28(-86.36038726436486 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark28(-86.3654296503964 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark28(-86.37333508778428 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark28(-86.37559343867846 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark28(-86.37822305964282 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark28(-86.38999811517367 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark28(-86.39771315523228 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark28(-86.42760388498036 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark28(-86.43552099777658 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark28(-8.649159575097713 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark28(-86.50861965769073 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark28(-86.51049978178114 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark28(-86.51224731983228 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark28(-86.51455539930389 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark28(-8.654027434392546 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark28(-86.5594701446164 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark28(-86.5962269387137 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark28(-86.60056230674977 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark28(-86.60140856056049 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark28(-86.64027913769515 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark28(-86.66210330932836 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark28(-86.68144957907442 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark28(-86.68465731614508 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark28(-86.7181624904343 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark28(-86.77767306564506 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark28(-86.82490673400105 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark28(-86.83588627969635 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark28(-86.91827620957773 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark28(-86.97101263806442 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark28(-86.98742057880176 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark28(-87.1160381276417 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark28(-87.19311957260936 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark28(-87.2038172647767 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark28(-87.21927922146533 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark28(-87.24177051295065 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark28(-87.26058266406365 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark28(-87.31517192814171 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark28(-87.3817154473755 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark28(-87.38916907068126 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark28(-87.39139190035495 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark28(-87.39782903868638 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark28(-87.42339634279841 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark28(-87.42718290907212 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark28(-87.46167134556136 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark28(-8.753722918126655 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark28(-87.55037971488764 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark28(-87.57641601933804 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark28(-87.6007860724167 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark28(-87.6103088351591 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark28(-87.6383238831073 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark28(-87.64798696234695 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark28(-87.6664348764603 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark28(-87.68947720460467 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark28(-87.76289716099627 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark28(-87.81710217394323 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark28(-87.82131656758163 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark28(-87.82841389499403 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark28(-87.88387197374894 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark28(-87.90102715363864 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark28(-87.95205672720748 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark28(-88.02394127401041 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark28(-88.03595493241684 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark28(-88.06306869845713 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark28(-88.06504639413801 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark28(-88.06625257756922 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark28(-88.08725460079188 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark28(-88.14578371286427 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark28(-88.14643578370773 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark28(-88.21615624222854 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark28(-88.22166084334664 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark28(-88.23226977116299 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark28(-8.823610821615532 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark28(-88.2494999628411 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark28(-88.26059830273883 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark28(-88.2712651953502 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark28(-88.27182376889313 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark28(-8.832280336285407 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark28(-88.3399378167727 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark28(-88.37357254508072 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark28(-88.38309069943722 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark28(-88.44107127238729 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark28(-88.46642897298034 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark28(-88.48947593638758 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark28(-88.5032120833492 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark28(-8.854979278819158 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark28(-88.56214000911874 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark28(-88.5735531217592 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark28(-88.60580113842234 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark28(-8.86129657979697 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark28(-88.62447271987645 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark28(-88.7277251145914 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark28(-88.73487074969522 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark28(-88.75807737699164 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark28(-88.78225975365082 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark28(-88.80965002400654 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark28(-8.885792727335158 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark28(-88.95475176424479 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark28(-89.00147503146836 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark28(-89.07917926204172 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark28(-89.09557144873143 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark28(-89.1137672660919 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark28(-89.1440137090672 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark28(-89.1521208816721 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark28(-89.15418182772608 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark28(-89.1770886140659 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark28(-89.18068582070089 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark28(-89.19644291426161 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark28(-89.1964597320523 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark28(-89.22902906350348 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark28(-89.24819355192719 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark28(-89.27356743083797 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark28(-89.36862569237142 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark28(-89.41243989997389 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark28(-89.42074087866342 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark28(-89.43839090942436 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark28(-89.51776266766416 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark28(-89.5611965666447 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark28(-89.56508289605752 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark28(-89.57188707950252 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark28(-89.6765728895831 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark28(-89.71501290808983 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark28(-8.97341390778709 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark28(-8.976530586180175 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark28(-89.77326244801691 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark28(-89.77886142504926 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark28(-89.79316660562802 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark28(-89.80557474597435 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark28(-89.81334116921107 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark28(-89.82273772891898 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark28(-89.83377770998713 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark28(-89.85274512237598 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark28(-89.85963527258929 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark28(-89.90010777488607 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark28(-89.9646063605648 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark28(-89.9668454600752 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark28(-89.97918488907115 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark28(-89.99657743137759 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark28(-90.01234388269926 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark28(-90.02229838689519 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark28(-90.04105693896523 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark28(-90.09210971576425 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark28(-90.17535809023529 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark28(-90.1894854206839 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark28(-90.20755515383767 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark28(-90.21811764286333 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark28(-90.24035419474316 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark28(-9.026890237776385 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark28(-90.3133526905393 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark28(-90.314752436374 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark28(-90.33408584240654 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark28(-90.33420103940013 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark28(-90.34467809059406 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark28(-90.34964459646264 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark28(-90.37173137976713 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark28(-90.39610081843796 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark28(-90.40285996895143 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark28(-90.4043010975574 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark28(-90.42210429998102 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark28(-90.48708987409364 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark28(-90.49761916095811 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark28(-90.50445989775942 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark28(-9.050663217700077 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark28(-90.51891130816685 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark28(-90.52257061177704 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark28(-9.053428019272133 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark28(-90.6107614912796 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark28(-90.64477137884222 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark28(-90.68669591948519 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark28(-90.80684831135098 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark28(-90.83222827297608 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark28(-90.84318313124464 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark28(-90.87015554235349 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark28(-90.94968934243926 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark28(-90.95435037545244 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark28(-90.96048438342217 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark28(-91.03156679029783 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark28(-91.0474156987511 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark28(-91.15024158880607 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark28(-91.17106159858358 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark28(-91.1752146299688 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark28(-91.21557976626 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark28(-91.27961025943718 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark28(-91.35687646449928 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark28(-91.42721707258804 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark28(-91.4658271971782 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark28(-91.48399250880928 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark28(-91.51150490613449 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark28(-91.52270196541483 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark28(-91.5378528416207 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark28(-91.58005973669103 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark28(-91.60397322122289 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark28(-91.63170762518322 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark28(-91.6560754159262 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark28(-91.72341114201205 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark28(-91.7897175509695 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark28(-91.80213293714003 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark28(-91.82389912641719 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark28(-91.83252288190684 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark28(-91.8330648251787 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark28(-91.85582255855398 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark28(-91.88886155757827 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark28(-91.90780008996276 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark28(-91.91018248718288 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark28(-91.9166148032138 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark28(-91.95715859104534 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark28(-91.99601695477892 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark28(-92.03609636827179 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark28(-92.09189433327667 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark28(-92.09931032122634 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark28(-92.10593093834463 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark28(-92.11329051064818 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark28(-92.11590820531399 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark28(-92.12037383341722 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark28(-92.12733914216496 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark28(-92.16908156269848 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark28(-92.18344113865564 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark28(-92.18560231240482 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark28(-92.24753272040125 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark28(-92.25027180662877 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark28(-92.25469124938964 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark28(-92.26298235015919 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark28(-9.226464913753347 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark28(-92.26939475587668 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark28(-9.239935898957611 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark28(-92.4087221747749 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark28(-92.44322787094481 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark28(-92.48875239317546 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark28(-92.4900192458507 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark28(-92.50844424117194 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark28(-9.2537287864007 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark28(-92.56920756203581 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark28(-92.59234456922711 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark28(-92.59347785241626 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark28(-92.61406007296209 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark28(-92.63708397849675 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark28(-92.66215636052183 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark28(-9.266979383642337 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark28(-92.6707609278016 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark28(-9.269917335585063 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark28(-92.71263673153014 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark28(-92.73022393900219 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark28(-92.77217352993976 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark28(-92.77282409270566 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark28(-92.77821717712081 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark28(-92.78267143634919 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark28(-92.79580967819103 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark28(-92.79790880576064 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark28(-92.82657456373533 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark28(-92.85266012445189 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark28(-92.86372182591013 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark28(-92.88575174308187 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark28(-92.92643919094594 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark28(-92.93925772132414 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark28(-92.99752825099989 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark28(-9.30416086700967 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark28(-93.06402246907506 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark28(-9.307668723479324 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark28(-93.09467219882997 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark28(-93.09544098208997 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark28(-93.11683474092334 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark28(-93.14699314024686 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark28(-93.17208287741015 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark28(-93.17264017710704 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark28(-93.22596660678897 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark28(-93.22832382313804 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark28(-93.25928259381267 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark28(-93.29043329195915 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark28(-93.31442181770836 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark28(-93.3543603646423 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark28(-93.35449571347615 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark28(-93.38982827704343 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark28(-93.39376535002167 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark28(-93.43281265453393 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark28(-93.43524070486473 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark28(-93.43694717445476 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark28(-93.47878213261941 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark28(-93.48483884061307 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark28(-93.49467576734052 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark28(-9.349815667256209 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark28(-93.50945599355921 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark28(-93.5212391886866 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark28(-93.52200474893357 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark28(-9.353460493111584 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark28(-93.54720110197347 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark28(-93.57115545492488 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark28(-93.6303056749002 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark28(-93.64374801066124 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark28(-93.66563352471759 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark28(-93.70466362515748 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark28(-93.7126968817865 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark28(-93.71871095177313 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark28(-93.73212411611999 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark28(-93.73725507897721 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark28(-93.82805735889622 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark28(-93.84001238387273 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark28(-93.85847897437414 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark28(-93.88354124847673 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark28(-93.93086574641455 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark28(-93.96006658449112 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark28(-93.96736560199143 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark28(-93.98746751325137 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark28(-94.02979299118886 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark28(-94.03406405415451 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark28(-94.03678608913715 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark28(-9.4052558247933 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark28(-94.05908893406851 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark28(-94.10149654574 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark28(-94.12705167854165 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark28(-94.13338337860833 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark28(-94.20763949009007 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark28(-94.22931248203025 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark28(-94.24506837516257 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark28(-94.25047481964756 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark28(-94.25411512382446 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark28(-94.26776605541254 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark28(-94.2824858605812 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark28(-94.30544098617837 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark28(-94.30798337041412 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark28(-94.3323969732436 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark28(-9.439683845395706 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark28(-94.45201514208676 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark28(94.51827435149957 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark28(-9.457761468450855 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark28(-94.6043816621716 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark28(-94.61621061271653 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark28(-94.63200873145678 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark28(-94.68087399861989 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark28(-94.70493683351758 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark28(-94.71299302593947 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark28(-94.71800348294607 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark28(-9.473401808083537 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark28(-94.75630599644174 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark28(-94.7847260689136 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark28(-94.7880411419354 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark28(-94.84230795546868 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark28(-9.487861779750546 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark28(-94.9134151333698 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark28(-94.916048462483 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark28(-95.02103123512242 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark28(-95.03313465430617 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark28(-95.07101752673796 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark28(-95.07455442807422 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark28(-95.15516921800327 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark28(-9.515830614960635 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark28(-9.521453539433523 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark28(-95.22222391163511 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark28(-95.24556711821137 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark28(-9.525051464266255 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark28(-95.26108676626399 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark28(-95.28194826100238 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark28(-95.29536238020108 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark28(-95.31391846144047 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark28(-95.33587923793618 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark28(-95.3462409824736 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark28(-95.35589022825665 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark28(-95.36071272532125 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark28(-95.37840217656523 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark28(-95.39364238786594 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark28(-95.40156728461318 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark28(-95.47036379407308 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark28(-95.49166980532222 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark28(-95.51079812724588 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark28(-95.56580136273493 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark28(-95.59378960359417 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark28(-95.6258768585595 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark28(-95.66599281270445 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark28(-95.67699153651328 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark28(-95.68205553304865 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark28(-9.568515191177227 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark28(-95.7153326548441 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark28(-95.71798811446459 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark28(-95.77371150906248 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark28(-9.580335064564835 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark28(-95.80338960996437 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark28(-95.81098321847152 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark28(-95.81910560120703 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark28(-95.82113356969147 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark28(-95.85474946876336 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark28(-9.588357311702467 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark28(-95.90982502182497 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark28(-95.93331744354225 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark28(-95.99352133546215 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark28(-96.01747951071874 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark28(-96.03662453499322 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark28(-96.05607811978985 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark28(-96.06464159571073 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark28(-96.08772267226232 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark28(-96.14471050545188 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark28(-96.14583528824376 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark28(-96.15167637416577 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark28(-96.15864840630195 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark28(-96.19159315388795 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark28(-9.622053398978764 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark28(-96.23228788620762 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark28(-96.26106280979599 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark28(-96.26582004236217 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark28(-96.3086946555837 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark28(-96.32825036133012 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark28(-96.33253088919001 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark28(-9.635357849925796 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark28(-96.36872738646214 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark28(-96.50662494966056 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark28(-96.54793944934741 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark28(-96.55172307212898 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark28(-9.659728543053504 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark28(-96.60132084349276 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark28(-96.628107610952 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark28(-96.66950846066212 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark28(-96.7057262871798 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark28(-96.747420823207 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark28(-96.7699198463215 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark28(-96.79132026333579 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark28(-96.80571508294446 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark28(-96.82578874783643 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark28(-96.85904324917871 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark28(-96.89981303117989 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark28(-96.90853328153398 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark28(-96.9250462465959 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark28(-96.95910253235371 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark28(-96.9987536352577 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark28(-97.03172850345459 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark28(-97.04154880697533 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark28(-97.06187718369917 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark28(-97.0685003154105 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark28(-97.0755909775207 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark28(-97.1132293681334 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark28(-97.14246943757993 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark28(-97.20058141415306 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark28(-97.2098095999425 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark28(-97.2506061116568 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark28(-97.25664027949281 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark28(-97.31496040098399 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark28(-97.31678171782707 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark28(-97.32581485724128 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark28(-97.34204022077878 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark28(-97.3739132736182 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark28(-97.38058498689408 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark28(-97.45923153208254 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark28(-97.464821653183 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark28(-97.48434655588571 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark28(-97.53385511363616 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark28(-97.5857572873481 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark28(-97.60727440094776 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark28(-97.63127926385846 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark28(-97.63508809698524 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark28(-97.67828380367484 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark28(-97.69871001916057 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark28(-97.70345509026164 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark28(-97.72860947140248 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark28(-97.74414660705757 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark28(-9.775029491751084 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark28(-97.82344066756127 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark28(-97.84463029083503 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark28(-97.88502088482534 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark28(-97.94756835667266 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark28(-97.95477915875719 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark28(-97.96626131595234 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark28(-97.98564574069594 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark28(-97.99679227822726 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark28(-98.00079974178912 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark28(-98.02072848712254 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark28(-98.0302528934946 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark28(-98.05400244222074 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark28(-98.11606792207985 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark28(-98.13001240279384 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark28(-98.14537836349184 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark28(-98.15234411792221 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark28(-98.17434083442255 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark28(-98.17539058686317 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark28(-9.818110168921692 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark28(-98.1822931384289 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark28(-98.20669931329206 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark28(-98.23655535847445 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark28(-98.24774684981254 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark28(-98.29764485688908 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark28(-98.38412659480026 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark28(-98.39881584535155 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark28(-98.40071667605818 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark28(-98.40739892712256 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark28(-9.84541727823131 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark28(-98.46337803905053 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark28(-98.46926526804694 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark28(-98.4874408366984 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark28(-98.50860231794698 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark28(-9.85587619776463 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark28(-98.60245219593158 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark28(-98.64154463431902 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark28(-98.64809790493617 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark28(-98.6491467742242 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark28(-98.6772764796626 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark28(-98.73548355462307 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark28(-98.74318704250338 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark28(-98.7706121447514 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark28(-98.77158382026742 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark28(-98.77610584537386 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark28(-98.81623742572422 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark28(-9.883231814135044 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark28(-9.901676184089013 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark28(-99.04348671666455 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark28(-9.907019241101338 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark28(-99.0801852476974 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark28(-9.909426766026883 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark28(-99.09860816988491 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark28(-99.10889205212399 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark28(-99.12790055736835 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark28(-99.18369917157645 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark28(-99.20886245273506 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark28(-9.921124173360909 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark28(-99.23484820894 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark28(-99.30364141996712 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark28(-99.31002446985124 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark28(-99.32858642032396 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark28(-99.34395544476669 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark28(-99.36819495825691 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark28(-99.42971606956748 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark28(-99.4737131781372 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark28(-99.54024146660868 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark28(-99.59092897926386 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark28(-99.60768155274083 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark28(-99.62830148726883 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark28(-99.64267467214746 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark28(-99.65285226132188 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark28(-99.66605034423492 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark28(-99.69034364864508 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark28(-99.69333647060157 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark28(-99.69465467439342 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark28(-99.69564223707334 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark28(-99.76697430270545 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark28(-99.80303854640499 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark28(-99.85612139871449 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark28(-99.92919040527208 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark28(-99.94132226976977 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark28(-99.95771837873188 ) ;
  }
}
