import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,1.592372643888254 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,95.91827904346616 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(0.043061996725390524,4.7477838728798994E-66,-2.3864294136235653,-58.38826076591126 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(0.12668948991947282,-2.211025191793744,5.038196818804583,-2.4171714826331225 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(0.7957165356784808,-5.345529420184391E-51,30.268951123935313,-28.107803622685203 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(100.0,1.3684555315672042E-48,-100.0,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-5.293955920339377E-23,96.29301013000716,100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(100.0,8.86097344742484E-6,-100.0,100.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(11.52769730361112,39.571241653203714,28.28012650493727,-74.80348499394319 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(1.2455855201296664,-3.0814879110195774E-33,77.78457316306842,-74.3971498110159 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(13.323294713886241,-12.411318024029995,33.78153271837968,-16.230013894968593 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(14.319212730296996,95.18259411226475,84.4119200208828,-4.833572642461164 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(14.750833907906298,93.225851235395,96.73517774914856,24.456480281870768 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(17.468777776545608,6.051938796526656,70.46779693170168,79.67830418946258 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(-19.656351092780792,20.510254659426174,50.90921412115277,59.61939510471079 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(2.1752584021720054,40.62333962712884,30.299603509926044,52.327275663180075 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(21.91438732544347,-3.606632272572553E-130,100.0,88.45165001144997 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(22.323590734298712,1.0691058840368783E-50,-44.81680696977821,-48.0958152144918 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(-23.056427889547848,-30.74778588625591,-75.92765753164119,10.928463236033295 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(2.385038045952953,18.995186728341125,24.152214282410696,52.533295321978926 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(25.739581845621842,3.552713678800501E-15,-68.41606578973064,17.151888900106634 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark61(2.9836987962345853,-4.276423536147513E-50,100.0,-79.1607806747551 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark61(31.26200475142833,-2.646091050171152,4.725038024209219,23.89087588341483 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark61(32.509445507048724,37.71227975274475,86.24875310482986,-16.027027845036383 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark61(32.74754689504081,77.17370654626322,38.0983415542301,28.446567009137112 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark61(33.774107690792846,2.967364920549937E-67,-100.0,98.55449962744004 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark61(34.24974667102762,-0.5574426868582162,-2.769318803738545,-78.05986118584867 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark61(3.8134232242305277,-8.552847072295026E-50,100.0,-100.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark61(43.82551500200403,-43.964385307317016,3.7321281491221328,-0.9968412999671834 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark61(45.46326077087352,2.2930265686498643,-34.929978351318255,68.16328409490319 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark61(47.51135073240894,0.0,-28.33500923584034,3.3492004762262826 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark61(49.79595006521776,1.5487920663438217,-68.13955078209115,-66.16333971475719 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark61(52.06223103828873,69.38847337214787,-34.254282737501796,-39.55748617259187 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark61(56.97851875316724,1.6867516709168837E-80,-5.955312795964962,-30.255833379625724 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark61(57.122993017766476,6.938893903907228E-18,-15.227913135982519,15.10566094754978 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark61(59.17320135560882,-1.232595164407831E-32,30.14464827501598,-51.73543174315889 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark61(59.36507189585796,9.495567745759799E-66,-57.83940818926243,-100.0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark61(64.6192571482919,-41.67310451795419,88.49121732404265,-60.50136203524541 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark61(64.85189766769233,3.542559407063113,28.528470359555158,36.32929990408596 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark61(67.5023808664877,-30.888627874545573,18.115721244624957,18.498031747317164 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark61(67.56310474642555,12.431046624398164,81.59917212272015,75.24919518407168 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark61(67.82552771440521,4.3368086899420177E-19,-49.66133916679905,5.716262427516398 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark61(67.96538837011315,-58.47790542887397,-9.789565313059526,-88.16297608598913 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark61(68.91801692504927,-70.07370227143532,-95.62418575423881,29.53547040213931 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark61(70.47988078869852,-1.6598329902892264,57.10755658044866,94.59704628086402 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark61(72.9393731197984,-35.79231140310944,-97.20057310444379,-60.78060742125191 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark61(7.41141667309477,-3.469446951953614E-18,8.79419197235798,16.336432374008286 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark61(76.62874296776621,2.1382117680737565E-50,-100.0,6.5430170106594066 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark61(81.72326241528393,-1.5192908393215678E-64,71.25603922523146,8.711549840548605 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark61(83.84038909106715,3.7092061506874214E-68,-18.96500818346476,98.37869954739085 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark61(85.7230662711416,-8.881784197001252E-16,51.073221049900354,30.677988604262232 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark61(88.79131139607773,-53.77432921556118,40.479582012259726,-5.4625998317431765 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark61(99.68123920245716,3.016885871221266,-11.370173559959483,26.3134400182443 ) ;
  }
}
