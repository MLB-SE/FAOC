import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-785.7003263133884,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-646.1265739957051,82.9888064820212 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-646.9069804902337,100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-647.9971107831857,100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-648.5664186410897,84.73599510574516 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-649.0264865773711,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-649.0582283926158,90.54738109920672 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-649.7724163288428,26.98735901555878 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-653.8528895585871,12.687213246450767 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-656.0108785932902,100.0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-656.1536349744756,100.0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-657.0550885994523,100.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-658.8272873497749,99.2587156271757 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-660.7391170928613,97.95299667823022 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-661.5189990241132,45.58835046345297 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-663.7385188060028,100.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-663.8703281644487,100.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-664.6327639503518,89.03735935197619 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-665.6625560494141,42.42583314181358 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-666.7825380555877,100.0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-667.1866271019014,100.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-667.3107115374742,86.6320735241537 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-670.3445376648463,50.1674737211532 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-670.4776147610089,58.896641314440444 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-670.7860090569791,100.0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-671.8622176184581,45.18825695783099 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-675.0617304532451,100.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-679.1370065508283,81.74177278929997 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-679.5136144661243,100.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-681.735395939964,7.105427357601002E-15 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-685.8878961410467,80.26677463898451 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-687.2094492781465,23.11841800541031 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-690.973791271892,19.334520222371523 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-713.3112988927818,50.919521172254406 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-735.0014898273604,23.09093229957537 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark45(-101.26410182286156,-653.8499583862365,80.75789811588191 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark45(-105.93941286119554,-710.5938021290532,46.85401152799088 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark45(-106.42168184692527,-667.2640000712216,99.75370330746324 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark45(-106.58538566391609,-662.4337607209475,20.630819501388714 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark45(-107.74402550625561,-639.157867143601,91.4116716802412 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark45(-109.19422223830085,-648.5948957856909,9.91343600998809 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark45(-111.62211149066195,-654.8425501069707,100.0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark45(-112.19739825363843,-650.7081138717213,100.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark45(-114.587832974329,-647.6299872213326,10.65282945503212 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark45(-114.60584758544348,-686.9651380773048,100.0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark45(-114.7106605040401,-636.770280930708,54.90821981365892 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark45(-115.97766020375536,-638.2144277977656,38.52200321463616 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark45(-116.17108023530889,-688.0828473906918,52.09275763322756 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark45(-116.66119246009305,-656.5975718870876,16.293603487574842 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark45(-117.5217407042398,-649.6715027402378,56.97179979888634 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark45(-118.96235565532051,-635.6389897006653,34.03352173714296 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark45(-119.9667502100907,-636.4554017554043,43.60746869618882 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark45(-120.92911862823436,-662.4439526561073,36.040854818939636 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark45(-122.68674891323998,-654.4600243673586,100.0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark45(-122.6937636237518,-642.2431811142043,15.873887068539759 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark45(-122.9182577273678,-623.8767091255718,66.04730411629382 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark45(-124.42432792391868,-673.2204796847722,49.71783813199525 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark45(-125.45032639852312,-628.7084057040265,21.524946361121522 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark45(-125.98517152795735,-620.9878421648019,100.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark45(-126.15341741307468,-664.4148560862034,95.43606571201963 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark45(-126.79609570571168,-641.3438669096739,100.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark45(-127.21992256367957,-635.2540341289492,100.0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark45(-128.4751333756786,-631.6641375977749,9.503553118295713 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark45(-128.78992371423226,-618.5079797914374,71.73948194569755 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark45(-130.34511745413798,-652.3463834300462,37.41663952181915 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark45(-131.02856412658784,-621.5156557916574,90.03646732277414 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark45(-131.38823754599343,-643.5630949757387,100.0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark45(-131.82628801846624,-634.9974254937242,20.157736535278474 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark45(-131.88913358702766,-630.0602989553863,19.03517336923389 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark45(-132.4277378752319,-648.2573313042313,85.97496534361832 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark45(-132.64792565232688,-674.4538995217365,100.0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark45(-135.02138953402778,-622.6065997382042,22.59650944053662 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark45(-135.43557684724186,-650.8403575948747,97.04651539625686 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark45(-135.5850399091883,-628.5620878686309,12.553403781641563 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark45(-135.6413637374672,-621.9775219221701,48.5312859619618 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark45(-135.67533441844435,-614.1183593755736,67.51591156249884 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark45(-135.73920270256184,-624.6200643846058,54.19171858251141 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark45(-135.73958207595288,-614.7331820825982,48.152524471992194 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark45(-137.23759939599833,-629.8557715059326,26.402409412145616 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark45(-138.36496013023475,-614.349331278688,95.96359094941393 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark45(-138.57500177561604,-612.1433003202433,54.97059515047309 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark45(-139.39765428498575,-633.0466799297046,48.755798977545965 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark45(-139.42364335616324,-607.8893719556947,99.32187250313333 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark45(-139.65375071489822,-649.6922550875342,37.4521917672285 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark45(-140.44084424144097,-621.1739018358651,32.468109114772204 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark45(-141.495471953955,-606.4375509354977,4.421334608248344 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark45(-141.53071707098923,-642.1411011714722,1.7258119108284546 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark45(-141.56753249249485,-615.8179761752093,100.0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark45(-141.5690074984184,-666.4168319616324,41.78470111372954 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark45(-141.90081441926642,-631.5706799916924,49.75062923319541 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark45(-142.4335559136186,-604.0745817656086,100.0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark45(-142.51311151182261,-694.2317635623607,39.410199164346125 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark45(-143.69985821280935,-608.642839377891,55.86278135833638 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark45(-143.88427079707776,-610.6224687420954,56.85213416323754 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark45(-143.99169714007232,-650.2447119766944,98.18839381704959 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark45(-144.05896524306118,-610.7197242710315,43.87628137498072 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark45(-144.6098092644512,-614.9677935224374,87.72377584038514 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark45(-145.03013903069052,-618.7512557477814,51.706254713522696 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark45(-145.41046208809774,-603.347433716849,69.88873163438922 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark45(-146.17619770471214,-636.155714991926,100.0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark45(-147.31610735276354,-660.2270391765168,43.71534569704622 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark45(-148.08494574875553,-609.5392829118454,83.55994977231822 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark45(-148.17951941705385,-651.1557685487705,79.67490082463235 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark45(-148.18425770436184,-639.2838616155143,3.123936069920177 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark45(-148.49052745590615,-597.784348694502,38.673660784210796 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark45(-148.52550673039667,-638.185862190886,100.0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark45(-148.85087842160476,-620.8141788148164,8.12730310872469 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark45(-148.97681922895268,-604.3544621132605,57.783169458819884 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark45(-149.40798934877714,-646.7055217801154,69.18766927363899 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark45(-149.60793056888704,-618.5742142469272,65.30208716931514 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark45(-149.7495832527059,-623.7463069284524,65.1588705877954 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark45(-149.8115616432337,-612.2795287165238,33.68259909358164 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark45(-149.85791763375678,-610.8506925618029,18.87722505398044 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark45(-150.10128104106204,-613.1532277602538,14.761898136311274 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark45(-150.16828822746078,-629.42204538485,74.67402226382023 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark45(-150.46010284093856,-639.2826378200621,48.59510058582771 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark45(-150.545890316155,-604.3073449268242,81.20896835221097 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark45(-150.8237007928099,-624.9973516535266,100.0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark45(-151.33065506193245,-597.9878886447522,72.68614871356164 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark45(-151.64568461868595,-602.4695786559774,92.91804571308194 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark45(-152.23676428021378,-598.4349689593984,43.97135487528456 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark45(-152.55691525858919,-606.7694924897577,100.0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark45(-152.84633866485683,-642.7176344673203,45.172158367808976 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark45(-152.8561232531822,-624.1157364299256,26.29504868451133 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark45(-153.12223029857984,-605.6080241669669,57.20075458685429 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark45(-153.2117335431035,-642.5736211132727,38.63865246130652 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark45(-153.66773025534826,-622.3672250725947,13.38837729747253 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark45(-154.30589879638515,-626.263951876318,83.72794454058374 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark45(-154.94373648416342,-599.0747125282896,97.0138820160135 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark45(-155.391487382237,-600.4173231308993,43.55811435332632 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark45(-156.2198564404183,-610.1667763666827,100.0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark45(-156.7101128822294,-610.4947097652454,54.9083143797948 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark45(-156.9056665422695,-591.2488429346012,37.8870627400334 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark45(-156.98770219842015,-650.9550511520509,100.0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark45(-157.11508343003527,-617.6914246016569,86.4394693513363 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark45(-158.0066905345764,-610.3551350145711,63.95679957575226 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark45(-158.08012549383523,-628.1471560078977,30.75782092729395 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark45(-158.2111758236506,-602.7585734113065,39.20816350515551 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark45(-158.51972877122378,-669.915769110732,100.0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark45(-158.72134072603143,-605.1094864939247,35.24963546803684 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark45(-159.1588637100797,-589.7543260413039,100.0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark45(-159.44423981690113,-589.337591697595,12.79188547435308 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark45(-160.87568767082516,-599.8017505057423,36.910573801324716 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark45(-160.9077606376989,-587.1061727108374,40.32109689519032 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark45(-160.93640653849673,-617.9945226117817,100.0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark45(-160.95040468764805,-585.1702853655653,8.874941935075142 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark45(-161.00522729185522,-604.9196736944183,27.74147227157539 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark45(-161.1074637067074,-639.290122210561,100.0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark45(-161.1710127495494,-615.4804202200304,72.33055136329327 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark45(-161.44718462070375,-624.5427985196563,100.0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark45(-161.59810273872574,-611.9031071273997,69.35055193412248 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark45(-161.91239199403483,-587.1940792392791,91.922448806523 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark45(-162.26816721580914,-638.6445583660704,46.00691087698391 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark45(-162.43557920548056,-585.0313372977217,100.0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark45(-162.50374351878384,-585.8792518805484,38.453807662208476 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark45(-162.58717475561087,-604.6061978138498,47.945093726756994 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark45(-163.2333568469528,-609.1322643435133,97.20545182914876 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark45(-163.37279416040457,-611.949668630359,79.04968589197296 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark45(-163.5758379076553,-587.4723217384044,100.0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark45(-163.86431526329355,-641.455806532859,19.834409955118176 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark45(-164.1890270319619,-604.8686069586944,45.522435613567836 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark45(-164.2494364525016,-647.5800144483045,38.68958497945644 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark45(-164.32131820914216,-616.7884472674566,86.09430990000823 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark45(-164.38380315836758,-595.1154213885427,70.21884340502935 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark45(-164.5318022837543,-588.6973495790719,89.3900359796493 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark45(-164.66788656953855,-587.0659369352555,0.9745849089047169 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark45(-164.72919741690544,-598.4579830686666,6.954190907214723 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark45(-164.73883186486094,-588.1289922690987,71.7516983259597 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark45(-165.8087206818786,-591.5841163142817,84.45765469365256 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark45(-167.0655356214369,-589.4282679692654,11.019404574293802 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark45(-167.08708387946203,-616.2731615307341,28.622338302839267 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark45(-167.95766195853736,-628.5088621383653,82.4267680098483 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark45(-168.2515264831137,-589.770896606471,12.723620869299637 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark45(-168.4863723609458,-590.0544307033423,22.17212608104211 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark45(-168.60212446524002,-580.7757770807214,37.73581296543341 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark45(-169.18082105555294,-666.0262986462542,23.594326982131975 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark45(-169.71048419687324,-594.3353952492772,-42.589300369941526 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark45(-169.76376476386002,-681.0650193998546,34.977709324817546 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark45(-169.88876043199133,-606.6395182697306,44.08132735012853 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark45(-170.52996995053462,-606.4773671215846,31.1295721914704 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark45(-170.5750584665162,-654.5241504265,75.56933430484696 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark45(-170.5880343001816,-635.4292797137857,51.69916290248639 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark45(-171.1971785746532,-575.1940760899529,5.708379521003209 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark45(-171.60464342845495,-583.7587719743265,89.30708279012032 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark45(-172.25681649778986,-584.3810665825607,26.870230595110485 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark45(-172.44355526587654,-598.1375268349362,52.359298983611325 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark45(-172.86530393228955,-598.7755335925582,16.98384020665536 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark45(-172.96416426230297,-577.1528360173701,32.35354583479699 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark45(-173.28770618970896,-589.1702268583404,100.0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark45(-173.5161861561834,-586.4824028231883,65.36652703506238 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark45(-173.76053155801972,-605.4193206024589,100.0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark45(-173.86653658615398,-577.8172482344612,100.0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark45(-173.87148529517333,-616.2107024859306,50.0090211619395 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark45(-174.37712534964805,-650.2754843568063,43.21433525097535 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark45(-174.44064294569512,-574.8825395403638,100.0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark45(-174.49408477089955,-596.5144983102833,51.473699484390416 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark45(-174.52207313605115,-604.4326644914912,39.14141027730642 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark45(-174.6413234865401,-602.9403950808825,38.81050022708189 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark45(-174.6539984376841,-627.1130539694739,23.755172525508456 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark45(-174.71792602891912,-649.829002319469,82.75105059391478 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark45(-174.76605817910718,-601.2071605200724,55.336414302827194 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark45(-175.3364263718186,-622.5983828184474,9.801100809132762 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark45(-175.83155973939876,-581.6708599820747,100.0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark45(-176.33464988574408,-574.1330700966823,100.0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark45(-176.39273673156575,-627.5201719369865,19.41811523019493 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark45(-176.49464612895292,-573.7951960164813,61.343406818855186 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark45(-176.69420682925394,-620.6589277968113,17.837984150004587 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark45(-176.7078695944626,-585.2772882708623,100.0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark45(-176.74163938285437,-607.8893437527479,100.0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark45(-177.09390048991327,-615.5789141797591,59.281637143438445 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark45(-177.1509602220433,-581.1425069215953,100.0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark45(-177.6803221987808,-587.6308364351441,60.8544946735266 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark45(-177.70141659580526,-577.5037401278339,100.0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark45(-177.99991335576811,-590.6787883454007,93.82092578902001 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark45(-179.06215510657222,-610.8904657707824,61.284072197187164 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark45(-179.44704842798842,-579.2141941863338,90.99374672525528 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark45(-179.58978818016246,-588.5549555407581,20.91965460309899 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark45(-179.8942873931946,-575.2936481757481,100.0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark45(-180.55940846114834,-628.2147842449201,42.80679421223914 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark45(-180.57956683215622,-569.7514514042352,90.16868398362948 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark45(-180.69735085904938,-596.2370602147301,27.36704125649247 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark45(-180.77091235567272,-605.5318638432717,61.0257666642521 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark45(-180.9525651314193,-596.5543165361138,100.0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark45(-181.45436150331506,-564.9297298680975,2.3717233266729075E-4 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark45(-181.48884195838684,-587.306232132065,48.66856177584677 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark45(-181.60000383916812,-599.4501793930467,1.634382353627302 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark45(-181.6386751917512,-590.4433133461338,45.058896208793584 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark45(-181.7926243785461,-569.9720931307469,5.658947288671897 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark45(-182.36945794746916,-563.7893629132288,30.401840489919294 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark45(-182.58947320802656,-607.0933030637849,83.38748663592966 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark45(-182.84143569757137,-572.7575803645988,32.34307069316657 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark45(-183.06855521381092,-617.0945531068219,67.89287608877018 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark45(-183.09678930979166,-675.1591030384134,15.81602007513439 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark45(-183.20749127827017,-635.1899152184982,66.73669102088004 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark45(-183.42974024900312,-595.5994558097506,52.623434132307835 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark45(-183.53937297587822,-598.5638889114763,93.79697448452222 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark45(-183.66991269621508,-573.3170438641378,27.586139130001868 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark45(-183.91698702486394,-573.7976118059134,44.222645605936385 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark45(-183.97207426320261,-563.923373293257,43.11992209308244 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark45(-184.14502614372287,-623.4795536827419,53.92223310194666 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark45(-184.21749782691333,-580.6561793486995,52.385430226799485 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark45(-184.7581086491865,-641.9847188946034,99.83178294619827 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark45(-184.90905481406415,-595.1103157663009,88.047063663583 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark45(-185.16661204989063,-561.2139906940266,30.053946220675044 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark45(-185.2902349933934,-619.7968827350993,15.662761749804908 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark45(-185.97758152914503,-623.5417660150592,15.6769589393257 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark45(-186.20886342303442,-592.8490102815397,91.39973063069326 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark45(-186.39138246565395,-594.779997510486,47.13827309239757 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark45(-186.48320378869843,-600.714136695945,68.09178519835916 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark45(-186.76875733096483,-563.4668595877225,40.543518132549764 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark45(-187.10494458386225,-563.2445412167998,53.1175231303327 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark45(-187.16421924499758,-567.9367910728172,21.810990083992877 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark45(-187.274965920351,-570.1968565079528,87.90371121922402 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark45(-187.46442023430652,-611.9910623067021,49.95377300852343 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark45(-187.85706625917237,-564.3312795036649,40.46767667559442 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark45(-187.91174283216318,-561.2888227707161,100.0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark45(-188.01852065506577,-569.9198589070733,64.25423654304964 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark45(-188.10589727187795,-564.9743468801742,37.77822655962913 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark45(-188.17040938642782,-566.9069429664198,4.939618730799047 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark45(-188.22298053323715,-562.3178741177089,99.18406774739003 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark45(-188.47945557032932,-585.8161800558664,73.72164942304042 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark45(-188.48705782878483,-560.4620241767308,82.42078294832159 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark45(-188.49166911957315,-619.948205293152,100.0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark45(-188.6056021633574,-575.3652597334927,94.551268883152 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark45(-188.6430580773418,-618.6612003141272,7.570868600779846 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark45(-188.95600793832924,-559.5976101669637,61.75665724062637 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark45(-189.1306839761567,-607.6777411913002,89.84528082635396 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark45(-189.29111348955897,-568.9698390446113,100.0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark45(-189.3352335643705,-556.9426929318594,67.59468981427631 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark45(-189.39699687794854,-608.3892244847347,98.26587134234046 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark45(-189.457719076712,-567.5758589575794,31.21984198762641 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark45(-190.51296645755463,-594.5044436670604,94.86098858802725 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark45(-190.59294477352395,-557.1626869009046,100.0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark45(-191.44829550915074,-568.0415750059093,60.00406500802583 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark45(-191.4905515500985,-583.6683427574349,87.51084300228149 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark45(-191.81132640707122,-572.3228425661143,100.0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark45(-192.11348563284324,-555.5457083487116,100.0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark45(-192.2319136280658,-591.6259160433646,5.424836842227599 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark45(-192.4156180638617,-554.921876604977,76.03977062399201 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark45(-192.42030285753373,-596.096130513973,74.14605544466781 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark45(-192.6858775719681,-565.097904979096,100.0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark45(-193.26561201014388,-563.7817482841905,25.70369061763087 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark45(-193.53587325176443,-562.4194595277964,45.99877957918713 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark45(-193.5630504884947,-608.6445888906825,65.34246138529934 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark45(-193.76749604137632,-569.1138746986921,2.326562363172286 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark45(-193.82068330252815,-573.4760102846349,57.65297283025757 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark45(-193.98471696606276,-556.230168158905,86.2578691675678 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark45(-194.24988368317037,-552.4721204633366,61.828825540475634 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark45(-194.7486592134379,-565.2033773051583,4.540779212814044 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark45(-194.75751545505153,-572.1733043918214,9.802097924988567 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark45(-194.82918883974847,-566.24394967538,25.877882095219235 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark45(-195.33269546747724,-575.633130015637,48.985111603523734 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark45(-195.94894787747197,-561.750724844626,100.0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark45(-195.99607942553033,-551.2215418353834,100.0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark45(-196.0599903702252,-580.3606693090038,68.8851649998978 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark45(-196.17975388031246,-599.5845111921162,56.378193581145695 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark45(-196.27708439353688,-556.0311965324951,44.769065669822766 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark45(-196.29453646429556,-550.8332387294187,57.485210997718895 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark45(-196.4297232279124,-553.5099184926141,4.059477122857729 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark45(-196.4607008686155,-549.8728697397453,82.74076834545852 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark45(-196.59385219794427,-562.4551831400702,83.79564841573776 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark45(-196.84843080085815,-583.6145758639642,98.64246536054341 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark45(-197.09650479361034,-582.1304665599869,100.0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark45(-197.1939165036122,-588.4092543868229,32.37149092613505 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark45(-197.5475012918225,-583.1035561848535,9.823977833754157 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark45(-197.63553828600965,-562.7283367534293,26.46210056598541 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark45(-197.8619361331222,-560.3466266713629,88.19488227215658 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark45(-197.88020959929938,-634.2183371249046,18.2036329589001 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark45(-197.99966566344816,-548.5646493598274,61.79904646846591 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark45(-198.0861732612048,-547.941945360857,30.21037705978665 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark45(-198.22084288211238,-565.6969290272034,80.63834378381858 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark45(-198.2886464399283,-557.6045807804483,100.0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark45(-198.79540640212863,-556.6296581349238,100.0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark45(-198.9646244204869,-617.2832839603278,80.32561151509313 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark45(-199.13085002449142,-568.4426041196427,88.55733132811301 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark45(-199.5401670779655,-548.9094174100678,100.0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark45(-199.66366442910714,-549.7081621207163,100.0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark45(-199.6906389459962,-595.3736103034976,100.0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark45(-199.6946479804715,-581.5445315780115,23.0686907181842 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark45(-199.7152628133039,-565.8706864991755,70.91625227800554 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark45(-199.71997465704848,-548.2112873251793,93.3501267088136 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark45(-200.2735942485482,-581.901673091867,99.99860907767419 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark45(-200.44632445958783,-546.0987343186944,15.634373815231498 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark45(-200.54101647741106,-549.9976227661618,64.83756338791054 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark45(-200.76884625167963,-558.658381599022,43.699698179817915 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark45(-200.82518539964525,-556.8654126932669,81.51490485101866 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark45(-200.86196040606993,-552.6725090359042,100.0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark45(-200.89582917807405,-596.408409207202,12.293559984886613 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark45(-201.1199014142916,-553.4203361452641,31.80802709513449 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark45(-201.52143751009197,-596.3037862592621,83.74486039604612 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark45(-201.72970234707628,-571.4026058568232,6.653736168952747 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark45(-202.1989240431604,-563.5129697245267,10.356348408649069 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark45(-202.6382716918396,-555.6245805470945,100.0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark45(-202.64984572722932,-571.4411816403415,100.0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark45(-202.74990757312918,-560.0181580135894,100.0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark45(-203.04245685965648,-567.3913868853068,94.72006919563452 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark45(-203.2716691171812,-546.5963581985362,97.8841606514637 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark45(-203.2973122451674,-554.3258176643151,93.17126316884091 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark45(-203.30109810935062,-578.9563214505434,15.236699137399583 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark45(-203.45777279300984,-545.8449382908552,82.63048911994085 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark45(-203.47340719062143,-542.8133059639085,74.03743672169227 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark45(-203.55387936282673,-582.9848063176726,41.17237804152501 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark45(-204.48500070206157,-556.8326987418329,4.473903419989256 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark45(-204.9109553320963,-593.8574010089619,26.8535200367819 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark45(-205.55482309868827,-598.479452480216,96.15716926286083 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark45(-206.30663726355874,-542.0003292695552,100.0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark45(-206.78773761025653,-595.3039777705875,42.74485179140461 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark45(-206.91815077808224,-544.8516764125992,83.1456658484594 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark45(-207.0290565574308,-563.1028821428536,16.72638357599112 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark45(-207.13590122412768,-657.8827602694982,51.16266817806462 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark45(-207.3965713954448,-573.7369594766104,29.774128377575693 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark45(-207.80958376495389,-586.6241946440016,25.93040456596667 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark45(-208.0948670002509,-618.577072252049,99.65531174885032 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark45(-208.12639783389045,-581.7401220436905,26.39790184479112 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark45(-208.76487373553726,-539.2211173461558,4.185408871183441 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark45(-208.79929721239634,-548.8566482155526,1.1247670784700183 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark45(-208.87027946777573,-572.9559886531761,11.654750202866637 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark45(-209.26229165295368,-551.6361095293015,44.96521202980318 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark45(-209.41906937401265,-558.0444382804619,74.85902142456479 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark45(-209.54242421785702,-554.0654665198892,100.0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark45(-209.86509619318957,-564.1280273302674,33.719154391622425 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark45(-209.92374780065103,-541.4717886109208,100.0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark45(-209.9931859732984,-545.2847411176847,23.57680745326995 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark45(-210.00573698957987,-579.170995793942,50.68023984063893 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark45(-210.00984328707816,-544.3401591934024,6.579812299049465 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark45(-210.32147390518207,-537.0954092319764,99.09683368154384 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark45(-210.4505056674223,-545.2671401130399,82.20475481444251 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark45(-210.7754395515983,-571.4273656514285,12.859964569516123 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark45(-211.06961058408302,-583.1415686947828,61.798776000198984 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark45(-211.17047521971105,-570.5333291857428,61.1173607703422 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark45(-211.2045711738906,-610.39710748737,71.1534177411942 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark45(-211.22707862248717,-547.8771714104151,7.213378041020496 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark45(-211.2847890938922,-587.4323081034424,75.4423855073878 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark45(-21.142996237773843,-726.9557839680963,16.857392409329037 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark45(-211.62487042892914,-534.6750736822172,74.69068014984956 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark45(-211.68554959297333,-538.2947069543768,67.72378189769626 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark45(-212.1729019370486,-539.036641678455,88.60300264897413 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark45(-212.96835024585255,-540.4430512534224,100.0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark45(-213.05408399582615,-541.9712481121782,42.92715130321719 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark45(-214.00789311737623,-534.5934120880795,18.75057784645871 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark45(-214.0233532229006,-597.5736175253927,88.54557704102183 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark45(-214.42696393888878,-547.250596756212,100.0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark45(-214.45531968327793,-541.4115216940501,100.0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark45(-214.64431420899012,-539.0589394893212,49.8029489059565 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark45(-214.73273233320745,-552.5742915493323,61.7558792788396 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark45(-214.97152695580954,-552.084533613773,42.73200233342703 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark45(-215.37395582634915,-549.9841136235626,41.0196418057171 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark45(-215.91326568318127,-553.7834808800043,44.87165185767992 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark45(-215.9895997824708,-561.7429463750159,11.6220137503587 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark45(-216.38236799105593,-530.7347833767454,100.0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark45(-216.51686314065043,-582.8728166849421,42.23861143724068 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark45(-216.62432487921438,-534.3649260653668,62.658952036735144 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark45(-217.17901062472313,-621.4336015926882,96.16641696246674 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark45(-217.29340823644748,-590.8298653727826,100.0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark45(-217.29856684185543,-531.1268462512152,14.897474859560816 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark45(-217.39421304306123,-550.0984907450799,5.404562491250857 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark45(-217.43165435637576,-569.626635111697,2.858454089527541 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark45(-217.710861674175,-595.8679033887804,74.06518782051103 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark45(-217.93092243843762,-559.184161126882,98.61453078640886 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark45(-218.01990367874367,-595.5190664641078,100.0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark45(-218.2810132968477,-536.4880707072018,84.09703300569603 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark45(-218.5690710415329,-553.478614895546,65.02068053998121 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark45(-218.81808972381648,-527.2735943634208,94.46376208728287 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark45(-219.14904474398816,-593.0566222052805,52.52402664566651 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark45(-219.1686436809427,-538.928943568952,48.99753248100379 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark45(-219.18492103924427,-530.8478433621311,49.94035551366059 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark45(-219.25256891317582,-546.7426945089973,2.590719991035442 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark45(-219.3806261324159,-540.6473474955786,17.752266491795005 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark45(-219.76071527458106,-588.1083053394561,74.5921997264874 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark45(-220.33475177416048,-532.3190276523096,16.312259286557236 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark45(-220.33583633334882,-619.7157133657988,29.91024951699714 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark45(-220.35915353953808,-535.6728364502975,100.0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark45(-220.39698873381326,-526.3918772300067,7.844208104344091 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark45(-220.41861965136184,-531.0414988794855,100.0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark45(-221.39897803037204,-543.0425846316881,100.0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark45(-221.74638495754266,-528.6289124839916,100.0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark45(-221.76746036940668,-529.7820054039547,99.0111180864561 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark45(-221.82146314855459,-524.7309254206019,86.31828482864492 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark45(-221.82681592181513,-544.474168749643,93.80563624673292 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark45(-222.1595632027998,-527.4122033802796,3.1349323238031275 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark45(-222.28140870058186,-531.8079102242059,67.84264537067946 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark45(-222.3576272277893,-545.4163828504816,21.6832644469892 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark45(-222.50854276767333,-536.1958015904512,8.629904561859675 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark45(-222.7888525124545,-594.5311497738917,62.8959662594001 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark45(-222.8880637390449,-566.0730153895663,16.69749976121922 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark45(-222.89903353252748,-563.9322645449231,65.17488890964535 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark45(-222.91943802863494,-544.8121296501719,57.863380639632396 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark45(-223.4508580580315,-540.9813313157351,81.26939979310146 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark45(-223.47663078174102,-552.02847741082,17.244986012483963 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark45(-224.23842233156745,-538.0564574062977,37.67061990199812 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark45(-224.2663517495513,-525.9262207793729,24.39233907401146 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark45(-224.32430816408424,-567.4296444302893,100.0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark45(-224.39191640478194,-529.408937815139,8.604348400856594 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark45(-224.51281422395655,-549.763450015028,3.5745187831952165 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark45(-224.81830918905234,-566.2847512752298,100.0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark45(-224.91401224553897,-544.1014787987591,28.7396757852797 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark45(-225.39439175337338,-535.8070714957512,24.11305511001025 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark45(-225.40014135772182,-554.261977488426,91.03096229982313 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark45(-225.45231480048835,-532.7762240179367,56.612383847126694 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark45(-225.50280497729523,-547.8652865460842,69.27125716534422 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark45(-225.5354970852129,-526.6340632267535,51.064307211798166 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark45(-225.60999699052772,-556.6982449559447,100.0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark45(-225.77333482257905,-586.7740189681269,55.64732330909857 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark45(-225.95663894025662,-580.8507175572682,5.564029145402998 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark45(-226.19144974604765,-545.126899297423,69.40695857747099 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark45(-226.44965835749005,-559.9516796263898,8.962089116937479 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark45(-226.5482029002686,-525.9117614060398,83.96546145746072 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark45(-227.31321205207718,-524.5009794261923,13.352742317403283 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark45(-227.3203786431975,-521.4046157952486,84.49884998256388 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark45(-227.42907202620785,-531.4419065710837,1.3784469359831206 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark45(-227.53188077959408,-539.8958742889122,11.277997996641957 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark45(-227.58221118430504,-528.8138524003897,25.534812385578377 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark45(-227.84967102308084,-534.548050957764,100.0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark45(-228.08640386497646,-540.9373572694061,80.223760267524 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark45(-228.34400187002944,-551.4090727051214,20.996237401543524 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark45(-228.8793956720588,-526.1359545471421,17.77563961218827 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark45(-229.15976460171473,-517.0961209410433,18.740358482556502 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark45(-229.43546620288996,-543.9979303563438,94.8106170089925 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark45(-229.88301360570878,-551.4349909144515,33.27023777082405 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark45(-229.94591423715502,-534.1875282191721,39.714686861647436 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark45(-229.9970855901613,-547.963801144959,8.529729437898766 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark45(-230.01077449513662,-526.6615370437308,30.891831679370284 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark45(-230.0183447367757,-559.8173324727443,74.07952852169203 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark45(-230.3597837955144,-527.4253144190349,23.335628428224936 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark45(-230.51847418640355,-525.8498274670011,77.20006712951431 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark45(-230.77302007312915,-517.4545345866466,74.6503883438817 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark45(-230.79073854490522,-526.7666167012541,2.36804746655703 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark45(-230.81529368842226,-528.4634743764727,3.5001721482043564 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark45(-230.90395815365252,-550.5201879858415,49.77456948144777 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark45(-230.9950963346816,-533.0887965335071,50.01506567361466 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark45(-231.22459634135745,-522.3391444602001,100.0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark45(-231.52855432700667,-519.7637443327731,98.60915124437699 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark45(-231.53239057390743,-539.9455861643175,82.76044154803625 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark45(-231.55106459533442,-585.1083191417954,24.07579189534421 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark45(-231.61765466394021,-568.8125825255413,16.347983425520567 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark45(-231.85713386404353,-520.757792291623,13.74627896350924 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark45(-231.9109795738613,-540.6046046798084,45.10813057916391 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark45(-232.09933277609485,-537.0070336274594,100.0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark45(-232.17314654832407,-532.2125372635322,65.04854454724287 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark45(-232.23361750977665,-543.4009417403449,48.491548996739056 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark45(-232.25184751347498,-558.7223689480483,96.17581403002947 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark45(-232.48359441176046,-547.7588654386586,66.69339442093298 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark45(-232.75000294657545,-523.2754728516179,94.27956650621971 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark45(-232.84042217581603,-540.8236576964066,90.32104828491313 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark45(-232.91500155561616,-547.585471783531,2.3179166562840265 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark45(-233.04926755582767,-523.1766987041857,29.946541773820428 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark45(-233.09851954119438,-518.5761788961148,100.0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark45(-233.37393216456144,-519.5768150803583,100.0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark45(-233.43678492686814,-535.486218585801,95.11909131810518 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark45(-233.6976765038553,-552.3043254205244,100.0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark45(-233.74963041797167,-517.8390491581846,12.648027317156817 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark45(-234.0060942403583,-528.2775452575162,57.89910958966777 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark45(-234.3851339210281,-538.1622000022471,40.98431469726415 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark45(-234.45562996452372,-512.8670327609149,100.0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark45(-234.61436345987659,-528.3892492008307,41.9449943716491 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark45(-234.63270784634932,-560.1745104044962,19.641021648442702 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark45(-235.168096472266,-537.8865654526375,100.0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark45(-235.46582944751228,-541.1342550852147,32.9567414655246 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark45(-235.5880027378092,-535.8466158955252,87.01359773386326 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark45(-235.59914490193836,-549.1628554574396,100.0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark45(-235.93080808483788,-512.4504420105565,95.99162052787474 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark45(-236.15480040984406,-524.4885437470202,71.63434733337289 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark45(-236.19859715596243,-533.6876555299801,24.766514918935982 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark45(-236.90232429740078,-544.1790805160504,31.639545458631147 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark45(-237.07166924010275,-513.7279704589603,70.44239200836506 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark45(-237.0797951503249,-537.3048332761986,46.30496711812137 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark45(-237.086389068371,-511.626119943079,92.62174248184795 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark45(-237.30128066683346,-516.5957874127276,28.553477023283705 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark45(-237.41261467453285,-509.77770733180205,34.258758872959675 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark45(-237.61916613797666,-541.9872957942043,22.896979465789727 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark45(-237.6965392371191,-574.4548671702,2.689147539192632 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark45(-237.72898265057077,-540.9352508301031,53.183874496487135 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark45(-237.7955084233917,-525.14490464342,58.7430071067227 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark45(-237.8606119806263,-545.4972453305783,23.59664112748034 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark45(-238.04045402438786,-519.7608210722689,59.745724619100116 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark45(-238.07652418452423,-545.4744942592527,50.16118945227575 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark45(-238.38794916821217,-526.0392761882179,73.22362912349399 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark45(-238.864779367775,-516.8353564408006,2.645302096673106 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark45(-238.90187108419175,-545.3900261975831,6.158233080309714 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark45(-238.98355097607794,-547.9578324871048,51.327626645538174 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark45(-239.05663399221837,-519.3362989138828,66.3347075073325 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark45(-239.24456442134425,-507.56094617733163,98.7780129306883 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark45(-239.276078673116,-529.6721565682132,30.539934402331113 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark45(-239.34764337205598,-591.2414158916197,74.95452280014834 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark45(-239.9115168099093,-546.5001986733824,100.0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark45(-240.08117753850695,-507.68988403321225,100.0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark45(-240.31356999600095,-547.6285602575971,3.4031564980825806 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark45(-240.43237322238153,-516.1493325355644,35.08208781735746 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark45(-240.66404348943072,-586.5129499967302,24.9942217648685 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark45(-240.9271120894989,-508.91967719798174,73.79714962335842 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark45(-241.16461049730512,-551.6671119167959,29.783761019432973 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark45(-241.2197503601961,-509.9498415129794,39.15936681181822 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark45(-241.41474511512865,-584.1701433549647,91.86321088572512 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark45(-241.63176471857193,-538.8541052914422,91.79943859448156 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark45(-241.7464674181109,-517.5278387426027,100.0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark45(-241.77402684601932,-564.9247561455696,16.88160763699878 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark45(-241.9016721055601,-507.5449338706114,90.45561580000879 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark45(-242.00282230074356,-578.987610191201,79.98116096022258 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark45(-242.2100191156218,-536.4611140802489,23.47431560397095 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark45(-242.37876346182455,-552.1250351876022,100.0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark45(-242.69910946825934,-549.2093573672315,83.27262685056155 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark45(-242.76837528953433,-518.513620558497,55.952522384114445 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark45(-242.8147671571558,-531.6358705321089,35.210638895046515 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark45(-242.88495176550515,-562.3937474482659,9.799361577625618 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark45(-242.8909701032182,-515.8148070297833,81.74048930721679 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark45(-242.9145421957909,-504.21952799666235,25.13040496647274 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark45(-242.96771017515383,-520.3584744058988,95.7518537099065 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark45(-243.4236368934434,-527.7391408761746,47.05885490836109 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark45(-243.4339423019511,-527.0529459882754,85.36780386604877 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark45(-243.49189107183435,-515.6275865166833,97.90685387775412 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark45(-243.50708676180156,-521.463394680984,54.09148170428347 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark45(-243.5459864345973,-506.95276436295455,3.08319185429049 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark45(-243.58572343310627,-519.9575831917927,10.17908237614975 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark45(-243.78996218766736,-558.6829277920167,87.00137626983852 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark45(-243.9284326487493,-549.5039037735445,17.03254853932941 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark45(-244.24637511590794,-511.9028182992322,37.50458064382164 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark45(-244.47771286336132,-512.04994323658,13.534406640478181 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark45(-244.50394477219928,-508.8847657713596,13.040196238902496 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark45(-244.51361887205954,-518.3292672456703,18.65373793930472 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark45(-244.78129593583733,-560.4499743716544,91.15139380264807 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark45(-245.14597054199848,-532.6839345270661,100.0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark45(-245.26500956821718,-518.1211563673539,20.431173213559845 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark45(-245.44554396967536,-502.63904607699436,80.61192607688571 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark45(-245.4783820628571,-581.6962505092893,3.052399437284531E-7 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark45(-245.66975062373618,-526.0156749808053,96.67458235513175 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark45(-245.98767560060625,-519.5721451455241,57.219051459704986 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark45(-246.0335873865742,-505.4847775909288,74.17968540249169 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark45(-246.27605022250924,-514.1213318093211,19.832048011628032 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark45(-246.88827760758375,-512.2931670158455,5.257132973397177 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark45(-246.92564362888504,-546.2897929451585,33.38181443033889 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark45(-247.07046374153853,-502.24328199432017,30.290927521522974 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark45(-247.07933267061335,-575.3331766485553,47.79203367617757 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark45(-247.19777697000836,-511.8346540535902,25.92246005475485 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark45(-247.63196702300203,-504.4724590836481,57.935942833938924 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark45(-247.83164881723954,-504.0675557800292,5.657628551095513 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark45(-247.9881159739204,-498.97528746589774,12.922945555329463 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark45(-248.01309257941165,-513.9546961139733,67.64354441301867 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark45(-248.12031604801518,-500.91068344393534,25.150869274191876 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark45(-248.23814546557946,-529.3740766986108,93.9366860956124 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark45(-248.54382463013488,-551.6362938656071,47.71666096246048 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark45(-248.6633383602884,-499.5375725986184,88.12187761737611 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark45(-248.69349476443324,-499.6416075895686,100.0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark45(-249.31238321553593,-550.6649242561626,4.51918784110299 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark45(-249.39280277373678,-502.540600937933,100.0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark45(-249.6710358686193,-501.7276062295078,44.932598685688305 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark45(-249.6796539220502,-506.3034446555232,16.7806183063652 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark45(-249.7754938930696,-516.1211844119812,100.0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark45(-250.00413566182073,-510.3903552523884,18.846512711274755 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark45(-250.00499289810477,-544.4031976804179,13.167599852266747 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark45(-250.21691692600223,-535.9740429145553,100.0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark45(-250.29245013481545,-515.8232518357579,4.819812569176477 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark45(-250.4416843841428,-502.2126482553821,38.60072847915015 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark45(-250.45066379621215,-502.5833852304108,19.50140443421715 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark45(-250.5156894020686,-524.6630911613826,13.582131261549762 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark45(-250.64586147633975,-517.3008450277148,46.35711628194525 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark45(-250.65738395129094,-502.2960206006772,98.3703126250535 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark45(-250.6612971928733,-501.3227558145302,20.499102507573056 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark45(-250.89115332566257,-503.2353187272813,24.92271460507878 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark45(-251.01537062952866,-496.50454890895685,93.28371311756803 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark45(-251.10505210815703,-506.29323562695436,30.63926660801536 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark45(-251.3189351944029,-497.2168347793541,52.34657000028383 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark45(-251.48623817337707,-505.0151813164518,90.17784300023582 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark45(-251.54032379152525,-525.8404484737508,60.77644583130842 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark45(-251.58778608314077,-515.6026478457358,95.42094411521799 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark45(-251.89401373654712,-500.1374360316838,55.530317316099456 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark45(-251.9618100290346,-508.7125707654741,30.63144500381557 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark45(-252.00051120864805,-611.0754446415904,12.437118548774052 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark45(-252.12347014389172,-504.63422279463464,6.644491442468436 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark45(-252.20836119586272,-524.1709560691993,68.53920264845246 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark45(-252.26798864821438,-498.3406573475176,100.0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark45(-252.39903001210666,-500.7574375185775,53.67086243638332 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark45(-252.50689948354517,-530.5645835564721,87.84540763903007 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark45(-252.6810845263421,-519.2224351891059,67.31680141519237 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark45(-252.77005315240373,-493.9359053509678,92.65746928151268 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark45(-252.98393557614443,-564.911664297936,59.54590880833851 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark45(-253.02714373100056,-528.8785397704245,89.95331456638397 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark45(-253.35558234391334,-499.3040119111593,74.75526078900216 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark45(-253.58385893496592,-563.8388039042868,52.3110008315831 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark45(-253.6162051909598,-525.2256118773037,100.0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark45(-253.8009078270606,-499.2662190847961,0.5651548827393356 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark45(-253.8211795307682,-539.7673239031657,11.344899354436972 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark45(-253.85273012573472,-503.4600984292613,51.62953735721299 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark45(-253.8954987089078,-498.7736316008888,16.685253838646915 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark45(-254.01189849478948,-498.33626285255434,27.780559162563904 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark45(-254.1578671866593,-510.8117277784402,100.0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark45(-254.70187057354966,-531.2234034107148,67.5450168911033 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark45(-254.7515639204876,-555.5172479124567,22.269919522243782 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark45(-255.085495044262,-511.9204205117668,13.354294606490242 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark45(-255.37568925811803,-494.8345256646112,10.847439230404675 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark45(-255.4934533275227,-517.0417137962401,78.06288169186627 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark45(-255.51828565264063,-497.24309405061615,100.0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark45(-255.64225295046776,-558.3635300218693,88.60559378190382 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark45(-255.88305064817777,-497.72317349645,21.068054695050904 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark45(-255.98126684454024,-532.9685791718887,88.9605815912617 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark45(-256.103008647165,-510.9001528980549,100.0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark45(-256.25498731870437,-496.2048642088964,25.205084953281826 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark45(-257.04913417945,-502.2091071379212,16.92101871326001 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark45(-257.1949132011317,-514.8942178038277,72.77467958287244 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark45(-257.2181300328252,-494.28656359801016,78.59013851403887 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark45(-257.41571571076736,-488.6623944162739,77.94678322372039 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark45(-257.4199973741068,-516.7591779580771,78.6823063585108 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark45(-257.4771299890764,-571.5684222806345,8.5987452535053 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark45(-257.50412173268563,-520.2792277627146,94.99355941341625 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark45(-257.7968298913374,-496.6788626298558,72.6046554175349 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark45(-257.8910113453144,-530.7318359588578,44.92297857223153 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark45(-257.97524120418285,-525.5489607972025,15.435605857515185 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark45(-258.1554360183868,-495.52530429255586,93.01642413878199 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark45(-258.27708572298707,-501.36605340421204,10.62559676819248 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark45(-258.51229722801094,-507.872792788339,60.41083630084569 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark45(-258.5220792201098,-508.0469800788774,7.916934982408108 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark45(-258.64625981132565,-498.70088670393125,46.01720815248484 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark45(-258.72897187771764,-505.44243837316253,80.47932233642058 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark45(-258.93117739733043,-545.8797492633805,36.81126148034534 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark45(-259.0079639135916,-534.1246005504307,100.0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark45(-259.3231456871025,-512.1328044075001,41.63164641183878 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark45(-259.36030776542805,-507.9725454920015,56.76130041760143 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark45(-259.36452350475724,-532.6271023206206,22.871754967876768 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark45(-259.681571419614,-516.3706500688268,36.881417641553895 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark45(-259.84704172957555,-490.53133659394314,100.0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark45(-259.94504415331244,-488.6280053303786,38.043949353209996 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark45(-260.32873116293854,-498.54253833382757,37.36191866888953 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark45(-260.64642472021785,-488.2843979509052,71.3134089388526 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark45(-260.7867583592609,-533.7870638132157,73.38614904045961 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark45(-260.80821890839064,-536.9345601112369,18.704577792252167 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark45(-260.83497273703125,-490.93719761670303,38.56438621999786 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark45(-260.84274131660624,-493.67755006136684,62.02308666717039 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark45(-260.87878907347357,-500.15739305449495,93.92853158694115 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark45(-261.1993609429435,-531.6860957004425,100.0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark45(-262.1949992143075,-540.4985198689517,92.59762942750979 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark45(-262.22339314236893,-520.8077184834401,7.105427357601002E-15 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark45(-262.22901201327426,-557.1043720069981,15.461902279550998 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark45(-262.3137906614745,-586.7049103771428,40.53297510171748 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark45(-262.3189239204357,-522.5311297789044,80.2059186869296 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark45(-262.3910973344714,-576.1061736230732,100.0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark45(-262.5702909904192,-488.266027320132,100.0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark45(-262.8390270564524,-508.84646128317337,39.778852468050275 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark45(-263.04385174536003,-532.443676149897,88.66257718188979 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark45(-263.31226248741905,-490.95352905724707,84.46249605790939 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark45(-263.51585187889816,-483.27556060457323,95.34308975379932 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark45(-263.6244118659587,-508.02213558808563,74.97133412295247 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark45(-263.73708707074184,-492.5612065618919,24.81797374105284 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark45(-264.45764878099806,-484.7536880569435,84.25064961905471 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark45(-264.48798229539995,-499.03337375120293,20.70867496867723 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark45(-264.65898510146786,-507.77900698181924,46.28049939471967 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark45(-264.73931088336315,-501.2121451510609,95.40872506023015 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark45(-264.7427660463768,-551.6276356544568,53.09393082578754 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark45(-264.7642133585627,-504.7951458443025,100.0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark45(-264.9066189122957,-550.3565390824701,100.0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark45(-265.82598665253914,-513.6544723827567,19.978075992726716 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark45(-265.8479152428014,-555.3892020180161,100.0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark45(-265.881605490084,-480.6356955155521,28.007377719146405 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark45(-265.9166898208399,-484.2850643448677,20.463620594203945 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark45(-266.23710979851853,-517.0913234119489,64.05542454022077 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark45(-266.3200953387945,-482.6068303385204,0.23184855191432518 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark45(-266.56938262939497,-501.3822971625647,23.629266543719666 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark45(-266.7336274474323,-543.3652478999089,0.5250970816537404 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark45(-266.79598036774274,-496.7007770791746,81.46799942211794 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark45(-267.22780704395217,-498.3080611567928,61.97597725723985 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark45(-267.4000639870686,-535.889906547094,46.5331797614256 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark45(-267.66710976142247,-508.49520653141343,100.0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark45(-267.8442868353,-496.67824580367983,100.0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark45(-267.9246041764123,-520.802324135355,76.900288172681 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark45(-267.9428758581192,-505.8727053304407,3.2758155579366957 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark45(-268.314789031995,-483.74549759801647,37.83945843739383 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark45(-268.48031613674635,-498.8016909410875,77.10520105078805 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark45(-268.6146276023113,-515.5229478649384,21.740012003490335 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark45(-268.6545277827464,-477.34547221725353,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark45(-268.74441997224943,-488.48130538884783,81.01483616437451 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark45(-268.8218828183615,-485.75310328715983,49.66055522158217 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark45(-269.3063503693067,-503.129830579855,12.648004577024508 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark45(-269.3081670807115,-517.4517484125711,63.009919189187116 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark45(-269.37545874497914,-541.1518549975667,78.44358604487357 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark45(-269.6396187002074,-501.82429433595485,1.7797725770720731 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark45(-269.94011495793677,-480.9871081930361,100.0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark45(-270.1607306948718,-503.14281915058575,29.61165467672197 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark45(-270.2144033746834,-487.106753884344,25.401408552303636 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark45(-270.51258161929354,-481.6251756989272,90.34896502541383 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark45(-270.59495300244896,-477.27104983192055,17.971652046860157 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark45(-270.7736962794387,-476.75967314174085,40.18763311971739 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark45(-270.7940600739007,-527.3827749966274,95.35116828828365 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark45(-270.9549343410514,-483.44187466758194,15.061656327622615 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark45(-271.16377460720145,-482.9478988483869,13.681622881315022 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark45(-271.34294619467096,-482.4775594640721,53.02177953841277 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark45(-271.49292950459414,-506.83445624936684,22.769495891155653 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark45(-271.77847595807873,-496.4200160302708,1.4452880691227392 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark45(-271.9359475714153,-506.66658571002887,100.0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark45(-272.0239343761387,-477.5189152199747,76.87305131745501 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark45(-272.08168323154297,-529.3515060666393,100.0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark45(-272.223946955067,-521.9911398878485,100.0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark45(-272.2718591977415,-534.8515881556846,32.64618973385353 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark45(-272.538685819296,-476.31867181374673,25.853745031343706 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark45(-272.6473457152667,-474.5094274952804,38.45078536327807 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark45(-272.8480328610013,-508.82880691796515,100.0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark45(-272.99193445878166,-489.55174686137616,34.90933952219814 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark45(-273.0462431288009,-523.6280718971308,63.7312014680775 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark45(-27.313031501958207,-747.6296902148019,56.07418245448568 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark45(-273.2303223586827,-489.8874487418314,61.39194313224054 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark45(-273.2411725819492,-512.2068059920003,17.719608378953012 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark45(-273.3222909071231,-495.9728638111979,28.109916335215104 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark45(-273.46754695482065,-497.9479563264578,63.62931900430638 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark45(-273.48915594545986,-482.49305866684114,94.27445174368671 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark45(-273.75406476661726,-490.601151697287,23.968382276330786 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark45(-273.78191575704636,-496.45929843806874,40.92343807850503 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark45(-274.0468778935072,-499.03016105175334,100.0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark45(-274.1994611459993,-490.1011626117943,100.0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark45(-274.20114285900723,-483.0979744037671,64.6489490756929 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark45(-274.21868531765483,-479.28521949067476,6.464989102716373 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark45(-274.3937405513982,-528.4587690028027,14.805420824285516 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark45(-274.6628580325636,-505.0745918682589,85.59229432666606 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark45(-274.9874157154847,-520.8359987363652,100.0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark45(-274.99299684064283,-489.9824430503804,26.144645127224564 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark45(-275.1142948304437,-493.5570113671138,82.38487531456474 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark45(-275.14237342385474,-488.74282380848194,68.13972131304513 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark45(-275.49789566070615,-473.0818768989762,100.0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark45(-275.5088900369751,-479.14175364019246,53.54503641125032 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark45(-275.9823022453853,-482.23919622717136,50.71636040468201 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark45(-276.2107019398074,-472.1083138424795,7.705079820945457 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark45(-276.25838815503096,-474.34863024066397,39.00173828068708 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark45(-276.2927875962757,-475.066338542007,48.572598436812264 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark45(-276.56630049342846,-471.1309819734223,94.35499121791997 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark45(-276.5740955499629,-503.86529461832845,66.11203229132235 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark45(-276.7959620982365,-547.3681467066652,22.268674117354365 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark45(-276.87068821543386,-492.2358781748464,10.262553148430385 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark45(-277.02546335524283,-491.1467243526255,30.221097132505747 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark45(-277.20030675880975,-496.1646027369737,100.0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark45(-277.2191801746936,-468.8145531170595,40.977660132530985 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark45(-277.4808564005784,-469.6913567296444,78.69672763358736 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark45(-277.6019276738816,-516.6600620410238,8.143525165368715 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark45(-277.70915559452425,-484.44218013739385,69.61778398349321 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark45(-277.98014570050253,-489.2060238045797,8.208294545059076 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark45(-277.99775391885214,-471.97973406982834,76.75489675996636 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark45(-278.01126433382194,-494.77570217504825,100.0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark45(-278.1309640391133,-470.37492649629564,11.249296456562632 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark45(-278.2000365334956,-552.5727572902462,100.0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark45(-278.4269087631934,-497.03638931510943,100.0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark45(-278.4369242360896,-505.70836570902645,38.3075741278314 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark45(-278.6874448963441,-476.52775407691917,60.439481718774694 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark45(-278.76675778962476,-475.29045846011826,3.5034340252337017 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark45(-278.7830844406133,-475.50272298363916,100.0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark45(-279.144634555311,-503.53735808477467,100.0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark45(-279.5633047522737,-470.1893225683438,1.4649265626662071 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark45(-279.6600899597109,-482.0378782353333,46.74986702673772 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark45(-279.99809493116857,-535.8945671923478,6.855505212081496 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark45(-280.0691691731147,-492.9779851859467,59.51615606255939 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark45(-280.07977539036773,-489.9780441657298,66.69810713257505 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark45(-280.16220002793966,-505.00822623634707,99.17351097845926 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark45(-280.2974634737891,-505.0062630388488,29.386768507396397 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark45(-280.31574750744596,-500.09352810891994,11.688956419461235 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark45(-280.3166382632717,-473.44470292793534,25.72509251061075 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark45(-280.5523189704666,-505.89872692268807,100.0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark45(-280.6957551904319,-501.2099190598183,99.24780726436325 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark45(-281.4865125692241,-469.3149852709824,84.37259224692119 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark45(-281.7416762574874,-468.5321912107059,59.80663996521653 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark45(-281.8556172836225,-487.4441135841599,25.270441790778847 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark45(-281.9422462385789,-518.9845546478647,60.445800851923025 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark45(-281.9605601910004,-509.4378182002916,1.2975313315673986 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark45(-282.0333780455644,-473.33420331660005,44.627544927015435 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark45(-282.1514558154195,-464.26734787229447,22.218979457402213 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark45(-282.2089388133796,-543.9927358713727,50.20764306806302 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark45(-282.4223693751264,-499.14148703500706,35.33524741485422 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark45(-282.4358656399517,-483.7053368283201,-100.0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark45(-282.7179372069074,-467.61487907286784,53.98180995403595 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark45(-282.9604450388189,-489.6253390647959,100.0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark45(-282.9758998451842,-524.1144640702238,95.53524967042839 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark45(-283.20885313894047,-517.6934044218427,19.64117965805447 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark45(-283.2603560927197,-503.94911303923703,45.142745725758914 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark45(-283.3975806231273,-503.73931487003813,31.86894844614386 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark45(-283.4626928457129,-487.7817202834147,100.0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark45(-283.4815733539733,-508.94666794323695,52.48655870600814 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark45(-283.53078698058994,-465.8686385928487,39.01900239317874 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark45(-283.62305700985434,-477.3662454597321,2.2853053049864513 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark45(-283.6869582270928,-502.03765959131505,14.182728571856558 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark45(-283.72865967864806,-514.7128754459919,61.57757105122582 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark45(-284.2162623850703,-462.9346844558263,100.0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark45(-284.39709208651686,-467.7785374595695,96.9620729553832 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark45(-284.46179422986546,-479.926889894102,32.91336754069849 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark45(-284.5948437851798,-483.63295811299884,63.51758166840051 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark45(-284.89587033713735,-529.1135316828332,13.507058698370699 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark45(-285.1603832132662,-482.1856254032662,100.0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark45(-285.2942648135721,-465.61832644329996,100.0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark45(-285.4293876521476,-485.77896730940193,72.61543957353626 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark45(-285.4516861364191,-472.9811567157709,28.394359926090544 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark45(-285.8041694581179,-467.4765965873232,15.918685131690651 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark45(-285.9737876545691,-461.44931194189417,24.903925219038783 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark45(-286.0070710864858,-525.5946195376744,50.67507255332853 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark45(-286.01435196986273,-466.85109444736435,79.2934359568514 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark45(-286.03920619538343,-533.7742852184736,92.21266230986961 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark45(-286.0431796520065,-479.17779630712437,25.784394028130464 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark45(-286.09314443377883,-479.6012252758966,100.0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark45(-286.1450458258934,-534.8532530775669,16.963965806074157 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark45(-286.14711451238327,-482.3257819798798,70.99622739552811 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark45(-286.2409277084508,-535.4130335576357,93.58694555535797 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark45(-286.55923527679414,-462.22020979942397,3.228837930198196 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark45(-286.5766491924836,-522.8729283424778,21.560148987818323 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark45(-286.5772832998717,-459.8477945954055,83.38930291320389 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark45(-286.73805017043026,-467.68202998613,32.65715688044958 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark45(-286.89193242570116,-478.217235161342,42.612307393319895 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark45(-286.9537008538749,-599.6630973541263,77.95962910226282 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark45(-287.14345217337967,-507.00093000190765,100.0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark45(-287.17143853320823,-486.49544175651556,33.21396956122629 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark45(-287.2702714763133,-469.4572009020187,11.166427429212831 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark45(-287.4690976686434,-463.10230213654415,100.0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark45(-287.7727163538768,-466.5876351392791,9.709146291410235 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark45(-287.7780742134481,-465.6772772274469,2.9169508662820505 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark45(-288.07501614479526,-482.02297516623906,98.70325609179568 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark45(-288.21445450608473,-476.1401057947611,27.57381754552761 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark45(-288.25025686584127,-489.69033161308346,100.0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark45(-288.3989967485588,-457.790929455521,15.243460315609298 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark45(-288.49178417979465,-494.8892772801692,51.187310893333745 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark45(-288.5404366607382,-521.9424250180019,67.34956161603992 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark45(-288.6850928542947,-498.8108930953239,51.65983284021408 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark45(-288.92771156291616,-461.9500983786845,100.0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark45(-289.0153098566909,-512.2629304892704,63.58448190094322 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark45(-289.01915022563225,-514.7062287535424,14.572546032746445 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark45(-289.0219085041609,-457.1901757194488,100.0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark45(-289.2721822197672,-471.7333737414319,79.66741013796906 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark45(-289.28707381675883,-475.9059560632354,5.482321874608573 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark45(-289.3030605741011,-468.2460350899709,78.0058697611262 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark45(-289.3380395122799,-488.1808608269744,39.40887537612926 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark45(-289.5830891910316,-462.94737699359314,63.143330139102915 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark45(-289.676334782199,-483.1408320669644,30.349012898894898 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark45(-289.6787302237506,-478.89223833897506,4.16671118005894 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark45(-289.89095561077426,-485.4221291225146,49.354105846917975 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark45(-289.9873539099925,-477.2410326942527,22.839503833515252 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark45(-290.0860081391077,-477.65564393360273,63.088936441674576 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark45(-290.1018789916631,-471.97894564540934,84.06842165604507 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark45(-290.29995036674154,-531.7979430039492,60.01638032988831 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark45(-290.5346403028809,-466.76851038395665,72.39530780868478 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark45(-290.7168263711404,-487.8192188010304,100.0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark45(-290.9162415265859,-457.4018461194547,76.44692153134264 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark45(-291.12056679351025,-456.6895304140676,92.18332887431723 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark45(-291.140634389656,-465.9087419500453,87.60364982682097 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark45(-291.16274657082005,-456.812010602133,100.0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark45(-291.18600782950665,-479.9551861533255,14.275417194752563 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark45(-291.24753892412565,-497.5237656937576,4.249025149926979 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark45(-291.2592485612703,-472.2711355681121,80.06700201717626 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark45(-291.2953307399578,-470.14157654818337,49.38090249518194 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark45(-291.34467183756544,-497.88526948412755,45.14239537638824 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark45(-291.3988216216172,-469.6204197229948,100.0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark45(-291.4901069857153,-464.43892326118345,30.694117373649988 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark45(-291.55556934144016,-455.25972928110474,57.321745805010295 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark45(-291.78111937462825,-465.8478502657581,38.562268180778716 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark45(-291.80741535773143,-497.03821497325515,1.4217800397916562 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark45(-291.9161947774091,-470.0501013732927,100.0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark45(-292.18309724508737,-480.9332070743724,100.0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark45(-292.3792065109779,-514.3468804106476,26.05226433978646 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark45(-292.4102641990456,-490.66999747806045,45.30448715898706 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark45(-292.41536521017133,-458.7018019176005,17.282697666361884 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark45(-292.5744297401,-462.78259013438657,22.756584771762462 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark45(-292.6953682283597,-499.90107874584055,0.7078695869309257 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark45(-292.86739457171655,-511.55811970388083,64.01127326112774 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark45(-293.04272626157467,-479.56676620386156,8.933588429664468 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark45(-293.3386797535521,-565.9317625909454,32.43245773699323 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark45(-293.3665412759037,-453.57578995311576,81.00992431961603 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark45(-293.4139594125713,-465.98433453976776,45.40458530556438 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark45(-293.49351224255395,-473.1227417712398,48.47161608043923 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark45(-293.5880246016221,-473.89235597182505,12.436327710848815 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark45(-293.7117101227969,-468.007061885459,24.541755666041595 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark45(-293.9114613962306,-476.36351928187094,5.3258151784236105 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark45(-29.393255771437182,93.21900523913388,15.249190530545349 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark45(-294.6065301436525,-469.1973126301396,32.649255002906386 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark45(-294.9634202746567,-490.7550560388501,19.254061322135982 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark45(-295.0614141839276,-467.5021212199786,100.0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark45(-295.0632545740364,-498.9209458699226,99.01371756819316 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark45(-295.24479397810694,-479.2082753899503,75.63379187901624 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark45(-295.25773758699205,-487.06139327742744,26.974019944443953 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark45(-295.2698070343511,-472.91089856586035,33.87554942459275 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark45(-295.2829810132672,-462.04130927863304,100.0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark45(-295.2846097451517,-469.09144563712647,49.1631108692732 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark45(-295.31819955179196,-469.65273276445316,99.11201468925103 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark45(-296.1690024634303,-479.0129082550155,41.5628515754689 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark45(-296.1947777823284,-479.9044972289425,100.0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark45(-296.5779696638247,-468.36711191827567,97.13490891586017 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark45(-296.74895572437333,-520.589894699169,25.379236311701533 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark45(-297.016343029264,-459.5862727551269,56.452088544818594 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark45(-297.06006443757093,-486.7765533020411,32.92706134351309 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark45(-297.24924753620337,-491.37024760252314,93.70438529476294 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark45(-297.3643450337288,-461.62604537255083,42.8333815435287 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark45(-297.39027976575454,-502.3323747622052,96.6405046926049 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark45(-297.47132591376044,-472.1014206797867,100.0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark45(-297.7896420297087,-453.85317632857056,15.827057967058039 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark45(-297.8400257854634,-511.3700457147299,16.75665181429092 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark45(-298.1319409340748,-482.05166337622154,40.87095613276452 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark45(-298.34715940928703,-464.9579098580426,27.92370776145148 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark45(-298.5006581059683,-485.44675011713673,59.81332701826224 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark45(-299.0791147552864,-528.1401370977502,53.51093831366495 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark45(-299.119720933329,-454.18334349837926,26.02629105725447 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark45(-299.4092139936306,-503.93240332215356,56.341483980749615 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark45(-299.49134605721645,-469.8679595153012,78.07546161276363 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark45(-299.51463077000176,-466.0361137143823,27.033317641213642 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark45(-299.8757775474689,-488.6509295332385,0.2773332835213722 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark45(-300.04046276181936,-475.6367420857935,100.0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark45(-300.12744819008697,-459.2745713086264,55.706690308177315 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark45(-300.1627726489808,-511.54045308629907,64.53531566338398 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark45(-300.271325696927,-476.37679553279145,84.55256091570186 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark45(-300.40107474726653,-540.6727633819814,7.041854927247016 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark45(-300.6777182851556,-448.2652679633481,28.917877270897833 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark45(-300.699320215588,-473.9287978294094,88.56744459475354 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark45(-301.02749381989605,-472.47263059288383,70.11948602431332 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark45(-301.13394877161494,-483.77203548070247,50.30914252742073 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark45(-301.1926321261479,-471.93573896050196,100.0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark45(-301.5219764472862,-473.19893210231214,93.1897487040373 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark45(-301.6342973948484,-445.66546008242324,7.354461441881838 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark45(-301.8468207735466,-456.4622625461973,100.0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark45(-301.86039207513363,-452.57026273409645,92.39321477334303 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark45(-302.4645089407565,-447.0747282461786,40.52918880510268 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark45(-302.55369226129415,-525.9516887322112,73.83124958719378 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark45(-302.56188854378536,-461.62018805979955,51.54594982315035 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark45(-302.76251435229756,-479.4919211294181,15.468229442788228 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark45(-302.8432266634836,-452.2894794943156,29.60227647467829 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark45(-302.9060805265696,-451.1289387517919,82.86242567910551 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark45(-303.05944921199887,-446.5106536279953,93.96943824660212 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark45(-303.39985429068446,-489.5130994577276,67.90079055499669 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark45(-303.51497362967393,-460.08092225007846,27.481435485811588 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark45(-303.6903667363869,-444.5696936603158,64.87066979348518 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark45(-303.6991150782331,-461.87696758040596,100.0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark45(-303.75789046082957,-444.60906670477686,8.562168713972639 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark45(-303.80293188194696,-460.43223711794366,5.97463761343991 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark45(-303.99105044212087,-552.9633604634703,71.38123995168189 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark45(-304.08952839035976,-477.10236636468244,7.279984761566723 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark45(-304.0902419235343,-480.8804753424344,42.531689983850754 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark45(-304.09071458146417,-497.2092068966903,20.860487596759512 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark45(-304.3968348504715,-447.68303585381057,20.116610606198122 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark45(-304.4393669828978,-474.62322635947817,1.0750239461451372 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark45(-304.58269570225,-458.82871159182895,55.96942055067163 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark45(-304.59704270681914,-449.7705454463793,55.97907326417578 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark45(-304.83016034930955,-462.60266592486204,37.32123688520633 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark45(-304.9104100229822,-453.80066597888083,13.302349831117581 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark45(-304.9362281369419,-493.47571972119914,8.003991117785432 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark45(-305.0803413205667,-442.13747900547514,11.019021894896895 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark45(-305.1759211963889,-468.2524210082725,8.310874616633896 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark45(-305.3946068407234,-473.8260741879948,21.62009181053584 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark45(-305.4132684968205,-444.11012349584496,9.991501846641015 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark45(-305.50100021652054,-473.8543977340087,100.0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark45(-305.50934403747965,-447.29281214993216,98.20392729136876 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark45(-305.7332943821385,-442.18713616344024,100.0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark45(-305.84911095529327,-489.06205992754894,49.47051574581846 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark45(-305.8975064013612,-499.4542823275081,82.81456812890158 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark45(-305.9801011007188,-441.54467537637527,94.37901493065411 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark45(-306.1487664891468,-447.6700946697881,19.75280318722959 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark45(-306.35748810537734,-488.8546038076879,32.36072174915458 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark45(-306.74315293134555,-458.90691685587484,90.35063025030101 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark45(-306.76759754213936,-476.1427868021299,10.546867905478123 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark45(-306.78706040891234,-454.0912772660396,66.56117064315819 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark45(-306.935848369185,-513.2114783327186,18.906018152517134 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark45(-307.45342766432606,-459.9411690785837,15.79971917272593 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark45(-307.90099184425446,-456.04101315646716,100.0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark45(-307.98400294092244,-444.39232229360044,28.19120542882726 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark45(-308.09910499456277,-478.9473748386233,2.3882449007623023 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark45(-308.191820157748,-474.61254444101957,26.57349548727599 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark45(-308.2169631070049,-456.66112835595766,100.0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark45(-308.27020660602665,-498.0148800529866,35.15484173633445 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark45(-308.3876184379754,-474.35328386120597,30.47993572259122 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark45(-308.4387455008983,-483.4235304403753,46.4288301034658 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark45(-308.445700931769,-464.8845842099528,100.0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark45(-308.7505743710781,-453.22268510265445,48.27899684617353 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark45(-309.0213425513899,-467.0393003493514,2.1067815126994276 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark45(-309.1572902484632,-460.44776703370354,100.0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark45(-309.2593187139173,-479.101410566504,18.4604228269216 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark45(-309.2749553861084,-467.49878094606976,52.9809895390361 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark45(-309.33075291807717,-445.377385592463,95.67692645876653 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark45(-309.43975956181697,-449.92567100006136,48.3096341044388 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark45(-309.4568808629003,-444.13175573743865,9.294124216330644 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark45(-309.89434180675727,-456.90656993704323,98.48401211583908 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark45(-310.0185005042101,-479.53677729468177,59.01693797017248 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark45(-310.2214992019598,-453.5640687170488,46.39562904660494 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark45(-310.28594485078384,-455.87834228683414,62.54786330751557 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark45(-310.4071340055761,-437.62884597245557,7.718447544478721 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark45(-310.5008736567412,-439.7918861024126,0.6427306785078244 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark45(-310.55000468575423,-448.97530703227,100.0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark45(-310.5660681227699,-481.5575800664896,92.35880181224249 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark45(-310.8591433762184,-435.8693564816326,18.799680284550874 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark45(-310.99515678090313,-477.5981009872558,6.164982206080822 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark45(-311.01431583450005,-435.5352538643028,92.49010338025323 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark45(-311.08334831628565,-445.48943360670626,100.0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark45(-311.18762847723616,-436.6978489806985,74.64268127428957 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark45(-311.2371000812734,-471.2932689607109,15.563557464112975 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark45(-311.41762095617446,-445.5108873033178,23.50085189477427 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark45(-311.61014625356194,-486.33688375364255,100.0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark45(-311.67376343723686,-458.92547597417706,8.464656855754853 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark45(-311.76001200390215,-454.5948894611465,68.61405087752999 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark45(-311.79840236454635,-456.20925193523715,50.21597499143644 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark45(-311.9765933766543,-458.7597797340121,96.88673143925391 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark45(-312.1632456217974,-434.9148637205701,100.0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark45(-312.20296840451203,-446.28527168553296,43.84124195159575 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark45(-312.3444015649534,-450.2475764892477,82.72431208095665 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark45(-312.37687900109796,-495.63807111660276,76.11666132383002 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark45(-312.81183862232604,-490.15184410822116,96.92495464359726 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark45(-312.9034173852892,-464.6500495431695,2.306928283364627 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark45(-313.02125432220396,-470.8093093628834,53.008005339198434 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark45(-313.0447724698099,-492.8133233104611,24.328104118039604 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark45(-313.303549961078,-464.98035640942106,84.72083174344701 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark45(-313.6430195711693,-435.4685385398085,46.0177332185657 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark45(-313.7836691038618,-452.70658382565426,45.91856243196523 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark45(-313.8262848295506,-464.7135283008274,72.26657921911706 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark45(-313.83185220484313,-437.0452610632024,40.65327826533204 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark45(-313.86257429991673,-444.51444637358503,23.871809924239678 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark45(-314.08812533650456,-464.13949618857527,92.54154580402773 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark45(-314.13823370374564,-470.077056864637,100.0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark45(-314.15770972615707,-456.0054768281305,98.08758142295551 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark45(-314.1901689655075,-561.1547246675113,9.122758942420958 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark45(-314.343567980558,-441.4626528064923,14.741011660273955 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark45(-314.73234379165785,-449.71066836991525,47.139530116705004 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark45(-314.89613821479264,-452.81231784493116,16.94988369803474 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark45(-314.97079216938147,-431.157189745933,92.40577433528591 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark45(-315.06949090424513,-465.02403453900257,100.0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark45(-315.07403465002216,-513.3973384948098,95.06971668006538 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark45(-315.150887919084,-432.4456146135276,100.0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark45(-315.25708227521676,-445.94807233638085,96.2482868008187 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark45(-315.30464848951294,-458.9825196353108,81.5337450612717 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark45(-315.54979714275925,-500.324125153002,73.01526491913745 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark45(-315.6150626050809,-468.19191126902433,100.0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark45(-315.9754644509676,-468.30774206583686,7.5628950071186125 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark45(-316.0202373902265,-464.21364070114913,87.74521919790567 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark45(-316.03961294154834,-448.2311514016354,57.993673292784166 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark45(-316.1045465690775,-433.6562086834553,100.0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark45(-316.22161058108856,-441.5532119822611,31.150391907419845 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark45(-316.23747080576004,-446.17710723375205,45.516394498552245 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark45(-316.49931689000033,-429.92390479668046,49.33227876829548 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark45(-316.58812450724935,-429.9098099871992,81.87216465471116 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark45(-316.71464994789864,-429.3132800381732,15.224771240260807 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark45(-316.71480723420814,-432.95767745624624,73.29811201971799 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark45(-316.75161601356166,-482.14359440022287,100.0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark45(-316.8818739559361,-432.05818761327043,27.62031477659994 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark45(-316.91732634041995,-463.06078556381715,33.82680694220241 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark45(-317.00664031908354,-449.5802928255466,98.90037811636483 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark45(-317.34737324283674,-441.25550955551694,31.180534840590838 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark45(-317.4007755116405,-460.81149286725906,78.22289002871682 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark45(-317.4199680041415,-451.68085348301,13.309712784464466 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark45(-317.69071132884574,-431.60827227516984,81.71658464695369 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark45(-317.771962556035,-438.7277933141175,21.180306328550074 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark45(-317.8080262176969,-464.9014659333844,92.76587375624354 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark45(-317.92185255585997,-489.93904807786015,41.9075079307116 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark45(-317.9487326041584,-439.06118357382815,13.614127198162379 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark45(-317.99023028804555,-482.4586625355585,32.15553396330199 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark45(-318.06987566499674,-455.8583456035553,12.986619962368025 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark45(-318.228039138027,-436.2841051142391,100.0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark45(-318.26513293076323,-432.7925535816703,33.39109337205494 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark45(-318.5397628740155,-433.80538567450463,42.313375096502114 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark45(-318.54025064486314,-430.82978046513756,76.94817175448233 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark45(-318.56106391228843,-443.3685094344017,47.11246995246549 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark45(-318.60882250869344,-447.82716475540855,30.666072039399694 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark45(-318.6195605900312,-490.94424082673373,19.602506402078163 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark45(-318.87144491492717,-473.852113735243,92.87399059722671 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark45(-318.8829995683311,-432.17149225546456,24.88709247502652 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark45(-318.91215306506615,-526.233885609872,66.31765954351118 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark45(-319.0984602675874,-438.68314306871565,44.814982593288676 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark45(-319.14753572097334,-450.0344220969121,54.94465484693495 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark45(-319.3639132639283,-430.9267962517975,18.279952052815034 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark45(-319.42089479043904,-443.36232861273635,2.441560302807062 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark45(-319.46727370672886,-446.0842636829106,98.11282550089393 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark45(-319.89335692967006,-433.3858103928637,83.1491774873079 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark45(-319.89353225516,-466.15011595174417,1.282276923764897 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark45(-319.9175413769249,-443.3879397514913,0.60119644771309 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark45(-319.97835807421916,-426.6947750073238,6.3963281802436995 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark45(-320.1303781639875,-437.1904433318068,6.277574160577842 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark45(-320.2369375747435,-472.2726245119219,62.3867783930894 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark45(-320.3111684212721,-450.9482160881388,86.04776186064589 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark45(-320.3469483615934,-449.1146853479322,98.59574300068687 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark45(-320.49536103383923,-435.48358073055306,19.277839745087277 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark45(-320.535274431495,-455.9459148525196,32.499954787262425 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark45(-320.63384288421935,-439.33735254560327,100.0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark45(-320.6869246694654,-466.7941453403913,17.509080780677394 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark45(-320.86006791483874,-439.55050860036204,54.980264721583296 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark45(-321.1533882267316,-428.20447581362697,95.62494467568263 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark45(-321.39776647284907,-464.812344561115,11.670494614815016 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark45(-321.39872230118743,-424.811259971402,60.522057989417846 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark45(-321.40329025356397,-426.15929296561563,54.811434395442404 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark45(-321.63939037307443,-434.38005415507996,70.64773608964089 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark45(-321.76376719938105,-507.61692706365136,6.4148906819974485 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark45(-321.81076231868946,-501.9565538334066,62.56472213099249 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark45(-321.9609890302859,-474.4938790284774,87.84447101906534 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark45(-322.1139864326934,-456.72513689267424,12.97300956440031 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark45(-322.22653210558803,-483.8853433215545,80.4768721523842 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark45(-322.3369454402823,-465.43480051915,93.18451242692532 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark45(-322.3865704776936,-461.3348884838302,94.32950436271474 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark45(-322.4496459040946,-444.710109238297,19.661975532214868 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark45(-322.4501691914019,-452.4565816575116,3.6987939306221707 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark45(-322.63362637887445,-450.6282404208475,3.2803556367422715 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark45(-322.66996808747376,-459.89727622925324,9.567373703116061 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark45(-322.7910471613498,-460.6609928149864,86.36109403639972 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark45(-322.9896175030749,-441.3501535151311,82.09405152125572 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark45(-323.1481097973811,-427.69327935782593,64.72245031059879 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark45(-323.24967794433985,-430.59254792472854,30.207748512806063 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark45(-323.2692018183826,-462.6313451480942,24.00463996258786 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark45(-323.53963912438076,-449.50338731940866,38.230762769858984 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark45(-323.71246259284834,-500.62778637007744,100.0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark45(-323.87824648160046,-452.4778808363997,27.246093732233426 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark45(-323.9186261604292,-439.39148654410286,95.82849255573785 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark45(-323.920008434807,-433.8717878827357,54.16845145130941 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark45(-323.9803651164817,-431.62839684137185,77.66229681429152 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark45(-324.00092067741576,-491.4191201020223,66.42710339071218 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark45(-324.1582985191838,-422.6647620337828,91.58201921628165 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark45(-324.6532443366464,-441.2497704038989,75.1865609580272 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark45(-324.8990378492417,-495.2688977610204,-1.0530346481642579E-11 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark45(-325.01214001477405,-422.42403985146257,14.258326313156488 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark45(-325.0283845656262,-428.1781687923902,87.42535532987856 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark45(-325.0834680600318,-424.0444675402877,97.21015263525126 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark45(-325.15125164815635,-431.95382789997586,41.056558403893405 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark45(-325.3162088616654,-444.18784612637995,90.03141425072138 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark45(-325.47711437318156,-481.1461851288672,63.745634571140414 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark45(-325.58999991095396,-493.84208417875004,25.893541684596585 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark45(-325.60305360150915,-427.8323811279364,92.90121864165411 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark45(-325.6107032759391,-483.9409985424968,100.0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark45(-325.698728142973,-428.77831781001805,5.483338988209027 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark45(-325.88495523920915,-446.47549924492074,54.94132897405649 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark45(-325.907880053893,-427.0422456136657,65.03019852936879 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark45(-325.94989760003597,-458.7415943636759,61.31737311755356 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark45(-325.95112365882215,-460.5011918822159,82.64805974269439 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark45(-326.34318863370294,-435.7359859060125,91.51169835490722 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark45(-326.48545124004573,-420.97305608416724,100.0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark45(-326.6854914409754,-426.399923518007,13.855881943913346 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark45(-326.78952587458105,-451.1095302191521,36.268268672304586 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark45(-326.8905331750454,-423.9763716725227,11.127881851235173 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark45(-326.9333439302187,-424.4694889226771,49.14243534205437 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark45(-327.0056260444994,-447.40573830340765,31.74984732755371 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark45(-327.1809165000614,-443.5558248823321,92.68953558045004 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark45(-327.22165502888504,-420.75837518846055,28.862288867882327 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark45(-327.30181305621227,-422.94354883908863,53.17446291353858 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark45(-327.3330824251376,-421.22812797628757,23.448962943663744 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark45(-327.36004490643546,-476.0045577791332,10.495345116213528 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark45(-327.67375091548644,-437.50708003916054,100.0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark45(-327.962716022672,-440.429140096679,100.0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark45(-328.0299003899846,-428.8611408340016,23.78530702718176 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark45(-328.3884662978593,-418.41273827640293,88.45529769114202 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark45(-328.4110849483423,-488.5428927839545,10.34384367903192 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark45(-328.53811819891473,-453.81594761354773,12.673386791332831 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark45(-328.58178158554955,-448.31856728362885,100.0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark45(-328.72131506917265,-419.9848861685132,5.9054651557604245 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark45(-328.87169650949636,-434.7135092529205,100.0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark45(-328.9827795345467,-426.465520382527,78.33326149073008 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark45(-329.0059099291208,-470.79183483038577,17.056438645802416 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark45(-329.01024709866454,-419.4350552654224,94.56541899411238 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark45(-329.01369256212854,-477.93584939629926,74.65306027165593 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark45(-329.01852643752403,-430.41344498020374,44.152084673304415 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark45(-329.0795611195898,-431.41285683182724,21.12413966530258 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark45(-329.32201461889133,-467.7886781007896,19.674370793688695 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark45(-329.56894558568354,-427.9882165406688,74.59047100122066 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark45(-329.5695952970277,-448.9576114342134,49.891220911315 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark45(-329.57651123538216,-417.27891607668437,100.0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark45(-329.57672826560344,-422.2139767313168,7.823643618222164 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark45(-329.57930964338334,-428.54218589355844,85.17332153295038 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark45(-329.9037547319129,-496.10996471608627,100.0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark45(-329.92469830524067,-435.49811471314075,56.53604804690957 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark45(-330.11691079971996,-417.4523101945747,37.97298272104345 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark45(-330.3018941499091,-438.2812548054767,70.48977211030385 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark45(-330.42519476976213,-429.7416262022736,0.6215114805946627 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark45(-330.5392466435408,-444.62032343116186,23.58546871303101 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark45(-330.7124046187975,-490.8187355107466,67.11778166288897 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark45(-330.78224295623977,-436.84789757834244,100.0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark45(-330.9705342843011,-416.28148892330387,22.692766534430035 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark45(-331.03623660100095,-418.8124067202742,74.27970082344552 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark45(-331.0531264415693,-427.53855861469185,95.14575522761851 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark45(-331.1280867001184,-420.61840371722207,61.725715911590385 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark45(-331.280338943538,-477.94035790923357,66.73485690922683 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark45(-331.42072504059126,-456.07124491987776,100.0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark45(-331.6491027616115,-442.2986385810598,84.81569171763135 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark45(-331.68474764800084,-470.56174535539617,74.56467536547973 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark45(-331.74414416097,-416.4424411290713,15.485740862850193 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark45(-331.82891703622306,-424.78466256957256,21.804372230713525 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark45(-332.0659200051173,-425.8748027822369,67.94354946837626 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark45(-332.25333857882185,-417.2440854963148,51.03808110515641 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark45(-332.28016425264855,-441.1361425013669,85.47560082167868 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark45(-332.3176711061049,-425.1482079816714,34.48100827564815 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark45(-332.4973397723729,-462.6133097471978,1.4335801849304914 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark45(-332.6007827513845,-434.9949277600442,96.12471310703852 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark45(-332.68089454362547,-435.7257011517459,36.279879213604204 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark45(-332.77427395968965,-457.76528014079184,27.66171652232066 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark45(-332.82147868928496,-414.3941782693849,81.67903839067174 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark45(-332.8639462718413,-430.8148850731867,84.51482142105652 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark45(-332.99910950676855,-418.4458732609397,73.6777331833215 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark45(-333.08642379529056,-418.7097351336772,50.8886700673055 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark45(-333.19057908431824,-426.109626905679,28.99960159603674 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark45(-333.2654854929136,-444.90889058302423,4.142364457467812 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark45(-333.3685252844972,-422.3674348357537,43.32086651392666 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark45(-333.5173812315845,-412.762329580229,95.14076147749103 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark45(-333.5960197052718,-429.47376633026306,100.0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark45(-333.8254136170166,-424.37671630344806,62.66605055754508 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark45(-333.8349497065906,-421.5834007353473,42.61787191384735 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark45(-333.8865279779143,-444.79505610282035,32.051937254300526 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark45(-334.0865219265023,-437.8229412786225,60.17313055553524 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark45(-334.10585559701883,-420.69825964876753,60.43189875721461 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark45(-334.185679901066,-419.44334787589054,39.949816416287646 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark45(-334.3840449402337,-439.66812157297693,57.8331660502441 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark45(-334.40082110120136,-424.483522573723,17.198561693463972 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark45(-334.48396286934576,-453.8029656848643,43.19522287725411 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark45(-334.5704919848795,-450.27617955077613,64.26647935437191 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark45(-334.64435614254364,-477.99413798501297,93.56564892411626 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark45(-334.7087668253594,-434.8520611476571,100.0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark45(-334.7963317254658,-414.88393929801833,65.69082895221476 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark45(-334.82945510381853,-419.43523437500994,81.01411992842057 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark45(-334.85526255078565,-446.2965996447625,92.57374351553855 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark45(-334.94241731997766,-449.1699001887989,12.411789832966846 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark45(-334.9667183949591,-427.3063865025404,46.7504834334905 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark45(-335.104421113389,-433.3879773323861,88.85084045244508 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark45(-335.1669695140244,-473.92357092737325,1.1486114462819046 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark45(-335.3131947076147,-418.47744778389693,100.0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark45(-335.3905376412331,-477.4009842268852,11.738046557263033 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark45(-335.4469414324069,-445.3073263912703,24.388616301323722 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark45(-335.6732014686324,-412.2076331531293,41.13945460066584 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark45(-335.6876460411346,-443.67823742208026,1.4139612396043333 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark45(-335.6973066076771,-490.0322028372686,82.64641168130726 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark45(-335.80447931101133,-439.8322981837833,100.0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark45(-335.831489413656,-412.40196139881334,5.692627441568348 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark45(-335.9236724036079,-415.259504003539,100.0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark45(-336.0841286288395,-475.800243083704,67.15268499568683 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark45(-336.13188720799684,-411.93010430152185,99.1118335522747 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark45(-336.2766571614233,-447.66384917147826,100.0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark45(-336.45408479460565,-467.75853039944036,91.54304459896989 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark45(-336.46122097505827,-420.4637909482461,71.28356201689692 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark45(-336.64828277466114,-454.9368865849648,25.39471221729501 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark45(-336.8363400350976,-446.1450414648637,5.659197612240561 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark45(-336.8859006404428,-412.07606508701474,95.8897155034361 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark45(-336.88954244633754,-438.20742544145565,100.0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark45(-336.93423501115166,-421.12205794974284,73.91291917330136 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark45(-336.98046446247895,-465.5936494328818,36.21973100121053 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark45(-337.0686673333501,-411.97223552637064,7.105427357601002E-15 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark45(-337.07430674611226,-438.8701213635168,21.696640704097888 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark45(-337.09886161976925,-485.79866007481934,7.984659275698888 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark45(-337.42924901654146,-482.1844143975904,33.01054788975571 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark45(-337.5041431878899,-417.23559764669443,4.656814621391447 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark45(-337.7395725821086,-432.6883780099948,26.978629734797323 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark45(-337.76549540612945,-411.39275653243783,80.54661523385548 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark45(-337.80015624964955,-504.8447284225731,76.6151415723092 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark45(-337.9510092156822,-413.83488552758337,39.8831131665267 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark45(-337.9778225576899,-419.5676191426735,98.60386740698533 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark45(-338.06565098093694,-415.6639008453907,42.274907562329815 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark45(-338.30813235568337,-467.4799985754781,15.073416263336156 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark45(-338.3762779622074,-463.86400441190216,100.0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark45(-338.44071150988503,-409.5652047791453,2.581604408739466 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark45(-338.4797307047613,-461.5804548708545,43.03349382678746 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark45(-338.57559098634147,-445.39138621053667,2.439278894859058 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark45(-338.6042000389015,-446.9366352019197,86.58748008235574 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark45(-338.93997672031793,-445.0494084288198,11.324299272849373 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark45(-339.15188636362035,-410.3074835499609,38.64848473680172 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark45(-339.4834035786603,-409.1295838044288,34.079088812613065 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark45(-339.49325753226753,-431.59419992206426,51.52835791290465 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark45(-339.62580522676393,-419.3434709817527,61.21866962651376 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark45(-339.9283416676365,-407.3946409070374,29.45785656437326 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark45(-340.09592691573874,-411.22575484781714,49.520230914467135 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark45(-340.3813390283618,-424.4189834077422,100.0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark45(-340.43793757146864,-459.3646628224268,27.001349982051877 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark45(-340.6850947693696,-492.6103286809809,24.66206019822917 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark45(-340.7706130654729,-428.67314197261317,63.786519893748306 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark45(-340.91667504100815,-407.50219458119125,78.3806860600555 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark45(-340.97899619526845,-443.362598495114,61.40876672077826 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark45(-341.12275844426404,-522.9791968001394,42.313324914570046 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark45(-341.1599922537319,-406.14756212507365,87.95155839812 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark45(-341.3511358720811,-423.07714514262767,32.3393312152661 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark45(-341.4277476923693,-423.1606164013631,93.47825368623376 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark45(-341.5784743727015,-490.55215803709393,9.20350380516983 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark45(-341.69049258675864,-405.56419344636583,59.39959296064373 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark45(-341.84201414375576,-454.03868486051033,54.824202846067436 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark45(-341.9042778920899,-448.89206414472676,100.0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark45(-342.04226545735986,-435.0093103398582,98.10375134739002 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark45(-342.0624807408904,-405.10671918316496,25.626764315199097 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark45(-342.12900962672876,-410.530351618102,79.26830019712492 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark45(-342.295934778584,-418.9024867895593,30.630462082086154 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark45(-342.983590990927,-433.62419609945226,40.31308255669003 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark45(-343.0348733228129,-404.2025536652052,100.0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark45(-343.05112772976435,-455.84855755944955,55.41195671342777 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark45(-343.0885675600466,-407.9640979806413,100.0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark45(-343.282184901378,-417.45026660129105,10.792638794354588 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark45(-343.3897236222217,-415.8899131719891,95.57999603714447 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark45(-343.43030243279964,-446.31779782152773,94.37182498702555 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark45(-343.83617949650176,-406.24664961435565,1.6518909499637005 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark45(-343.84282335970653,-438.25415853224274,81.13619821055558 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark45(34.39964156501273,-34.39964156501273,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark45(-344.07706963928854,-432.13399224453434,100.0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark45(-344.4022766921181,-425.22409539401843,75.80377442705074 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark45(-344.7356774122201,-416.1319186614948,37.895878703411256 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark45(-344.9829567884902,-407.6505012316592,44.54002324966416 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark45(-345.17580911810956,-417.66593463800245,85.89506975418328 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark45(-345.23516978156283,-423.4403697324756,98.44920203283982 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark45(-345.29248893680233,-407.09997286562503,52.550054079975496 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark45(-345.37791224756455,-410.4276488346852,59.18559705345882 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark45(-345.4596062096778,-402.48093137550603,56.51353958114885 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark45(-345.527677964863,-404.3000300429114,72.11503833787822 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark45(-345.5805685364164,-428.5798170494737,100.0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark45(-345.76028902864005,-405.8937372649238,37.807742890313335 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark45(-345.87065115147686,-409.0246489996522,80.73781548917077 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark45(-345.87136247669,-415.34356948079875,22.480965204046683 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark45(-346.0680158072737,-420.272035962057,43.159394502878854 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark45(-346.14796357433556,-414.71377741342144,16.223805242562435 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark45(-346.15708001430136,-434.9877884836821,19.93130824571155 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark45(-346.20238430201135,-420.8264070978528,93.49457608073493 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark45(-346.29341259408415,-404.4491994009095,100.0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark45(-346.31189212979376,-487.79347437892466,77.61649307369188 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark45(-346.59055196784107,-427.1380920621548,20.062896075232658 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark45(-346.73910973973517,-418.9117229611808,10.193691470366332 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark45(-346.8249525541991,-402.6930570315127,100.0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark45(-346.948787062315,-399.9053625720831,61.924414218879775 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark45(-347.03696387186426,-403.05210905127245,82.25124422667616 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark45(-347.2414512370364,-404.5405807603979,24.609406440730993 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark45(-347.31757382800333,-401.2765363671804,64.720599119893 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark45(-347.3484999981561,-418.7499967875644,27.421351712334257 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark45(-347.3656010785601,-420.98847536451524,66.50995403314064 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark45(-347.4909250418592,-398.92035606943375,8.364769082620626 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark45(-347.557304084811,-426.2934206610102,4.415429804466967 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark45(-347.68485251480416,-414.6242301084803,22.759410585109237 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark45(-347.83988912641314,-443.6666025949489,63.880740801082545 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark45(-347.92115371296416,-420.58431072276016,1.4210854715202004E-14 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark45(-348.0757924792137,-453.8706203153797,81.36425314920061 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark45(-348.1445364209149,-443.9470563863272,4.460357936225748 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark45(-348.2020037194001,-412.0510193815542,21.31719624420289 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark45(-348.2071669721561,-451.2934736995275,49.837856758132574 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark45(-348.30109001626556,-493.90819595805624,76.95326062629942 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark45(-348.3138370540924,-401.15690206412927,62.613365026699995 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark45(-348.45342770839187,-421.62925667752785,3.2034074528174443 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark45(-348.48668404914196,-436.0346876614194,29.390994554709078 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark45(-348.51205010072226,-407.35983680453467,32.66340397454371 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark45(-348.56061486827264,-399.0406651118411,61.021497169217696 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark45(-348.9393550595639,-404.3953652981105,23.301745514882825 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark45(-348.9480001704218,-417.0346126947807,6.361950934478102 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark45(-349.1096206938284,-403.3246299426332,0.0624052583504664 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark45(-349.2005833956208,-419.88757659112895,25.620442400595778 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark45(-349.26090655440885,-408.6928350133442,37.162752653290454 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark45(-349.589598016781,-400.5381169924476,12.835785653793977 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark45(-349.9390386226471,-443.0540693299729,22.82920511872964 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark45(-349.9940138514938,-435.5077411215283,100.0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark45(-350.0135605630283,-414.19248684272713,94.0728178824628 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark45(-350.01512564075574,-396.246241112105,95.75414520975562 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark45(-350.15000133727807,-430.9558117844922,25.48157746066984 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark45(-350.16494743107535,-396.2751518217037,91.02361711971037 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark45(-350.3806484004094,-404.3119066287101,73.82430564145898 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark45(-350.41542286576464,-418.2981212155904,58.506856495420834 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark45(-350.48632804851474,-409.10806106022017,84.01946406523803 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark45(-350.5802835136456,-447.0054459037886,57.428249068923094 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark45(-350.60074783370476,-453.35412170324224,63.656056898911345 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark45(-350.6911815241543,-415.10198463378254,35.66608853191005 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark45(-350.69595530540045,-424.47678477126664,43.24388252217173 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark45(-350.86408069147075,-419.9373499953807,80.38903459006593 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark45(-351.08304154741614,-409.0047538493705,83.3838236019875 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark45(-351.1059488721584,-433.1981599992452,86.61216560858645 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark45(-351.11257303889766,-398.1557357843295,38.61847779297199 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark45(-351.19621935820066,-400.9419038649935,3.75145103667531 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark45(-351.3309964252941,-396.29794568075044,1.9586511335413217 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark45(-351.50312632997,-458.6371379479504,100.0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark45(-351.62405159764353,-414.38491385206055,61.89251988889336 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark45(-351.80848571546176,-412.43309404560506,58.954579323603895 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark45(-351.9268403009383,-398.73328732464023,28.81732354391093 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark45(-352.0933990588622,-400.2603380823125,100.0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark45(-352.445817440227,-475.2490772694936,100.0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark45(-352.5740173354178,-427.8292380572676,6.37360089055025 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark45(-352.64924731921565,-402.3960578455722,48.679008698350344 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark45(-352.89826578324374,-416.0815038609305,100.0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark45(-352.9166861953627,-437.0921874959482,5.723630596918468 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark45(-352.9456690630698,-433.766487724363,69.44632273862756 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark45(-353.0473803901302,-462.27863146379576,43.27731356932864 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark45(-353.3700250060001,-454.8699967269915,36.937144719208646 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark45(-353.6333699780795,-462.5188162532373,9.870812524939225 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark45(-353.81020340164855,-416.5758372929354,50.68000384067443 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark45(-353.82180193335694,-425.5577706193046,93.57903146834619 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark45(-354.0477018506251,-399.82885087608713,10.037814813748042 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark45(-354.134394701706,-447.8334844616874,21.16824130808459 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark45(-354.3087378507041,-392.2157275648347,100.0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark45(-354.5634827074176,-394.32243231017327,82.18053897657789 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark45(-354.62476414107647,-414.52050931489384,66.90572466474862 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark45(-354.8948381482858,-451.5090450372104,16.312771806325415 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark45(-354.94901650207544,-409.6034973763637,10.563479396278595 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark45(-354.98602838927565,-410.4238855653039,98.88846529231694 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark45(-355.07102191781604,-406.6961349152862,73.08486856255502 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark45(-355.10866807720186,-414.3416506537685,27.531329980221713 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark45(-355.15337535381553,-396.6860277649695,6.957745977127573 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark45(-355.19154637146727,-473.00138528051906,38.07143286807346 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark45(-355.2068861532366,-395.14772801360215,22.226225848529822 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark45(-355.4735606649158,-427.55659458907553,60.167928470250615 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark45(-355.57124541069965,-441.5525029970564,83.71724629470376 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark45(-355.6741199980533,-394.1539721478044,56.70565622149502 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark45(-355.7756821567531,-405.9247713261168,3.6899015795386987 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark45(-355.8154783330574,-444.58100411609837,95.49535292172538 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark45(-355.8747158687492,-392.39343043006573,20.43512622933457 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark45(-355.8973964779116,-405.7986969531295,87.8810188782835 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark45(-355.9208667318028,-420.6234765129433,49.87679013497569 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark45(-356.4029786230969,-482.7215910936075,2.4937681063480284 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark45(-356.5374443974765,-397.59755910821605,6.4456061934697715 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark45(-356.6573520878478,-391.06803920381446,15.133339675533009 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark45(-357.1036524597237,-417.58740049944066,8.696395627547197 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark45(-357.1385803413663,-441.04466791055756,15.77604340779206 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark45(-357.1958292173514,-456.51636574736955,40.46096243614551 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark45(-357.39239955363627,-413.7065361622243,73.70675448605661 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark45(-357.4114879046534,-405.1222076550274,81.02017545429916 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark45(-357.4617243448434,-439.82644193575675,30.973055480245222 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark45(-357.55230416274566,-391.3582319405386,48.99583311691558 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark45(-357.7286896493405,-398.70547946113356,50.491390009920934 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark45(-357.7378851651367,-390.5976994759633,84.60908848958815 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark45(-357.90220470918746,-390.17549875235846,52.933143350161686 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark45(-357.9079592382726,-430.85061701461206,22.4670826409493 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark45(-357.92995689577396,-418.04070794952787,27.19182909876865 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark45(-358.06355480158993,-393.1105964894418,46.76529920538914 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark45(-358.1981602492338,-473.43349188598876,98.5412973678136 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark45(-358.22370529536454,-390.94088733586506,63.87199558096063 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark45(35.82342977082973,-789.7436213949297,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark45(-358.5542017238818,-469.36306671751123,2.208519418902938 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark45(-358.6534890032956,-451.027796587795,72.67636822626179 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark45(-358.7324577618234,-406.88599383647824,28.65136135782825 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark45(-358.73642774488445,-409.86785322207226,80.43044517151478 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark45(-358.87318910294016,-444.34754612795183,5.368968807816259 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark45(-358.89573158792234,-419.15417147980764,62.95496509267636 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark45(-358.9881678985718,-402.4877333097734,75.05152213574326 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark45(-359.1958224946534,-446.7654989059923,49.57880514888916 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark45(-359.2909742707226,-405.60639456622374,24.256586668196192 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark45(-359.4076329452453,-396.9082856372571,100.0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark45(-359.6402921991057,-396.21262520350047,24.787159979866402 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark45(-359.7696375195609,-420.2554312317918,18.6061082974486 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark45(-359.98089327795265,-397.357428131185,15.945203641249172 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark45(-360.18099671038595,-440.0568732894706,99.42908434462697 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark45(-360.2072768582577,-424.6918546203358,33.469239177137894 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark45(-360.32851075971826,-430.7462124494052,3.7144060291905134 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark45(-360.356829265736,-386.39658315092885,2.287206103338818 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark45(-360.3776024778014,-397.16726569382075,5.383276190362125 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark45(-360.43693946621744,-407.3581687690777,78.93967151696441 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark45(-360.5022274541602,-427.3412957670695,32.35462454648405 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark45(-360.64318280935055,-410.79197096055333,23.777109423152993 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark45(-361.21601592676853,-401.29015202957794,19.85040375586904 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark45(-361.2409893161255,-409.94264808972497,39.9140066645204 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark45(-361.33044852444164,-399.1842684324154,100.0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark45(-361.4199529617527,-410.3583399085082,16.956251757137665 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark45(-361.70018936191855,-395.8670838027742,40.03185799040767 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark45(-361.73796560684684,-392.70362704297446,38.80288516164313 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark45(-361.7673223466044,-418.71292158802015,100.0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark45(-362.1212197081894,-453.1482068102459,23.23352330099067 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark45(-362.1961293401426,-390.4770148144546,94.14637515021266 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark45(-362.27523094460105,-387.70194209080364,23.99820660218252 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark45(-362.28234595161166,-403.5700071505669,29.621960015479885 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark45(-362.3259417225634,-406.53711387683404,46.63371888310337 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark45(-362.37404254516986,-388.4985576301937,69.74237194066677 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark45(-362.41432512111675,-393.3504122563174,81.71300151205855 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark45(-362.44819673946625,-425.7334644825753,100.0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark45(-362.5475534785433,-387.7052759001805,27.67256885921381 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark45(-362.7527701616687,-465.11393114676156,72.31052474218336 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark45(-362.8309241644876,-402.62959130133174,68.29512834082155 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark45(-362.9159906919767,-447.09148592202405,59.90371643220479 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark45(-363.3176555562899,-416.9807625523507,25.226604071692066 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark45(-363.4159253423042,-446.8636077310841,39.463355999486055 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark45(-363.5180880502637,-439.38162790726705,32.784773951026125 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark45(-363.59163643433953,-465.381091070718,90.24176474898141 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark45(-363.62842003764945,-408.5854095219989,50.376791390404065 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark45(-363.6575195752787,-442.9359004691343,24.42349711281379 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark45(-363.7119789546391,-394.76611810028487,74.40751824922398 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark45(-363.7443671408587,-451.7553319433579,25.460399345818146 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark45(-363.8569323511212,-402.8522869926706,100.0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark45(-363.92539381894386,-405.75498017571874,72.33041893733082 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark45(-364.04308606783246,-438.11530521226024,36.925779460927714 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark45(-364.05491172502065,-395.6104774372137,43.74494550653273 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark45(-364.1708371800251,-401.4428094815832,17.04277655683883 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark45(-364.1760399246258,-408.8908313664681,26.128150762458063 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark45(-364.3915018439472,-423.37381534214614,91.86940338744662 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark45(-364.468716075988,-410.6218419144709,36.29163519437094 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark45(-364.54086868150006,-452.81206748457043,54.6597391205928 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark45(-364.70619924614044,-385.0791364219752,69.32155268372739 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark45(-364.9279216316077,-398.68451460496124,62.74957554467025 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark45(-365.01182258969726,-438.3314087006331,59.00965688068747 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark45(-365.0504583554004,-438.0674032122941,44.215622052115236 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark45(-365.0608807002274,-431.6834273985253,14.490496668394009 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark45(-365.16429157365985,-400.4598998675162,41.706650290140914 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark45(-365.3649434162888,-401.4578337816249,36.29271960948432 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark45(-365.38930611396427,-385.8620829679764,1.9817301007650556 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark45(-365.416116818091,-406.0252750511214,98.61216633713309 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark45(-365.45294817150074,-431.03611163924313,100.0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark45(-365.5610651955565,-415.61529347834124,55.843356825825424 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark45(-365.6081638402067,-452.38002602938394,81.84994239017732 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark45(-365.6896840902539,-393.0685747312288,100.0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark45(-365.6926677532745,-383.328825161669,58.51716649321379 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark45(-365.8883117029988,-423.2075992695139,100.0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark45(-365.9385319714564,-383.75018443915377,91.63798242244795 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark45(-366.2615682375138,-380.2915268962678,27.572628045147365 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark45(-366.3626944022874,-384.3338937940638,100.0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark45(-366.38729948018533,-412.5188600638764,100.0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark45(-366.46057175902155,-400.72911979035285,78.69252476148577 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark45(-366.4817201207187,-381.1160968930328,34.240759686496006 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark45(-366.49149001764,-393.3822114850966,71.78807386858077 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark45(-366.5787331068011,-392.24163127090475,100.0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark45(-366.67429538869726,-380.2968922499848,100.0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark45(-366.6891739629081,-411.8244071540987,19.722576214188095 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark45(-366.758606318843,-389.0527619028517,100.0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark45(-366.7782833081648,-382.78398575831903,78.64604327908708 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark45(-366.84921904959265,-390.091281399067,48.6069167133727 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark45(-366.928993836413,-428.5913228797549,7.170188819861664 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark45(-367.2592732738143,-416.1193292754141,100.0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark45(-367.37483565963856,-434.40026541760597,100.0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark45(-367.4035147395067,-396.3181005004109,71.49170758981484 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark45(-367.42054402510445,-391.99294348054053,95.57366810593138 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark45(-367.6497121865864,-411.164043488444,84.43021616916596 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark45(-367.79713381108695,-403.6063774641794,92.53283122426295 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark45(-367.84380433263436,-379.70119553452713,74.05888782525588 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark45(-368.14222310855894,-379.9245266237168,45.879658461861794 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark45(-368.14234485816297,-419.89259818024107,14.395023930928907 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark45(-368.1899814481445,-387.9765277063583,4.11744472036051 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark45(-368.2110740653474,-381.2414214749673,100.0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark45(-368.347037078556,-390.17064073385853,100.0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark45(-368.35108320477303,-393.08170543033395,85.16254198297813 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark45(-368.7215678010373,-386.5248108958039,100.0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark45(-368.7240009073101,-390.5417545305927,28.564766440165215 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark45(-368.83024349342867,-378.7559613342245,22.979670414351204 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark45(-369.07898347365943,-393.41817058512646,91.26904265728945 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark45(-369.16273745839544,-377.60756266399613,69.54173440822899 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark45(-369.16894817340824,-402.20837667585243,45.29890557050976 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark45(-369.2690116770875,-402.45726663705676,4.810379564674378 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark45(-369.38438044225086,-397.2998384185422,19.349029185248142 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark45(-369.42710757758095,-396.2942010324512,6.003481686460873 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark45(-369.4325341727004,-382.95304914165456,65.52961208011686 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark45(-369.569056224358,-387.68229450124574,100.0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark45(-369.65180957384547,-385.7970848953134,38.56130504604542 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark45(-369.8533765036905,-424.60810430860664,36.13105815409705 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark45(-369.9890992984285,-390.74126684253764,35.14802415249753 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark45(-370.04194686080206,-376.2233401077982,49.14276540344554 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark45(-370.04429438141716,-421.53359742096507,81.4500524264289 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark45(-370.1661861857052,-377.1784593189388,47.19864170862142 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark45(-370.19945387327886,-394.2165298159826,77.00581978058545 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark45(-370.35919863443723,-393.5519762894461,25.06463680165345 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark45(-370.70495368825806,-388.52751874030065,68.73727980007635 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark45(-370.7577034370585,-391.2419639319247,21.87090934085809 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark45(-370.94287404720995,-392.0751076219396,18.149282806429227 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark45(-371.02290264433327,-380.1890848616993,37.817330727828875 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark45(-371.08878692458364,-389.5900015921962,30.29425348699138 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark45(-371.1237765480382,-404.52997203676915,16.870685039764993 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark45(-371.1592495109948,-391.4716847342885,70.10296654009593 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark45(-371.1603410182861,-402.4216430115873,87.54208882033112 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark45(-371.4111654251862,-393.3415580953297,29.733238967597003 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark45(-371.51402105657513,-394.3128297172441,19.01937073506597 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark45(-371.5349734485131,-378.46357697256747,19.79826663732527 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark45(-371.6537138275339,-395.1402730336574,78.59529539513298 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark45(-371.70291287758647,-376.0012990847094,59.63289300460147 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark45(-371.7078078500996,-388.2554532722352,100.0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark45(-371.80426810723833,-382.4212333513517,86.69524279482539 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark45(-372.03231070539573,-411.5596840451736,51.294938868509036 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark45(-372.0689605598151,-398.3564541642302,100.0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark45(-372.3235350296949,-382.94773950892977,38.2448132564854 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark45(-372.5338342755539,-408.0278363763127,31.816885537227563 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark45(-372.6535430900685,-387.59971019090756,100.0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark45(-372.6563938493567,-457.79941206126244,36.135644847401565 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark45(-372.86002098514393,-389.87848930050285,79.64732263345056 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark45(-372.8950544459375,-381.3306510420529,2.480076325706591 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark45(-372.91128783231807,-439.1405447364384,78.71990796991128 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark45(-373.0129793136174,-390.4727178034027,100.0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark45(-373.29911202918584,-415.4621583362092,100.0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark45(-373.43561588554167,-385.7697737758329,74.59150747614166 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark45(-373.5726659487731,-393.5988874905889,46.308479978179605 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark45(-373.59273039035793,-381.29209774502,48.39279092844572 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark45(-373.68354870936673,-390.1626951241682,26.044867222658468 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark45(-373.8258375793601,-404.10704656798526,100.0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark45(-373.8362025795401,-395.12594676659995,12.78249375568123 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark45(-374.0613702107442,-412.02267247005994,11.420221143855798 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark45(-374.20750696219415,-400.1288466628238,10.400783943131504 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark45(-374.35911866395975,-422.2749921793974,27.825950593981517 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark45(-374.380689180186,-410.42967658732925,15.708193027188926 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark45(-374.49711742186776,-401.5205733659915,52.28429513117888 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark45(-374.5117022642365,-421.1287702785536,44.36883704536382 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark45(-374.53735977284094,-396.21330435757875,27.368190374792206 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark45(-374.55019033433484,-378.8363859694476,57.94694342150842 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark45(-374.7143506799207,-404.0975247849901,42.08870563798763 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark45(-374.71873236490654,-457.8406374015566,10.351068408389267 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark45(-374.75522254306406,-414.85343062543404,53.79604161782271 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark45(-374.81308123384,-468.43912862108925,13.304372000342553 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark45(-374.87223010561104,-382.60452223518854,9.71799883289735 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark45(-375.1030424656548,-455.8692855895649,8.89706136174621 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark45(-375.2707039268764,-374.54305784224647,100.0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark45(-375.28186456657477,-403.4804118186748,47.16746511323785 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark45(-375.4917701759488,-376.5096138000383,25.05261700801647 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark45(-375.6401363053935,-456.63963927050435,76.07347277013196 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark45(-375.6637344203182,-429.2941234529001,100.0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark45(-375.7730709532273,-450.15583730387254,100.0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark45(-375.83593418056057,-384.47755825473587,97.14179383435496 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark45(-375.88181623856656,-410.51837498833646,41.34708820218188 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark45(-376.12462549158886,-399.5590866613592,13.340033522044408 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark45(-376.3734224665312,-381.1710616027141,67.43738926814649 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark45(-376.4053048483713,-390.5555018353454,88.10359442917695 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark45(-376.5036775310031,-376.6363986325389,100.0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark45(-376.5207716060384,-394.4994419199053,90.79334697142042 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark45(-376.58752555015406,-387.8528294200928,52.39635346791429 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark45(-376.5945198044784,-387.73783642114716,6.973435798468699 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark45(-376.6452876659373,-373.59106531309845,21.91115094317375 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark45(-376.6805887810604,-377.8645174095254,100.0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark45(-376.7557651020982,-419.61087366243385,29.25103497775666 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark45(-376.7696914908918,-378.11691611748296,93.3862269123178 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark45(-376.86131134598986,-441.3723993833354,100.0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark45(-376.92505106130926,-394.54071780613504,18.952379857200526 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark45(-377.07607427935966,-423.4615678580713,69.32910810379511 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark45(-377.120288565763,-372.1232819608269,6.93072788067899 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark45(-377.29033681407435,-372.5258021927991,78.72942471120078 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark45(-377.4521232614861,-423.29243354716937,24.704431170555836 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark45(-377.4703036787149,-408.0734506080451,100.0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark45(-377.47206797289607,-378.8027028344288,75.03694901082505 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark45(-377.52208746060796,-458.6931928121908,100.0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark45(-377.70831740133286,-387.6739991534574,50.05904824590206 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark45(-377.7996184026775,-374.9215219560028,100.0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark45(-377.9416136354626,-379.87787213031254,39.14370586574654 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark45(-378.19159058126934,-384.032125975328,45.28421635692118 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark45(-378.3481608156761,-392.6884897783641,14.983028507874693 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark45(-378.56530646210797,-440.83363640239105,20.494084243946702 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark45(-378.5662835603288,-404.5122992599491,66.33462424037702 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark45(-378.6039270909563,-397.93435128698883,100.0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark45(-378.64503280552174,-377.9629182309558,66.57860643192252 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark45(-378.6855499532942,-432.30331078274793,100.0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark45(-378.99438732182097,-443.84315297280597,100.0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark45(-379.0055241997889,-394.09120182467575,95.60899639390564 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark45(-379.3166214883135,-374.2316267450184,95.43437745620747 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark45(-379.3376063549293,-373.54578349516953,27.953688866619004 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark45(-379.49421920984776,-414.6685640395125,27.221184337017903 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark45(-379.5539263773883,-377.5285958775264,49.42722288923528 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark45(-379.56731581563304,-371.90655551059126,47.03415656036995 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark45(-379.6381181898767,-403.9698705168515,51.11985648325225 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark45(-379.64240092770854,-391.0865437038166,26.092027022962313 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark45(-379.67764124238374,-380.13183793149256,3.027134418516937 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark45(-379.71265966372295,-401.1472199106276,88.4602675867558 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark45(-379.75729538923053,-417.5515838591669,49.15764153518039 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark45(-379.8405798495008,-369.3107159585024,39.67812585358345 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark45(-379.85507118589544,-391.52332060143857,100.0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark45(-380.04694512896964,-385.9440404786425,3.0211466811403938 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark45(-380.14208878898523,-431.6346747504528,24.753658614684056 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark45(-380.2231913210332,-446.91190750201093,90.89406390587675 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark45(-380.36133320675236,-368.9809196352307,37.91370107402631 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark45(-380.4223793052675,-396.13657647258555,63.14491074811107 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark45(-380.6079843664699,-371.9611002194268,100.0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark45(-380.70963229646503,-397.11094562710974,53.134708987896175 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark45(-380.94613565673507,-415.502903547295,72.8857627211006 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark45(-381.064032838616,-410.3988446410093,35.135279260567415 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark45(-381.3792182364746,-406.7460240643267,62.23630636351848 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark45(-381.40666731991473,-407.0132174982552,66.36693590819536 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark45(-381.4635687813032,-452.79756024679534,42.156539912432095 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark45(-381.64851972649745,-410.02984528992476,100.0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark45(-381.6954545260868,-379.77581636979244,4.913614899627717 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark45(-381.79423766460246,-389.948180226059,64.79927020113175 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark45(-381.8484994774217,-372.20826407597303,8.118402827258336 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark45(-381.8563258674473,-402.1931201301965,94.92857860436516 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark45(-381.948353735142,-407.13124316891964,67.35354842298588 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark45(-382.0614399707033,-380.0117571270611,22.130008901389076 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark45(-382.0630220471105,-367.74035190074477,47.53358848174736 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark45(-382.07605654087934,-367.4391452667932,62.00578433946069 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark45(-382.2246720328637,-368.75555252157596,100.0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark45(-382.30093113411493,-428.61924567436074,69.87672813996176 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark45(-382.33442787455726,-386.4836821646171,82.6368133849924 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark45(-382.524578443317,-374.130401028968,15.173430585326628 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark45(-382.5703423946253,-375.4343268309102,51.60286736212947 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark45(-382.6057747562221,-394.6711466676042,100.0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark45(-382.6168148120376,-366.5233303466771,92.20529767390161 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark45(-382.88364247620444,-395.97211318615547,40.89319715159371 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark45(-383.07808652789095,-394.7442926979924,52.8273323008259 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark45(-383.3360335372321,-382.74665411839555,100.0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark45(-383.428396064231,-370.1971585317227,13.684982451212818 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark45(-383.6817864171274,-366.0758230440414,2.494007410097481 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark45(-383.6844461386032,-373.59269213540585,54.35710630236275 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark45(-383.7153869562671,-368.4554333320923,76.2341238224686 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark45(-383.79730006422017,-396.8700227506162,59.200479053364376 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark45(-383.8450074558974,-362.5065986375576,55.26702827439621 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark45(-384.19462399898,-382.65913049044167,93.93774299290125 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark45(-384.3195883342205,-396.1184513268315,72.94286341976525 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark45(-384.33244023062514,-371.1230664233181,23.551035349664147 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark45(-384.6257152467728,-393.10009793547846,5.63987484329418 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark45(-385.0730277465208,-390.2627244665734,22.831371366854384 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark45(-385.08341626507263,-362.0260376669236,100.0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark45(-385.21680718169966,-373.3875150761637,82.53979501433258 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark45(-385.468945240817,-396.5549856719197,10.946268243825656 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark45(-385.59907565025037,-367.54468748087584,49.69903380434681 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark45(-385.6232181432199,-405.5657184750086,100.0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark45(-385.7400732474805,-362.6390855605039,51.48369409968622 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark45(-385.9191096922318,-383.16828884360444,97.05629778912655 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark45(-385.9738681598499,-434.5810491006051,100.0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark45(-386.1215727935825,-382.61574356564023,3.393354996771407 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark45(-386.3163688132479,-385.54445888894855,12.598674823608818 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark45(-386.3313993318121,-377.68629546784786,100.0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark45(-386.6591566316003,-371.3050670047471,62.94186366458726 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark45(-386.91414583557383,-415.873377899358,27.340561132463108 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark45(-386.91756399865926,-375.29309380782513,7.866028210964245 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark45(-387.0156404150455,-376.44723342411277,100.0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark45(-387.05539509629426,-372.7470869385372,25.511112780321028 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark45(-387.0838613968423,-362.994007029186,100.0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark45(-387.1727649255482,-361.09833987965425,26.31168232246364 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark45(-387.24521721327716,-405.67952117209256,0.03981514733875713 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark45(-387.3616374989109,-377.0587276948263,5.522590480396872 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark45(-388.01793681623104,-390.1543778882575,100.0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark45(-388.04074256580896,-372.7648438447763,100.0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark45(-388.14753806310375,-383.98415137798435,7.447132430290765 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark45(-388.352565921125,-375.3376173989059,6.474208216928702 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark45(-388.412120953428,-358.92368412379153,70.1199710935712 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark45(-388.51464473990643,-404.5618015705727,16.986655409398338 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark45(-388.60385058051554,-415.1890082707985,5.578617419354856 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark45(-388.68979082460703,-367.3261117890227,62.79196031159202 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark45(-388.7371219505065,-361.2968140431908,100.0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark45(-388.77183549410796,-374.8226085013123,9.588687219736606 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark45(-388.8146193225634,-370.09872376459543,31.910531066756818 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark45(-388.88441809372483,-360.8035692739413,89.54761179204868 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark45(-388.9886487740546,-369.15735885999294,0.8050147184616208 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark45(-389.11604092520327,-381.282950981683,42.54294700166133 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark45(-389.12789798687203,-365.54890008137113,86.49983450395041 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark45(-389.1695352700245,-376.9630559789654,70.83264327264646 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark45(-389.1800139043943,-384.58821261136734,10.363137748552262 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark45(-389.2537198115351,-395.8810588204723,7.016087367786142 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark45(-389.29731993456005,-373.30602688342003,49.766195828127394 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark45(-389.38559605505884,-370.3833918247618,100.0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark45(-389.39169742132367,-392.98043133032735,72.50408322075242 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark45(-389.6041506413271,-373.2430978615788,28.305292700787703 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark45(-389.68580664848486,-364.4672320626027,100.0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark45(-389.70735009990415,-357.1587314525038,9.385425044184444 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark45(-389.79297198299804,-365.09601747246165,30.379799272735397 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark45(-389.84456587585635,-361.7017241623745,-36.59360328472978 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark45(-389.89807113347626,-432.7020128878509,98.69674787755051 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark45(-389.95976778887183,-369.39900670228985,28.31720508490349 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark45(-389.99640045559914,-367.7055598812591,8.444840800785599 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark45(-390.0653830106491,-439.9898894314804,84.1684363179858 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark45(-390.0832460862886,-357.5735682773589,58.166130658746766 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark45(-390.218271491389,-391.02893259572227,61.50554000676766 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark45(-390.3924631413987,-369.40560333590963,29.896226960752855 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark45(-390.5904778747121,-362.9353996641487,23.906286649562603 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark45(-390.67754004439644,-385.42813491399096,42.51386126476078 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark45(-390.6854874687846,-368.00285042336856,72.62270525889971 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark45(-390.85134654621413,-360.78714672555986,49.48953728558493 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark45(-390.8546110748813,-357.2108193112537,25.681464552257907 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark45(-390.9890316890404,-377.030808500834,57.5573639789356 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark45(-391.0422296885126,-401.1663584647063,9.66335597836769 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark45(-391.23376722026353,-363.7292041979303,0.7590336490188179 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark45(-391.24540400372223,-357.8183341715634,31.09185892729414 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark45(-391.54225886271547,-362.3283012074006,27.27200926669672 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark45(-391.6214403615915,-427.45561113615395,50.31097385994926 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark45(-391.77253369323716,-370.61696219455433,19.835813404081648 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark45(-391.8979935474277,-357.9997070315349,9.144305299399436 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark45(-392.0078972678157,-393.76883640561334,100.0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark45(-392.0987002716291,-418.37308031457815,83.96166100168091 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark45(-392.15442173518636,-391.16138705803206,39.67808677520199 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark45(-392.3415790691501,-379.81906710077146,67.62519600874691 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark45(-392.65460370712645,-367.4969052888564,23.722707999268756 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark45(-392.95762992272614,-423.66663921214536,26.656437183681277 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark45(-392.969677131553,-384.54526025146134,50.42781936989047 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark45(-392.98571413604157,-405.0511150128009,49.936872346658504 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark45(-392.9946357619962,-363.05073101893356,37.40756743388144 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark45(-393.0256936393427,-414.0725671568685,83.273830030977 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark45(-393.1311027201987,-389.2480535185313,71.35101841918663 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark45(-393.1741755623823,-377.3559638296403,81.45510378511344 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark45(-393.2628918228442,-424.5246552040502,74.26357218120177 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark45(-393.3151408262674,-377.15790525406,34.188885816586605 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark45(-393.34723073503676,-414.43241471960323,71.42164794535009 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark45(-393.3520725703853,-426.133725916925,9.290738627407308 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark45(-393.4051790752192,-366.77725291877886,92.51272501701361 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark45(-393.79036434410204,-356.30472883625373,4.904080003853892 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark45(-393.8229097960504,-425.19619604020477,54.40195946489587 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark45(-393.96561149654843,-402.069828498181,21.96026786400624 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark45(-394.01464033204945,-403.8066863203864,100.0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark45(-394.15839128894225,-355.43649587790065,96.50769354422113 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark45(-394.2776766086171,-374.0746911704741,75.07524564726612 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark45(-394.5020742379064,-442.8764099836109,82.38246622800102 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark45(-394.57415125011966,-418.73938589699435,18.463063318528825 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark45(-395.10869780053804,-373.58735509439373,37.68357984809822 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark45(-395.65437120998473,-361.0261646324503,63.83897057922101 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark45(-395.7226469916061,-367.97908233154806,39.39032148487698 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark45(-396.0476929580316,-403.1794459318256,91.2437490158641 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark45(-396.1508252448903,-408.65729949122493,66.74697645486978 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark45(-396.2293714183944,-359.77213147772216,18.60548384692295 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark45(-396.31971216578063,-373.9092346958914,90.1175513941055 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark45(-396.4299399545785,-350.49709605927103,4.080084875245632 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark45(-396.59195924028387,-406.15984051128487,55.20573183979923 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark45(-396.7101791488768,-355.64474593444294,13.68252167163439 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark45(-396.88652919056165,-366.2962356146143,16.213067051584915 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark45(-396.9320142815715,-383.1670701554365,25.511930475719552 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark45(-397.0953790687844,-411.2947215485342,98.60327737845702 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark45(-397.2279738931728,-360.1351085177978,4.523734841487581 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark45(-397.2758147800498,-357.73351622553736,26.802149138873816 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark45(-397.2879443044448,-353.5543873838878,64.42949412734654 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark45(-397.29679883033157,-388.0017441901102,17.02306710318726 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark45(-397.4102551153885,-368.23806330862647,100.0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark45(-397.43744847968753,-399.306865038389,100.0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark45(-397.4989613118876,-353.3727735511591,8.922052921751344 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark45(-397.63427672002956,-350.9871138436295,41.981253006552635 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark45(-397.7143136279885,-398.5662858328745,62.62181914298682 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark45(-397.84200231542843,-352.24125689594405,74.35054339664495 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark45(-397.92601529313157,-408.6584067611941,13.166030451543946 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark45(-398.0743964509771,-349.3666223240382,100.0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark45(-398.4508068068799,-388.8556224478548,57.887148147135235 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark45(-398.4972039218002,-348.2281246621087,80.8714843774786 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark45(-398.88102567258403,-402.78563980907313,100.0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark45(-398.8875503499104,-372.053568240076,1.4318507873539232 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark45(-399.05517967089236,-434.4586927833744,22.87641225021258 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark45(-399.1302564895527,-381.85321816703663,93.06315681532308 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark45(-399.1618122014741,-350.4739900734521,15.749526406465407 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark45(-399.39444791345466,-369.1426160498769,43.20006951213844 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark45(-399.5613079228773,-356.3049802237949,3.5584150446801104 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark45(-399.6152762993595,-380.8740550060729,87.77460115869314 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark45(-399.67679418949285,-365.258794135432,36.281735035835744 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark45(-399.6854823225668,-359.10956256132437,9.190862887445547 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark45(-399.98937520273336,-371.89684084176275,36.81384816876172 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark45(-400.0674560552844,-381.21966044378337,67.56776049763357 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark45(-400.12871104945685,-369.3047053510458,78.52531257213414 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark45(-400.3025855337446,-429.00194661842573,67.01255059185169 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark45(-400.4555659791439,-419.24498248376875,74.24052583981927 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark45(-400.5359190960874,-370.146937142546,21.163822793044517 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark45(-400.61940910977637,-353.97920819138403,58.21337998035645 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark45(-400.81387088674745,-369.86934522168633,81.61877295094047 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark45(-400.9847153664237,-345.0320785178689,33.81225730564515 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark45(-401.0209403592697,-346.53648476453526,99.70057101152753 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark45(-401.09416232907773,-400.10789457419963,100.0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark45(-401.09472058476297,-361.2239705861596,82.16403434961649 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark45(-401.47409481326525,-345.60904069161137,89.34372281308521 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark45(-401.47699995825707,-381.16763734145803,0.9055012082677081 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark45(-401.6275517835308,-374.70397447232926,97.31160560347675 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark45(-401.6814252367188,-353.84685925875084,44.39864296451708 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark45(-401.72851338122484,-393.08552352560304,67.03429719631765 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark45(-401.87170268635464,-360.8307360413015,98.89282785228676 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark45(-401.8824612304038,-358.5701190728235,60.65375412237398 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark45(-402.08371553826566,-371.12950481811276,6.9188459625633385 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark45(-402.16679716119194,-353.23163107305834,85.92158576807151 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark45(-402.1779296402443,-381.04923377305784,79.91927888716862 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark45(-402.24044201757016,-412.2742546581316,1.7306726914190023 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark45(-402.2425799541839,-345.0436647348713,74.37081445831132 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark45(-402.2618406302416,-346.92974458343394,28.50182238656663 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark45(-402.2702192099921,-390.1283338198834,36.87138687398442 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark45(-402.3078947688208,-359.20528070084254,29.506170516944934 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark45(-402.6915558536204,-352.68562413014354,23.448739798049317 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark45(-402.7337932586163,-357.380593927373,100.0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark45(-402.8578943171167,-350.77112230719854,42.643294874067756 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark45(-402.9933983330858,-388.3265243731324,82.64352038563658 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark45(-403.2572673932549,-361.14628527712046,11.796443680047688 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark45(-403.28813177506174,-359.16392471313435,60.37721872549625 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark45(-403.3758741028593,-400.7953343379205,7.105427357601002E-15 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark45(-403.4001840599162,-376.2557935344109,46.839177267853415 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark45(-403.5615361476432,-347.49798686520415,23.66953866294341 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark45(-403.80597757704027,-345.78018757700727,99.54348788830447 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark45(-403.8131134033448,-343.34560723882953,80.86233855632764 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark45(-403.86720806970607,-349.647589430107,12.545100139133453 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark45(-404.3622376907711,-355.5541077950254,3.52811026221913 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark45(-404.509890353751,-370.29538246530444,64.5706847461532 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark45(-404.6842690473153,-367.0886902341042,23.914757758943892 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark45(-404.6894421149116,-387.67404496758843,73.78571299461944 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark45(-404.7263033826367,-349.064947223647,44.49410553986843 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark45(-405.1241104568334,-421.70327803746045,85.2132045943618 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark45(-405.47176759290215,-345.1332947627145,87.73695143243103 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark45(-405.6033847610392,-351.60520953781577,8.48473420516342 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark45(-405.66124837134,-400.67556244673403,37.1657570805412 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark45(-405.7269982671711,-378.8474734923938,97.69085809018597 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark45(-405.8365781054115,-397.3876011154765,44.78947715971981 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark45(-405.85770940176303,-365.8287888270155,27.848767704327187 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark45(-406.0197628060915,-370.1445026004312,36.20863882528042 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark45(-406.02739262608577,-373.2887605336439,77.81303393937816 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark45(-406.08633173652305,-342.4410888957862,49.76768047156045 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark45(-406.1880583471483,-395.80965024458715,78.2883847427475 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark45(-406.1934431952389,-354.6665820129787,65.77747042935897 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark45(-406.2190205329962,-375.5893412023887,61.04704472883208 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark45(-406.33123279227397,-352.8318112051368,100.0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark45(-406.6363362145655,-358.4686851710029,19.674937152463528 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark45(-406.75217467904747,-373.44390014230356,100.0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark45(-406.92875489942907,-347.5990796282198,38.45804107162775 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark45(-407.08970365407026,-380.499233140811,63.637677292815766 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark45(-407.11584564182124,-347.4902014756434,74.55895620705692 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark45(-407.1299219773974,-398.069596034134,43.70256030137128 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark45(-407.3825617838302,-342.6088587411657,28.504361898832144 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark45(-407.70612436028864,-400.96973447691965,55.7895409649137 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark45(-407.7075990385962,-422.6201184170522,37.352791470083844 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark45(-407.7334050531014,-347.2139970108734,88.41914812705008 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark45(-407.8278878990892,-365.79271018415744,52.34623072046665 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark45(-407.84202032068197,-384.9784975508428,66.812421368213 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark45(-407.8852013092048,-343.29300590317575,95.04133775794034 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark45(-407.9492425906271,-376.35387405316953,15.977890350080571 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark45(-408.09827195778615,-346.75649745632745,2.4048918931013077 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark45(-408.37048476871115,-379.84465022089216,47.0339126650841 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark45(-408.38537597293714,-388.401286646644,82.86023868248387 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark45(-408.48789320614804,-379.89252827079633,45.52472244043233 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark45(-408.6965163498111,-345.3344748687823,30.880887610742377 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark45(-408.7129970509432,-338.83507639542177,56.809793577865335 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark45(-408.9118430092764,-362.96053983145873,29.459939957993445 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark45(-409.04734241879595,-363.6553902287505,7.3260268684638135 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark45(-409.10381580082776,-342.39388661717334,4.8339495486421615 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark45(-409.11041186440286,-340.05157684331385,100.0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark45(-409.1536758950495,-372.385009740643,75.39932475143783 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark45(-409.483717537387,-366.59711882750946,40.869776315874816 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark45(-409.60335045880646,-342.587993822848,0.6880247054487825 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark45(-409.61021850434156,-343.1763837294168,5.629947660950663 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark45(-409.66744405637115,-337.56258160692965,31.03722178706002 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark45(-409.7043193927198,-378.13134351729326,41.366306801196515 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark45(-409.70965556783534,-375.405123084746,30.383076741850772 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark45(-409.82981757035367,-388.92421104416474,4.693686159217705 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark45(-410.1400300956379,-336.15804606964747,87.98312251277426 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark45(-410.14707090701364,-339.5720144921211,35.71075309258168 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark45(-410.175750268231,-350.9198519969705,47.437799550226146 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark45(-410.4115052752963,-413.2922261632138,100.0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark45(-410.4472275308967,-344.4799463486585,8.46405320374987 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark45(-410.45850391399574,-372.8857685084066,88.09742482413766 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark45(-410.70440559170527,-337.68181400717555,6.345915185395953 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark45(-410.9264170791903,-346.3281383220739,41.846814297983144 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark45(-411.06509315195365,-339.39757375255283,33.944754288686994 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark45(-411.1302896578234,-397.13488241023015,65.42609830134396 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark45(-411.1786020468596,-338.53701187578605,100.0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark45(-411.21911710516014,-350.3685005269755,24.99990434575477 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark45(-411.277721330298,-341.57329960195545,58.562030866187825 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark45(-411.2873510511643,-376.6252938700809,66.63424617536594 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark45(-411.4078224600989,-397.974904910539,99.10352253561604 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark45(-411.4179084382756,-396.38446719312077,57.062509656023686 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark45(-411.45011263364194,-365.1834366583707,100.0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark45(-411.4942295881647,-341.15529797638936,27.3264600881689 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark45(-411.66184285294537,-340.93683296764124,78.44710040478373 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark45(-411.82548224576425,-367.4673671102596,100.0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark45(-411.85638644847154,-362.7874891807456,9.611566359334105 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark45(-411.91177436725627,-345.567515794436,84.29643293069938 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark45(-411.9191811401257,-342.7760637969303,8.977797518312755 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark45(-412.14438820944605,-347.77267855226756,21.932764565989828 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark45(-412.26440935014847,-338.32426012868757,86.52939999128714 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark45(-412.4113066034871,-340.9737986673872,100.0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark45(-412.4363012688864,-423.68102621388795,32.15972957505272 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark45(-412.51649080352155,-342.7399121529217,12.565562554218147 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark45(-412.5551132446424,-374.32417552201656,49.59743472415846 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark45(-412.562283856667,-334.30373863628176,49.80739941748712 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark45(-412.6718001261463,-399.16044023394795,66.05972177570422 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark45(-412.78341772013766,-340.47646763143433,31.47100292122363 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark45(-412.88055478049597,-342.0637317286605,49.44296354906962 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark45(-413.03995352847744,-353.67735194880174,31.97266209177647 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark45(-413.0739723200812,-365.0509014947204,73.3568787317802 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark45(-413.1282173729214,-382.93293450971623,18.199216367658536 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark45(-413.47052481210216,-379.4658367391072,49.97955711648377 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark45(-413.4738878172766,-345.5972849248006,78.61100472219528 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark45(-413.5277155119903,-378.05270199562267,66.49662720813544 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark45(-413.5425332316603,-334.73211114370497,45.23630029033268 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark45(-413.5800132551743,-381.7112902484659,97.04638657805259 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark45(-413.76026007733594,-338.28353364092635,80.36428774558135 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark45(-413.85848875071844,-332.2153692331414,98.74218372622238 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark45(-413.9948812723896,-347.00180112471037,9.019772443774116 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark45(-414.08891985302165,-332.87351884312835,41.710810063165184 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark45(-414.24575018192843,-339.846516127501,13.232321408401589 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark45(-414.4339964779729,-338.6948066135585,29.384049531853123 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark45(-414.4605945365685,-352.4298966236128,41.62236810141425 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark45(-414.49488451009785,-333.9038009259648,99.40588677714047 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark45(-414.5869100228727,-343.0030609966133,66.36520008338067 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark45(-414.60731999559977,-346.56052728879484,46.37653905216433 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark45(-414.63408264257066,-331.39986241105566,2.4934008044158276 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark45(-414.64205641192774,-379.09652542887704,100.0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark45(-414.66884419292376,-339.3749815128676,75.42082074943622 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark45(-414.7936278309597,-370.8943441624631,91.41241951673331 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark45(-415.06158498879927,-341.8277215855754,29.249327492702406 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark45(-415.0689092510958,-339.99726766563305,11.369585705559345 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark45(-415.14171569221685,-346.27299385064487,20.337389227564714 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark45(-415.2290439820067,-424.60125211949713,26.448575264436712 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark45(-415.3202356530534,-336.65078292779356,15.04290899184052 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark45(-415.7166065399876,-345.2451206108112,19.355663137466124 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark45(-415.8159724584756,-351.70952324709634,92.81228332527037 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark45(-415.9495610029075,-425.0978110183026,31.414616943546463 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark45(-415.95982172607285,-336.5365436443056,100.0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark45(-416.1546340373036,-357.388665669771,20.40083134810584 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark45(-416.1571787612051,-402.9328551296605,18.08248948474362 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark45(-416.19948338062966,-358.2267426019521,54.766059366452254 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark45(-416.33977011159186,-335.95878690738715,27.546497215114357 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark45(-416.4637444864872,-352.76307502189286,97.66710246046887 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark45(-416.7080873908593,-332.8165403396053,83.25292573739597 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark45(-416.87390110883086,-363.53577765836775,100.0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark45(-417.18682606840105,-337.6979267731412,45.40634752618119 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark45(-417.23024444098127,-333.70044344036785,18.20050277026988 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark45(-417.2435654277141,-340.03438817814805,58.331763049864236 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark45(-417.38384930638176,-346.971117022208,63.07327112275459 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark45(-417.4607052202474,-376.18543192314866,96.60732203214332 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark45(-417.4642267706384,-349.86327231984416,57.71790366941673 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark45(-417.53412234428464,-333.43672359781834,8.587203554885448 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark45(-417.5494612898454,-340.5471605833174,91.06284454711255 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark45(-417.58676011869187,-371.3884542367884,1.7978355781146433 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark45(-417.6887564651754,-355.7295509071883,30.00541660681438 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark45(-417.7356936540487,-332.4487278997228,53.65974177121245 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark45(-417.9641184630493,-382.70582206347143,29.97186400994335 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark45(-418.0675744009338,-334.40535068527447,3.4627782218281027 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark45(-418.1420641450838,-388.82249644109737,83.09329328271738 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark45(-418.2400790107755,-369.86211548007435,100.0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark45(-418.2565984902204,-333.5390774381825,34.045190603309436 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark45(-418.31028710925943,-342.55340998434275,80.7425342015197 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark45(-418.3677025963845,-330.30451159968226,10.757811025900295 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark45(-418.68310261245523,-393.6002635155825,89.91243699169061 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark45(-419.1285615771925,-334.46967235430066,96.90360091711798 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark45(-419.14856878092684,-349.8637778932323,99.93164106105763 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark45(-419.3180023927785,-351.05024711368816,3.552713678800501E-15 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark45(-419.33358273382277,-364.6415740541332,57.73416382387438 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark45(-419.357323590829,-380.669451505511,5.173305606431967 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark45(-419.3593891470117,-358.34225701534905,55.03393575010037 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark45(-419.4903760085399,-352.4261010731527,66.44200649117698 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark45(-419.77416384758703,-377.106451721525,100.0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark45(-419.7784501042536,-340.1392505225479,100.0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark45(-419.89951996745253,-359.73638783357285,52.14634415578149 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark45(-419.9231558082717,-401.85517665200956,66.15585234860612 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark45(-419.98029506963906,-386.8676640625796,43.48130289397662 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark45(-420.2782525506578,-333.60626587925077,83.9779950795882 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark45(-420.5590963685548,-338.78251917680427,11.279449240523775 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark45(-420.9121803913369,-357.0384711433881,59.90460884340541 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark45(-420.9478246445761,-328.7472257007033,13.823651595002588 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark45(-421.08402693260985,-340.60583877870323,25.648396566941642 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark45(-421.2086349555541,-404.01855039827836,20.26090025684543 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark45(-421.2409303235332,-338.4956616217801,73.30479594349501 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark45(-421.3106649586989,-330.6048503377017,77.02076560949479 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark45(-421.37605325652504,-391.62300203203966,73.90744322252269 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark45(-421.6028011456469,-374.24019750888095,100.0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark45(-421.6990167117051,-339.181583245627,54.70860847314668 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark45(-421.75444309231267,-358.0335511774088,13.541047894880535 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark45(-421.76673673266373,-363.01761640265,83.06663466092428 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark45(-422.09993544240524,-377.1392347092386,50.278784849845806 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark45(-422.18832027332195,-333.4347534877229,100.0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark45(-422.6316399109268,-351.4119777635118,54.37493035450413 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark45(-422.7397832599318,-342.4900322717151,100.0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark45(-423.02118214432886,-332.0300634970418,23.835880888368166 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark45(-423.02730385274657,-327.61401681906653,31.375366569548618 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark45(-423.10760373714646,-329.36817071235384,17.7738134333526 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark45(-423.18098210715067,-368.7467982558008,33.59893255778641 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark45(-423.2536316291845,-355.6869660920528,72.62571149234819 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark45(-423.4771268140263,-397.02611282532104,12.459950026000087 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark45(-423.5734019304549,-386.3898637554682,12.465785061516101 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark45(-423.6951790558908,-393.49595785278683,36.04485854149212 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark45(-423.8353834121878,-335.83652674031794,19.52477884011192 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark45(-423.89591529892243,-359.8062255120995,97.49469524181191 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark45(-423.9067848732939,-362.5236797926244,63.08368488569306 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark45(-423.95886029245366,-337.2973563307708,40.127835453555036 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark45(-424.03321259203307,-335.4055658890746,93.24305316660337 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark45(-424.3471064634103,-369.9529153972416,46.06292079548487 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark45(-424.64646172452433,-370.8246557884138,68.46786719045704 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark45(-424.67592927031325,-352.09814465079535,15.155312343237924 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark45(-424.6796305931506,-331.963185878663,89.79492078080068 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark45(-424.70472483850295,-354.7209874701406,100.0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark45(-424.705501747613,-386.84839910301713,100.0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark45(-424.8205588107255,-364.0333091429543,100.0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark45(-424.8583001597656,-386.96217142497125,100.0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark45(-424.95810382408536,-325.74865694319595,97.48426402874637 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark45(-425.1132497171126,-333.53353553458993,36.61158335601081 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark45(-425.20631578569595,-381.4001098696935,0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark45(-425.21007746557603,-370.89179565402594,54.79276861326744 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark45(-425.5418589713631,-379.4234914755068,10.408609764651473 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark45(-425.7727477024792,-321.41482459497416,100.0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark45(-425.7798174085766,-379.86795767152876,98.56480348449713 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark45(-426.0641586996706,-386.21987080114707,11.301105436653927 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark45(-426.07767247945674,-340.9931127311697,100.0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark45(-426.5813289349533,-340.2173469802627,53.53520381309011 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark45(-426.637526866797,-364.9237744296717,83.89936291386397 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark45(-426.63836928160947,-328.44547517336485,57.4734871480872 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark45(-426.701287670874,-320.98359325875197,85.45356881673072 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark45(-426.74825479039004,-390.89143830503883,3.3534001996420386 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark45(-426.78242644279254,-358.1432814018866,100.0 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark45(-426.87111034563185,-395.9884725153564,2.7515992786342167 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark45(-427.2780328745257,-347.91204050664754,100.0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark45(-427.2810774061099,-338.57089339488,50.92877150280847 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark45(-427.499753801276,-342.1914926698489,93.16441266567296 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark45(-427.50677598113293,-389.38964390797037,65.31341890878113 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark45(-427.5632904054012,-383.8653175116003,96.64616721640215 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark45(-427.77579134121333,-363.75029774321905,100.0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark45(-428.0194839164279,-324.8779024228725,100.0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark45(-428.02766677342413,-377.957048545527,73.80698663273472 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark45(-428.1414953859612,-336.62523524218153,92.79559289119607 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark45(-428.2221389876786,-328.4486468552971,73.72415596801923 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark45(-428.30502937193864,-345.27783464925574,70.74061527790053 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark45(-428.3226073802779,-378.7669854452035,16.31712758885098 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark45(-428.33286007805725,-357.921648228683,46.364755792431026 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark45(-428.3529251570292,-353.43399845555376,16.87615259172344 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark45(-428.4324214327289,-321.4067549643844,35.58718194862806 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark45(-428.73409701001475,-318.3477766639302,3.5103470720206644 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark45(-428.7998357695066,-377.2137534489679,64.0867457163846 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark45(-429.0925369028936,-383.79509525393695,100.0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark45(-429.1672955971507,-365.6835927987649,36.47394818536637 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark45(-429.17213120960474,-321.5302071125885,17.623349281191153 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark45(-429.18743873402315,-359.15154496921406,47.08945052147369 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark45(-429.23406002166473,-331.96316582514123,99.90208232226018 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark45(-429.25574600843925,-317.3146372138426,37.63975398406572 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark45(-429.61681590980606,-317.62830556185924,94.67867950945967 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark45(-429.61992252920066,-342.75464714106687,0.6414915786491946 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark45(-429.6270282429282,-332.29431082979,34.87526178266188 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark45(-429.91310086217374,-345.48762188830386,20.869658333513414 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark45(-430.11310117559583,-340.98537706128195,100.0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark45(-430.1734474428074,-377.61597419386874,15.676442652122361 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark45(-430.19081377012844,-459.91422373148663,100.0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark45(-430.30424698988605,-328.1462206179,21.741055987934743 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark45(-430.3331564759424,-381.19349803950274,85.21225560979047 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark45(-430.37125596713105,-336.9615558275592,78.31202875876494 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark45(-430.3884020560257,-363.0226546699822,100.0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark45(-430.40824161530844,-339.8414183565235,29.36123676560353 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark45(-430.4943687825281,-354.161751679151,88.84997326257616 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark45(-430.56823639386096,-338.2185672717379,72.61759044053818 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark45(-430.9193719874778,-322.0180870186238,5.6957073233922415 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark45(-431.0427497072518,-329.3139061461853,5.262300040101934 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark45(-431.07370414231934,-359.6890056959252,9.582565322782855 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark45(-431.0815103962117,-327.27410833992855,48.12779522660301 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark45(-431.4011245096374,-330.7622878943226,71.10622616129066 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark45(-431.4697722236196,-340.2556763128249,100.0 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark45(-431.59441236741213,-375.6966859136606,60.865336945126444 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark45(-431.6925195599618,-322.80390387813026,48.461923241520424 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark45(-431.7971343477049,-395.83298667994825,0.010196912317761193 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark45(-431.8436148796616,-325.9046496563115,75.62132531490386 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark45(-431.9222100795974,-348.7304121761047,81.27044122408108 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark45(-431.9693335421595,-343.30077847545334,4.648521642578743 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark45(-432.0423747899009,-334.4134901651911,100.0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark45(-432.15371733251425,-355.03523832147727,27.61948447472794 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark45(-432.2901932095405,-342.3729122466707,100.0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark45(-432.6373862818946,-359.6352222101643,33.48539111221112 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark45(-432.6442146451481,-329.21910697334965,82.16268893229349 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark45(-432.7843112103882,-324.4220075489691,100.0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark45(-433.1022758081927,-325.7751273885761,24.387648636187294 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark45(-433.2406765453081,-343.1543325501993,2.780881223609356 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark45(-433.27670791859373,-358.55271543269447,88.2976597202254 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark45(-433.3706792797353,-318.59877971753593,62.96329915510691 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark45(-433.5445676593769,-322.8156103786391,9.992711668859727 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark45(-433.59800494467646,-333.1218725385454,8.881784197001252E-16 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark45(-433.677471483416,-350.56952273684044,74.45548099509739 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark45(-433.6831479301155,-349.9371999960007,3.1913608881772575 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark45(-433.81673961055776,-357.739142526303,84.2898863466014 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark45(-433.87998320725717,-317.4456327257356,58.42777039275916 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark45(-434.0678653282814,-318.6131590920086,96.91599901361042 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark45(-434.2017002587515,-374.4805259221012,85.07728703740901 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark45(-434.2368364982695,-381.7111230934799,86.83234052932627 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark45(-434.2918467327438,-335.10177707840677,45.83372302256845 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark45(-434.3792027224936,-318.2691878516467,86.51076199319203 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark45(-434.46319994844293,-345.33580129767,45.64882615623676 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark45(-434.76539821952747,-315.6770006202748,73.7501362080805 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark45(-435.1324650604994,-391.0459860461614,41.80239239669342 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark45(-435.24818867252475,-313.049582739852,82.49993398311412 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark45(-435.3963489479604,-327.80842309848913,0.057894518516079074 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark45(-435.4814895862447,-313.8919476273361,41.88600956830031 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark45(-435.5823544767878,-384.8625345278013,18.647578243193962 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark45(-435.6504968801502,-330.72296569548917,57.13848614045119 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark45(-435.79799396958015,-333.8402013864899,87.73280507844464 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark45(-436.0831899650099,-328.8706730769029,54.46077678277334 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark45(-436.1817838703906,-358.41818915339786,47.41828058109846 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark45(-436.26737841094354,-331.99596328650574,100.0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark45(-436.3708584393362,-350.4567927345398,20.33076885626683 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark45(-436.7023716267267,-357.9677336612343,76.63511550689245 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark45(-436.7968818497071,-357.16960473300793,48.72548076982514 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark45(-437.0703877253614,-321.9592196659098,75.56457297939812 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark45(-437.1860491967738,-341.496556812209,86.83640045375338 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark45(-437.65884585194976,-367.51350476414916,38.80167110169148 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark45(-437.73269901675906,-315.3686979063852,97.71152939503895 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark45(-438.00277131944085,-343.2807682820185,56.15628232136743 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark45(-438.0297131082778,-357.99311946545225,93.46558165562683 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark45(-438.0526021641436,-340.1286906063352,75.9297519900488 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark45(-438.06365837496173,-318.1947023706392,100.0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark45(-438.24190231081485,-315.4146995389366,65.1508971126832 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark45(-438.40431733077935,-374.59386035188766,99.4325460168493 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark45(-438.4113387515888,-315.07066867613605,53.297028159309434 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark45(-438.5698393515672,-344.9811956670497,51.48836828529187 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark45(-438.7705198194791,-315.6703361606198,60.21263418138062 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark45(-438.8775456847635,-378.58637491177495,100.0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark45(-439.3355231546385,-324.7432565638656,78.17374459188099 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark45(-439.3758335503429,-319.4121188696222,30.217407303303816 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark45(-439.58107220033503,-319.1186755976544,50.27211807367456 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark45(-439.6721986933391,-336.40436997016207,99.33827613901244 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark45(-439.74361195797724,-327.6243574145361,12.102279460362396 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark45(-439.8856956689679,-316.1690978637478,70.6854508028245 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark45(-440.1155753167888,-341.1333873049946,100.0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark45(-440.1376524680793,-307.06025465403013,59.58898350330463 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark45(-440.2631150345271,-324.6236312091808,78.70617605469411 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark45(-440.28226843374443,-325.5756385074554,89.06246298086015 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark45(-440.3125864144803,-358.88232328386596,63.391649324164234 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark45(-440.34429416789453,-364.6918209267757,64.3715043449769 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark45(-440.35567661880293,-318.276583174235,2.3865899117480467 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark45(-440.3639058763271,-328.6311009439526,12.226458916117622 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark45(-440.48599363772064,-330.4243159177401,12.3906599901689 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark45(-440.60271809498835,-362.691289230989,9.8251179674497 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark45(-440.61403594627126,-325.3603761298208,26.416998281554697 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark45(-440.68965037329093,-341.3357214766495,53.54974337045127 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark45(-440.77160267462693,-319.3190573151278,7.105427357601002E-15 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark45(-440.81296194262904,-334.3833395011852,24.979448880695188 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark45(-440.8187150808378,-341.13797585301336,28.737692978553724 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark45(-440.9916869811148,-315.0243177695892,30.828680280515744 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark45(-441.15517910014955,-306.26571164879846,63.83410051870837 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark45(-441.44571440002426,-327.7241100647102,88.12499619822162 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark45(-441.50272831806916,-361.27112098154066,22.21363960759379 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark45(-441.5439552717492,-334.9346539489412,100.0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark45(-441.69621368357684,-324.3783987285729,83.1945781767399 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark45(-441.706787816322,-310.7754021963914,33.52799133444165 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark45(-441.73555089128314,-361.8719488456232,9.722864724863328 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark45(-441.7928831230083,-316.8480265601318,75.72040141088004 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark45(-442.07364392438643,-397.6225601821433,74.1966474014306 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark45(-442.22444310635456,-335.0801352161298,50.515555598975226 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark45(-442.26205000255715,-310.41964295549974,64.44021260626761 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark45(-442.28043951954544,-321.19283604445286,11.164877083152163 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark45(-442.29050290674627,-370.0181363117569,40.71784254119672 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark45(-442.41777620224696,-314.9880286691945,66.34920242156721 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark45(-442.42117583194084,-331.58346057186515,90.38913910807366 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark45(-442.4376202702161,-337.1808119170835,30.710144139131785 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark45(-442.5436847795533,-312.8930926421111,45.47495820668783 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark45(-442.57850873155036,-330.67216499337326,100.0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark45(-442.8448276676713,-372.033363102735,44.31856549614318 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark45(-442.8686186678965,-401.5229560349202,96.9690396602279 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark45(-443.0442643327183,-385.004460058428,66.893358410475 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark45(-443.18132241729217,-331.66358322055163,86.57368588552501 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark45(-443.25162331670276,-384.88945976161,71.31248658558002 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark45(-443.43446950117266,-308.536908832427,29.235010075445075 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark45(-443.70175422217267,-335.4750498174468,61.03686719550066 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark45(-444.1642065603904,-305.41824150854575,19.30040931647659 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark45(-444.2570468652582,-375.72303361123187,65.96082841921407 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark45(-444.31958602613076,-308.28216686190297,89.60733510673163 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark45(-444.53226437167905,-313.0502287789674,95.94428746971369 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark45(-444.5572408991867,-376.58110695567393,14.295288509038343 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark45(-444.5971721680209,-305.1955556713917,68.84191332019489 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark45(-444.8028158000445,-308.73666752924044,36.122464322540736 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark45(-444.91735937149895,-331.23876065638706,81.78656263493383 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark45(-445.020575754512,-315.45581162613274,24.066120924410342 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark45(-445.0523141806627,-325.20925010168287,87.38553439683125 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark45(-445.1821458433387,-368.4972604774116,75.76617428732226 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark45(-445.3515000715085,-313.0570463236487,3.1994349477262034 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark45(-445.36294786874925,-317.86710826433955,43.72484403377948 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark45(-445.3656238823437,-308.93557151051226,35.574165415387114 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark45(-445.36583908984625,-312.44298538576084,59.662988857378 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark45(-445.371206458206,-331.66235446530897,89.71485795463022 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark45(-445.4458309302344,-360.4592465333914,38.09651444659889 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark45(-445.6410337283535,-342.0321061492182,98.75304185312092 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark45(-445.7636802684403,-336.13706148209553,28.95733542710005 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark45(-445.99800940586726,-327.76878357871993,19.494203936192747 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark45(-446.07870105726846,-342.61470156902703,33.23934987891997 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark45(-446.17833385827487,-336.26903549996933,16.91181377503581 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark45(-446.2531469739318,-332.57509275226244,100.0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark45(-446.3246366032182,-354.76587016860816,33.60431125532358 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark45(-446.36411792971427,-302.57685594334663,67.09362386429288 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark45(-446.56207451240357,-438.3815811172144,0.4738131155088183 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark45(-447.01226041394125,-305.68210695880293,84.76899213270633 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark45(-447.03763677564746,-309.20834002941996,27.19037703154909 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark45(-447.1303520039103,-327.4149129299437,19.91012974600075 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark45(-447.16502358704355,-348.6756787422429,47.096808113630175 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark45(-447.2689139117526,-318.59662974680526,6.889127020738627 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark45(-447.29695561266357,-307.7563413091465,79.33244945167138 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark45(-447.3862407289355,-393.9164344402908,5.07504070846943 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark45(-447.5147708820059,-303.28621871839005,3.600953941507214 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark45(-447.65263272934897,-356.11438957735595,81.56467736881211 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark45(-447.8993503963051,-303.3581032891075,24.215172132626577 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark45(-447.9784864177065,-335.7428369376647,100.0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark45(-448.4644811420662,-315.5394309768714,100.0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark45(-448.56238513581934,-330.5411940906618,5.3025506946719645 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark45(-448.60665815166726,-322.93287273009025,100.0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark45(-448.8666546115873,-341.9431970234591,5.264446620317358 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark45(-449.01451798857494,-305.7638992139608,92.09218658560451 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark45(-4.490656336226408,-744.9196253424501,89.65190993025337 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark45(-449.09959325926445,-317.3768003488202,87.1773914855246 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark45(-449.393828085747,-322.10737434986976,100.0 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark45(-449.42780035818356,-388.82377580005266,54.97604527714532 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark45(-449.4595330823175,-300.0574735392162,45.83472267463412 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark45(-449.5986165249507,-380.1749094771167,21.03395253389671 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark45(-449.8899127027155,-431.74619558896495,60.47381509528128 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark45(-450.19821480137375,-298.5207452692275,16.434996387947592 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark45(-450.20255606501865,-303.3022293762107,42.79651879882155 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark45(-450.2130141814566,-331.1416959182607,37.621927489722324 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark45(-450.2961572108518,-345.65793431611417,71.03409390917972 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark45(-450.33216714938436,-327.07814107309554,68.45462044176637 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark45(-450.4544656633628,-354.6545917463562,100.0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark45(-450.48699510542934,-309.09738747541553,43.77989051655925 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark45(-450.5468835447285,-323.74682054608473,39.98958783694982 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark45(-450.5476605075607,-347.12766591278614,24.06513676574859 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark45(-450.63113220467477,-332.3041179901277,4.608649993213973 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark45(-450.65809960571886,-321.03581324778327,21.125818002893567 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark45(-450.6838994799234,-322.1822282016092,92.07004330683878 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark45(-450.8423786852594,-324.28233018914926,100.0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark45(-450.8748538843451,-317.04185237892557,100.0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark45(-450.9437754034918,-298.04820710678615,73.58558021769832 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark45(-451.14260037620943,-335.20408501574394,26.15842563752851 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark45(-451.25468138696095,-369.30758924473304,22.63092228767873 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark45(-451.38878171506093,-312.98843429644774,62.13756036293361 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark45(-451.65941867948544,-302.6705450577722,62.91468497293286 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark45(-451.74835768267945,-329.22142853326096,87.00418645282528 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark45(-451.7832772433974,-299.8513724952111,41.59929273171525 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark45(-451.7983811866558,-366.6692739194852,4.369374876933591 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark45(-451.8240689421802,-298.04521674532486,50.32677651702622 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark45(-451.85716530555464,-313.83903813570123,100.0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark45(-452.2172839715025,-325.1066863179348,99.01608499878469 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark45(-452.35129760066894,-339.47241581634904,100.0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark45(-452.46615217158296,-354.27962491189083,37.42381024836749 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark45(-452.4918409362327,-343.0923129424675,68.77124825706747 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark45(-452.64503334267454,-313.07934197036906,33.50817736217991 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark45(-452.88236116410275,-293.501467347463,46.936680023991215 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark45(-452.89326415145337,-349.7547316896591,16.74273069057856 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark45(-453.0249991921755,-392.11057441727377,28.965232193794463 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark45(-453.0611517175111,-315.00941136907136,35.6689689731715 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark45(-453.1088101653857,-297.45535125881116,16.697967581110788 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark45(-453.14074646905095,-301.5730306031279,20.759974274686854 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark45(-453.1599892997449,-309.5662948905407,77.87226411011429 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark45(-453.27262679424996,-309.57218376428773,88.56020279489968 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark45(-453.42797482342206,-299.17889017918304,30.474680023975754 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark45(-453.6391629977925,-322.41606206860496,52.44568564197293 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark45(-453.81977701249735,-326.3899587784133,100.0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark45(-453.9739961224131,-356.3393521877262,100.0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark45(-453.9869460842219,-327.87766184931917,96.92079354323891 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark45(-454.11475512521014,-335.74475540303126,25.38855499014467 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark45(-454.4275188361874,-328.8619896560031,14.865729173213964 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark45(-454.51480194325103,-317.4642348477317,92.9162002304993 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark45(-454.5580481689577,-299.77710229290943,100.0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark45(-454.56824056435204,-299.21827929204267,58.25121939242214 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark45(-454.7642026489609,-364.1530098971883,100.0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark45(-455.161320514273,-329.1375183642211,20.91849233519123 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark45(-455.27462800151574,-313.5293462705379,36.96471380981086 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark45(-455.30380735047726,-328.144063331842,21.554829805897185 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark45(-455.5815737444761,-307.2832014978179,12.990817577901367 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark45(-456.080849394151,-306.3135144661941,1.2336764871681513E-5 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark45(-456.15790032375685,-305.0055799240962,16.43910825062082 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark45(-456.24800712278267,-347.6802736434375,6.20752407896162E-4 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark45(-456.25587534979655,-296.8680724344157,57.97944099570833 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark45(-456.2876179367934,-304.13297241602834,85.72534960906631 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark45(-456.474761031052,-350.6424624611916,31.29632145675717 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark45(-456.8990325253216,-309.1990218648054,9.139278405411517 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark45(-457.12511877910316,-349.49176696049085,100.0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark45(-457.1471701385166,-315.1364810622272,93.17897218924367 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark45(-457.1537201039145,-301.42840590038355,80.26612907374081 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark45(-457.352742877605,-295.4407991144594,100.0 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark45(-457.41469247485105,-292.8409102079918,100.0 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark45(-457.4896547118725,-299.67240614648694,38.039131298190654 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark45(-457.51765990070294,-316.94701320327323,75.29079016246911 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark45(-457.5666851093914,-306.1891534567937,24.359051463972506 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark45(-457.62624878411776,-311.44358503359723,72.15638377704269 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark45(-457.6425830378521,-310.62007158953526,100.0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark45(-457.8814818256893,-303.39917345807345,27.936780402742897 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark45(-458.0043247672486,-310.6616725246858,37.32453749135885 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark45(-458.2012376564459,-311.3791255852301,74.14054265660633 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark45(-458.2954667420995,-324.4145565398934,31.061349869229304 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark45(-458.41547942444197,-294.1060563441244,100.0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark45(-458.6300149444829,-302.97832402458437,80.19650323953476 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark45(-458.8603411841305,-311.32140092499253,23.50983813812665 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark45(-458.93225481862487,-295.18655136138824,32.1294391751414 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark45(-459.0533089810174,-353.05860062504445,76.37146282407258 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark45(-459.1150671813183,-293.2081863318659,100.0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark45(-459.45050030322585,-336.5832644516181,100.0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark45(-459.57277139041344,-330.69435220352665,100.0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark45(-459.6113490992919,-347.5905501076455,14.090609404555934 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark45(-459.62710078178793,-305.83281283089974,31.72906479655876 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark45(-459.72161468096067,-295.76091727827014,0.7508602606531412 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark45(-459.74229804089794,-316.6307170176366,86.40517238511956 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark45(-460.1168618349734,-310.1921292221438,46.916842002524334 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark45(-460.20163945040787,-308.4128192139988,80.39555713326948 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark45(-460.6173873681645,-320.23358026261747,80.75690324793808 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark45(-460.7129253054041,-297.9760407807385,100.0 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark45(-460.76408648427406,-360.9531185312253,100.0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark45(-460.81215929121373,-338.94176432285707,8.44731836735211 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark45(-461.20352503186894,-287.92903597100604,62.66079222832178 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark45(-461.51458767608284,-288.3831276615197,9.253958836702608 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark45(-461.63627066065754,-389.88048754940405,15.877140640012911 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark45(-461.6638016112818,-333.9036696304523,56.2573830488779 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark45(-462.12669982310206,-304.12208628444205,100.0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark45(-462.13726607938037,-333.47835742074585,100.0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark45(-462.369801956045,-328.7619767741172,2.566187994833925 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark45(-462.6572694252781,-305.9471898751909,82.58274904339635 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark45(-462.66405364830183,-313.04585104071816,36.19526559197183 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark45(-463.0415096866438,-285.7860489175697,100.0 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark45(-463.0816787594441,-331.45191801523345,100.0 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark45(-463.255839969641,-283.9886931264887,98.36760414453965 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark45(-463.26837906538145,-284.4512952627134,75.6647326611866 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark45(-463.44936842999437,-326.24940560225576,87.58220865882458 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark45(-463.54742017438105,-291.09061338026174,100.0 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark45(-463.5640287696966,-303.53872075337995,100.0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark45(-463.73094155661806,-299.86074917742536,56.365437900377344 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark45(-463.73296598730906,-319.85288565357797,7.835882942061218 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark45(-463.930421989091,-344.1863751797863,71.45664211596915 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark45(-463.971379312464,-316.17583781589207,14.239392115703339 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark45(-464.01296998600503,-304.3046737534138,100.0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark45(-464.24293057146593,-299.45186352609915,92.48530127280972 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark45(-464.25645729929437,-404.159968526653,41.369827346017786 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark45(-464.3986579726443,-296.9469303759936,80.1532545634731 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark45(-464.50968301149237,-287.54129161487754,20.226119290724483 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark45(-464.656586391883,-336.29022804040574,14.470367247703877 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark45(-464.9093278215396,-314.38555032524397,31.787969659353962 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark45(-465.01145647552306,-283.13623981851066,51.96550852791708 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark45(-465.01152081690816,-302.09208531474945,43.98119380899294 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark45(-465.0198346748755,-291.21905514926965,37.18272942383339 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark45(-465.0960070548313,-338.05310252505717,100.0 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark45(-465.1320780411427,-312.05315384931157,26.753872618018022 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark45(-465.1528454086391,-303.51545486735796,87.93303826526054 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark45(-465.1528979324574,-281.6318302276646,100.0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark45(-465.2511084974825,-299.65904056601926,48.191821442874385 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark45(-465.3046669786154,-281.7794596259113,94.61096255520056 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark45(-465.38073492024535,-320.75075861847563,91.2400081442201 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark45(-465.4679114139893,-358.835225790483,100.0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark45(46.5547794794569,-64.37450893289724,98.37590147479386 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark45(-465.92856435948835,-306.65363020070095,61.01475988625242 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark45(-465.9566255883673,-290.36213453512573,10.179601206614805 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark45(-466.03774939394333,-329.97825081026707,73.03058975229087 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark45(-466.07976171654207,-307.40280059741235,12.490592264267647 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark45(-466.1045855582013,-319.51809165006273,20.855743780692066 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark45(-466.1058035199608,-295.48243540788553,60.46602891385305 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark45(-466.2860142219771,-305.8364851137712,47.88830259595497 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark45(-466.43386839074293,-287.0795320126677,86.4180996344626 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark45(-466.4532714276174,-304.6215611610313,62.686767774085695 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark45(-466.4738623764408,-286.4701876381709,100.0 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark45(-466.5105102500208,-285.68845783747577,68.41207696658148 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark45(-466.533204336608,-340.14334942102374,91.54942697861233 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark45(-466.6280100931863,-285.874091986325,72.46132069536847 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark45(-466.7867642338741,-280.09810261865323,77.30012516900436 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark45(-466.91064794177413,-289.4374567409866,100.0 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark45(-467.0284092364059,-309.2820969202574,51.457252876024796 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark45(-467.0412935327263,-328.1422904484795,81.01158133000692 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark45(-467.12950315665023,-292.5446646623226,100.0 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark45(-467.19171094150977,-352.91682118259604,25.343743477134367 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark45(-467.3584121821744,-300.23349535808273,12.761538416625726 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark45(-467.5660759821491,-324.66269216600244,81.04557436661571 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark45(-467.57265078113653,-343.50974031339064,6.450178861731132 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark45(-467.7364744226249,-281.0787348057948,7.825877060959357 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark45(-467.92864213049137,-340.28642500037614,100.0 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark45(-467.9722465384995,-280.4013656692637,100.0 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark45(-468.3618090101428,-292.58405261267205,83.88062237224497 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark45(-468.6865542369008,-326.0472110904231,24.7061680860714 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark45(-469.1745296066261,-326.5297174946841,84.25931442182565 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark45(-469.30610029323105,-287.53183321188544,69.8482717329855 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark45(-469.7381443443901,-283.41743629123204,75.72841567062403 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark45(-469.77446364894666,-339.2250813118472,10.576022100428546 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark45(-470.0931960427683,-299.6938260150997,57.057627265475304 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark45(-470.21728172533824,-293.96487576584605,66.8968223882722 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark45(-470.3896445716487,-328.8203793929985,6.692205139256039 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark45(-470.54940798098875,-291.0208153960515,33.56113886385684 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark45(-470.68563341382105,-297.4244738477745,67.78620976997084 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark45(-470.88921184304104,-388.76326180837725,87.83334338033967 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark45(-470.9285879653746,-281.58753310729037,-100.0 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark45(-470.9671061621162,-314.45748564022654,46.18198242400558 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark45(-471.0063788388878,-295.8899854869944,98.71896361529576 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark45(-471.2803520309272,-289.40826282822206,34.079773299955946 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark45(-471.45581095420255,-280.19488222738136,64.53370594287381 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark45(-471.49086790428686,-336.74446910137397,70.81952025068642 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark45(-471.8695468254253,-279.05043441230094,21.14435422928038 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark45(-472.00137901573873,-344.3235875393491,24.962695537622622 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark45(-472.0161106163372,-277.7303083783646,77.5053762694026 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark45(-472.2645459306167,-288.89497649211063,75.76678043834585 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark45(-472.2866533775511,-308.35184072433555,48.751252456068755 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark45(-472.4272465965141,-316.6849092337175,30.7424130775467 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark45(-472.58658242539167,-298.42767499854403,19.655270204469772 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark45(-473.17794992691313,-278.2068527388639,100.0 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark45(-473.2842931590912,-290.12475130720014,59.598825590313055 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark45(-473.5145199847472,-288.7276857463857,35.1637632484383 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark45(-473.5680415168513,-362.141422330877,100.0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark45(-473.5808167727519,-302.2443059884389,37.02332447185023 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark45(-473.75760476392765,-275.0539687570517,63.934895613917405 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark45(-473.80745549974245,-319.87359322437453,100.0 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark45(-473.8278760067944,-274.5424895606925,2.7942771607910215 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark45(-473.8346205746884,-278.2768690503787,3.260381117159227 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark45(-474.35959292410564,-272.0741529585109,45.28443149157616 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark45(-474.3674977135158,-352.74931105238124,100.0 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark45(-474.46747917917276,-302.2463722930864,88.23558330274122 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark45(-474.863512787519,-297.14926533063397,46.600149201625555 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark45(-474.92892417165507,-352.04380021040976,10.856693011298466 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark45(-475.13445455173047,-323.2605512485934,53.208109138505534 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark45(-475.167803528001,-286.13013072432125,10.804337877788043 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark45(-475.17444353580174,-274.2921894806755,95.52325096128479 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark45(-47.53712413658124,-750.2203700447484,68.55969913095875 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark45(-475.579708303392,-281.90880777799913,62.58172950202709 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark45(-475.6751063491363,-272.15907094506775,26.91471004287564 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark45(-475.72618543561344,-286.4525504138876,100.0 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark45(-475.7897973238397,-289.81789573122217,3.6563330769605216 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark45(-475.8561481931302,-298.9365555032806,4.854584220318657 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark45(-476.2658630346732,-327.6640875610261,94.58512887751024 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark45(-476.44210132267494,-294.2977415911745,100.0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark45(-476.8368923777375,-308.6253025377848,0.6281912545724708 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark45(-476.86569534515746,-282.05972181905577,56.07590418638344 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark45(-476.9173079383589,-273.76005324108627,30.219774111867196 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark45(-477.003006952008,-401.9392640499174,50.17495509455375 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark45(-477.109837644497,-296.8569045825261,20.15117449082011 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark45(-477.24862110299256,-304.9052842657822,85.07651927351603 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark45(-477.27629735046025,-333.65414287061196,18.94604757347392 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark45(-477.90730650011307,-294.38415365599656,100.0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark45(-478.07081540002963,-293.0273126604223,34.570180279431725 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark45(-478.1108164530173,-285.17519433985547,92.4453021186229 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark45(-478.3545198166073,-318.9852335548199,51.88857765957093 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark45(-478.3649429469784,-269.613735496466,100.0 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark45(-478.3806148242266,-267.78901155332113,58.766043652568584 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark45(-478.69166737378697,-278.64009545659786,72.19102063366142 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark45(-478.8691517498938,-270.38347817085236,92.63038943444218 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark45(-479.3864064499745,-279.92031352711643,0.0030271127061162854 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark45(-479.46116921803593,-312.07998190073647,100.0 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark45(-479.750108998882,-321.9040035678682,100.0 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark45(-479.76671185911323,-343.1709978809329,39.394976000371486 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark45(-479.83977615641294,-379.89790171476415,60.53833170228023 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark45(-479.84450597777334,-319.3141806283561,100.0 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark45(-480.18523763079793,-274.21112853491854,97.00372048781276 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark45(-481.48467337101187,-272.39145657984545,38.91582064397422 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark45(-481.53668141521626,-277.41486221183914,83.20943379901945 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark45(-481.65148651189406,-268.63254775407233,100.0 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark45(-481.811620397076,-312.22008101488865,14.936920689995901 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark45(-481.84312015236287,-318.6036750340435,60.70616382313324 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark45(-481.9722546985992,-266.0709287710989,44.56330458978388 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark45(-482.0290780312882,-266.6507100927773,73.45361790047107 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark45(-482.0302223248574,-267.26288504702507,38.840699282451055 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark45(-482.0867960579348,-267.5063670165473,30.651843810055226 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark45(-482.3885446856304,-294.5590830361743,4.060302195091722 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark45(-482.5957879262403,-365.77883524006273,27.877554285642887 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark45(-482.66284043571306,-289.7615796485622,49.78396292261951 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark45(-482.7619184816771,-319.34664713462075,1.586070062890002 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark45(-482.8002400969537,-286.3908682417264,72.59197947822645 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark45(-483.2325187261024,-323.93410822968247,100.0 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark45(-483.25064479309043,-270.3087909805819,100.0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark45(-483.3258628389754,-369.272546277716,98.930307357436 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark45(-483.34314138530146,-281.8014394354199,1.8258972878984423 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark45(-483.43781213575875,-271.81659600909416,49.154450439503194 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark45(-483.4843232664777,-273.489454241439,100.0 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark45(-483.6117282327373,-270.20187217347416,89.03761859221484 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark45(-483.7711484491641,-295.78744843149195,100.0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark45(-483.87071469978656,-293.7891755336463,92.36186836696675 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark45(-483.97391098558523,-287.4847496640788,100.0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark45(-484.0293156617261,-264.08392306721237,21.49038988941176 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark45(-484.03837945427097,-292.81303374862426,31.508978319266248 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark45(-484.1239000267467,-270.7288655257049,77.85865100408535 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark45(-484.1865256867127,-263.57145082408545,5.550651803285273 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark45(-484.5215506106372,-303.58475022959846,57.110931052694525 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark45(-484.53751268502134,-266.8132490516888,32.68307377255286 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark45(-484.58342068100967,-269.7628480472941,27.781222884578455 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark45(-484.6058481537535,-288.07274823847814,52.736409376815004 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark45(-484.6223676509209,-264.4626257923887,78.74626558422577 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark45(-484.90385052851656,-270.1042276612298,92.16872660496234 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark45(-485.17518047391724,-271.1564021719814,43.87174552778174 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark45(-485.1980514445439,-298.5889964405316,4.9696845827557325 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark45(-485.521021218574,-321.77301988951916,29.060816434415415 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark45(-485.53194226011476,-296.3885252419625,100.0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark45(-485.84465833576894,-311.48945306448906,97.28036662512358 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark45(-486.1446829035119,-286.44571819220687,4.536132552895694 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark45(-486.2781400911338,-285.9248735171366,44.572468065709586 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark45(-486.2838175875843,-277.54669936841157,95.61938625946658 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark45(-486.3623774731006,-278.53011132032634,100.0 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark45(-486.3953823865986,-305.63351882910575,58.97333873405347 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark45(-486.42977629647515,-307.88953869667336,41.65315515461302 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark45(-486.6612336370569,-274.504286998655,100.0 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark45(-486.79924859753527,-274.42053267790675,80.53997277047284 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark45(-486.8552151979253,-268.28554965895097,66.05178904862936 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark45(-486.89128542861306,-268.3477082545594,27.08194416221636 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark45(-487.27092229173724,-270.4219616711717,96.04109385442717 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark45(-487.53242630540836,-264.69170158570336,95.65670526610015 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark45(-487.57848838947217,-279.52852035924616,7.105427357601002E-15 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark45(-48.7889566665354,-711.8844147354515,24.382960752044028 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark45(-487.89469024786615,-306.2282566250434,100.0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark45(-487.9381979408246,-333.6962752185254,17.414258494500217 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark45(-488.14041670078245,-282.2319521694195,82.06498178652154 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark45(-488.2230800259438,-261.55897696200776,25.833980336468997 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark45(-488.27076683499627,-280.7304950681632,84.31604193661394 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark45(-488.62230786856406,-296.83059108184125,55.19140708527502 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark45(-488.74707709195945,-308.68759249488045,59.51059879683939 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark45(-488.87953138428225,-265.44789099336305,6.1109720251861575 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark45(-489.05003320853496,-286.6526820149648,74.53237272258087 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark45(-489.2874925662454,-355.6098151907634,2.2115984291390873 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark45(-489.67104925148465,-330.3624356646892,43.61794500034054 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark45(-489.6946344114172,-290.0691786490895,91.77222054726911 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark45(-489.7457792747914,-281.5290541161827,90.23854818735455 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark45(-489.77376191461605,-262.6673152254182,41.63977469491692 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark45(-489.81893826808965,-296.51282235260464,57.38100872755268 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark45(-490.2595855125646,-258.8076346752574,41.96676107193727 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark45(-490.46104615298464,-258.9342988730921,54.09209809912727 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark45(-490.7617195393872,-278.2443183967721,75.96773934547733 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark45(-491.0972648338934,-324.87548305727967,100.0 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark45(-491.1242536625222,-260.61236458275766,0.6934507120932523 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark45(-491.1596000358885,-294.8541733714269,78.6815461625776 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark45(-491.3117536689635,-277.2969084853605,93.52984023221501 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark45(-491.32903808480165,-290.2349906413495,100.0 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark45(-491.5130952777232,-257.53704399209073,84.05633054846177 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark45(-491.7356483784535,-282.5575364793927,49.58336671544791 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark45(-491.83005370723276,-291.00617569047404,25.237483566666114 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark45(-491.8451980557426,-326.18592504227786,26.84819385001343 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark45(-491.8671831020223,-297.3640391242784,4.125552718866899 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark45(-491.92189310420457,-289.92400604433675,73.86462882394719 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark45(-492.4407208065106,-255.7241462478641,74.13005745311017 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark45(-492.4633400617341,-274.0735852509202,96.45322991272036 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark45(-492.7236022387659,-284.8568643505582,51.93372786019194 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark45(-492.789310299028,-261.08819107602574,100.0 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark45(-492.81975682712874,-257.92758227079696,100.0 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark45(-493.06834291783855,-254.77613696961757,9.497516369026087 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark45(-493.11735480390985,-309.0130906777111,85.73678651863284 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark45(-493.2357607571745,-280.6422534750638,79.88364390625586 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark45(-493.3594583859173,-258.38518300530046,65.89972293445894 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark45(-493.3744363524678,-300.0516536572567,28.903002393412578 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark45(-493.83942816647846,-285.3565548084785,94.4927926804503 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark45(-493.8490547473734,-254.11610329544828,85.03425395988208 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark45(-493.9004700701612,-279.07485387487793,13.284891028668582 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark45(-493.93671565906186,-260.25160469955335,100.0 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark45(-493.9500653205656,-303.81343263908445,61.88283599753183 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark45(-493.95739623836204,-325.18163847543275,100.0 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark45(-494.1387007713335,-288.9973842460886,17.410578103904612 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark45(-494.13956868844934,-260.68989898924593,100.0 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark45(-494.28618601003035,-347.79567112456624,17.886097949185228 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark45(-494.40230650619657,-262.4035889837704,22.910512566717173 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark45(-494.40425389453526,-303.8261115676211,74.93863357728969 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark45(-494.4405231854119,-346.54744470938164,30.425476014744817 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark45(-494.600319717407,-269.3174296955793,97.04231920559133 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark45(-494.8103045766698,-273.81263197316673,53.18114456631744 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark45(-495.0069979656355,-251.04281749723697,54.29904798543296 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark45(-495.16095087986434,-259.9072102677138,12.022670308585376 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark45(-495.5032609113303,-278.3626044024768,25.411930786553143 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark45(-495.64923298701905,-260.5388294263518,36.338250262178406 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark45(-495.95047569464293,-259.87002322286065,9.411909129959803 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark45(-496.1326936773977,-277.27119646356005,58.43676593336596 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark45(-496.1709277772637,-291.57110281901515,89.84235804997618 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark45(-496.2074422433863,-251.6137361018675,45.03653337535732 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark45(-496.363522153881,-290.6871277514218,65.5115169715977 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark45(-496.37370195151897,-253.63816602497758,98.71392847248782 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark45(-496.7102278755533,-261.0975547761303,28.485610678664074 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark45(-497.07687791479464,-252.7793227337252,68.29352561916068 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark45(-497.0943647913188,-251.43021632624013,74.4078527652951 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark45(-497.74612083431566,-329.3932988993147,31.58755621197929 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark45(-497.8043082435253,-259.5920437772956,11.649705278901834 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark45(-498.2737425932476,-317.7027127724475,13.201509403810974 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark45(-498.28495840846625,-268.4532604368239,11.06924987389742 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark45(-498.51366675708437,-277.50255808611973,100.0 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark45(-498.5261123946403,-279.0943249900543,95.78758206187564 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark45(-498.55364637231787,-270.1734857604095,41.43924585643441 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark45(-498.5565012342405,-322.7245225442589,90.94176578090374 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark45(-498.55831882874946,-262.5729858262384,49.95734941035363 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark45(-498.75441169900495,-264.56496784090393,100.0 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark45(-498.8960562914781,-254.79052769660618,65.10306489888461 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark45(-499.1610641128398,-277.42272585347393,10.563634543911633 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark45(-499.1767492209782,-250.11950059933005,47.955634407362936 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark45(-499.3259605257906,-347.52623406147603,99.88316946708414 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark45(-499.4345661364812,-270.20082557790664,75.93258071629745 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark45(-499.58666411808304,-248.74953763858838,100.0 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark45(-499.87974576859585,-316.582566605717,55.598961910712575 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark45(-499.9026329410396,-272.27558454916635,70.03183992501562 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark45(-500.25704374769555,-262.568004723754,34.17971126338156 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark45(-500.5008852583818,-246.06849551755712,54.45683820723991 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark45(-500.6067779206211,-266.3314287292941,75.34200154661383 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark45(-500.64835042200735,-266.7257480677242,1.6165286327680946 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark45(-500.7632025455937,-261.5374070521647,58.60931183597842 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark45(-500.9204341153754,-276.32560205802173,22.960643508364996 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark45(-501.023237790734,-293.0240844791715,29.694205225351254 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark45(-501.0850556639599,-264.7478457959814,73.3975614973923 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark45(-501.46321385681136,-248.5925530224838,10.815120204093049 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark45(-501.539252991543,-249.40302350287374,74.17021687049447 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark45(-501.60248081264405,-269.8800068139961,1.0943834840211586E-5 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark45(-501.71055605520905,-244.52280540525965,43.803902974461295 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark45(-501.80880723616707,-280.57930760812263,5.072137939863069 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark45(-502.19804952396015,-369.35914175896255,51.42009973366507 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark45(-502.2749944767628,-270.04607236679396,83.3119362930785 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark45(-502.358082504556,-250.3849078254913,77.48371568215907 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark45(-502.56031055427326,-279.8091614664442,37.15331435273856 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark45(-502.58897691926245,-248.42078958685414,43.87142247171076 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark45(-502.8183610994867,-286.6141626131804,42.3094838033997 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark45(-502.9945447550128,-263.5298168621907,93.67120344044756 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark45(-503.0323083962033,-279.8560777247963,72.67814391306752 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark45(-503.28972286540363,-274.2553723347109,31.6857829189735 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark45(-503.4762182500604,-255.44046006075217,66.58584792151942 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark45(-503.55017149398526,-294.0848138260983,100.0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark45(-503.5824867096965,-285.6750027684099,71.1844061665451 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark45(-504.17327250456367,-267.8756617222828,55.12554959345894 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark45(-504.3719236453871,-315.00861271563514,100.0 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark45(-504.41322010192187,-295.8228408969421,90.95444645793594 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark45(-504.54498427567694,-250.50766975567961,50.065805381943335 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark45(-504.79593076041107,-257.7364993870769,78.19453413473065 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark45(-504.8073447231668,-261.1519380278723,26.357482990331093 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark45(-504.97673620100306,-245.51642348333013,0.3025360041473988 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark45(-505.04705760685204,-242.73775576379106,52.95108358054793 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark45(-505.1234982640431,-255.55974625253043,69.82740809962672 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark45(-505.2686034261367,-265.8843026122508,54.4896555761936 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark45(-505.32831545029063,-254.02826643057824,88.13369891536112 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark45(-505.5607835828704,-261.1922156138497,64.79457183633147 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark45(-505.66382809290957,-316.2144480478482,50.95661625484772 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark45(-505.6698650946371,-254.4062888449409,82.11617626651037 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark45(-505.845902322307,-243.5454942734907,60.1552410257826 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark45(-505.85788719248734,-253.16486391338452,80.60641542031189 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark45(-505.9312948326803,-256.71490620974146,9.170947418162513 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark45(-505.9862521903658,-284.81466842134023,29.18951999695622 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark45(-506.2529134243356,-255.18520005659073,13.885942230862042 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark45(-506.35173518373574,-249.88379377955636,79.52663301972643 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark45(-506.48691788756855,-256.0597129845795,55.722823183385316 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark45(-506.5666510364043,-258.74434746382417,17.641780702067372 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark45(-506.58933871386733,-240.95254487858602,61.085717640948445 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark45(-506.6130838083762,-252.6548155530453,57.09930961202241 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark45(-506.62399117763806,-244.09730586787092,73.62603694541832 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark45(-506.67888119710386,-257.9268092897368,10.016312657475348 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark45(-506.88653745192613,-261.1689004160508,39.665958003401414 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark45(-507.01949776794237,-248.34165315987187,32.711917724893965 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark45(-507.102418868293,-305.9935109860541,51.00082213675273 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark45(-507.17063391959016,-261.6617047141497,68.71407500231007 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark45(-507.2831812575115,-263.2126057025805,83.61630658432969 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark45(-507.4105028659751,-272.03131554915046,5.319139045005599 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark45(-507.65063837406706,-241.41308700666374,80.87572514986971 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark45(-507.6880905179603,-266.4365477782625,25.29603348821952 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark45(-507.81384097428787,-257.81317958061106,97.25014068504916 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark45(-508.1199918381233,-271.64375927553294,99.42823797924862 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark45(-508.1354806369473,-270.93166353204134,26.219076996267617 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark45(-508.16999867993496,-266.6043894384327,13.693490971589782 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark45(-508.36833365962985,-261.8390299762019,100.0 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark45(-508.4545835413132,-304.02856607297645,13.716042427124535 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark45(-508.4792924526964,-309.43523464200916,8.233527078323633 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark45(-508.6208854599558,-266.2446157526798,44.57065226123137 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark45(-509.17398273840035,-239.68146808217782,25.71844733696078 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark45(-509.19742963092057,-299.8195272563056,39.67899772349074 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark45(-509.39656251003976,-243.34278380127157,91.39346386557642 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark45(-509.40713122499585,-277.68835750129665,52.67171520845142 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark45(-509.86258113552356,-242.77130315136048,34.10711100882028 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark45(-510.16243685887514,-245.54315226201982,5.875428819164654 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark45(-510.3761127936033,-242.21743033665996,70.07792213306158 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark45(-510.5097209290099,-239.55356018375215,21.88854294828934 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark45(-510.88827714937094,-285.48404751770715,99.08848143420833 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark45(-510.9747504932842,-246.6915585185625,98.02110351790333 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark45(-510.9923810332225,-286.6680013695214,100.0 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark45(-511.1582405463728,-254.7625121668749,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark45(-511.39147958329994,-246.6147471621569,41.67956543178664 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark45(-511.5090972158424,-290.86863727517533,100.0 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark45(-511.90677308301366,-240.45215971856658,86.77838472050246 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark45(-511.9518394125631,-295.8086631075859,40.10047080728799 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark45(-512.0906683245881,-259.23168887641873,88.63466347706216 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark45(-512.1570574769107,-250.65160462940264,72.33543712892606 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark45(-512.3794505720687,-245.3774797904356,31.285413152860116 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark45(-512.4394396906819,-256.9924111043064,100.0 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark45(-512.7257292129756,-246.91504581320712,100.0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark45(-512.8768662210855,-235.27556704501953,1.078339809890963 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark45(-512.9285582532391,-244.7879709399778,93.03415465603985 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark45(-513.0876178796315,-292.83696653076134,44.78572655614269 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark45(-513.2541492024947,-265.47633186220037,48.872682758045784 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark45(-513.3367557817367,-298.51965555376853,92.27699117162166 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark45(-513.3753273238686,-238.89640890471094,18.575287586972294 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark45(-513.5205865295819,-270.9647652109654,100.0 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark45(-513.6164970805679,-258.712552636255,44.42203083138506 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark45(-514.0190052008929,-249.5156520795296,55.195572398121925 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark45(-514.13441129852,-259.1707124439854,30.611135162854794 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark45(-514.1543834609886,-265.7786855206881,83.08694010673096 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark45(-514.3394405362797,-276.3160975892357,82.02651043400363 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark45(-514.6570583799124,-278.12870167537545,50.702466882814775 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark45(-514.7478554848435,-288.13331288794063,0.3490615857099044 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark45(-514.8480916088803,-235.0552517967791,26.869094326854295 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark45(-514.8737761520513,-255.43920806806736,97.63997781187555 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark45(-515.4480202154786,-330.6652324931296,46.77344634761516 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark45(-515.5153423047041,-264.0799965094858,17.477244702662958 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark45(-515.6446211240832,-291.1891914516059,32.46765841928527 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark45(-515.6804936048453,-238.90107508633844,67.53525464231606 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark45(-515.7053970025318,-267.4518442408749,79.2528602918621 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark45(-516.0655814905832,-238.45518602767407,100.0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark45(-516.471136546276,-239.9540626132772,16.49719678831339 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark45(-516.5427107249379,-230.91295860060717,54.28695115170632 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark45(-516.8100955919934,-284.6658608287254,100.0 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark45(-516.9769065066804,-276.4099921232225,85.09215898594664 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark45(-517.0973608344424,-261.14582996039996,2.322385998550459 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark45(-517.2071886011462,-236.22006070204324,92.01841889539975 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark45(-517.2661434692957,-287.9670831359597,100.0 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark45(-517.4167513705202,-231.41898924099206,40.487495763462164 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark45(-517.4421352998879,-243.89477055775293,23.636385918734447 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark45(-517.7543349361069,-243.86581558504466,77.9810471583312 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark45(-517.9383004543586,-236.90294577681368,59.210830992809264 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark45(-517.9676086770215,-230.18923799988497,96.5224291755072 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark45(-518.0632225539268,-249.04669252844434,81.65560940635254 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark45(-518.1430927809319,-260.8256906465985,40.83225128599665 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark45(-518.5883102232173,-229.94974310171978,89.33836547561168 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark45(-518.619987553146,-228.7072308408807,27.076955483113835 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark45(-518.6265158921017,-252.12984513827888,73.59874374520828 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark45(-519.043575339811,-246.52421795027868,94.8281825916311 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark45(-519.3062222550327,-247.50956374023184,79.02899123957425 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark45(-519.4008461449373,-279.8330287026568,96.90085924608536 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark45(-519.5179824012108,-228.168058852421,11.40834479499162 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark45(-519.5539840132426,-245.03622502992084,98.75861389065616 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark45(-519.6699832788363,-245.70021319714036,98.3033278462743 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark45(-519.8191862724614,-262.7384337253857,93.3252198683563 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark45(-519.8587927461515,-231.61895339238097,43.44853938104043 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark45(-520.0443975523151,-248.20918224546924,100.0 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark45(-520.0546069636019,-291.06165401742726,22.275033893137348 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark45(-520.1115888492722,-238.18386681346527,100.0 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark45(-520.2117858276675,-299.9678820738273,5.401022947839039 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark45(-520.2477521816334,-236.56722442394437,98.58072109071486 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark45(-520.2989574993837,-271.112458324206,86.4189647677095 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark45(-520.339967105832,-251.12243579224676,10.263900077496444 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark45(-520.6782579223975,-245.93293973839403,100.0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark45(-520.8141572613849,-313.5370524589753,15.019548090620276 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark45(-521.0697597293448,-274.50203933574335,34.70192963283819 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark45(-521.4070623429498,-276.99903115401037,100.0 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark45(-521.4232402364006,-256.9690357226076,58.10495739228966 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark45(-521.5852967161338,-257.1373022427048,91.27765561891016 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark45(-521.6849816239196,-304.93951573926864,57.726122644587974 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark45(-521.8384421296903,-258.9355692929433,95.72985434436761 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark45(-521.9458921543916,-256.4682229415002,71.0997823665742 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark45(-522.0575654296327,-233.17612495398532,74.29629961606418 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark45(-522.4164270520954,-327.1969599659072,100.0 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark45(-522.6123279010482,-290.2581559512725,11.449010747097915 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark45(-522.6776761209887,-235.59163090670452,57.53367479191894 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark45(-522.8899041161742,-267.26946716297607,3.9212151634676786 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark45(-522.959314782485,-224.13805516932314,86.56639833141872 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark45(-522.9694567977169,-235.5836054079303,100.0 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark45(-523.0114865547994,-260.63286829219675,50.980616122733835 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark45(-523.0969219519886,-282.53562113770477,100.0 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark45(-523.1193199950557,-230.7564581239427,100.0 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark45(-523.6030607548473,-300.51845308879723,54.736917739439065 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark45(-523.6910451478616,-238.6463544622505,83.47707109097172 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark45(-523.752511547682,-227.39646639246274,66.14565601682136 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark45(-523.9132904855968,-232.5280274887178,62.44762622088672 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark45(-524.0884767339127,-270.64221682369794,6.57410781327259 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark45(-524.218660557158,-288.40144622136694,81.61937872429041 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark45(-524.3017282254774,-229.60535111720012,17.561433143515146 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark45(-524.347188337118,-247.95531294742295,31.31827561820549 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark45(-524.4944574631228,-237.736123239928,95.4080703964801 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark45(-524.8952503745736,-221.82952574607197,14.205576319532696 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark45(-524.9434568128094,-228.23565379545983,100.0 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark45(-525.0468445075902,-226.0923193856591,79.17696151542958 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark45(-525.0554198231426,-235.83883136178724,53.86227975596927 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark45(-525.1014720706803,-278.04498096129237,80.4611784667095 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark45(-525.5257534137692,-266.0037826160762,93.62726838382193 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark45(-525.7601463871061,-259.2608562655922,25.89209695411418 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark45(-525.9003055926443,-241.39561177615383,100.0 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark45(-526.0610242093921,-245.97953586869812,100.0 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark45(-526.2100096387873,-274.8493037860448,82.22818404277444 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark45(-526.2514190707116,-240.24503468265237,50.8894705051963 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark45(-526.2776725350193,-241.4505071651297,31.033672110891047 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark45(-526.5992003101948,-294.87915009131456,9.467994963971947 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark45(-526.6443587802942,-234.02070752394187,58.55237405870005 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark45(-526.8201288502369,-225.4997980833339,2.9791474367895745 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark45(-526.8304787079778,-226.5248774876087,57.80150566253835 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark45(-526.9152600335951,-289.6772438958383,66.9599867598321 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark45(-527.1625165505058,-327.9390037287683,10.07853296949419 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark45(-527.3297158087116,-272.3246790998744,24.49294587508959 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark45(-527.5523757339196,-302.50784125800834,7.903755451446344 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark45(-527.7109311916572,-238.05034393443907,56.378590607531805 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark45(-527.8363330667395,-238.67767529341336,35.134168103850484 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark45(-528.4003403899064,-263.301799547844,100.0 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark45(-528.6061815680441,-266.24391000202814,77.40768088833147 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark45(-528.7373533003033,-218.23754039817968,58.11859283557402 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark45(-529.1575267566152,-221.85694902176985,34.34796514748419 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark45(-529.2120538731798,-235.64159641351478,34.683242539459485 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark45(-529.3167310741226,-251.18203904636846,30.618160241121046 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark45(-529.4839842151441,-250.8483949632066,100.0 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark45(-529.5966454774688,-234.81922466790905,19.953171161848317 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark45(-529.9914686888677,-261.49511474184976,12.439364602169121 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark45(-530.0934248812811,-317.3385003172149,73.41371568621292 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark45(-530.1028150982947,-274.93584482028393,39.32855075999524 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark45(-530.3422521856297,-222.0849443202372,18.918709487314175 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark45(-530.3958509717569,-270.03822492464167,100.0 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark45(-530.5744955615049,-260.1387816237682,61.48735001311732 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark45(-530.5877521630863,-284.9284323587242,100.0 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark45(-530.588841178616,-228.40400808646407,68.34458510020391 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark45(-530.9843301526953,-257.67892578762604,100.0 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark45(-530.9902796329002,-236.46109937385597,88.13734913626146 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark45(-531.3294973704046,-219.10659858794688,70.39925411741399 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark45(-531.6993574184681,-277.9205861192983,100.0 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark45(-532.2391793517111,-230.36052880411742,17.870335455109753 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark45(-532.4074355979596,-230.82634260698183,74.60667425820753 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark45(-532.5157461704716,-216.89154744951654,2.080524992103534 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark45(-532.6179672446021,-220.901423092196,82.1843925308605 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark45(-532.8886021378021,-298.7227375824086,100.0 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark45(-533.0353721987499,-227.18458909397998,76.85004931645398 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark45(-533.4347209960968,-225.18652315679682,74.75315253794153 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark45(-533.6068538053667,-221.34397185874505,95.30907981402582 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark45(-533.8027872085643,-256.3072894067781,34.15646384849768 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark45(-533.8044854522028,-219.79257841689014,26.552297754032935 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark45(-533.9520334483295,-259.91481278399823,26.778820305067615 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark45(-533.9683858897286,-215.71611453917822,63.20268392816445 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark45(-534.3096242558443,-266.46503125349926,100.0 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark45(-534.6137375867286,-224.04456051953886,55.837165856818885 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark45(-534.748745070798,-235.71072530419883,100.0 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark45(-535.386278843222,-275.3444369713624,7.84578216562646 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark45(-535.7192400317676,-228.71411581236364,59.88313581132388 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark45(-536.1364525816031,-215.49762815196738,73.5372235306371 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark45(-536.4498455191174,-264.2634481186928,3.1680272345037395 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark45(-536.5343770779831,-211.92331636598638,11.825297570318142 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark45(-536.5580896464309,-243.88601181112045,12.76033742669049 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark45(-536.7541779813631,-230.4514952241448,80.4411798552409 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark45(-536.7841461336786,-263.0073358542904,50.602130100491536 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark45(-536.9858846512443,-314.8176941723122,1.5597863889713466 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark45(-537.0673721642781,-215.46868827191892,0.547191953938821 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark45(-537.1620697155017,-216.30506814727713,100.0 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark45(-537.239089127176,-214.42693154787722,47.767987317826396 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark45(-537.2896357254117,-211.8093907006594,100.0 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark45(-537.3188947505803,-266.6466604574048,26.04489817023567 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark45(-537.3297322285238,-219.5484126680609,63.628539942325574 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark45(-537.6981532451275,-292.3326441173173,75.96073463457884 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark45(-537.916155502285,-222.86376797668763,42.000730921379045 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark45(-538.0038168629167,-215.3785012403725,41.55299236601434 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark45(-538.1402016470576,-230.08398263699777,44.96793266052214 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark45(-538.2579821958973,-263.32303099215414,11.795570030980969 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark45(-538.2763436385254,-218.0203888142366,89.08638064405233 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark45(-539.0687406713588,-236.56095601892508,38.680036795715665 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark45(-539.2779446833327,-238.19002031722388,86.06708084068742 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark45(-539.4733252057994,-242.61416793643176,46.58378554798969 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark45(-539.5010956748578,-221.46780032968232,28.61843951962115 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark45(-539.5529549604511,-222.26739438830924,77.7950236648673 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark45(-539.6908906511092,-245.18459277928318,27.004729470170915 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark45(-540.035310701738,-219.1128149159623,40.78682497676314 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark45(-540.2301765614766,-258.6275312113384,21.647957373720956 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark45(-540.5845341915567,-219.18385885973117,64.07446097751534 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark45(-540.6108826962796,-226.11468120147953,6.446947560745016 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark45(-540.6728301497617,-216.04302251774212,100.0 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark45(-540.6772055994669,-235.579635701376,39.84085406647253 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark45(-540.9915487569492,-212.4446386076358,64.73205179491265 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark45(-541.1230251065332,-207.7747916570263,33.27381270598542 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark45(-541.2989561518498,-214.98926909330618,82.58715171339537 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark45(-541.3071267835398,-256.73888805570334,90.73370312058441 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark45(-541.5373486815637,-258.9387907406265,78.82766711445524 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark45(-541.7048994381561,-279.25276930563797,91.0951905872769 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark45(-541.9681162143822,-250.85111119094313,10.388926095090596 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark45(-542.1766108682007,-289.27512884278025,50.847925710317924 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark45(-542.6736192975312,-260.35791478781414,58.101577972308434 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark45(-542.6820281277868,-213.8581731872465,100.0 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark45(-543.1698511424215,-216.76285506610213,68.44934260900445 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark45(-543.1983660313678,-210.20320364494586,69.33984494050506 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark45(-543.3701099088049,-229.35850208488526,14.231107735725715 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark45(-543.3791494126506,-232.28454934245983,34.836958754839515 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark45(-543.5475827579556,-254.32680178658518,75.14421091774238 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark45(-543.5489195825697,-221.31268644677175,0.07347727172988527 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark45(-543.7147166854023,-280.0811623986876,92.63671647942618 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark45(-543.748628698755,-213.52653946027303,60.80203298204577 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark45(-543.7539180041288,-204.5212021344115,100.0 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark45(-543.8099814394667,-260.8607274631941,31.393110819723915 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark45(-543.8927238153472,-264.04293775756787,98.96912665163404 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark45(-544.1039634823973,-242.68655125637395,100.0 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark45(-544.1305357169848,-244.48061529505276,100.0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark45(-544.2923432165502,-245.15684353475027,13.807319518808939 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark45(-544.2989003199589,-243.4571333726308,39.107794448739725 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark45(-544.6236589219942,-210.2264718331417,73.68177814752966 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark45(-544.7629840534938,-234.5353734650021,11.687178334296846 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark45(-544.991761170841,-215.34985939177892,50.33139878311917 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark45(-545.0062989772091,-231.9945079800761,0.21142683794668926 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark45(-545.1904515230536,-254.83293423936917,100.0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark45(-545.2571903434816,-230.10616169049243,93.93722812430312 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark45(-545.5245065380869,-221.93743874565178,100.0 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark45(-545.7491619242284,-267.1307621561665,52.75095096017864 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark45(-545.8789392091164,-268.23409995519654,1.2941216121784151 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark45(-546.4722581984391,-212.20390963675226,40.0644114694565 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark45(-546.682336196204,-244.37677547712582,52.76051041175555 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark45(-546.8011405782356,-225.30956044160274,100.0 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark45(-546.8157675707827,-269.8500637649233,51.114941835289784 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark45(-547.5181132839214,-204.00908528242786,25.995197100290127 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark45(-547.6194992538955,-225.73367620926012,95.39291358977488 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark45(-547.9236061972304,-241.942455787714,67.35128149068933 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark45(-548.0187250419444,-234.89113416080497,10.12318224053052 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark45(-548.1956360968561,-254.0391747678748,29.29818601010173 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark45(-54.820335751877614,-708.6518887248404,21.665369410922253 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark45(-548.5270220717998,-220.4621572651301,100.0 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark45(-548.5561182975226,-243.253280122713,100.0 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark45(-549.5527852967174,-233.21143765697337,100.0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark45(-549.6037832285788,-215.18459069666739,76.31777769217231 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark45(-549.7885526395737,-205.77022599899595,93.87111516773189 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark45(-550.1869904799635,-215.15133275054757,100.0 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark45(-550.1918718103794,-230.01814573318848,74.6987053758022 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark45(-550.2383445811138,-269.043343757524,9.13444022302194 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark45(-550.4486129308111,-196.1039248596448,19.954287266215843 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark45(-550.5398229993522,-238.08614544400058,47.29370942281858 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark45(-550.7256335597938,-228.46024437772303,100.0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark45(-551.2304923738699,-211.42301928316957,68.87981970138623 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark45(-551.2407882350307,-290.0899313096693,65.14122028730657 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark45(-551.4958301674939,-202.06819040585205,0.13307577112398405 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark45(-551.5405648489733,-246.65972702070457,94.7057144078724 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark45(-552.0668478959681,-214.7886053389625,91.34675430088478 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark45(-552.172804530927,-242.43131565617415,49.463871922965225 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark45(-552.290220634216,-197.7739264710965,97.18799589136765 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark45(-552.4378214840864,-227.63345905885788,100.0 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark45(-552.6604213250689,-257.81780690662447,96.41970654606655 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark45(-552.6809392886663,-198.5720279175211,39.91236841839219 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark45(-552.8236036189854,-210.39058509513197,100.0 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark45(-552.986205436141,-211.32834598375698,52.088025906522006 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark45(-553.154247418391,-293.4926429321227,100.0 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark45(-553.3404841799287,-225.7413972599371,38.65692789083093 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark45(-553.4645820131162,-208.10580596799088,98.89105301392829 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark45(-553.4847303293711,-194.99561951458216,100.0 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark45(-553.7606512576333,-271.81501280221306,100.0 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark45(-553.7686945104533,-256.9240517312145,12.644809329540626 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark45(-554.0650621728848,-196.4176007923433,100.0 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark45(-554.2618287370071,-213.94527556633471,82.24649045888788 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark45(-554.2795521643416,-263.62226096093593,41.56764177802984 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark45(-554.3158003348398,-227.49020516774635,99.30989795411259 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark45(-554.3705803798773,-231.59500759108602,74.22206473136305 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark45(-554.862831353454,-207.25834217141298,70.6511651243581 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark45(-555.0705235247702,-196.35971645500553,13.193405127371179 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark45(-555.3302526115049,-204.19170870962787,71.93664953062674 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark45(-555.5063583991415,-191.19306056386029,39.909457653585974 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark45(-555.5510465882882,-194.39257617734313,46.076215836990364 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark45(-555.7002225139851,-222.59347489497452,52.26264465551117 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark45(-556.0055369452614,-200.1623015196976,30.828163632425913 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark45(-556.8262289835152,-192.41975663017226,2.6576250685727416 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark45(-556.8483414717531,-280.1947179428221,41.77070775485876 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark45(-557.0004653303597,-238.30145507699285,48.500284878385855 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark45(-557.1373746407891,-204.80048491499562,77.87831056864746 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark45(-557.515358696351,-226.87066942242447,88.29797807427974 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark45(-557.581425932434,-195.76416095544266,100.0 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark45(-557.7474437784193,-299.6965437353324,73.88995642763754 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark45(-557.7976323671185,-211.2101903151576,11.481332805898717 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark45(-558.001095815263,-199.28340643771998,21.701954283515803 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark45(-558.0233285189606,-190.40699255312208,100.0 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark45(-558.7249088451827,-187.58135274746368,58.254179749036865 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark45(-558.844857917445,-251.95139055814386,100.0 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark45(-558.9975697965332,-191.03248854475098,7.712269993723737 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark45(-559.3143741815722,-197.04074791728775,100.0 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark45(-559.3765232875805,-241.26142564046359,12.894162377597155 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark45(-559.4008963140197,-223.59100196006383,19.39308872432457 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark45(-559.4096013296509,-263.2291438371351,19.885514275079814 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark45(-559.4141388834821,-251.72807780954443,18.57625080519108 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark45(-559.5905972781214,-194.69070808938446,79.26068565303274 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark45(-559.9856900031157,-192.77876381379147,100.0 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark45(-560.0141785327959,-238.85051725416542,47.307455930392706 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark45(-560.1802101950433,-194.7029150717843,34.37437473130379 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark45(-560.6426706831758,-194.08719287636586,100.0 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark45(-560.6710980833277,-196.23148390138851,100.0 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark45(-560.9180824871984,-223.6312359093209,13.477693139787789 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark45(-561.8462159282168,-214.37271514016004,86.62156579921052 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark45(-561.9518284623534,-218.10305844777417,7.222316932716041 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark45(-562.0784945099132,-184.88262909046918,71.05383791787054 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark45(-562.237247546631,-187.17183183317115,73.46397385773852 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark45(-56.26377374771039,-740.9833966185556,68.05668146961446 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark45(-562.7819902289294,-186.90643508564003,43.8632299820226 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark45(-563.0723836529006,-194.31603747836755,60.49201326693239 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark45(-563.1252853320946,-215.53578975101647,62.801407364106524 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark45(-563.1923869086521,-201.6641348851856,47.08684243321983 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark45(-563.1949406584816,-247.77201198073564,34.19863479199057 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark45(-563.3881565953758,-223.58155316163175,23.402418552160114 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark45(-563.713170839734,-198.23087090805015,100.0 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark45(-563.8358817104405,-198.41616026560544,100.0 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark45(-563.847731498502,-237.0970942827148,0.8005212518140894 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark45(-564.1067578036786,-242.67997018850642,81.99541401190766 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark45(-564.1796636285319,-188.79350377982223,23.15442920920369 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark45(-564.798373632552,-182.17502702668997,88.88813516001241 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark45(-565.0208392963523,-235.10896679561557,100.0 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark45(-565.0520921800107,-196.97027361224139,7.579474441793252 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark45(-565.2749087032818,-200.48963254089668,100.0 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark45(-565.4746308533926,-194.77915711356334,45.241004612052464 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark45(-565.4803589616358,-183.4518896099882,0 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark45(-565.7107224313593,-235.0763718274344,100.0 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark45(-565.9625544612867,-209.17810809993517,74.41413489002548 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark45(-565.9752665581105,-192.8764926897308,100.0 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark45(-566.0621844781574,-192.51508346770646,46.653785740301004 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark45(-566.2115615999786,-185.2796744851061,66.9280057698559 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark45(-566.2223362455853,-185.43947192031385,100.0 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark45(-566.365967415147,-198.6869585253709,100.0 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark45(-566.6466322566148,-180.80205899933247,70.6751030448371 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark45(-566.6483753976723,-198.87898311925363,65.30580271434047 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark45(-566.9807839898178,-183.16889094686366,3.552793646091061 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark45(-567.6521586463754,-206.59846467996996,16.075799673000233 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark45(-567.7124566123923,-199.6133246311496,100.0 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark45(-567.7244701001729,-190.4336722867941,78.88873779646104 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark45(-567.7563949922142,-202.0175892461575,67.1945253854011 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark45(-567.8085208376136,-180.082698466079,100.0 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark45(-567.90150759211,-182.11546954978388,8.338572971271844 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark45(-568.0514388672641,-189.22289402817125,83.41569110989454 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark45(-568.103360246017,-303.1760219699713,53.18999064068731 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark45(-568.3741679911469,-182.41231111497387,83.66960056240777 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark45(-568.658739609352,-178.16644231422495,72.0063783849179 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark45(-568.6698714484247,-180.54958015488,100.0 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark45(-568.8700810549824,-234.7036030506118,100.0 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark45(-568.892827135071,-182.42578624809843,36.45458235527903 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark45(-568.9704938438674,-204.21296734798085,14.678982193953672 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark45(-568.985224596984,-205.53144178305337,17.19462587211416 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark45(-569.0199274500809,-241.40005280257907,94.52218585158906 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark45(-569.2051595810944,-197.7450918662899,2.306617260855276 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark45(-569.2402175815911,-184.4662547948841,80.37800410422676 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark45(-569.2419501041737,-312.88623582944524,87.91140285276737 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark45(-56.935743383401835,-715.2104100226704,79.25681058942263 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark45(-569.4963130940592,-235.69453128065163,100.0 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark45(-569.516455865422,-239.028595936442,59.49963151833546 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark45(-569.5284475558586,-213.7456500052262,50.4584238878042 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark45(-570.1174281102715,-195.02545845147586,72.48190765183628 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark45(-570.2775613397655,-221.93267394044275,0.4603558077284333 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark45(-570.830230262756,-182.52367096515857,9.74548950851242 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark45(-570.9148276595744,-178.00325459049552,80.82836152677046 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark45(-571.4946590191383,-219.3076441303393,33.5991642102328 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark45(-571.9720568783782,-205.23702020345746,23.617650150336516 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark45(-571.9898127225193,-247.6311393532252,53.52539288437637 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark45(-572.0292592395391,-177.60228763635578,90.126887449901 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark45(-572.13915343867,-181.12043726917102,46.64434231238536 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark45(-572.1401170147363,-223.28610756183832,18.42477030005783 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark45(-572.1810501975477,-205.3908670197943,100.0 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark45(-572.2486433462457,-184.81175512573233,54.432941215952894 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark45(-57.23415877222766,-702.1190014351371,92.98804137904563 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark45(-572.5369085020147,-210.79429795184254,60.37875902958325 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark45(-572.5862049258037,-227.56902446793265,79.9857691819376 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark45(-573.71971490857,-186.615182805892,56.930065980890596 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark45(-573.8543439852227,-191.078011626755,100.0 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark45(-573.9529077757289,-184.35734717182822,61.65789583309055 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark45(-573.9698726618718,-182.19516629744533,45.91500454851433 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark45(-574.223686613905,-183.467444969763,40.61654294321153 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark45(-574.3362074180505,-218.5499794500874,64.81234244466995 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark45(-574.7343162239558,-178.6851453963824,34.72244008582555 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark45(-574.9796640449393,-295.2483925319914,27.028017239553236 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark45(-575.0966092634114,-179.14513228869305,57.69283957432009 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark45(-575.50499993699,-268.2493850249327,21.368111534771288 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark45(-575.6151782208331,-227.837934964321,14.798976764783419 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark45(-575.7649461914067,-172.00248567237045,49.731202535160094 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark45(-575.7773961940067,-262.206844078261,57.3382035945632 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark45(-575.9324577664679,-170.4676961694095,23.3338692028683 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark45(-575.9343788406077,-171.1363195826459,67.24380337438313 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark45(-576.2244902385768,-202.0215993664437,51.467500612117675 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark45(-576.9172456117113,-214.02647050518794,47.88504842075606 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark45(-576.9616441063313,-178.14678095443557,11.997056164535522 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark45(-577.1410546203946,-189.7074309672856,24.248488821545923 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark45(-57.71683640281084,-699.2891897966689,75.22054265975746 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark45(-577.2234306485982,-182.99485916528843,100.0 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark45(-577.4913948371664,-197.03716867920346,100.0 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark45(-577.8524620364158,-170.17355128649245,24.574210090088002 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark45(-578.3596103162324,-184.11470868391177,94.54528858116655 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark45(-578.4686058256092,-232.33576750327566,73.67717947599752 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark45(-578.5550908033955,-172.6105463964372,90.1362689204476 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark45(-578.7683792814138,-171.46833111623002,47.489923042656926 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark45(-579.1923524084285,-348.86290436741166,63.64369861967921 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark45(-579.3116583365543,-193.4116673599157,100.0 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark45(-579.6643691135004,-195.7458386498949,100.0 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark45(-579.9396583666389,-169.69293670589929,88.84317886532182 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark45(-579.9794911514487,-256.1840215884804,99.87534376514674 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark45(-580.075995751085,-197.99417487805442,54.54446574851943 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark45(-580.8139124067301,-192.59650838061785,81.97073524701432 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark45(-580.8739980789295,-247.28050567435182,3.552713678800501E-15 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark45(-582.1303567494664,-168.57758299969313,10.584711934087764 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark45(-582.8256197897483,-181.8576170786924,7.105427357601002E-15 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark45(-582.8853380497027,-167.80410829515603,75.91215387632082 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark45(-583.2360212551123,-165.8951219892884,11.069734893547235 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark45(-583.5733596298543,-168.25318802072738,83.83084305215434 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark45(-584.2069353707416,-178.94614704860277,38.58022967572248 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark45(-584.578051983914,-180.93698528250928,77.77373030034818 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark45(-584.9033850883385,-167.42962875463994,8.792498157513677 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark45(-585.1166179559191,-240.45722710972694,22.475964385222767 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark45(-585.2958668600563,-238.95959356882403,7.27849031566376 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark45(-585.5654723356092,-167.0643768618747,27.849852374405643 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark45(-585.6028259284401,-202.05050594495384,36.231999210500504 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark45(-585.9216008038829,-170.04790581665898,100.0 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark45(-586.088855847383,-196.59980870229836,51.76146379154585 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark45(-586.208153238617,-179.99260149130163,91.79257237936159 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark45(-586.5291920205191,-179.64827544326147,39.60907968500479 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark45(-586.663774939591,-163.31675299921858,100.0 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark45(-586.7751437416301,-199.97956999297466,100.0 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark45(-586.9469422313289,-171.25238851602947,55.35320982411821 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark45(-586.9887822880714,-184.79933383871128,77.5261019525899 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark45(-587.0774298150338,-166.17243801061343,19.93126341281885 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark45(-588.1900410942616,-240.4265815768016,12.870665871314685 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark45(-588.2878176346202,-182.03406358059596,30.371861295471547 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark45(-588.3165126635466,-179.88832537641233,100.0 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark45(-589.4386246945433,-191.37336145104285,0 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark45(-589.6454467950263,-330.2664739992479,52.88542097763201 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark45(-589.7384964565833,-173.2333357681176,21.882963990329955 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark45(-589.838010294169,-160.72890953240096,100.0 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark45(-590.0365586651618,-173.71009322830454,65.82548558170964 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark45(-590.0974409974749,-204.3953156497902,97.05448371062971 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark45(-590.2475192388774,-182.27168470216847,8.602407131077555 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark45(-590.4007260362672,-183.26284864596826,58.20739578178612 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark45(-590.7547970354542,-231.14281871780926,61.647552399286326 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark45(-590.810439524813,-161.2342793177456,75.71423754112018 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark45(-590.934753853963,-158.65276521820766,64.87973681997781 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark45(-591.0048864758016,-165.00326681458847,51.35727627106982 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark45(-591.1617073654053,-173.11196781296664,36.6742548929854 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark45(-591.4078906727668,-235.45410094099032,93.77592106160978 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark45(-591.8595117582437,-164.0665645443123,100.0 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark45(-591.9217574672139,-169.9799007465135,50.08523849483191 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark45(-592.1944774105418,-156.0470082895272,18.551631488229418 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark45(-592.5963562048954,-164.36488205120705,3.8837412122287134 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark45(-592.6518864253152,-155.50967964387607,2.131887844395706 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark45(-592.7349687116634,-190.4930989853646,100.0 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark45(-593.2417500169787,-194.20788750716275,96.87760642418053 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark45(-593.6873467835159,-209.12464527037403,59.66690639619509 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark45(-593.7343810061478,-170.99975921666413,70.81070391754909 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark45(-593.9774192069316,-280.3398744818227,71.24706782623954 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark45(-593.9930810542177,-180.13980351175005,32.08221515551503 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark45(-594.184626251496,-178.74582109062652,83.14347803027621 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark45(-594.2136819503818,-195.59720131173603,37.797313875414574 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark45(-594.4709878492038,-228.14272138504458,33.23046581672838 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark45(-595.1873081612596,-152.47215797620902,73.9648158140374 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark45(-595.5864473729121,-196.98528653604188,5.89307120328651 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark45(-595.8282713540692,-244.99453997034806,13.769412468961818 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark45(-595.9346926163712,-182.24578301645332,74.28719801758353 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark45(-596.3351617764531,-169.5004797604091,50.556340861764625 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark45(-596.7014337112181,-166.0685453952703,6.226062369237752 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark45(-596.7098089223081,-188.92701108266175,41.237411098231576 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark45(-597.8728854154657,-232.52452433220677,23.149788365222705 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark45(-598.3165518827119,-170.3284343922577,38.36885092422065 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark45(-598.6222256351524,-173.8261932744002,27.521804021577935 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark45(-598.9471705744355,-180.35031281519377,50.63396475148306 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark45(-599.2220520997212,-202.46772590468245,66.43967767099369 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark45(-599.3810656978897,-150.38525260257612,100.0 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark45(-599.4057475868007,-169.46278523198248,71.53736433766079 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark45(-599.6644329911468,-175.1617634811823,33.676870928442895 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark45(-600.4945448900421,-208.34280331222635,100.0 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark45(-600.8855989490517,-169.39354709993205,100.0 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark45(-600.9992641427705,-217.2361632260322,88.95550104586766 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark45(-601.0696649577644,-204.16839176871264,55.72691714469548 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark45(-601.0970836507406,-208.67212143453432,39.65154461038372 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark45(-601.2371994515329,-152.4393396808468,14.321734325848297 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark45(-602.3630692651276,-176.78384184256666,3.2851376295843124 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark45(-602.4173468724565,-191.37917100804484,70.3509653635337 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark45(-602.4266641863566,-165.85904843405976,17.21785868567416 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark45(-602.7304725563192,-160.91927753309918,63.68762716244859 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark45(-602.9290786949467,-176.72948197156785,55.51945190497281 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark45(-602.996866027386,-203.90143340571024,97.702929161258 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark45(-603.4904831747936,-178.97550457056659,46.15828695300422 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark45(-603.5390936977923,-150.92746944729936,89.34887613723029 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark45(-603.7945573534862,-159.78840721320097,79.39638614801092 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark45(-603.8478257558921,-179.04216340677587,-2.004350058231156E-6 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark45(-604.1330878331354,-202.02035620137303,69.66256306270597 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark45(-604.3297383923904,-155.63018446078502,100.0 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark45(-605.7241370788994,-145.1107403589529,11.841362759394485 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark45(-605.816183761278,-142.36899639312824,74.59637127131475 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark45(-605.9279250502917,-153.66302519319657,18.89174750045386 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark45(-607.0820140645998,-145.75523941183357,95.48293225781819 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark45(-60.718969770107165,-720.5322938338707,59.110367780465936 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark45(-607.2011418365853,-142.3567949517775,79.25025045822358 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark45(-607.4559002380291,-167.41227003403986,50.59644164414527 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark45(-608.2763309412644,-171.56819024554613,100.0 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark45(-608.5950380385302,-179.41876611559897,8.831193823123911 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark45(-609.137348495453,-158.21029484017706,23.575810968881356 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark45(-609.8019473027267,-143.78432560661187,31.03658559797418 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark45(-609.939214700441,-137.3113603458329,35.451651588769636 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark45(-610.0500539308988,-142.4310174118443,27.492832408531086 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark45(-610.8593642232481,-179.141787069877,49.42273294196957 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark45(-610.927359440666,-136.37162445524098,69.15607967342365 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark45(-610.9504782840086,-204.0311695753983,84.57564245071777 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark45(-611.2929167695106,-151.13224244156393,78.04683662873947 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark45(-611.4714140245112,-218.75527420375195,55.80821664806902 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark45(-611.8801798113402,-142.6742978637733,98.83257065017557 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark45(-612.3645117741764,-145.86455528762534,60.03084134174776 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark45(-613.013042782907,-168.77964087374875,47.490984337162445 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark45(-613.1598879788447,-151.51158112445103,100.0 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark45(-613.9681483119158,-138.43903618237317,26.17515114258238 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark45(-614.2470093467107,-136.26375208674375,68.3553059412175 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark45(-614.7340479093708,-151.6321723878374,75.82509860950489 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark45(61.49204517865675,-65.53837151737719,0 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark45(-615.5272467046311,-178.39473185379805,21.365733743013976 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark45(-615.7074705993009,-163.86245491946534,40.29737760637772 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark45(-615.7717259575868,-150.31188213273717,45.73066586376984 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark45(-616.4160376693276,-185.34681850740265,56.41960583877896 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark45(-616.6809376635231,-192.08555462079414,100.0 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark45(-61.71419316110354,-728.3400000868224,80.43002630556973 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark45(-617.8333625081067,-196.0403295448068,49.81398838078576 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark45(-618.2691075934558,-153.19710271921286,25.63862557112178 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark45(-619.5384569230298,-134.04483473062817,22.515374468815423 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark45(-620.9670353473234,-162.91091136653034,100.0 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark45(-621.1442355246478,-177.4356587503674,11.932783903689995 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark45(-621.1480261983538,-224.43707896904291,39.64773791500416 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark45(-621.8484998363849,-130.88729538121822,42.990911273509454 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark45(-622.1507901916525,-159.9885105732284,64.74675232540778 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark45(-622.1671095113426,-170.13338763731647,35.00790997371752 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark45(-622.4137225490597,-131.21258350608895,51.951885883901696 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark45(-623.0513208087883,-138.50762988421104,100.0 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark45(-623.4106452346315,-146.27828838337786,54.62551686286622 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark45(-623.618664815201,-211.95281075038926,60.131483975606784 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark45(-623.756009356078,-138.57123316611685,12.598527761019369 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark45(-624.1082915759423,-190.09509664577803,15.089330973739052 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark45(-624.9261514512434,-162.57247226096848,3.203132896008327 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark45(-625.1077012009953,-158.5387502673652,85.47298260818522 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark45(-625.2613087348245,-133.6401470832477,3.969883827593094 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark45(-625.549894837274,-121.88833655122824,100.0 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark45(-625.9634867965345,-120.86877218559086,3.1253413220468573 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark45(-626.4912872962522,-120.20010791958602,4.4053793890506086 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark45(-628.3235381129115,-127.28108957716266,27.716301722791187 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark45(-628.4196869767516,-124.39495698773186,64.81944785013752 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark45(-628.6772143036691,-154.43992681229696,100.0 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark45(-629.5822351920749,-118.92972075259357,52.224541513723494 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark45(-629.872722730494,-193.85214225238616,69.62324065614442 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark45(-629.9725740499217,-178.01571272664438,76.19190595707636 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark45(-630.2255300636008,-149.097720022575,100.0 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark45(-630.3007912019042,-184.85399462963693,61.325114413282705 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark45(-630.7654563122667,-161.17385325504634,99.1809235356767 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark45(-631.5471721136414,-168.41062036522095,100.0 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark45(-631.8332516430344,-161.2788683626802,20.601783857836423 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark45(-632.1783248219081,-137.6525919416416,90.45188779058432 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark45(-632.754171684772,-243.01399667627908,70.97403239729499 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark45(-632.9741046519267,-171.03458477395714,1.4210854715202004E-14 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark45(-633.3570372678017,-167.33215148761332,31.728026714129243 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark45(-634.4353729629381,-148.1221239151578,27.8065570219715 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark45(-634.5777689342077,-168.5744154661191,65.36013727201865 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark45(-634.90929843321,-190.26104338271844,33.05382487998486 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark45(-635.1139566813545,-166.8649296025431,100.0 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark45(-636.3863815536074,-126.0458804980122,70.89151767467735 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark45(-636.969580835883,-141.43424849311256,90.56968739034718 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark45(-637.1369615424755,-182.54944609949195,46.145183136527464 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark45(-637.475900545011,-123.56724186750884,10.772828920564905 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark45(-638.722425835138,-180.172909765168,32.08109942577198 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark45(-638.7672079366948,-125.60992105944278,54.212140012193686 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark45(-639.111189155106,-173.82008939663413,100.0 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark45(-639.314895124873,-140.66083603599077,84.32202449454675 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark45(-639.7976725066569,-187.4468136477998,38.0160761064231 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark45(-640.3445851752524,-184.91988541152222,100.0 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark45(-640.8619457549182,-114.01932014517274,43.21144947810754 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark45(-641.7508338500814,-118.58885600598036,60.940444786508664 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark45(-641.8529719465962,-104.57670571757087,71.33076262750029 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark45(-642.0580931705782,-181.47337005391194,93.35493163736541 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark45(-643.9093955874874,-118.7260859977338,100.0 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark45(-644.146694092563,-181.5009170413465,100.0 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark45(-645.0038535131628,-147.89252553719743,90.01473807080706 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark45(-645.1399060832629,-146.17822507776708,61.079968897571426 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark45(-645.1595460302466,-105.23077871423456,79.87161783065218 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark45(-645.2563993168122,-141.06070195301066,58.2849397253685 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark45(-645.5208223325936,-162.58025113846918,78.77836265971499 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark45(-645.9662200824597,-141.98561241423604,5.8929460104561855 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark45(-646.1834806004532,-173.84510043990306,77.57466459538111 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark45(-646.8351555129686,-123.22210437988542,98.87880527082484 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark45(-646.8691123497989,-146.44315506739628,83.82704620577101 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark45(-647.2426497888232,-119.13508298289058,41.56690397905339 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark45(-647.6139311529422,-171.49163112036138,91.67651966937939 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark45(-648.0442187516867,-125.92988185527355,100.0 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark45(-648.0654380907404,-130.40629580953782,94.25377330353376 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark45(-648.095397389918,-100.0,72.43954018852574 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark45(-649.2662869942983,-150.99878245550977,49.51344946624269 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark45(-649.2974448844556,-163.7882049229135,17.568834326813317 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark45(-649.3269944635916,-100.0,97.41930593146085 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark45(-649.3501351599804,-147.18736893441894,56.34492209466916 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark45(-649.4565714597937,-146.04280787172212,75.65595363089622 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark45(-64.99809436150224,-704.0119908410182,50.580476089008215 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark45(-650.0500976422705,-100.0,58.96237609267092 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark45(-650.1782438818041,-130.86337554742042,10.917465042174996 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark45(-651.1072185708325,-96.88953914365908,15.274344144914537 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark45(-651.304040101204,-131.5201723874605,59.510085967785216 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark45(-651.4225677847023,-100.0,100.0 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark45(65.29705592809393,-67.66511820472796,0 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark45(-652.9819684597483,-100.0,6.143827894209792 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark45(-653.2227916441942,-106.96282494077752,62.777937970099885 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark45(-653.9277263155769,-100.0,100.0 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark45(-654.1259092369495,-183.73477976364748,37.05319607856558 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark45(-654.1789560942249,-158.56654057778348,20.590213173772256 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark45(-654.3151303490343,-100.0,100.0 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark45(-654.4569295361597,-91.8082166920467,14.833146282928539 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark45(-654.5847178555558,-93.69202440147679,100.0 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark45(-655.4297872649832,-149.198394417536,24.817949691861756 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark45(-656.1250025326516,-105.53743649981602,86.19580551767388 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark45(-656.2412905893351,-100.0,100.0 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark45(-656.3122597409841,-130.68569148026313,98.44824592706726 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark45(-656.9639974988418,-146.9259643699661,100.0 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark45(-657.1806669611782,-100.0,100.0 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark45(-657.445844741812,-99.0897015487703,95.64671119496256 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark45(-657.5744890592498,-124.99420536601235,77.59885854171543 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark45(-658.1771203868815,-100.0,40.244688940556955 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark45(-659.1991626978948,-113.83245251165205,69.48166289174799 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark45(-660.1355039502581,-238.16562324241795,71.1648815684652 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark45(-661.1079241907889,-100.0,100.0 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark45(-661.4186358686072,-144.53345167361036,97.06965882301844 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark45(-661.5238331168479,-100.0,100.0 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark45(-661.666209292528,-100.0,100.0 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark45(-661.9740412960122,-107.78889297234971,100.0 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark45(-662.2140493996953,-100.0,9.490428080970986 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark45(-662.4862753034744,-102.2003104667106,33.860638259912434 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark45(-663.0035055410629,-111.64729580836277,0.6949814376518759 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark45(-663.5910113478451,-100.0,100.0 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark45(-664.7702590989223,-100.0,68.32036524094391 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark45(-664.928340087923,-100.0,100.0 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark45(-664.9796052951181,-100.0,77.59808628169324 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark45(-665.5540921707317,-82.51478252034543,64.36065602710408 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark45(-665.738928771606,-159.82530243940087,100.0 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark45(-666.2217546055842,-100.0,100.0 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark45(-667.0310143194764,-91.94745960955862,30.01961756560135 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark45(-667.6838474971707,-100.0,100.0 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark45(-667.915296298779,-157.17909218663323,75.02271461621913 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark45(-66.8022024228811,-692.511128843487,0 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark45(-668.5588686560933,-176.3237559111983,49.51845362303783 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark45(-668.6952140609502,-100.0,35.00136361488073 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark45(-668.8164491899777,-100.0,100.0 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark45(-669.3013666438527,-100.0,38.633307951848565 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark45(-669.6490846876594,-100.0,100.0 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark45(-669.7671680381193,-100.0,100.0 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark45(-670.4673793151028,-100.0,91.66199307187892 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark45(-672.5206212854553,-145.64203945060547,70.13720771990796 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark45(-672.7599127911756,-113.7273528727423,83.62903553478799 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark45(-673.3289869351618,-100.0,59.788909977560735 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark45(-673.5354604098065,-84.15200238166645,38.181994031768966 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark45(-677.7112798407371,-134.10403027316397,99.17393923789896 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark45(-677.8110317862862,-78.67807199978017,6.644320860995762 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark45(-678.2129225572253,-100.0,100.0 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark45(-679.7431391522704,-100.0,100.0 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark45(-679.7608590324096,-92.25004082990603,95.40903387581156 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark45(-686.4223509154317,-77.00303052538266,10.612956067513608 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark45(-68.97848578624156,-716.6929985957253,78.15705467193703 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark45(-691.5432717237284,-68.74654836603928,66.144334455912 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark45(-696.2600984654125,-132.82609776026345,61.638138043823574 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark45(-697.3052898212225,-99.8724959806624,67.0547348434572 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark45(-704.5003310171854,-99.99721239696416,89.1401289748996 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark45(-706.2316757558359,-72.92626318818547,0 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark45(-707.3000463405991,-86.08782109187445,78.42293136099886 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark45(-708.2626822529744,-76.05347954589587,28.299742368575693 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark45(-711.7439465947062,-87.9788873615589,74.29782792681806 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark45(-717.0577596444477,-32.74201779665418,14.722812554431258 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark45(-71.84912015431706,-721.1292587305285,98.39960620028353 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark45(-724.2846829455742,-55.84235679987726,78.70684699966546 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark45(-725.5657609119831,-51.47119140406213,90.61056665004114 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark45(-726.0844997421557,-96.11371855754962,69.84880910001553 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark45(-737.4472341493869,-66.07690795369896,78.16388523194547 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark45(-738.4443873110794,-100.0,100.0 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark45(-745.0487039686944,-54.23610405269156,69.7434577399321 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark45(-762.3135145229911,-57.36670236065908,6.3912344174964915 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark45(-77.40698165574078,-673.4734440330752,74.52617794665278 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark45(-77.49808180165294,-690.3778177431693,1.7581026964248423 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark45(-77.50253453955867,-714.3780405613747,90.05020479547977 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark45(-77.81660479610532,-681.0513933389635,41.8101909871157 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark45(-78.76977261746666,-685.6428821248742,88.02787980950683 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark45(-78.774241589764,-734.2901271249486,16.821265032904705 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark45(-79.69478033009585,-669.9843240361541,0 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark45(-80.91711710321314,-681.6304142738644,93.49433309338008 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark45(-81.26145034016896,-702.524982479454,36.27986931401759 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark45(-83.10135248380215,-681.7743538512981,14.357819374300789 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark45(-83.33093307894528,-726.7771933287328,5.6029535134324435 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark45(-83.75915377670823,-685.7864989723694,35.70286554517949 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark45(-87.11116370781632,-678.2593459401202,100.0 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark45(87.5168583592953,-22.32896341087094,0 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark45(-87.58894393741218,-660.7107478513888,67.29717676875947 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark45(-87.85154431048804,-671.0853871526054,100.0 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark45(-89.24353406723135,-727.8324350141637,57.98779639777314 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark45(-91.28535836735298,-662.5653393801823,28.592233367038432 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark45(-91.6442830674182,-720.4588146176754,49.45757473094133 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark45(-91.67421682383194,-657.9935417245425,67.85120849932687 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark45(-92.3111138932905,-657.8770059020861,4.664425991224903 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark45(-92.53779043376065,-691.6645816442946,78.63822749730159 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark45(-93.03643432609387,-662.4010789175495,85.28452758005938 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark45(-94.25453568242924,-653.7168781186336,49.05381318934755 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark45(-94.78164648760875,-665.2656133911711,18.81489861843228 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark45(-96.3047102115139,-652.4288828720989,38.36231777574858 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark45(-96.63145455962577,-679.212730530967,87.50102835483904 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark45(-96.78023864324426,-652.5813820645823,72.87092526004093 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark45(-97.46130597340183,-689.1135589873013,86.22226754899566 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark45(-98.99960333788005,-657.004144294028,100.0 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark45(-99.69005773956535,-654.5794929967797,7.404677166877121 ) ;
  }

  @Test
  public void test3402() {
//    sym_v1null;
  }

  @Test
  public void test3403() {
//    sym_v2_( doubleToRawLongBits (x_4_SYMREAL) & CONST_0);
  }

  @Test
  public void test3404() {
//    sym_v2( doubleToRawLongBits (x_4_SYMREAL) & CONST_0);
  }

  @Test
  public void test3405() {
//    sym_v2_( doubleToRawLongBits (z_6_SYMREAL) & CONST_0);
  }

  @Test
  public void test3406() {
//    sym_v2( doubleToRawLongBits (z_6_SYMREAL) & CONST_0);
  }
}
