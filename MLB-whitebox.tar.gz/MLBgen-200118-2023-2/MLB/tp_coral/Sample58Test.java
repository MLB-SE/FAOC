import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.005863385978338798,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.010124032440360472,16.337801015125848,100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.01310812371512654,-0.031391795414199876,50.038435395904656 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.021053340572361523,1.1583327617590982,-76.60207732378647 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.031741065116098754,-2.220446049250313E-16,0.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.0339334133458125,-100.0,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.045470617984343355,95.47669996343294,-69.61478656678167 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.048012640779747325,22.976717762995705,-8.927424626983019 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.04941279098075141,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.05002156894899376,45.57432596792928,-6.938878768429561 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.05796157396218897,1.3079697924744949E-5,-45.06562903762885 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.06310999564340758,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.2710570650254747,-1117.9709259230108,1296.9040810623221 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.5170652958785795,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.746768414614476,-1250.508235988438,1148.8616324086759 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-100.0,-0.008592425799313519,4.440892098500626E-16,-66.90599289431628 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-100.0,-0.009205873857224947,0.1387827288462809,-10.34800329073511 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-100.0,-0.036772016515706774,0.09757228748645778,-7.740474465209362 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-1.001284831205228E-4,-13.384164424397069,0.07001464562909858 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-6.42027676088916E-23,0.05628802805710652,-22.342630807840848 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-11.033976608799,-1.1102230246251565E-16,0.1651754698110686,-3.475864069138323 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark58(0,0,1.1102230246251565E-16,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.1401929046223456E-16,2.8853058180580424E-129,-2.7159623227969744E-127 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark58(0,0.1348347790809832,-0.008813334645299015,4.358508398157601E-4,-100.0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.7763568394002505E-15,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-21.37494740042472,-0.01951023952874717,-45.00939219084102,0.03457331213969832 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-2.220446049250313E-16,2.8368418725222E-12,8.673617379884035E-19 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-2313.474228814125,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark58(0,0,23.46694145176555,-10.87962614964178,51.321831535638694 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-2648.061643993866,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-26.743095076408004,-2.7755575615628914E-17,0.20520052083830168,-7.557582575236681 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-29.073308081309918,12.654681695823754,-26.849749884775548 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark58(-0.029497418802264974,86.27997545036447,-0.0427597474260675,-42.06263229469353,0.03734422315250732 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark58(0,0,34.986052214921244,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-41.328453775314514,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-4.1761948595190557E-53,-2.1155902934254805E-10,0.020280361326292365,-48.58063338815198 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark58(0.0,50.759617176653514,-0.035778056804391445,7.153653779679947E-6,-13.620054233223094 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-5.551115123125783E-17,-29.984691963284895,18.561485389376458 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-5.551115123125783E-17,4.440892098500626E-16,-30.40699823081354 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-58.228105188854585,-0.2868825616680447,-20.061721481349764,0.07829818234966406 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-6.348693179605405,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-6.410915721203317,-0.014202719798012476,0.1341057458360839,-6.852363630161982 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-7.240551914564591,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-82.94284239185978,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-8.881784197001252E-16,40.81489729025681,-51.325206074487156 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-95.34749547611827,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-9.860761315262648E-32,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-0.013500463371886581,0.0024059235671070878,-50.51536202106011 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-0.013643741501806299,-7.884283817508084,6.372607462551876 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-0.025789379176772043,-3.9396536883528714,0.3987143162960651 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark58(0,100.0,-0.033890893543969236,0.07374462166388619,-23.56489319679244 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark58(0,100.0,-0.03771921670631222,-3.5366152579637773,0.42867927081829704 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-0.05737461885866535,0.6000992838780441,-2.1708956106729405 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-1.1020434332974306E-16,10.81103773979252,-12.381834066587416 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-1.1102230246251565E-16,5.4187310193351905,-5.4187310193351905 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark58(0,-10.037718592257546,-1.1102230246251565E-16,-6.6319162140705,0.23108937392618267 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark58(0,-103.29768301118463,-0.013361686668802886,0.08845536742319529,-6.871598858170833 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark58(0,10.492653164781629,-0.01090549046088288,0.06018094829067522,-26.101222586388175 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark58(0,-12.1590300371703,-0.018385411114120898,-28.872098393058337,0.054405339903258465 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark58(0,-13.521448879497216,-1.1102230246251565E-16,-25.934153667741946,0.025867117702154552 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark58(0,182.94999006157104,-0.012790067373009858,-1603.6152338995012,4.320609401398945E-4 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark58(0,21.84058297345743,-0.9999999999999999,1.6179459246320376,-3.188742251426934 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark58(0,-22.415334018881662,-0.024723262955422962,2.502545072516007,-4.073341399310905 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark58(0,22.508238979244283,-0.01010803708998367,0.9837137758961649,-1.596802205360902 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark58(0,22.994277805672592,-1.1102230246251565E-16,0.02915555990848737,-53.87594302894229 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark58(0,-24.0328812811365,-0.5235855556163288,-7.215031164613529,5.743700588254804 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark58(0,27.288084069792205,-1.7763568394002505E-15,0.778477181559541,-1.256716578677536 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark58(0,31.828487075671802,-72.95848883704548,12.5189494447486,-85.97162428222198 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark58(0,33.42534944902221,-96.06143662284776,-76.75745834662277,-14.63451131764397 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark58(0,33.867772312694754,-0.057560336907196016,0.017810211484845517,-88.19638824226269 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark58(0,-36.235845260245526,-0.01720757424085418,-1.5700494753221108,5.551115123125783E-17 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark58(0,39.315809968873666,-8.632383661593368E-16,9.79227774337133,-11.363074070166226 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark58(0,-4.077620005140173,-1.1102230246251565E-16,3.2448804024006266E-14,-24.583548219218788 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark58(0,40.95233409900719,-0.010102742740767402,-16.616788999237198,0.05246375354322059 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark58(0,46.015235158057486,-0.016760392340191665,-62.05332042776844,1.734723475976807E-18 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark58(0,-49.98348938406147,-5.551115123125783E-17,-3.581269739907089E-15,39.72720900434848 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark58(0,-55.3218507581866,-0.06181763945348756,-2.0152144666969036,0.7794685641422339 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark58(0,66.32614403865564,-0.014827350028762232,-51.07781119439614,0.030753007814227403 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark58(0,73.06934111165918,-0.05949361885691005,12.98087265300554,-12.980875726358311 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark58(0,-74.52313065807094,-1.1102230246251565E-16,0.256067218190976,-6.134312458627132 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark58(0,76.93003651163161,-0.1909337841826005,2.7755575615628914E-17,-2064.799029392938 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark58(0,77.52790293950189,-0.011855603634425227,0.2808325207813738,-1.851628847576272 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark58(0,-78.23205396494264,-0.042963770834658035,-5.754937164779004,-3.6702578749869366 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark58(0,-80.06729097826722,-0.0030074600857808442,8.782019112631012,-10.282019112631012 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark58(0,80.26917017416922,-0.038400839173137094,2.7755575615628914E-17,-4.641592653589793 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark58(0,82.42300427272814,-0.008725064908009283,0.02042413839834556,-63.415942519279966 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark58(0,8.438950265947593,-0.006483914011864461,1.7763568394002505E-15,-1.4218851974987672 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark58(0,-95.21000056272271,-0.03186687786129213,-7.219997767626119,7.219969765099683 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark58(0,9.55900374706697,-0.004526232078043313,30.871637409270807,-0.004969974953820661 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark58(0,99.67582327687846,-0.03010138192898934,0.007192924395068544,-16.54408852561008 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,100.0,-5.551115123125783E-17,-13.967184263090454,0.009838736974743356 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark58(100.0,99.2273704982975,-1.1102230246251565E-16,-10.345154138746624,0.13837582300184348 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,99.78555631208079,-0.006843465213530809,-7.493478314880376,9.828360160633043E-4 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark58(-1.3877787807814457E-17,15.398968276825793,-1.1102230246251565E-16,-6.8266369683862305,0.07734975038572243 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark58(-1.5230032262286954,13.136569419358992,-30.73264007347403,12.365450618726314,-11.651837410580953 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark58(-15.737243345298353,24.0012835483949,-0.13192035150035358,1.3877787807814457E-17,-20.045713572571685 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark58(-172.28828507195942,-60.19709617528151,-0.010809224989229371,0.005185234272246653,-12.661526483867961 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark58(1.7447081457236993E-5,-42.545095129805375,-2.071735805592966E-4,0.9953358731477816,-4.796360651142664 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark58(-1.951180276193137,-0.8820469817678172,-3.130201840029751E-29,-4.121134352673768,0.2999920141562468 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark58(-20.180122634855824,-17.363608660644033,-0.043802383169502426,-34.928865430200574,6.938893903907228E-18 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark58(-2.1774178090381042E-15,100.0,-0.03440850093043646,0.002311997322530873,-16.03810340883005 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark58(-2.3170476086200793,-0.8167514994854059,-0.02868877653464213,-4.016306375363086,0.14172896315554206 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark58(-25.115781036138205,-85.26660760843042,-0.010177626638289916,-15.755772165160565,4.843660296773891E-47 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark58(-26.57045153949871,-28.244675032048463,-5.551115123125783E-17,-28.360162772451787,0.008307163002510064 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark58(2.66090424067652E-7,-4.0816789570038557E-7,-0.06076475504570128,0.20062845129079715,-7.829379715034034 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark58(-29.224323521681896,-100.0,-0.0377918693443669,-63.59130975738432,0.024701430632390664 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark58(-2.9351259118331573E-66,-2.945670777545203,-0.01509871117792909,0.11552955748408422,-13.596488734160445 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark58(-2.94699497150948,-100.0,-0.05172392660578651,0.073398481770931,-14.063131645030342 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark58(-3.552713678800501E-15,-100.0,-1.1102230246251565E-16,0.017862575713154083,-7.024259704578061 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark58(-39.295820807669834,-100.0,-0.0047058014409816495,0.36968879876549465,-4.248969219625456 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark58(-40.08728241494549,49.42365577092524,-0.025248730628730804,-6.635069175077871,0.0044516789935303 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark58(4.503121617200634,-96.21646944010953,21.258985463960386,38.73367706190908,-97.21154772690943 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark58(50.48167375694376,29.001299511148687,-1.701401125691741E-5,0.3761353987254571,-4.176145962644233 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark58(-51.091124673420616,84.15911482120174,-6.13852651037541E-4,-35.84123544370277,0.0055043588226595525 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark58(-54.34546973508854,-17.337782210038565,-1.1102230246251565E-16,0.35112321101363936,-4.473632837488145 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark58(-54.56179701883987,94.95313814207702,-0.020200043308479423,-4.279564330070089,0.35644946135977823 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark58(-75.13852728113143,-100.0,-0.04654250827128925,0.017688775319706508,-47.207896316066254 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark58(-76.40909917988608,46.525669517142546,-3.850269956550308E-14,-7.289315819146875,5.551115123125783E-17 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark58(-77.77599659300449,84.48219966677217,40.018861911378195,-83.13254770616183,-78.36421169401886 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark58(-81.09708522772799,67.57701926202898,-1.1102230246251565E-16,-10.14552622402906,0.11301937212970126 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark58(-84.55074159562776,-40.33894188485157,-5.807428397909251E-18,0.19920650006448426,-7.885266425975804 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark58(-8.539202235424998,-6.399963053350908,-0.014004904722205391,0.11314207665045917,-13.883396639852236 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark58(-85.45670590598331,-93.81990090482955,-0.05443743650453384,-9.58894464310705,0.013527108875718175 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark58(-8.66422524805239,83.55551589273568,-96.22341886513092,-92.71162736595964,-11.673680544115854 ) ;
  }
}
