import org.junit.Test;

public class Sample17Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark17(0.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark17(0.36208927206005476 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark17(-0.3620892720600548 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark17(-0.9995698989058711 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark17(-0.999980454192413 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark17(0.9999866112520803 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999859 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark17(0.9999999999999974 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999991 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999996 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999998 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark17(0.9999999999999998 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark17(-1.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000000000000002 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000000000000004 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark17(1.0000000000000004 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000000000000009 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark17(1.0000000000000009 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000000000000018 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark17(1.0000000000000018 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000004269025067 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000934788340308 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark17(-1.0001630125416114 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark17(-1.0001853246973358 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark17(1.0011410437323127 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark17(1.0013478557312183 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark17(-1.0038054346024656 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark17(-10.42777677564213 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark17(-10.986480492422885 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark17(11.205369928320465 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark17(11.477325190649722 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark17(12.074579720312855 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark17(-12.720915766661989 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark17(13.806753042227143 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark17(-14.477237979093744 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark17(-15.142041388315917 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark17(15.676521942575278 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark17(-1850.4640802370998 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark17(18.93350329687435 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark17(-19.513972829583764 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark17(-20.116663238982355 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark17(-20.138147711742022 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark17(20.183804673100724 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark17(20.643777302189562 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark17(-2.220446049250313E-16 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark17(2429.14409265109 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark17(2.465190328815662E-32 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark17(-25.501357087518656 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark17(-2738.509595205529 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark17(-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark17(28.85506465368934 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark17(29.248749534640837 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark17(-31.518681499304662 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark17(34.646591087351766 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark17(35.63152803139454 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark17(-35.90587374310728 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark17(36.992802300480776 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark17(3.944304526105059E-31 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark17(40.419963582912374 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark17(-4.25193248455466E-16 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark17(43.17136240807943 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark17(43.82755605363761 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark17(-46.3079462315044 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark17(-47.27023451182482 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark17(47.300913163662585 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark17(47.39506711586881 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark17(4.930380657631324E-32 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark17(5.2033943938642295 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark17(52.191303582556685 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark17(-55.030814391919925 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark17(6.03968351328939 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark17(60.564949238450794 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark17(64.5939630738892 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark17(65.72209538168624 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark17(-67.18959637897686 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark17(-6.722245658414792 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark17(-68.12945739792934 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark17(-69.64187450946382 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark17(-72.99229563221674 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark17(-7.323028375040337 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark17(7.670002643729987 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark17(-79.3224248234366 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark17(80.13194858479883 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark17(-81.83181968815694 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark17(83.77658562879017 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark17(-84.12622491985451 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark17(84.79360944531155 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark17(-90.96564623966638 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark17(-91.07393611063586 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark17(-93.29930392276142 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark17(-9.535262548096995 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark17(-95.54299639794796 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark17(-95.60697851480337 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark17(977.045447774662 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark17(-9.800507294437537 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark17(98.55219353019456 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark17(9.860761315262648E-32 ) ;
  }
}
