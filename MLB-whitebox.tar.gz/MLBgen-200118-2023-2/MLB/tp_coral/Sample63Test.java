import org.junit.Test;

public class Sample63Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,-19.535297568851306,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark63(0.0,61.84806859892612,-62.79622733516683,-67.48916867279078,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark63(0.0,6.671974249717323,-96.08271144438416,-32.465934005638104,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark63(10.334319462980247,-11.728558333023557,74.80791837156181,-20.991594259067142,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark63(10.478574125135893,-10.94640160470162,-25.41929860416394,3.625194530052127,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark63(10.704050218151735,-9.573384272196051,82.8145395497944,-37.02899946180904,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark63(10.801001965225865,-7.863954579087888,33.78584206103639,-61.236836385867875,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark63(11.159412129655877,-7.734764382804343,6.976352891527071,-74.51941855160786,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark63(11.587280593707064,-7.2167626607946005,76.13715818699114,48.784182051015335,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark63(1.1612083989539883,16.156276229087794,89.71940771979396,79.60813554002101,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark63(11.658638113444184,-6.90043376379343,-22.97567399656515,-87.19305417459509,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark63(11.837676032717525,-8.768064428726689,65.47321632029542,-48.37916355269864,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark63(11.904666850289942,-11.621317651669344,-2.896580668185294,-48.15847821802228,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark63(12.080986433358888,-16.62769051366817,-27.480771158230112,3.135811598069594,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark63(12.176142444684174,-10.117765502040726,83.47841987859869,-95.48986859117163,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark63(12.257975533862805,-11.676420918103105,85.84421860894085,-91.16742474064648,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark63(12.90704958331932,-2.2279289065192387,27.33243504058794,-35.198622773458936,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark63(13.064900806040328,-1.2724442973830463,97.97577880282532,10.38197694716267,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark63(13.07041518011276,-5.559394480562418,60.1688247557357,12.390089939854093,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark63(13.149358626351443,-3.8613472846876107,37.9532892848805,-95.5926530673854,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark63(13.199817617544653,-4.347008463136319,89.8057689087237,-19.26074446143042,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark63(13.278186372336492,-12.828931519176749,-30.524635720189423,58.41629481410942,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark63(13.292718349637795,-1.153090801979431,59.33834071979649,-4.16633356740364,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark63(13.584421132253354,-12.640517484300304,24.2387610989056,-43.408116355769266,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark63(13.758806090980883,-5.4654475127649675,-17.908934302437984,-18.339142567184922,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark63(13.760191867694815,19.436628370485607,72.09965320759784,18.32533888033406,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark63(13.837075348789881,-16.92642337659487,60.80390976003446,-10.23240972976356,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark63(14.23684081578645,-4.991476700986382,72.2851453760014,97.92961865785122,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark63(14.385213789954435,-19.96915649423417,-59.52301217591507,5.074293343079006,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark63(14.38780516147385,-3.2468559662449366,90.19329306977548,-72.36100627503497,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark63(14.807101841596946,-4.30773870288013,91.59159707171204,96.99069668865818,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark63(14.858803026071143,-11.971471074343512,19.32415158735428,73.19221259943345,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark63(14.890378407664741,-25.972025787885727,96.28952531902308,-8.182487375060845,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark63(15.246315588639732,-5.934865206746892,77.30564676717634,-72.33215626530063,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark63(15.792010096697766,-7.863719468630919,95.89951270912786,-58.63891654259279,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark63(15.919792762634373,-4.478612957795704,82.72741480531207,80.84953011653965,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark63(15.938868480723883,-6.8806303518314,96.68631090308475,43.46393242308065,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark63(16.500332172687976,-11.790592826895093,-7.804898197944723,-87.4883361104188,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark63(16.52508727032233,-3.0402577111043882,-7.091941088143287,59.78825622020608,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark63(16.585454916471235,-6.057758184518875,90.75128028684534,75.34504235550511,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark63(16.795758255645808,-14.057509704219015,-14.500865487938299,50.52614666815566,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark63(16.840094249245794,-15.355436553103203,61.52072346560996,67.36073779372228,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark63(17.01052211754228,-10.444203924526903,1.3700621330165745,-18.025247341723727,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark63(17.139576813542547,-10.219429469538468,18.163340523826065,-34.46077400387139,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark63(17.149642551640554,-6.645713982557794,1.285110925030338,9.630229367988449,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark63(17.187190782892188,-21.32454406553603,-56.42479154700624,13.473492422330267,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark63(17.247081512311425,-10.463874264370077,-14.349708039656917,49.28167417093999,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark63(17.268953972047512,-13.869671072182243,49.94499309696391,-97.69664871520531,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark63(17.285025966727147,-7.612564061736677,4.211740864407815,75.19089842959511,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark63(17.417886836432174,-6.251654600205583,94.5689167246401,-35.471441622677816,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark63(17.462022855959816,-13.271735493711475,37.06601394362869,-83.1563229536642,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark63(17.563029535989585,-10.595468175918569,70.34494208526644,66.96680320052778,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark63(17.5858296006395,-10.936983650411491,-14.8044049359318,-56.27746378045693,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark63(17.967837669633454,-10.012155812896808,-18.603462375104087,23.194511169462203,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark63(18.132411833890288,-9.819548335389541,24.404505244092903,-76.9962261547006,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark63(18.180695236311763,-15.722372923282421,89.95436272519294,-43.341469694972254,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark63(18.293409031437207,-15.983408829434637,-33.76454908978583,-37.207429237721115,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark63(18.363878095353783,-9.11436014613183,36.34913791066421,-15.254789262167435,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark63(18.65244715367274,-17.46838894091684,-40.02461293683015,71.0334697988504,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark63(18.72300831681744,-2.0998243292880545,53.16310349905453,-83.77491528904355,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark63(18.764135349666674,-0.5006933705114136,30.024457145728434,-60.219322897088915,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark63(18.861981956093516,-15.137599129087391,92.595501928219,-17.5329199909428,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark63(18.911763102870083,-15.813370045893933,-14.23248348364639,68.56670670720831,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark63(18.954052160109967,-10.601550657681742,-13.49245755282152,39.20574177137149,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark63(18.997113006457525,-18.61321629166291,-26.043138057757602,41.23297957910438,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark63(19.066436345252598,-9.876244983775265,48.25764753228091,-98.24051176674686,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark63(19.352004485915742,-5.981494893213963,51.33183269945957,9.253145526776493,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark63(19.411558305233285,-15.6981989410599,83.77666343742726,-23.52651457202137,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark63(19.421526360229535,-11.59604660839517,6.026001710337908,46.02448120478755,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark63(19.452102027237103,-15.360390081627955,-30.9332024901003,44.138385579950636,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark63(19.494969805627704,-8.334089313394927,27.054716442620517,-47.202332584816695,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark63(19.510330813846295,-17.546859126330745,21.41732415606765,-78.47094959236259,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark63(19.563826556292298,-15.254628431586028,-33.60479489340892,67.32196952796147,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark63(19.70287092333504,-17.76973518210592,-12.539809875909924,-21.9246164139296,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark63(19.85338650679087,-8.298664704576765,77.06943906466205,71.10131356415127,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark63(19.863057990111216,-11.619566005061955,-8.6005436932072,-21.132644185091337,0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark63(20.052348605354922,-17.74642016607369,-6.191883094961042,-90.15869888016064,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark63(20.357520499686842,-11.036798473735132,4.211414100138853,42.050646306395834,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark63(20.373296860058062,-12.033357892353251,27.132372397400204,51.360359874304265,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark63(20.936908924488137,-8.01457448287097,93.31730164177378,87.38267977052374,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark63(20.967017425561593,-30.529566141207724,-73.49763635501414,4.340723364302306,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark63(20.985199060862286,-81.2144555359501,42.24469807719774,-0.18387257124584266,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark63(21.002381677997974,-57.832261454223,-80.60375017403678,1.1084352888207434,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark63(21.077219397666695,-66.97906196100041,-91.23295769967015,0.00974774591892924,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark63(21.090038994262045,-3.8615186324074955,64.87048433668411,-31.32121479272361,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark63(21.16930273240895,-9.909016314494039,-14.334480910132115,24.32590277361608,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark63(21.182943531542932,-18.618224715814847,37.23559484598681,37.200880079531885,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark63(21.183331131236997,-0.3232451533809524,9.192397099281592,-78.77026130020386,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark63(21.23764405533359,-11.509441557130785,76.83966370802503,-76.29725196134913,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark63(21.25110335263271,-0.9118884928861632,14.856014680219289,-1.4856942211431061,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark63(21.36155104390278,-19.839267876608616,32.780645206513384,48.698628687133464,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark63(21.373181171033863,-17.5341825018058,8.708987534901098,-54.93053114944069,0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark63(21.56875831587554,-12.665924321487168,-0.6666626941160558,4.856266596406144,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark63(21.971544165214894,-15.407919788558104,89.34197888267838,65.09962027599937,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark63(22.16125136875023,-3.128900793433573,92.42260403550071,-70.65101134826088,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark63(22.373594963784953,-20.95513710435712,30.454919102111234,-87.47982091955247,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark63(22.38679533069839,-3.187725785236026,64.21745033542538,84.4150345109997,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark63(22.502368947803888,-19.774935177159676,98.26911778474019,-30.565378549226025,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark63(22.657757918575314,-17.40731114659704,72.48317458767534,-94.50676310164283,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark63(22.71005679402907,-0.7827072691413548,67.56611425935893,-52.092547936728636,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark63(22.740046357649064,-25.896210229755724,86.22770141824455,-6.364886835461164,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark63(22.76098774316968,-1.0348717092180095,82.85221634623258,-30.624536859696036,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark63(22.826071712954004,-16.78831618390963,-26.14223852132173,-88.9200794799548,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark63(22.855278506202367,-8.20345167861818,23.142243779678708,-90.81859618763335,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark63(22.892375983367018,-16.650093998793423,77.50127687127281,57.19368315752902,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark63(22.943422227189885,-20.557445879572626,5.680407535223537,-17.173062341458035,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark63(22.94404431308392,-15.44508605501953,-63.58357742053864,29.189016342378892,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark63(23.02828342360803,-6.794590542405075,3.0451104831119835,-26.054081555368967,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark63(23.035630632323546,-16.50224997319485,94.36967896427785,-50.31011250765063,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark63(23.1624410135542,-12.14761912626065,-56.379848992586766,79.56724935189521,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark63(23.29108353382985,-9.118877667982076,84.81978708515271,51.661908431146855,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark63(23.54270850835198,-8.64485987287867,68.7933033411031,-40.89707393820012,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark63(23.56742577908247,-7.564549944914319,92.99316423104187,-88.58826510655766,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark63(23.631459581637188,-12.05173809898659,90.97230845270349,24.572202481499843,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark63(2.3635014980800264,-0.36897185519846687,37.031334062563616,-78.2277815787326,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark63(23.826241506186932,-2.104538110385178,44.72396094217507,-52.51869702623213,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark63(23.93406840104815,-19.681453406053137,-78.37838553883589,-79.80213537520824,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark63(23.945481785707372,-2.783721156746253,44.07520789852404,88.0948485347268,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark63(24.026412026344474,-21.25735608950545,26.170408913705117,92.29651774868935,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark63(24.10247348861354,-20.651661033159613,-96.91279931944227,78.11353052864746,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark63(24.330685430796038,-23.183028793473667,-11.041719198967243,87.41163930888433,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark63(24.426107785246415,-10.944516541102274,68.27558395825085,51.77163919969405,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark63(24.56414744537372,-13.246900682056648,95.67166104014063,-51.90137648800614,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark63(2.4606137700307755,9.860761315262648E-32,-18.628467132783015,-94.90685128423726,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark63(24.662853425020543,-0.04605477714186179,33.203573191036185,57.91898730867513,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark63(24.690205234469232,-12.98051563216562,12.499385664765114,-31.462766043781713,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark63(24.758576990201234,-11.131163459803517,19.981287056594226,-25.68254313775553,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark63(25.113326779928087,-17.47823418725018,61.1696439507775,-19.870678935954118,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark63(25.416887526557502,-21.961528381328094,-92.33911110024012,99.50817705630152,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark63(25.479478839524077,-15.694103634622223,-64.65700045521709,-42.98591584523486,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark63(25.57866905462214,-21.7726193495469,-72.68178232523705,15.993126272906395,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark63(25.622706168626877,-7.649374192499266,56.95433092525849,10.34630061027056,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark63(25.869035701865897,-19.407215813835094,-16.101572006733477,-37.82881520851367,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark63(25.902943759859625,-6.090728517260288,60.99287205922852,-31.281147514295895,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark63(26.031460479810306,-13.749329817424112,67.9317720882689,37.43300470423799,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark63(26.108394892496236,-6.747592730881365,3.042581502605074,64.91826543633766,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark63(26.1884243612228,-20.52890299602626,89.7948955067537,-29.138018775510545,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark63(26.311405154866435,-9.422305294271553,64.87606721361502,55.0232245339777,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark63(26.32276988006153,-9.553480713814807,-5.63459269432218,4.960244529950714,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark63(26.357531337919255,-24.699156865815326,-77.28505130589804,-86.80863460196551,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark63(26.357639901275647,-15.783685554919089,91.60802414694069,91.4816055349381,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark63(26.369281812650854,-34.47892817904996,-60.73985543912901,0.9152858831561872,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark63(26.45086549571394,-5.498020275032701,-14.061501981942243,-7.0049303899048,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark63(26.619012519868335,-12.210925387995246,30.508599852590436,77.10238880461807,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark63(26.66728896679878,-5.737692944516297,74.15108626097177,-3.7848979903887,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark63(26.69263209771357,-27.20082762782701,-51.285297748024796,20.158886668383147,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark63(26.890597842468907,-2.6678604204944065,80.05666156086133,-60.83162026770032,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark63(26.90717568707133,-26.894567041569317,-63.57861596993941,36.34153250261346,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark63(26.95304522900051,-3.029168483749501,97.32900163873879,49.80345912692269,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark63(26.99302854216738,-2.404916134092346,79.24624218187762,84.82882061540386,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark63(27.24914671289052,-13.036150182189203,-51.55059465682672,24.4447822838667,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark63(27.269296072738157,-18.316818805113954,44.623821537362005,91.67957930699367,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark63(27.327477595138603,-3.5743723326993546,0.030167890510440998,4.579325005458273,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark63(27.328324904447726,-23.357978222124046,29.90064224746294,56.43611009065236,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark63(27.421208787439497,-23.056156799599336,52.39158021733979,-5.624623108285974,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark63(27.430806742351493,-17.638735139223854,56.66029671918017,94.30447715825926,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark63(27.493674293454035,-20.09023178855722,38.39338547645298,93.9072118528037,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark63(27.560441031206807,-11.898102777784445,-21.90311296208405,-95.46409240355587,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark63(27.75932749840831,-14.886333420803737,35.98207067864587,-45.88836475840419,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark63(27.76729229494623,-16.710411727147374,54.76667273251604,-23.215710715734986,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark63(27.940691214717603,-6.5696335436272335,-1.8872050513231784,-7.241320028501946,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark63(27.956868052249888,-16.65355022383679,-86.79455866528237,-90.18438129842939,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark63(27.961205712669596,-27.755389191414764,50.729753353329244,-55.61743224624092,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark63(27.99985868408656,-12.198066897592213,20.546598703875233,-45.00793745649692,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark63(28.088299129438553,-20.776567988003293,35.26690036380501,12.219575962456645,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark63(28.135999140774516,-14.211074194795813,-34.12492697272231,7.292016027477317,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark63(28.18258661546696,-6.673695005181074,79.92909921541681,-5.3245945264396255,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark63(28.228856288069636,-0.8057518055724984,27.828704740148424,6.441736171165857,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark63(28.240037251572147,-6.933196533273133,20.393095143836277,-29.408984069039178,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark63(28.402590293983053,-37.84390684467449,88.45704415091313,-8.911370494537493,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark63(28.631331934138558,-15.576723586894701,29.593904682860938,45.81436690102322,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark63(28.6440851307849,-29.51188677726566,59.234265649443074,-67.9438424400123,0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark63(28.702730384912797,-23.412218226426077,1.2366365976221232,45.925816288806885,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark63(28.713747860775896,-85.70713824517506,33.32748970446602,84.51862955331265,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark63(2.872558950440691,-3.0909096628060126,69.28900914144472,-88.87266590632088,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark63(28.900156370762858,-8.16421729245063,13.259571730193471,-50.07357196011566,0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark63(29.24079870586408,-26.042163095611045,-12.345768532740252,-31.25553075993568,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark63(29.307936938176113,-13.3299706407509,-10.52067155096239,-63.21102420121869,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark63(29.507305045461436,-22.926205930012912,5.9402913018513885,6.6814022300926865,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark63(29.550660946276707,-26.44829427960343,53.95027694026268,-37.94922430483578,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark63(29.589078229446727,-22.83044676427319,91.94923389687685,20.2274397230007,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark63(29.69050357122501,-17.232659388729132,-50.979722325404666,90.7969225203577,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark63(29.73578681765602,-18.337302461916494,44.557945615224725,-97.95340013749052,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark63(29.794213147105495,-24.346226096072797,-46.33929480052259,12.305038186720623,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark63(29.79977698707691,-18.843272758888617,72.65001352856783,70.50612365780148,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark63(29.822147466608783,-0.2958193729735399,50.49541387254294,50.422734263739244,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark63(29.887451821942705,-14.587608232845682,-43.52152045882982,-42.27691560641367,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark63(29.941144887275414,-27.155187932270294,43.284851391451184,46.33574788845877,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark63(30.17952709399671,-1.9789193793108097,3.888244480983033,-32.47137810041711,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark63(30.26849236361994,-13.708673492315683,59.762270691852706,-61.10149117463837,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark63(30.32968162888477,-30.432530130724473,83.26438343260514,-32.84196797218391,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark63(30.398998141732704,-22.620193322795785,9.40694384329403,69.72223630025579,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark63(30.40228290476807,-6.317586356938378,19.293562321454758,-55.14244860758419,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark63(30.557008926562332,-26.66631877963961,-36.53937757474041,50.71157015857062,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark63(30.588878576727495,-11.684770708614181,40.26877941463866,-13.224217590247093,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark63(30.670441243096604,-18.10001045546666,37.44514079888623,-44.545588079097854,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark63(30.740173474506605,-23.104391856190915,-28.15246154579667,46.10814549298223,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark63(30.755396756124128,-4.226011068381524,12.861531966952697,-44.656471271211394,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark63(30.874588987756738,-24.230027203554144,6.597950633830351,-95.60009344799722,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark63(30.874842203546933,-18.92189497306937,-22.98645756645061,-73.79747232447596,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark63(30.894460270001957,-21.975379964814067,14.583409726997786,59.20707529840783,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark63(30.997404298850796,-25.793514674889877,52.51422543233667,48.116660269118256,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark63(31.093274835128142,-9.381232398295026,73.91199942359646,-97.65380881873129,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark63(31.215184383308014,-8.406747919596484,-15.028211390520951,-32.285356812323386,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark63(31.219023306847703,-20.802654671030638,-72.41110190718749,13.943253784323502,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark63(31.260321384808663,-5.8289168741396225,-21.869963811411225,-59.54080284705956,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark63(31.273873458312636,62.45582669701412,82.48937405019146,-18.896807222020612,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark63(31.317049983045194,-0.6029598671344161,4.143252510009958,48.50029585904031,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark63(31.324352089968613,-45.92425842040049,-82.0924572867616,3.698945115373192,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark63(31.396388562842986,-30.03970675491432,-63.04127712103684,63.39885496570275,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark63(31.40267218514859,-18.31130801286271,49.367779917834696,-43.59257768637854,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark63(31.6712279015687,-24.800147794273528,-75.06711240838479,-40.22294474112975,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark63(31.752575181034217,-26.18202948550983,-55.10143794398081,-25.674536880002165,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark63(31.761335027265915,-1.2597890369210347,-3.203642789723517,-0.9878393600831572,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark63(31.768755492824482,-22.38955446798434,5.547836311666259,-58.35533129029966,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark63(31.859922202143423,-23.940396975038865,27.934482695803382,-42.917615817639245,0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark63(31.863333969163165,-30.60755325960949,-22.42512365505722,-32.14213879015979,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark63(31.87328048597533,-19.989498648259826,-89.84004304230521,-16.834808557002702,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark63(31.873851370502337,-5.1207897524800075,0.04910008220515749,93.9984691526682,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark63(31.877582835194346,-26.77053744313575,63.30646078621996,19.349196745370918,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark63(31.91488386815047,-24.281769508265484,-4.708701830356901,-75.14098937904727,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark63(31.92503291809524,-26.93221849381456,74.47275301430781,99.05046829953346,0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark63(31.969130067728088,-19.28481119817343,-5.0134875049897545,-81.98199703515186,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark63(32.05217579695031,-20.74159426222775,31.593916451461638,30.271770220615082,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark63(32.220581833232416,-8.381620988618124,-17.543609973704292,-84.14247274566797,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark63(32.358717922332346,-18.603172658399785,3.4664277220918933,53.62545679243257,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark63(32.39681163667791,-17.502943792647045,-89.69609074986933,-90.89023583950562,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark63(32.54239267891529,-2.2541904276139206,73.86902152286092,22.910035825940327,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark63(32.569630914604176,-24.527514063752264,36.016119022438744,-24.545653550780273,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark63(32.776995422809506,-26.316644041065217,87.29272954344438,99.0509633837392,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark63(32.983584110379354,-12.326659627122538,28.441365947390807,-37.63271185393524,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark63(33.07207865028906,-20.56224575199677,-52.054759937037545,-5.514823380366835,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark63(33.13359450457182,-0.4598800202475104,75.47016958927429,57.47243823838329,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark63(33.17039229744259,-12.880072374762037,60.61763568977159,33.55591116347719,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark63(33.19918426616016,-12.636653031012585,95.5953320416418,-13.821466737536056,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark63(33.27063797838136,-12.133025630460395,-10.203366881680196,-8.297662733818598,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark63(33.273634046174635,-20.480189956914657,19.42557552473096,11.379763906637066,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark63(33.2822515397217,-31.879754319049496,28.823798975231256,96.91672217050382,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark63(33.35825300223232,-18.352871864315716,-19.29680449730715,-5.945635406650666,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark63(33.42904942621885,-21.936718305931066,-83.65031361866639,-77.75983962715355,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark63(33.43577826478935,-19.862719407115705,-77.27627420776855,-25.063374977298906,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark63(33.445132667079946,-1.7626954715990877,97.81409124447052,-50.734818376157435,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark63(33.45112596668821,-15.068658758989045,56.63981739545835,-27.91592424424701,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark63(33.49531942223763,-5.917307338638594,-17.735649940672985,-8.093196501078268,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark63(33.5056371406977,-20.970444245565005,97.86782448596924,-36.535590159237174,0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark63(33.63057667309087,-4.74484383754465,36.59546573031329,74.2135637381096,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark63(33.65807811165877,-16.85989573282454,79.40987172941985,46.21565219713932,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark63(33.77661885704782,-33.80206480670438,-87.72953310912229,2.0992620719970887,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark63(33.78668238026904,-23.60694755538634,-29.52725641038181,65.32714892482551,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark63(33.80264233107809,-21.886946499611156,-28.538096662719184,20.13306005412805,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark63(33.85998579456577,-30.58176427777562,-74.58000428592008,62.6734632421296,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark63(34.10410036250258,-24.52216901760322,-61.95045878244447,5.619637885584567,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark63(34.10709054584501,-34.881418679252334,46.510737987561754,-46.75378315254284,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark63(34.130440995750035,-15.573414672461155,20.638054701433475,27.080326187951883,0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark63(34.18707027667631,-25.077825952865567,-39.60294592825684,30.944418081167186,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark63(34.209134905528,-21.04993656046163,-62.7991091661988,63.23214747242193,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark63(34.3101446831607,-2.4208857670715815,81.53955969459005,-94.26659551717344,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark63(34.37785591794963,-2.3787832819980963,72.36972072531879,56.08164727309881,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark63(34.38213412613803,-15.155704324749578,-66.27808875267235,34.46400723340949,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark63(34.40696730453635,-32.59436043743807,50.01433258388482,-5.8656579979897,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark63(34.607217803450425,-34.13246485965398,-81.09645052564119,92.4216387814595,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark63(34.651101201593974,-29.4660911399629,11.896006040668809,60.78815586036319,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark63(34.651767091534424,-25.729238056473136,19.69953818232466,53.5324388032395,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark63(34.706095735844826,-4.081820416695052,-17.674486586452787,-90.54829178324404,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark63(34.71122352317377,-21.762498795601076,2.366302939683493,87.88995781964684,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark63(34.71366198773231,-31.362532098740246,-36.685808617784076,-50.470981153838146,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark63(34.722183125133114,-24.253060117612677,63.76695432391969,-79.10183708171199,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark63(34.83433089991115,-27.671675378090626,53.31512688388841,-95.35462171513016,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark63(34.90544777991653,-26.762349976840127,48.902348179480924,-48.34866699658007,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark63(34.977677159509,-3.2175843548063057,-16.157977593768607,10.888165567091306,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark63(35.01577942181066,-32.75063503563452,-7.999551141585442,62.12337769287865,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark63(35.027379379639996,-13.86644394022845,-2.673487109444821,80.6321929339546,0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark63(35.13544322048614,-27.903593892506407,-39.65334284096207,79.60744137802877,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark63(35.34650858474296,-7.08509388287797,-13.09420042539817,46.74757390858261,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark63(35.36073506157064,-15.146602936523394,-24.259539640234735,-61.26851302603509,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark63(35.402602253043966,-29.78822266654872,59.86193711121942,-68.98817331379416,0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark63(35.44354027089602,-33.42518841990656,-2.658109601935692,-86.92095014839414,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark63(35.45063641173982,-70.6520539165189,-85.67764400072076,1.361260481766081,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark63(35.5118808390381,-22.499233817755652,84.5921860171432,96.79403720508532,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark63(35.53299096699368,-25.745067643802642,-18.58946626459634,-99.0937522543611,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark63(35.567978701962915,-17.205562814887188,-20.2481037375464,-67.98295841082188,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark63(35.58166172490053,-30.967009120467864,48.27506594440993,-11.471597333691875,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark63(35.59300256544202,-27.724735804795216,-3.7548974619568014,69.0416212582594,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark63(35.613191826699335,-8.908730736821695,56.0365273936319,-60.29605565790206,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark63(35.614625317697744,-5.003519632668812,44.515587848306865,-89.44423937666343,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark63(35.62095610358216,-23.342408339080805,15.881462389607975,-89.78322315273073,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark63(35.62273433887475,-15.567438100224734,23.59398091217888,-91.19196221781422,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark63(35.68257238587057,-27.866018047157496,41.91432795938789,-98.57419620793304,0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark63(35.76001781709533,-27.78098445672947,-73.75641968786799,-50.901468321556905,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark63(35.771257264752535,-33.51888852564393,98.57274581551368,-78.79500857953727,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark63(35.82564194392589,-24.744197905969884,-23.56637894544329,-49.75885678896106,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark63(35.879116894696836,-21.491652434475057,-93.12930694377586,-74.93660288440891,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark63(36.06859802027998,-15.615203493751764,63.55776677053541,-79.28776382771457,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark63(36.19900015707961,-21.313137085574112,-50.37754302260622,-29.89847976867594,0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark63(36.22846674455457,-10.250169655213085,-51.36792300281476,-16.46738602264594,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark63(36.31732027677839,-34.059589911235605,55.65331664611608,-1.025481646515118,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark63(36.36274152001275,-3.4616676382525498,87.96604701487169,-24.73721204074741,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark63(36.42438426598255,-18.219387845062755,39.48308548678361,-13.012312460436789,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark63(36.445958158617174,-16.673351155943422,-13.224604777049123,-58.66571355175283,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark63(36.471364479116744,-15.519922120147541,-5.433645495038334,53.68561725362383,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark63(36.567864711999334,-25.381070544841265,45.624498957814865,-14.115235246561326,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark63(36.59632912911212,-29.889436953593446,44.737251649998484,10.484719148106578,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark63(36.6758707002578,-36.078770448128324,76.53887852041464,-79.5830234714982,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark63(36.70145717604146,-35.682384489085834,7.187058317531367,17.001120189796183,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark63(36.7329015044194,-6.041233886281333,15.272603564735547,26.833965383566778,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark63(36.737551893645104,-27.08082292410569,-14.706443973898047,62.669657802046686,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark63(36.78268813716636,-26.857801502754015,55.13518299977207,46.33169747541942,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark63(36.84273781459632,-35.681918820499874,76.45418352223246,-39.816407736861215,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark63(36.89449219618743,-14.184569141029442,-6.15755091243561,51.38849051010473,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark63(36.909795341117814,-30.63159774289781,54.09165318882006,-52.67819745457594,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark63(36.91639161425647,-2.9037984032124626,42.69713729768074,-31.663477364925512,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark63(36.99996664977735,-9.639009762937476,79.51655136014122,-95.92375308345204,0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark63(37.01407576521652,-26.874254479938386,-14.557788001619329,-68.09216256514893,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark63(37.05555849275339,-5.53228190984612,91.50689373842658,-94.34684932313844,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark63(37.199278220730974,-17.53911622954898,-26.874959818928474,75.90787699137607,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark63(37.21009490552635,-20.949654880449245,-36.17965979079383,94.6601365389657,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark63(37.25741758383538,-34.6593101152193,4.646119690811034,37.728302111153056,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark63(37.266469027589125,-23.39662046842963,-20.284387806132443,1.8224318957976777,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark63(37.45708294783009,-16.6769515857126,52.88847477133095,30.210260631216528,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark63(37.53683247356017,-31.557898804583843,-84.05859308570246,11.251099786879763,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark63(37.57835854157278,-17.7889231305618,35.965645978678026,79.67414752157188,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark63(37.649084630381935,-22.88188994789438,-78.56179892101218,58.44233721499651,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark63(37.6547052581445,-27.81839079304875,-21.02451203305982,87.69251006602403,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark63(37.65788927437217,-23.521387857686122,-64.82509178218743,28.19343984886669,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark63(37.67558515162875,-18.48006293502891,-44.903135542578696,97.60421872214508,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark63(37.675913366708954,-14.70934799219927,33.812947688865535,-93.93583486896324,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark63(37.69874589504758,-0.5248136589743808,60.26497817255415,51.33416168757623,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark63(37.74197590957215,-34.56567863781514,-91.71613116202263,80.3773076035495,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark63(37.76988372325786,-13.034542018572807,-54.55102625218598,-92.07516317068547,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark63(37.845975667866014,-15.178598700413787,-66.60298032213274,-93.56825616724566,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark63(37.86680190084232,-18.626428428798803,-34.58688254625346,2.4259024768308137,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark63(37.90080294141649,-15.211700322654224,44.2743791016232,20.12618208450698,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark63(38.04478920265569,-21.326754738852088,-84.62718590661227,-91.61315897541769,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark63(38.11123658686958,-24.21730526208445,89.09693103819859,24.569508189748987,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark63(38.14468096735425,-17.44103706757501,16.579088161800783,3.406643694866702,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark63(38.147390662302456,-33.833408396982605,-35.91784190891889,-48.7551077546228,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark63(38.18538486666367,-41.67922232701318,-46.777737436652764,5.42491157078193,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark63(38.210188680938415,-18.344687074245854,41.55149084480706,-69.65308367937646,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark63(38.246428311326014,-44.937775435171986,-91.65937440179151,2.5642121338888444,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark63(38.25661935351491,-22.901653837281685,-86.26520613871394,-54.003983026742205,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark63(38.257283302943165,-6.08801086056188,-12.269332000778704,65.95218694116127,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark63(38.32148592503222,-24.018948319370878,-46.449294371966474,-35.47864363310114,0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark63(38.33778968286626,-13.87273866285284,52.31799420647104,99.30166960236505,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark63(38.345534950772844,-12.659539833622844,89.71204432104275,-27.705038512063382,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark63(38.354490227797925,-31.39276692948569,9.46660562905197,-93.84048069258799,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark63(38.48544913050267,-26.041692718141448,-45.19165095147801,77.109077339532,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark63(38.50239839058986,-17.871394098480152,-25.923049911077896,57.63990081947631,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark63(38.523457399328265,-34.52636191860876,-40.34385686110853,26.540771284215097,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark63(38.53967312206507,-17.91199787092215,8.281631437917781,-32.80218205894275,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark63(38.54104697929188,-9.680302783126464,80.97238707186784,36.024489384670886,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark63(38.54579800201358,-37.28321426211458,-21.085714084795583,-24.939429988674263,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark63(38.55275589648235,-26.9616541389625,-43.78102640996118,-87.06813793719073,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark63(38.59161676077298,-34.01138703128453,-26.652397189840443,87.45543554982581,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark63(38.60381312231351,-29.935117773482673,-37.98604287862639,66.94037422591776,0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark63(38.658257192225875,-17.386758344914142,61.38803245845946,8.59312397248857,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark63(38.71472238024697,-25.66773750016118,-62.227844929501686,-71.26953958833016,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark63(38.727148153493715,-35.51467281981044,23.735572768075386,27.979130255257132,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark63(38.76262830953067,-17.724721833890086,41.9890635616116,-72.95482189329817,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark63(38.78981059852913,-31.19306005053801,56.89819104999748,71.6066817336359,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark63(38.851809359340876,-27.42153406158421,-63.907254950950644,76.76401386739354,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark63(38.87645770117501,-14.72154152903245,53.58364571601558,60.544098620802146,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark63(38.928360295484424,-27.64086164474844,-37.860128606868784,-47.84533950808403,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark63(39.000230157076544,-23.03859137937117,-56.77473273646416,12.246056816541056,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark63(39.07273906081454,-7.038771225147201,43.663807003392805,83.50716550767515,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark63(39.127321326079766,-10.692951403893545,89.91009670423594,-60.994853474147746,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark63(39.259096990894534,-3.212043186093453,27.959382689837156,14.269085730645358,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark63(39.2853463263298,-30.402762771788034,-34.779069281366404,-44.96501022183013,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark63(39.33402597795299,-7.2848926882005856,92.7875945133822,-74.63573516761271,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark63(39.40099253896227,-24.691673410904173,25.243409879202304,-53.02039342213709,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark63(39.41634781546489,-9.990231155923652,-16.547114251574783,95.59494455671089,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark63(39.424761548110666,-35.98320996819125,-54.319123303131555,-33.280483771598824,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark63(39.471097846565726,-22.539491351425937,46.94362164836497,-86.51102031256804,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark63(39.48503517237455,-0.6421265765052624,53.091591080925326,93.11755688188845,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark63(39.519386480968876,-38.51246820822758,4.570565514436865,-64.10321163274932,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark63(39.59354723718042,-9.903648968034489,63.274823025874866,83.6970950451641,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark63(39.610442412017875,-35.91450179971565,56.4369621206242,72.47354387485271,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark63(39.61686184519942,-4.890453186607502,2.8528940012736683,46.01789827542194,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark63(-39.64189699982548,3.9109615234588944,48.180937051064944,-30.79927414628156,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark63(39.64547100623196,-19.0465655861708,-86.21817833844973,-52.37428860165338,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark63(39.652570201838756,-24.086878927940305,91.5790229398209,43.94602993176548,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark63(39.87421671736999,-30.577309489825637,26.764133002822504,-6.0341257677252,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark63(39.94929981647786,-11.472846189343727,27.746970046463048,-36.59500547022843,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark63(39.98190060680474,-17.13290045804625,98.14150817695196,-14.16203349112996,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark63(40.008674488113684,-25.822775452905034,48.85422389559389,7.058590740471331,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark63(40.040507920854594,-18.653198453711667,-20.73654259008704,-38.34368244586776,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark63(40.04404562672684,-20.58393959795997,-61.62744817066426,-95.45253522005095,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark63(40.04730171871239,-13.29948571729335,84.74428489198627,67.93493786521157,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark63(40.04991847963021,-30.20486374107972,-8.488769380640377,-71.97954334052572,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark63(40.08725070510894,-36.88879656005355,-18.331561658830523,-76.72920480375372,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark63(40.12746995282092,-35.173543360741434,-87.26300001783704,87.61887207038257,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark63(40.155168890467934,-34.93380366234429,-40.989844539962576,79.19510763035777,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark63(40.219224389231755,-28.019257617461207,-83.10766846588086,-97.09658349618249,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark63(40.2324169852956,-17.191595376493794,89.2131363680567,7.227141235474832,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark63(40.24649372367227,-27.776125273387066,72.36676521733506,-93.41997588509673,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark63(40.26618245595307,-31.297656183278505,86.6922979840549,-21.47203483842833,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark63(40.356038656745966,-4.411230295381017,-5.802326996922403,-5.72430957066814,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark63(40.42307107962645,-3.7417747393966465,-20.49064468826876,46.863840199219794,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark63(40.42800516029189,-15.982798056848921,-42.14506959494773,44.4245803513013,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark63(40.431907353265615,-39.20522678971488,-46.44256158112307,-41.602737730108345,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark63(40.449483062833565,-36.77576357839554,25.24753626653178,-14.60324785096904,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark63(40.48549958099201,-22.820578219542284,28.34598208617328,-54.48534249592074,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark63(40.4960921124362,-31.865656459606043,-41.897555256793396,-68.048977802652,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark63(40.49790647253428,-16.53134471272881,-21.985152427673256,78.45494807661763,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark63(40.53254930133815,-27.675340561461596,-27.071581270828275,41.84306563250715,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark63(40.5363191394691,-16.81169274912608,-59.79415232374128,38.60939102369255,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark63(40.57452263379179,-16.516230125147402,54.52298584264369,-47.3715935536946,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark63(40.656341511003205,-5.752559873498612,23.155576571876324,52.20999776952982,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark63(40.79385458371712,-7.808423862881369,9.712409194125499,69.2178916650831,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark63(40.8112075360315,-26.19091663536817,35.31647691645205,-43.52978940186845,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark63(40.834418110268984,-24.155429924848562,43.36146913994551,93.6937759854271,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark63(40.880508311461256,-29.72115702723177,-55.671864916999226,-55.141152106105,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark63(40.90946423113937,-10.303632383776275,30.15341448449044,-11.768390402669212,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark63(40.93316654562042,-20.116370028403068,-35.552102646866885,-16.33892849895058,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark63(40.94775054372974,-28.97154461318972,0.7232837269419292,67.02649016661263,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark63(41.029506845853064,-13.77441179880796,-27.410443672737216,-6.906131040586899,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark63(41.0299215611216,-28.860651664571634,-8.322175060598113,57.64100533701787,0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark63(41.04333920551281,-38.225406628243455,24.595749673638608,-5.1802014539980235,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark63(41.06656645000123,-3.461218721493225,39.669567504185295,-94.14480055291008,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark63(41.108235442979606,-28.779523903438317,33.52706721884641,-75.5369212491633,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark63(41.109129683914176,-27.34080506992653,-15.56539594412196,-91.41139668425475,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark63(41.13022922778555,-23.974462247011047,-67.3581831552477,-30.434022059796064,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark63(41.13496153325593,-8.494467151445491,-35.30246194032354,12.905300684307647,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark63(41.14874882538962,-20.634702927319722,75.13802946335605,-50.251762514861255,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark63(41.154227922217444,-9.428448279679372,40.65398810523561,-94.34612682293294,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark63(41.17324202260414,-12.328695562829893,-68.06981057210557,-17.75347743417302,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark63(41.23981356236749,-22.03338460236985,-38.95767786187745,33.16064970030027,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark63(41.322918462585505,-40.428725065654405,41.87287837148202,92.21287623630039,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark63(41.326270277202866,-13.30485517031373,23.683382211874914,29.661150389969976,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark63(41.405376073305774,-10.135190126712757,12.174190054657558,-7.461947549053761,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark63(41.42739853178344,-13.842052049972352,-31.49939210907003,-67.4928435052124,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark63(41.43041776122212,-15.846554872223507,97.520620194916,-19.74891675500514,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark63(41.44426257909686,-17.072694131236332,-10.521951307588878,-71.70618297821196,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark63(41.46341269905659,-1.3879932887299589,83.20045985969315,61.64791789759943,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark63(4.149159880250508,-1.5356786167044731,65.84439509009087,-39.48049954982575,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark63(41.4984466604414,-10.799846448780542,36.11027710456591,-73.70338515357496,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark63(41.5353147021099,-31.883269210350605,78.4519843272553,42.559401742276094,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark63(41.56275890765781,-30.399388751571067,37.932939769657196,-78.1669657379633,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark63(41.62850713886067,-4.88652501748075,64.33924862170181,-51.51955618675588,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark63(41.63186602128201,-4.151141742054733,-11.406337950237287,-6.175998768814381,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark63(41.67259985638856,-9.827823108118409,89.81358307184627,89.22397333657744,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark63(41.73299512084216,-16.945826438573036,-62.17407508842836,96.93023015035476,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark63(41.91865409225386,-16.569246612950693,-98.55895418436444,-13.1588879356906,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark63(41.94303781197115,-40.07027495657651,-57.77299286513342,77.46148829532845,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark63(41.98372113727487,-16.59998341100375,-9.344844226640902,50.62044503473953,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark63(42.052917355973875,-24.348641020487833,-84.2027900024797,-75.00632798956492,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark63(42.074861426195895,-34.554904334737074,-66.89959896712276,-66.06193499078192,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark63(42.11782505036658,-27.413938778914797,-12.878829164778011,-68.5007993070975,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark63(42.19538613673109,-38.26418800890916,73.50015208525915,65.84989521183383,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark63(42.21762330152396,-28.02710899064016,-14.256041476041645,-31.2952864887134,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark63(42.328045995880416,-10.33986203469071,54.22338703635003,-21.49911551307659,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark63(42.334810070810676,-46.78449612341402,-72.71282638683792,3.313989957607461,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark63(42.414480543440675,-10.601989410283636,-60.494247234191036,-50.24090132212249,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark63(42.41894055935708,-41.153350870283646,-49.53314540977662,-44.002757650643254,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark63(42.46595588626741,-4.859544175476543,49.854488663264505,28.809852602014644,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark63(42.491087804581696,-25.972495366199382,1.0012310262941497,54.51593017207961,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark63(42.49301410325276,-28.212668446717018,13.662775719210558,20.94665545457839,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark63(42.499436384965634,-1.5345310204860567,48.7941831498581,-3.8842714703905017,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark63(42.557517882204735,-32.50465209576561,37.857493095567605,-16.916442326219055,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark63(42.5647162027241,-35.079186277150214,86.8137783859656,-90.11000402769132,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark63(42.586311512325636,-15.843414668008492,7.918047193265338,-62.19224015205309,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark63(42.61639724547268,-35.40934949132229,34.607065910024545,75.36795168040521,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark63(42.66595306251432,-9.981148295014222,-36.61445090943858,-35.470393332533234,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark63(42.69146549480337,-33.73918894024439,58.82417794238049,8.636521584084917,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark63(42.81219136757264,-6.071227675517534,80.54999236972924,67.48481090887071,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark63(42.990120447457855,-12.377823965043461,31.44943072795948,21.805745203712235,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark63(43.01229657005243,-39.96031698386619,90.66858811851901,-86.54198368572096,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark63(43.02059574226894,-17.0235365168339,-92.84924640349797,19.935689772264695,0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark63(43.10547686341252,-21.012077963122792,-17.852819085803716,-74.31060426271712,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark63(43.13787395473378,-38.72084803874667,-30.78372578284791,-24.986418097706988,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark63(43.13794570673332,-23.998621000976186,51.9488163519502,-78.0026259408254,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark63(43.15884435005063,-2.745114044820099,11.252606070804319,-43.22727563616993,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark63(43.167127429657995,-34.0073298472695,-82.98293243875321,-79.57159105900863,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark63(43.21366578089339,-35.1116804086041,86.67030791166869,-24.030073336780305,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark63(43.21842741059595,-32.545902307621304,-20.28100218322453,-82.96252959747557,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark63(43.23862581850295,-30.160744547572605,-57.386349730266,-48.33509571904,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark63(43.25052690002323,-26.065157900865273,-43.07847613851641,-94.38555452669411,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark63(43.26179530972303,-7.87937743568861,-44.8029773232294,-58.78982485713928,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark63(43.30122366367476,-1.1888299551263657,3.584707602962638,-25.142290567968544,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark63(43.470766246225935,-16.75269691324806,-84.93014387864352,-14.75087341265835,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark63(43.496081558082864,-36.319281923688074,-64.67791725953929,-41.97447855176431,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark63(43.51061041412515,-30.71331055429114,-28.740593541261546,-82.05810013150926,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark63(43.51605603418574,-12.037301814792414,20.562325891780603,-10.498086542234674,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark63(43.5660587135597,-9.661862539225538,24.40789172180456,-24.893601142431137,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark63(43.56816294695986,-45.43994748850404,8.31325733776768,-1.490338448806611,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark63(43.588207214872256,-26.232560921911528,80.32353143594202,80.04184456173294,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark63(43.65547615119141,-39.48502252299156,-58.80098142243813,9.477706435031124,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark63(43.66348391507532,-12.967207335193052,92.98876893964879,47.468403903124624,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark63(43.674036146756976,-36.1720914467264,83.60106439551043,61.34185086368146,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark63(43.706639463699474,-13.612890145572635,-73.51433638300331,-64.42001326245904,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark63(43.8021934488319,-43.84657133934417,-8.461703397818738,66.84502468256738,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark63(43.81072553381665,-17.4004245203933,84.16151608431875,-20.40180114558821,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark63(43.85258892784404,-42.02121759703687,49.7582577139147,-35.954423512069255,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark63(43.85957226160323,-23.605591977069352,-84.0534929513384,56.86194411331874,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark63(43.870919225447324,-11.7616936614356,-52.65316703931897,94.76165435659905,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark63(43.88638632534207,-15.21087932550725,96.4272210426104,-29.552951292930047,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark63(43.89764102467743,-39.23842801783126,13.709728090295272,-3.084147405973738,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark63(43.910596905052756,-12.79648912386871,76.26331500323238,-84.05071147851734,0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark63(43.92803139629672,-34.25245235562227,57.92294319580148,-3.7953271065082532,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark63(43.97186520877136,-22.19975936202458,-10.601519283477543,53.375810584128374,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark63(44.04786636082903,-17.91068358032031,-68.25912132729421,-24.20429328713641,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark63(44.075103503798545,-22.14007910185458,-93.41923368665934,-86.89031605203508,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark63(44.075931682754685,-39.70075794434851,-36.14736566371475,57.74760959217497,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark63(44.08925766894873,-32.889242783969934,-98.09440439330905,-87.01324960288215,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark63(44.09633549817835,-28.02484368814521,56.89585326832537,17.16469616608613,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark63(44.1052244900134,-37.38480628961924,4.728511934359105,-50.444715573508134,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark63(44.11092352778513,-39.722653032837485,-36.62638026577718,29.65450995374698,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark63(44.211278460358386,-13.609477745227181,57.96824985623016,83.39646175902985,0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark63(44.2696319741834,-31.90866600336342,94.57948511325134,-48.643446226133435,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark63(44.28287884616938,-4.842519573486854,79.4946114847526,-95.01844968428823,0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark63(4.429327335949367,-1.4534602749168357,58.796426675001044,-95.32243323812281,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark63(44.29696187859295,-25.47781734166115,86.51252793830088,-86.22401058305388,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark63(44.305967951111484,-41.5979355291376,66.25960335370246,-53.30765314271715,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark63(44.3261265260827,-6.223991977416304,-17.111486286583144,-59.68938000545867,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark63(44.40308751098806,-23.371141979770954,63.29053732563432,-74.66442007783903,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark63(44.47586450365526,-9.715895080595402,71.62224212793154,36.2415197237724,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark63(44.49624337784951,-36.74205230841401,65.25850509007313,87.28695351733592,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark63(44.50780818806737,-27.466421022155714,-25.520341661685734,-99.75831124297356,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark63(44.55229016772296,-35.603080007454096,42.204984778484175,55.43252616044839,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark63(44.554672012854724,-33.7490668470074,68.32811601440079,24.38156714149349,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark63(44.607773514168,-11.602291650171125,93.52687072717902,-30.776021182087092,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark63(44.646017149917185,-35.53654083767938,78.77657577604563,-21.25605835600996,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark63(44.6777055814232,-13.955492718675686,28.919187676077115,53.365831881732646,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark63(44.68639425836403,-42.26537934974175,-19.594686883851466,-58.3894092077897,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark63(44.70520528610095,-39.83758107238102,-61.64756058142231,77.40212373624368,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark63(44.71393038900251,-71.64262601275865,59.89637086727316,-1.182379342800857,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark63(44.73321040072938,-19.443452936014523,49.583388341648856,-44.50011756785355,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark63(44.74103748955983,-13.887400678203662,61.599831710274714,69.28376622996217,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark63(44.76412738296409,-15.185027987593685,-53.00808788418851,-4.320081847279852,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark63(44.84292519147769,-18.12488690134579,-90.37058969770007,-87.81618186370139,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark63(44.8625791132134,-19.53606276951767,-4.014886018400404,48.362093547513695,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark63(44.87943782853392,-48.369145465524795,-61.70661025635218,12.527409525073892,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark63(44.893843793403306,-47.37578412698349,49.22623560479093,-1.7987855695569266,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark63(44.97822520394351,-40.47563092267299,11.092308256164628,35.0610502546738,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark63(45.14336326309987,-22.904766183043023,5.118965512648899,11.328070069531805,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark63(45.15462204896818,-8.75317535086269,26.984934797660685,82.93132850758153,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark63(45.20201267792274,-29.31424879944248,-39.7506006453844,-21.425878561051007,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark63(45.24442710644041,-18.77136057526944,98.33543911169386,-83.95875678119253,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark63(45.315013754135265,-29.116014065087683,35.75580593202204,-31.699151841793835,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark63(45.326865814153024,-42.33883265775622,34.7586518282823,22.643711936933357,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark63(45.39143143792569,-43.22229776340698,-10.771633371200778,-18.08807533391507,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark63(45.40737013709716,-17.853231838597523,-7.244007913622539,11.99228800816499,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark63(45.4173517950648,-26.00579968326096,9.835019282147542,97.77219772250203,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark63(45.427175283180645,-0.6995674259075315,69.54354497547405,-42.07005694602424,0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark63(45.47735905111574,-31.82503450040211,39.79830379055599,-83.02791002007427,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark63(45.47911472576857,-27.692089604614694,70.10544476397968,-96.25225915817089,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark63(45.55019445615147,-16.055129386702262,-24.265824885361667,93.21967478469674,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark63(45.578039772294034,-13.33690524791949,-7.130822023781164,75.32538435461817,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark63(45.662751748006485,-28.966740106862304,13.488964838814013,-94.88543170773194,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark63(45.701906115481336,-29.610710120530584,54.80432127271433,-77.49558934625207,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark63(45.71929654874711,-20.654191515823968,-65.89619813331156,41.32236152173019,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark63(45.77158235463128,-22.12342405156238,-33.37578591479908,-62.633292263127615,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark63(45.809158101647085,-8.931406321895238,-2.9742734286352572,-78.96448110202672,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark63(45.82005655889424,-19.57588978238209,43.27507867999972,49.41335198204544,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark63(45.82341048769956,-44.43079353420665,83.02106128144376,-44.10536832453289,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark63(45.84170230456158,-10.378056261193947,5.296129711316539,26.979700077151975,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark63(45.86135290360565,-14.894126023778568,-79.22732539198279,-22.69649288907803,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark63(45.89700485619227,-27.084944017678254,83.79258276812308,60.88941451318297,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark63(46.04901403348623,-41.819543860169105,40.63892744516767,-18.002517917528422,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark63(46.08416103353156,-32.020182116257345,9.670934426463205,15.079732417622793,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark63(46.212280026255826,-35.25422691439513,53.316595462391376,46.715808752881514,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark63(46.23820604649501,-16.010754228196404,-15.73247789915851,-99.236390095393,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark63(46.413057920664755,-15.33546946243176,-70.33101448128687,-57.7367742253577,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark63(46.452036749898525,-17.389066419290472,-53.268782676679024,49.18229312953463,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark63(46.45306887185174,-16.86945123846624,86.21965173856125,56.78652047917049,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark63(46.46436507335119,-25.380485160625923,-79.668368135195,-61.71912963126327,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark63(46.47282388946505,-41.43835721967295,48.67284038384784,-97.94690059641304,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark63(46.47296122317235,-36.27233277975661,-7.273656726370078,58.04974144464251,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark63(46.49361967303,-29.985507106982197,19.22403099419705,11.676641113091549,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark63(46.50156136483264,-23.398074289259284,-67.27157499917331,-44.32791704925161,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark63(46.58155560649112,-10.893598163242686,21.104987384246996,-78.3065807554302,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark63(46.66797439576334,-40.55421244616733,-87.37380522802434,62.3548031163306,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark63(46.68568373075257,-24.337456518487485,10.073737261220856,-99.6486285623165,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark63(46.82802513989952,-42.90890540258327,31.95456202654131,-55.3495136894248,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark63(46.892990056368234,-36.69435775584908,-14.923696327023265,75.64587160316069,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark63(46.95263491148293,-69.9162426488132,45.22991897570364,-1.3740762457149742,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark63(46.96049306554565,-9.047864770145765,37.803573244347376,-30.506778696695733,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark63(46.97876934205863,-15.580972005949192,20.126943847019035,22.254570562307265,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark63(46.995012180034536,-1.310607059306946,-4.733559130076188,-97.99561373968713,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark63(47.03436722735972,-24.15418666942972,-22.751752460637647,14.09839882068897,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark63(47.10480961098364,-50.34213317253533,-70.79574454486166,15.836039813977294,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark63(47.106037522790956,-48.05585087233568,88.90474784635944,-52.77308032876435,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark63(47.1241536717518,-38.6431930412348,-88.12329627391739,-65.82378580016345,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark63(47.166413913420115,-14.742793075637948,23.044765428928528,2.808887236398249,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark63(47.2047598429389,-6.240670818600208,-23.619161260500874,-90.54698784621083,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark63(47.20530910977391,-21.737352408338367,-70.01961678246329,18.93429724079367,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark63(47.21055578776,-3.0949517581062764,27.771886433596137,30.735325866895437,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark63(47.243850647052426,-37.17338573890932,-65.35134625178698,-62.676783823855956,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark63(47.24724156976845,-32.00844255684356,-9.967633065227076,13.341605790710886,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark63(47.32134510677005,-49.06238353200558,92.21701849311393,-19.91001946872059,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark63(47.38140651304508,-31.345137400392147,-88.45965957909362,-94.24774434184495,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark63(47.4096418202285,-14.786317761515377,2.164054611863179,-84.73841130281872,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark63(47.419062221862134,-3.6516801744659944,41.821676137833975,-61.00421940249132,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark63(47.44335288947619,-47.96965492959122,-41.30165988233423,24.22285710846414,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark63(47.48029330221027,-42.66342591986447,-79.74401822315795,80.97644237343258,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark63(47.4839831681565,-19.110484707185776,-91.12848704124616,22.61210235831652,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark63(47.48622214461926,-28.188450530663786,15.361872556121142,-40.451320921126154,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark63(47.4873888802841,-38.779764931354954,72.52512659453984,34.91685076165999,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark63(47.52886938075841,-30.174083567027154,30.83729515395811,-32.526410836474696,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark63(47.54540558679054,-19.284830629502466,6.552822619541374,49.17025458796567,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark63(47.54646426814662,-12.92795980753074,-4.028528962232116,21.28406218277341,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark63(47.55046437522827,-30.627910999895988,34.177962762001926,-46.45550280889032,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark63(47.563599509184826,-46.67985921716959,-8.38661922221955,24.970219646794533,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark63(47.56393786744138,-26.770737292056964,31.88302440084223,6.960193531022,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark63(47.589196221986754,-42.74720269615187,-14.2602609651492,48.11648806843573,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark63(47.64280192490804,-15.024020556370019,-83.70349670906558,60.744930629560145,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark63(47.64562553224292,-10.230819794530731,59.23088146287398,-21.025538619223113,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark63(47.658609620002125,-44.58882634910959,10.058226866032243,10.109412409521767,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark63(47.66005118595422,-18.5644880486541,44.14679278744978,-78.28987325174077,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark63(47.67918864393755,-17.556360891363497,27.04177256932641,-69.24671272429688,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark63(47.727772487859056,-42.08923490082095,-10.692917870439132,70.19394609649524,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark63(47.75278748693387,-31.549924609264153,72.39802796368744,99.18339499236447,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark63(47.7800818391153,-20.841036794601607,44.79725772952594,19.403448595826347,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark63(47.82306973517487,-14.777558118561558,-97.17802794429767,-66.76691930268831,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark63(47.84593422154509,-37.24619972487424,-79.87779208935672,-61.09494753971298,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark63(47.92747504027929,-7.734145817024981,-45.62412961501274,34.42847167506892,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark63(47.990470867503205,-16.304936216828892,-37.06808043011598,-75.29228178091118,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark63(47.99649509786903,-24.837807689980536,-8.408221234561069,-6.729515585764446,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark63(48.01498080950245,-13.671849737427408,-14.775923195388785,-99.16723763303344,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark63(48.017816104838914,-2.1580481465165064,64.41631884507873,7.672605672713544,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark63(48.07517244995239,-46.232950350765066,46.72114280437418,72.32317876273186,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark63(48.07954723096174,-8.274971070098317,94.53154449626925,20.00308508324939,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark63(48.10856113845114,-42.5719592486683,90.14617152512986,-0.45235579972195694,0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark63(48.13368358616253,-44.75980350397841,-66.53319489407025,-85.44461590958858,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark63(48.156603703514236,-9.17708827683768,-50.41598092962849,-61.69910763502769,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark63(48.1621453497863,-22.210014958265916,-14.722597492531648,55.91089141338031,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark63(48.17389949905552,-19.496053495006223,-77.02085541568566,-54.88238236033438,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark63(48.183943471743675,-26.812239309885058,69.35300282252831,-31.04909594944614,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark63(48.185163938716755,-37.25255034743078,-13.563960989088812,-12.261157817371497,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark63(48.189380925284894,-10.560864798510465,-34.65762904366265,-89.6716769095928,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark63(48.23662334969589,-7.795286979573746,35.31825164512287,86.31634802771103,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark63(48.254347847637035,-35.09964033687096,-12.44030518790997,1.4395249370074055,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark63(48.294831335418905,-17.44905459604105,-95.55921100200486,-86.09522591907512,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark63(48.32021355097743,-46.93838703419439,38.0384752211275,-74.17163060519643,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark63(48.344070607723324,-20.444117534586994,95.15183368552692,90.81231617740232,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark63(48.35548674759437,-41.75051569854536,-36.3746410543635,1.1569194594173808,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark63(48.47890942740935,-44.02307110931356,-16.197919029533153,94.33560349980732,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark63(48.52260332910089,-24.092977428752533,-48.496678800011004,84.58700513329157,0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark63(48.53397042685933,-37.82513215583621,70.15197638906196,-95.79480028387559,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark63(48.542112910125724,-34.92938599108304,-19.713092941564398,-8.238989614267638,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark63(48.547043514426974,-16.56922695402079,-45.93759008600698,17.30182274288059,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark63(48.554477953571535,-26.958578685630542,-28.474446217175412,70.92299930523563,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark63(48.564076791649796,-0.40894270323519777,54.579474740248855,39.187398011223536,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark63(48.62669780945282,-46.05899411817791,40.02741027850709,44.03374978482998,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark63(48.642600212398804,-39.70057337383197,1.285701971215218,-83.8134698509373,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark63(48.67315575786586,-48.228384480092565,-47.038824095802866,23.516398646339255,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark63(48.70825896455244,-44.47191751948185,28.32277036660375,-94.26561919577152,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark63(48.719224223577015,-45.66683367563533,77.7279562632011,96.54578282884026,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark63(48.72009567961854,-5.1975783185307165,21.595695469913508,-7.661976771886046,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark63(48.76345748786147,-22.92510069134299,33.239409794500574,-66.66857018716541,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark63(48.763579244334124,-26.1563863908558,-43.130713620885516,16.18433181076537,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark63(48.76571197747123,-3.441529622330492,98.86452516525296,8.735784353263028,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark63(48.76819813030505,-17.98953840393125,95.60302286662824,65.67574652422786,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark63(48.80708363985667,-23.91418946738311,-97.71481639507684,-30.235877802329895,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark63(48.88229346936325,-26.693031003396086,76.0863441307383,10.225174605889322,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark63(48.9408446849547,-0.9497480427325371,25.6875047277656,39.44353374294323,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark63(49.00393005732366,-33.482769590941245,68.88586230253517,27.032446371825486,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark63(49.01193759076722,-23.243318136107987,-0.13965782520683945,-2.000073226908981,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark63(49.02090190924662,-9.184871810948849,4.080184532402825,-11.788771210019334,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark63(49.0341096433628,-46.668953635958424,-2.937111805287145,1.1906163028042585,0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark63(49.08417577187112,-9.029231151466249,-59.48987295498198,84.04121450853452,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark63(49.15114071373665,-48.61021285457123,31.47385633679974,61.913795755406056,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark63(49.23084624798844,-32.32770990054685,31.699200999996094,-96.15296039231734,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark63(4.924600405867707,-9.667698013387252,95.05254628376781,-3.25244912907759,0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark63(49.32832297633723,-34.93072428708592,7.570670894202223,-43.68133979449284,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark63(49.37135745637764,-27.374012102713266,78.76145679824484,-21.040439685807243,0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark63(49.401661228826555,-15.004666392564928,-43.48048455213394,12.416888240068374,0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark63(49.407021226468004,-4.912873660006497,-19.15701187229115,-98.80671003102866,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark63(49.43356857353197,-44.330292999911336,-32.60615035441543,1.9211447607786027,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark63(49.45341773558121,-42.20495976068859,0.7981981146406838,21.462224137059096,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark63(49.4602173850499,-45.569183633894724,60.07128147710347,98.3450789750834,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark63(49.48794693574345,-31.418412178431026,87.44376971188527,56.19759290999514,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark63(49.52509115314038,-0.6301550086213297,25.03883660468142,52.54322311063794,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark63(49.58710234142316,-39.06483786348907,59.48163897936726,-54.21285088004461,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark63(49.58958073977939,-40.805948962457904,-5.083494663475975,-48.937312459330975,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark63(49.5942561655082,-36.1281344387306,19.99627843542848,6.749272896205355,0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark63(49.6432174229094,-22.118094239340607,8.070976927687212,-44.72121160173963,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark63(49.65952099359674,-44.72326248528462,-40.47521311094733,-28.442180735826625,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark63(49.74038783257632,-46.104922590921895,-4.5339058560968795,-38.843777725227554,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark63(49.78056111019541,-45.251735028602624,-75.0116683114951,98.1346699167249,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark63(49.78470024916777,-73.98351429566495,96.20061597454293,-3.2840689555652176,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark63(49.81648727074946,-52.423977430918825,45.04910069004987,-16.11618078970298,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark63(49.90431209247441,-18.756565429553262,-25.051903391035665,-23.830889927499427,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark63(49.90724391604468,-18.88468643898274,-39.59426105888944,85.79725626296909,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark63(49.919070959787376,-19.666821260339447,59.83562084620547,-83.65057965645431,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark63(49.956443703784856,-39.55487648641443,29.72171310005359,-67.39288304050316,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark63(49.97827885760674,-26.480684206708816,66.02426472251511,76.50504576301702,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark63(50.032188981577065,-24.625895049998547,-17.15211446671219,53.577838223302535,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark63(50.03401099601655,-32.50461207991408,34.92691504557479,-42.32397871809701,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark63(50.092049830665786,-7.402337269679535,87.34237728872293,-85.27130459374554,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark63(50.1139235300393,-7.707138831072996,29.66592385909999,5.6779716143406915,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark63(50.11918247405478,-11.936800774266914,-62.61911735214083,38.996152144148795,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark63(50.1227093898238,-20.533222712416645,19.641786540758474,49.784662282815816,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark63(50.126593721760344,-23.350541185974123,64.68467357126764,32.59578322154306,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark63(50.13168333105992,-43.10124499924051,51.01912179856208,28.205935691784333,0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark63(50.13240912371273,-44.48553920584204,-21.75025717118804,-91.32524732155296,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark63(50.2084933191895,-11.831821288139551,-10.911585511686013,-86.63177378939366,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark63(50.20929487467379,-22.08494130199192,25.817882773847117,80.43725167173784,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark63(50.23315911414477,-25.338450252847494,31.03806563893764,74.70100557925315,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark63(50.23805206840569,-3.671554532031493,8.121070688173916,40.08857326813043,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark63(50.29675461475668,-9.33730539239454,18.732822125392914,-36.990395115072985,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark63(50.30812432852494,-32.1465483644062,40.84125954292125,42.85160802495835,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark63(50.320826281307575,-47.07303515411081,-16.236707388993295,22.224298377160267,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark63(50.32190104421335,-27.153060553096935,-15.17138249024137,-42.83712494421006,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark63(50.57100528448214,-34.56988831478438,-26.114664890444473,-91.99372300354945,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark63(50.668105815141075,-23.382010685636786,72.07004960499123,98.0235800778959,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark63(50.68225421403358,-41.76635312339212,89.32117992500542,89.08632020334534,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark63(50.68828856923503,-13.824591630590703,88.94932351787605,85.33791890343866,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark63(5.071710247857354,-0.6091724834094805,71.44783029490688,24.943206817764946,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark63(50.760357745568484,-18.384524416270054,60.41088490904528,85.53940790757088,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark63(50.81720370984405,-11.03200342771558,11.549951379544908,74.5606778472036,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark63(50.82132804015498,-39.25526725858337,56.395702237596254,-72.39565691232819,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark63(50.857583920081424,-20.029602297890705,-82.20776851682314,2.305941167106738,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark63(50.876579522990795,-35.15149440365073,-0.7635121642832701,71.83139548831343,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark63(50.89057310366934,-36.20099237211563,-32.76985898340823,-61.15969466347264,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark63(50.91622757925796,-36.853293629639914,50.00072002801167,75.31254932268803,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark63(51.0187057864666,-43.21262452979677,72.21203589163261,-68.4038145084578,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark63(51.037106296773146,-44.96337369192691,-1.2917372524919841,27.586253244128713,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark63(51.050683465666566,-23.478897443690855,-23.059851777222235,-53.744507321115464,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark63(51.118054991833105,-30.629920155456645,-6.828257045290442,33.00666973887911,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark63(51.12395526351949,-21.27691839860759,46.88531630775557,-23.771307641905423,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark63(51.13733896457424,-5.819563652237349,-38.04513938635266,-54.32090141459871,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark63(51.189658953741116,-31.795374717144753,99.25483407098955,97.40287412923735,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark63(51.23681059137675,-24.05554485186437,58.4123201894904,24.961918853630436,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark63(51.288596221888696,-6.468188013605385,-11.745570069624932,-22.171819714983727,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark63(51.31816147916635,-28.54703743280666,-62.6078126149167,16.509866559430947,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark63(51.44063078302625,-32.148620546407074,-86.38804401082186,48.08943767643092,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark63(51.472341886910755,-49.17899940748573,91.5150165146346,50.10033300420639,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark63(51.51864362757752,-13.860801974072999,-54.61763328955813,-74.58637583903551,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark63(51.53113082794894,-9.650486045676772,-63.67366226379805,13.122394810011656,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark63(51.557171798768906,-35.79132509748848,51.86903186620765,8.206491640792763,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark63(51.56856534168804,-41.317767899590606,-79.12906998631514,50.95157506191518,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark63(51.63399929424182,-41.055340035107065,95.28994506593753,-41.0071979146426,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark63(51.65615118201805,-31.92802744269774,51.14994831114902,-83.08520475989592,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark63(51.73070973467381,-7.915534958440546,75.11892601399151,-35.813830428867476,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark63(51.77718426736641,-46.29417272718628,61.148342620225606,75.12203506612329,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark63(51.796622406768336,-29.38655444239744,-36.106012632451964,-53.074670153150684,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark63(51.82216404097028,-11.402566896013894,99.31876436772444,55.47031257544441,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark63(51.83518957313703,-37.57364722094647,-16.652375981294682,81.37247591592879,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark63(51.84099352904144,-51.18873289539994,93.31976173230464,-31.36742428815606,0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark63(51.854681596679285,-26.59182492011712,-35.34406431310535,78.39103673878884,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark63(51.87331861874242,-47.17658975763583,-4.267058317712568,62.237812944025904,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark63(51.9138280616844,-48.189839140394696,74.33765980178367,-43.53517862148257,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark63(51.93634764330233,-20.598381917438772,-30.98017271454563,-32.086874102776136,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark63(51.94359068734616,-17.164042839885823,99.2190047070066,-18.717316692997272,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark63(51.951776904890835,-46.89868651794147,-41.86388178124601,93.94551679127034,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark63(52.05240967788953,-40.80934219996202,13.445287137246169,99.41010467008826,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark63(52.06391859094674,-38.71960221219191,67.4282714446172,13.667666652734738,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark63(52.07688082759091,-48.95863694916578,74.43654375593215,52.036532777458035,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark63(52.087594706687526,-19.789302941724316,-15.562218117183662,-3.7794556103548587,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark63(52.12867851811316,-22.064930186082037,-93.06368662795637,-45.299331034499524,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark63(52.15082606658177,-22.002997990219768,58.93484353809151,33.97876484557301,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark63(52.25814561963864,-9.556898209653326,-1.3024477144374202,25.408675438201797,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark63(52.288410821086615,-45.75645024708444,-19.110399874630076,41.23873685245789,0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark63(52.28934443468188,-27.61321652034114,-15.525636280644846,0.5183430669774509,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark63(52.31021024056247,-24.4766598921983,-19.999993711320172,67.68241360065247,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark63(52.406246590449086,-8.76733869109654,34.01683941183978,-75.26629030603891,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark63(52.42550845411034,-30.36377318306873,84.45515313088546,-49.53511682554228,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark63(52.46262015427163,-45.145258713777366,93.79174872546773,-37.4121536263192,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark63(52.46804275152999,-19.321641097035936,40.27817205050118,16.808950922113496,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark63(52.47646157479571,-1.273283012062464,30.282213447624997,-74.5316601025638,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark63(52.487279662586815,-51.35225669842918,-79.99244060226458,65.0508836322974,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark63(52.50848887185856,-15.30016513069559,-84.79669794592108,86.85055026799756,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark63(52.5536942475332,-2.6073052922323257,37.04757669186483,62.59499620667759,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark63(52.55827811427639,-8.477412175229531,26.5446913593522,-11.521604242178498,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark63(52.56805505835521,-6.150466571473402,72.59858660878356,-2.917526409981747,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark63(52.626712523994456,-2.721443519755624,42.23892390505168,-44.79641109965486,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark63(52.64123131314756,-46.462649759979804,63.043815227672184,-11.875619800837868,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark63(52.71387170941901,-26.603022495516626,-48.46046238290096,82.92709826736026,0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark63(52.76597551867735,-12.825101924036247,-29.69198082603326,9.65612245825227,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark63(52.82509319683575,-47.44616183894168,39.428684732321784,63.329614988411095,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark63(52.83824020350332,-30.922061723440436,1.460950986620844,-15.188402719968707,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark63(52.86797127757336,-6.460813788200355,65.0446743222019,28.018234211253088,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark63(52.884273397395134,-29.406361548729038,26.13043256387668,13.176255867889978,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark63(52.885450514138256,-4.580690511353083,61.3188998637747,78.05696882012037,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark63(52.887090990817654,-36.75302923629109,28.044258881854518,9.467622344334131,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark63(52.89132821601058,-10.295975186731468,-45.67147574987611,9.413704192206012,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark63(52.92820490703903,-10.47773666153229,-56.53957934133391,-21.551092047781808,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark63(52.92848088049976,-48.18928884709799,-56.17331966414676,-36.44139623950877,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark63(52.93890266780599,-41.8758332020982,60.52397309141975,-93.27554825660154,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark63(52.94836230099156,-37.88312248691281,-93.14912889255412,5.662165685572688,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark63(52.952962917251256,-0.15155997548343692,31.922391752639726,33.342846015326046,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark63(52.96262674783131,-26.257943357947397,32.03824839901591,93.80484514829047,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark63(52.9849957526132,-14.71563723312255,-42.24368077561744,55.3523046026902,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark63(53.00631012846671,-26.66583422699766,-68.21871709117067,10.712119479059751,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark63(53.01614224860478,-24.665560181335366,-23.258592188687757,94.5727491461881,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark63(53.03527122491545,-47.740388431786315,74.49321273285895,-86.34140179165301,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark63(53.071708168664884,-48.24824275741555,-25.822787839933923,-65.88745764524076,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark63(53.10128282373154,-12.936271582174541,-50.11215473864925,-3.6718993313327246,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark63(53.12248109941629,-21.995665327442765,93.97150264195909,9.099253108953405,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark63(53.124456265607506,-1.3562140715862654,58.1319295767436,70.4746412792849,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark63(53.18340630375366,-41.98926606954625,31.51701946874016,-53.85957096731451,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark63(53.24734195645743,-24.646018658209982,8.836502707494915,12.848324181101802,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark63(53.25438809456935,-20.49271555421373,-64.50811734828736,-54.4925513088173,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark63(53.2776812361262,-37.90796405536911,-12.06177636398364,-5.505246820357158,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark63(53.30693825628376,-23.773971832425445,97.78373876436251,-47.93708278930413,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark63(53.35760275680917,-12.608942886684332,77.5356097476946,3.743078828695687,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark63(53.38760940819921,-45.90825323898579,-36.65024666564187,71.58291334372515,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark63(53.388424844441005,-21.530366149920027,35.79257415683742,4.3877912641455055,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark63(53.40749061764626,-54.84395098698896,-44.584351233456566,11.104971998227171,0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark63(53.46201260556242,-26.42650246358795,-36.545317369393814,57.44949974551767,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark63(53.4637835193775,-5.699360427825155,97.31539351571644,64.55546011875845,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark63(53.497730229508534,-45.44627890594939,-61.5480270572992,-29.60657911472269,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark63(53.51840940558316,-51.50765827857378,12.78758242066587,-11.527223589778828,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark63(53.565797216142016,-31.912475005110522,86.38673569163387,65.56628563983742,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark63(53.570061475714596,-8.104630305389037,16.913794704413192,67.89163513964041,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark63(53.580367700463825,-39.604253723246586,-38.61763894841448,37.0621172987006,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark63(53.60034433491313,-33.12044225301034,-26.253591184712448,79.85208704340826,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark63(53.616620176365956,-4.117097169183253,37.31645080954041,43.489590001657916,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark63(53.618910275789204,-24.28003455259551,77.00215625089538,-59.37098548496236,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark63(53.64679800001943,-49.47762022012843,45.6425775760803,-28.30382735865544,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark63(53.70375303769208,-51.26372596325588,-83.71068231214616,-93.8409817719633,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark63(53.78133563479332,-50.01156226595989,34.583655822060734,71.6020508812984,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark63(53.820319792068204,-20.58299701645862,50.44853239565015,70.87278232707283,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark63(53.8218986664954,-12.125206264372324,51.177934885736306,95.43084397575467,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark63(53.834122196167954,-32.78742694521651,31.908866693651532,-93.90228477583607,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark63(53.89377440424096,-39.58834071352744,-22.610499301202907,85.73024521932908,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark63(53.94714085493729,-38.03801313640094,-84.60603103769888,29.120991108733307,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark63(54.02956400173025,-41.89580596367652,-44.537309542876514,-24.511310883717826,0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark63(54.04233572590866,-7.568934902145813,-40.04346634366176,88.84925812961038,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark63(54.07021472378858,-13.135675936290653,42.160901964092204,-20.954115802223555,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark63(54.07712625101922,-33.361829150443526,85.33739087858811,77.72551621945937,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark63(54.08159415997426,-10.288754791394012,21.66476321086408,-73.19146948504792,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark63(54.129558016907254,-31.966449070287382,-71.2510025823706,82.84514676780921,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark63(54.13621983438733,-47.93457875549445,37.45176688175599,-58.920786361857736,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark63(54.13659957061873,-27.008254497871874,19.049105736014212,-64.9620222071459,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark63(54.16798526982731,-44.35146334382418,-22.561400572786283,17.595752338684647,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark63(54.21219736087386,-24.837858144390808,-76.22890289082476,-16.565116356523603,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark63(54.23803106002117,-1.0336385325692419,75.26240075131659,41.10478496922104,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark63(54.25647927930953,-4.0555910418351715,76.32870010278842,-42.26339396846159,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark63(54.279034850711355,-15.533650838946869,71.3762457779724,-53.786579715952264,0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark63(54.28181255268885,-4.225539243450143,17.857407607517843,83.4553626190517,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark63(54.29119483374021,-0.8422942688076915,51.6420858192551,51.792336464604205,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark63(54.33731844352775,-11.066241208878097,38.874213788378086,-93.23722647843687,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark63(54.34422731222125,-14.94464849508222,-55.51373156227368,50.09397655407605,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark63(54.373899965085315,-19.48223801079503,-87.76612358680794,-30.380926325548614,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark63(54.41635730849384,-42.71411654026562,-72.14631523183606,-28.025821927073096,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark63(54.41797165536752,-29.25229756651136,30.965284359398538,-29.38823967675603,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark63(5.4462430387530105,-5.03232389267329,33.66083374628812,-39.51527101049032,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark63(54.48734965219094,-37.974494367724,-35.21401114196992,-56.665119779372496,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark63(54.52166060657393,-8.469877138734418,50.72683189474935,95.69082609096708,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark63(54.534217501250794,-6.826193854199758,32.26257851629833,99.84344567981722,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark63(54.53485606277275,-31.03015854969138,58.859299105362794,-1.2185130010501979,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark63(54.54628590829125,-49.98384354220005,29.66324476071466,-1.9846574841888298,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark63(54.55951253682608,-37.24740412538146,-23.299077101858387,-58.849165740118316,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark63(54.56646204454535,-38.83268794556554,23.325881915819124,-83.78514168266446,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark63(54.59889588254262,-33.37873438869987,-99.45193675002035,16.973699403554306,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark63(54.61214757072554,-33.50782670470966,-3.23552779993814,81.87664495128453,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark63(54.61264201931297,-53.87553530190179,-99.94867687030806,20.479388347426195,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark63(54.62613286790568,-38.163134285068566,-46.0825861078918,-24.535321831626746,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark63(54.65071489957799,-38.790262390163896,-98.82865674370981,31.51291569996505,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark63(54.69271764872772,-45.06650689551448,48.257051069248945,67.08955351358051,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark63(54.70150237285577,-3.5259573700612066,23.655821396362825,-6.594741627822941,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark63(54.73862595919144,-32.87754111148149,-8.476561655975772,73.95530715083541,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark63(54.744838994663354,-55.82208954884751,-4.651924738607647,0.6607450593247819,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark63(54.80127239445537,-39.47791715589326,78.58602088918053,-43.03468204816543,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark63(54.81648243290539,-38.5692094710202,-86.43421403597253,-89.38143172852959,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark63(54.8256929959382,-20.152744079819044,-40.05366521104501,91.57435410845082,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark63(54.83102724900553,-33.49998878643261,-8.547986364582869,72.63834163768328,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark63(54.86621403497122,-49.77998065246809,66.59284151360922,81.37921635970238,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark63(54.983040045125904,-24.610409093132077,37.0193266482828,74.76944316457616,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark63(54.98681021807084,-31.30947555561822,-94.14254219387831,-33.788819678683296,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark63(55.076380444056355,-65.43988573049602,-77.42550118952043,2.042697577617389,0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark63(55.10785404928387,-7.953386101039811,12.151647592144016,0.6451291351981467,0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark63(55.128811225400455,-15.839097364679361,70.0903253894628,-58.504198705368715,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark63(55.20619984706644,-22.45246550098325,-19.476063558080398,35.66455601163125,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark63(55.20794557167815,-43.24379001398102,69.2494935742892,-38.66114930859226,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark63(55.25599953463757,-13.311766129980327,-41.152289603292694,-70.42712874997895,0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark63(55.265246219600726,-44.16835346741568,-94.29402214446918,-43.4506688701648,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark63(55.28573243770677,-39.84693293361063,27.464121908739173,-62.69247266420814,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark63(55.29501418628695,-24.68500058868584,-96.63059288010385,47.28558058763937,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark63(55.336847518466044,-36.8582612489397,91.66307636619524,-59.95087147221885,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark63(55.39472368388391,-43.84070674051148,-62.05429277932175,-19.319155124618987,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark63(55.46209557326273,-20.6905948328223,-50.481646107312,5.904278084089398,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark63(55.49590613751809,-54.12967246178049,9.828871493152391,-82.45735121432642,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark63(55.501847952759306,-18.63308123842519,46.8259194590228,86.37090958199619,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark63(55.504583192495716,-7.276055009359254,59.58178921798353,22.823911358119403,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark63(55.51000795480289,-25.233793153329543,53.732710255494396,-30.29935524958995,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark63(55.56220141670988,-10.118548294350148,-40.65338080049412,99.17861829320532,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark63(55.6394935723157,-22.535620230067906,-5.030380424049639,-41.234686523812144,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark63(55.67302928605386,-22.528795253259773,63.59499102274225,48.85891388142181,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark63(55.68252307623689,-45.342624754064985,14.251617134408704,45.58688696147388,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark63(55.68276790800351,-33.30997263806941,-93.9243226688593,-89.70676973215508,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark63(55.68530110078328,-10.482050361954663,35.35171772870285,-39.50054749705545,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark63(55.68673256679162,-22.595173224170168,-98.67796234294836,15.595675573049775,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark63(55.69273534026186,-55.494028646599006,92.8188754952983,-95.50677591659624,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark63(55.70086818453822,-31.876193989458883,-91.57123549422379,-24.787834305086648,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark63(55.70249301364376,-7.399805102030825,-52.39591331620337,-27.23209906346304,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark63(55.77895709393107,-53.26033387387743,-2.1817881667517867,40.095586151765815,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark63(55.89496070963946,-37.73531715551215,-31.35978193574489,88.78117802784601,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark63(55.92799152754628,-55.30853275331149,31.249501199373952,96.41799884426348,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark63(55.97268497166792,-52.64879793412109,-36.81947823668843,-16.670357644999385,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark63(55.98256453684442,-38.96813642783874,41.6416918767041,99.91578144191982,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark63(56.0180669496647,-41.30714033287863,42.96654948832057,44.21592934328663,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark63(56.068730144287514,-17.43087138998027,29.520299796600824,-57.55451214372604,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark63(56.14376273794383,-13.557772773964729,6.970960741300473,-51.09993061803577,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark63(56.16323903037613,-29.74216313429227,-87.91225743490489,95.11460780441382,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark63(56.19036811911056,-37.2849480271833,-86.01222107052438,-69.36932595046754,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark63(56.193704886460495,-12.089152330392523,-50.66581043601139,-52.708940211964084,0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark63(56.255640850786364,-10.804375628560877,9.470012603324335,-42.26282508197785,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark63(56.271080472467816,-49.67161733232095,93.86330248556769,-8.2213854162664,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark63(56.27372845028634,-35.39046374035621,-42.817252977790844,51.91710239770387,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark63(56.28084565549659,-10.983385668727479,-44.271058201234624,87.12945883903905,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark63(56.30035462122797,-10.791819528806329,56.96822200880723,-82.9127048375745,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark63(56.30650210343137,-26.517259278759738,59.15525204582616,-61.15577548485503,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark63(56.308333483080474,-16.328222488001416,-3.138978853520797,9.564338166323495,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark63(56.344575034829234,-26.759970356750998,-51.351916901663806,-53.45904440738636,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark63(56.35041656585557,-25.546008010565984,-8.172610924928179,-29.140302930841628,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark63(56.400295445549176,-19.25815510744748,-81.37784835763532,62.72100018263359,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark63(56.40801007745634,-2.590846848566585,11.80584442820522,-44.62655032213463,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark63(56.51020212768995,-41.03471124029285,25.034260634384808,-38.131497394076334,0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark63(56.51617061780016,-35.406865852063746,-14.857805618615401,-85.22120128700838,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark63(56.52778630421665,-56.76457260934933,-61.31097726732926,59.40887009843411,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark63(56.56024311868549,-14.743722026339242,-23.075858639263117,34.38163480188015,0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark63(56.590831327451724,-16.181042308896764,-90.01236645540484,48.67634399642441,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark63(56.65414265061082,-67.62345170168462,-85.29993322375068,2.7735823146323213,0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark63(56.70104479437953,-57.42325662071068,75.96508591832335,-75.40949133027861,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark63(56.745734965474156,-34.63933902774477,-79.61230105724334,-75.63508774637747,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark63(56.76755365716531,-48.65820635964475,-29.79790385204288,-28.757917847209555,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark63(56.778635078460184,-56.769905396438446,53.86471219673899,-20.90703055387017,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark63(56.7921133436445,-27.601089401114052,-66.4242791487631,98.03620720557925,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark63(56.83746885209672,-11.746222869757887,-32.040590957593196,60.6315701773581,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark63(56.887799719491284,-42.56036491030506,87.0161701343952,-25.08784334072915,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark63(56.90575798808766,-0.38888194454997915,83.38015405461482,-61.005284333563466,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark63(56.90866628337028,-23.334268170394083,-62.554228833867874,56.11803283446497,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark63(56.95829891513176,-45.391805438511355,-92.01304471105107,-53.073873008620474,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark63(56.984394827661276,-14.983749121122415,44.7374920635944,-87.76692116321185,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark63(57.03561406829965,-26.710525314113738,80.72098558811774,69.28692921794158,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark63(57.05787359106705,-46.886053234543176,-81.17390578434666,-26.382392352292783,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark63(57.10388019468397,-50.968257081855725,-14.751795492576235,-52.16416477400927,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark63(57.153985038370564,-27.685423745964613,91.82900738820138,-96.92356268278604,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark63(57.16313136699728,-19.306782462504813,71.21646046896652,-56.035051263018175,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark63(57.16515857838559,-13.28532829588913,69.15822204556753,88.88578521200444,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark63(57.1662412690801,-47.787474772469764,-96.73156173152391,-16.350989153513666,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark63(57.22148155689257,-22.280480458234408,98.0099304145782,-76.77223517438871,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark63(57.247052845348065,-31.9544855452353,-6.406469533876873,72.91152292467726,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark63(57.28775164181491,-53.82595884544941,8.184385714997688,-63.35942812777666,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark63(5.733345579237792,7.643153541425107,86.34834717253347,-83.4881346723275,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark63(57.433056663527964,-51.611965603686684,-44.98728743892302,-11.177277753395586,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark63(57.457239252331675,-26.119797243105623,57.35653887782502,-19.58415851981077,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark63(57.46919817341268,-51.464944100794696,-53.12461124537025,-65.29769156341818,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark63(57.48149933460479,-36.7816939372388,-4.944804878982367,-98.4858674926818,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark63(57.50586967884979,-41.188360808608834,12.457251928060813,-3.4245816614354396,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark63(57.51575338365663,-13.192092755449607,55.13509268690336,-34.150901771489984,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark63(57.52505841744943,-26.335528979149615,27.23924347744824,-15.237345416018357,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark63(57.54915967378807,-24.16797328195753,97.06280527716854,-65.28426557784715,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark63(57.550858913581436,-52.24712058342356,73.24077851415038,28.98540057327341,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark63(57.55633237183312,-24.082169992434515,68.33727405079614,-71.31223692019637,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark63(57.64464116021628,-38.8084510709503,53.21753400409523,4.343155598321232,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark63(57.672597056326225,-46.12708402429506,-60.54199807944551,99.78144043055985,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark63(57.687563560091434,-44.73295042929224,-89.83713591130976,7.744041020578663,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark63(57.70255874088542,-38.460000842023945,-19.212578542596347,-68.02256365288197,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark63(57.71499650376603,-25.584000490615068,-91.65827012075474,-38.89012831422467,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark63(57.76461919093825,-58.408930652928426,95.75830463476993,-41.926360917507075,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark63(57.76677218568264,-42.54372954829007,-51.620707408632185,-82.9003454544409,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark63(57.7680490994841,-24.740262074604942,-71.23089710152769,-38.020512422028865,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark63(57.774954938330865,-34.13798081167086,-42.935856580787465,14.056753325989419,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark63(57.79134800229983,-30.36151417895077,-83.16343841524518,64.43409547208796,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark63(57.80303133532604,-20.523755579363453,98.9675801003784,33.20545983403903,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark63(57.83489677540615,-44.30071119918551,10.610983725693586,-21.71956342773376,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark63(57.83491728934408,-44.55102019415178,52.093340156949495,29.023400275744535,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark63(57.89557273603427,-10.470366599879014,54.40688814940174,-3.1757803384826104,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark63(57.95054545979559,-1.4864530931786533,32.65455026704686,-68.21022659264366,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark63(57.95348093291926,-39.62496931811768,-96.00469446827928,-86.75215839049679,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark63(57.968396054133024,-40.60862682903481,8.235665902280715,58.0063367003726,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark63(57.97373245514311,-57.57547242787528,13.196594414484395,-65.1675024096132,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark63(58.01776253264009,-31.569683692870697,-74.54563023652162,-82.84947491897461,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark63(58.04506527049705,-27.820250794353043,82.931181097344,33.70617667600797,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark63(58.05306663181037,-28.394816520468822,19.168624809077883,80.14597437363932,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark63(58.12262672672918,-16.90021078406683,40.428687417076105,45.61993857031035,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark63(58.204019203411974,-12.387360165542958,43.86756274972356,-88.38153645224742,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark63(58.20493599894351,-19.786586274742575,71.26599634970717,-51.84027025912232,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark63(58.27929772244747,-1.9656055200833862,62.2480311884093,-4.959437215351727,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark63(58.2910416207113,-37.299990490810345,-44.871018874164626,26.833788270423156,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark63(58.33236673110943,-46.97994658904064,-92.16713419822442,32.85663000665616,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark63(58.33512400879121,-27.6702142683056,-65.48330595696801,-59.67483098895856,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark63(58.34188715571736,-15.647093540776268,-53.80276234605104,90.62922415321253,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark63(58.34781128919491,-16.20017369370656,-20.53587278875908,-59.01187665240046,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark63(58.35151084041513,-7.704476937851894,21.310497143445133,-56.04220470401338,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark63(58.38059166165425,-21.086374872827633,79.74293809811408,38.122057416768456,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark63(58.387259122864236,-6.38585902460467,95.8424826172481,73.98556651072897,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark63(58.39126833367942,-56.975352754337024,82.18597129428971,-90.86639687143277,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark63(58.415660466849914,-46.423190875429896,-65.93235976327315,-18.514160608769473,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark63(58.41569511618158,-26.437279524970265,-79.341969125629,49.09402594351522,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark63(58.445371379926684,-9.023019650917632,-53.47543073707794,-57.26203561366261,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark63(58.46997944823838,-15.553992446161715,-22.95002593379654,4.048438897317524,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark63(58.483446942521056,-11.331546773079708,87.97340812893896,-77.60371087223601,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark63(58.50408679848195,-16.55904351000943,-11.865696998382319,59.21500107392595,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark63(58.5417830056694,-40.72419737913151,-78.34298829535717,-69.11382778067512,0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark63(58.579667808573674,-34.89183274993155,-39.365823253554666,-52.41487545118484,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark63(58.614048100713916,-33.43092080376691,38.46084324475066,20.38627762336354,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark63(58.61531014037004,-10.294507464220473,-22.628443084414343,6.406827064429649,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark63(58.61850947789051,-38.432127302767036,-64.23409536829712,56.644856789552534,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark63(58.619613763614296,-41.20937981078623,94.77905030056425,55.16143741749687,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark63(58.66415828763749,-48.628860608308045,91.63513129463453,38.50078275611858,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark63(58.71162385522405,-57.59321003823388,-11.322453937172682,60.439850004641016,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark63(58.71933990421692,-56.57155161564167,29.0181761397302,83.77278251307337,0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark63(58.77437463120779,-31.44689421525544,-55.37904629947443,25.107301464051602,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark63(58.8128291811814,-43.102224521179245,-33.69606078507536,44.88729837375084,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark63(58.81326908450569,-15.833572027655492,-50.242359108280475,36.89424479476784,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark63(58.8396631427448,-32.71231618753923,-46.50192628606711,-68.14409224867572,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark63(58.84773005351721,-47.41694048794041,68.2734735386567,36.85756376293651,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark63(58.85517097826974,-48.03942682575146,2.4629535780904774,16.46506084722421,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark63(58.877925643984184,-40.90732312598071,87.38253136253036,-47.42958665947212,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark63(58.90438342333039,-54.15523434313552,-62.58974560535688,-74.96033646489673,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark63(58.90729914816407,-53.3177503535389,11.242388324722327,-51.80171196251073,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark63(58.925761963615344,-34.3779586064575,98.19183223059923,-22.926043307186617,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark63(58.952589665959465,-18.248476890330295,-16.56398885394151,44.74011120562551,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark63(58.97043424190488,-35.14157338496531,44.40169822442897,19.08134204481526,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark63(59.03339190703886,-49.11746172864282,-24.401019496421398,-33.17872534968383,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark63(59.09834507621511,-23.882448649064372,34.52025394024474,-50.45136873038349,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark63(59.128448617014556,-8.89384105448596,-41.17180844773092,92.57178561917084,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark63(59.12883634913038,-4.1801327395040175,63.688074794074964,28.196419077753745,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark63(59.191809959248275,-6.7048346326613455,26.143471219644937,-13.754066179684528,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark63(59.202361709723164,-24.56740994356805,34.40253686930777,-76.97679030474069,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark63(59.205479495744356,-46.934168386820254,89.77155742416218,42.3022775096199,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark63(59.21896958034864,-6.89491143984749,13.082150254820306,-31.81979368017369,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark63(59.22106188513908,-54.00410755213958,91.89534324872204,33.77147466429392,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark63(59.246333479913744,-31.877610622535244,-64.05620141779139,66.80180943176,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark63(59.278566063350894,-40.59370565344689,-94.54239141697151,77.69603845868622,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark63(59.31713151789705,-20.003388577541486,95.36975766446588,-63.18740334950841,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark63(59.32994646488635,-58.06171055976898,-51.02700770918551,92.85231946765157,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark63(59.373027679252175,-42.61549632827786,81.84231449377228,93.57313340722658,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark63(59.39249469529605,-33.572131732975436,43.55589203066589,-36.73611192437913,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark63(59.4027556915743,-54.04710210763896,9.714840881556498,64.42285707542408,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark63(59.47380168575279,-59.041835232905,-22.245940776811764,13.122542986735255,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark63(59.49258633263841,-39.96767400512666,-46.90400603966023,66.7384463034962,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark63(59.53526734860452,-28.851114491982898,-95.83354711680568,99.00142094139471,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark63(59.54947636327802,-22.207031678705633,94.75683089984906,36.171588816475406,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark63(59.57399833123006,-36.02208369628885,-67.1849387104892,20.221921497884907,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark63(59.62421645155507,-28.668528736960283,33.438826218167804,-45.4627361498152,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark63(59.64090509591594,-23.07755620270335,16.154357396644173,46.09075985505115,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark63(59.76334690747038,-20.45324237273229,84.9772079716686,-88.42282852426344,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark63(59.76962292388433,-15.92191516492636,43.90774351626169,91.85792708910856,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark63(59.82440227224072,-28.40593126343431,-18.276911864683882,-2.162797345529242,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark63(59.82636918700487,-57.615393856897825,65.67288878628602,86.02213588126304,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark63(59.848783313968624,-52.480166000972076,73.09349895917495,-18.588846022442638,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark63(59.85868033113158,-36.58966622341937,38.075917669166756,-83.72846995053152,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark63(59.86657685082335,-10.219532498792972,33.69180812659911,-54.6487527125338,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark63(59.869287666884276,-53.13743081751117,-84.06385046363613,46.06639262219397,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark63(59.911226534134954,-58.82472341570546,10.828951157389682,17.638359585027416,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark63(59.96971904276148,-55.68072436295055,-66.30539495972616,-31.593709055799863,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark63(59.98624781521855,-15.533791826576746,33.651034213010576,12.189735466467226,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark63(59.98922530258446,-6.26831207705311,83.20411637638509,-94.74477296622617,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark63(60.00872239840257,-25.11588840398764,-46.50018291996643,-68.61965615791878,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark63(60.03607508032226,-32.82848623860633,-73.71351829928057,60.79796807678656,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark63(60.045093696974504,-72.47023824467927,-35.80378726388409,1.6903957208888016,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark63(60.0462337806139,-26.805915606256846,-93.0131668595553,-61.720263933021144,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark63(60.064950289858444,-57.63412448163583,43.209836289365484,-99.60851120752582,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark63(60.08152117783442,-9.812473407161576,98.11568771938701,-61.19861730614373,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark63(60.10279146326894,-48.77118527050794,-61.540137619362326,1.2999267402401529,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark63(60.14693006589425,-46.47501748041507,-60.2222596408519,-77.23281263599652,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark63(60.14809192105653,-46.367007234739035,75.54387779700338,-96.1879213171336,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark63(60.2564056082156,-35.860628414299,-85.90315096889269,65.81730790876651,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark63(60.301895647722944,-14.12104869857231,-54.20180582104135,64.47827342696175,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark63(60.318820717131985,-8.98189669475724,-43.55113470576497,-3.828854039113395,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark63(60.39166841775659,-32.686254454939885,-26.95302236150752,-91.89444576860606,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark63(60.399625375835825,-16.210529891825587,99.54739106919567,-96.6406165222031,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark63(60.41618272420831,-9.110618531086033,7.819500726175008,13.258308695888758,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark63(60.419002882089046,-0.47782105368679595,27.43787037846188,26.80879545043034,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark63(60.43056271502442,-46.09621359904228,-58.88728073335594,55.88042352624677,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark63(60.48294993652058,-46.33907320677655,1.8310733711545595,-92.74711230712217,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark63(60.490808272463,-54.32477242875278,69.66129668835327,-45.48627451932043,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark63(60.50106980048918,-42.617376919497275,-92.57763734299098,-38.1538484837842,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark63(60.53654200197735,-31.2134624190016,22.921210620833435,-9.599848690503748,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark63(60.54395333806971,-54.89401606382418,24.648798139878167,34.88157402600899,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark63(60.583128918560675,-17.90856966792893,-46.110332877022245,20.88533333854741,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark63(60.63197885078881,-23.177144211560787,-86.53873592230255,-31.193071838437362,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark63(60.74124266128547,-30.189563350352188,45.36905704496914,-60.41898333644655,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark63(60.76156240291709,-8.347459929311299,56.8130945676553,76.32492959305057,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark63(60.81051476216322,-20.103277979207547,-31.539481984819574,54.34934757433987,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark63(60.82053084599579,-46.80783039139169,51.794690577095764,58.28470391686972,0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark63(60.88464760813892,-2.469800673116751,18.868998824592282,-39.72987463054507,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark63(60.89348071340834,-15.367136024557311,47.855717424402684,36.171376198686374,0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark63(60.9012527175812,-28.396392057712276,-23.73950090538071,40.89150814429908,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark63(60.96542182931191,-25.024944334123987,-45.36023752591527,81.17161821739415,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark63(60.97963643782549,-11.788135026535755,-40.30909630999733,30.131925312709228,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark63(61.03661164085946,-22.53912149537794,-36.891645141297126,32.368066375695946,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark63(61.04922061923264,-53.02925622074866,-21.445542304655277,-2.8130586466069474,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark63(61.05071852684395,-11.702285169231487,4.94750787531369,-10.81244273283373,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark63(61.07141918795563,-25.18828372142569,-76.34222399612314,24.529801521884437,0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark63(61.09529298327331,-21.097686930105922,57.58495980296462,85.9323455705509,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark63(61.099165420517465,-34.79233370270349,56.80272205871776,-69.10894815591506,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark63(61.112045894728055,-25.397440700272085,-7.208422130786502,73.36142463858377,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark63(61.11545759603101,-52.27926085377079,-42.631928850749446,27.410010638924945,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark63(61.1395973465078,-47.47204078407232,-42.239211288460154,43.05001319704945,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark63(61.16581685541095,-44.88133385884361,75.93035237951312,11.465787575062265,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark63(61.20096459409248,-52.259968906228906,-86.6011630711079,-18.34788649465567,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark63(61.220992542932635,-48.982314918725756,39.932294987838304,-68.98847968001436,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark63(61.26364676526475,-12.666814907936,31.716449591868155,-3.8819395759635285,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark63(61.29120206737389,-22.92211618713229,-96.559034089827,81.3650756426157,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark63(61.29122498024887,-29.374458822707595,-68.49623839368353,85.7681698039813,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark63(61.29216853494191,-35.73522650481624,-75.53260807178847,68.91791262023531,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark63(61.30094888736511,-22.63210439529489,-63.947857516256114,57.65316167549514,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark63(61.30331551464684,-24.84898366257697,-60.51545378292271,-46.33348891965343,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark63(61.35924522715635,-15.76782889099097,3.878785303002715,8.45566997674618,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark63(61.36223944610754,-47.73915275459875,-50.91811530402097,24.188776409075956,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark63(61.40094093285535,-0.4692261695794002,98.90475739571772,-84.30477073331363,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark63(61.446536203566836,-43.72095141327126,-21.898633096626824,17.047454030276654,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark63(61.45957612490301,-6.210664179589287,23.272620841950342,-47.15563834298471,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark63(61.49356109005274,-20.46815512061559,-45.889582045734215,-65.67134919507859,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark63(61.546340093417285,-52.16494827845197,-27.321348796486717,-37.17773703432658,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark63(61.56643202551098,-29.655058699149578,67.45274991160306,-14.107241284285578,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark63(61.58613167988989,-19.950719156798513,-14.86800444803606,-91.42490405565897,0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark63(61.61736857376354,-21.732207031558758,51.79753952260964,-91.93344834995506,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark63(61.632586939880724,-36.45656815497911,-88.30199789969568,-77.9197157291903,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark63(61.63958638978596,-32.99273938702467,-5.332843623755252,85.26170966827658,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark63(61.65754532971738,-49.861508050779044,5.677523932210818,8.419092743619075,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark63(61.664728394437816,-51.669339129298784,29.412575550139593,-96.5063606043482,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark63(61.670416520078334,-34.178525114828616,-45.79561081216663,-61.21420674642364,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark63(61.68296556563274,-39.55427248033465,-11.809169994884044,69.6988197330059,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark63(61.759489795023256,-19.543306337243266,-36.96150532687719,80.77730893472491,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark63(61.75992497817242,-21.088411144640588,27.835897241170443,74.46875261306155,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark63(61.82685170725037,-9.723637425368551,-29.37431186990871,-39.521379307512476,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark63(61.83699559099597,-17.310118307544272,-28.732063985200966,82.46694155963723,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark63(61.907278201567465,-58.65869001627675,-49.4576506991302,90.21619770758804,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark63(61.91512776804737,-26.45900394283423,5.497616265546739,-56.288102370002456,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark63(61.95704576388604,-48.29154791792454,-23.272963523083746,-19.410516649801394,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark63(61.95997320535858,-27.09230407761494,-98.31695884081404,71.34465388652484,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark63(61.99993533219981,-55.09333334169455,10.451040288940902,-87.85331156249549,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark63(62.010641123958294,-34.02098898761072,65.49635223697305,31.17486575163028,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark63(62.03823820438174,-24.984488354154905,-9.326763440955375,35.69042701305651,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark63(62.04025560142654,-30.33613939130126,-80.06276294238825,-90.9770787931991,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark63(62.04711097195647,-31.34753592873392,13.40421663575708,44.21336779636104,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark63(62.063191138927095,-39.04513155160143,-47.1786231755913,-68.89331541974602,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark63(62.13715267824966,-6.736094317511103,89.19831329174065,-66.12048993817079,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark63(62.195494364943926,-48.80969104798576,1.928174334926382,51.37084176586782,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark63(62.249556928716515,-11.802254208347279,-62.77550303008867,14.739421944460759,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark63(62.26453433753912,-4.078461946418784,94.28226702635621,-31.64514677354235,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark63(62.27207149752866,-16.24062725765951,-1.2499090548656824,-8.823480228608148,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark63(62.29562599374188,-20.342261662588925,3.6213106098839063,-95.97631272101235,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark63(62.30562127316284,-1.5554987745699975,82.22496892232425,22.65959444570281,0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark63(62.315813173464676,-12.22878826312865,-33.903655464201776,0.48974203671154726,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark63(62.32017182675969,-18.876494008849804,90.87888550501987,-27.132032711313286,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark63(62.33212824003738,-45.414125610043634,-38.27789261895083,79.48099686075705,0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark63(62.33297944246564,-4.582153390094817,68.54002065085831,-22.0713408659702,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark63(62.34337553450274,-27.150609156092003,96.76647679645822,-93.34740406492703,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark63(62.3493798726918,-20.179193162985882,0.3520669806750192,56.93666649792277,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark63(62.35564354086617,-51.20307762862755,8.027766532569842,-43.083692092018836,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark63(62.357671257641584,-14.531843726402954,-1.1897119279357327,72.19619293143492,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark63(62.358983866311604,-46.028862248457656,90.09281062707129,-23.474429797453027,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark63(62.37869441801058,-28.182157667624182,-18.376641050805304,85.84509615399202,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark63(62.426813492041305,-15.24208865556038,-48.02169512569456,-10.371589480322726,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark63(62.4710414250452,-19.627301562361026,27.198582212019673,-62.15229827541406,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark63(62.48463811905768,-18.827295283177932,-20.738219297369255,-55.8538413204303,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark63(62.50051996292149,-21.05671274312131,23.451706468426337,3.083013416916586,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark63(62.52065331499824,-28.67322794454779,-44.82369008001874,44.41970385777552,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark63(62.54481903738002,-5.211113039559763,-36.323649605110006,78.24825726971804,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark63(62.54856660402214,-27.194530385766427,-75.960447015664,99.40625612577537,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark63(62.567931299061,-41.070626554467424,23.64126961418043,-39.1102716705672,0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark63(62.65025219751922,-29.005987555882214,-22.42137256396164,-94.93560822472288,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark63(62.77790885567066,-52.830175188594495,36.43992008666524,54.756748668318664,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark63(62.79301671343575,-48.50722962206555,27.698654514581307,-79.30070771530823,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark63(62.85810459757556,-45.82324161237237,-22.53927927703863,57.351821099065745,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark63(62.858247053720845,-51.63728096073959,91.07718704486436,19.674593047232165,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark63(62.90102649815162,-28.484837933955347,96.6038341552285,-63.97438465990497,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark63(62.92277513925342,-55.90035493140595,63.2412141408557,72.19817157298581,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark63(62.92366792020965,-55.72506535710182,7.295224862426025,-73.8039285912369,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark63(62.9266969986536,-74.13835398456507,-93.36189989824678,0.9237758249157366,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark63(62.959812040326824,-7.835508539589824,-58.35489356308483,-2.2255325855558397,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark63(62.97793546655549,-32.14958781822514,-43.17277482871393,-89.95700006284319,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark63(63.02144941217014,-60.95313004857308,1.0034558374363058,-88.54883559381088,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark63(63.02510666839757,-43.17467151743229,9.12019602800369,-20.09758434185403,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark63(63.02608944904591,-31.554119470227064,21.535061273486548,77.40992454853449,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark63(63.026810062578846,-62.90811811603947,-2.8040057872030957,31.815090613292853,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark63(63.05919761746307,-61.391564173256796,-71.49975187806557,5.876033902414761,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark63(63.14206635708564,-12.18755188083773,-2.691786676909743,88.30799359515052,0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark63(63.15568028197717,-47.284062915771386,-46.18949106523515,82.49890445059074,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark63(63.155921972335676,-13.360254419881272,73.09913369974186,44.572219177281596,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark63(63.15777468007465,-42.0474768326349,-11.745783191733892,30.79911347265306,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark63(63.20564592127957,-37.27329412910072,38.28180782886855,32.138980870879266,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark63(63.22731947326983,-19.492227805335887,-76.94881408603666,-87.25628411770559,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark63(63.27949810659729,-36.64110029251309,-33.80866625047784,-79.61896419099577,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark63(63.286317386973565,-37.23916128842444,-40.204289177475275,-74.50639932132255,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark63(63.30977044149154,-9.369680363319333,-39.581564588417415,-15.934906269724024,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark63(63.32111033607373,-37.92125759679883,-53.406005787968056,59.413772611297276,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark63(63.33950554670892,-22.229051421320506,-48.977031964415275,-41.4357483493325,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark63(63.40823100318747,-27.08333833968885,13.768799925548265,3.529568488154908,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark63(63.44270193700717,-57.313460196978895,35.04598836073362,14.494999221836366,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark63(63.45382810821923,-41.77570657357508,97.0516640825461,-9.958819339788192,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark63(63.50808276408054,-16.935133748919156,80.23534053021609,-85.42450058151086,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark63(63.52404499832832,-8.734776433457569,36.68753265320046,75.32018571472918,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark63(63.55267787124862,-25.317340380564872,91.24093161134198,6.265785430001159,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark63(63.553242914796186,-35.031397633145204,64.2021457828761,-45.70210549208482,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark63(63.59265471189184,-52.9218333941291,-0.9111338438813448,-72.96402130911031,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark63(63.59340674298039,-26.822436846140008,27.190795498583384,71.40205921412289,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark63(63.60301557178798,-15.531245654073558,18.487427614175104,-52.560338465557436,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark63(63.627981110029424,-30.258144870006603,52.497919084720735,32.31047791264274,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark63(63.66614121309638,-23.841896191401403,-5.464265161863025,-90.68809944174853,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark63(63.681771059404326,-8.628425061015221,32.20353216101711,93.64896173045713,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark63(63.699964230331034,-13.9538299417503,-44.94116455703616,-91.38903420566953,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark63(63.71889072404937,-17.977588880406543,9.721314345153814,81.2760748398459,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark63(63.728019821054176,-15.802677869018055,-57.918240732422134,-32.884219847257555,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark63(63.80455443721476,-61.2713224136495,-26.03276217066943,-73.81228270897766,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark63(63.82907572265765,-63.831832586280754,67.08077819993358,-88.06983404069464,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark63(63.866756470099574,-32.85725786739286,-31.357231533630397,21.107499927616445,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark63(63.90611942234881,-11.062630233273609,28.14451466791735,-61.35130262985058,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark63(63.91205219798408,-15.372515423579244,74.08697101805151,-20.27388717761167,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark63(63.92081945248876,-18.857001501457617,-47.98146499394851,-96.72222908641484,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark63(63.93743087631657,-33.62205630695054,-84.31666496972133,-79.1820498790327,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark63(64.02038301148718,-36.19555294624528,-67.78879527057188,13.547300941314148,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark63(64.03298277956966,-7.072070024487957,-2.5140396181913474,-75.78150648842059,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark63(64.04316185505749,-64.53697411529338,-57.80085209190376,80.96506776925222,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark63(64.14228123495937,-56.86138827584995,64.11326970496111,57.00107257830837,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark63(64.15382397361898,-38.600891176276654,-33.472826509091874,41.00276748306007,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark63(64.17440384017493,-41.83302874621122,-13.29045139283194,-80.57497075881066,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark63(64.18120929432115,-21.88141402008435,16.550937654011037,-55.7899898157064,0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark63(64.20707835727353,-40.6338204892928,49.304197546731075,63.83122311375001,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark63(64.25195419927863,-24.74446089993579,-92.72491914624364,22.867521903973213,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark63(64.28119783592359,-38.76317009912891,8.783610830919116,65.32107481994674,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark63(64.30204887933905,-53.06887299917873,-12.824520139962587,39.5720344761167,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark63(64.33221488119563,-63.232923401813544,-5.95103377050188,51.80152633652574,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark63(64.3399217920105,-5.540470601358379,-29.91742268039053,36.68865118894368,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark63(64.34260381744798,-3.68607946186701,92.040501985616,-45.532837079189136,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark63(64.34422121801822,-6.627966628941536,85.92793424914538,-73.29047200439959,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark63(64.38103849690307,-37.00583108053357,75.09151175339866,69.16996717929402,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark63(64.38741502980318,-42.15665909978388,88.39551265963169,52.3746029332934,0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark63(64.44128042216161,-29.739365631017932,62.20306185996108,92.92883596886415,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark63(64.4622400300963,-8.096642586867503,-23.653853028825992,-42.19959666101856,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark63(64.48436783535004,-49.20118196985555,11.509425825819577,-59.0521750659257,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark63(64.48476217573113,-32.05670191465195,20.301101390633974,-18.661923168933953,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark63(64.48556681927218,-11.6104921868927,12.954156944434374,-1.1647701264640773,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark63(64.50997945343298,-5.750862545180439,-4.214144475707826,99.31448752596745,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark63(64.52452202774296,-53.06785889894865,-14.352881162902548,-20.454222739246603,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark63(64.53833243927343,-28.07481045790125,-3.4985744060331,-92.94222082481983,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark63(64.5465622127158,-18.290482004271837,-42.43073101522421,84.63586671327175,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark63(64.55465301168536,-22.407959563382462,-7.668909480552571,16.42536711613684,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark63(64.55869527187707,-0.3803252585834258,28.539894149022956,-96.30541470271538,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark63(64.58477250993445,-40.30392470351731,23.751843159610246,14.300940122295572,0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark63(64.61675198336735,-36.360245012467615,24.94434636349743,30.473835875115753,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark63(64.63237311692538,-50.00477324757675,-97.71773099708285,39.843032081318455,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark63(64.64370899514674,-61.78476304814,32.366352092367066,-37.27465896149167,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark63(64.64890577645392,-9.466138516170403,22.68632581277012,68.89385136457969,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark63(64.68104204263213,-13.31194955447215,-41.51224081286038,-17.36146648420676,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark63(64.71086645609932,-49.56957429400786,-16.988428364139892,22.084080222377352,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark63(64.75741407532581,-40.87275815439659,51.98457663935392,42.40135347059848,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark63(64.75882472143053,-60.066905519823166,-4.305304774603442,7.413895517365347,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark63(64.76579355855432,-29.8984408822091,-50.656667067967675,-75.43836416983197,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark63(64.78576586676809,-61.14600104792436,-41.42393945418328,-46.48551407339654,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark63(64.80222863698606,-54.98021519402678,-98.77595285356826,-69.33610898702315,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark63(64.83287253119141,-38.76842925474209,-24.128560700957237,16.30889597661205,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark63(64.88803535372963,-63.97943514224347,-57.502466704551566,24.511214954496594,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark63(64.90337769394907,-46.722012790911016,62.338741546154324,-32.65377758844801,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark63(64.90773832488043,-29.224094256905346,5.380143685921411,67.2718021117058,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark63(64.93119570172686,-54.6770427517556,28.885733073999774,35.6365166403929,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark63(64.95914626489977,-14.018955415389442,79.50373423933968,-46.41320785355245,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark63(64.96221817735238,-24.03065829492661,-14.933541335224888,-37.19471207884284,0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark63(64.96695793991387,-7.260820018935959,-22.71115075440477,-6.606820041273039,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark63(64.96985961651697,-48.174532291997174,-15.185003719885245,16.228127657274683,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark63(65.03505884528434,-62.47807655722646,-89.629305756959,86.29314353722046,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark63(65.06409322026778,-16.29569562329189,73.37520963130703,83.28819195562824,0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark63(65.06799700996143,-20.12020615307759,-67.37020961555558,36.168250579264566,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark63(65.08036357704262,-43.4624807291766,72.53810822341188,-51.85586253981916,0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark63(65.10112714692008,-33.525106209223026,64.12377353649356,82.45920894119126,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark63(65.19689618141805,-26.280264658434078,-54.6772682266119,-26.95851780892258,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark63(65.34642227726903,-3.9201247322944397,33.739706639604805,-61.507276609163576,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark63(65.35387188306098,-44.29689687738176,-93.30381536652057,0.8216311325687968,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark63(65.3773252364989,-7.9446991823703,-11.357604253746459,55.95752171503946,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark63(65.37917592967989,-33.60156875618692,15.302428288398588,-54.69949643607044,0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark63(65.40183410656851,-10.445518140061026,25.797349834028708,17.105232805977025,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark63(65.40546728889595,-65.57825578095097,-98.44569515166235,5.022920083065557,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark63(65.43742776075948,-41.273592911249544,28.329315761778247,-43.45617538240107,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark63(65.465677187777,-26.514462218794193,-58.29596018005647,-91.21630355202149,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark63(65.47790962123264,-23.69856755147306,15.971086485735725,-76.26609730415481,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark63(65.47918916466418,-13.886252259574533,-18.536038158446488,-35.14135709768267,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark63(65.48224814868976,-10.902556223888581,74.69784149067885,-37.29901177165238,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark63(65.48938893528,-39.5876671728723,-90.59430366002113,2.7402360013315246,0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark63(65.50165473126569,-61.73499306672423,51.89650323441063,89.41692104853493,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark63(65.54809317636727,-29.723819168265123,33.59490204208788,40.142608398754305,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark63(65.5569472196351,-44.11499792386733,-19.525118184308795,-82.5520319343216,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark63(65.57092010308136,-12.005675856427487,76.41937630628246,-35.33485301647579,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark63(65.5886948346581,-58.28432771638556,14.103607767875957,-4.401170633485933,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark63(65.73998792148177,-22.8480015109143,64.89909338907378,-95.52820006110876,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark63(65.75040475288887,-64.20614936432364,85.49624240324752,-13.881823679220929,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark63(65.8150049305095,-9.466964391531846,-13.884693538660457,-75.50489724658176,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark63(65.82935143723918,-57.93747894831513,-58.213765598378856,15.657584808503302,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark63(65.8353182765137,-20.48107137450863,17.06093627083709,-47.901559193416254,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark63(65.85515150444212,-30.649489251197465,-43.365808288514444,-68.27165784253563,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark63(65.8622316367229,-51.1799706916211,-50.783676722569446,-32.505579658090554,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark63(65.88677677283664,-4.5516607568710725,41.659456554393955,87.16224560872806,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark63(65.90798129681377,-63.87704140029273,-72.18326141622764,-80.2777410153864,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark63(65.95619871566748,-59.9385826084172,-33.923649833501045,54.71737397400446,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark63(66.04011547260976,-43.383251909781315,64.8826250197944,-1.8403488223679147,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark63(66.05611240410991,-37.661757070991285,-16.017802801053605,19.11356460671756,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark63(66.07286242070953,-26.562506694928103,14.404034439402949,-17.579821323494357,0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark63(66.10317649951841,-26.232006949355963,76.04168016933068,60.21950200803005,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark63(66.11512990563563,-20.068085330916745,-61.528915542120814,-2.39041176972475,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark63(66.12933172578212,-63.22784503310124,-13.584584687839921,-13.93509513518461,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark63(66.14231642314027,-18.78058768431687,37.94634433732446,-91.73322404005557,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark63(66.26476848002636,-54.72959091929277,20.41325935733505,-3.994490578078853,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark63(66.28390070274801,-61.29295093914977,-34.33474620326167,12.141048433570603,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark63(66.29210664591503,-15.066312282960453,83.26211422566351,-28.134737523010102,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark63(66.31240652293687,-16.9815915620148,-48.43161828303914,11.351171069028425,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark63(66.31703823699692,-26.53586988647652,96.72020446968412,33.26155150275798,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark63(66.36202011769899,-57.19010757477958,-21.95301296559093,34.136815776519626,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark63(66.41046559766369,-48.57365492999814,-68.2269528998179,-83.56227755466703,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark63(66.41210512054931,-20.24326641535734,94.92678657258134,68.87994651625903,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark63(66.47691915297443,-50.64945538342096,-84.02192454603508,-33.98320454790522,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark63(66.5083418680212,-69.09720900188088,-94.03356037800967,5.643758020382236,0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark63(66.51120739938185,-9.540944959340266,-34.92285435560456,28.91211256711327,0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark63(66.52213419776567,-49.26698073632772,-45.49828396558957,46.68357295262672,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark63(66.52988778346662,-24.643129565783937,-54.01861051728556,9.450345708477997,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark63(66.56477264384088,-24.2282317693509,4.42699851296986,65.87672013670553,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark63(66.59542486368846,-62.61189795764444,91.7642885024801,69.62297878681278,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark63(66.59667213589012,-8.718366460222612,18.798099289763414,-99.43488035203967,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark63(66.60192579598674,-59.67232543251386,68.90712026868817,33.47368007337795,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark63(66.62372931432506,-46.66830772242152,-6.271175703733306,-77.45586651729167,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark63(66.6255914832017,-10.018406283281507,-22.184581167813306,74.44243109022918,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark63(66.63385459413905,-16.499233981632358,4.70708344689011,32.25401924116477,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark63(66.66456881153766,-18.58277648224285,43.58183302148589,-31.451273608894553,0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark63(66.71634602380263,-10.713336254611775,34.817708929859606,42.799002554297005,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark63(66.72762344118559,-19.565448137786404,75.323090523898,-36.35505248144113,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark63(66.74718781793649,-45.60140998929001,-16.332018244520413,-28.599737908750072,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark63(66.75513700638177,-32.37772023693344,-72.71821155519743,74.43824056912271,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark63(66.75640685879196,-5.424714945943194,60.313743282263346,-55.11725028240615,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark63(66.76147604996962,-44.05235160833727,23.432623203068005,-37.4775813963008,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark63(66.76269014084423,-23.61647173342986,66.5480660043311,-92.93842902601526,0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark63(66.77180696183157,-12.057885971432285,-30.21722389552653,-36.000091198682924,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark63(66.77593625506805,-29.35052422825987,36.13753570012827,37.995818393383985,0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark63(66.79633375012074,-24.21715411624008,3.9264035921102334,67.0557057349607,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark63(66.80960492427562,-53.61280836729372,-16.67829423108759,-45.66715546661164,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark63(66.82892672884685,-42.03552674335378,73.09509211528467,38.59888584516679,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark63(66.8301295451428,-3.261783990975516,79.9248505773497,-8.164680820620674,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark63(66.86662701719413,-33.87518564058054,-1.8890964032555928,-20.433133334554128,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark63(66.8760181828248,-65.67091329520551,88.40180674223782,-15.307563084605661,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark63(66.87968393115352,-41.64555556731933,46.923351036519136,-22.32131602267114,0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark63(66.88206626012536,-29.95617611849039,19.89157218014708,43.49591269123155,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark63(66.88533048982376,-9.294096846151163,11.810257948102574,84.69010435728518,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark63(66.94043372632731,-11.313368533710161,6.704670710669447,60.71597706196212,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark63(66.94137572839927,-39.104891579624066,87.87614437865281,95.15563799411296,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark63(66.95888708438994,-52.55720311078833,52.145018937588304,29.81965089115522,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark63(66.99834591907589,-48.765519519854884,98.49699089283448,-3.588692198723578,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark63(67.06498111023978,-52.07233757518668,-80.68357578630277,-35.06644913409349,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark63(67.06577358752313,-75.9113361832799,-82.87462412889354,4.176135038791756,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark63(67.06966961014544,-47.07646071594323,-71.12583652307663,-86.67823787080087,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark63(67.0741379037097,-29.902748213761,24.048305208024033,-44.856444033127985,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark63(67.11292119596345,-53.82309299789454,68.81547389442102,-7.404574671733826,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark63(67.148569442123,-34.05461502864064,-42.52779149804384,75.23571196909936,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark63(67.16538994217802,-57.331578077797005,90.26191475319257,29.031752649868253,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark63(67.1875005607476,-57.34372572869124,-31.07454637256646,44.51533634516181,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark63(67.25036347690514,-15.151413556921398,-26.24965795882308,-82.84762048744071,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark63(67.25654455837741,-26.727072437809824,-31.581498964877895,-10.763656169906227,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark63(67.27727503469941,-60.002237809107314,60.09203579842878,26.40885627254208,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark63(67.31620014490338,-42.49938459113953,53.089771250196236,-64.10416146563912,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark63(67.331539994047,-21.808133509402495,-60.46122485969008,41.43098310469796,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark63(67.3506675092901,-23.478175237517803,93.07846441588165,13.142466835430014,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark63(67.36609864462477,-42.805594862501884,-55.73666353433584,-86.3094385771869,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark63(67.4385901366316,-43.139626403141776,54.44315681461953,-60.54553156841524,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark63(67.47149504313171,-64.32717530265336,-77.05432829488038,-97.37445392007673,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark63(67.50528440279109,-59.91376795288561,-43.8570569444356,-12.59979777170443,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark63(67.50810151877292,-26.548144829691125,70.56241878983167,-40.89210328796293,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark63(67.51718038072215,-51.73675329527543,-98.64635532931723,-54.95627573862825,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark63(67.56030923893147,-15.462301237050255,15.09369850183289,92.52883089251904,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark63(67.57480123833966,-35.39309577404832,40.63118535878658,-2.110572645135761,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark63(67.58811331259119,-63.16199824833575,-11.963842186755187,-74.02994666033531,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark63(67.61444078104361,-63.13024299350185,-90.69083006348045,15.453476813919238,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark63(67.64872962525982,-56.64896525829788,19.80013719927824,-30.727749090268148,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark63(67.68962663712631,-8.210894184048271,17.48961209469499,-80.22288756997675,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark63(67.73309551141355,-1.736326199752142,38.95224176798163,60.114459606397986,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark63(67.76170662749792,-47.68212957114375,-61.57304159687933,85.52315191010135,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark63(67.79174174039912,-10.905294743115562,-23.844830734674957,33.132331616146075,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark63(67.79443578957125,-11.750432938817724,-8.819213996464171,29.53599870748033,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark63(67.80823796299251,-37.55668515539987,-88.92376958956135,56.25116104639761,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark63(67.81270322273164,-49.73712424862335,-83.04816086447755,26.779083502210426,0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark63(67.82029670781475,-48.075863632597546,-85.28893552002626,-87.53034779879295,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark63(67.82161158561709,-29.089673712265693,-60.36619818896833,-10.806901994086331,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark63(67.83925173012977,-61.92834946629085,90.82913925325676,72.48069471892958,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark63(67.873359489047,-46.2816343065626,58.19919799894342,-87.284510900842,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark63(67.90463587716997,-43.163552564553754,98.6239784306149,21.6220395893439,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark63(67.90535467536733,-41.436753322852304,-59.64193920515872,67.67657487123057,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark63(67.91031702091269,-68.26707659441387,-66.22199606520955,45.16918232884319,0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark63(67.91363037578469,-14.047342659916808,98.15683398586313,-74.35168614707719,0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark63(67.92392866080391,-54.6729241021505,-56.83884979920999,51.323941042603764,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark63(67.93395006977732,-66.58447953578721,80.8809367635119,78.14777257553826,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark63(67.93400909491501,-5.297321082383348,5.060354512892658,33.93226544698797,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark63(67.96084908118891,-8.369970364762239,62.175702045680026,-29.618279847434366,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark63(67.9836102356835,-47.97716545173869,-8.893679378225443,-70.71530740463194,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark63(68.03756168194906,-63.8297695655349,12.534855158871068,-58.32388282350966,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark63(68.04177274982771,-9.798286024453091,20.583256844916235,2.4993601362180584,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark63(68.07449028100208,-67.71046972927607,11.488438122637774,-80.0357735606035,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark63(68.08209834105014,-16.082816454999943,-21.02007958854206,40.85411915143874,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark63(68.10473102621066,-15.467657311598984,27.231146087189188,-18.95107888147946,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark63(68.11497891084312,-1.4811695484306,24.10806014935953,-83.60532166215188,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark63(68.11780034796436,-9.463565279971363,50.288240620762224,26.868043807869114,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark63(68.12983788120982,-20.40378171093495,-33.8262997688624,98.87202062336155,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark63(68.14960206881531,-36.356468873697764,36.62818908574383,55.61437614936125,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark63(68.18124310415686,-54.44413526217389,14.460308979779086,32.02079367531641,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark63(68.20729581073664,-17.157422866316026,-21.07387719954717,47.983513660239396,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark63(68.250992622039,-27.172213680994446,-52.855440053224335,-2.9304334217656702,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark63(68.31254050574384,-51.693880437007245,-96.26590908470101,9.047642831991041,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark63(68.34577316900152,-36.91059259390579,44.22096672855537,-68.22657714913987,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark63(68.34871230258125,-19.39793255270139,95.05945899407436,-80.46654114827716,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark63(68.35151026646142,-10.813152652474088,20.744853969969327,-10.72367658337356,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark63(68.44368452636687,-59.03546456371993,41.73291436352727,-38.79396082474811,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark63(68.51776932965106,-66.45802400512468,-43.02682355688334,66.25561425651776,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark63(68.55277201506416,-62.60479398244374,-95.65014589157528,21.84817568839965,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark63(68.56269147039868,-12.851599668333975,-45.1568983996083,94.88060926005622,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark63(68.58918794499857,-19.276396561190026,44.91465588811258,-45.60825531609021,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark63(68.6147738002731,-53.44663261794729,8.71237872865187,93.45127268905426,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark63(68.6371567525733,-35.36463701007105,10.511087788784863,34.67313130450725,0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark63(68.67088303651096,-30.707200587276205,84.90282643473134,41.825313342439784,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark63(68.7166785772443,-26.98206964680101,1.338166993443295,56.30107821332942,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark63(68.71977553957032,-82.78445078080571,-86.19108251797685,2.115244309365494,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark63(68.72278448990991,-23.7150366676925,-72.16594641589381,25.857911721286158,0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark63(68.72320507140145,-31.783399867245194,66.00659587076845,-83.9336322410285,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark63(68.73908544482745,-49.197573758051625,81.48591207222631,40.0433859223985,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark63(68.76088989775079,-17.752618090137815,-56.46454286115223,-70.40941776932715,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark63(68.7716529711355,-20.252586145965324,25.994546026496153,24.901983202918856,0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark63(68.78213380752229,-17.50357042838162,-95.69228947394105,-78.66144567474238,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark63(68.78273161639044,-41.75253979326068,37.584109627120654,97.9674893376584,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark63(68.80021916799154,-56.17914856344595,-19.93427919307571,28.952116575270736,0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark63(68.81542901679265,-8.413109845071105,65.2087679368943,-26.02895050510871,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark63(68.82148925389225,-59.06915871569245,-3.7059539388124136,-46.12325741472441,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark63(68.87716554569735,-7.761750417874836,10.906443847696394,-12.546547442095772,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark63(68.92702171368731,-58.365965126713924,75.57893776119369,-73.01291321386414,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark63(68.9570561860667,-0.6484248926931429,31.025498982663976,6.16005669768694,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark63(68.96532510027299,-63.37994022980193,1.7480119478560994,59.67511559913049,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark63(68.98264453673914,-56.36182635583178,40.88902325325682,58.03371006573539,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark63(68.98852363261975,-13.524576960944358,58.93954564995076,24.264358729262455,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark63(69.0338118447147,-69.2257325100588,73.44832983907637,-43.57828475174686,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark63(69.0578967737327,-54.006681943055334,67.90489123599716,-92.34342801576125,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark63(69.12800015056595,-6.722660954199938,26.041152778889526,8.444922785065899,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark63(69.14663439611829,-16.77393364266912,-67.2758215977563,56.04120909668367,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark63(69.15603623574384,-66.48959976183644,35.171790915014554,74.06490734342765,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark63(69.16162730193051,-46.215201344319354,12.507785909864964,66.85079616773012,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark63(69.17729146666392,-55.31528773317176,-21.9725990730429,85.90071968303758,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark63(6.918663028569256,-7.621291417771886,63.02090161118733,-63.34006576825111,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark63(69.20674573907422,-11.035687408237635,94.51354246161145,-11.487032640036304,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark63(69.23041324331965,-22.41538445055771,-79.51861695024498,-49.76395247356502,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark63(69.23308020221143,-58.075217193104,-84.7790798662296,-97.1280174459886,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark63(69.23841039104536,-64.41203815539666,55.48309428341918,58.12056040862487,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark63(69.28561530051621,-53.17832439780958,-80.00471654638326,17.739345388973774,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark63(69.32581768390824,-26.881417469452785,79.5886996106573,-98.26275364650795,0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark63(69.32764480355092,-25.19256550794529,93.37017562150268,-66.97698447785359,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark63(69.33998698326911,-36.22332541378741,0.5293901105503522,-65.2925114416451,0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark63(69.37506503946983,-43.35425150946326,-21.051895964329887,-4.252242994660008,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark63(69.38462967247276,-2.7147088266056443,97.74139146164424,-59.10265191583801,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark63(69.39912123119521,-49.34139510680986,28.78633135049563,65.20290321061512,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark63(69.40870503319005,-56.55460905493814,-76.23565156543737,25.943007793480447,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark63(69.41360673313508,-38.23770502259423,-32.42309835595552,10.12769700416034,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark63(69.41945959033916,-56.346073754740075,70.41686456355416,51.471435773778666,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark63(69.45366741184714,-54.15857789356422,4.444052131302499,-2.1125086113280815,0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark63(69.46046249335075,-19.23331534110382,-97.26351107259144,26.81465301095109,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark63(69.48620295591783,-29.177991583096286,-95.07094362447188,-48.47568972051941,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark63(69.50686276152271,-5.296812661222376,53.94117982325727,57.13611106267072,0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark63(69.51463188202024,-60.43387351963989,-11.639997623775741,-75.91882784075105,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark63(69.52938331680625,-22.234649052944746,-29.74902668679111,-78.80760432118457,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark63(69.53206004245277,-19.754598649959874,-28.015752754450205,19.98732496647449,0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark63(69.56542557608302,-42.53427737365356,-59.259955395991646,-14.25492570706723,0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark63(69.61530299471747,-36.10300749504878,-73.84986131800638,55.953191753577926,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark63(69.62572236188328,-47.273585191385756,-69.25827455893223,-79.29624920647787,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark63(69.67917665489409,-37.79855236499073,-41.033314523455374,39.758717093893154,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark63(69.71057773961758,-51.578492374998675,-54.06189457403619,58.383365857589155,0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark63(69.7459193860268,-27.229402984785082,-31.90802862308803,-79.85061173502446,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark63(69.80757369885316,-58.590108340536815,-22.88787453670922,84.88748553111961,0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark63(69.81573001891957,-12.321612980456138,-0.7243670460624685,-45.923117458045226,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark63(69.8191033872765,-32.02802157847256,87.45929932269766,99.83686951008269,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark63(69.83161733684403,-56.75739168829899,85.15730527975111,49.84408150201838,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark63(69.86164971913215,-70.16810876987627,-74.58035621105114,87.41034875533674,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark63(69.91266864493664,-41.15652283805531,47.969276399480805,7.536108259266541,0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark63(69.94781877592914,-37.351291801577815,4.816805206685856,-75.40409676957773,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark63(69.94867139732554,-26.707886907118137,59.1609952871691,-9.199132249102718,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark63(69.94873580511234,-42.989462846037085,-93.56133613456458,15.100862808644266,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark63(69.96134696710973,-30.668273695944492,-34.23983355340118,28.83447846002923,0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark63(69.97028912696584,-7.631276251402625,72.51993910827125,29.276247815786405,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark63(70.018753090431,-59.71583722619711,76.31885638228545,-10.742846203964774,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark63(70.03763687784888,-9.808633425053472,57.162127914314254,20.560646393884284,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark63(70.03898059362382,-47.76322876696726,50.48146046271563,-87.09746637757006,0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark63(70.04087787945596,-47.402380279432734,43.13777393138807,-83.67140065252114,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark63(70.07243061548797,-38.4973082595059,11.304570205809057,37.7211392495021,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark63(70.10427421967961,-8.173294748969909,46.77132877279985,36.31899055304123,0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark63(70.13876859049392,-10.89574284563237,-78.40820421370844,-96.34346095063356,0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark63(7.015885004906465,-2.296954177466759,19.612202759714464,70.21378161183245,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark63(70.25213303506041,-33.29170725918182,54.922804667713535,-99.2301721560509,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark63(70.26214631769074,-51.18417826132813,88.20934919933896,6.398761073646824,0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark63(70.28016181423197,-31.93623607651884,76.15241504402914,60.36984479418592,0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark63(70.28388405480305,-57.38505632940614,-20.242651662997815,-64.76580692828495,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark63(70.28470573833923,-53.39689301677326,82.07852293009597,83.82466767244236,0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark63(70.29547773996413,-55.20361804486051,-88.74845012527088,-89.73812977241387,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark63(70.31629809890995,-42.19817640660821,-22.819502532351123,1.7639360937569535,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark63(70.3389879976109,-1.0657493893944974,96.25399042128313,41.45163194242315,0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark63(70.35123104288522,-41.17439823170137,74.25849616994998,78.1391798076703,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark63(70.35556072402457,-43.312181549742434,-45.012284526766265,93.77736588904753,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark63(70.40183564966225,-19.301985534676362,15.134895375002216,60.21065047475713,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark63(70.41294931368049,-68.78415196309643,-33.912627448864356,51.64091032013445,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark63(70.44646575575405,-30.0250995629318,-58.33133817557956,49.06700929496793,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark63(70.45385827669415,-49.384464143100985,39.001411089140646,-15.987206886389387,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark63(7.0475567146941955,-4.402029222693386,1.3611655992369975,-47.24807152745829,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark63(70.48428751309211,-57.421188088155375,56.612007948924514,75.99832987504561,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark63(70.51796388155901,-68.36459263533847,-94.49637050842941,-92.78709138941691,0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark63(70.52983811214514,-37.170040815663505,75.49394058999741,59.41511195415251,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark63(70.5388733864429,-10.5969840801651,-16.423120482898824,-50.19664560631738,0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark63(70.54325006484433,-35.23468417363662,-97.65486046027418,67.25227205904974,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark63(70.56751076016647,-47.887066614432406,-43.97519850151854,-30.279065342531595,0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark63(70.57361727333455,-53.38241968820627,-85.0949753233595,-18.963164338360045,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark63(70.61681121820163,-50.65586974313376,-23.0557912198214,68.88043297888754,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark63(70.62347633738995,-51.42374234395295,-76.81097757724856,35.99628914148056,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark63(70.62430963404424,-3.966021191695887,21.515277638758874,-70.46595014486128,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark63(70.62640626216833,-29.402391399273625,-3.960365183116039,-78.6696434955283,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark63(70.65710004424295,-5.297891076211101,37.51782425089115,35.06944514478417,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark63(70.70934717557353,-44.932934642859834,2.4892564096400775,18.664590529531864,0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark63(70.72117731694001,-67.59101888934097,-57.742007948344856,33.72452496082724,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark63(70.75531364231315,-33.62484800927699,-28.403112676208096,-96.82136269473185,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark63(70.75975409089506,-66.34208939873272,58.79486825974391,-37.70761473912747,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark63(70.76401079346886,-27.11813634877278,-74.43284765545006,-19.51589537889828,0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark63(70.82005896671114,-40.58632940260407,34.563612730280624,-3.3805956442365783,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark63(70.84228546937328,-44.60587066435649,49.36150854881279,52.06111935955536,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark63(70.84324518118302,-2.999930321437432,-1.6572961919673048,94.76214148395584,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark63(70.85049924768748,-27.488231482842252,78.07471486219802,5.633621760129913,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark63(70.85487011172407,-21.8745362700504,58.26728900824651,12.164219372028,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark63(70.88252419068945,-4.591573513313435,34.76220444332736,-53.5641305910348,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark63(70.90087966575624,-45.469170061569166,93.14440749858218,-12.651576440618001,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark63(70.92095687363974,-39.345161590298375,-56.15601079511716,84.5815848120206,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark63(70.92475661878407,-6.891463181438851,89.55306649070513,-14.491112225450493,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark63(70.95576393935593,-32.5699490308363,76.20653634304225,-21.230673054592714,0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark63(70.96196601556659,-58.36160938502844,-15.23902544118863,53.33693740588953,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark63(70.9715942386581,-39.0284342918116,59.733716047536916,95.59113966156272,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark63(70.99588507877402,-60.846935904032826,-47.02909336147376,23.946558742461193,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark63(71.00076268544848,-69.21226570696967,34.70418028871609,-8.431191461409298,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark63(71.012987905356,-10.314443772364527,-31.73279218235399,-42.53487497339621,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark63(71.01369442386624,-42.74903419789198,49.570830911568095,33.16001169385544,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark63(71.02254736759573,-41.7723711065239,58.770042919578714,-6.841324982879755,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark63(71.05245259030232,-4.997951416776814,92.30977498898787,-89.50306527968259,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark63(71.05922839042819,-67.77645461830448,70.0721975113174,-45.63390386826698,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark63(71.07475505659926,-9.057500583988514,99.53848320910842,55.301661302392006,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark63(71.07830384169759,-53.04840220653635,-4.720547391280135,38.5789940508366,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark63(71.1146432925274,-50.756687186071645,-91.92224645968031,-65.22484944351324,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark63(71.11734237693642,-4.460473805539891,78.34169060922414,57.72100542397746,0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark63(71.12264751752306,-57.71139187100842,77.04502992843896,45.20535400138914,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark63(71.12660122375007,-5.271629985914302,-12.67822229501607,3.6925793427523814,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark63(71.14273936912946,-16.63018778882126,-57.94269408642374,-62.61863923784312,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark63(71.19028304610814,-17.44669132811285,9.106005428790922,-55.0526279738746,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark63(71.19373515910405,-39.471106799987666,84.78543439047726,-64.96556059708851,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark63(71.2225276634974,-52.42537513149168,47.40225811807451,3.9202404939871798,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark63(71.27654386470414,-21.40861602503641,25.623943965691225,93.96631813552975,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark63(71.28080946084435,-32.506305182657485,41.120559889461816,-31.30057387098337,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark63(71.28679217561572,-20.700534818075923,-86.21572416984921,-22.03697666241966,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark63(71.29599979478192,-14.944929783842682,78.33275568859239,-31.416600999207162,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark63(71.30192988401382,-57.36600991695446,-74.34359198329847,86.53493783174065,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark63(71.30225842371101,-38.64527086088558,21.38110414186312,-66.80632969503182,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark63(71.30539309522811,-10.826489200186472,74.41687179976074,-48.78935711476957,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark63(71.31196118225913,-34.64837806878343,34.03613264453321,75.88235305451951,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark63(71.31819233543885,-63.034233294227946,-77.45986362433605,98.36528501474956,0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark63(71.32307466189727,-12.90326085805782,-75.39093700657571,13.41163464709119,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark63(71.35544847859711,-63.88733613439279,-12.164687182037028,73.06421311624132,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark63(71.38152436969122,-41.76002318366952,-60.86247292965359,-74.45563313208905,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark63(71.42195988957843,-56.7372814989169,-62.240682824706695,5.161111477014742,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark63(71.482093937945,-34.11295649927919,-28.047133857424186,68.57742880472608,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark63(71.48248265666538,-16.522587395227603,90.79485294655117,-38.46527112211531,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark63(71.494965251937,-37.20051189387659,74.09044783583926,-59.86382436296746,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark63(71.49726164400283,-18.029356385984997,8.070148623016308,-32.772649023245236,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark63(71.57077735049367,61.09334151580575,3.9046692717521694,-14.346473977626118,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark63(71.61252776931323,-39.04702755826217,-70.31294494169929,16.697571280600073,0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark63(71.61616805592658,-40.89697049143759,-73.7019161748693,-28.085412180452835,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark63(71.6340972075011,-15.525330375589093,8.160823165238384,34.13912521694337,0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark63(71.63646801639592,-28.260494225535297,-28.582896062721403,-25.20645878868406,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark63(71.64358989529521,-59.1153664787845,82.53079638760195,17.054648744068103,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark63(71.67986794885812,-38.11008988389184,40.29958570489541,49.558596268714155,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark63(71.69514166363518,-70.5265457402036,20.434843864060028,53.96967200686723,0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark63(71.71004542960259,-62.24244756685147,-58.53148447108993,84.32851780520764,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark63(71.71817060884763,-26.54265091812337,92.97297668841665,81.7692320611774,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark63(71.71888259641213,-47.06806327036368,-25.650227071240366,-27.51551411113641,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark63(71.79149276066966,-8.745435049141165,-50.22880314251032,-3.973152436223643,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark63(71.80295213643629,-65.81606858356398,-70.75737520405177,-26.91618576286568,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark63(71.81861342733669,-41.14552461110297,48.045657925568776,-18.447578114897837,0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark63(71.83228151224489,-30.04393445685561,67.69397212589703,-8.876312320802995,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark63(71.87964340458356,-58.726038178301934,-22.250132414846632,57.557889877253274,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark63(71.90221363479736,-21.92146452101953,-54.91319528366285,-65.10275850966826,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark63(71.92046375918176,-49.50589099874281,77.3187331851559,-9.252399832160137,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark63(71.93699676492699,-19.529778137696468,3.7598689263239464,31.175394801544286,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark63(71.95214884392638,-44.206839220140814,-54.31508720129037,88.7360209060455,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark63(71.95322389126034,-63.176180148105864,46.1033579350827,-98.60718615104598,0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark63(71.95591594727523,-45.305401702032896,-94.0604419497426,44.12678211046469,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark63(71.98949052961885,-34.0811369955466,74.12722576998618,-31.471114439441465,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark63(72.0205119807562,-28.31160085158315,-94.41717145652615,-32.2880468575718,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark63(72.03222289500746,-55.99430840023203,-83.80331453405417,4.029703138236698,0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark63(72.03254342657826,-30.253454629805248,-45.304049596403175,-67.79861120618727,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark63(72.06066740845645,-62.246483137886614,78.23527266590878,-83.8158729767323,0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark63(72.07772922733938,-59.3181667912648,-88.61981976792923,-50.2674815854288,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark63(72.09147146419056,-3.5483220742173103,-8.617140356510006,69.75288922445762,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark63(72.10576295702808,-13.452607467098716,67.36235459545381,75.15418244843443,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark63(72.12690866081778,-68.85549448854036,83.14865819594038,56.89247085474159,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark63(72.18559850343374,-59.20711553477695,-88.62442101011956,49.71784700208963,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark63(72.19396091436374,-17.575994952966468,62.09058172349242,32.26068497085427,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark63(72.19889740302585,-7.7406692353104205,66.40690618411085,53.6729630747017,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark63(72.20584688822939,-29.25621598573116,46.212119961003765,-37.21523064453043,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark63(72.2192227915246,-56.58779393401221,-35.43584870088621,-93.16721020687461,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark63(72.25442008772166,-20.56479903693061,-84.12983976621997,32.41284159444305,0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark63(72.26617271305702,-0.39852971614737953,2.4149780137545207,76.49843632631405,0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark63(72.27197603686506,-41.806206481489184,-18.42458117383042,-25.800815328604656,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark63(72.32497695989181,-24.416319590820464,31.31537563345438,-23.238503355044188,0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark63(72.32526052936805,-25.81281715707658,16.057008187976976,-21.75562079589328,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark63(72.34654012765506,-0.32457795789129307,88.65446094206519,52.3736937771007,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark63(72.36162762328934,-16.811068375092944,-71.29317705528122,-78.60690475850467,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark63(72.37635448514138,-62.29981341433686,-47.03981287503973,-57.640154463224505,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark63(72.417393951783,-52.839501889650094,-21.79124409805388,-34.95313491910524,0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark63(72.4825501280923,-19.896182475155342,2.4311174020922692,84.66057826503831,0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark63(72.48883650839383,-22.259003948559837,-49.62944618066951,69.84784644198794,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark63(72.49060036012568,-39.31789918236201,86.14000419220923,22.444053176349072,0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark63(72.49737144260527,-19.90274293781546,23.507934055676373,85.8768043458117,0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark63(72.51378756652446,-6.836830541195283,-12.024546165673826,-20.891565182090588,0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark63(72.5455479543553,-25.070482364478778,-98.8926393437605,76.54597938516969,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark63(72.61341595645229,-2.8469310025063947,72.07938342572564,76.41039770009559,0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark63(72.61834385219709,-38.80566695988739,50.24070744676223,-21.815985556798864,0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark63(72.62020626246607,-10.265878994330507,41.945795619150374,-8.283486235879451,0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark63(72.64461554754368,-52.57094887366449,42.016920834038785,93.7910396718299,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark63(72.65548943338149,-58.10085797711346,48.175910550118175,25.118030746716997,0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark63(72.69029911574708,-10.813841153840372,-18.234463217731943,2.081429271705204,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark63(72.70284576258922,-29.56662053095465,-63.41638140666526,-12.178369772630404,0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark63(72.70893887460056,-36.949922062050014,-87.62764435575045,87.47374780453498,0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark63(72.71866693370723,-57.67413199144165,-84.93298203741584,2.5471584397278804,0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark63(72.71891374809687,-18.68813680037276,-89.21647315956636,-52.93268842942882,0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark63(72.72264305079369,-59.07381251819308,97.28057318410356,85.37556124816385,0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark63(72.7485672599795,-41.20989882389476,61.20559291817,-12.773241474721345,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark63(72.7758067107332,-10.892394310995883,31.787022862503704,3.1349579586759546,0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark63(72.81065769815541,-59.93275024238085,8.17987809120359,19.79830920724504,0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark63(72.8498340572769,-60.86141764979938,43.075524036213096,62.87425983139755,0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark63(72.95196566695012,-16.172674463774,17.97347806899316,68.48922457272047,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark63(72.9560656024658,-66.53069429046343,-15.596284552658403,-83.19656318231587,0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark63(72.98586072775322,-38.248441108363295,-46.331898524785785,-28.217887447013055,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark63(72.99358651361914,-42.91058083627091,28.18958117134929,-24.010762885749855,0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark63(73.01091720240757,-32.51181809781984,92.92924500845635,61.18155370472755,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark63(73.01773181465336,-40.67790136163987,-92.67913092666198,8.20516223176395,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark63(73.0234542368355,-27.630592479467907,-55.223290528803325,-62.62081036788245,0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark63(73.03404908031644,-17.443954222209967,-97.23627238313097,27.940279869469407,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark63(73.0395265545242,-25.260127596135803,-31.483474079256666,83.95642045173528,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark63(73.05068113999053,-30.00765109419868,-8.356640639781517,65.6354781954312,0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark63(73.05674874207631,-16.335390384106944,-52.81341410437705,1.2306421983133475,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark63(73.05696792728332,-67.78931207618703,86.37114060244676,27.869793811378358,0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark63(73.10661505943494,-51.328327995710055,-66.05471312937394,26.66633205367421,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark63(73.14812167351167,-67.83922358011444,12.143614173681797,61.80522341744225,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark63(73.1483451254237,-35.564300413498586,-78.75166963833126,-97.31139624704126,0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark63(7.315665237543428,-4.763117374776456,24.924337870138032,11.401955829811584,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark63(73.19602787531883,-1.4113829027627105,74.89911440095796,-98.90869822922173,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark63(73.21269526888065,-6.123471172721807,9.797278125697062,-27.70565155433053,0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark63(73.21344524586272,-39.066501431629554,24.96898962366565,76.93480167311196,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark63(73.26675531313202,-21.548112393473943,-68.34818421871478,81.88732936247635,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark63(73.31834495870044,-59.52221381144922,66.62267551231824,-56.70360557905836,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark63(73.32639824961262,-67.22450067909526,73.41481404377325,72.7508469866614,0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark63(73.37398139462712,-26.298019581826182,7.89135400346828,33.132902801889486,0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark63(73.3966558881267,-53.92952852388251,73.11326365158575,13.67419002020489,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark63(73.432936947895,-46.84518675213629,85.66497469893105,-98.66028689614271,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark63(73.45301813188041,-64.91282661594695,-34.06936225512081,-64.9421941502875,0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark63(73.45465203522551,-5.31659760833594,29.41111977259777,-46.681337892326404,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark63(73.47795132707887,-37.914138111966935,-18.49920992506715,37.812161943583135,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark63(73.48488300262596,-51.403631853281965,8.458114674019981,-33.44748406484996,0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark63(73.49960254222921,-40.7310464760112,86.87956847679635,34.119732006442746,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark63(73.50490193045903,-42.28503903744387,-16.866884017467726,93.23144717588082,0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark63(73.5170501889337,-61.95837861923113,-68.29076913914618,31.001817729653965,0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark63(73.5307958410448,-59.47776917018357,48.69383773584829,45.55482327884869,0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark63(73.5410551012842,-32.25918153987017,-72.60263242389257,-10.045444812711168,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark63(73.61359031461066,-3.413229776672935,74.8865285450994,-28.401309746422527,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark63(73.63860818646685,-6.1532691520376375,57.02143949251956,19.18492005197581,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark63(73.64067608412691,-51.15087117933999,39.68389703785377,71.12264081123382,0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark63(73.7039431688678,-25.395441053688188,41.24209032749542,71.0680919786279,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark63(73.70997035418466,-32.9992753148,-82.19604707583908,47.4188306562736,0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark63(73.7256475626786,-29.286736065711267,52.774896063961904,-97.99418124489702,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark63(73.7598411157646,-23.011114211385745,78.12749481767179,5.535029825090149,0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark63(73.78603583111632,-55.22428955443104,62.78748179059619,45.10885544636503,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark63(73.80951458854159,-42.087688095447874,78.15899633195411,65.05611914443554,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark63(73.81950796393261,-65.30083326468741,5.599059546685254,14.043171102483939,0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark63(73.88006488787681,-61.01925283327554,-60.97465783265259,-29.97126760376814,0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark63(73.90602630467521,-52.62803280442181,-8.75367036751966,9.22844158271458,0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark63(73.97604202818331,-15.696146930945403,69.11898023348283,-77.2760560120348,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark63(73.97688972323792,-55.114096054677766,45.24319468199977,-50.47691497580511,0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark63(73.98334274959873,-63.67528394573216,99.49776188890485,-72.34744149308956,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark63(73.99280408837154,-27.320404249487055,54.43345081904326,-98.69558565531766,0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark63(74.01999646975796,-58.2081871817727,-20.400897619863343,-54.36078509949731,0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark63(74.03710547168595,-26.37087087025401,30.154437390684365,-95.99370177660577,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark63(74.04754526408362,-9.413869733588115,-31.176568418060867,40.82145008994701,0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark63(74.05856006148946,-45.940786165838276,-7.427086415565242,-88.67362558977658,0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark63(74.08823480341943,-36.39134959137813,-23.320475536744524,-7.3782831357705305,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark63(74.09061136986512,-48.13648554875376,50.666363906265076,45.02773389274478,0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark63(74.15608661024038,-44.320096602088086,-31.5692433326288,86.33671287663779,0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark63(74.15764908334103,-72.65033648382484,24.55888119293172,60.551829522585166,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark63(74.16321593944406,-66.42958491810917,-45.543039507285286,36.584078912144804,0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark63(74.17066597355247,-28.41015526894617,75.52740156600746,71.58179176062168,0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark63(74.25005865062752,-9.101250493040624,19.15367725899361,-55.309184993606195,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark63(74.32925986499686,-12.940048205646136,53.65120194462176,5.909547258668368,0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark63(74.36790630676927,-6.363644848450178,-37.434723592746025,-76.8294224292889,0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark63(74.38379757050569,-30.156244494619983,-86.54419990353563,3.7869788220270806,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark63(74.41179928124734,-27.949525890591758,37.205953753341134,-50.22023263363169,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark63(74.42528314899795,-50.54042165659065,-92.84471804732948,4.516037081000405,0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark63(74.43651749948538,-15.809075310454617,-9.213756425003481,80.36395883917956,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark63(74.46252073628045,-14.516247214927418,-75.18589202919787,-25.35491026497496,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark63(74.47295694649574,-36.16409902139288,95.80454642249993,-60.93797710248654,0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark63(74.49517776500909,-67.21832251111763,48.667341879719004,99.14486272223812,0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark63(74.54616816240303,-79.94831188016406,-78.36082853222122,11.088446819898294,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark63(74.55574145913951,-11.151996251536616,-28.085213950463483,-87.8414138882267,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark63(74.55781304317853,-48.44733768448253,-19.484220479883845,-88.6871749962788,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark63(74.60568598166066,-20.548166533457106,-41.24033263786841,-85.45143566666692,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark63(74.60897607422433,-59.7523802746341,-54.647009095456255,-93.87162477272904,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark63(74.62403544028092,-42.013160529451056,77.63799317542467,-29.6382819888167,0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark63(74.66668892246238,-5.732260547365087,-47.94674395873877,-62.016612248755834,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark63(74.67655708054468,-18.826091893499935,62.273170325827294,-14.985657821949744,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark63(74.67674715880531,-40.821309834692585,74.85877383702879,68.31003129791267,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark63(74.68250197244873,-59.85818690230384,3.1849954714191426,23.538563514462552,0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark63(74.69232087168291,-35.67586380072687,-0.9718008597780994,79.34095630447956,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark63(74.7007954431682,-52.40555288972122,-11.256993752181927,28.297119861437267,0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark63(74.7563666203875,-42.466996319025974,99.28077459060532,44.733544612388414,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark63(74.7570414152697,-3.8124762141764563,-29.835877046592586,90.68050542011161,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark63(74.76786798369977,-45.77434215459748,76.82730754384062,-98.8394969958591,0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark63(74.76841855095927,-25.626111330621896,-51.067057331830235,-84.99401319456949,0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark63(74.77479021820591,-50.66231071864531,9.424438878390774,-18.686012535961055,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark63(74.7767793327904,-48.490524572330585,49.834617540338144,26.558909168532878,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark63(74.79470923085498,-33.02787825608576,-37.63912266930143,-20.6591487284514,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark63(74.80439683459332,-51.37800942088748,82.16834192509569,-37.43462404186351,0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark63(74.805347821514,-24.100574622947633,-40.503690649848245,-30.964276407232376,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark63(74.83737230272226,-50.61263250204351,73.05047501221699,-52.777572611144265,0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark63(74.92072659878852,-88.66750029188174,-58.69640242534893,2.4201168797094823,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark63(74.97905964168828,-57.70367469053808,-5.326187325328235,-80.75767187901013,0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark63(75.01134075741612,-53.7565431007109,84.35219943286953,41.41926302953763,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark63(75.01781102757786,-45.05363297267535,30.389714437655556,-15.024659396592611,0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark63(75.03656619392817,-54.995648807473785,42.596208452106964,-75.57486131475827,0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark63(75.04936145375635,-65.15009517416838,95.69056755004738,11.839858055350817,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark63(75.11924242684512,-23.422519685714647,65.924614557187,-22.853881953840926,0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark63(75.12017962016566,-32.44316785010656,-4.639515883717266,-18.408167682907802,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark63(75.1243475686201,-15.085761594345797,61.32983117038273,26.172656452297446,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark63(75.14979325085878,-64.3039936317764,-42.464914036204874,59.63723597799378,0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark63(75.1563951555271,-65.69995299897182,-36.10000413268648,-38.63269628937618,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark63(75.19749042401881,-73.19710816365532,86.34055303467784,51.25231905439841,0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark63(75.20607607110662,-44.97779316441803,-24.901949286186294,95.38134261345556,0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark63(75.21862449383997,-50.70361156187306,75.05433172246876,-27.900821808221153,0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark63(75.21992952707188,-12.596289810055723,91.50497961010245,-15.002049271818962,0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark63(75.22450944297688,-29.768500103673887,48.38672438729995,-77.65716833549865,0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark63(75.22593887802307,-13.701398716566658,66.28574203387714,-12.407142154155054,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark63(75.23570930034808,-12.635334441022579,-48.27882341390919,-53.5800732162087,0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark63(75.2511387313119,-58.422244776107625,90.58937475326746,40.730868047208105,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark63(75.3312562655266,-76.4471106935165,-97.20284276982471,33.64346624724453,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark63(75.3758944938632,-56.9434729393514,-13.534399962314183,44.903402749617186,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark63(75.41365516487411,-51.78227405395515,16.601096519599494,-62.034067327017326,0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark63(75.41872741841647,-13.68851880235529,-98.17198309581087,-62.75002899819828,0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark63(75.42277547311187,-19.553910204061893,-9.459199523533158,-54.358660800675686,0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark63(75.46332474072975,-60.208171100215594,89.09482197147076,8.25996154997226,0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark63(75.47271881836068,-51.731689849810316,-88.17658031784698,-25.893971963898494,0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark63(75.47344345180338,-7.371395798721252,29.892953820338505,-82.72868786721388,0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark63(75.47424548551027,-53.87921515570013,9.989130563852441,-39.45294806097775,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark63(75.50356137479602,-3.4053985724258524,41.5586060953471,77.21401083563998,0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark63(75.56022875064855,-25.688538883617767,25.374077893217446,43.190487523928624,0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark63(75.58325564034146,-66.6670029978111,82.95459470606053,62.72046105599415,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark63(75.5951806343098,-20.325620634390916,-84.38576453014628,-44.7491512869763,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark63(75.64746061874382,-21.79135294495285,30.696610180151254,37.25286636779353,0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark63(75.65709292267687,-17.337183420476165,73.14916444271884,36.45933749715542,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark63(75.66959180058706,-73.41801910797147,-76.40121845220816,37.925008808561756,0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark63(75.68561489332214,-9.365671448646154,9.273662144619749,-55.26155236976107,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark63(75.68671969798976,-29.565106626322816,-19.673247478038675,35.68229139537502,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark63(75.74414933255085,-28.900152229506773,-11.28500790847238,-60.030670607418315,0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark63(75.76207778110066,-60.57571960098116,-64.3240848046986,-75.34141753119319,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark63(75.76344630062027,-14.155847845236963,67.38195229708779,-63.25543409139671,0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark63(75.7896090618485,-38.74989715371482,38.37342990667236,35.818679374373914,0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark63(75.80499844000266,-37.850824091831846,20.46144334905233,17.763135211923014,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark63(75.81436288498017,-53.35051674974025,17.665992502752786,-76.77867060034085,0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark63(75.81914306498047,-35.3171495141184,-86.8666455239264,-79.88759138357287,0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark63(75.84342595297966,-16.441224132108047,4.355305849213735,-57.42809045604391,0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark63(75.84524461430132,-8.861703711645916,31.46720425772699,26.433972666491485,0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark63(75.84895728627365,-33.18306749059259,86.9502370028842,26.498549738223076,0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark63(75.84946612901715,-22.41297490407743,5.810500299600648,-28.54326165344652,0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark63(75.85745995967551,-68.44136147814648,16.931990159280247,-19.189304368749276,0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark63(75.87848009510128,-19.03574763199994,-55.0066276360309,63.62330821150215,0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark63(75.90028914262734,-62.50460832497728,-13.95199116490437,-98.27249547973216,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark63(75.90479994873567,-51.85440201059939,-99.73028772229684,-22.660604192707694,0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark63(75.92844897172233,-22.312935577627456,81.68945803822777,41.64832353976681,0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark63(75.9392449596842,-21.940912298855906,3.3639001287572228,-17.35946449415313,0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark63(76.00244304110282,-23.31047405270199,36.14377380974469,-94.10202725411767,0 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark63(76.00718636503572,-54.21428993628399,63.728403279061865,64.52788787796194,0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark63(76.03462445260075,-22.92488279936964,-48.941453440561425,33.55949066299971,0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark63(76.1247538831436,-66.64610784548901,15.666988016548672,-45.555141213016114,0 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark63(76.12618450421257,-74.02052592597028,70.43587189010589,97.69523565984454,0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark63(76.16472118369995,-74.87638841177595,-26.541626731665843,-86.86035363808422,0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark63(76.18290276034935,-15.424618603725719,48.46131203310648,33.499642750141305,0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark63(76.2869809262678,-73.21411927542022,-88.09438193376265,9.049704827818502,0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark63(76.28761747087646,-62.557781398699944,38.0485955333574,27.774477033784876,0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark63(76.31211342859561,-36.24172276175821,22.250629941735852,34.790514379686755,0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark63(76.34488346604041,-25.023416348705993,51.90028884673336,89.33307996428178,0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark63(76.40792373205869,-54.88586493265881,4.89479435369114,83.49496591595053,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark63(76.43601134083684,-16.255982328267706,-5.9700101588845484,-95.21585467981315,0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark63(76.43697280566539,-17.273333334686598,-64.26377144948,-65.34598969101131,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark63(76.45953517375895,-44.40562531077632,96.53509572641212,5.088693982292568,0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark63(76.49978112639658,-16.63949143868355,20.023059804615897,16.30016813308039,0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark63(76.50532480919779,-49.502447763228005,-33.53400181413684,12.515672571662819,0 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark63(76.51730503487883,-2.6793043642502994,37.3674412369067,29.016806462903105,0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark63(76.5371684702065,-25.945149219464554,-61.53108136011078,9.326206402719393,0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark63(76.54110908489307,-57.146660499977166,-21.8026929057733,-1.5554771824485556,0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark63(76.58390368577301,-47.0417715833122,-29.2745148998375,23.391563915741102,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark63(76.5849866132568,-17.63134580625831,70.18500443505724,83.08771282843978,0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark63(76.58530579456303,-26.769953233383646,97.74222500277722,84.78491758590346,0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark63(76.63472040466638,-39.27343038704827,84.80206003188101,-35.32120692100477,0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark63(76.6764011762688,-16.345208691603958,81.38967711735933,-12.246189377923884,0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark63(76.68274960127908,-76.3398541294678,-40.52449706829182,92.85544980094446,0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark63(76.70207387649387,-59.97404269142115,-56.92128335120144,92.79497217247516,0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark63(76.70864981816334,-52.14916363445585,66.5424476714928,-15.055982137322957,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark63(76.73524318320443,-3.3325098959923594,36.7007016390709,99.01910992896131,0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark63(76.76010007630765,-20.2259219756655,19.931178063263715,96.54106207739227,0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark63(76.76617905938082,-9.398928122012776,8.777271890590654,-76.41792079786826,0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark63(76.76853642871728,-68.26309640643792,-55.89303985840355,-71.59180671004304,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark63(76.7726463572906,-6.352762289884794,32.58714028446627,-41.86233473771799,0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark63(76.77963910848172,-48.00428099424396,51.455464694109736,-15.809760103614323,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark63(76.80047067227903,-7.508612839096713,-2.7682823650661845,-53.23286966187535,0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark63(76.80526705676846,-24.207495890267154,18.43378803628258,-99.74162959470334,0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark63(76.88359746784573,-71.98071794530296,50.615105647534875,54.71789075360661,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark63(76.90063990885884,-64.03883885826508,-23.278928610539865,64.15923607171112,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark63(76.9036374949032,-37.66623868516614,11.82518030776177,-80.4738239449939,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark63(76.90803070856592,-70.33768034801452,47.341358829316505,-31.984125176413187,0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark63(76.92064976466747,-58.20643822925167,90.65462825472403,14.454788911013722,0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark63(76.93137725915102,-62.511558995501495,40.15889099366936,-57.24705028095296,0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark63(76.98029026095548,-27.246864234492847,6.4055385165365095,72.01807792819798,0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark63(76.99377644721665,-70.45547070059382,-2.5463984778071307,-34.90803558178999,0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark63(77.00697769284511,-73.61087911020252,57.526196875490285,-34.084399151717506,0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark63(77.03382718714181,-29.355473920209846,74.18353266038991,-93.1138486745007,0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark63(77.0836108876232,-36.86812971568103,-69.41628319073483,61.80871279974366,0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark63(77.08408472189726,-36.587638057052764,47.490181089839865,61.91609721725618,0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark63(77.08675469736798,-14.035342692217185,-66.29187005581335,-24.169821938346203,0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark63(77.13462577952711,-61.04060545022796,85.5721224086756,8.519192183020664,0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark63(77.15578325779802,-41.66405136141713,-22.806476774197805,44.014561380847596,0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark63(77.16656315023192,-28.402007834621074,97.36644714607431,16.70380293191414,0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark63(77.19254704077287,-19.612163864503614,-83.33562545842246,-19.383659421922744,0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark63(77.199452920498,-46.329594287446405,75.82544957624856,-97.48664563090254,0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark63(7.721336319847325,-8.51355472860493,65.51339341471808,-76.56621570583992,0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark63(77.2262393875319,-30.28520079599177,69.01399933890173,18.699936428732002,0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark63(77.22672760510235,-55.760656679437346,5.415876276416398,-82.75154493673412,0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark63(77.2290711680495,-38.308954230868906,-29.23123921755139,92.59471393694378,0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark63(77.2369575354777,-52.60482801974844,-42.30152549249298,-62.527084263712894,0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark63(77.23960095222841,-64.53747868499173,49.18270209901806,-76.67542278522315,0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark63(77.24002847837443,-32.682957881943196,90.43142316713127,26.191251114010996,0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark63(77.24233262666175,-61.473258878234205,-89.07148300272692,85.19642818664778,0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark63(77.24636440594549,-61.53535753447888,78.53945327710412,-76.95844099091178,0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark63(77.2502088445602,-7.123485054588528,26.714373290275773,57.92287319230198,0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark63(77.26336638633165,-26.465740108610177,73.31898908615636,-13.218603554638378,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark63(77.30833868384184,-16.749275845819895,-45.169785573667,82.29266425269017,0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark63(77.31386750465009,-18.545055204033318,98.90701032516586,-43.83626337236291,0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark63(77.31491868330019,-4.225369914990452,-25.93790903188038,-94.94617151825038,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark63(77.32940606006815,-9.515365550723743,95.4735688354034,75.92661012110636,0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark63(77.34887257581221,-55.771029108596615,72.1095460720031,-8.93502134809394,0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark63(77.38825268092398,-48.263965512926575,-86.85506360514161,-17.03380600431271,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark63(77.52273132937725,-71.52305155951063,19.804529065296038,-91.90589278442425,0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark63(77.52521480053383,-20.195049244675474,86.9315009680858,96.62012328044128,0 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark63(77.5254419163239,-25.78523446542232,55.371308438239396,66.10395779911883,0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark63(77.56224788413036,-71.90657740947123,-62.47380379130274,27.576875154474266,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark63(77.56762736716871,-72.34325493492237,91.27468091497056,18.437193733571334,0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark63(77.6680892725428,-55.439616415632976,-42.64489591677631,66.21767630579433,0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark63(77.68254164703558,-68.42914271143951,15.497251952991277,-78.98413902800124,0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark63(77.71604611472316,-25.780064046261657,50.513875621717744,-20.328124298672094,0 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark63(77.73630535105926,-41.197288333295056,94.58384133256814,58.34316795150414,0 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark63(77.74915748069938,-62.58692832103729,-38.15322599921374,-52.63904999289417,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark63(77.76613746219309,-35.342976337737085,55.08697335132777,25.905272014976106,0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark63(77.78892776820567,-14.336108644132153,-4.8688167433301714,-32.93039128267603,0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark63(77.80052885305827,-69.71272703420024,-35.34733549655931,-58.145057057315405,0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark63(77.82208404669564,-68.05420729957332,62.37323398621746,-88.28598475369134,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark63(77.83034759046257,-10.301636569894313,71.32114435484223,-30.391403185980522,0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark63(77.84662673218051,-64.65947682179727,-42.34702316874199,37.730284680522374,0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark63(77.86493032411846,-60.79502183576102,-92.7075483203075,-80.55078225563727,0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark63(77.86952937233912,-39.827569625909476,50.73259422160595,-52.825884525154684,0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark63(77.87450034574908,-17.27384299462173,-14.222140513969947,99.74987693711535,0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark63(77.88540324088302,-26.43269907500192,49.827376955059975,-2.112409655594874,0 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark63(77.90127160968638,-71.23661436910936,58.25419814709798,-3.1272895063357566,0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark63(77.90218076115977,-73.99554693184787,-61.327740918190024,-32.06032305497513,0 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark63(77.93473856372839,-52.8648441816038,-88.26700603857431,-32.83180526763178,0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark63(77.94485395466623,-54.79060877477762,2.5322196040010567,-23.26249637051447,0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark63(77.94750896194864,-24.853648729798735,-71.90972962789604,-82.13647445973425,0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark63(77.95463071336806,-16.77778409892774,-88.36368205756384,-10.000286080143411,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark63(77.98702426056067,-3.9286944538152113,55.12852284614408,-59.595134885354064,0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark63(77.99133818669273,-75.7829497301455,-39.604647688686434,-72.17378201699475,0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark63(78.01178314511196,-37.274064292223215,34.34411377126219,36.78736694252353,0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark63(78.0156422440505,-10.088647782844447,-55.13159960122782,-25.495693102597002,0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark63(78.0287404270407,-26.60787176041299,-22.569602015023563,30.57797228497688,0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark63(78.03854480315897,-46.578245020271545,60.39126463940528,-82.44060664875185,0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark63(78.04148112833457,-63.54114458145843,-25.67720086450582,-26.6527029742456,0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark63(78.04246673622362,-61.91647372932012,-79.52990725489315,-25.877817301522143,0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark63(78.04619249589621,-41.435471734639016,65.79397551960443,-59.54541723421376,0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark63(78.0488872915785,-63.06904945409586,79.66256526279577,-20.540129143288,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark63(78.05983488256928,-67.86981715417764,23.595104914041528,-32.04749585513544,0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark63(78.075050768806,-18.23384473679309,66.42323642132601,98.56487517607306,0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark63(78.104045744357,-6.685131276200963,22.15145088208979,-49.21010392717453,0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark63(7.810858159033799,77.46593366517814,63.558890623764285,39.55563821542913,0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark63(7.812099545337659,-6.28844702663929,79.18390107853341,-78.0074074270761,0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark63(78.1228619712212,-76.94346913273512,48.648878565829534,58.83497336314741,0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark63(78.12287697104944,-60.29681801364792,14.893084966650292,-17.801891532047392,0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark63(78.13199372247792,-53.70563861828976,-20.13836840006917,-41.807918575573396,0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark63(78.1789638073081,-18.19326741156064,-54.01839782311906,19.619018937362227,0 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark63(78.18083796516348,-20.164223926531008,-71.06836139081558,-8.675188090696679,0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark63(78.1870807794215,-30.74812589452516,53.567917022029434,-29.353247399704856,0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark63(78.19701099020023,-27.93032178608705,94.62330305234022,24.85057413994045,0 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark63(78.24711352855289,-45.611259843586915,92.04213605818865,-61.04721554307313,0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark63(78.29308367520414,-40.13828100109511,66.86540767109526,-33.45169754952062,0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark63(78.30058808462579,-50.47528481080612,-17.746198058394796,-67.85144285726912,0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark63(78.30296325324892,-21.598883355884468,-3.2266079471334024,-72.25429058407462,0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark63(78.3473882611423,-3.7374647320537804,34.14292846517196,-15.428058433607987,0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark63(78.35709566533518,-42.47180837961897,-72.1708522831436,-82.39244158900178,0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark63(78.36929571501145,-70.74231788993661,-74.54265709250404,-25.276775358005054,0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark63(78.3882575171981,-31.756211937388997,43.947825377019456,-88.70903678502735,0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark63(78.42162435529767,-7.987543281014737,-63.21035219212603,-25.080960400644642,0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark63(78.42905960566549,-23.55355269776176,-94.56395003577798,-59.25041742307391,0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark63(78.45982645213539,-69.53683784520999,-45.19448804756683,89.96267131286771,0 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark63(78.47594221590916,-47.900909512621894,82.8584878376611,39.83759552575461,0 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark63(78.49907326236936,-14.227457288801261,50.95588207685128,-2.350849439568293,0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark63(78.51127230677878,-12.235629877219068,70.48127789112579,-54.68567343474662,0 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark63(78.5485039023936,-46.03245293734191,65.55565636252004,-75.89457221968681,0 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark63(78.56339964611351,-18.915878027846887,86.63443032925255,66.69033435747744,0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark63(78.5693015847869,-31.991260995455022,-37.81385182912385,-99.77506376745049,0 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark63(78.58401831321385,-0.9928219905053197,21.26834880455526,-56.07159589375088,0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark63(78.65372957846753,-17.603450544984355,-38.77137134386297,-25.330313640825295,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark63(78.65569893351505,-50.76886554907123,11.615346561185262,2.7143242485030186,0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark63(78.67471492067105,-32.70958739075934,-82.11805679578671,35.632866877163565,0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark63(78.67916861852967,-68.53757945778874,69.72745794075027,-70.26457988503596,0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark63(78.73062392656777,-57.703930120562404,-45.73540720439926,-25.752159216810867,0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark63(78.75123671708823,-14.514014254990542,97.53163997625086,88.73274157134625,0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark63(78.76831263682928,-28.954712589001886,97.3486376872101,-73.05566917176742,0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark63(78.80089900174144,-40.30536429641225,39.190882566052466,-73.0330386191055,0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark63(78.80931476853789,-64.07618859006104,-98.39727281126099,-44.58146080471466,0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark63(78.81430880325652,-13.442275094618509,-37.70540465582521,86.99306456733524,0 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark63(78.81543980342772,-61.31877132767192,-6.499699988771198,80.09808110997199,0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark63(78.83228305562088,-65.17828411014597,-55.655951062837076,87.73495005602157,0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark63(78.84795747323034,-36.0497057354297,53.62389889165746,-12.460058927418189,0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark63(78.85672681419805,-26.82286492989239,74.54993325696017,19.246605395022613,0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark63(78.86937625865619,-76.1137020756462,-60.43682845913481,31.00184673776255,0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark63(78.92240929188245,-28.079341395572783,-7.8959808031623595,10.69581768608758,0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark63(78.92922425603948,-52.84451644740082,27.800697459575318,-72.40154990993418,0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark63(78.95365352950589,-10.331116016289428,-31.39680889037126,-74.84989544471534,0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark63(78.96743873405359,-17.17610999280359,39.172607880967405,66.16899472662743,0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark63(78.99694063851419,-1.125793458705985,77.08114112824495,-24.826601738388973,0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark63(79.0149282642044,-47.65749103890122,71.19713658637929,-78.10125555622345,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark63(79.0156438057497,-58.13476035397331,3.2480427373508434,17.86093413274841,0 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark63(79.03592859417336,-53.86218600361477,-63.10754264678828,-32.84402578217038,0 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark63(79.04783745447037,-69.04236045929923,51.13465111901732,31.28734075404094,0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark63(79.05350142234263,-13.319479387885494,-76.46982894036343,-79.84094037770255,0 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark63(79.05398101421727,-72.5940373454591,-10.659623583171893,36.06955326079472,0 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark63(79.07288962447305,-61.903738710369225,-7.070207777064638,-39.01846411250855,0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark63(79.09452394705409,-76.14552752771671,-46.193915581453716,-87.88429259712561,0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark63(79.10041662365464,-43.22645565483769,73.72183370173403,-46.204175355498364,0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark63(79.1163065369997,-41.69456808113799,-84.8037004816782,34.98116136689569,0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark63(79.12312646477153,-13.508557872211526,95.52530169214998,40.99735453737861,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark63(79.12581071274747,-68.3119863355435,-45.51259196878084,38.72063579284824,0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark63(79.12863107165671,-62.67650490751491,-6.0305420995308054,-97.33669031090781,0 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark63(79.13136552778693,-70.62136805259809,-47.12184808456221,-96.60783257494361,0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark63(79.14136202386922,-5.280127811927741,-9.706682300242477,-21.811063982699878,0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark63(79.16769791612077,-50.25627941616029,-96.14197784565394,-42.67744125334971,0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark63(79.1999090553696,-60.72047075666629,-91.25284267858977,72.76490748611289,0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark63(79.21321681724928,-7.6655440557460395,-58.811649661003315,57.86343665951526,0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark63(79.24989389398951,-73.78691961738109,38.01108439256387,-79.78536580984147,0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark63(79.25351466590223,-14.776206870894399,-72.38299297338338,91.2956222601133,0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark63(79.26709792846731,-36.742897910613046,-72.84191426484085,-97.23711035277864,0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark63(79.32766736700617,-59.339023245486125,60.828510180283416,-54.730538100766694,0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark63(79.32955068322843,-16.509603621199815,-10.59904163959591,86.28362336659782,0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark63(79.33518660259281,-10.426217127857115,-62.21071484300891,-27.03958277917944,0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark63(79.33943457561148,-39.550308413124924,45.261310326151545,-59.57026115673551,0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark63(79.34482842889153,-54.33539807332814,-32.92370736741404,-70.62158455087382,0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark63(79.35481638341562,-12.804695291896621,39.23732695020033,-43.72853192623267,0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark63(79.38423669881573,-14.374096476750807,85.94201200062409,28.551298258974953,0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark63(79.43949932589933,-12.841626446629206,-85.44339441574323,90.86473182072635,0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark63(79.44433160388837,-39.558002300847825,29.90241387157215,-73.20645720368665,0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark63(79.45487119602097,-47.60873755129684,-1.0971776719356683,-12.251919489454679,0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark63(79.4921658085633,-21.949955525247944,75.10514205498194,-18.404130668183498,0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark63(79.49756050462986,-35.28970205556456,82.55314186012686,-34.59956258565671,0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark63(79.55653476670997,-62.531166925457214,67.16053335327834,21.630317147127528,0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark63(79.5595034850873,-34.4124574233676,-19.319828378393794,29.369645474710268,0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark63(79.56248181632583,-69.22720984583965,-12.148630364161889,38.283235363748446,0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark63(79.58625266593452,-8.989383522255935,57.74762908845361,-35.99846112309639,0 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark63(79.60735711207568,-67.50029694587133,-32.69774570610859,49.03711795608808,0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark63(79.63666148844445,-44.05000101094147,-41.52114534719813,-64.83169196387766,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark63(79.64876148918015,-43.65858266010512,-17.626742414216892,22.936681615116456,0 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark63(79.67639509391867,-36.72480923086434,-90.11610971768991,-91.54082965646977,0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark63(79.68087386108161,-42.380089766447846,61.69435790448193,87.6910756492029,0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark63(79.68223591360004,-71.73012742359867,64.92474462748572,50.59520426406411,0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark63(79.69203234655674,-68.42004854602048,6.800841829372217,-97.19766224354703,0 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark63(79.69574362492605,-7.214687081813324,-25.369034389228702,76.97490526701225,0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark63(79.70140417856106,-75.72500765436483,-94.44345527415953,19.755079015518632,0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark63(79.70570549876174,-51.333520403156086,-78.31881817034494,29.425702187529907,0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark63(79.72867202331594,-70.94541163645312,-27.57079867930507,-53.34639292258072,0 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark63(79.75321363005713,-34.37673881705703,-82.20354875581388,-64.0467145628053,0 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark63(79.76312353683264,-63.324311220166486,-29.170434924430992,-78.25339623410753,0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark63(79.77140196611313,-56.88208637400278,-97.21348031578427,3.2936565968808793,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark63(79.77355515008458,-44.87829021882672,-23.703178886145153,-74.31388258769724,0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark63(79.77876417736195,-53.27042107960154,-74.83725378240737,-89.45832858287382,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark63(79.78219861923662,-25.530619129904025,39.57491171124295,-7.0611368182059095,0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark63(79.80472103121878,-63.45193090930452,95.40720106062037,-1.9021040280249082,0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark63(79.83535722212449,-64.94186618228318,-51.158556746618466,32.06787734539307,0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark63(79.87116554179369,-18.60878705683379,57.749621448693404,55.788093999803834,0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark63(79.87660299047246,-66.49417531574602,90.55826566066568,-94.20410251220166,0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark63(79.90665748067008,-81.23855373068243,-59.096317369285046,40.45175747782349,0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark63(79.9323515254857,-61.91494926075993,-22.437815165702673,43.23246468732211,0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark63(79.95996533129517,-17.539182678083364,-4.037454299906273,19.355003947305008,0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark63(79.98133170560007,-68.60581669243743,-40.8909694936709,97.41452729163868,0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark63(79.99581404254593,-76.12158108813904,1.6374232683155014,41.339533806019006,0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark63(80.04946525358784,-62.908597025971204,-98.30502210422544,-74.22496916716852,0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark63(80.05587299466598,-52.30171758175424,59.026108898116775,71.2923488268853,0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark63(80.06224606570126,-33.94077872808697,-41.30775662488235,-23.233728585684915,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark63(80.09375972108845,-6.2532942153910085,-51.51019567067192,-57.929665315574155,0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark63(80.09792443746412,-18.596387615911894,70.69753679043751,-70.77156484136131,0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark63(80.1162326534565,-27.12798029130748,85.67693928491784,26.64700320308937,0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark63(80.12025855817768,-6.583279765181743,-18.716852521341366,-73.48794461870068,0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark63(80.1230558318004,-25.057375196449925,-44.93350398473566,29.342422687510037,0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark63(80.13027855584315,-54.677138858629014,-56.6904057880737,-78.89690416938939,0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark63(80.13349016174976,-54.566953709208235,61.259808720639086,12.457616192483115,0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark63(8.013669092699956,-5.8875344580113165,0.6288590916467172,-26.937310253055614,0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark63(80.141852098284,-13.380837561013692,-79.8567921237298,62.92434803240738,0 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark63(80.16850459962427,-71.52973286270134,-38.36071807808956,-38.499356497044324,0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark63(80.16908252609795,-35.15046043707193,85.43891482462581,-31.382929155585543,0 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark63(80.17096193357841,-68.00460771366915,90.4226598589546,-75.79812030567052,0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark63(80.17770794849673,-68.19944262078015,28.952511381500614,17.452575209159974,0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark63(80.1853044559696,-16.545064259347697,18.147242747651475,-51.327032395909455,0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark63(80.21398157182463,-37.41018253564678,90.93245197806894,-17.92990298363968,0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark63(80.2352630020049,-24.966980493775054,62.624871951525506,-39.88488044667313,0 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark63(80.24495431921525,-27.59268001069219,60.18410231595419,98.43072430969039,0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark63(80.25032657352901,-74.30650232856387,40.60367734584494,61.19003034841356,0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark63(80.27757028611418,-52.472239241992355,-9.25548194314132,-43.082152546099195,0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark63(80.3033238195315,-11.98437095557712,-55.38503262834986,-42.47960161918471,0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark63(80.31352544791002,-47.57168020257576,-15.88103815547754,52.82413461345297,0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark63(80.31440825532727,-56.269694535810764,30.905448467654793,84.75004564561056,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark63(80.32322928013008,-28.30407855932671,79.63797330064725,42.51592705671749,0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark63(80.34104548028355,-23.77220540935295,-22.61207281693683,-32.500244649394205,0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark63(80.3523906614885,-20.20665629735319,67.48800900497164,-2.7339419515820964,0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark63(80.39911690043496,-39.317708362607085,81.93589699053106,-68.42579555123984,0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark63(80.40233804009179,-44.37795015469859,92.8759492608178,-67.18136938639057,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark63(80.40597697073991,-31.428627884807867,92.18868865943085,91.62311278256982,0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark63(80.41817254867013,-50.45220648225814,-7.906174608000384,80.57621317557252,0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark63(80.4261925036451,-51.02896037599574,31.169040124586417,-77.95447075337938,0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark63(80.44661922473287,-76.18845690341804,-6.665740066527263,-64.1615859233122,0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark63(80.44899750109965,-36.11890493331779,95.11118383713665,-29.286513027299705,0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark63(80.46741091536006,-1.4977009112069624,28.11223418544907,-45.53681365881446,0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark63(80.49964640643978,-67.46125574550943,-25.805060626760863,-75.65412798942788,0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark63(80.50482493836213,-21.347906878582165,41.47375769609471,92.38067450192528,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark63(80.50716767543778,-73.30300741088922,9.566958144810812,11.696839876192485,0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark63(80.51469542605852,-68.09466730621881,-54.46884865605539,21.440772487971316,0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark63(80.55019770351919,-78.43946131308776,-32.87414174907937,-20.348610822103524,0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark63(80.5588450602113,-55.542788846228184,-71.45016494250795,26.752967763046627,0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark63(80.56266210858522,-17.4750011624957,20.23514497763965,5.717631750501056,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark63(80.5783069922131,-78.57896317186297,24.801801926491464,-0.587043412910603,0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark63(80.5807883624426,-41.47903520354621,39.610213144954486,57.38320292268082,0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark63(80.58194731510358,-46.55621741177074,-82.7826118985088,-98.83278145153986,0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark63(80.5886216298835,-24.596845736627856,-75.05223354509398,-5.629784359497549,0 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark63(80.60531226839018,-23.533143730632162,-70.89303628051363,40.57794412621848,0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark63(80.62806301589913,-25.664917340461813,83.20768409704775,-5.514054650439931,0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark63(80.6389554302489,-66.71721655295391,10.663270720958806,97.84795811281592,0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark63(80.66120645351634,-60.522461644465196,-27.596435604368352,0.9420936761491987,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark63(80.66246855716668,-51.303601706250305,-60.09498566774487,93.19689336467044,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark63(80.66882577891369,-16.613961675852778,-2.8205522366195197,-44.838067651650306,0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark63(80.68631431513279,-46.892523620002336,-22.617543442884823,-73.355408982563,0 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark63(80.71010931510403,-82.14735882066103,-82.86678468882151,14.899031189390527,0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark63(80.71592611908068,-77.21873792538862,3.04200987382292,-25.34097052209046,0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark63(80.71840303462722,-1.8595501695128434,61.229956050321704,-79.12510893922111,0 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark63(80.72225827728701,-35.53624535082676,42.09511821631483,69.4888802661855,0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark63(80.75067488881652,-84.06656692254668,-81.93196972146094,4.569235516357367,0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark63(80.75243930331874,-68.62409362591065,88.30547613485845,60.85509427230531,0 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark63(80.76961895912291,-99.7149808565654,-86.86806478217397,1.4414961671644022,0 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark63(80.80103143267436,-17.679445739396485,79.63565862069245,69.81229781915744,0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark63(80.81179471925253,-80.70858992646441,-92.99378380910835,68.34967771488058,0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark63(80.81271836326485,-67.52283408758915,64.12207123876772,62.67973420045672,0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark63(80.81370793597983,-81.9175615700128,61.133434979564726,-54.80418671385377,0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark63(80.81898484312481,-34.63500237192079,6.7171619317519315,0.5683902924419755,0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark63(80.82474740795897,-41.76406233663141,-91.41671376090326,-81.3193387848828,0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark63(80.83350658166506,-48.953656107306685,-91.77113546436271,73.99277647719157,0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark63(80.83470782112329,-40.41616203879532,91.31684307388369,-71.5965567865628,0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark63(80.83935172908508,-68.9302349638229,-75.63899341390157,-52.993835012412745,0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark63(80.85619585415219,-62.76451659555753,15.869042693191489,-79.09215466996633,0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark63(80.88310948384364,-30.242340683617243,99.06803461170688,44.68305838148473,0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark63(80.89498579715485,-14.53140547391017,-89.42069369697789,-24.827901421410758,0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark63(80.94356893297194,-20.708130822956377,99.54976651243314,-39.51330531586925,0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark63(80.94585518337712,-72.52133716549372,-50.56103997558492,37.18489977307493,0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark63(80.94829752549708,-78.72667013060703,85.96081844781557,-62.64236413783462,0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark63(80.95664256285596,-71.8177991271858,58.76499430196057,-97.4088296565543,0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark63(80.98397921127514,-3.7203315495497122,54.03263400258459,-40.32681491523875,0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark63(81.01206012059555,-63.741167366644504,47.33437545806177,-61.574853458622236,0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark63(81.01540648207416,-80.6117808874223,16.449645974152304,56.3542252492457,0 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark63(81.0377103241359,-42.6560493656714,93.22129977141631,29.5810157899746,0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark63(81.07411634083581,-13.891043059367007,93.12777981041663,99.69189315563943,0 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark63(81.10235755400564,-69.59955271747391,-59.2085606929603,50.76401173098327,0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark63(81.10743918216053,-27.651244234234,-39.8232134012038,-4.387044071350019,0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark63(81.11338603849762,-47.004820538837855,46.942420539033236,-53.59771314732627,0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark63(81.12999343895564,-48.72183782729886,51.562900865743075,-78.02222418120746,0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark63(81.13069387520727,-12.318257423929353,-18.888836468558296,-33.18268424624054,0 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark63(81.1349245359907,-21.789658875687977,-36.68567872932802,-89.66716187502806,0 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark63(81.1373803040727,-81.51836871686298,89.56202995912525,-20.861164948898477,0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark63(81.17075035298427,-14.670662778207415,8.602346746165736,-83.53222846539386,0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark63(81.25424650738478,-16.208258034858346,9.416984334474535,-26.57302604571757,0 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark63(81.3122708923521,-46.37848263845561,-30.17313555254755,10.214030251714462,0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark63(81.31630488327093,-35.88316492892001,8.84703520684387,62.12592204124485,0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark63(81.34087042608863,-49.95888276698841,59.605573660367384,50.56649048424083,0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark63(81.42920288555786,-70.39758931549511,-70.27244902164627,-63.18441294401238,0 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark63(81.47317194127564,-27.476306667519964,87.39604279392296,-38.08944726824053,0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark63(81.48422869318287,-55.420357922873855,-51.38177543684239,-84.88357366290944,0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark63(81.50942671497376,-60.833915564520645,-62.06154839346898,99.99580295215117,0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark63(81.53449630456345,-34.37510902195069,26.961061716067533,13.10730049856268,0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark63(81.54207781821364,-34.1104851012298,41.80261131422466,87.12943968076547,0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark63(81.56278088112202,-40.14616798815665,37.2828126285483,-52.9257490581815,0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark63(81.56814940258562,-44.99004123754779,76.9953854453779,98.34623282424249,0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark63(81.5937249470349,-80.02326498106598,22.23298837175915,-28.64795545242687,0 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark63(81.6177782429348,-81.06919035016116,-45.83823853060505,43.13927525291493,0 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark63(81.61958941693888,-51.79568434441284,96.1890323423994,20.077920434213524,0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark63(81.6272749144299,-3.4294275145319233,-13.676949263195937,-61.603830332262824,0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark63(81.63195363943188,-33.01396511266678,-61.71214103658635,17.488998160148014,0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark63(81.64026656274811,-49.44896573166404,48.810446503538174,76.06717018277837,0 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark63(81.64370707086834,-32.71477253580832,-8.309691465540013,-10.88304001937992,0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark63(81.65842787598939,-12.578823311322111,-47.571629575269014,5.871433870622738,0 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark63(81.66593045502091,-81.77420383442842,9.732492068841808,-71.80035411690528,0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark63(81.6672848522079,-1.2487471368770144,99.26931754174427,-88.55594024769921,0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark63(81.69810611251683,-33.37061770135644,-90.4396624193281,92.65816489172352,0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark63(81.70070182572957,-6.552570095126683,-36.74460745477983,-94.20039313506574,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark63(81.70587956253252,-60.23498431118812,26.355766060025744,-74.77011671095472,0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark63(81.70591111708788,-14.656845829240822,-16.35861407247043,-68.84301342767981,0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark63(81.73368311985442,-47.625464568156815,96.88610969175969,-28.009114209260915,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark63(81.76245010843243,-4.2596314795512455,-17.01049404938017,-77.74708913151139,0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark63(81.80700000093958,-51.71094464786394,-60.94524771508385,49.64656331637414,0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark63(81.80988927994457,-68.21298462225865,-21.887317773251453,-41.40183689141328,0 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark63(81.82034870840243,-17.225426848424647,-1.17030028544211,80.15188617053599,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark63(81.835188094469,-20.328412026569367,-59.06411470716692,-97.92364503396487,0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark63(81.85326681265991,-66.71363401512241,-31.663758858774926,-98.48851622865294,0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark63(81.86846086448583,-46.281337490973385,30.926747128328685,-89.22758670401973,0 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark63(81.87578741136937,-59.20098610661819,94.6303471679719,89.8006722988257,0 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark63(81.90793544381035,-20.663947453844102,-36.01483131141276,-93.0230764523164,0 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark63(81.91013868329341,-83.48120428780726,54.13230429258016,-16.45019280069748,0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark63(81.91981944942097,-56.0078312897897,95.36896572547602,73.1569155371028,0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark63(81.95031902763418,-29.57749103537097,15.395205524627627,-96.66127147734503,0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark63(81.95574158014168,-57.887478914272506,-89.90850241437012,-53.44394754429318,0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark63(81.98241670819624,-27.34003919873824,0.6218093483513485,17.23151927044664,0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark63(81.98453133587407,-40.963169454426954,94.8128430381054,-76.82037219135394,0 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark63(82.0019088951272,-51.248130253298775,36.25912219428548,83.4882253543309,0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark63(82.01422135135616,-77.6545124165833,2.0841021354057716,-77.68354292308963,0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark63(82.0194030634828,-1.287982660235997,34.79918987452439,-69.31681772893326,0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark63(82.03578729663394,-52.8565326586375,-67.67667935461736,56.332938598377126,0 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark63(82.0762852043232,-12.087978265846715,-46.755383444142026,55.714486323268034,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark63(82.10398667064374,-37.78892014191031,-63.78560710857892,24.495968184589117,0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark63(82.10485481878118,-42.422178139173084,-28.211083066194377,-53.76740853553015,0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark63(82.10691587205699,-78.27851473071263,-67.1666467322349,92.54717969456263,0 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark63(82.12553576943716,-59.08606160384162,98.52808209845486,-24.179204442550656,0 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark63(82.13229137533511,-21.8429908069554,-65.12430937641129,34.70576958881102,0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark63(82.1404078195317,-72.00567322668654,-51.10108136733509,51.38229801234306,0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark63(82.17497771140842,-67.62418246273111,69.34132163508389,-86.8676231187141,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark63(82.17525776017675,-35.308325485146554,8.8071892139088,-69.32113549003067,0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark63(82.18578733409473,-70.79529075715536,-90.33355605291374,-11.785578868054472,0 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark63(82.19036240368081,-14.83892334882124,78.43557244581112,-71.65740441981077,0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark63(82.20883896990102,-39.54934411051232,-71.59281061085323,-10.57543916245504,0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark63(82.23935467486024,-43.77102928355783,26.00642842290486,85.41182739054736,0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark63(82.23940506310217,-52.4315803779067,-84.89873392166447,21.523596164606772,0 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark63(82.30544775273893,-21.322942161195172,-52.11054171902283,10.561488339428493,0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark63(82.30805197203745,-53.95905545937312,-77.26545096076856,-85.13962452661306,0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark63(82.32872041591088,-47.300392630086364,58.907243554797674,-33.88770098106539,0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark63(82.3313804463192,-75.0947092595204,-47.41771425914203,-18.911987396512117,0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark63(82.33203637336587,-27.49350031512168,1.638854444613159,-50.654307768160265,0 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark63(82.33920980584844,-39.750076813933234,-52.129998102432836,-25.279881227581427,0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark63(82.3549640946303,-28.19400756155521,-44.847171547019386,-22.72767886145492,0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark63(82.35820664179337,-72.32362566508812,17.88434375352965,-73.97208396004291,0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark63(82.36677652768037,-44.810334512095906,-71.0171168666628,-69.07862710264104,0 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark63(82.38996468159317,-56.65027959338968,-26.073745411245923,43.79984680291031,0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark63(82.39918520386192,-74.97873850219526,-29.791287504743664,24.944251965416825,0 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark63(82.41613838545138,-36.040067586096434,-13.97055471730964,-94.64162288565394,0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark63(82.42493206720982,-72.3040925771673,-28.49666616174993,83.62544277906036,0 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark63(82.42526534760145,-24.65285724184338,-6.170643234072529,9.278696644423732,0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark63(82.43327007184647,-20.838728036151494,49.79149759914253,80.29511666731739,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark63(82.44746786805581,-40.51303184054178,46.84017703976653,-95.87660011565804,0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark63(82.48394335084922,-19.388837219102655,-64.14740045581348,13.26072468611423,0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark63(82.4976958659374,-63.14700019439423,44.24113918625926,-55.48768041181371,0 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark63(82.53234035355956,-16.706594788196426,-40.30236258317175,-69.80899120428698,0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark63(82.54563069266078,-28.675242969888288,22.76993982430362,80.79534651880286,0 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark63(82.55770272854087,-24.808836413049136,-15.230146489085556,-25.082401586205137,0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark63(82.5725010779538,-71.48058494084765,-20.243420451742367,-18.557782497716772,0 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark63(82.57394453159958,-26.316237058122354,-57.27177908711805,70.51066017919507,0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark63(82.59609153647926,-45.662744578291715,-24.93568758903453,82.0019629503779,0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark63(82.63764412510727,-46.78312536076752,6.019122021997418,-36.13568791282582,0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark63(82.64889883570027,-0.23972861816947955,1.1290772758060257,-40.816323409390186,0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark63(82.65886606203117,-13.187306179625935,96.17031670196153,41.22766723467592,0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark63(82.69343196040339,-44.47957257683719,-20.306249623324817,-12.094688024228944,0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark63(82.69474304417841,-61.58880637876034,72.39450242531356,35.15161581815542,0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark63(82.73332464143994,-75.4525056536937,-56.06470693344845,37.74812704369077,0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark63(82.73658182197241,-14.798496317498604,-84.83260503458658,33.32063887265261,0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark63(8.274927941948235,-2.2875066531871084,-1.3646432619781308,35.853907829976436,0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark63(82.77509532910389,-71.64716173394821,-33.065575367561934,97.12905553064886,0 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark63(82.78255757023484,-37.200554756221614,83.89102015790866,-38.631598380510404,0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark63(82.79632011588069,-55.4713408886633,-65.24514517030744,-10.469937657692398,0 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark63(82.80334309030789,-12.77128146576014,39.3635580120868,-85.7320420064214,0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark63(82.8049703157734,-50.98799102456122,56.263292158487815,-72.42537706530501,0 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark63(82.80971830384627,-59.991107744827346,25.349925599682436,-60.11726607262098,0 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark63(82.83060397143527,-4.997649617606427,43.336143459876325,-81.28494158523483,0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark63(82.85074641700672,-34.90125632872416,-2.6104167803291602,-65.27517398346944,0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark63(82.85631687587869,-81.26164959190308,-61.153265691483604,21.415422059714444,0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark63(82.86692496520442,-10.249745680578243,-20.9088746503531,92.30732761394685,0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark63(82.87077800665244,-43.826913864150626,-71.12332511271853,-35.238507560695126,0 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark63(82.88654392621635,-22.213021657625887,68.05514187535701,71.88854415971309,0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark63(82.89576620063087,-16.851529221564647,-10.30064880283632,-73.31429040359274,0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark63(82.92584351293672,-17.760241179713816,87.43254155773562,-28.595587975819583,0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark63(82.95560577929132,-14.03803518682534,-59.32381624199632,38.849975737174816,0 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark63(82.95648241679544,-72.33883684268312,93.75841233503263,-92.36132132251984,0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark63(82.97460862336138,-27.623934297144828,83.57356435648464,-46.40340997346246,0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark63(82.98189206754924,-29.34597618320396,-51.909327704867714,-49.85149252775199,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark63(82.99725624858195,-39.62507470087937,-45.954950972484056,52.23881497965982,0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark63(83.03264671580393,-20.67765018241407,5.522367771517935,18.258789164334814,0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark63(83.03649350573696,-49.59587559504697,-19.55381324935152,35.12599727425797,0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark63(83.05507172494401,-14.823750398147453,-72.04704175659322,-32.979271420693564,0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark63(83.06144823245091,-14.298340268247472,23.296612906848395,-7.722933778758929,0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark63(83.0806422726283,-70.71919496618793,-29.17917611382819,-92.03424160877098,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark63(83.12526838774448,-75.7204432899184,41.002336175472124,73.08851526172592,0 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark63(83.12939504186105,-23.970842554882225,-48.53980455374523,80.80464738492137,0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark63(83.14133750644388,-12.719420493129618,-21.03225799428698,3.6083065759187036,0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark63(83.15287749885408,-4.211737940103603,-29.578161681026273,-23.68295333113278,0 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark63(83.15629851454261,-46.244562736730344,67.69438231539777,-80.79856339816925,0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark63(83.1877953065015,-67.89520950762957,89.01881153533938,-56.37430474597198,0 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark63(83.20577610084473,-80.74718845358572,43.02512728581121,-4.3153719299006355,0 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark63(83.23098852185205,-48.94310489747187,-88.30714561550673,-64.63804409237503,0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark63(83.23920930839682,-74.44314309097943,40.72020420888845,-21.12879794891427,0 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark63(83.24645423687372,-31.109770742548505,-71.31212939174762,-58.047368123059506,0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark63(83.25018417227841,-73.32688946517456,93.15675716054204,89.72811990458095,0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark63(83.25861522043982,-78.38129232242936,5.314213178451112,50.832630675272185,0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark63(83.26401407102372,-33.81092286001501,-18.514658376370534,-63.83381032196054,0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark63(83.2898875193114,-76.9564205397948,-32.47475302807179,-56.34953564337795,0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark63(83.29863553030293,-22.62112909735707,69.02552324766978,25.61562780727033,0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark63(83.32159222217973,-5.341795121485632,28.73082747083444,99.53515099910803,0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark63(83.35975549919854,-64.41062372268482,65.47480733796212,48.30234857767212,0 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark63(83.39366075429626,-0.2944198690925077,44.65640442583788,-22.353845322164673,0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark63(83.39496080465298,-61.49417229738434,-6.175160810691011,57.14471710928839,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark63(83.39765771586457,-81.95261627707433,-72.08444754151793,28.971018055159675,0 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark63(83.3979642377704,-25.27808202408599,7.66031608303652,-62.75176055548539,0 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark63(83.39994843050644,-78.68545204377375,-59.38369041511811,-98.1490160473885,0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark63(83.40178823312712,-22.54098019123043,52.16370743692525,-17.23694341640656,0 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark63(83.42149434649343,-31.995792692198137,24.524682897176532,-12.01419024532045,0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark63(83.42915618103669,-64.95648608845332,48.36659956043755,95.2783763429866,0 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark63(83.44249282006416,-1.2086848616068409,2.8823630106077758,-80.90268712291923,0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark63(83.4872436138815,-80.38941730848543,16.26170813894862,-91.06105440468049,0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark63(83.50325247738954,-55.440402095444185,-25.27892785692896,-48.16527412587514,0 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark63(83.52671610378007,-19.522367334531964,18.55373541733978,-35.34374689452882,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark63(83.54065844188807,-66.97212999763151,2.8368875860015805,91.47024345066069,0 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark63(83.54961524948487,-34.3250285387072,-93.59308245187164,-39.79438863794071,0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark63(83.57280745544978,-6.132813203878868,-43.497139683183825,54.422088433423,0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark63(83.57450443855873,-32.99632667459427,57.426492008448975,37.25048249233035,0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark63(83.57478314657865,-50.747236284586506,99.83655187356038,77.05184425579245,0 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark63(83.59264782192326,-35.82775262250037,-15.797285158919877,71.73810299356325,0 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark63(83.59651297999625,-1.9596560170835033,81.35268566450583,7.969184044864733,0 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark63(83.60373905780588,-48.84461275392018,89.58915969591294,-70.9570212489316,0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark63(83.61651843916405,-34.14245060691219,85.31198831468717,57.12301429930906,0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark63(83.61997345833896,-67.81179212994095,-7.705194547262479,96.79471009921042,0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark63(83.6484970675327,-13.423585920987819,-9.604632447746852,-76.21272060409945,0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark63(83.67805914976395,-68.66355384279535,-57.68813111051039,48.76797840400343,0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark63(83.72607857705472,-36.00935198554358,-27.503774738144344,-71.12612599756673,0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark63(83.75884742641304,-36.840846971570976,-40.661887330608806,-18.863043049466867,0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark63(83.77464519510093,-83.80108735290257,50.57435342433254,-7.0146626291226255,0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark63(83.79017125619612,-41.83087550187503,98.61178615704449,-48.29985342329481,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark63(83.79870220171657,-39.71183342830567,22.2426065966298,65.70750817439065,0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark63(83.79899450908721,-82.33778830036991,-53.30705674837017,-66.43778541866139,0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark63(83.80024865758492,-55.316649844905854,54.39909509461867,24.622748283748265,0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark63(83.80045185707769,-16.685125259540172,96.4436468036713,-38.479211396536584,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark63(83.80883436173895,-17.255779685814915,63.11947574330341,-74.34461334760185,0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark63(83.81233265458246,-67.41918621332808,27.573869000120865,-8.332900752678498,0 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark63(83.81403969699898,-54.37005598893803,58.19197991926717,21.00553944714764,0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark63(83.8327395518576,-12.243533416715891,-11.423241024164483,69.68453657670565,0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark63(83.83470471491,-59.67326991725675,-76.9888862950394,-69.8386742274057,0 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark63(83.86798065693887,-66.28015617501416,19.072247525053726,-3.3735132900508233,0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark63(83.87266640521463,-25.913723342707556,70.79593584960503,52.92640984617486,0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark63(83.87449060736716,-66.6610390049196,-13.693162390684904,-72.13871618666573,0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark63(83.87707297029809,-59.62172114341637,90.94332699822269,-93.0207398083154,0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark63(83.9046766826099,-8.355916161133877,-44.527689520776256,14.15158504254346,0 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark63(83.90706434949519,-47.015653047064276,-6.646679511303404,94.02492123032172,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark63(83.93607287248756,-2.6380373290514285,32.754444648474475,40.66945278356016,0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark63(83.94044798609656,-32.75088744507377,45.680616198402475,-73.62731338205975,0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark63(83.98581606239298,-78.81930259513288,-71.89075266101398,-18.887434876432835,0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark63(83.99994044651336,-25.919407110748764,-62.73765542984684,82.93378040233989,0 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark63(84.083756404096,-58.50096963507874,-6.199935539602052,46.97427398669663,0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark63(84.10837597218105,-65.82892081221432,45.271952120353916,88.65699985156675,0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark63(84.1102808133015,-29.10034499690721,62.38102838810201,-26.161627824436323,0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark63(84.12983383304478,-77.62441883312403,94.90695028687688,73.12281488013971,0 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark63(84.13411654101643,-15.90862620793925,36.12744687833879,-4.09949417593856,0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark63(84.14739606848417,-32.9450628336603,6.016459226725203,77.2419174518443,0 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark63(84.15821472282732,-40.480692748280035,-61.23672160759839,70.82318253800585,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark63(84.16009324487356,-29.63129227048003,47.725104425038126,-5.075057450265803,0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark63(84.17972088900137,-50.40834117984776,89.67572574296469,47.138138207318946,0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark63(84.19381356100706,-28.93056568353478,-84.02177732586958,94.55919997147097,0 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark63(84.2131524265466,-75.58215390366854,-36.66531987043295,-80.90836298762991,0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark63(84.2178700711718,-64.34582714287689,-82.6920295702624,37.63292010970258,0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark63(84.22559389383395,-72.92033332730719,81.36412156266789,50.634187923482614,0 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark63(84.2361253255097,-35.20148862920496,42.722416088880095,79.97773494789507,0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark63(84.24971412437515,-80.24900526884709,81.04693153784586,-23.711427056335822,0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark63(84.28812341606675,-47.50892039766801,-67.43827580951267,-47.662339242229464,0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark63(84.29527338983647,-78.84938094291189,-27.801960797286185,-50.406462413227885,0 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark63(84.30428287264417,-80.65052045324059,-9.132150755544359,0.5872366311673289,0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark63(84.35478018059788,-55.819610041355936,79.3532829387963,59.77582886447749,0 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark63(84.35997156704505,-0.7069232558516632,71.21150809728294,21.999699860041062,0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark63(84.36474329048752,-26.208809101818204,-9.14547666021592,-59.876763383192674,0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark63(84.36887087669368,-44.99311669232586,-35.993843504910814,-17.34929212296956,0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark63(84.3703164114554,-57.44895414948499,-84.15373553878594,96.96622055350758,0 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark63(84.37347964214763,-53.74545856264425,-43.7884799460172,-15.522457048270894,0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark63(84.38141981514781,-80.14035979113359,-62.011402197350705,45.83711587553017,0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark63(84.40798244588146,-9.925339881837274,-76.2263401617438,1.1556895589006189,0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark63(84.40832044846667,-57.289610365883426,-99.04094704172046,-12.724937290846512,0 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark63(84.42436846483827,-63.26054770543501,-45.779560307890165,38.8869385153981,0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark63(84.49750086781725,-44.23954612364716,-73.16627503379584,-75.74605128276832,0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark63(84.52467188121207,-75.4068405569193,55.70706752762712,68.41102047772881,0 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark63(84.5302149771014,-67.90846820395085,50.14852601134109,11.83577302985708,0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark63(84.55161795689418,-20.69408207161881,6.920755178032152,41.25212754491744,0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark63(84.61580038551116,-78.97496776525166,65.05841616574008,99.39646010578443,0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark63(84.64068147954643,-28.106437521986294,-16.10672578011814,85.43404331655532,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark63(84.64993231419257,-46.784970550206026,-19.3830485614577,31.504234451454693,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark63(84.67396310671072,-60.08512216639523,-91.52622626936588,22.48221031741538,0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark63(84.68385323778688,-26.945754883770448,69.29323278953945,-1.0963029054855724,0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark63(84.69936033681407,-32.45240818237636,-15.784875525102393,-85.1851201938441,0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark63(84.7245000049846,-29.591374775342302,-30.75599639272602,75.0893328674322,0 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark63(84.72465848641158,-57.74165008741596,64.72559008315463,47.23174022344904,0 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark63(84.75154153059543,-20.137404380452722,-69.01469626244065,-66.90041168444665,0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark63(84.76450274853792,-57.95884860787508,76.36154244249153,92.17122905032838,0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark63(84.80074211082481,-29.0190067167089,59.78234417068143,46.10516413297432,0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark63(84.81896017165064,-47.371421141903134,-71.23979442657631,-23.181346624059884,0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark63(84.85455685574374,-45.50214004051032,6.807467690932228,-30.082549969218263,0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark63(84.86379230217801,-19.745079545667977,13.567675520181098,-31.780973971774202,0 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark63(84.8681589879559,-58.30166274080631,-7.8683772557423595,-56.973439977733854,0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark63(84.87104645693475,-11.420172510519762,5.136576752247862,4.960296395835655,0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark63(84.87867619933925,-28.300856897082994,49.798557280829414,-2.931953327273746,0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark63(84.90475606275092,-41.269958197098354,12.048643804831528,-40.95407073148329,0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark63(84.90813034068813,-6.76259028827711,38.64734721965527,-87.9869317701089,0 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark63(84.94277365526474,-44.79862216857238,59.85807636304855,85.51312746523766,0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark63(84.9580202988844,-67.51097257694481,-18.15485158738919,6.476368714203545,0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark63(84.96280031980666,-76.02000207074116,-99.12158269353321,-28.224048017789087,0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark63(84.97518319087246,-39.22503436602183,27.03949096655596,-35.38677006636486,0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark63(85.06451912530116,-67.45111664806433,-10.184191881357975,3.230490682198166,0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark63(85.06754047438312,-39.66569382927321,-75.67988868043412,26.453067184519966,0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark63(85.07053617311462,-53.45742488265519,95.06437666355762,76.61220291561236,0 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark63(85.07165030113367,-52.630649371524285,52.732708313389935,-35.542785413160274,0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark63(85.10720303148324,-19.18856097130002,89.43309907931015,52.90212618299793,0 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark63(85.11490222195354,-42.56406864892448,15.35476372591964,-19.00802579944454,0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark63(85.14427230371956,-40.32530749823637,-28.710693950494743,-34.217169285899175,0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark63(85.14504315118552,-5.052381699129199,38.490425343638066,-67.39619559885901,0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark63(85.14949304067733,-38.705469527299115,-18.876858181355118,46.308886958093865,0 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark63(85.17853342031756,-24.92357586201483,-48.34442130765484,30.786197933103523,0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark63(85.17938623644909,-44.84484764637904,35.71606078264642,59.24852444186183,0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark63(85.18005918896762,-30.57416114656597,71.58994951616492,28.28635402272687,0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark63(85.21452726221673,-35.872184329918255,24.771964333076994,68.43329115399774,0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark63(85.23696017771974,-26.965549875975597,54.673964489681936,-4.829988201339887,0 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark63(85.27008067738896,-45.69522413402836,70.5091218093603,14.539385367645963,0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark63(85.29615223688683,-53.35711023597665,38.52484897448019,-96.15501291900175,0 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark63(85.31457644235863,-31.4972832863249,-93.69971796188486,50.455543258544196,0 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark63(85.31635340092467,-56.722421824759174,50.588486420097155,32.514126081153705,0 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark63(85.33251635300098,-61.07343486884902,-17.912016328928047,61.983796054356276,0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark63(85.37455813097233,-60.42455968108293,12.555908379807846,-21.083165954002297,0 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark63(85.37457302289823,-58.880495783757226,12.189618749852002,78.15015624105266,0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark63(85.3995680736206,-51.469462855988525,-40.36211956873419,18.56913056654996,0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark63(85.40946722063634,-50.36267709560009,-24.693726992996574,-27.120023092530474,0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark63(85.41000166670764,-76.12889795106601,24.508609168895703,-87.14817841400276,0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark63(85.41333490621093,-61.839212042286526,-9.695831344160055,80.28676116331093,0 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark63(85.45436305785464,-27.366997605366265,-24.230618567062663,-90.62664071184517,0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark63(85.45782040072646,-14.105158168845762,26.150591894283664,-63.71335207367257,0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark63(85.5085621873503,-90.22248787919547,-32.6997606285334,1.9387464694755323,0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark63(85.51004592870603,-21.202765969068565,-76.97239811250557,72.40521005180935,0 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark63(85.58424223594642,-43.97946631538938,-54.976052104636985,-51.10367255921575,0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark63(85.58716944968202,-42.61009591496012,-51.86542081301233,-75.24008549321954,0 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark63(85.58954142870897,-26.347453497860116,25.81782160329395,-45.38658910964772,0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark63(85.60210597607372,-57.25666637250466,21.231419743680817,41.785185495678235,0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark63(85.64044566089609,-65.37293132378004,-1.6140961574605086,-88.59526233000683,0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark63(85.64080826559547,-25.39619625418517,14.340386599104264,-95.94201405330105,0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark63(85.64568017635307,-81.03374379965717,43.650907003557734,-94.88363462597948,0 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark63(85.67505658315352,-67.12957129364491,-90.2358745546011,79.23504037100477,0 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark63(85.69283245619934,-34.62928340870623,-35.271177744664016,3.976873250686282,0 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark63(85.70729304153022,-13.692629008205472,-57.53293052660027,-9.367659998470756,0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark63(85.74784010003347,-82.60801285999699,-65.9351231083713,38.15879749320905,0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark63(85.75235159598077,-63.67676223997596,69.26055479445895,-24.478422653179493,0 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark63(85.80734608412689,-66.72148400306219,-14.05060330641625,3.702397918691119,0 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark63(85.80777181871767,-10.981360230316014,-90.17211907335279,31.821429354529982,0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark63(85.81171156235399,-8.399390248805403,-66.3978286181949,46.16166960578309,0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark63(85.83643469169968,-46.70993608082836,-54.80146620938582,-2.361625751351056,0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark63(85.84156217860021,-51.739963704098614,-70.72255762461985,-91.41013092544692,0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark63(85.85030721929863,-16.34760062264533,61.18244509101433,-8.76508699508696,0 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark63(85.8589346610294,-10.346890843075897,-81.69705862494033,6.382029719007747,0 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark63(85.87501575375364,-46.70773878339853,35.77192370971429,82.75432586514702,0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark63(85.91120089034959,-47.16022912664988,-18.080771282367337,-81.76774418668683,0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark63(85.93286406850561,-64.04440231348943,44.16732683218817,71.52225269822668,0 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark63(85.94000976912233,-67.83672215414128,59.88884272777884,-41.056390829754804,0 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark63(86.00410950667731,-36.43224739209418,-95.0378529730956,32.42346976581629,0 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark63(86.04149471023874,-63.30909911042761,69.47521603055401,-85.72438305237257,0 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark63(86.0624171036776,-55.26377650007453,45.28111775367887,89.34616058706422,0 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark63(86.06384804624457,-49.18131617608299,79.6942184190471,38.28583961320919,0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark63(86.08058911820885,-70.7685141651492,90.2523712687931,-0.22491282658891976,0 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark63(86.09524755526118,-37.04453683202911,44.571581772015605,-43.67915711733175,0 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark63(86.09833027650205,-15.624048030621424,-30.94731532737312,-51.305513928780066,0 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark63(86.13138350699322,-60.49968611712644,-15.414717952218155,44.592175351182675,0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark63(86.16243188752591,-53.148390276686186,0.20024688866664064,-37.89287944518895,0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark63(86.16587486875889,-85.7390568756552,83.78529857932767,-29.939418019409473,0 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark63(86.16708685361834,-38.42439236086022,14.072356596727275,48.69543972315901,0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark63(86.17108767994935,-54.857045967638896,50.171719077385745,97.64498997949892,0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark63(86.17931109154043,-29.728140374902807,66.48639976406466,-53.86330659128045,0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark63(86.17969660857591,-80.3785039008282,94.16339453470098,-36.49173750117003,0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark63(86.1861525265848,-18.94872489031718,-76.1246109316476,94.20842009131906,0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark63(86.21722316063753,-9.72339030589464,-89.24128490922818,76.65538107739175,0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark63(86.25931793916368,-21.46153805567333,48.286543877398884,-62.05809280415864,0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark63(86.27255042332877,-50.573215996523736,-92.01477640426549,53.90308228317383,0 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark63(86.3065298555504,-19.169782987577037,70.39603728650687,-51.4368004462016,0 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark63(86.30669561781917,-26.135249972198892,-97.10993135019508,-36.61261901606132,0 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark63(86.3069405468278,-5.821788873244913,49.09446714302851,-60.40939080010996,0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark63(86.32012255970369,65.4045497364244,-6.685599837363938,-14.803361075854,0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark63(86.3548056458331,-64.06853054349087,-78.91425932272867,46.04643784025615,0 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark63(86.37309630938313,-69.55490007683011,-96.15590457148511,90.63660714597737,0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark63(86.39753613392708,-47.83414045936403,36.73504337958718,-67.93869115919557,0 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark63(86.40343274655348,-33.624566432020345,71.00401177470508,11.56094312652074,0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark63(86.41313779800058,-20.33888600575567,56.502863751299515,-53.68605234402322,0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark63(86.42957751320591,-73.17870439003727,63.08486166537514,16.590727522631553,0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark63(86.43920663520294,-8.993848509689983,99.88912123654737,-57.39142274705884,0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark63(86.47092131335634,-85.95829511556575,-16.686218529536887,-97.91045943269371,0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark63(86.48213479403137,-21.10657922106678,-86.50082111548392,-69.79321698618419,0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark63(86.48668536745438,-79.54412581479859,-51.047379124304435,15.883960073147236,0 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark63(86.49376290206214,-60.29029608791423,9.640739067883871,-34.854414889396196,0 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark63(86.49521356141895,-32.118783785325405,28.743903331905244,34.56124250416508,0 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark63(86.50304398084273,-11.145626020405558,70.91249645129824,-73.35222031390003,0 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark63(86.50352434506436,-33.37048856277032,-87.39624063003654,65.23374518060268,0 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark63(86.52385758929793,-46.89674777698563,-28.502175713748244,-62.95770454728935,0 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark63(86.54862888831755,-8.409330476672764,-36.89893538426241,-15.983836816816122,0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark63(86.55357691091993,-68.74127698176598,-56.4921793911554,95.14344874739297,0 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark63(86.55420217608213,-60.69484874227431,-2.1642169078334206,47.51839299367904,0 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark63(8.6558606181909,-3.3617483574628864,36.28218618913107,-36.96316574573517,0 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark63(86.56007137174916,-15.413294276655094,-71.47995057036071,-79.6836906555848,0 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark63(86.59302132287448,-64.872025571508,38.50562948685615,-34.187751961267864,0 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark63(86.65263241517138,-55.87097585720997,-42.160967429855376,54.58166312070608,0 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark63(86.67834430282184,-15.481408557420707,-15.654721001784083,-96.1807064621239,0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark63(86.68900530230746,-31.987405676154964,5.948619849559634,-46.627315003850825,0 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark63(86.70092932329638,-31.201119839019583,-71.45127868908114,1.916476222511605,0 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark63(86.74549329917585,-11.248259457970946,11.11372407626348,-78.1674977891359,0 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark63(86.78141390605089,-63.339613987185864,-63.449423691747356,-36.86030542213994,0 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark63(86.79161295558731,-21.26342378728043,80.44147413139143,20.95879544600521,0 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark63(86.79227199343472,-76.45488918344472,-85.52554064767715,53.901558069927376,0 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark63(86.80197883096125,-48.29451849583655,30.38459628840141,45.953089308376235,0 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark63(86.81008351408116,-62.75888894083368,19.98977911536717,-13.383413209754778,0 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark63(86.81650586971139,-76.55094186253943,36.569535366540805,22.52262727796426,0 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark63(86.84046856429646,-63.40732027176112,77.46454049762079,-74.19526852940155,0 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark63(86.85558194755953,-43.071048555090144,-97.10920517002863,-70.5263605076585,0 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark63(86.87673020815299,-73.20736431956054,-55.11461136188143,-49.56965154206392,0 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark63(86.90203529854935,-77.57820070361596,-81.89326230600018,-70.7783654822685,0 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark63(86.91452771264687,-86.214761742056,15.927415096440427,-86.69419577227593,0 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark63(86.93964599878942,-54.584450320071866,14.084579465069297,69.06705662876297,0 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark63(87.00623997860347,-81.07310705396512,-51.393854288606654,71.72047170114303,0 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark63(87.01126180459502,-14.658207763401293,89.71529350967643,52.973978214593586,0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark63(87.02306949363458,-47.091934240498624,10.832852442433975,-61.23018609961579,0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark63(87.03319350806478,-34.32472284780876,75.11786732164322,-62.155061601188734,0 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark63(87.03694444607996,-55.89214644668312,-75.69750858039663,99.85114270073964,0 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark63(87.05539282017025,-13.074901228614593,-21.81486722204275,28.10239758535556,0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark63(87.06129161692436,-0.9340375576267945,17.336344071759697,-60.28128811407916,0 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark63(87.0663303599762,-76.45350782844432,-30.463685024837545,-75.05367599391575,0 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark63(87.06798084606581,-33.019242429641054,53.3810835128067,99.41643841976389,0 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark63(87.12480011351872,-73.46582201428771,-63.24599676433169,59.31322904795516,0 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark63(87.1283678810965,-36.18483803054762,65.23975093152075,-7.228358386606828,0 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark63(87.16393287319207,-27.183003655878338,7.473223355109553,-22.097823620110375,0 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark63(87.19510884044328,-37.65715203235229,64.2655757870258,57.10755180685004,0 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark63(87.20239852810394,-38.44002943004941,-82.12347490243653,-51.1753396136438,0 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark63(87.22398939572861,-18.506306633193674,26.257849247785757,58.401217495929956,0 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark63(87.27997028111534,-20.98211230724138,-8.574368744756853,-36.07825077112092,0 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark63(87.28017755088314,-68.8583694764314,84.11826053930864,-47.72840552573858,0 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark63(87.29773729382481,-69.79181864841316,73.35467694913751,-10.627061338809767,0 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark63(87.29901202455923,-11.017560462795473,-46.03613398249004,51.08646482901676,0 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark63(87.30423987654711,-48.767927371212316,66.75918645610284,89.11004842163916,0 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark63(87.30448348171592,-78.24470155270555,-20.315552495615762,-95.44086271360561,0 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark63(87.30574509099301,-50.128813797312134,-84.87402185969125,-7.799252377598847,0 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark63(87.34860130412511,-1.4508803643685155,91.5000189983516,-44.586686204109924,0 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark63(87.35369221196433,-16.64385659925658,54.36287266541879,-98.85341345151559,0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark63(87.36373074314548,-83.90426822748353,-51.320146322795935,41.0970047347526,0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark63(87.37029429788214,-14.288873553333929,7.226405939654867,-84.77715046783507,0 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark63(87.38264525579632,-82.03781716387991,-8.092399891506503,95.51929124132508,0 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark63(87.39323995666155,-22.85942586024869,47.3826631302328,-95.94272053988084,0 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark63(87.41343253954369,-70.64052202333491,69.55039437106515,-58.64938514359981,0 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark63(87.41421960267323,-14.280794330567304,90.03844642542532,79.62184953146271,0 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark63(87.41779316039649,-71.96943237039497,20.495949304042682,98.31942133113452,0 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark63(87.43721800857574,-73.41659461841289,-10.154358101321634,5.120297856611529,0 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark63(87.44762716556227,-38.55780179108075,67.46268044288061,66.49300356424712,0 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark63(87.45782812443278,-49.429814564386795,47.21929739633856,-96.67861819217207,0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark63(87.47760005931826,-78.64323968162961,-33.857579179925025,39.87841730261806,0 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark63(87.4902004221623,-33.399470676145455,-15.95110689949351,-62.75370295008542,0 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark63(87.53003719343579,-40.098634089864845,51.05240381804023,-46.3719570381619,0 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark63(87.53920628475805,-20.26216591440742,38.28477354948183,-97.71663585729257,0 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark63(87.55071525141724,-53.3844212119204,52.02441442725828,75.07806465037007,0 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark63(87.57650750368967,-9.410216424588484,-26.560250173520615,37.68229989490234,0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark63(87.62325921876928,-30.12634693489929,-35.50006168587545,-26.712482368805126,0 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark63(87.66722843331786,-55.034044716554355,99.0791978286137,-46.74688926140562,0 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark63(87.69591583856277,-63.07518882858319,36.139827798374796,-95.1688471949818,0 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark63(87.70458476507329,-46.16138665963951,-18.37098896315763,-24.41390216176748,0 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark63(87.71796795162169,-43.2835127671541,37.04457353406934,69.07896887557987,0 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark63(87.72516504218305,-78.02266323352869,85.46461412226262,-46.38873129228227,0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark63(87.73366717110622,-19.072402242339265,-92.07260140197695,-73.48982344517685,0 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark63(87.7547154865494,-24.926194152228305,85.29771749798232,71.42028818018156,0 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark63(87.76775479444842,-39.67151011146686,-67.87082292299198,33.86564866464431,0 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark63(87.80523927865406,-64.60822625859714,-75.14072537026846,-38.884802284627476,0 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark63(87.82964702029926,-42.98316814788152,94.30122734755415,-38.85595492922136,0 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark63(87.8379226000041,-85.35662234983053,-17.676398866490047,30.93793381176158,0 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark63(87.84497672388656,-80.0975950845708,61.52281675841988,-54.57211833051456,0 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark63(87.85579343621973,-24.350561486295774,17.275653314920334,1.6641730682697329,0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark63(87.86136113212885,-15.587490655618524,-97.73056418399477,-68.79082580199645,0 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark63(87.88039008264013,-48.15289487854004,-53.68905449632027,29.47111977421602,0 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark63(87.96372025793005,-75.5301010371463,-55.01143434366955,-64.90785192463579,0 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark63(87.97481402581332,-65.50407893679531,34.270979796594986,-63.421949494608,0 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark63(87.98403642951843,-47.43168325442619,64.95444154331994,-48.46455945225217,0 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark63(88.00975876532837,-47.606734091276756,-81.54191482109361,48.79137574553616,0 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark63(88.04005088743452,-78.06802908459983,91.61354622085545,-21.191196880719417,0 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark63(88.05114725807272,-49.08322180936268,58.119650477724235,97.00874984913835,0 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark63(88.07556478479276,-76.83709953116752,-34.77157588965302,24.100496536157507,0 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark63(88.15603544041082,-58.999428797789236,-6.844017805046903,-41.121205525413075,0 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark63(88.19492685499566,-41.80700541733877,23.917086770554533,53.68902603059408,0 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark63(88.20030375085045,-79.72602780851284,11.683970335327373,9.365282630214168,0 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark63(88.21442019674853,-70.30943718998603,-74.16384223835576,-5.020758091695569,0 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark63(88.22371842992814,-38.721263399583265,-41.91122098594959,-30.666832974960997,0 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark63(88.25683741410225,-43.786280034426596,-50.984486607218436,56.28084071065723,0 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark63(88.26600223256654,-60.0945460507529,47.46132394830545,-91.32297419852561,0 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark63(88.31926793197357,-34.50547314928511,-69.94857247943003,77.06672421116951,0 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark63(88.3588745711036,-42.53997578455176,2.283564579001009,6.919443567945095,0 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark63(88.36695395672771,-69.51865341227266,53.39852814626346,-89.67058281714895,0 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark63(88.37222450331751,-0.5900738714216658,71.34497409591481,10.009943600019284,0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark63(88.39087838182513,-9.309927466497498,61.21564188146377,-31.728405190328132,0 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark63(88.39528648303465,-45.72592799472268,98.21724080512641,-36.40052650931238,0 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark63(88.39607758225185,-17.014031729994798,54.467966076572424,-88.24875853653003,0 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark63(88.42274698341151,-8.060028605190638,-54.21610289761611,-48.20061977259045,0 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark63(88.50254049123674,-64.08334562885294,-18.679920949664236,-80.63981044637885,0 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark63(88.52862815399453,-15.891903122633806,21.95720634924156,56.21384729822057,0 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark63(88.5319626568548,-47.07309897754533,22.24899122127097,92.36375017157968,0 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark63(88.53517220593619,-16.167713819005016,9.423419260782012,24.947945022246685,0 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark63(88.55893325169305,-45.89116519890186,18.781040662030307,-23.305317193688353,0 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark63(88.57577250026824,-70.01221755370197,-33.58025572485744,-63.12071597033611,0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark63(88.59811786360535,-83.76844177318821,-57.32137336270535,-18.254996741212224,0 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark63(88.64026335397716,-72.20145276901835,-11.402683421264783,-52.661879529034515,0 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark63(88.64527470735246,-57.44802707300376,70.16193586219126,-43.455742114154106,0 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark63(88.65309971986031,-28.495165175082235,99.38700942282884,92.68193999790137,0 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark63(88.66102144798938,-55.662085722071744,48.14385124409179,99.68195018841689,0 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark63(88.7369741612319,-58.70208617460286,26.709215764927478,-80.19058958343649,0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark63(88.75718384597178,-45.92517583870299,79.31354759171248,70.71895178149236,0 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark63(88.76500681034946,-17.45114003206109,13.539133380937017,64.46517683244372,0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark63(88.76566965325173,-81.16818405778004,10.646446400656572,-71.519388632196,0 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark63(88.78078747352629,-85.11313699562429,37.91519476450529,-96.73888676649844,0 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark63(88.78205412835538,-89.26547865198955,-84.1108130158525,77.65207232271248,0 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark63(88.7839234025125,-21.679965894483615,-42.070831456256656,-47.06159237871537,0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark63(88.80817529665848,-43.22386181248563,-23.990726878297977,-6.94031296652409,0 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark63(88.82982275738209,-64.09545073000875,14.520548768063918,-17.66707955614379,0 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark63(88.84714412451362,-47.204147850179034,-17.745061866460304,-5.90794648534019,0 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark63(88.956528669769,-51.086483710272404,-34.10855925058189,-29.44967913624083,0 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark63(88.96339249627502,-88.24093027259417,60.12085254897755,-38.39649423095981,0 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark63(88.96631545394007,-2.409414240052115,59.84405193131741,-9.257415578535827,0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark63(88.97782665183274,-47.11418397801641,15.575869401414025,0.9463199857976008,0 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark63(88.98118859686411,-1.8669248329339325,55.04363974097234,-57.11820055065908,0 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark63(88.98142791730965,-71.92049851689808,48.23860216326642,-52.145242907209585,0 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark63(89.00026041698109,-23.630520175221335,5.576975122508827,45.21656351643358,0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark63(89.0003695778322,-75.4457705284706,3.6021992888724412,96.94485197569904,0 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark63(89.0358930136338,-50.91466774878208,63.70532445723137,8.464089624434592,0 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark63(89.04431418502776,-65.1646336394007,68.39180014374969,77.49884639162735,0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark63(89.06631378677903,-82.0495754001785,-6.6594772230630355,-40.85816766171308,0 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark63(89.07139273252372,-44.0811634718922,14.21292498516415,-83.41408265180827,0 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark63(89.07691940702668,-68.9542943026141,-14.752618996496182,30.29694464857468,0 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark63(89.09464094002362,-70.7506567419606,78.89696198631009,75.53773974706834,0 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark63(89.10169297115837,-25.45294176298418,29.63014046480771,-43.760469352889444,0 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark63(89.10612117455841,-81.46411981482176,-12.5442223336714,-37.446992811686066,0 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark63(89.10975764609191,-87.93100680133954,-88.53636343963484,13.268138035306691,0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark63(89.12280385075093,-81.54082075605035,58.63881828343625,82.3848165818736,0 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark63(89.12679406682443,-12.602522854254687,63.46273388778596,26.49532411838716,0 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark63(89.17162476468258,-10.997467612125718,28.787113181784008,55.33770539294147,0 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark63(89.18968507491803,-11.735673479479345,12.243908453333646,-42.974132880009776,0 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark63(89.20105163163873,-75.74389562682995,2.4332541274222166,13.47996668204658,0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark63(89.21132116035446,-88.59356474959606,47.59090256500386,-54.65838420447264,0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark63(89.21298731645513,-51.797697764293616,-80.86937253313556,5.539838747692173,0 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark63(89.21657010307788,-16.557119150510786,51.271215083971015,-81.63899121805096,0 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark63(89.22660672752062,-0.4497850539672612,73.19862355490702,-12.03793903886681,0 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark63(89.23365369898227,-8.569101644543608,-38.997756202424426,-61.92017835973702,0 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark63(89.2455167111529,-65.31951994091345,-31.203552962793253,-33.103274443048505,0 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark63(89.24586600156249,-85.87601831202144,18.012859284101552,-11.512502983899097,0 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark63(89.24746899337859,-9.263581596727605,-32.38860991895815,-45.08374253423353,0 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark63(89.24924862567346,-23.10839756877631,-98.55274915155793,-70.96964506357611,0 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark63(89.27176862026587,-12.139705344678745,-85.96000747083063,74.09461999870265,0 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark63(89.2975440650263,-41.467438804102954,-66.49431409968622,-51.17265530211077,0 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark63(89.30307534727447,-52.28941246026901,-79.97020042231568,21.7594871242472,0 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark63(89.34111645561026,-32.138393669247975,-9.833194199876743,-39.45812400162079,0 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark63(89.34280439074212,-81.91902614445578,55.18898865490053,62.611416223551515,0 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark63(89.35723052559607,-33.423275463995765,95.66708857475453,-34.005392455577905,0 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark63(89.39196718218861,-28.169965027433875,-80.63482737235623,-30.373227118059205,0 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark63(89.41840704762555,-71.55817140650083,-99.07627960001544,-35.0166350552783,0 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark63(89.4190283354464,-70.93864054993554,33.900848285411826,76.4407095670704,0 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark63(89.45533936146762,-38.108487037791065,-78.09835900826367,-92.62133365964293,0 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark63(89.48327927572853,-65.55519268262717,-47.583039113628864,51.1157928007959,0 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark63(89.49057685912865,-79.00546852222823,45.05563334182915,-69.30283357752344,0 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark63(89.49528120784947,-21.066421785337866,-6.774317821742272,-36.5967585844736,0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark63(89.55178589081405,-75.26064395429451,44.120311535879495,-48.01498119910483,0 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark63(89.56831274101026,-51.25581966417916,-94.45325705056663,-48.128131341246984,0 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark63(89.58600983228996,-28.946509118838208,77.88529173126989,-84.87926966268378,0 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark63(89.58914598264977,-9.063831529497833,-73.49604607148265,-46.92244953664988,0 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark63(89.60188788821714,-48.93137912490184,-33.73222301156022,44.06438675485836,0 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark63(89.61232911441533,-56.507877031656136,7.631808703903559,-56.81948548012898,0 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark63(89.62650630856817,-46.47656211425453,-56.63501682011622,-80.08434501268374,0 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark63(89.62716852322669,-58.278838239853826,-10.850286764522139,66.98619797545294,0 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark63(89.69131236821514,-46.68091661649576,46.443351164200294,-48.55501449122281,0 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark63(89.70122583505068,-52.44933899050439,65.23954475081933,-95.1927023980345,0 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark63(89.72923624512825,-36.777418122881976,-40.26703386393174,-28.014589417677513,0 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark63(89.7367567123948,-42.489852841251555,30.817161206377705,-42.110983830455105,0 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark63(89.75976659583293,-76.88572845293663,88.46165038091067,78.4091022762498,0 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark63(89.78082841384963,-54.698153518645576,84.97937733118778,32.26384560175026,0 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark63(89.78835262791611,-35.88064729171816,93.21111879270595,-23.377925377342507,0 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark63(89.85886600032359,-35.23823339507808,-8.929102964484684,-10.422721668813196,0 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark63(89.86070882669128,-26.512864625388517,28.154593310167485,-48.728856332579774,0 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark63(89.87040018018226,-29.657777688412907,-26.045764052976978,79.15526367843003,0 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark63(89.87642145846837,-69.3265805871508,2.9674374963850596,27.767066439549453,0 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark63(89.89119851017128,-72.42181373456633,76.53194031515923,-62.416373404381595,0 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark63(89.90671448856506,-9.056269691383804,83.3395873169228,84.64538469280754,0 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark63(89.91821008656152,-42.08784383192459,93.98298137904888,43.01257480560125,0 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark63(89.98461118180339,-43.67039982086898,64.99957500551764,60.885906701048725,0 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark63(89.98739729203783,-76.39943943670298,-55.99206899291711,35.42766997615843,0 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark63(90.00753502366001,-43.4245851433132,-44.55005945272297,21.59482689600894,0 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark63(90.03836018495602,-89.14429852989119,82.96860144276391,-72.90187469418639,0 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark63(90.05612482408478,-54.468357421564576,24.68302767999174,-1.4570707269401737,0 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark63(90.05936519688268,-47.25093282772506,27.58102859543925,69.85364246035311,0 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark63(90.08083453029266,-60.78422936867718,-61.40684629423097,-81.88211778292928,0 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark63(90.10062630787863,-23.09121756376169,76.80869744838427,98.16291810918284,0 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark63(90.116288843408,-8.51793256551845,65.76136720255732,-5.541097395156271,0 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark63(90.17292765970112,-83.48551193595557,-0.16190161943600856,-4.13021848213107,0 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark63(90.17499325130757,-2.7076381089636214,66.3804723316558,25.311025715759982,0 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark63(90.18262408646564,-40.45927981001809,76.51513152617943,56.235546570023274,0 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark63(90.19504094139347,-85.4333950447999,-54.342165909226956,6.55557205285379,0 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark63(90.19685938096063,-75.6119342350134,64.73423175194591,-71.20755702101712,0 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark63(90.20603448090094,-68.03572491527189,46.95099742690263,16.238053728634554,0 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark63(90.24258411717994,-12.969860611170787,33.059182890484095,-9.801211444459284,0 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark63(90.25956040308424,-72.29982702018938,-8.871791339357785,-99.28384126404572,0 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark63(90.28128766141793,-12.739342901353652,21.93085310206797,47.59535475406932,0 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark63(90.28135280803804,-81.62993331695385,-11.712452033207924,-96.74599138382246,0 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark63(90.28477972322588,-87.16196133422577,-20.823626476266696,-99.27374358402943,0 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark63(90.33157633882104,-32.73367717315416,-2.0099840429339935,-21.095898176385532,0 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark63(90.38178918768534,-89.08211808010846,57.336618297875845,-78.84807724991765,0 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark63(90.3897148152175,-81.08623682405675,-67.22392960028088,49.57280559848326,0 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark63(90.39208966140691,-38.853748080551,-10.423337005164186,-70.99905834508844,0 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark63(90.4186704968611,-80.54003360508642,36.801573826784846,-47.85921891613221,0 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark63(90.42080159881715,-13.196768870724583,13.191036141060678,49.314013940093844,0 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark63(90.42947334377607,-24.745995954887974,-57.9183904013048,-23.85264525812167,0 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark63(90.43009495300373,-84.30698432989337,72.08628214381699,-22.986230711691945,0 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark63(90.45215521058844,-23.23730332839358,82.76758665606278,46.553083667749206,0 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark63(90.46062651626718,-44.01012494272207,50.581843918966484,92.35901196063512,0 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark63(90.48274376610388,-14.645567196868654,-68.03509174639933,-18.70221370961869,0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark63(90.53804491858773,-15.296582241858147,-10.653495248065141,-89.82212116132604,0 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark63(90.60154703865905,-30.299443935479715,-93.14520526283196,-43.01792543998426,0 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark63(90.62022371858393,-77.37482684888988,-65.41906270971862,87.83088009450171,0 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark63(90.62881830414696,-40.21274925145208,53.690113138977324,49.143930812398736,0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark63(90.63165355206624,-30.098972905922807,56.500875357855904,78.07171252687775,0 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark63(90.65705681109964,-62.60239620529009,45.73380380455811,-55.86846971924451,0 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark63(90.67078739412065,-34.22314616949053,-97.18460811197151,43.12035715867191,0 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark63(90.67793489126674,-78.63785060463576,-94.97823121572631,-15.472319208853719,0 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark63(90.72506478552981,-21.993908037516377,43.602112310415805,-13.978016317734927,0 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark63(90.72520609679799,-34.3204310661539,15.30157208715346,-88.10944410989272,0 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark63(90.77474829116315,-71.08558090000578,3.7483128262300056,-95.03975233967307,0 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark63(90.77536909016746,-30.280212823292302,99.36172262880152,-79.82857262998203,0 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark63(90.77810820205855,-16.705334886293727,2.178787118617805,-77.73128173754749,0 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark63(90.79039316889899,-54.27792737407324,20.705386399711628,-14.644155511908991,0 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark63(90.79297749497562,-25.731234669455944,31.883435444269793,41.834744529581485,0 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark63(90.80658435182622,-34.69038637808298,94.78451105022032,-40.925086719524415,0 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark63(90.81138744343465,-70.77117506980848,75.52452237646548,-35.466445120814825,0 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark63(90.81154844815319,-45.51808474037191,-76.34072369682023,90.0087984782364,0 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark63(90.81542918891464,-8.517208658860298,75.39192015122279,95.21192352705597,0 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark63(90.84920572700611,-12.837570626397905,76.20266922169742,-53.63805887414761,0 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark63(90.85511168035924,-45.583114613262254,99.26835194685654,24.97664119125848,0 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark63(90.85853391824986,-22.064155627810862,4.003498153002809,-7.963876990441548,0 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark63(90.86863410614535,-89.37976972027279,-21.935660696376246,-77.55240840179363,0 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark63(90.87352027192387,-64.38780014375023,-62.263933458301324,-13.75665379586195,0 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark63(90.89964019910278,-52.70687467589414,-78.20688512156184,-98.88510833418442,0 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark63(90.91967724618053,-12.294859201572692,-23.867457318208224,-0.43230172489417384,0 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark63(90.94177256356798,-53.93680525540074,46.27292337555872,-66.53127171914532,0 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark63(90.9652134598804,-20.759859107716167,68.01373429767702,-48.89938324082335,0 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark63(90.96631676954757,-59.81561253972127,-59.319651263065644,96.55500230569442,0 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark63(90.97830606715698,-6.236472006144453,69.05525945595883,-28.66294622522021,0 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark63(91.00237062812968,-98.17304450237185,94.56895635922885,-7.316051116805397,0 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark63(91.00545289528412,-20.083207227077366,-9.91562428691364,-24.43886592041811,0 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark63(91.0348619063223,-70.03047890698903,-97.08811634105226,43.74176326565092,0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark63(91.04127327047374,-11.531000791071165,-76.7215255389066,45.23255284464574,0 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark63(91.04391837461384,-37.41822820216072,-36.00567899983278,83.74596495797849,0 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark63(91.05653937450654,-83.63596322469438,66.05509480379152,38.393265224509435,0 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark63(91.08581484816301,-2.567128169201766,75.98998133322925,94.30699566229754,0 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark63(91.08890060568231,-89.57882594431999,77.81098781423671,-4.3403172237658225,0 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark63(91.10173781782521,-34.079141839520005,0.5626074759860415,22.2993151937132,0 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark63(91.11439307864839,-58.917019802714556,80.56848172334361,-17.893101732822487,0 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark63(91.12839705976893,-47.179382457608796,-21.86125139701396,63.701348933977584,0 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark63(91.13886287059324,-44.86757256429716,-56.31052468767837,-9.992396066438758,0 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark63(91.1555678321375,-19.382020720852736,73.61026337522182,-38.83994673605946,0 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark63(91.15853795575757,-79.63994802990177,-22.67278016597527,-13.879475755561586,0 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark63(91.1608047267444,-9.71675825980978,64.19186493521067,-44.41147741620135,0 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark63(91.18586380725259,-53.00116737406826,-33.51937583914406,15.67288453157687,0 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark63(91.19877923843913,-25.5663213906178,-78.30146498420149,22.719109643973056,0 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark63(91.22677107477767,-68.27199262864312,-70.01076765935134,3.073359132403212,0 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark63(91.23283890565114,-33.97288504749068,52.22528277025634,-99.95181836539764,0 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark63(91.23832130330351,-27.307253179024755,-91.50946818091336,10.726664376972565,0 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark63(91.24035034205988,-7.898780074901637,3.572401790383367,-12.971509835959424,0 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark63(91.24039017531615,-21.700274291330615,-45.22405103845026,-40.33048799028229,0 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark63(91.26579375578828,-88.15733475953031,-44.04460352449024,85.29980912846116,0 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark63(91.2739210471045,-23.283060395280145,92.95897225425554,68.8056329225729,0 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark63(91.28839803190795,-45.813575756825806,11.216087527899134,-66.90584244130702,0 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark63(91.30390057914451,-35.05527451207983,-19.982579793162188,12.492318421537178,0 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark63(91.32649849595572,-75.92381883929838,92.2777014330579,75.23033583907136,0 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark63(91.32862261691886,-12.335313112460895,20.247822118624796,69.5926333027488,0 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark63(91.33477445871202,-43.528607043946565,-85.79710502767844,23.49832827488531,0 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark63(91.33637018301187,-59.06633098656242,-69.71905374119507,63.58923757225136,0 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark63(91.34610670689901,-41.32102691908257,-30.477474775851945,81.31218572723557,0 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark63(91.35709951302354,-62.58750869665726,22.13341731832719,8.639172239358544,0 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark63(91.38681835339236,-23.70041620835805,71.60372943092611,-50.319614395465926,0 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark63(91.39009482171377,-50.63110280934593,-9.353024760331081,19.47279006508282,0 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark63(91.3918434823913,-35.500560012610265,-35.26157582639651,31.05830737912399,0 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark63(91.3951801674387,-66.74917651890252,-14.351773417595197,77.27324096531845,0 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark63(91.39800832039259,-89.2203599835199,25.92258199120012,-44.99600321422401,0 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark63(91.40234036048344,-42.54994645135388,-53.58393930325116,84.2782133415933,0 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark63(91.42623751862504,-57.81662900766005,57.61013363570811,-89.94302900152307,0 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark63(91.46936205621779,-15.790496281190556,45.27081843377931,-19.07816529949058,0 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark63(91.47464139027775,-24.538163473000438,31.919812920810415,31.803717079027507,0 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark63(91.48768831197552,-59.44328313852614,-87.13984860281865,4.2809147139871015,0 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark63(91.49826198008623,-6.453022989658933,74.68145302530172,-94.7014537369725,0 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark63(91.51379570182797,-39.478194594921675,-52.41958720766713,-95.83625334778102,0 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark63(91.5267916003213,-56.01665050241802,79.4722908296639,-15.313011766177624,0 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark63(9.155584129420632,-8.707919582102662,10.709770913141938,-4.203048596712321,0 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark63(91.55896523100009,-11.436678934133354,10.999350336818196,54.426035172797924,0 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark63(91.56426727566318,-32.157169318235006,36.40797459505279,13.518688281683168,0 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark63(91.57193920566482,-0.9355177249335895,61.62550098445419,37.91323265027404,0 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark63(91.57213430334366,-26.251534893476787,72.33198674730207,-59.346554901713766,0 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark63(91.59840201093078,-63.47535138560802,13.82343804029989,-46.98128037046014,0 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark63(91.60712614071241,-29.13911799469402,-16.737440240379,57.24834140318072,0 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark63(91.62838661762706,-48.46382148445188,-26.16287691892434,95.38073321745497,0 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark63(91.63158959975115,-37.225294334789936,-86.12825210419362,-63.97926441680084,0 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark63(91.64778975642517,-66.20911877750237,-44.34322171188045,15.741186164778426,0 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark63(91.661204427803,-32.101509907689206,-27.12039393807339,20.13951176301876,0 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark63(91.73131472534678,-34.40132645377325,3.6925380021499024,-12.224986189869938,0 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark63(91.74126521161492,-82.37012917861989,-71.7085676707236,-53.03302308061111,0 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark63(91.7415146432748,-59.39303692804092,9.654190389417266,66.549237175766,0 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark63(91.74705156149054,-64.69856866367735,-89.23418108753742,-79.07426212803767,0 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark63(91.75116204830363,-65.27914006529112,73.72964028465586,-21.466752951571948,0 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark63(91.75747087688069,-57.54429350368573,-35.06956949558257,18.018586669514548,0 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark63(91.76955687043696,-46.043238042344804,-42.073926470979515,27.22058971391988,0 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark63(91.77512684801894,-35.77786007745438,74.81042836284803,35.32885540379803,0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark63(91.78495413652308,-34.64699735363152,-96.52510540666022,-74.42596041560222,0 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark63(91.79826144882563,-67.48199492755197,79.6760882275897,61.06311233531869,0 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark63(91.83706642018734,-79.85362110040217,-30.746973586549856,-63.68941334808979,0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark63(91.84861312663088,-25.898680867675466,15.917813337361068,-58.56461975346641,0 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark63(91.8542690191477,-81.21907856341714,12.758702067828295,-62.37346651639155,0 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark63(91.87304386182595,-78.90048487965004,56.53978077613013,-63.80178634043114,0 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark63(91.88084075094395,-37.54458787837278,73.64121968681329,95.11037105459573,0 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark63(91.88437521289686,-43.65154929827777,27.068713786794603,94.61972362854237,0 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark63(91.8889802102579,-88.99797116788228,44.642879083659494,34.38553952741049,0 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark63(91.90419907589745,-15.731996577710845,47.53889729759467,47.089602839161586,0 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark63(91.91394238544314,-41.716524016413814,18.05655840012264,-96.64912961107304,0 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark63(91.94347918768943,-20.678628530442865,-45.90745689074698,-55.37269268610581,0 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark63(91.9673047043413,-28.426839077304365,82.01472867513772,-7.0077938817802305,0 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark63(91.97925545111434,-16.100950787165488,-33.765140029656166,87.60225409252797,0 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark63(91.98480378692543,-26.911261480384525,-1.2963223274832671,-93.07697317060058,0 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark63(91.99162675113516,-42.6303053063785,-37.638075041669225,-94.23497286404631,0 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark63(92.01673412407371,-27.268099118645807,-0.18268177726683632,98.48947724322912,0 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark63(92.02818741621874,-47.23640800696418,77.69396224493914,41.41025287105609,0 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark63(92.04955500800261,-29.830481369117436,51.92812870602194,-24.09752269027088,0 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark63(92.06956835455736,-54.31071753734875,-63.74685977304393,70.24137439431198,0 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark63(92.07293170056334,-79.8422606182001,72.28283171215298,-25.979602634406064,0 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark63(92.07925877036865,-89.83233006994588,-93.83730327020447,-44.66285615563417,0 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark63(92.12401385529299,-57.150211457154064,-16.57828014287908,-60.55546842731796,0 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark63(92.15544757809025,-35.94106780302964,-83.76240302459976,45.0981406049178,0 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark63(92.19234109247938,-68.36362713447126,71.0983794808034,38.15018642900361,0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark63(92.19296686774157,-80.94833958123067,-1.1344900980068786,-83.89526059302955,0 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark63(92.20981622593456,-6.081392036491323,-43.08413615659563,35.784542032535484,0 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark63(92.21172252816464,-43.666255805353885,72.67580429654723,12.908252989484353,0 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark63(92.21440362433688,-7.835989672663814,-10.492717085881893,57.282911558268665,0 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark63(92.21566228749728,-81.14442042101808,-17.40868405212106,11.299425483607067,0 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark63(92.2264337767889,-46.49413142356191,19.758527554643663,-40.367307110357764,0 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark63(92.2735597628695,-65.97259478451193,37.06292999265693,-16.35512136607528,0 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark63(92.27365029021573,-41.12075269039468,-23.425301330580695,-17.73340733106336,0 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark63(92.29568868723007,-58.43895203554812,60.60418230002392,53.907941483479846,0 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark63(92.30885721074472,-23.912370996404235,14.665676558579534,69.87747191990115,0 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark63(92.31419906117006,-41.352340475745166,-48.87801039264017,-79.52577389842968,0 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark63(92.32538490886259,-62.29794767375172,38.93970080158789,-82.68698124035778,0 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark63(92.33187628583599,-24.9817067255985,-28.446088918539658,21.866368211571157,0 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark63(92.34301101474847,-4.0707822630332515,-24.016811258071357,-99.71618387608837,0 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark63(92.35929861433752,-58.29953177487255,-28.360454546278774,-69.88077738791148,0 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark63(92.38916382996288,-67.75918682183244,-64.38307473487765,37.43622565175269,0 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark63(92.40330658233574,-10.7575648968282,32.6123733588889,77.9301225114404,0 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark63(92.40354261708498,-61.71842953283067,-68.0623252715526,-76.98811577018535,0 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark63(92.4084993209504,-25.014457094736684,-20.30610591178008,96.2736825071512,0 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark63(92.41162988723491,-26.81030103008493,-52.62087919452292,-14.103754460480062,0 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark63(92.42440727961093,-37.44476339484333,84.1160701087712,56.32339014971538,0 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark63(92.44444560349268,-21.558041396202782,-76.65100583984082,97.55779883361419,0 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark63(92.4462393124837,-46.56892582231909,61.65372222895283,-42.55292375428501,0 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark63(92.46394013482376,-90.82753746693476,84.11832253167438,69.26223951254497,0 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark63(92.48924079450774,-21.312669986009226,3.057430789065691,-88.77900721979988,0 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark63(92.50747452923946,-85.4505963040744,99.11440242751388,29.468456512259138,0 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark63(92.5180759141216,-46.173434485533924,79.33733953754964,-23.295323273999415,0 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark63(92.53547222572371,-35.79480172430152,20.545709253216927,60.44698136415485,0 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark63(92.54114211956133,-68.5358091291758,-93.80488456079289,-6.718107184357919,0 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark63(92.54816008146031,-56.93056640272698,-43.630137884807475,-47.301687148314045,0 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark63(92.57319937716056,-45.58474779621533,-61.61270229427278,-11.445151877675073,0 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark63(92.58649841796631,-45.1283044210748,-42.45933098850077,78.63301903661036,0 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark63(92.62951947189234,-70.43824664549403,-16.192989130948334,-94.88047411873349,0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark63(92.62991021039392,-5.553051397823737,-33.18481639222577,-16.911689481976524,0 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark63(92.63461942402918,-28.501066596093906,94.9821363064664,-46.81796703970416,0 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark63(92.6430597343132,-25.917645714744822,41.83362334264419,8.05949498053387,0 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark63(92.6571883393442,-22.529400591209495,99.41397173607618,8.024087733805857,0 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark63(92.66023153976832,-74.0928253909831,77.90758356950039,-64.98346607495586,0 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark63(92.66909048017041,-91.5543452863939,68.35828771627908,-80.11514757577004,0 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark63(92.68182102203531,-28.13667827893977,-22.71582692107384,-27.177032270444343,0 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark63(92.69166167925687,-82.18785932464851,-31.061685894801784,-19.977124262128896,0 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark63(92.69190386323851,-48.51111803801091,-7.193101721014884,-37.51364967169604,0 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark63(92.70700640865769,-81.00393869183918,50.50919150896448,5.222231535002322,0 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark63(92.70727563235772,-28.98154491831248,-55.183012522576334,77.36383113554169,0 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark63(92.718877080265,-43.33270728551661,-88.82472059118804,54.36579425646221,0 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark63(92.7468159711201,-72.91623338231224,94.71955033475956,-82.02314519824832,0 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark63(92.76699133524485,-51.59563122800401,-53.51451775451756,91.66420855475141,0 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark63(92.78487205961127,-26.858551007853237,50.587855840729276,-78.23241994013328,0 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark63(92.79705758565703,-43.88924252761963,32.809084231377255,-72.14667320362187,0 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark63(92.82920632482578,-20.30305543295306,-75.89155061155313,-29.776937510716863,0 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark63(92.83258419246812,-1.880145927657324,-11.959649084274403,-62.03565681382261,0 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark63(92.846525523829,-55.38969298867262,20.078426577694074,80.15937518815204,0 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark63(92.86633339647386,-46.40596419267027,87.63894424282944,-41.983454407867306,0 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark63(92.91965177513407,-88.21470063892147,37.90689465259331,-4.834804865645424,0 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark63(92.96363464876433,-33.3747562911729,74.29688260950812,-70.44414227764335,0 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark63(92.98014286355684,-34.20769277961054,-17.95392807043008,13.48771949009722,0 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark63(92.98878661092499,-76.78983860567523,-18.05884282949694,-57.46528563846751,0 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark63(92.99228641811368,-65.9307232217792,18.099995007985896,-34.140129773233525,0 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark63(93.00829766617872,-39.35128639516934,47.349370004385094,-36.14444048053347,0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark63(93.04795512484796,-73.19122001697527,-80.47579229750279,-6.5160739672743375,0 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark63(93.05902543266754,-34.92294943403272,97.90939019324321,-83.3234219235408,0 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark63(93.06847024153751,-89.5838581892487,-60.11272939149346,-46.67311461431423,0 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark63(93.07274114936928,-42.508429513555626,80.85389123291179,-57.2375295321875,0 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark63(93.08411350948964,-37.13024472656479,4.290064372680021,26.123028081097573,0 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark63(93.08621429077505,-16.129550945115326,-41.28565523508239,-62.0889366568236,0 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark63(93.09986058977532,-74.603365268701,22.43932465942102,-42.59389257448429,0 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark63(93.15676792433717,-27.50625545815744,28.55208539543895,63.614779342534064,0 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark63(93.17202525828952,-44.609277095712116,59.92718647033303,-23.405278154721643,0 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark63(93.17563977385512,-54.24553480256131,39.17944740132381,-17.767129972621376,0 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark63(93.17605283004443,-70.67184832247179,93.79482321592732,-79.05164864782998,0 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark63(93.19795692931123,-19.24268006319454,-36.77177881722899,-48.70882441291913,0 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark63(93.2379075021023,-57.55114042291301,80.29615383456627,-67.36906078527203,0 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark63(93.24229230396071,-35.54264009553985,-82.08132302276371,-11.01845849769623,0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark63(93.24548374936734,-17.199916279677893,-46.390715126836724,74.19908769269864,0 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark63(93.28920021048341,-88.60940918349065,-88.05959388549141,-83.75090055101775,0 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark63(93.2944966790717,-4.250271540172264,97.26944012217012,-73.52523384599444,0 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark63(93.3151068095238,-58.14451886563465,-88.61572527285347,-62.24653987385533,0 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark63(93.31587228864356,-55.79842697400288,-64.03680080232618,66.45074856581513,0 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark63(93.35420835234765,-74.35688351451921,-45.80319294110342,-30.207613153537878,0 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark63(93.35946277870138,-12.070632191586725,84.48314129844746,-47.42957782618586,0 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark63(93.359654541071,-67.13310714795142,48.64372264112674,-54.303842901364476,0 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark63(93.38629007445218,-75.4359255481174,-64.00594847848065,26.90971218880979,0 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark63(93.4082901059794,-53.08333267017129,67.80169677861855,-45.64089340530035,0 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark63(93.42972724402586,-66.55843852595038,82.01990279759576,71.7061715609386,0 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark63(93.43754866182258,-82.89987534056726,-23.870452277263013,-24.589329850394066,0 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark63(93.4429467819094,-29.181651962849543,72.1410294748145,3.721459777232866,0 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark63(93.45175873528169,-5.062815500573464,5.961196742417556,-66.90023788596761,0 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark63(93.4590092669564,-23.80500362656035,50.347049571824726,-79.01013560080429,0 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark63(93.4660538632424,-20.666241862746176,51.931427411043245,25.163227781800018,0 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark63(93.48515970705898,-5.4008066237353916,-25.092031015548315,75.2277775131218,0 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark63(93.49790436583001,-19.81655086957457,-6.2471025776764435,58.330997364112505,0 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark63(93.56340748882931,-90.89914229264606,87.71535164702641,-9.280318608514364,0 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark63(93.5636113318285,-49.45468106614761,52.32621096511127,-59.98937100909598,0 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark63(93.57029044508909,-72.93214358819777,52.26623573004562,76.6298135281277,0 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark63(93.5760874974585,-90.79925158594673,32.99567797638235,-90.61728758600462,0 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark63(93.57673986139906,-8.021865382026718,-29.29524044197973,-65.38187043015826,0 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark63(93.60761438187083,-43.2027513396535,98.26845407523425,-70.41409018787346,0 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark63(93.62354109055548,-22.68704785875019,15.463399984481825,46.011857335326965,0 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark63(93.64077185865224,-78.42931256491914,-59.632693136379224,-54.6693548783191,0 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark63(93.6436105000293,-18.357696783207203,3.4732568525113408,0.17666810275520106,0 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark63(93.66663192892514,-84.32857345955603,-10.714282071716383,68.46718760801917,0 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark63(93.69364051995709,-38.973650896631625,97.32694927073487,54.03202132830788,0 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark63(93.73413956546023,-53.95278589852299,-80.5550249791835,14.999037246358384,0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark63(93.73861109807032,-83.30745953190723,60.24113783991683,-93.60209630434791,0 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark63(93.74015070800655,-54.27960481552376,-1.5919155791883384,-85.38321892814795,0 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark63(93.7450018238599,-69.88205908889036,-85.07559423901169,-11.800876305219731,0 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark63(93.75049281814634,-78.59833016658413,32.95842310709216,75.80083436538075,0 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark63(93.78621735520235,-80.34439169442791,-56.32963100010087,75.70245485926833,0 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark63(93.80440825971812,-17.69678897785181,86.54395716963325,-32.9654689169125,0 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark63(93.87796732884809,-31.710526401095734,-3.811876085601142,34.08813306090747,0 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark63(93.87956765812388,-22.86582454542024,-35.60397210776654,50.91238651537074,0 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark63(93.8855424421717,-21.77448755015436,-27.500668654284993,-76.18015697243565,0 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark63(93.89961121877653,-92.03408181835621,68.91160554072715,43.01724372301754,0 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark63(93.94125838076727,-81.07699965723707,50.40155398639641,-77.90173736261727,0 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark63(93.95254325555655,-28.57178353338776,73.40361417193162,-42.399895115855934,0 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark63(94.00039574263133,-32.15718234650578,-59.21643365181875,61.25959571839354,0 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark63(94.04032505227264,-41.51274749514411,1.0386253311179559,-60.90601477164241,0 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark63(94.05962314417425,-3.7578839034270146,99.575215954094,-91.27458131156992,0 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark63(94.0614342546246,-49.38113597983565,48.550183865055686,30.10136175704224,0 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark63(94.07230720646385,-70.10903669427147,-54.093344882642654,79.17186624703496,0 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark63(94.07689968181802,-9.731899204814525,90.20072901813086,-48.52046639649499,0 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark63(94.07793318767898,-46.25271512704228,-12.868190748946162,63.90034847933944,0 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark63(94.0933959054311,-1.4162836261102854,22.102703086240098,-38.47866078472373,0 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark63(94.12012711726624,-41.207618951871595,-57.01006996519544,19.946849967497286,0 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark63(94.17340227770273,-66.74553021349121,-88.17692620242158,1.2123191403664748,0 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark63(94.17945628362207,-52.1900011655416,-93.34183051789881,-91.68104032895405,0 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark63(94.20089679892672,-26.035238284532696,61.393520661458126,-24.98354572048744,0 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark63(94.21620931614584,-58.18238080432745,-87.64133466602377,-81.44500508971578,0 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark63(94.24840531354434,-61.33304083566094,86.49176238581103,-74.80810757584604,0 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark63(94.24917106953887,-50.68858756595296,80.65911537684252,76.95802778386553,0 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark63(94.25682062836543,-84.23242910212917,71.69637814946552,59.568242848147435,0 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark63(94.25921160255251,-82.7799654681067,-47.09042425653085,-15.048472438457324,0 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark63(94.26056972910152,-12.542824493053459,-2.6601274085640796,-98.28772032798818,0 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark63(94.2622942488324,-57.74281882914502,-93.94591075463556,34.12385809704725,0 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark63(94.28643524666026,-4.377405604150454,98.21737348906169,-86.81202801896713,0 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark63(94.34004189288405,-55.190421949072935,-77.05225870418539,-90.21631435102073,0 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark63(94.34787013388299,-32.44889402747539,-61.49719973594912,64.72456287498258,0 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark63(94.35010670366225,-47.253632646487674,35.053536030198416,89.52028325244399,0 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark63(94.35525557956896,-76.84628527895876,-77.8080978601204,93.4573980677676,0 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark63(94.36679261591382,-14.977564410753956,-63.88647846902493,-48.66509257149014,0 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark63(94.38507309935756,-60.55453154320627,9.451998804163651,-87.57104820467019,0 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark63(94.38649986548836,-28.914374463584892,-0.6739204286531901,57.768151273634146,0 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark63(94.390506466267,-32.0737728024407,82.50860350765555,-77.16407252173438,0 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark63(94.39686324204158,-62.77997751305018,-20.658141121195143,-85.36192437081694,0 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark63(94.39968657537801,-49.713947460765695,93.757032002399,88.69308264696954,0 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark63(94.40755015316157,-51.906035314476085,59.34948718952191,-10.623471961357382,0 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark63(94.40943612757582,-49.20502261392989,47.88503726490745,-32.26747516696517,0 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark63(94.41470054507315,-86.37615725277163,4.170066438277956,49.14280512753069,0 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark63(94.46963751218917,-72.02302579658863,20.400325748378222,34.86827660547905,0 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark63(94.49004271807374,-39.158202661342045,-2.479959468062347,-41.53839115118543,0 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark63(94.49429213505991,-40.95658638111879,57.294471232200095,67.30138075518968,0 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark63(94.54646371395822,-35.41048093181578,-9.099120513207453,-36.903243017401735,0 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark63(94.547390178205,-54.513027622956514,63.494823347099185,-82.14580704289264,0 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark63(94.58340248131682,-48.30312784964201,-49.63503843956971,-38.04952765450651,0 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark63(94.61280590736982,-11.422517787395208,95.84337192050151,18.749423283126603,0 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark63(94.61557575692399,-6.788403845960403,-60.34162979497768,94.71291703462796,0 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark63(94.63068606285478,-70.16108978969903,-63.28998821209284,-50.21157198951796,0 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark63(94.6311158164234,-75.73759436590699,21.399965781680933,-66.948619517514,0 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark63(94.66936252771731,-62.05377808681871,-76.02648626012925,45.99042403170279,0 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark63(94.6709398464314,-45.91811775175629,-86.72983016807909,-67.17124198973256,0 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark63(94.70615268004008,-57.38741348104253,59.09166265143628,18.742590591395796,0 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark63(94.71376029109848,-70.26287150658426,42.08873570745172,-45.890358161893865,0 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark63(94.73198183163225,-65.91584648850338,66.85452599353567,57.23365659040769,0 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark63(94.76063166671304,-59.83588915304252,20.91776758422334,-29.421568587766544,0 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark63(94.76432328374855,-66.09107869357915,-87.1988261985378,-13.930431673767416,0 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark63(94.77499481514542,-85.2167120515372,22.37138576232968,65.1178212612262,0 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark63(94.78605751777778,-78.8277669515027,61.45025721519957,91.92767188064298,0 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark63(94.82566436917693,-11.075803876052277,-31.01637142393517,-27.441778003453905,0 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark63(94.82905312277913,-59.499321002209335,-36.80035666364931,-92.87296396862988,0 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark63(94.84170787055467,-54.98821641511766,63.09938233283114,-48.78885763120999,0 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark63(94.8559864872961,-17.520367880912957,5.6886278291975,79.47910630068873,0 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark63(94.85631751684824,-54.15930446934656,88.40492147633555,23.288843103061268,0 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark63(94.89180719338091,-9.839857216999093,76.65286237427955,-28.16477959233697,0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark63(94.92056123577427,-35.82344656567781,-65.79997979048554,-68.99170127541072,0 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark63(94.93527723821643,-59.187154409446194,80.64154461647661,-96.3691631562114,0 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark63(94.9442321457096,-50.38289340854241,60.97925953356511,29.036448872965934,0 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark63(94.96088490421064,-40.259388839694,-64.76101945756719,6.794541231443944,0 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark63(94.99365009272296,-63.11297973555716,-75.50398689567305,21.325710280416303,0 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark63(95.04407976508458,-69.14686027339398,97.45589151359201,-46.33181934736088,0 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark63(95.07310158506706,-12.435124677258713,50.668193613228794,4.505200477503351,0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark63(95.08602737895663,-93.14518526762711,18.429145066813902,79.04179782043252,0 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark63(95.0953395121671,-68.15107843336065,19.972171715224277,-47.560813107333686,0 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark63(95.09906385531113,-8.107840882471763,46.41081851141951,72.88716398083122,0 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark63(95.13255460594544,-94.54066701714885,-37.79981066501523,70.05672419288354,0 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark63(95.14268607385182,-40.1819049383233,5.247755294201312,77.04901443246743,0 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark63(95.14633821642781,-76.07436799229518,66.10647730889679,34.15667294106683,0 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark63(95.1496935304989,-88.39241930322021,49.31013594538629,70.35608472565232,0 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark63(95.16494815023401,-36.57536130853249,54.236710289277624,-99.02788813915492,0 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark63(95.17495546168436,-31.38814400977212,72.19535233453794,-74.1769875998741,0 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark63(95.17769302647199,-80.16416655503431,-54.42454795858747,-38.606568262881446,0 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark63(95.18443959059061,-75.16251649896543,20.7868723941194,56.70083632083271,0 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark63(95.1879552264013,-27.825675312551425,-33.12236324974323,-95.92185273485872,0 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark63(95.18893625136107,-65.7749870578328,99.75245436788765,-65.060912912475,0 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark63(95.20747563770894,-39.76343420236903,54.377850064477286,-70.69848901784854,0 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark63(95.21756077412772,-52.43048685323506,-8.406179093676542,20.17062272195298,0 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark63(95.22238472511347,-81.00332383096858,-82.31139273708483,-30.66565279845763,0 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark63(95.26974330293376,-53.743775926990466,-11.030198083820622,68.77911319675184,0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark63(95.27466364204253,-48.7540880099306,77.5430046882548,-7.744565120386483,0 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark63(95.28549793293126,-27.37145430949026,-81.0098506516647,15.234703160808678,0 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark63(95.28692005553333,-70.85527462981477,87.73565701445048,-34.23022917898837,0 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark63(95.289563004072,-81.83260927859965,79.70951957349229,48.006984572847216,0 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark63(95.30659938488085,-41.43593667374186,-6.6172344204148885,-51.53772268326784,0 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark63(95.30700729406755,-26.229041840044815,-78.1691161793465,22.07811828294257,0 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark63(95.3173299641704,-68.86396523324574,-13.140325029609585,-27.863074348465872,0 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark63(95.3399382254891,-10.0253062214247,11.852780028742131,-57.85457412879551,0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark63(95.35403700610857,-65.81216349088857,-0.08299922470844479,19.18348377718347,0 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark63(95.37864231562497,-60.23653108550198,-36.4091637159063,42.402750916849584,0 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark63(95.38211199995192,-70.61799399967478,96.92735697107028,98.18311107031624,0 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark63(95.39398280653526,-31.6408665081004,14.902942488482267,4.723618244100209,0 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark63(95.39858265462996,-13.37102697320951,-27.48211800161981,-46.081596157025075,0 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark63(95.47858160256231,-23.126260727826036,-97.83555014383526,-49.49890989466426,0 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark63(95.49623487868041,-84.7221393377884,12.725878351175652,75.28550665273215,0 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark63(95.50046893514542,-15.774335822909208,8.910614616296257,-41.117669668628245,0 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark63(95.50950265366399,-68.925127844093,-67.39714475122275,-19.674154108783554,0 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark63(95.52531862790406,-17.752012450770025,-37.5631495261006,90.53425682371824,0 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark63(95.53194377096023,-10.692624833817362,-23.83561377632917,13.874229654166086,0 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark63(95.53523904726924,-31.76495390743213,61.18075135470755,94.23310592532957,0 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark63(95.55684244323174,-25.751562794997554,77.4539214987075,-86.36804426483877,0 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark63(95.58678025386911,-79.56957740188746,10.00658127853147,-14.350339902531587,0 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark63(95.62634994199178,-41.900000750706056,-90.73446424663545,72.49095264538573,0 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark63(95.62714636276564,-72.63087309779863,-90.14452670800426,-40.05663360527891,0 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark63(95.63084909323089,-83.48780800237942,-80.18418444582844,-75.1017190298805,0 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark63(95.64851116520231,-80.47528503750581,73.7782596057659,31.615024776180036,0 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark63(95.65523735170112,-7.920279492260988,28.154241343421603,-89.14042187412554,0 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark63(95.67104260840455,-27.14539573289572,25.23468778156166,-52.520047026033964,0 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark63(95.6726322441634,-77.76892346059464,62.007396459090245,95.80841183694469,0 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark63(95.68893086360447,-36.11782350409325,-63.3967499142565,88.16140183015054,0 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark63(95.69142247179491,-39.706056096239564,67.43373253621422,1.9337217884617388,0 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark63(95.69714173693941,-10.343304708853609,78.68663469792949,32.30913045931277,0 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark63(95.75069500384484,-71.65345196119652,-72.63841205579145,20.468574332852867,0 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark63(95.76449942484112,-59.388861681538074,63.037888937150456,-64.03884248366938,0 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark63(95.77741808010254,-15.492305842544326,74.03060015273803,64.04715889861163,0 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark63(95.77805497183522,-27.818836590668866,-11.554342350293041,-97.56344649674458,0 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark63(95.77931098087853,-94.0924911094877,5.412196098712371,-6.81062082596371,0 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark63(95.78932560485273,-43.36489738798659,-84.79517757594235,-79.85903077466034,0 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark63(95.7980394016576,-19.290361570398247,-11.157697187444015,-9.054020669984467,0 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark63(95.80014942966511,-9.641480948751948,-29.932717789265936,-80.77642544553483,0 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark63(95.80888827446208,-77.95787827723335,59.84653682345376,-51.58802921261771,0 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark63(95.84703117670324,-94.4229365861694,34.468864192267944,58.353866431288736,0 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark63(95.85722078336366,-22.813595089081076,-53.215602640045944,-89.30019072999988,0 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark63(95.86325993006724,-68.03753527560656,-32.64745123837656,88.43476225078217,0 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark63(95.87675881208958,-60.53440966707122,-33.103634811853965,40.61826634733666,0 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark63(95.87973663878034,-78.57538669654356,-57.047194058565154,-63.50719219258529,0 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark63(95.89064500491256,-71.10025682829448,-42.78333067353355,52.84553338342914,0 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark63(95.91334156427388,-47.42152610938211,53.436055589969186,32.50080507906338,0 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark63(95.91678025855401,-19.90998721066697,91.38089844657728,-9.97698931535416,0 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark63(95.92524457696692,-86.55091634403489,-17.685669374069477,-96.94599133954083,0 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark63(95.92584254486184,-62.10707760511778,-85.34095481376436,-90.62423292672142,0 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark63(95.92842161763008,-27.077871140747604,-22.860107763104295,56.03192842837839,0 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark63(95.94334033012336,-39.03167826216123,98.04454052339304,-99.16465754998245,0 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark63(95.9555715115242,-37.4139631295914,41.23967977408117,44.08279492998773,0 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark63(95.96246809586523,-63.318521883573055,-31.42389841562752,-30.40531110556222,0 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark63(95.96369635625601,-33.213623531938225,49.210414319453236,-87.36809886691046,0 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark63(95.96803565805916,-9.763464726502491,-27.181011472063418,97.06913618740893,0 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark63(95.99907243667488,-34.19226748044673,30.193704603938585,86.97189408188899,0 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark63(96.00721900147553,-3.06774096477767,79.74485448795244,18.83607920402774,0 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark63(96.01174240950226,-87.32936372196984,91.10692675659004,-62.583050296849116,0 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark63(96.03008409904191,-7.879562554289322,83.25169196483421,91.5292211756321,0 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark63(96.03329906684343,-46.220873228113945,58.53128198315815,-85.96305267908716,0 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark63(96.0352120146824,-88.13280188689994,23.08180451193998,10.322377221456719,0 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark63(96.04412991122197,-66.58837224673368,-21.409225697056115,0.0403177868024045,0 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark63(96.04442366518433,-68.40852912330459,-96.62696962809001,-55.26646755578457,0 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark63(96.04863256866776,-46.67709989615481,46.248677221354,-72.65892790174118,0 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark63(96.07097234235806,-15.700774639776213,-22.71456120803306,70.6196841897088,0 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark63(96.07435859399581,-4.1661483031335536,60.522818058524734,-45.09032878091028,0 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark63(96.08710360211779,-65.91346301924428,-47.179117517692106,75.64568527082773,0 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark63(96.10304125392796,-65.82090836648169,56.42900141647752,-28.49059739258159,0 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark63(96.10326553752867,-44.89353931965767,-71.64333192448598,-56.698071701775035,0 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark63(96.12884834023487,-76.65009827265543,-49.18079772740249,-61.66106622064946,0 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark63(9.61536139794741,-1.5046243849881051,26.999699697105115,-27.16728950409228,0 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark63(96.15575778618964,-44.62913754453683,-42.801218080514445,72.02801089697107,0 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark63(96.18672810472773,-88.45794870514291,-67.78353873565976,48.73326779698306,0 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark63(96.20834660653188,-56.66728937840419,-11.626623237718391,56.06025899722394,0 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark63(96.2264555710336,-23.074599377650173,-56.35833759804445,25.927816456656387,0 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark63(96.24080377086054,-39.72711726388185,-57.901701124737315,-13.183075452356348,0 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark63(96.24120692756651,-88.25566840236418,90.1843454983582,53.840704334950374,0 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark63(96.27170951589326,-18.396980833528076,70.22507165762337,39.27965005593751,0 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark63(96.29680111397315,-54.424356011405585,-68.05889266040302,-24.06029838262178,0 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark63(96.355329318478,-9.86188273052069,90.17433745714024,18.041253962298526,0 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark63(96.35629883337472,-74.9269514588673,-75.49571262202156,56.07636603198446,0 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark63(96.37576521953883,-13.384328705994704,-76.99477347895838,-38.18075252570614,0 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark63(96.38821734017415,-64.04931196889727,11.670002931815944,66.28421364402706,0 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark63(96.39596704429852,-16.449441129480434,-79.89304448693355,-76.5550537316534,0 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark63(96.40574335100945,-40.049351748925275,23.680313850113222,95.53565469389974,0 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark63(96.40946443035315,-84.43937539067463,-93.42922523936595,-59.27894749019096,0 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark63(96.41441707338518,-22.89241482423006,-38.56695251758211,-16.602781909554125,0 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark63(96.42953566580127,-31.552316639095082,-66.0887296799564,-65.81734186933627,0 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark63(96.45059966895204,-10.51651814923298,-82.58361202699152,-17.20480503910504,0 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark63(96.47659637745076,-67.66565095899361,95.8383408212872,-34.44410850022754,0 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark63(96.48441014380217,-20.354173734531926,51.839608028737786,35.88362481760262,0 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark63(96.52179878106256,-29.197914399973484,26.610752787061173,93.36099680694306,0 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark63(96.53123408070135,-24.596277086358427,14.896451674117088,15.278588213319338,0 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark63(96.54864092009313,-53.84414827246686,-28.62850172887714,8.05208087971927,0 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark63(96.56427350682156,-34.16061844274658,-40.6516831882342,-73.7406275179408,0 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark63(96.57685855604134,-56.76231960522542,19.848818668309036,32.665523450722986,0 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark63(96.58576319912947,-85.4628940162855,62.43136512175943,70.33098532447531,0 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark63(96.6048422482859,-22.686753106041536,35.28034802108627,92.34055188779632,0 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark63(96.60526910996873,-36.54617234323185,37.98314013329164,7.438178513915901,0 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark63(96.61007658515794,-35.58510090407876,-9.841362185076207,-40.62977910002532,0 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark63(96.61211463353277,-70.99970843254219,-13.188012954132304,-52.7832271973951,0 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark63(96.6158983331027,-39.2536047003208,-74.26691397557661,11.963276531103759,0 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark63(96.656613462742,-78.1485299302255,-48.40264429913945,-41.49528559711912,0 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark63(96.69665807748171,-28.693835482124413,88.61147989570614,-79.47189743923227,0 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark63(96.71044714171771,-92.00660214130518,34.58869985104485,13.211483999333893,0 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark63(96.71946704401782,-15.410653867106248,30.76182202540133,29.303669034576842,0 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark63(96.72273335660228,-47.36309542365564,-59.460390962866924,43.737458873455495,0 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark63(96.734012104725,-92.94669721523938,-43.77147522317841,39.240986794155106,0 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark63(96.7692813574094,-58.683354720216265,-44.563026503267665,-27.407305581219646,0 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark63(96.77331298678712,-74.8947455536987,1.455269327242064,72.114384022595,0 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark63(96.82718627520632,-22.206313071110458,-42.01661711936775,46.94338691881151,0 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark63(96.85365023573326,-50.938220650563835,50.74285711623517,10.506470664930362,0 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark63(96.85405211733206,-89.07506837576918,-57.35577348001206,-95.14222404815824,0 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark63(9.685688147336009,-3.601600463734627,86.82389955981253,-68.91783315827205,0 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark63(96.87284448514015,-30.322660289102487,99.75934670383162,-74.34591683205743,0 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark63(96.88963437891752,-14.908631183846282,-83.80127507528054,-10.966953915586018,0 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark63(96.9119192407104,-6.533549696002609,-11.878280451965267,-81.61533277590786,0 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark63(96.92621092200892,-7.257602881705424,-50.64771488478084,82.14732750194091,0 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark63(96.92875938349766,-96.32969309807089,-67.88607783385089,58.11531116736995,0 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark63(96.93565496118686,-15.73247199322752,-62.36073716415118,0.35241115748443974,0 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark63(96.94715587224584,-9.123535655039746,-9.842871988044081,89.73858554233641,0 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark63(96.96324771244116,-49.17115650566246,53.84344791852956,23.26568428816975,0 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark63(96.96796236825597,-10.370554801886726,18.280246979485,-51.249680554100884,0 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark63(97.00678267798426,-35.88500509834209,0.5082361015556529,-4.329461038268946,0 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark63(97.05174096347722,-45.62949716882538,-13.281224102647187,32.70654578463714,0 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark63(97.05353899242434,-13.915723338215912,-87.8009648998455,94.66589121151202,0 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark63(97.05667222819307,-45.77136755466387,36.39777987876715,84.99468443416413,0 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark63(97.05926952665723,-47.925356242892406,24.222572547931037,2.3635640763254315,0 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark63(97.06402222160253,-80.01365104130215,43.590223141205854,63.43728142168203,0 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark63(97.07906631755753,-86.8991302387907,55.10019796469658,-21.269067123434,0 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark63(97.11627750565228,-21.731578571244768,74.64582019707507,-45.882125749301174,0 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark63(97.11646852988054,-51.06528587752659,30.28364081655127,70.00111962444277,0 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark63(97.12060466890563,-31.06246125004455,25.884970026920257,31.564038034996003,0 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark63(97.15473343495478,-19.40858949828315,-26.71548681222656,-49.19044537278347,0 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark63(97.17118777678607,-0.04574995686272132,8.816617225402993,30.06094861758976,0 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark63(97.1802065614985,-60.79736804638409,47.64463260113973,-18.970390928595606,0 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark63(97.18624496421126,-33.068862430461905,-24.65992298648858,88.34985434530566,0 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark63(97.19076617930313,-11.833794213916121,-61.89656619387278,79.22286731787355,0 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark63(97.19856696489398,-1.9523523882416072,74.46774534255232,69.78204860852702,0 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark63(97.22066355658546,-4.252719511039672,89.53066587878325,-88.35607268327212,0 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark63(97.23551169640157,-66.30972685947228,-92.0654556135553,-35.54922798646152,0 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark63(97.24531086776105,-97.47879058382361,-26.957230078891342,96.996906481535,0 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark63(97.27007143084984,-47.46141536108625,-4.283202773586396,-69.23527427985888,0 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark63(97.28817618881652,-3.8645491299050576,-37.448314099487924,19.04078407835057,0 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark63(97.29336453712784,-51.57896728985634,86.54823094115193,54.84245826875562,0 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark63(97.29655970713432,-2.871986676003459,95.7985937626512,83.11980605899066,0 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark63(97.29695547085919,-19.973599821162864,89.73710389024404,73.23654652830882,0 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark63(97.32035719400182,-9.722486615074018,6.103800943238795,-83.38052174848502,0 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark63(97.32053381045719,-62.908268102134144,-41.0196031738493,-26.428934386726638,0 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark63(97.32351138268791,-87.36971254698423,91.28199393591532,20.082739595009585,0 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark63(97.33112558967804,-33.91662957190344,88.02204231768866,38.51101279123512,0 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark63(97.34419187612781,-54.50725429427106,99.54336363565844,-62.65871507946452,0 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark63(97.3820627956895,-47.888270565857695,65.07483944904985,42.35293459351374,0 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark63(97.39622921007512,-85.47211952477178,4.18402811343887,12.9924476539736,0 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark63(97.40007006634724,-27.771617045080262,-66.0747969768414,50.77636438615073,0 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark63(97.40440801535354,-83.2018712738942,10.010311823619332,72.29690239651515,0 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark63(97.406111393289,-14.475985522586228,-25.175891848367527,15.352118715552066,0 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark63(97.43228725470746,-65.66029298959216,-29.827065657269287,-32.2482506161617,0 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark63(97.4388608525978,-0.22305997918306275,84.34978700164109,-65.70221465740242,0 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark63(97.45424289225048,-89.85967484881799,99.58914168431758,-64.47594517179856,0 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark63(97.45540518630983,-24.652641136950876,32.40982353080108,-30.102978223001315,0 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark63(97.468842270648,-44.2331795972551,-22.18280236084152,-40.666032758958146,0 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark63(97.51705298933882,-92.78655070796593,14.951213782145189,84.9403162226744,0 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark63(97.51890691312656,-61.58840030581172,-29.263973458825234,12.45525782842924,0 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark63(97.53281918312743,-18.58339272718179,46.63505957959049,64.05140411727251,0 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark63(97.54427121427273,-29.618472402260537,38.114040054447884,-95.98170845244798,0 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark63(97.54916243214345,-83.87983246697632,-88.53987063390316,37.79735275595144,0 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark63(97.55394034942793,-81.32872890214011,92.39341008995243,77.70483597487532,0 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark63(97.60897650919364,-43.14524998526108,17.727255786336144,-59.767036432670004,0 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark63(97.60980161294947,-37.71820578935736,73.78368107250526,30.50584713330406,0 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark63(97.62887140609408,-56.71763387446867,94.27623600723908,-2.7675930323081985,0 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark63(97.64567789500038,-73.995146869017,33.4095334425528,87.65604250687582,0 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark63(97.65249334412235,-28.559325552116917,28.453789979769283,-46.68496497325061,0 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark63(97.6626493564494,-93.51262283405131,-45.850591858455324,69.04418314689127,0 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark63(97.71812117484617,-14.716414491284851,-68.05280154216642,-59.77372372475127,0 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark63(97.72815568415302,-49.607072091818964,-82.73404776847187,29.492927990634087,0 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark63(97.78761360060682,-70.47901417186917,-14.783932465358404,67.50738352273237,0 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark63(97.79439864507594,-48.2532044598464,-65.16803782507134,-58.938453602669206,0 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark63(97.81731068279151,-62.51758514188559,98.22217304796897,96.99765276023174,0 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark63(97.82139436471215,-11.450439986373013,60.59250761709626,-69.68681799283792,0 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark63(97.83617309912006,-76.50809758801662,31.816555844679755,-50.157240602098405,0 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark63(97.84351398015758,-33.1463980530815,48.31069801293418,-73.68560431365674,0 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark63(97.84588516884133,-66.95481637305345,-35.51392132606448,-89.5043069627015,0 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark63(97.84826278930169,-80.80313028808057,20.6456634224631,55.123932262951115,0 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark63(97.85382882110017,-65.56067002472346,60.586576089148934,-75.55695138768976,0 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark63(97.8715136999241,-49.57900741787522,71.43708552755504,-15.235853305221596,0 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark63(97.87227930643263,-35.77610538141778,-29.865592947541103,-41.43795239696351,0 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark63(97.88581545050238,-47.42635834021336,-41.5781758036391,-62.305653577124495,0 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark63(97.90177893926739,-50.358862188208334,-29.382786282631585,48.75465670083693,0 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark63(97.90415195974913,-77.98440687227793,38.72461184113533,23.37229524721178,0 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark63(97.94632701768947,-82.12693255470293,12.373847464636654,-18.988561143878798,0 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark63(97.95654754604783,-28.88205562754422,-2.8973810951503367,-43.26683915203746,0 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark63(97.95916012987814,-62.485107575333075,-29.056707872945765,17.106852656882964,0 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark63(97.96989339810756,-83.36835306224779,-96.6894613459784,92.38731427606882,0 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark63(97.99031141019702,-59.22888103206001,-86.26755594960711,28.616310847572606,0 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark63(98.07058599779313,-69.31962167939653,-63.71862932369239,6.189754700283913,0 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark63(98.0784872990829,-38.26572748529993,80.05819696775859,-42.28673963177714,0 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark63(98.08976208805785,-12.291539625019027,20.41335914724513,91.29634241743616,0 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark63(98.09371016685665,-6.310107070457221,83.83066899902963,-94.13299760117329,0 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark63(98.12091922621917,-6.579443094122112,-57.42343873234117,11.77730673586126,0 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark63(98.12614710052077,-32.061776250767764,-56.410836647099806,13.926899348958372,0 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark63(98.16060301484961,-41.59376268558825,-65.86691642453437,37.32419553020469,0 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark63(98.16892907056678,-36.09335458939038,36.17307352313401,-37.419471651308676,0 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark63(98.18114760696167,-30.40123406313893,96.44943599914876,13.117163203030373,0 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark63(98.19993093289247,-19.6988886991535,-48.633577864118884,-38.47747490737072,0 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark63(98.20113515303558,-30.98813540106879,55.35701328048822,-1.4085265535155145,0 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark63(98.22149296001152,-25.609398794661104,27.06990564014255,-52.90461071948689,0 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark63(98.24318933759096,-64.80617797910118,-66.95568186423236,45.01702089915952,0 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark63(98.25476202348995,-9.314379077919256,78.14576570001856,57.32792655420235,0 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark63(98.26731725165945,-55.47286184048863,-19.750683487421327,-7.593266682131343,0 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark63(98.26761256662846,-4.605057067007863,60.75916386718251,-62.12233234572415,0 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark63(98.27985840691872,-34.968220911669874,-39.864726998116765,-88.25142622312197,0 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark63(98.31732635119499,-69.47269916863661,-69.23932474972779,-15.000931455094886,0 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark63(98.34487271606432,-50.615934209146744,84.26079895498779,-95.9234837983106,0 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark63(98.36896952511049,-81.72026105906636,-70.53841998443428,41.961777077408556,0 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark63(98.3742669115841,-85.89876374740848,-24.275155004103937,-46.524539591410786,0 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark63(98.38035410058123,-71.23931622033729,35.97514055698943,-16.32838392604441,0 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark63(98.3952989796341,-3.1085787575027837,-29.99524648480127,-86.77527166847293,0 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark63(98.44169738647474,-94.54824786945785,-16.75763404681672,-77.46714580704675,0 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark63(98.45801583203774,-72.58317413733747,-11.080459305777993,-1.5477839200376309,0 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark63(98.49397406248556,-22.913168989502537,-3.2317223300081537,-21.664574957135045,0 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark63(98.51444897896852,-63.540955815540734,90.57784910272991,-58.85858851082717,0 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark63(98.51908945773201,-41.65104864245854,49.18595198291672,26.307392196726866,0 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark63(98.52000915970416,-81.79763759362066,98.0953556522511,-24.397935906699246,0 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark63(98.52834955942896,-49.638463210171494,-83.54650289045091,87.1888657043238,0 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark63(98.54551389654972,-37.31784985172186,44.309753552584,86.60440548893061,0 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark63(98.55526676404858,-92.98818986116567,-11.538060744802209,23.144233684653088,0 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark63(98.56211863809116,-57.94695440203035,71.46594181635854,38.0970134323253,0 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark63(98.56575175158699,-82.97390493233034,-16.488725365896457,86.48103359661312,0 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark63(98.57974019998522,-90.3340197792094,-37.39974031921924,-44.82649342657234,0 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark63(98.58706228517079,-48.812866198362585,-21.38481960596637,-32.66358255578426,0 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark63(98.61241982001795,-9.216672947775237,-9.88766470925529,93.82571922829356,0 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark63(98.64461935436904,-75.30828419902886,-1.0858336869601146,96.79969349269356,0 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark63(98.6460681904581,-6.011415236963401,34.87383346024828,34.452580497263085,0 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark63(98.66360635141496,-13.898712297353839,-22.478827934327697,80.00615397491745,0 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark63(98.67288348143774,-86.65286419787186,37.6574585064304,29.987295609578013,0 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark63(98.67665708622991,-56.37394407407144,-63.469328865295815,20.12091168535622,0 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark63(98.7030660148836,-73.45696877440255,-28.572269589378507,-30.245455662928848,0 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark63(98.71289276881555,-95.8133699934488,-88.29858725043267,86.39742655451857,0 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark63(98.73692280945627,-86.14714855261145,78.08772075468659,-49.700396341429574,0 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark63(98.77761429079109,-61.20334237828678,-61.316226259993755,-71.05907391689561,0 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark63(98.7987546389522,-69.14390014180006,-79.45306580007005,-28.75723587147145,0 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark63(98.80287727620015,-42.04197555819103,53.79039426142862,-41.91388719681595,0 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark63(98.80924172053253,-77.5084207983848,-90.59731464740524,55.578100468903216,0 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark63(98.81714443224237,-7.1375942869065625,62.96202011380069,-91.57756504321233,0 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark63(98.84791432827362,-94.74815150461757,-24.30032737875038,80.31437616227518,0 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark63(98.86385841952256,-97.93274564717096,51.231344085646356,61.35811925738952,0 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark63(98.8722683820589,-21.844222462332468,84.13712308391567,62.409867295557575,0 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark63(98.89528862029377,-15.711474752917567,5.20093416445944,-2.924144742094441,0 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark63(98.8995344343345,-62.9643050012793,-18.807869967378622,31.599891951340453,0 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark63(98.91016686275799,-15.010377841896002,8.37912802529344,33.772746182507376,0 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark63(98.91255726993694,-89.21402775085652,-66.8327568052713,-29.207546197722294,0 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark63(98.91906259437204,-44.437719203771266,22.506501457786925,5.201264982398698,0 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark63(98.92595589052252,-43.09580068323986,47.60272671406642,-65.31316548554902,0 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark63(98.92772881519784,-3.951053354978029,39.56067636920392,-67.96146412729681,0 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark63(98.96201478499694,-41.32959094969895,-88.85761040802898,41.52170538042162,0 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark63(99.01250143389672,-56.1998135304274,-39.37224360741274,-4.639274659623439,0 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark63(99.01791440463228,-68.56114095544578,-23.07698972130163,71.8302232585699,0 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark63(99.0330359394035,-12.619406044091463,48.52231714594731,78.6974379478194,0 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark63(99.04092002013348,-27.7460951349007,50.721170722565574,97.47664342372303,0 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark63(99.0483119703396,-56.98869683240972,-46.45449108642627,-60.312451285004975,0 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark63(99.05390523042533,-92.2400800491135,80.01386301752004,71.88039260002046,0 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark63(99.09561677297086,-85.69637724072045,-69.87193056940772,-50.05500101564455,0 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark63(99.09869163739836,-83.49218922785863,-98.47092744374493,29.41581673282022,0 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark63(99.13791636734487,-6.392920746191493,-14.111182193896283,68.54773494330851,0 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark63(99.14835656197465,-35.70616665091106,6.013428341736017,-33.65803373454746,0 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark63(99.1757540805801,-88.64654337172975,50.635903510593806,48.58425600250948,0 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark63(9.919666206694401,-9.117725353565385,75.08691866177962,93.6314921091813,0 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark63(99.20012648513654,-83.93380620595786,34.68117581553659,13.505193612140658,0 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark63(99.21799448533858,-73.37847629478391,22.606916539789168,-26.518266381993044,0 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark63(99.24330100531705,-4.659871188859782,22.24542839718093,-96.96509754485885,0 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark63(99.26592904059046,-60.492240521381824,-30.943233664675503,-70.10665007989127,0 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark63(99.31954484706708,-83.46773716453262,85.07008126885242,88.50272964851433,0 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark63(99.34726773387757,-6.855356544809069,22.0066239093359,10.014140944758253,0 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark63(99.36099490457684,-1.5870500971966237,7.9947012120792635,17.34447605989446,0 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark63(99.36651173516563,-24.412490727963075,72.41117513982482,-64.94355464996761,0 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark63(99.368660995319,-69.70741848882031,-1.921829799120701,-31.39722370201028,0 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark63(99.41311648629122,-39.93671240809433,10.764513229786104,-68.6929197949241,0 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark63(99.41486148492154,-44.42912149366729,-66.56897365347109,24.143725252633047,0 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark63(99.50747582791993,-71.7874987355242,-77.64486201530386,45.792695774011094,0 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark63(99.53191131778703,-66.94811059511713,1.1758820833429837,-91.45920716650733,0 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark63(99.54581257479356,-48.73780005296966,30.611097957650657,-79.30445961992392,0 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark63(99.5498251009698,-96.08931911814811,-44.1091699829635,32.59096589798355,0 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark63(99.55611889281937,-34.624173301405875,-97.86899590865481,44.17788199254059,0 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark63(99.56926124672688,-87.6099932617626,-51.03696142247629,-22.965316498596238,0 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark63(99.59331691606204,-46.85016614477304,92.97177722697975,-45.78388494683081,0 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark63(9.960980337893346,-6.391640003348172,58.07648985318417,-6.924094459481452,0 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark63(99.63585800107174,-71.01825116432796,-62.61990810853635,-39.31178148798753,0 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark63(99.66160253281745,-9.383463110575207,72.28979421869096,13.746300100264435,0 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark63(99.75106197726365,-25.604954908078753,64.62363282888089,4.318050330546768,0 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark63(99.76048011939807,-19.289558148424348,-44.934396824146816,-68.70109581809896,0 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark63(99.7609289954753,-33.38079249516517,-85.22450381678586,-18.888990112346974,0 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark63(99.76093218663007,-55.51405755656844,52.03577319981767,-94.7083175821936,0 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark63(99.76600210283965,-26.86871728642548,-85.3371501858704,53.18851116149915,0 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark63(99.77194050720229,-78.80848425285023,-63.796927385365244,60.759146204793524,0 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark63(99.783344088713,-54.27990149413746,5.2654296559228015,6.662823722391309,0 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark63(99.80185958061588,-86.76503493631056,-90.3177698964287,72.97924383647313,0 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark63(99.80233863789778,-81.85792445608628,69.78617147867584,-23.259660825346558,0 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark63(99.81755515420602,-70.7896184330776,-28.172453866202105,-51.81645698907869,0 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark63(99.88796662300112,-77.50229450328698,20.277279348284495,-98.78122478418159,0 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark63(99.88957591923432,-40.8917367340409,12.013350452643152,-90.96994733536204,0 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark63(99.92002152594966,-53.83994235210076,52.45534290818864,-97.73089905619526,0 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark63(99.93200513768389,-13.242135197233978,6.557353909875346,-12.540172112245585,0 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark63(99.96786629763548,-80.22731936529053,-8.682952266453256,6.4459247867073515,0 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark63(99.96976582406418,-43.602835467973456,-68.45834136818834,10.085085258273608,0 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark63(99.9741430112455,-33.7745562095658,47.47907929156395,47.12687429122553,0 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark63(99.9968856695593,-41.908078601369915,-48.6859300127978,-84.53132365228812,0 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark63(99.9998009332331,-82.6153875139392,13.6551446796513,-77.6942032918323,0 ) ;
  }
}
