import org.junit.Test;

public class Sample82Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark82(0.0,68.5533541227684 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark82(-0.1299784672209352,-7.693582032323992E-4 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark82(0.3464506521726065,2.886413963226677E-4 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark82(0.3501568357946494,2.855863138391257E-4 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark82(0.507806076200751,1.9692556802031452E-4 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark82(-0.5883010211174325,-1.6998100701925978E-4 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark82(-0.7850315544388811,-1.2738341412443788E-4 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark82(100.00000000000007,9.999999999999991E-7 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark82(-1.0103883376911124E-6,-98.97184703112752 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark82(1.0E-6,100.0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark82(-11.47273061687379,-8.716320755677853E-6 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark82(1.285064821269728,7.781708622386337E-5 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark82(1.3371084459707404E-7,747.8824944087506 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark82(1.3404825738569213E-7,745.9999999883956 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark82(1.3873622262099844E-7,720.7949090857271 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark82(1.3877787807814457E-17,36.93977478742559 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark82(-1.3950385283570646E-6,-71.68260801927092 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark82(1.4104313344066138E-7,709.002966394106 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark82(-142.232455823301,-7.030744102754758E-7 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark82(-14.233543718124821,-7.02565727694792E-6 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark82(1.5507652578738984E-6,64.48429218558853 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark82(-1.6888441771071006,0.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark82(-1.7000553720336598E-6,-58.82161348684593 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark82(17.453913534219577,5.729374091600903E-6 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark82(-18.876292723175368,-5.297650416125066E-6 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark82(-2.3923698104837143,-4.179955772798394E-5 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark82(24.810439252564763,4.030561450818482E-6 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark82(26.180451784353988,3.819643787039695E-6 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark82(-2.694256940478646E-7,-371.1598492722719 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark82(27.232550364538554,3.6720761978362895E-6 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark82(2.913047147069321,3.432831497444361E-5 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark82(-29.415244635400793,1.4144348921360384E-22 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark82(-30.341822760799758,-3.2957809024125595E-6 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark82(31.250036260003572,0.0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark82(3.1355208862806267E-6,31.892627613340693 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark82(-3.169848508122185E-7,-315.4724894384304 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark82(3.2148819396060624E-6,31.10534131034953 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark82(-32.23494465135329,-3.1022234125598785E-6 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark82(-3.2783989539098E-5,-3.0502693981559617 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark82(-3.305502495817806E-5,-3.0252586445335368 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark82(-34.97039163735319,-2.859561912746389E-6 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark82(-3.5311928225922884E-5,-2.831904261075863 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark82(-36.96647377055043,-2.705153881343847E-6 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark82(3.944304526105059E-31,-0.640249689374778 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark82(40.7247945503712,2.455506555749795E-6 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark82(4.148855932584183E-6,24.10303025022236 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark82(-4.378786922991338E-8,-2218.0348857287345 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark82(4.440892098500626E-16,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark82(5.964797251900578E-6,16.765029183202625 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark82(6.062445949193744,1.6494992429727517E-5 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark82(-61.16341451243035,93.50073775964069 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark82(6.67892723811292E-5,1.4972464371569885 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark82(6.882032278089645E-6,14.53059154028824 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark82(709.0000181149856,1.4104372025752413E-7 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark82(710.0012790337033,1.4084481669521117E-7 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark82(7.105427357601002E-15,-4.3915995640020355E-7 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark82(-721.8348432939014,-1.3853502856417382E-7 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark82(745.9999999998907,1.3404825770847658E-7 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark82(746.0000000025159,1.34048251900817E-7 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark82(8.050175065567828,43.09969184658871 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark82(8.403519045377115,1.1899776684032304E-5 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark82(84.06258209281302,1.189589916350542E-6 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark82(84.62537574202736,1.181678652805522E-6 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark82(8.762787532923255E-6,11.411893718098643 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark82(-8.881784197001252E-16,7.105427357601002E-15 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark82(-91.05506466015143,2.465190328815662E-32 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark82(92.24498202323085,1.0840698085324158E-6 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark82(-95.19363258669355,-1.0504904296926504E-6 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark82(-95.43482120232581,-1.0478355671458306E-6 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark82(97.29367462302304,1.0278160464949337E-6 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark82(-99.91543257833133,-1.0008463899868758E-6 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark82(9.999999971597928E-7,100.0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark82(-9.999999999999983E-7,-100.0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark82(9.999999999999993E-7,100.00000000000006 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark82(-9.99999999999999E-7,-100.0000000000001 ) ;
  }
}
