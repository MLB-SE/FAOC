import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-2.4788431428293336 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,9.465575461834248 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.03328164205909253,0.8827928523238718,0.12810973535777134,-0.005293510248342284 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(0.5789539996071339,8.552847072295026E-50,-99.89856315057587,77.01564505630192 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(100.0,3.248565551764031E-114,-100.0,100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(100.0,-3.4211388289180104E-49,100.0,-40.738884655314386 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(1.0923762084824824,24.66280938607538,25.760241202006828,-5.202739685546267E-4 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(13.392965642914916,52.71371102090191,3.394585834667893,-86.13452401837363 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(13.562771311871131,-1.7494736429147364,33.17704178776486,-44.20745942381176 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(13.565200701331628,-2.3224050065771586,-5.094621163006471,18.65222614501632 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(14.69026072300808,2.40747161004983,-31.498213307447752,49.52203581598862 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(15.455767930507372,3.0814879110195774E-33,-4.3493366329255165,15.219063889389359 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(19.334566032566546,-4.163741821712262E-9,65.46983899179871,-100.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(19.984695731565832,2.7369110631344083E-48,-98.8723024301764,-20.11628902294323 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(21.062167817481566,-4.440892098500626E-16,40.86723488538895,-80.46075891765835 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(23.748095442640945,-4.2168791772922093E-81,100.0,100.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(24.696770538384953,2.220446049250313E-16,-36.93997368162783,-81.13135072745425 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(27.097719538305668,59.1892646527005,-33.19374618552477,98.4482650114181 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(29.72865528908548,-36.27423079651776,-91.7330581268934,14.01451377693735 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(-30.199765586057453,-27.164310288869515,21.976587299972934,-43.7853843374951 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(35.36181791293589,-14.855514960910583,33.11873715966965,-63.11463520844571 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(39.65827915799965,28.436924478889154,40.898418971153696,27.19678466573512 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(40.43244748168218,0.2523669197683739,-64.68583636967873,-51.21840043022956 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(40.69150409583207,9.393396799251452,78.48834962780646,99.22343270391276 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark62(4.400465476688154,21.33067000659696,44.74595753378117,-1.4692564604225993 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark62(47.661663865067645,-48.66166386506764,100.0,-100.0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark62(48.235722024131974,5.551115123125783E-17,-85.09635447587408,-18.338030621533434 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark62(52.70292195270927,2.8521270017324216,-0.9732267014953493,56.7486023675632 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark62(54.13206467485102,17.08426100867537,36.281429611395794,42.120844567976434 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark62(54.7482015641522,65.43428795566786,3.351533006124626,-79.65331916840313 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark62(56.08501693005152,-1.7763568394002505E-15,18.16180918593237,37.50073745344628 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark62(5.670941513845966,-3.0385816786431356E-64,100.0,-100.0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark62(57.09490224529307,0.0,-32.17422602860394,-59.4761019984516 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark62(57.51030707291437,73.5600014507232,-15.676946604228988,-10.625964153402933 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark62(5.937499441151445,-4.7477838728798994E-66,100.0,-100.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark62(61.04321032982661,-4.7920936353041945,34.311852651503614,21.939264043018795 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark62(61.65017365314304,-45.897723546610194,-23.606924253864804,39.35937436039765 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark62(61.78652369597154,-22.482215366984562,-53.19885302082697,-67.11202622993922 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark62(61.83454837198835,-67.44426000101072,34.99199100197823,-0.916824476553849 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark62(64.0650264516871,-3.4599039848598294E-4,18.92733179188402,-100.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark62(64.0746478545119,1.3363823550460978E-51,-76.12018111137448,-100.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark62(66.91802086976196,8.89103499794031E-162,-9.637818236789496,100.0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark62(71.80490908269283,1.1752022625565337,-100.0,-100.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark62(74.58936561852418,-3.469446951953614E-18,71.50382503982942,66.18196102297412 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark62(74.79721115610215,-33.26222450368563,13.219932310613956,50.710975315687165 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark62(76.87114675198305,22.462095649393362,-50.556658201137864,7.3099314289763555 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark62(78.74665081434169,-1.3552527156068805E-20,77.93952627161687,27.91591973790809 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark62(81.11214938339907,-35.77798261981293,94.29813869672532,-23.866469300345457 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark62(82.4605497155035,55.28688477841271,71.99446224880944,92.31745679067191 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark62(83.66276039185234,3.0385816786431356E-64,-95.23183673819491,-41.7806685188837 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark62(84.42103684176726,17.57877517135718,25.48216875599043,-99.08019774141343 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark62(96.79055719458847,-27.239790889103332,50.488542273814886,-35.75651815389406 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark62(97.1425584270687,47.97883348390397,50.150456462819506,-51.839601184524064 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark62(99.99999999999923,7.596454196607839E-65,-8.347107747367042,-74.43274924473396 ) ;
  }
}
