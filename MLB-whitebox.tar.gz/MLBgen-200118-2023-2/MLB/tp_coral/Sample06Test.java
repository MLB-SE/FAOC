import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(-0.0011843526283965395,-0.3975965249741868,44.28958561942254 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(-0.0013030668579633517,-1.5707963267948983,109.95568440038663 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(-0.0016216168125353647,-0.47403995671653476,53.780718951780614 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark06(-0.0017009465700477122,-32.4967286679193,89.96433079040753 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark06(0.001805898029435593,-1.5707963267948957,-179.3590435788603 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark06(-0.0018454568352767992,-1.0792095626362324,-58.853919362555985 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark06(-0.00215526155702784,-0.49420231729470165,-7.473883474805646 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark06(-0.0024810179537155513,-0.6485788888123079,65.9818736275137 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark06(-0.0025523071900810106,-95.63883296433129,37.89671566129834 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark06(-0.0026472686563108055,-1.7763568394002505E-15,71.57237384238444 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark06(-0.002875820844408153,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark06(-0.0029182857772722033,-37.935001061688666,59.4469196815036 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark06(-0.0030127227076467717,-1.5707963267948966,54.351102028420925 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark06(-0.0030488551876452913,-32.54961143478586,1.5707963267948957 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark06(-0.003209943440777977,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark06(-0.0034129720352576443,-32.48777246020444,37.90502798870493 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark06(-0.003692611978344531,-0.9220296230517193,24.15608219959065 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark06(-0.0037612532063728494,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark06(-0.0038857681627988694,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark06(-0.003955546775615329,8.673617379884035E-19,-100.0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark06(-0.004098099793647947,-1.5707963267948912,-48.983753443478115 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark06(-0.004491215069828081,-3.574167873659224E-5,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark06(-0.004555430324404197,-31.47495092756271,1.5707963267948963 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark06(-0.004688719611345576,-1.479219962524482,-97.0150308150251 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark06(-0.005056421448903695,-94.36748266994015,21.60255509669092 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark06(-0.0052259321669035075,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark06(-0.0052940221276366614,-1.5707963267948966,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark06(-0.005358447790579393,-1.5707963267948966,-19.95271868027212 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark06(-0.005642841460067771,-1.5707963267948966,0.5588567541878176 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark06(-0.005808988748725397,-1.5707963267948966,-10.845878843982721 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark06(-0.005971817877154522,-1.5707963267948966,89.9764624878506 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark06(-0.00614629206143924,-3.552713678800501E-15,79.3323688876637 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark06(-0.006165189622784548,-32.586588051335085,90.20654834508889 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark06(-0.006343965189534557,-1.5707963267948966,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark06(-0.006663213422621903,-1.5707963267948966,17.85129030031406 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark06(-0.006763737115010216,-102.10127662870681,59.69022110464111 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark06(-0.006765283879872186,-1.541289338935604,52.3033167990248 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark06(-0.006921749299499957,-39.13993963430413,19.65188169206553 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark06(-0.006952029110065011,-0.9403344080393805,-37.0850895207997 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark06(-0.007046718098127083,-1.3449265481922719,-68.10728047402533 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark06(-0.007050164200727627,-101.83248635603483,6.774849673864441 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark06(-0.00709960705630921,-1.5707963267948966,-19.910880172066683 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark06(-0.007163744144390552,6.462348535570529E-27,76.72169322854549 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark06(-0.007616848255446264,0.0,9.495567745759799E-66 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark06(-0.007807173637802811,-1.5707963267948966,2.8511134188511407 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark06(-0.00795860466988689,-100.56416960154178,1.5707931048706503 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark06(-0.008808268456453086,0.0,0.0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark06(-0.009327063447092776,-1.5707963267948966,-112.45998703296902 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark06(-0.009373797093106845,-1.5707963267948912,-50.760990398152536 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark06(-0.009771429974028781,-1.5707963267948912,-48.879011846050616 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark06(-0.009834788250555462,0.0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark06(-0.009953450183445544,-1.5707963267948966,-59.60490869299511 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark06(-0.010030579926836758,-1.5707963267948966,-22.618027831604095 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark06(-0.010132471560877931,-3.552713678800501E-15,-31.541945744368192 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark06(-0.010142515541098088,-3.141592653589908,125.21072370536064 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark06(-0.010310470580733977,-0.1766326947964325,-100.0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark06(-0.010340030898353074,0.0,0.0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark06(-0.01062555180332962,-1.5707963267948966,8.306439155740321 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark06(-0.010698340078082381,-0.39676509535056237,52.77974671331097 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark06(-0.010721609113178151,-1.5707963267948966,1.1270725851789228E-131 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark06(-0.010740858369836204,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark06(-0.010856613132899111,-1.5707963267948966,-1.570796326794897 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark06(-0.010926709555977021,-1.2783440711233984,-6.712389075350493 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark06(-0.01096909040777167,-1.2944535812481397,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark06(-0.01119657378434967,4.7804465323318104E-17,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark06(-0.011351195236054767,-1.232595164407831E-32,88.09792001898401 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark06(-0.011354236986202523,-2.8736502787509794E-31,-2.5707026987714046 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark06(-0.011965882666635286,-4.440892098500626E-16,32.99215684243639 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark06(-0.012376934545461626,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark06(-0.012885098109408168,-7.105427357601002E-15,-7.649948887558381 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark06(-0.013396446532427688,-1.5707963267948966,-5.125615300124454E-16 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark06(-0.0137094809968612,-3.141592653589795,-80.50339055034483 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark06(-0.013768967358422616,-1.5707963267948966,-16.089243405203632 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark06(-0.013810829695174607,-1.5707963267948966,-168.60202853568623 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark06(-0.013898640710201464,-0.009936422068641775,-1.5707963267948966 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark06(-0.014184444924641219,-1.5707963267948966,72.25663526655916 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark06(-0.014207333553008347,-1.5707963267948966,-47.12389075942644 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark06(-0.015790986894993305,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark06(-0.015951191143878447,-0.03791194832605527,-106.81465447488743 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark06(-0.01597581168993112,-1.0089698153203162,36.19840846201712 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark06(-0.016119472276679314,-1.5707963267948966,-8.419009109361852 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark06(-0.016149054770495795,-0.1707852618363526,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark06(-0.016254501841357915,-1.5707963267948966,-3.141592653589793 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark06(-0.016997689097131036,-1.5707963267948966,34.15192416783097 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark06(-0.01715633230953756,-1.5707963267948966,49.29366539705622 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark06(-0.01724463411121313,-1.3936800649281933,-3.266594504002165 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark06(-0.017305540469779224,-45.52549722100359,1.6332963267955138 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark06(-0.01778785581723791,-0.05863602846540753,3.1415926535897936 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark06(-0.017793336716630748,-0.005791879439885226,18.028790679657277 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark06(-0.017798276961476844,-0.7072969374289368,58.735148948048675 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark06(-0.017846935285867498,-1.5707963267948966,-81.68143615162663 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark06(-0.017880251368646682,-0.011278682737117155,44.90203533319804 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark06(-0.01804452289657683,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark06(-0.018279118024632005,-0.014562807669932471,-46.895617082889764 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark06(-0.018311452591792232,-1.5707963267948948,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark06(-0.018682597020821534,-44.13942328870438,25.534377254730117 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark06(-0.018850079300158532,-0.09977075563310635,-0.6681036452244502 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark06(-0.01919780988172959,-38.928518549377586,1.5707963267948983 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark06(-0.019331844720852587,-101.96699956908883,2245.7728746017638 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark06(-0.019375997088577394,-88.46086572868879,31.90777433642552 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark06(-0.019714680156401918,-1.5707963267948966,53.714980619668005 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark06(-0.019951975416276538,0.0,0.0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark06(-0.02032173717454249,-0.7791456830222231,60.75969189783506 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark06(-0.020404349025449346,-1.5707963267948966,-47.0613155705974 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark06(-0.020716912681736997,-32.65818513169411,1.5707963267948961 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark06(-0.020731103524871956,-1.5707963267948966,-10.458015439407639 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark06(-0.020873143168511833,-0.06704119811281639,0.0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark06(-0.021256651342081684,-1.5707963267948966,-74.11576968407999 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark06(-0.02176197260049729,-1.5707963267948966,42.8831243604602 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark06(-0.022140355767599484,-1.4340513300397908,0.842359729523213 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark06(-0.02236178752452389,-0.305873506817657,-9.621555244583107 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark06(-0.022546893460480888,-0.625090526582599,84.95714836272691 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark06(-0.02324404248770589,-31.415926537587442,0.95930742237756 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark06(-0.02324737819065286,-38.86056026133073,1.5707963267948963 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark06(-0.023499677298872375,-1.5707963267948966,2.589599066337132 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark06(-0.023527297639273803,-1.4528229703594029,-26.986235698448553 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark06(-0.023600656509057783,-1.5707963267948966,3.1415926535897953 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark06(-0.023948816710927412,-1.3031773600259262,77.43830834744062 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark06(-0.024181330822894982,-1.5707963267948966,1.8744405016969665 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark06(-0.02420512610176606,-1.5707963267948966,53.14468705876494 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark06(-0.024505828574567887,-0.4820893306074186,44.47126163912017 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark06(-0.024931081252254052,-0.7566532772428345,-55.29611042113703 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark06(-0.024977563970058587,-39.0934424901435,39.35074696464716 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark06(-0.0250611905955906,-1.570796326794896,-15.547877153933642 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark06(-0.02528228331857907,-0.3659953105728131,-1.3430320734646097 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark06(-0.025407896400377494,-32.788744202890314,0.3295309582064738 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark06(-0.025752400454217683,-1.5707963267802103,20.951125578267018 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark06(-0.026079304291407358,-1.5707963267948966,-84.82241594436681 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark06(-0.026425975033785055,0.0,0.0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark06(-0.02647253435599812,-1.5707963267948983,-136.184528498033 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark06(-0.026709714291456077,-0.3375148447491469,60.393109046158486 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark06(-0.027103849624659428,-1.5517362896417377,-1.5707963267948966 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark06(-0.027122473459676555,-1.0877862744234819,-57.938807129994345 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark06(-0.027843538428660372,-1.5707963267948966,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark06(-0.028229529422342914,-1.5707963267948966,6.338015729487787 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark06(-0.028358148774644834,-31.415926575646136,19.1778855101477 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark06(-0.028710821592014213,-0.9235082490630764,-62.44101752813475 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark06(-0.028759736946337044,-0.4354393283882141,1.5707963267948966 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark06(-0.029464936766130104,-1.5707963267948966,53.696751142200355 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark06(-0.029615088489612675,-0.03237792209668596,1.4701518759645102 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark06(-0.03001920899065367,-1.5707963267948963,43.3998774337764 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark06(-0.030223447794782282,6.938893903907228E-18,-1.5707963267948966 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark06(-0.03056912283714272,-1.5707963267948966,-3.3080141283704996 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark06(-0.0312898399443217,-1.5707963267948966,7.314769871130096 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark06(-0.03130132502219797,-1.5707963267948968,-32.22859409648406 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark06(-0.03138345829829858,-88.340473607894,21.027404216716672 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark06(-0.03157249246148188,-1.5707963267948966,39.19390280235757 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark06(-0.03170465710957328,0.0,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark06(-0.032191734549736895,-1.5707963267948966,-39.875483224942556 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark06(-0.03222193003155882,0.0,0.0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark06(-0.03244750819967085,-1.5707963267948886,-36.32877350446786 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark06(-0.03287545384535995,-1.3411614941070678,-68.04641315163967 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark06(-0.03298399100912135,-1.5484477007489899,-31.49499263027586 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark06(-0.033744703452534795,-1.5707963267948966,-1.5707963267948961 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark06(-0.03425274117246335,-1.5707963267948966,66.5736426547146 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark06(-0.03457172471811351,0.0,0.0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark06(-0.034752273609809425,-38.74313986250472,27.460406875279645 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark06(-0.03568477272150422,-1.5306346155312216,-100.0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark06(-0.03604341209108816,-1.5707963267948966,9.424777961663528 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark06(-0.036197481652366234,-88.33169936988845,3.552713678800501E-15 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark06(-0.036433040587987936,-1.5707963267948912,3.141592653589793 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark06(-0.03661545135610412,1.3877787807814457E-17,-67.86488342606036 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark06(-0.03682113966726552,-0.5386525449695336,-4.024098066537036 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark06(-0.036882991799487896,-1.5707963245055676,-100.0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark06(-0.03785664573386362,-1.0232266322444181,-0.014516952251633183 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark06(-0.039794141553316946,-1.5707963267948966,-4.712633330597127 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark06(-0.03985232432084547,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark06(-0.04010728264570357,-32.84304976513327,20.292796905963215 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark06(-0.04040505954126621,-0.06093584878089153,-27.443570020141834 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark06(-0.04041711679540494,-95.63651411553593,59.59537908415379 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark06(-0.04051773700531423,-1.374374996422662,-71.4283487750706 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark06(-0.04074599285378466,-1.4515439439853708,67.02137012110825 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark06(-0.040847241597809725,1.4210854715202004E-14,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark06(-0.0412943758170556,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark06(-0.04262863369679892,-1.5707963267948966,-5.154675541340197 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark06(-0.04274222850371827,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark06(-0.04280538330450989,-39.20889231220198,7.8539969701916545 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark06(-0.043646511007938905,-0.38109187816698054,-77.2453353304649 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark06(-0.04398351458379146,-38.83297386564624,-6.712449440542883 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark06(-0.04434278490169741,0.0,0.0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark06(-0.044343931522356606,-0.7337819500621882,-2.0303534698525194E-115 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark06(-0.044699459911032316,-1.5707963267948966,39.034049246617954 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark06(-0.0452891752607919,-1.5707963267948966,31.88084498142028 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark06(-0.04609269701439585,0.0,-5.267575453093372 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark06(-0.046607739460480524,-1.5707963267948966,193.2069049656669 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark06(-0.04686012476094625,0.0,-100.0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark06(-0.047371865670721276,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark06(-0.04784146033346248,-1.5707963267949054,21.349046925180858 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark06(-0.048260965088297025,-1.5707963267948966,-25.6240498384023 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark06(-0.048974401002594654,-44.186818301567335,1.3618645960054543 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark06(-0.04907301127205704,-1.5707963267948966,-35.2642337127915 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark06(-0.049084953732704696,-1.5707963267948966,65.16372975373105 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark06(-0.049234640710697275,0.0,0.0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark06(-0.04946889512322562,-1.1186469635597796,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark06(-0.05015231607801734,-0.443339148994641,-47.58759414091621 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark06(-0.05121646225524998,-3.1415926535898064,-5.902636796776339 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark06(-0.051279725999189105,-1.5707963267948966,3.2665926742238716 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark06(-0.05137559755347307,-1.5707963267948966,-1.6332963267952136 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark06(-0.05188130122321866,-38.73589663830483,39.4984874565641 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark06(-0.05208662586421852,-1.5707963267948966,-64.49669472385412 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark06(-0.05220017391177026,-0.8701846692439806,3.141628185629179 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark06(-0.05283407313368352,-1.5707963267948966,87.91593874282646 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark06(-0.05303248670399075,-1.5707963267948966,-15.912306597914295 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark06(-0.053235200945223084,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark06(-0.05357115903928496,0.0,-100.0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark06(-0.05367049420266756,-1.5707963267948966,-0.06770799580372028 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark06(-0.054099296431697835,-4.482885911048132E-18,-0.22814028760393948 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark06(-0.054658479793253056,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark06(-0.05536505020917512,-38.87090089490343,45.393791844919015 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark06(-0.05543733044125054,-1.5707963267948966,-0.11060351695389146 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark06(-0.05570427565738235,-1.5707963267948966,68.56776906380719 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark06(-0.05570752899175446,0.0,0.0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark06(-0.05583861271908211,-44.205691311637494,1.2808571702328542 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark06(-0.055894588035029565,-4.004166190366202E-146,-44.99053826057681 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark06(-0.05601562903121319,-44.98784414754745,1.5083888439050135 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark06(-0.05650846388791475,-1.5707963267948954,-1.5707963267948966 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark06(-0.056579892214210226,-1.5707963267948957,33.45946203302091 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark06(-0.05791000752760739,-0.7040163621312515,-4.258588778149569 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark06(-0.057955257836305674,-1.5707963267948966,29.877507460190486 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark06(-0.058172632730120015,-94.2784874952887,90.6440917130115 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark06(-0.05830806639078997,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark06(-0.05866381664789011,-1.5707963267948966,27.605687262194238 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark06(-0.05883557738888169,-1.5707963267948966,-68.17619830577925 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark06(-0.0590195951509625,-0.8540153310861953,25.557338264254412 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark06(-0.05915081419432481,-1.2667930573062307,-33.07849061582205 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark06(-0.059455821126061556,-0.25022754982077805,14.627461453252039 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark06(-0.06009627695182457,-1.554744251959779,-99.72575482447253 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark06(-0.06019012129829693,-1.5707963267948966,9.978076284900084 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark06(-0.06164576611284515,-1.5707963267948966,-11.007244712374757 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark06(-0.06176483999009364,-1.5707963267948966,-3.141565825144808 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark06(-0.06209941518681696,-0.534113051428588,-3.141592653589793 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark06(-0.06309037906047676,74.38245663964715,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark06(-0.06324400364664232,-44.21772034809942,296.96005268841833 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark06(-0.06354883135577516,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark06(-0.06405727012928475,-32.9258341195212,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark06(-0.06417963434289975,-1.5707963267948966,-30.328411886526442 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark06(-0.06421891272162947,-38.98267232144273,108.95340032217273 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark06(-0.06493652334830302,-100.68651156883728,58.58722988946117 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark06(-0.06516405415847504,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark06(-0.06896232200348065,-1.1923702615043619,66.50598706494966 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark06(-0.06935580730135515,-0.6124313989237775,83.89041059640476 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark06(-0.0697915862186229,-0.3183037806255159,-3.154583020633377 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark06(-0.07068503932509156,-1.5707963267948966,-53.523403330181274 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark06(-0.07083173679683635,-4.0389678347315804E-28,53.55960361068292 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark06(-0.07164198732687477,-0.8683385556522994,100.0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark06(-0.07245561081283913,-95.5490558928783,0.3943868376949189 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark06(-0.07298560920140673,-1.5707963267948966,-56.82074145576688 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark06(-0.07303472237024389,-1.5707963267948966,-130.24938738840783 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark06(-0.07327138373925529,-1.4599492722155833,-11.01218296276025 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark06(-0.07331504399435579,-38.961629069697665,53.095478206542225 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark06(-0.07363198039130123,-1.5707963267948966,-124.03718251322367 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark06(-0.0738359744188326,-1.2813331809171846E-144,90.67812881678145 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark06(-0.07392153233710463,0.0,1.6242827758820155E-114 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark06(-0.0741495790034479,-8.231771882275545,45.44417284276039 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark06(-0.07453059681047258,-1.5707963267948966,-44.70927021326414 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark06(-0.07494524499772148,-1.5707963267948948,10.216730203348742 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark06(-0.07505935554847686,-1.5707963267948966,41.418803741868025 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark06(-0.07542977773741377,-1.5045896363372095,9.68300354718815 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark06(-0.07633373975299163,-45.55309206557337,116.09916145882345 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark06(-0.07662660213711449,-6.2565096724471904E-148,1.104330710237359E-15 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark06(-0.07667961683685602,-1.5707963267948966,1.5707963267948977 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark06(-0.07742883708165643,-1.5707963267948966,-4.8442398918803775 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark06(-0.0776316506030791,-1.5189014650802046,11.355635326901812 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark06(-0.07803109344057191,-0.46792937560149417,-58.57465448599818 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark06(-0.07907369849860335,-0.252431888699606,-11.652381544482097 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark06(-0.07929013530712492,-1.5707963267948966,71.39191283884449 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark06(-0.07938755085266598,-0.11528820288659798,-1.5707963267948966 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark06(-0.07987476947089735,-1.124281734530185,-45.560070103928396 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark06(-0.08176606549083236,-1.5707963267948966,1.5720343698166597 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark06(-0.08196401136334443,-1.317120172541141,-44.46924658442296 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark06(-0.08236010963449789,-2.1684043449710089E-19,-66.68154576345611 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark06(-0.08352421642244678,-1.512782381897993,698.9740456191377 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark06(-0.08380498395071126,-39.032639374277224,33.665508559090625 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark06(-0.08417651937889237,-32.865672035340026,-17.279248581214016 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark06(-0.08503289756161636,-0.0841102525588866,-89.86933780171573 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark06(-0.08664528016669021,-1.496734967796003,-40.51703839894216 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark06(-0.08774464101684717,-1.5707963267948966,0.7045952481290686 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark06(-0.08790769892880401,-163.7007516990098,-3.2861257955685514E-8 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark06(-0.08858773061551889,-32.616983025563094,8.722429770541169 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark06(-0.08866690795534016,-45.13577264526964,95.59381762592076 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark06(-0.08904012562144603,0.0,0.0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark06(-0.0896003534717094,1.0842021724855044E-19,95.41435488367183 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark06(-0.08966086319920599,-1.3314603555039555,101.61942073701303 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark06(-0.08998771136381833,-1.5707963267948966,53.73401122121873 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark06(-0.09064008377135446,0.0,1.5707963267959868 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark06(-0.09082882607165474,-0.4110074735058258,-17.279628624480708 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark06(-0.09115112289466257,-4.5082903407156913E-131,-82.7962568154876 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark06(-0.09130219178335841,0.0,0.0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark06(-0.09189576587285053,-0.4505718562565107,-11.776175931646959 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark06(-0.09251533461303207,-1.5707963035332762,18.14989858153916 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark06(-0.09255441539335152,-1.4436596206754542,-9.333179421818969 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark06(-0.09293589902175813,-1.5707963267948966,33.391582011965276 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark06(-0.093085607963582,-1.5707963267948966,65.75460487798759 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark06(-0.09329441733193587,-1.5707748582780159,2.622369760520702 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark06(-0.09569389668799631,-1.2117285370224837,1.5707963267948966 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark06(-0.09577572145062477,-1.0357380099434796,3.2667804627745065 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark06(-0.09660932357726892,-8.881784197001252E-16,9.67236714494966 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark06(-0.09666768215922872,-1.5707963267948966,-61.43736564065332 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark06(-0.0966954218132452,-1.5707963267948966,-91.01011799885148 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark06(-0.09758954953860233,-1.3237210824419536,-4.712389934476586 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark06(-0.0985825244981169,-1.5707963221945656,-4.324388197070533 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark06(-0.09891763952909932,-31.680100830561535,77.9743721335042 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark06(-0.09898130515746928,-1.5707963267948966,72.67756580769347 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark06(-0.09904471505984563,-1.5707963267948966,77.2760550155435 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark06(-0.09935089794911257,-1.5707963264105873,-62.61025045817699 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark06(-0.09952849564158288,-1.5707963267948966,-80.5039962745966 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark06(-0.099548252459841,-0.644093648032765,62.492358128503824 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark06(-0.10052706248474765,-1.5707963267948966,-36.87662797116176 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark06(-0.1006208090159735,-1.5707963267948966,55.67664327833199 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark06(-0.10129395107031329,-3.141592653589795,62.77290098210318 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark06(-0.10234564392531828,-0.9539656028195781,-60.70778490637819 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark06(-0.10247471621909368,-45.03931756740391,40.1926084110033 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark06(-0.10269165774543651,37.48699868995829,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark06(-0.10298916902759991,-0.4879087507509591,88.27627258923714 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark06(-0.10342820609479947,-1.5707963267948966,44.37902962923434 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark06(-0.10414809376253206,-0.11826959610799292,-97.10005433698213 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark06(-0.10652787216609404,-0.15840547788611037,1.5707963267948966 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark06(-0.10681189882391857,-1.5707963267948966,87.93751717660525 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark06(-0.10806923181265599,-0.1329573846461063,2.1063259046294363 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark06(-0.10890343031535643,-0.4709340649497458,96.67138949017274 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark06(-0.10917970394894376,-1.5707963267948966,-71.69387815525744 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark06(-0.10966846603488195,-1.5707963267948966,1.570796326794898 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark06(-0.1106643065929742,-88.37481327087168,75.526482697935 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark06(-0.11129682315653816,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark06(-0.11250872662469646,-1.5707963267948963,7.8617941396322015 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark06(-0.11330480068287141,-44.17730432338142,0.236811012687078 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark06(0.1136023459114487,0.0,0.0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark06(-0.11403672549932187,-1.5707963267948966,-63.28536185306628 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark06(-0.11420602904326287,-1.5707963267948966,-73.57276967216445 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark06(-0.11656161382417896,-1.5707963267948966,-3.733627205629734 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark06(-0.1168702135212345,-0.5926597619755967,-9.64273613164238 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark06(-0.11698356764770512,-1.5707963267948966,0.9650199782730378 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark06(-0.1172061543036702,-1.5707963267948966,-13.02863489918181 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark06(-0.11739365773964051,-45.099548107197165,51.958119390984194 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark06(-0.11831380306592909,0.0,0.0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark06(-0.11833281241357427,-1.5390159477903897,55.59710889545737 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark06(-0.11863264895133716,-39.22700023450654,7.69231115109527 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark06(-0.11882515987685872,-95.74337095932863,0.0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark06(-0.1188747709143601,-0.42490884517392796,1.5707958315792607 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark06(-0.12114968097734446,-0.03153996323251084,47.97396361495382 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark06(-0.12138040049594823,-39.21142562409641,75.40838866516802 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark06(-0.12157696048672606,-1.5621477953751395,0.0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark06(-0.12211248254614304,-77.25502553042193,164.45148877562667 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark06(-0.1221317158053854,-88.12539499861289,0.08208771329854458 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark06(-0.12220724290436635,-1.5707963267948934,105.75954698610118 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark06(-0.1225524532748743,-1.5707963267948966,-58.193399376407726 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark06(-0.12268714680731996,-1.5707963267948966,-84.3002380976647 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark06(-0.12311829907527017,-45.46770194757901,94.28358773019275 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark06(-0.1231947548571587,-0.024443638640076384,163.52300654854244 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark06(-0.12338746324339527,-1.3210970940415536,74.35227977752662 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark06(-0.12383854921691512,-0.5489133458046535,7.913324862135667 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark06(-0.1245263358593009,-0.07211697885456309,-76.24810174512564 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark06(-0.12507556982959933,-38.78729656049228,27.69866184505878 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark06(-0.12566272184163355,-1.5707963267948966,-31.77485496095312 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark06(-0.12716704787990762,-0.20769169585055103,0.0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark06(-0.12788660438641714,-0.36667597025443677,-72.66727050660401 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark06(-0.12851379667947552,-1.5707963267948966,95.82568952121183 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark06(-0.12860391022887607,-1.5707963267948966,2.5294886092068936 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark06(-0.12881916588142342,-1.4911403062292898,3.141592653589793 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark06(-0.1300484662043795,-1.5707963267948966,353.50108239576315 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark06(-0.13008095044246382,-0.8149126815558045,-10.995696446005162 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark06(-0.13035967174607277,-4.138590405103494E-15,-11.258152593924798 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark06(-0.1312575429570092,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark06(-0.13135147220481797,-1.5707963267948983,2306.1428224263045 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark06(-0.13138241832520584,-1.5707963267948966,77.84971717704607 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark06(-0.13155899851817981,-0.2725248698984086,-1.5707963267949054 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark06(-0.13202153996259414,-5.998787255582524E-241,-27.746635252348256 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark06(-0.13227479312841106,-1.5707963267948966,2.2841606298429085 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark06(-0.13240191460951992,-1.5089508195182855,-44.21025365756964 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark06(-0.13280173682634938,-0.5487826906610764,35.06582060925933 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark06(-0.13399594679609161,-1.2220455076597454,53.84909269410836 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark06(-0.1344676662937765,-1.5707963267948966,4.395274585207997 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark06(-0.13535753894302327,-1.5707963267948966,56.52611512691473 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark06(-0.13572649494805536,-1.5707963267948966,70.88966025521869 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark06(-0.13603587850487336,-95.30728876331155,1.3989391369097888 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark06(-0.1360602484940287,-1.5707963267948966,71.1455327228289 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark06(-0.13734543758486595,-0.16229812429374044,-26.97657535355546 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark06(-0.13786685223097606,-0.5591529068750205,28.160636965552932 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark06(-0.13787142144719788,-1.5707963267948966,-84.12399058180748 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark06(-0.1383675667179297,0.0,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark06(-0.1392314397302754,-3.1415926535905423,8.775060766292944 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark06(-0.13934123722401726,-1.5707963267948966,42.082859410621566 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark06(-0.13964678150725707,-1.2522088976194465,57.832285387295045 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark06(-0.14009451476348758,-0.35005990751206406,56.24076941138799 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark06(-0.1400953613275202,-1.5707963267948983,-29.100241358887047 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark06(-0.14076165528917906,-1.3843786770712336,-1.5707963267948983 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark06(-0.14212691060500862,-1.5707963267948966,-1.5707963254284223 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark06(-0.14245136138004466,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark06(-0.14318177170734536,-0.7060243490222985,4.71782784174775 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark06(-0.14362734033770463,-1.352879303328974,3.1415926535897967 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark06(-0.1452508126101762,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark06(-0.14662488609485097,-1.3877787807814457E-17,-41.35866530063822 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark06(-0.1468321367734522,-1.5707963267948963,1.5707963267948966 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark06(-0.14700321006878525,-88.17043881688488,1.734723475976807E-18 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark06(-0.1473753533460822,-32.831660397050925,593.619303209351 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark06(-0.14940118611136155,-2.5026038689788762E-147,-29.082496413561536 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark06(-0.14991566149741664,-32.97299272849898,71.61780943605815 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark06(-0.15014698365469759,6.7123902106851725,72.2524826091398 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark06(-0.15078113709337693,-278.0300817116638,88.51773404457191 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark06(-0.15088155495434896,-1.4476110861248483,-24.53572210917505 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark06(-0.15104258498406276,-1.5707963267948966,48.03423356881373 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark06(-0.15244019813905768,-1.5707963267948966,-71.59000598034396 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark06(-0.15248808010522508,-77.06194290369554,3.0155926629327077 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark06(-0.1541380118243674,-1.570796324257069,46.099540757383785 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark06(-0.15432777511657095,-44.54221267446347,-6.712390082750403 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark06(-0.1545071838373262,1.9721522630525295E-31,-84.07489867616982 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark06(-0.15463957277669993,1.5707963267948968,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark06(-0.1546636803993311,-1.5707963267948983,-63.089194282712704 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark06(-0.15497147415001677,-84.29683681502958,82.61131324587728 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark06(-0.1562551508810872,0.6930272961686453,2.220446049250313E-16 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark06(-0.15664156073801563,-1.3302312266237901,-6.712388980765623 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark06(-0.15690245419492033,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark06(-0.1577825094375199,0.0,0.0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark06(-0.15801800568554666,-0.10586270903573208,-62.07470759362479 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark06(-0.15858779964082176,-1.5707963267948966,-52.152308973772435 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark06(-0.1586478021762734,-1.5707963267948966,95.86512940240615 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark06(-0.15867079091042618,-1.5707963267948966,9.552867389350155 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark06(-0.15899301078004235,-101.80490825903688,82.52426286003859 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark06(-0.15907568549458442,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark06(-0.15939951302513444,-44.460226176938804,63.57503715574357 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark06(-0.15968214675256834,-1.0609554562867052E-14,-64.59659520735939 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark06(-0.16076453018686748,-1.5707963267948968,82.1795916421197 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark06(-0.1610598074125121,0.0,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark06(-0.16199708031571447,-1.5707963267948966,-58.40953205637478 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark06(-0.16235504612475374,-1.5707963267948841,39.06764342223394 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark06(-0.1634291941613633,-1.570786763837633,-193.20778933198292 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark06(-0.1638048749118579,-0.8663931567872686,6.783389951810723 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark06(-0.16571509217542868,-1.2669379987044098,-136.6182395624562 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark06(-0.16591377036403498,-164.83478291154464,1.5707963267948974 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark06(-0.16605387105248193,1.1102230246251565E-16,14.840665021174503 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark06(-0.16655028745910883,-45.21892465701307,39.53840021732414 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark06(-0.1671360226574881,-44.08699515959293,33.02091282266423 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark06(-0.16769590063384499,-37.79213203003661,189.89987580247433 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark06(-0.16802254924877494,-1.5707963267948966,-47.723455384188846 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark06(-0.16808522276166804,-1.232595164407831E-32,31.472848960388674 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark06(-0.16838942563381312,-1.5707963267948966,12.916980579242084 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark06(-0.16923854888109213,-1.5707963267948966,67.96900691266305 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark06(-0.17167218618890834,-0.00925049924898939,-75.00561647478848 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark06(-0.17215602736465963,-37.875632124960795,58.45321162454246 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark06(-0.17251642214114768,-1.5707963267948966,-34.403566755278206 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark06(-0.17295437019027135,-45.206288531741514,59.00705115717745 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark06(-0.17302034642297964,-0.6520996279098317,-32.52370553308233 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark06(-0.17315839161990937,-1.5707963267948966,91.79220678016375 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark06(-0.17363239277858894,-88.49688585960659,58.46408720314065 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark06(-0.17424349252133808,-0.03899361415401641,-53.952466165727245 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark06(-0.1745767249003336,-1.5707963267948966,-146.43843213736744 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark06(-0.17466677537579223,-1.5707963267948966,61.4709608567934 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark06(-0.17497918083860273,-1.5707963267948966,22.1370033501395 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark06(-0.17532145982465167,-0.30016161174580036,1.5707963267948968 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark06(-0.17568295932445996,-1.5707963267948966,0.9459330564810944 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark06(-0.1757207857197045,7.853981633245609,0.04441272989366833 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark06(-0.17591073509035482,-1.5707963267948966,80.75491355798002 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark06(-0.1782436809314909,-1.5383107025335476,-44.03375293954715 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark06(-0.17860002477439468,-1.5707963267948966,-1.4074715529809654 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark06(-0.1787462439068416,-0.9629391244739214,-31.505423976149032 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark06(-0.1788977458655841,-1.5707963267948966,51.79874120801662 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark06(-0.17935299171015615,-1.5572777936605178,-15.027765410996443 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark06(-0.18029354159324174,0.0,58.00371992033664 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark06(-0.18354179939168686,0,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark06(-0.18465833155446187,-31.90366147491943,158.2346585133291 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark06(-0.1853223809247903,-1.5707963267948966,73.59117346641091 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark06(-0.18535083836764069,-0.7744841735960029,9.900453641253947 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark06(-0.18562427131953488,-44.222566436817935,163.69466368856524 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark06(-0.18718212180135413,-1.5707963267948966,-75.300931520424 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark06(-0.18750779467335504,-0.09046443878558846,4.71239679626682 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark06(-0.18780260933148518,-0.534960617093732,31.846443241628318 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark06(-0.18782362605030944,-1.5707963267948966,21.442365813312104 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark06(-0.1881481646257619,-2.220446049250313E-16,-1.5707963267907985 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark06(-0.18845307825269456,-0.13854612319302337,-6.7123890185928134 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark06(-0.18915684552389334,2.7239693108412847E-22,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark06(-0.18994487869886537,-1.5707963267948966,-39.38079486851926 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark06(-0.189968857799248,-1.5707963267948948,79.96775000263186 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark06(-0.1903963124800201,-38.82544327595314,18.84955592153876 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark06(-0.1932599914581239,-1.5707963267948966,-64.72817391919861 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark06(-0.19676108448757354,-1.0010415475915505E-146,10.582084280032555 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark06(-0.19688823592944174,-0.20647715807777306,-43.15138033108066 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark06(-0.1969676266298942,2225.750530289729,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark06(-0.1974672834392201,-32.926761271644985,95.4397266973456 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark06(-0.1980924646067308,-38.887204840978264,1.5707963267948977 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark06(-0.19902062476766685,-1.4437432921897653,1.5707963267948977 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark06(-0.19959145649320062,-1.5707963267948966,-83.63274266116524 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark06(-0.1998169319843789,-100.0,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark06(-0.19998689924313195,-0.13154155207059748,52.647210553389385 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark06(-0.20022513317090868,-0.27363686512716473,342.4331972682798 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark06(-0.2006272893847057,-19.389562843818965,51.81318954229485 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark06(-0.20078060166881762,-1.2025456312315552,40.99433018511033 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark06(-0.20081647153528667,-1.5707963267948966,-25.079413836435005 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark06(-0.20090022824311388,-1.0847796286256732,0.9690976146005649 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark06(-0.20106164782872327,-3.1415926535897967,95.7213347477454 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark06(-0.2012424697481407,-0.1909706360517731,-81.25695007142129 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark06(-0.20140366557164135,-1.5707963267948983,80.0196370172986 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark06(-0.20157048079600492,-31.415926564570498,91.07434441669152 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark06(-0.20236323378175314,-1.5707963267948966,-150.04924480322921 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark06(-0.20358360459102506,-0.4134847785293114,28.65358781557555 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark06(-0.20369784062719987,-1.5707963267948966,-3.141592653589793 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark06(-0.20434625546064722,-0.05850041210473743,-3.189177284967515 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark06(-0.20507175760960794,-1.5707963267948966,1.5717742654008915 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark06(-0.20697400812808753,-1.5707963267948912,1.1669138280992541 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark06(-0.20781605793507651,-0.4948944509973753,2.1351758295346173 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark06(-0.20836166122574018,-1.5707963267948948,-90.57453210820834 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark06(-0.2101216063385749,-44.065346969884885,82.94888441373885 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark06(-0.2106734474866343,-19.415476898859424,20.55820752013548 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark06(-0.2110341133876732,-1.4524318477574893,-32.95471027613792 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark06(-0.2118000629373937,-4.440892098500626E-16,-35.37571607730691 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark06(-0.21204385674550652,-0.04347216807645293,-80.35244937648864 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark06(-0.21253265758196835,-8.881784197001252E-16,94.48370304826203 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark06(-0.21305337347695913,-1.5707963267948966,-3.1415926535897922 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark06(-0.2147013998770666,-1.5707963267948966,165.43349875703808 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark06(-0.2150301204577869,-1.570371098674793,1.2432364465055643 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark06(-0.2172790859143079,-45.089538598076615,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark06(-0.2176373060556549,-0.45605252733132895,6.504291910246437 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark06(-0.21818578974608105,-100.83616771611241,1.4996387827535174 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark06(-0.21845634849689902,-44.4972355725377,0.5139859114271151 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark06(-0.21927115774532227,1.9721522630525295E-31,-1.5707963267948966 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark06(-0.21984009088560563,-44.29650225362975,77.35772232375902 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark06(-0.21994043817100556,-39.07753840639106,14.543907696285467 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark06(-0.22186444994695712,-31.49346062019513,1.5707963267949268 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark06(-0.2222202417178103,-1.0068192935602127,83.59170884793764 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark06(-0.22307372581749033,3.3087224502121107E-24,-37.39762318226465 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark06(-0.2234829298237131,-88.4946275866311,1.5707963267948983 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark06(-0.22422773532227674,-1.5707963267948966,-3.141592653589798 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark06(-0.22429103161524458,-19.38534077316825,0.0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark06(-0.22524074523186643,0.0,0.0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark06(-0.2257626709372802,-0.37433531117661745,-2.684853461684628 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark06(-0.22600566388910137,0.0,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark06(-0.2263697418678837,0.0,0.0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark06(-0.22642605017976258,-1.364804679000011,54.406224413838004 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark06(-0.22725051956446868,-44.43046654516437,45.441430017331285 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark06(-0.22743500227934987,-0.3505129016604849,79.92176747902326 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark06(-0.22806591538839496,-1.4526476815244627,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark06(-0.22837163936973703,-1.2366185988535587,-39.23820922265537 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark06(-0.22866858850730587,-88.48204665227412,39.16003715394575 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark06(-0.22912768248494453,-0.7670262575015494,135.38955278284885 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark06(-0.2296749859785434,-2.220446049250313E-16,46.439796962097404 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark06(-0.2300299772810133,-1.5707963267948966,44.53509530577193 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark06(-0.2302195930060822,-0.8030647227469933,44.48882708003549 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark06(-0.23094229603376837,-0.28725792452203563,1021.5730850500179 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark06(-0.23263856959276238,-0.16745224633360908,32.11114529518185 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark06(-0.23272038145508633,0.0,86.46559799767019 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark06(-0.23367324957865776,-0.5645316861049632,96.11817359282628 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark06(-0.2338163562483535,-0.16270116952568,10.754107699501532 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark06(-0.23419132337552573,-0.52555306805171,19.367538439351602 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark06(-0.23442286265188494,2.465190328815662E-32,-98.78305451919805 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark06(-0.2344919445275697,-1.160341699316172,-100.0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark06(0.23452276594805788,0.0,0.0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark06(-0.2358905825519071,-1.5707963267948966,-12.461452996498556 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark06(-0.2368454436934197,-0.37204576101988335,38.81780679205986 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark06(-0.23746550772828812,-157.58981451968515,1.561240061036937 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark06(-0.23756022170654836,-1.5707963267948966,-1.6332963267953275 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark06(-0.23807747290583126,-1.210674316365735,-29.86103167103983 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark06(-0.23844306284374372,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark06(-0.23864487121553585,-0.012805106100373696,-87.23552833912792 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark06(-0.23889979022172625,-1.5707963267948966,37.14458700755129 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark06(-0.2394898813809962,-0.33771558404825086,-100.0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark06(-0.23984129973885063,-1.5707963267948966,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark06(-0.24097901544744776,-1.5707963267948966,2.6305243759087213 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark06(-0.2411286450054142,-1.570796326794899,8.702494248129142 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark06(-0.2413454970518985,-0.50775909746735,-130.37513460246265 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark06(-0.2413548912296637,0,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark06(-0.24156479235217668,-44.35461457631329,1.5707963267948977 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark06(-0.24225794560543207,-1.5707963267948966,4.759113523732787 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark06(-0.24378503041169167,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark06(-0.24380742571243313,-1.5707963267948966,89.59615327287719 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark06(-0.24409875322400199,-1.5199254477943125,9.546629469250139 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark06(-0.2449748904468525,-1.5707963267948966,-3.1415934596729826 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark06(-0.2461539754354347,-214.0538912512954,58.07824483383922 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark06(-0.2475309047722085,-1.5707963267948966,-121.35933190151152 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark06(-0.24762619232838157,-1.4623193835994304,0.0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark06(-0.24782435840055386,-1.5614174296523058,-31.41592653589793 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark06(-0.24836845806124586,-0.051939315929904695,-58.84448017002414 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark06(-0.2502800887780836,-0.6190643693679371,1.5707963267949014 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark06(-0.25076942018879333,3.3881317890172014E-21,-56.908126174598856 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark06(-0.2508603897092314,-1.1874891530493397,86.78855853331655 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark06(-0.25182529973851886,-1.5707963267948948,-95.2063323390236 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark06(-0.25183360638934504,0.0,0.0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark06(-0.25217411061188666,-1.5707963267948966,-108.72856464675769 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark06(-0.25256568884687586,-37.699111843077524,33.72047149178863 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark06(-0.25268483767613403,-3.1415926535897936,32.463404203001836 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark06(-0.2553894533711727,-1.5707963267948966,-46.38204599351442 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark06(-0.2570509489890586,-0.6904655926526829,54.01377616375052 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark06(-0.25756571352141333,-1.5707963267948966,-7.87251059187785 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark06(-0.257674788927313,-1.1679847987629213,254.83300460991592 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark06(-0.2586580568209217,2.465190328815662E-32,20.709629990912294 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark06(-0.25899817162024036,-1.3081418945521455,-40.162028396571245 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark06(-0.2593348024026724,-1.5707963267948966,-2.5626663618343692E-144 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark06(-0.25966925291939175,-1.5707963267948966,-47.07694636979528 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark06(-0.261133515147019,-82.2217806963544,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark06(-0.26187924699758736,0.0,0.0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark06(-0.2633634015541115,-1.5707963267948966,0.2748159504004105 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark06(-0.2658461402927194,-0.8973870407913064,-100.0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark06(-0.2664586145360055,-0.6583439905598583,-100.0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark06(-0.2675812608680985,7.888609052210118E-31,1.2851504230636578E-17 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark06(-0.2681237065489525,-0.9614606049633195,1.5707962146699 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark06(-0.26986147270899463,-1.5707963267948966,3.1415926535897967 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark06(-0.2705235581537613,-0.01706781168450104,-119.97664468724807 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark06(-0.2713625038052327,-1.2274111593934167,-86.51482566820813 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark06(0.27176735253814854,77.2247542499858,27.06238598857516 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark06(-0.271978124439193,-0.02365011553869706,-1.5707963267948966 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark06(-0.2728098515701086,-1.5707963267948966,5.421010862427522E-20 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark06(-0.27415998028353145,-1.351704979284591,3.1415926480047682 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark06(-0.27425190472847216,-1.5707963267948966,-3.266782322260505 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark06(-0.2745538811208992,-1.4339447889441175,-73.486179890924 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark06(0.2746824693262443,63.63623881927059,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark06(-0.2749506017476227,-1.5707963267948966,-3.141592653589793 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark06(-0.2753785020153421,-7.105427357601002E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark06(-0.27572670883324,-1.5707963267948966,34.47079756638911 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark06(-0.2771069218266436,-1.5707963267948966,-14.468368796709527 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark06(-0.27884903575993375,-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark06(-0.27997545370320154,-1.5707963267948966,3.1415926535897967 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark06(-0.28252942513919543,-39.12071193922693,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark06(-0.28289502869881344,-45.55309347691764,1.5707963267948963 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark06(-0.2829009741605999,3.469446951953614E-18,1.5707963267948966 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark06(-0.28304448764304857,0.0,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark06(-0.2831699239485632,-1.5707963267948966,725.9451916695174 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark06(-0.2833769165223074,-1.5707963267948966,-9.785078477095816 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark06(-0.2841058427017167,-1.5707963267948966,-29.676753512989904 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark06(-0.28424041817077245,-0.034690035728135976,-7.2094147668607675 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark06(-0.28455171172330723,-37.82175728183867,69.85893907415132 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark06(-0.28486589506096593,-1.5707963267948966,-43.179100910892515 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark06(-0.2856374220019584,-0.3133935275691954,-100.0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark06(-0.2865659956833541,-0.9127331211653437,3.2666084003670663 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark06(-0.2867159052312591,-0.0904647385918784,-56.41856250772495 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark06(-0.28700609317211334,-1.5707963267948943,-58.759940596775785 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark06(-0.2872164389328995,-1.5707963267948966,-38.54320251366739 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark06(-0.2875182407957546,-1.5707963267948966,-0.02100497263281678 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark06(-0.28848253409820934,-31.724921079883813,71.03993233259092 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark06(-0.28922400093469536,-0.02592945474289854,0.0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark06(-0.28977052974312895,-1.5707963267948912,-15.500995616456663 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark06(-0.28986450365216493,-0.10947805089250101,-1.570796321919703 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark06(-0.29035843337725725,-1.5707963267948966,-1.570796326794897 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark06(-0.2909534541996237,-1.5707963267948966,-24.820593797343864 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark06(-0.29121194622956703,-1.5707963267948963,-2.0712320610366963 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark06(-0.2914918114405909,-0.2366649959794742,2.5707963157146043 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark06(-0.291573512201487,-0.3988214754245887,1.2624357259108467 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark06(-0.29164742084739603,-3.1415926535901617,1.5707963267948974 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark06(-0.29175072641815536,-1.5707963267948966,98.96016930055988 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark06(-0.2919795497613533,-1.5707963267948966,5.551115123124633E-17 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark06(-0.2938647434484629,-1.0407993866888887,-1.1232794757381055 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark06(-0.29437638667408694,-8.881784197001252E-16,-65.6169990885389 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark06(-0.2976154723241942,-1.5707963267948966,-81.68140899333463 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark06(-0.29763090833054207,-1.126550053213867,-3.1415926535897936 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark06(-0.29782206332300665,-1.5707963267948966,-57.344361292601604 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark06(-0.2982312799120147,-1.5707963267948966,3.141592653589793 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark06(-0.29910572173056094,-45.54318162577415,58.25758110733527 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark06(-0.29910803457180896,-1.5707963267948968,-53.951234575690684 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark06(-0.3009007923499404,0.0,0.0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark06(-0.30102121514363894,-1.4866154384993642,-73.60106761124811 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark06(-0.3016325636860367,-7.105427357601002E-15,79.84043104282476 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark06(-0.30200317379085806,-1.5707963267948966,-1.5710404674199019 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark06(-0.30314393964871766,-1.5707963267948966,47.112608316498296 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark06(-0.3031622312402362,-0.654120657506323,721.4100499692265 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark06(-0.3034644639709439,-37.699170905452185,27.362169223057478 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark06(-0.3037082120390693,-2620.7837975311036,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark06(-0.3038922472933666,0.0,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark06(-0.3041541664664371,-31.415926590443807,40.42025353388401 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark06(-0.30490466187068543,-1.5707963267948966,-33.8304865643822 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark06(-0.30546481096966477,-1.3194073260113646,20.034888985599157 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark06(-0.3058489936243518,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark06(-0.30596405307423846,-1.1816778772668595,-34.66807297101957 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark06(-0.30658087138534407,-1.5707963267948966,-13.963736721441935 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark06(-0.30696925212251286,-1.548109604074439,50.990532545867836 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark06(-0.30759830992617526,-0.7162809073537916,1.2868893973670072E-85 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark06(-0.30808564928227966,-0.22017826477073288,-94.29551912714676 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark06(-0.30852670417421485,-37.733252442345574,-6.7123905107673085 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark06(-0.30921820129755384,0.0,0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark06(-0.31173920341390526,-1.5707963267948966,-65.06264497477622 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark06(-0.3117397468719625,-45.060312501139975,21.946023267425524 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark06(-0.3148546345742367,-31.488251625815295,13.516698705596749 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark06(-0.31519853350573074,-1.4526930277728338,-46.156749772141566 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark06(-0.3155476858633262,-1.5707963267948966,-57.929230970644696 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark06(-0.3167164331678329,-0.6053706987620013,-2371.5745205950734 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark06(-0.3169349432793882,-1.5707963267948966,-38.366020160287945 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark06(-0.31743250407896606,-1.5707963267948966,-46.20428514545319 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark06(-0.3174701538777924,-1.3733403552274694,1.570796326794898 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark06(-0.3177434479325103,-1.5707963267948966,-1.5707963267949694 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark06(-0.3180693647000292,-95.3331687189932,21.464594941153763 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark06(-0.3195629289581537,-1.5707963267948966,70.45071025831037 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark06(-0.3203056649391865,6.776263578034403E-21,9.667554708915318 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark06(-0.3205871581180064,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark06(-0.32135378796428754,-1.5707963267948966,-12.489292122123755 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark06(-0.3219676127831263,-1.5707963267948966,54.39604006554505 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark06(-0.32215272949432006,-1.5707963267948966,-71.06366291224515 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark06(-0.32270304694575525,-32.91702261910652,20.9484977103193 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark06(-0.32287985647903383,-1.517774113470247,18.907172795677837 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark06(-0.32367549372393023,-39.11215056067935,44.395195960474844 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark06(-0.32408360004672454,-1.5707963267948966,-66.08229281945498 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark06(-0.32664575658210365,-1.5707963267948966,-11.707583514604394 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark06(-0.3276951324604192,-1.5707963267948966,76.02719375488901 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark06(-0.33089257203506095,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark06(-0.330955096976229,-0.030763480995241066,34.8823503587477 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark06(-0.3317059386897796,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark06(-0.33317269743570804,-0.17571455103115297,-1.5707963267948966 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark06(-0.3337129722134023,-1.441739043492615,31.814799106063735 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark06(-0.3343808428669015,-1.5084986807888414,97.3342430926581 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark06(-0.33438174741849114,-1.5527002602710414,88.20700908438722 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark06(-0.3347306026954881,-1.2487027530951087,31.37142430623652 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark06(-0.3347900218943102,-1.570796326794897,-1.5707963267948966 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark06(-0.33509478366504686,-0.19081855777751616,61.609339588561426 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark06(-0.33578818424747375,-1.2688370315847461,-40.840704496667314 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark06(-0.3362646953354491,-1.5707963267948912,-9.42477806090156 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark06(-0.3365617862496435,-3.1415926535920473,1.5707963267948966 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark06(-0.336670567331236,-0.7025692058075829,-70.04762063558486 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark06(-0.3371589594877179,-6.497131103528062E-114,0.0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark06(-0.3378378303281435,-1.5707963267948966,47.07402518177667 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark06(-0.3384307623123189,-0.07463820015734424,-77.89531697743243 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark06(-0.3389634035819342,2.465190328815662E-32,-63.66886591741525 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark06(-0.3392323083741542,-1.5277932339310363,0.0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark06(-0.3394257085531219,-1.5707963267948966,-96.50679035553644 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark06(-0.339660853405529,-1.5707963267948966,-6.712389181173794 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark06(-0.34001614868828267,-1.0689065249395104,-568.5426011954185 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark06(-0.34008921192931024,-1.570796326794897,62.01297715703156 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark06(-0.3403868125477749,-1.5707963267948961,-13.893540662468354 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark06(-0.34177711353262435,-1.3552527156068805E-20,28.528594073945044 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark06(-0.3419124242616478,-0.9108220155296696,-35.41521098464278 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark06(-0.3423985566451939,-44.06870065367819,83.18386867464736 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark06(-0.34302739489502554,-1.5707963267948957,-0.7092505168839294 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark06(-0.3433755306753571,0.0,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark06(-0.34419526369954134,-1.5707963267948966,73.49328949992139 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark06(-0.34473242350965094,-1.514082668231155,0.0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark06(-0.345188889505221,0.0,0.0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark06(-0.3460604419225659,-0.7944568278560006,-0.2901354899084297 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark06(-0.34788210223998733,-1.5238343415741349,-624.932941572683 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark06(-0.3483752448417177,-3.1415926535977596,-1.5707963267948974 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark06(-0.34854191528683875,-0.5602350878829322,292.06851532643407 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark06(-0.34863308015902594,-39.160121593262865,52.41075288877233 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark06(-0.3495384332129964,-0.030391983382595453,4.969685821347806 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark06(-0.3501481618776501,-1.3578732819158699,-24.247259860106766 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark06(-0.3507244911827029,-1.5707963267948966,-21.85208419663213 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark06(-0.35213821459021805,-1.5707963267948966,-12.56149498322594 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark06(-0.35253623068179607,-0.006540111275711524,14.735392120442285 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark06(-0.3531794470316809,-1.5707963267948963,86.71965023021166 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark06(-0.35433558313524655,-1.5455331333491376,-2.0708432922864835 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark06(-0.3543722173244709,-1.5707963267948963,-43.444240743296746 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark06(-0.3550581108057429,-0.10830072947212538,91.88263345254319 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark06(-0.35575870974830703,-0.23984637348776472,431.39742281842183 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark06(-0.35583968633254964,-1.4538612965033764,15.20725822785046 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark06(-0.35584953288743104,-1.3932754959523108,31.628860334354222 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark06(-0.3562162285489001,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark06(-0.35640804077512317,-1.5024277350059831,73.89137526710775 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark06(-0.35754863388750563,-39.02852788135796,8.42736181083079 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark06(-0.35813263616557606,-1.5707963267948966,-58.6433374755923 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark06(-0.35955336803388177,-1.444467691960121,-11.485217225846252 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark06(-0.3608596136137825,-1.081105911784769,73.51864168243242 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark06(-0.36164418125801423,6.712388980395151,1.5707963267948983 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark06(-0.36339184497372456,-1.5707963267948966,64.9182973467709 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark06(-0.36472211797546783,-0.21042447786115498,54.11301386745321 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark06(-0.36561401092655754,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark06(-0.36625081404970067,-44.53871380084883,19.34957092336532 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark06(-0.36926246288437015,-1.5707963267948966,90.04191361391673 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark06(-0.3696084882963096,-37.71007108115437,44.32753124150364 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark06(-0.37136454689640713,-32.730289618086545,1.5717728965832698 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark06(-0.3713963552847656,-0.5649568430371686,34.175229599172454 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark06(-0.3718115236713644,-1.0157623244250475,-234.29864714449374 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark06(-0.3733950131816077,-1.5707963267948966,-58.27098624226532 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark06(-0.37399418228229386,-19.356773934587906,2.2496395601236827 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark06(-0.37415713034199616,-100.9385761611442,45.15429140398793 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark06(-0.3751258775625624,-1.5707963267948963,4.712396949876374 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark06(-0.375253808569502,-1.5193944582078722,59.69026107774014 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark06(-0.37727748609083717,-1.5707963267948966,-47.12350913855741 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark06(-0.3778575055100963,-1.529203680753605,3.140195239009344 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark06(-0.3781118262407608,-8.772998317731405E-15,-38.73541235102625 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark06(-0.3781473303389272,-2576.733960703842,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark06(-0.37912123423658467,-1.5707963267948966,41.839206546026894 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark06(-0.3794821462404807,-1.3000401315685053,-77.42381796754951 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark06(-0.3795974044665029,-1.5707963267948966,96.5775954450437 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark06(-0.38003016629461617,-1.5707963267948966,-93.11465436191686 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark06(-0.38012307325369077,-0.8071546853442428,-28.27433419774951 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark06(-0.3805704371191812,-0.5094812365198604,33.59780413379604 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark06(-0.3825714004837729,0,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark06(-0.38286142831630543,-1.5707963267948912,-1.5707963267948966 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark06(-0.38325540307603245,-1.5707963267915568,73.44336993209699 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark06(-0.3835560440493552,-1.5707963267948966,-24.068937648127168 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark06(-0.3849503095025928,-1.5707963267948966,-46.50217079849925 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark06(-0.38501781163058757,-4.440892098500626E-16,73.99334189044541 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark06(-0.3854063065748279,-0.9444629922940813,-74.84730088044202 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark06(-0.3856753256044043,-1.5707963267948983,-25.238117364291195 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark06(-0.38601204413295503,-1.1842811743959034E-16,36.569896132481524 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark06(-0.3861321833539271,-1.5707963267948966,41.35261812195105 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark06(-0.3863429872478567,-32.935744759750484,19.37333028019541 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark06(-0.38715939513064224,-1.232595164407831E-32,-7.567050271716269 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark06(-0.3874033834707302,-1.5707963267948912,57.25536492162789 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark06(-0.38911704822366494,-0.9305133042054007,10.935021764729427 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark06(-0.3912220307371178,0.0,0.0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark06(-0.3917599840365664,-0.7161669521533459,-600.8152959016811 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark06(-0.39271882105420786,-1.5707963267948966,-1.4797467535281128 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark06(-0.39302044194536767,-1.5707963267948966,3.1418381906225674 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark06(-0.39305690870219134,-1.2814285339171017,-1.542773599409489 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark06(-0.39326142239303086,-4.5744266997771454E-4,58.0668856948094 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark06(-0.39353632843413466,-1.5707963267948963,1.5707963267948966 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark06(-0.3949005118258075,-1.3606762402880008,69.50808503226759 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark06(-0.39550610708590694,-0.42928886877048456,-31.925960544928984 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark06(-0.3973656944108077,-1.5707963267948966,8.234944072437722 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark06(-0.3975903128875598,-0.703549927519283,16.792308044180942 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark06(-0.3979410607920215,-1.5707963267948966,0.8504641884204474 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark06(-0.39804806174466734,-0.12960858861714186,-6.185488360690428 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark06(-0.3983465264350308,-1.5707963267948966,67.0216135065202 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark06(-0.3984279572395042,-1.5707963267948966,34.58863607638409 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark06(-0.39871717054150047,-1.5707963267948912,-124.24976665531545 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark06(-0.3993820583234635,-1.5707963267948966,52.448463828319376 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark06(-0.3995954350380475,-4.004166190366202E-146,26.254623092705334 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark06(-0.40094846742849327,-0.48191138556734625,-12.516289465081385 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark06(-0.40277161565624686,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark06(-0.40381024248209696,-1.0835847725288985,-1157.1671480662148 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark06(-0.40391313829584563,6.938893903907228E-18,53.94254657953459 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark06(-0.40589094275082005,-1447.302447860226,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark06(-0.4068313341689074,-1.5707963267948841,11.456766629583782 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark06(-0.40683883329491266,-44.91602993686594,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark06(-0.4068782637076893,-1.203079238702752,29.260972744459025 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark06(-0.4069287873245594,-0.8456071978524661,2334.5813518534874 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark06(-0.40726596602603676,-0.3396894268637696,-15.213475348269156 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark06(-0.4091953267749369,-1.5707963267948966,32.10850739639846 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark06(-0.4098597885559767,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark06(-0.41124232709254027,-37.69911184307752,34.28061877246084 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark06(-0.41135277240857765,-1.5707963267948966,25.15305622948989 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark06(-0.4117903019442717,-1.5707963267948966,-40.22291562962066 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark06(-0.4121721631985622,-0.5734933169658785,-10.626314856133035 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark06(-0.41228550563472083,-1.5707963267948966,-66.11769782436635 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark06(-0.4126874547906752,-1.5707963267948966,-4.7365909010138125 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark06(-0.4130363706534679,-1.5707963267948966,22.231857382039053 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark06(-0.4140759193527499,-1.5707963267948966,172.62036148183444 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark06(-0.4143640190763711,-1.5707963267948966,47.37843614760209 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark06(-0.41443945109545216,-1.5707963267948966,-57.8903776293012 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark06(-0.4144538995666677,-0.08267239769399917,97.29139773330058 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark06(-0.4149532404865023,-0.8681443821348108,-1.5707963267948966 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark06(-0.4152242107345909,-1.5707963267948966,-28.44730918441701 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark06(-0.41681710960868923,-0.20394543292205308,-72.81903198201076 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark06(-0.4171619637946568,-1.5707963267948966,1.570796326794896 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark06(-0.4175341352362931,-1.5707963267948966,-1.5864213267948977 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark06(-0.4179159827657426,-1.1102230246251565E-16,-1.5532616203746292 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark06(-0.4182659026260972,-1.5707963267948983,-91.41975947544232 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark06(-0.41896386708940175,-32.488730124498275,95.5260022409006 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark06(-0.4192408278904534,-1.5707963267948966,-53.952704703628164 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark06(-0.4198766324026679,-1.5707963267948966,2.0501330894674953E-143 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark06(-0.4200956952582615,-0.40344761507928084,-1.5707963267948966 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark06(-0.4214614004569257,-1.5707963267948966,1.5707961829177983 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark06(-0.421658022609043,-3.141592718451296,-168.07145187344642 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark06(-0.4221887926381301,-1.5707963267948966,78.04709419932078 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark06(-0.42220204283165863,-1.4911780768368992,0.010073930270429595 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark06(-0.42226636160018893,-2.220446049250313E-16,-1.5305922883177152 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark06(-0.42262250410215474,-1.5707963267948966,37.08288643183396 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark06(-0.4227802790342212,-0.154847676604156,-99.56599334785034 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark06(-0.4229069020960792,-1.5707963267948948,-2293.729389966224 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark06(-0.4244540992566493,-1.5707963267948966,-72.46487318213319 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark06(-0.42447224925576155,-0.9485308830302983,95.89535274695109 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark06(-0.42554553756747415,-31.97574086289769,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark06(-0.4279440942681565,-1.154122327223217E-128,14.275240459117732 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark06(-0.4283876649677208,-1.5707963267948966,-58.537121139747974 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark06(-0.42908851923666336,-1.5707963267948966,-69.72401319018695 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark06(-0.4311090505501787,-1.341873648702104,-0.6059158170915276 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark06(-0.4321403469854639,-1.5707963267948983,2353.8769687566414 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark06(-0.4326811714868093,-1.1069811162720753,1.5707963267948948 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark06(-0.4360740452884488,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark06(-0.4362588611004625,-1.5707963267948912,-12.391706113948842 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark06(-0.43661939355698354,2.465190328815662E-32,-2.5139959809924735 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark06(-0.4375358297409988,-45.396864278524134,164.48780954414133 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark06(-0.43769891411970996,0.0,0.0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark06(-0.43840191157971775,-0.2817364154612676,1.5707963267948966 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark06(-0.4397648788058476,0.0,-81.51743514237276 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark06(-0.4404679926243773,-1.5707963267948966,3.1415926497049558 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark06(-0.4405410693558043,-27.94837140222691,70.96727125012436 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark06(-0.4416482715069522,-0.5414101011065435,-1.6332963267949245 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark06(-0.4429412435719273,-32.68892203277948,58.91395283035067 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark06(-0.4430674754999591,-32.62249503424593,53.20603411741278 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark06(-0.4434483508232847,-1.5707963267948948,91.59686875978429 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark06(-0.4447444190068527,-95.45126394240519,12.56637316267579 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark06(-0.44522187376973427,2.220446049250313E-16,3.1497527265733343 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark06(-0.4453684172187451,-1.5707963267948966,-56.96632366264092 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark06(-0.44623387879546417,-208.98849333683842,1.635990680080992 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark06(-0.4465342146616175,-88.24603051670475,69.69541880633739 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark06(-0.4466528304145319,-1.5707963267948966,44.52901620062948 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark06(-0.4469228822922634,-1.5707963267948966,31.792226163220036 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark06(-0.44774540495228665,-0.921533480649207,15.227957993283324 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark06(-0.4491011644800611,-1.5707963267948966,0.2715383446264741 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark06(-0.4496753905968451,-1.1490918663538687,-13.408751089559676 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark06(-0.4503015783813791,-88.51077042360994,12.72234408149088 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark06(-0.4506183049818349,-0.2230419761480827,-1.5707963267948968 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark06(-0.4509280257492451,-1.5707963267948903,-76.06821563160531 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark06(-0.45132130021197536,-1.5617712113746034,63.727034544777496 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark06(-0.45186561690870536,-38.766017738762926,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark06(-0.453009740899963,2.0194839173657902E-28,-72.35857029809479 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark06(-0.4551300217740598,-0.03830481954513232,-42.10686711913621 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark06(-0.45702056971174265,-0.7954394801785589,1.5707963267948966 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark06(-0.4585038749944906,-1.5707963267948966,-9.514377781524791 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark06(-0.46076078757742744,0.0,33.31396581357599 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark06(-0.4612294698802195,-1.5707963267948966,1.570796326794658 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark06(-0.4627413232229485,-0.25393487439475315,59.14734166601886 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark06(-0.46287577702246485,-0.15804922628114754,3.141592653791026 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark06(-0.46334532706659093,-3.141592654190838,75.5142077102225 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark06(-0.4634322248373337,-1.5707963267948966,-3.141592653589795 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark06(-0.463466901316414,0.0,4.469678692273307E-20 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark06(-0.46399680546474353,-1.5707963267948966,-55.90306591475806 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark06(-0.4640964950187776,-0.8552916505653947,1.5707963267948948 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark06(-0.4649960433406477,8.673617379884035E-19,73.76495409628961 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark06(-0.46519034359336553,4.3368086899420177E-19,-8.523621584164495 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark06(-0.46525795405299064,-101.09426098503938,19.845311683577897 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark06(-0.46713390672100225,-43.99655007314291,5.551115123125783E-17 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark06(-0.4681058496316036,-1.5707963267948966,72.57405619139995 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark06(-0.46816841194073366,-1.5707963267948966,-5.779597445736769 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark06(-0.468682880219909,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark06(-0.4688257641404552,-1.5707963267948966,-34.205766993436946 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark06(-0.4699166405321449,-0.062157432654970916,10.201309652081662 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark06(-0.4705325239763485,-1.5707963267948963,0.004795663874239631 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark06(-0.4708985541851689,-44.34238560257526,77.92253387926479 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark06(-0.471531309065105,-1.5605636664295137,3.344733318847208 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark06(-0.47199212713335503,-100.79280562907252,40.709495236822605 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark06(-0.47215000304913035,-1.5707963267948966,-4.079428111606866 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark06(-0.4723835240186318,-1.1217545505308635,61.88410839913831 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark06(-0.4726204540243518,-1.570796326794896,45.55309332828298 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark06(-0.4727456470490652,-1.5707963267948966,10.01376138553759 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark06(-0.47390951568860445,-1.5707937760645438,99.71758769190146 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark06(-0.47457867832135026,-2.220446049250313E-16,1.5707943584470503 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark06(-0.47632117354812564,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark06(-0.476380434765351,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark06(-0.47682950184601025,-88.52765700763021,68.69104710614103 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark06(-0.47920851366213757,-1.0855490395580745,34.46780089129831 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark06(-0.48072439343680884,-1.0863911777103241,82.6427062454778 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark06(-0.4826931049632226,-1.5707963267948966,-0.8925114439940318 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark06(-0.4829589211554458,0.0,-2188.442117655384 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark06(-0.48354295811392767,-1.570796326765475,-110.54702960915685 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark06(-0.4836084850161599,-1.5707891668775222,3.2665934975862196 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark06(-0.4852788588142145,-1.5707963267948948,1.5707963267950111 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark06(-0.4858286486819393,-1.5707963267948974,724.1363662805744 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark06(-0.48764920468055406,0.2679949307712811,-1.5707963267948966 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark06(-0.4880549345432712,-0.8760940347850086,-100.0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark06(-0.48828129140482934,-0.9209782829681726,-47.55123125340895 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark06(-0.48854427872592077,0.0,0.0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark06(-0.48933532382829054,-1.5707963267948966,-70.28100975393298 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark06(-0.48945684384868926,-1.5702371568886226,73.84096030446955 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark06(-0.4915172887784019,-94.31780748087293,-6.712389834819649 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark06(-0.4928017118801919,-0.13243011147251083,0.0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark06(-0.49384253179812354,-1.0702194086955093E-196,-68.94670389377387 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark06(-0.495251884038328,-101.9247935101339,95.36410566742754 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark06(-0.49576576719050713,-1.5707963267948966,-10.124743334207281 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark06(-0.4961789143925138,-1.7534474792067224E-192,0.0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark06(-0.4965942375983099,-1.0297458258496641,44.38749581835282 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark06(-0.497215291479137,-1.5707963267948966,67.89578916644629 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark06(-0.4985011943417667,-8.470329472543003E-22,26.146338780532126 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark06(-0.49884362207671196,0.0,0.0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark06(-0.49946674616949727,-39.09104662281765,37.95258891139072 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark06(-0.4999069068000142,-1.5707963267948963,44.51951099398647 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark06(-0.5000773092750208,-0.010079476038567375,27.949778716896088 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark06(-0.5007350569442387,-0.005580011105115273,-1.5707963267948948 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark06(-0.5018481866173179,-1.5707963267948983,909.2941831259217 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark06(-0.5018588882064681,-1.5707963267948966,-37.480011299999944 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark06(-0.502225876549897,-32.78724743932612,15.607749357543867 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark06(-0.503647148523946,-1.5707963267948966,-73.59640930613426 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark06(-0.5038705141527239,-1.5707963267948877,63.809668752795226 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark06(-0.5042979905741873,-1.5707963267948974,-181.46161606914012 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark06(-0.5055801200582695,-1.5707963267948966,-66.09322593771759 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark06(-0.5075192952878628,-3.141592653837913,-66.05296094870928 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark06(-0.5080130834011527,-1.0085907811855173,53.9655276867605 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark06(-0.5096940139589814,-44.15706094908114,26.195967792482648 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark06(-0.5102772185183173,-1.4141165287709383,30.328484510662395 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark06(-0.5114684927993378,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark06(-0.5122509195821309,0.0,0.0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark06(-0.5130387472946274,-1.5707963267948966,-68.48596063516959 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark06(-0.5146366810197314,-1.5707963267948968,-1.0361170979783447 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark06(-0.5154217944888004,-1.5707963267948966,55.52183439112562 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark06(-0.5158011769757048,-1.5707963267948966,38.65483490686873 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark06(-0.5183038186795063,-0.3002205968546008,1.5717787535730159 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark06(-0.5190275793415267,-1.5707963267948966,16.504399914746532 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark06(-0.5194788275852438,-1.5707963267948966,-54.10908428268321 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark06(-0.5197274081407559,-1.5423965063248253,-50.729337267950946 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark06(-0.5231336836940413,-1.3899632828560475,0.26149456038068275 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark06(-0.5248755092278199,-1.5707963267948966,9.01988046865312 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark06(-0.5258008727265615,-0.2566769052434692,0.006450310915649403 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark06(-0.5266294737573629,-32.47892582377318,2.254253032019264 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark06(-0.5275367899484209,-1.5707963267948966,-115.72466216153606 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark06(-0.5288706911314497,-4.304746851614709E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark06(-0.529357875952698,-0.6636626995730693,32.35906710876084 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark06(-0.5294581665001683,-45.31189712754919,84.4911398459234 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark06(-0.5299058700976188,0.007739725070419485,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark06(-0.5301474246764646,-1.5707963267948966,26.9788345882161 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark06(-0.532370607855985,1.9467177638862437E-208,0.0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark06(-0.5323764752626305,-0.8375979077765656,105.00587299879288 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark06(-0.532464876937244,-1.5707963267948966,4.2168791772922093E-81 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark06(-0.5326429799792403,-1.5707963267948966,-78.3845677944557 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark06(-0.5335508619483669,-1.5707963267948966,16.548476556735213 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark06(-0.5346011385837064,-1.5707963267948963,-502.6548148912771 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark06(-0.5347129355233781,-1.5707963267948966,20.941600565265 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark06(-0.5352042769002069,-1.5707963267948966,-165.62144971095938 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark06(-0.5370636120727401,-0.37711416931351494,19.233425654461424 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark06(-0.5384235881651529,-45.397900585030925,59.06315985063931 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark06(-0.5394001241660993,-1.5707963267948966,1.5707963267948957 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark06(0.539830268969775,91.37204100410868,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark06(-0.5400840793424957,-1.5707963267948966,-70.65824520728056 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark06(-0.5417449523267255,-1.5707963267948966,-76.88520436385029 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark06(-0.541782015340615,-1.5707963267948966,-253.6594859497046 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark06(-0.5420070394736861,28.88284997339615,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark06(-0.5427734084212039,-1.5707963267948966,-8.112383819946483 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark06(-0.5428655865063455,-0.8087113273925817,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark06(-0.543130031687735,-1.5707963267948957,-3.14159265358987 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark06(-0.5439858795914287,-1.5707963267948966,-93.63895635102375 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark06(-0.544133521951581,-1.5707963267948966,73.35061645550523 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark06(-0.5445890350457272,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark06(-0.5463022704151481,-0.12222154064397936,14.638813998563439 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark06(-0.5485957845098497,-1.109876183859392,0.0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark06(-0.5489823637838709,-1.5707963267948966,5.551115123125783E-17 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark06(-0.5502064997598854,-1.0183883586646945,71.16208411754718 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark06(-0.5527272564628434,-1.5707963267948966,-86.34401427858367 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark06(-0.553890301200231,-0.9235671976405484,28.02821394093214 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark06(-0.5556012009113265,-1.5707963267948974,0.0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark06(-0.555889777932015,-2.646532354661522E-17,8.677417715524222E-17 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark06(-0.556132483223879,-0.7579383225118368,-1.5245256230075 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark06(-0.5565093949213367,-0.17188809487221202,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark06(-0.5579030159966991,-45.02963453459324,40.10518944406276 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark06(-0.5583701635538052,-1.199445746563141,0.0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark06(-0.5584368895044659,-1.5707963267948966,0.29640667579276236 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark06(-0.5587692440887662,6.7123889804628485,7.371440845384476 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark06(-0.5597398318630333,-0.9384884895692096,-68.86416986025057 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark06(-0.5613047692170454,-1.2008360275172254,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark06(-0.5615110932557665,-3.141592656586269,-0.03900650690528629 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark06(-0.5618734297316088,-100.93451823563231,65.96499664720422 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark06(-0.5619470886606994,-32.73875599272493,70.73089234316609 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark06(-0.5646229239721335,0.0,0.0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark06(-0.5653755072566959,-88.35870927756693,0.0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark06(-0.5684718412916343,-1.5707963267948912,46.06951045357131 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark06(-0.5686521238493283,-3.1415926536181877,186.44405035158024 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark06(-0.5694404010569527,-0.1011082573568993,0.0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark06(-0.5716215732633126,-19.407020954017035,1.1704190886730496E-97 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark06(-0.5716391986233924,-1.5660024247401028,58.77920931503227 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark06(-0.5718119115615238,-1.5707963267948912,78.55544140636785 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark06(-0.5726875233476009,-1.3085098170887062,-53.75626712566126 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark06(-0.5746438171072015,-39.04751434067287,70.81995242972097 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark06(-0.575724670349234,-32.58984156553339,-6.712388983400631 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark06(-0.576380918796984,-1.5707963267948948,-30.862757356339316 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark06(-0.5766680935036645,-0.026849090961678083,-4.485764477558092 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark06(-0.5774233236064192,-1.5707963267948966,2.0707963475462607 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark06(-0.578116629503417,-0.9700749991414668,79.02102537543442 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark06(-0.5790187683498209,-1.5707963267948983,608.4094031276127 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark06(-0.5805823526561833,-1.5707963267948966,-52.30141826429251 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark06(-0.5805842203666032,-1.3270625287619273,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark06(-0.5808154104174719,-1.5707963267948966,35.32350876336833 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark06(-0.581694859214165,-1.5707963267948948,-77.56927161357284 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark06(-0.5824614099062728,-1.273129360640822,64.84898543149924 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark06(-0.5829674630449866,-3.848311572986183E-16,1.8033161362862765E-130 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark06(-0.5829875469961315,-44.16660396329894,1.5707963267200207 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark06(-0.5832769072482715,2.1175823681357508E-22,-1.0749937503052327 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark06(-0.5838702317785572,-0.10036947183428424,77.98315672757815 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark06(-0.5848365046986879,-1.5707963267948966,-4.004166190366202E-146 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark06(-0.5849842174167209,-1.5707963267948966,43.89833476106353 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark06(-0.5875742532788883,-1.5707963267948966,-24.04650904934691 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark06(-0.5880181578814501,-88.40451970584265,58.734509780746095 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark06(-0.5888415314763584,-1.5707963267948966,210.96251642471663 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark06(-0.5893975061700557,-1.5707963267948966,1.5661770405305369 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark06(-0.5899710622018661,-1.3631132355302809,0.0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark06(-0.590475691974492,-88.22483803679535,128.34378411581397 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark06(-0.5916388755229073,6.938893903907228E-18,-91.24835258502877 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark06(-0.5920469410698508,-1.2726100839739347,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark06(-0.5925876451606618,-1.5707963267948912,100.0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark06(-0.5927513635432725,-0.04559259721320963,95.96453382163457 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark06(-0.5939250415485311,-0.7296951745904997,21.301703759850806 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark06(-0.5943919594269214,-1.5707963267948966,-10.995577236868183 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark06(-0.5961406513112271,-83.4552557724329,1.5707963267948948 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark06(-0.5962535345290404,-164.9238812613128,9.027996509276363 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark06(-0.5962723253234712,-0.7442403437505392,21.517242548568962 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark06(-0.5963049825990187,6.7123889803846986,44.06642383955911 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark06(-0.5963885511632802,-3.1415926535898877,1.5707963267948966 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark06(-0.596461072785771,-44.47625141527694,31.666886998012046 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark06(-0.5975261762080639,-0.641328329937195,-1.5707963267948966 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark06(-0.5975443743617799,-1.556769704446439,0.0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark06(-0.5981868966119306,-0.8519380953797127,72.12658344492095 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark06(-0.5998736300744709,-38.94157505090155,-1.3896979988263116E-5 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark06(-0.6008943553089032,-0.9735001812183879,1.5707963267948966 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark06(-0.6011017268943135,-1.5707963267948966,13.059751478013254 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark06(-0.6016603756878993,-1.2312578712406856,-53.81497823657417 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark06(-0.6017896767221345,-0.6639392270012985,17.410954378714024 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark06(-0.6022484581741092,-1.570796326542473,-36.830724758430804 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark06(-0.6025635852383129,-100.9367400631355,1.5864213295339775 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark06(-0.6028697217815351,-1.5707963267948966,-45.89366778567997 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark06(-0.6041096236547094,1.734723475976807E-18,1.5707963267949125 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark06(-0.6042573448986772,-0.8512279710122446,834.3413858455048 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark06(-0.6046016790310915,-1.5707963267948963,-1.5707963267948966 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark06(-0.6051122760900358,-31.415926535905694,0.2979076238675643 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark06(-0.6051186511080607,-0.32061326010466473,-1.5707963267948966 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark06(-0.6074745815106297,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark06(-0.607584843094477,-1.5707963267948948,87.76552227267152 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark06(-0.608616963802646,-38.758199810784625,178.33999252750903 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark06(-0.6114787232251117,-1.5707963267948966,-86.2248405050355 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark06(-0.6121053300731102,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark06(-0.6135738411642482,-163.47207973386904,0.0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark06(-0.6149908092790756,-0.930183511067155,-71.73965837950735 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark06(-0.6154208310403496,-1.570796326794895,1.5707963267948966 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark06(-0.6169112685036201,-0.8471818396162064,54.519073336330734 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark06(-0.6173494031630287,-1.5707963267948948,1.5707963267948966 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark06(-0.6178443363060682,-1.5707963267948966,-81.36021714918783 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark06(-0.6178715236765143,-95.40049732167937,0.0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark06(-0.6184961529291003,-1.5337696054867656,65.43876113708752 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark06(-0.6191431108701366,-0.794206258913019,39.04728206408202 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark06(-0.6203008470525551,-1.5707963263501763,-64.96832771225914 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark06(-0.6203820399573234,-1.5707963267453582,31.033006118466286 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark06(-0.6206448559570461,-7.105427357601002E-15,-46.54208259076589 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark06(-0.6212885635133935,-1.5707963267948966,3.2665926752166308 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark06(-0.6239712271609582,-1.5707963267948966,52.11122666363451 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark06(-0.6260324537370296,-1.5707963267948966,-64.55521731219454 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark06(-0.6270212588672737,-1.5707963267948966,78.09533709531306 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark06(-0.6277232326267113,-1.5611572428155736,46.962295361382296 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark06(-0.6279179852584046,-1.5707963267948966,24.565321168826614 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark06(-0.6282444193304002,-88.32725192071976,51.56059288328072 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark06(-0.6289509613241966,-45.29986373736402,2.308244654446434E-128 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark06(0.630119788484923,0.0,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark06(-0.6304145989241128,-1.5707963267948983,-65.20919070816448 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark06(-0.6309527581250245,-38.738955459829796,53.38535647599133 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark06(-0.6310181876347976,-0.13868994055099104,-90.67333355152162 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark06(-0.631160614082973,-37.86869573141741,0.0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark06(-0.6316784754350268,-39.26383348449936,1.5707963267948912 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark06(-0.6322958912223116,-1.5707963267948966,62.27072873168231 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark06(-0.6332551094622944,-1.320253805939624,-83.6771366448903 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark06(-0.6343631600757443,-0.012031578188304567,2.5751543179837952 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark06(-0.6360801016021028,-0.9583899864193625,-54.435398967035354 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark06(-0.6361331153838131,-1.4798661353953393,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark06(-0.6367740701795709,-0.04572809157527047,-72.85824113808263 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark06(-0.6368158252213965,-45.408237675995785,1.1891096240534667 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark06(-0.6377678257997426,-1.5707963267948966,-1.2419895110202788 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark06(-0.6381213166915862,-3.1415926535905085,47.49243389055975 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark06(-0.6381599987886539,-32.82063582125404,39.152242094656 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark06(-0.6385307079193497,-1.4942146352143668,-45.526870606350094 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark06(-0.6391816919965412,-1.5707963267948966,4.50859857850236 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark06(-0.6400108844538376,-1.5707963267948966,9.816690385840872 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark06(-0.6404375641972182,-1.5707963267948912,-48.009612425091454 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark06(-0.641114652514434,-0.5926799155769439,376.8769985494508 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark06(-0.6414082152260789,-31.41592653589793,77.4888569375584 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark06(-0.6415615391199092,-0.975885079309111,146.09373438556295 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark06(-0.6419045725581469,-1.5707963267948912,52.741486137825206 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark06(-0.6426151300744891,-95.31554059813357,32.359237488320275 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark06(-0.6432162620282895,-1.4362235748772854E-10,85.73288331455237 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark06(-0.6449981273180702,-1.5707963267948966,-54.81310096428375 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark06(-0.6467037908075169,-1.1736218442256334,136.65723671241773 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark06(-0.6481214728186075,-1.5707963267948966,-23.700738407656402 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark06(-0.6484001810262113,-44.487035529732154,6.938893903907228E-18 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark06(-0.648825314559741,-0.9962076634505151,0.0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark06(-0.6507825814989237,-1.5707963267948966,-1005.2402983572331 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark06(-0.6515285394447072,-0.2545698659260669,5.256511744283927E-16 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark06(-0.6516433338588878,-0.4776257417868685,-0.07303627253280831 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark06(-0.6518233138889419,6.712388980384977,2.6191608424799364 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark06(-0.652311760869229,-1.5707963267948948,22.9412741845668 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark06(-0.6527625634617975,2.465190328815662E-32,6.261874330012503 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark06(-0.6531297445486501,-158.1913659037921,151.07377542717748 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark06(-0.6532896177959409,-0.11679184328583216,-3.1851172884458823 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark06(-0.6564062222595134,-88.1847709687161,69.32741535413321 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark06(-0.6566850145209926,-1.5707963267948966,-94.64156972322219 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark06(-0.6593727630043071,-45.511067873415016,1.5707963267948966 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark06(-0.6598015085274549,-1.5308362456234417,-3.2666145654051433 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark06(-0.6612076635001792,-100.60184389240086,1.5707963267948957 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark06(-0.6614236396206867,-2.8853058180580424E-129,-74.84920309117632 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark06(-0.6618487344640166,-1.5707963267948961,-2.7701961003434565 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark06(-0.662386463674622,-59.930519797254256,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark06(-0.6634483282449373,-1.5181744946613804,-65.57075041584392 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark06(-0.6634898583110511,-1.5707963267948966,3.245461258186136 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark06(-0.6640855834865137,-1.5707963267948961,1.5707962544791776 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark06(-0.6651691113246444,-1.5222811891738874,-4.714342644367135 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark06(-0.6673479463079712,-1.5707963267948966,36.97875293963543 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark06(-0.6693992287264088,-1.098860991450855,-0.052018017824676396 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark06(-0.6717216737227827,-1.5707963267948966,-45.38343621143557 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark06(-0.6719461920043299,-1.5707963267948966,72.65136721836318 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark06(-0.6723236866965255,-0.10036333613971095,59.69026041820607 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark06(-0.672667476447484,1.734723475976807E-18,31.074842960728404 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark06(-0.6736674852168048,-100.65072584780764,90.49479967963984 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark06(-0.6748762620389739,-1.5707963267948966,76.77129761787337 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark06(-0.6771246955467379,-101.85225626091395,0.938936064262279 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark06(-0.678308393781685,-1.5707963267948966,-20.379900446001173 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark06(-0.6797329108797295,-1.5707963267948966,67.67237871175627 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark06(-0.6805639093465916,-1.5707963267948966,72.03326360011076 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark06(-0.6806997046235166,-1.5707963267948966,-1.3135342245004997 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark06(-0.6834090550124134,-1.5707963267948966,-77.95548360301935 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark06(-0.6853081026049707,-1.4380725858243681,3.141592653589793 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark06(-0.686124488984011,-44.116675992694205,20.80944266208884 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark06(-0.6874076540718446,-0.19588402842955205,51.07555990103995 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark06(-0.6874413711555583,-1.073969981258857,-67.36153061518144 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark06(-0.688745419572355,-1.5707963267948966,-99.82761360184796 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark06(-0.6892479699240259,-31.41604153761988,88.35424873162077 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark06(-0.6901764574799785,-1.5707963267948966,-23.9461887910467 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark06(-0.6937858448103152,-37.76235946144275,0.0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark06(-0.6953934779893569,-0.5707705727183626,95.75785282610109 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark06(-0.69570371919268,-1.5707963267948966,62.65645264073123 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark06(-0.69607255749929,-1.5707963267948966,-21.7726548896353 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark06(-0.6972893558445221,2.465190328815662E-32,25.109815189285037 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark06(-0.698072544674905,-3.1415926535898,-93.734768005626 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark06(-0.6992156437983468,-1.5707963267948966,-76.46328504080459 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark06(-0.7007144093308278,-0.15936419268126215,-100.0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark06(-0.7010240229139786,-1.5685188139829203,29.489124162845282 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark06(-0.7012192817382328,-45.4015311017711,32.23868573860028 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark06(-0.7026314372724443,-0.13820192138798582,1.5707963267948961 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark06(-0.7029981977392957,-95.27240588487678,83.98122331644267 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark06(-0.7032762194166247,-1.5707963267948966,-96.08826495820243 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark06(-0.7046700110316921,-1.5707963267948966,-0.7987179023191333 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark06(-0.7055964122160683,-1.5287397558636227,72.7516969618556 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark06(-0.7070332408452826,-0.7749869548966101,3.141592653589793 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark06(-0.7076332823775324,-0.01221185006862728,43.834317472687474 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark06(-0.707637638744412,2.465190328815662E-32,-43.247621751545594 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark06(-0.7085861248756449,3.3293405527405624,-0.014456989184580776 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark06(-0.7092563365095534,-0.38539482003681647,1.5707963267948974 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark06(-0.7100419527485009,-32.86973599463188,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark06(-0.7101166805961419,-1.5707963267948966,0.005156068889568737 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark06(-0.7104130098318469,-0.2741378743660715,32.9826182281372 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark06(-0.7105607939181766,-1.5707963267948966,55.48728602324305 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark06(-0.7111586720669416,-1.5707963265039258,-100.0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark06(-0.7117267057228691,-1.5707963267948966,-0.11854624100041693 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark06(-0.7130374636970878,-1.5707963267948966,-18.481951327112412 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark06(-0.7135438001652833,-1.4788065751053463,-3.2666018889088098 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark06(-0.7141311769400274,-0.8192797903701394,-2.9956254881199555 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark06(-0.7150549311560259,-1.5707963267948966,3.2220969778286195 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark06(-0.7166984931384391,-1.5707963267948963,-22.462143976106283 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark06(-0.7169163103886995,-0.6792096072575733,-48.49901662240106 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark06(-0.7195873739936901,-1.5707963265472573,0.0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark06(-0.7206336964411,-1.5707963267948966,-53.44169902819049 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark06(-0.7219269816472558,-1.5707963267948963,1.5707963267948966 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark06(-0.7223958321433642,-1.0795057948716191,-60.95652333700568 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark06(-0.7250559437565349,-1.2735257094370809,2.6806703853646274 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark06(-0.7266065625135437,-1.5707963267948966,0.938531248778736 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark06(-0.7269266860783397,-0.8486331095151329,-1011.2618515347726 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark06(-0.7270233314371453,-0.15002752588371693,-86.44644387052784 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark06(-0.7276126443358931,-1.1058945789721077,124.33815495605467 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark06(-0.7276133066306087,-88.28757472753297,-4.7126662491919635 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark06(-0.7286037652957281,-1.5707963267948983,530.4555399346373 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark06(-0.7290641680110643,-1.3053311418469762,-570.3403802612062 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark06(-0.7305884388400747,-32.64591064069111,1.5707963267948968 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark06(-0.7306810242508606,-1.1113317216297343,44.44014583546773 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark06(-0.7310802309478719,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark06(-0.7316948710418543,-1.5707963267948966,-658.5193796506585 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark06(-0.731820592070731,-1.5707963267948983,-65.91823297054903 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark06(-0.7327209073807436,-2.1829581240095458E-16,0.08838887676629302 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark06(-0.7332235756392218,-1.5679601515665942,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark06(-0.735621085200518,-1.5707963267948966,-10.627852776098521 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark06(-0.7364510682561671,-1.771919196712297E-6,56.27666661167186 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark06(-0.7365082951307136,-1.5707963267948966,42.39615806400844 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark06(-0.736999912113185,-3.141592653589882,-44.52268938750619 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark06(-0.7375933117250413,-1.5707963267948983,849.7317649744921 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark06(-0.7377290557199867,-1.5707963267948963,128.11167029281796 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark06(-0.7378011098376691,-88.28611557821019,88.15837226460134 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark06(-0.7398519119491009,-1.3262702293958455,-3.141592653589825 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark06(-0.7407215939814236,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark06(-0.7426948028568177,-1.009543842192672,53.80090861850511 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark06(-0.7450111861123406,-95.6391443492634,44.53685879820344 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark06(-0.7478532755346801,-1.5707963267948966,82.52630528777502 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark06(-0.7486448055090418,-1.5707963267948966,-163.63860623194097 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark06(-0.7494688649580471,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark06(-0.7500405548474589,-32.50182400922546,1.846289290443437 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark06(-0.7507266252296682,-1.5707963267948966,-8.519462827397511 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark06(-0.7507603816520073,-1.5707963267948966,164.9323716279571 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark06(-0.7525910012259674,-1.5707963267948966,3.141592658100145 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark06(-0.7550299136978451,-1.550811431150895,-75.42947376682768 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark06(-0.7551982966061853,-1.5707963267948966,419.941902783125 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark06(-0.757243819631741,-45.414428029466,44.060565582411705 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark06(-0.7575514228691207,-0.5723134431826871,25.87175034297774 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark06(-0.7606663441204047,-4.440892098500626E-16,6.3613373444375165 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark06(-0.7607384091842082,-1.5707963267948912,66.98597989651161 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark06(-0.7615791565910295,-1.5707963267948966,1.6332988962075965 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark06(-0.7615831325651256,-1.5707963267948966,-41.246068169630696 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark06(-0.7637236326594861,-88.4689741475803,31.64338662055357 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark06(-0.7641647937527773,-0.07515567512634291,56.53611074853029 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark06(-0.7661287160855181,-1.570796326794891,10.480742579267798 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark06(-0.7662999881219084,-1.5707963267948966,-43.28507105752815 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark06(-0.7672261062411146,-39.21023793577328,44.8550115524711 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark06(-0.7677172756993365,-0.38409510363984145,4.372099605152716 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark06(-0.7683033567756857,-44.39688919307373,40.765046530981465 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark06(-0.770009571280927,-0.5839230684758042,37.82643282446898 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark06(-0.7715186315825016,-0.6142565764297592,-71.40401503814113 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark06(-0.7721049567336224,-0.03944080752662609,6.415454720723343 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark06(-0.7726638579969642,-1.5707963267948966,60.76065496471466 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark06(-0.773407262155192,-3.6931914471142943E-127,5.032141188338414 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark06(-0.7758852589488295,-1.5707963267947846,-0.4604314466231431 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark06(-0.7759472820866815,-1.5707963267948961,-35.49580615106806 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark06(-0.7764807132902121,-164.79311897105086,140.57362812383485 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark06(-0.776632588681526,-1.5707963267948912,-41.098595785927316 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark06(-0.7771571998354241,8.68970510861476E-9,-146.5956731742486 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark06(-0.780763188924432,-0.9608246863546871,78.97272057826022 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark06(-0.7816734522576567,-1.5707963267948966,-41.79836605335022 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark06(-0.7822088050334861,-44.10003288470912,3.1415926535897967 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark06(-0.7831070600159634,1.3552527156068805E-20,0.0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark06(-0.7831101361123539,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark06(-0.785119591082284,-1.231657326821202,-66.89321673215662 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark06(-0.7859738256116386,-0.35315508580626265,-28.245284513443295 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark06(-0.7861213245448023,-3.552713678800501E-15,6.712501004675703 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark06(-0.7868807453893256,-1.5707963267948966,-5.653990390867477 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark06(-0.787616378636201,-94.2477796076938,1.5747028402168208 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark06(-0.7882994197064824,-1.570796321537944,-1.5264778935520633 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark06(-0.7890034924436703,-0.993643018709683,-101.62706581182269 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark06(-0.7901693330650643,-1.570796280512298,-1.5707963267948983 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark06(-0.7903033774751475,-1.5707963267948963,9.99635792825541 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark06(-0.7909343071400188,-1.734723475976807E-18,-67.51215140053311 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark06(-0.792222373153928,-0.6474009505019733,1.5707963267948966 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark06(-0.7925208693270007,-1.752439235133564E-4,-44.35084183131599 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark06(-0.7927017106647968,-1.5707963267948966,1.5775107483033608 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark06(-0.7928298161529981,-0.5600704485214871,93.57940950033576 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark06(-0.7939449049734617,-0.8388027655151182,119.3853793676107 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark06(-0.7941946530928317,-0.22500181741655484,11.810621251201907 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark06(-0.796562831148435,-1.5707963267948983,15.713842528224372 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark06(-0.7967543608759837,-1.5707963267948963,70.45415363058771 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark06(-0.7979612325666121,-1.5609396825137642,58.164689005341415 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark06(-0.797992875415202,-1.5707963267948966,7.830700550649576 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark06(-0.7984085874230156,-1.4287342391028437E-101,-1.5707963267948966 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark06(-0.7988728044632492,-31.44433590704884,13.841024466286315 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark06(-0.8001200145916485,-88.45663682426084,31.866604922841333 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark06(-0.8009467074335908,-44.23799699524477,0.07107903931558046 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark06(-0.8016997782064585,-3.2944368572595385E-83,-3.228286628643243 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark06(-0.8027432229259805,-1.5707963267948966,-68.04490127606034 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark06(-0.8031086940119436,-7.36937845826878E-18,1.5707963267948966 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark06(-0.8034036271553506,-1.5707963267948966,23.621935742518456 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark06(-0.804077346553363,-1.5707963267948966,25.135109132671246 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark06(-0.8051332680539683,-1.5707963267948968,80.53825001593222 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark06(-0.8064800697607182,-88.42465859859973,6.98463396460734 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark06(-0.8070378262834657,-1.5707963267948957,-1.5747026507606043 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark06(-0.8107734731574423,-0.15195728159157262,13.8956014708595 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark06(-0.8108619774766104,-0.7817324813600564,20.01764824934331 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark06(-0.8137483398016547,-1.5707963267948966,73.69753979099143 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark06(-0.8166123307708845,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark06(-0.8166409530611105,-1.5707963267948966,-0.44636438129563416 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark06(-0.8186796757835343,-1.5707963267948966,32.67595408189942 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark06(-0.8199518142693433,2.465190328815662E-32,0.0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark06(-0.8213152736516243,-100.80846357386874,64.12011356968662 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark06(-0.8221832954854037,-31.4165557834927,45.3906244996031 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark06(-0.8227342924525693,-2.9749747112436767E-12,-128.9619221904934 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark06(-0.8235643066367931,-0.31044993514291264,-159.67539434718444 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark06(-0.8256637607352362,-1.1231868454107286,0.0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark06(-0.8269005950312117,-1.5707963267949019,-42.50281053904306 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark06(-0.8287521210639682,-2.914791188717514E-15,82.92024107825796 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark06(-0.8295421384809722,-1.5707963267948966,3.266592655855384 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark06(-0.8299707938194886,-3.552713678800501E-15,-43.98246371249639 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark06(-0.8303732533885775,-1.5699451024278843,51.74348638818076 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark06(-0.8309666105348679,-37.70542369861628,59.40867311121309 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark06(-0.8329984440990774,-1.5707963267948966,45.84847457641918 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark06(-0.8335559432186478,-45.08297629918971,2.070802245575057 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark06(-0.8350151076048938,-1.5707963267948966,-53.91398026444345 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark06(-0.8356979601512927,-45.553093473940876,69.80512099120583 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark06(-0.8360601202368036,-1.5707963267948966,-0.4055052734859492 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark06(-0.8361700583007552,-0.43461378518221716,65.68714511429624 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark06(-0.8362458327036912,-32.915249831777714,58.445595681541064 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark06(-0.8371147131040644,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark06(-0.8371883223109648,-1.5707963267948966,4.443886235695153 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark06(-0.8374817345210772,-1.2661965306492853,-3.1415926535897953 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark06(-0.8375643529992005,-0.2763790763226253,-4.71263313078938 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark06(-0.8382491999337064,-0.887013933690693,3.2665926642303207 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark06(-0.8385820624851295,-1.5707963267948912,64.90883845479605 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark06(-0.8400988114064654,-0.13243013915562768,-24.64227592021654 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark06(-0.8406906921846051,-101.09291136985429,13.035666733404476 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark06(-0.8407371211460865,-3.141592654033935,-1.5707963267948966 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark06(-0.8410521294041429,-0.08526789115152966,-85.40435289142913 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark06(-0.8410717343638154,-0.5749852493567666,136.26635764556755 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark06(-0.8421872177248083,-31.72345493260768,0.006737483714128384 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark06(-0.8426753079446636,-39.142691620432295,1.5707963267949054 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark06(-0.8438776190269195,-1.5707963267948806,4.250316040216589 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark06(-0.8441166779312236,-100.87695024510572,341.08460630397565 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark06(-0.8449325215989222,-1.392644237089287,-4.3292965395633995 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark06(-0.8452613089069628,-0.4186608793084101,1.5710404741342852 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark06(-0.8454089944664157,-1.5707963267948966,-1.5710538859672405 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark06(-0.8465012896046797,-44.39723437310577,64.25327986096846 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark06(-0.8470232212602693,-1.2127697793101564,66.06803929059373 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark06(-0.8474863066303429,-0.649726815119459,-25.987090950365864 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark06(-0.8476575772790937,-1.5707963267948957,-10.768640628295685 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark06(-0.8480557177185382,-0.14114628624673003,-79.05124532994375 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark06(-0.8496295077331983,-95.64103049739168,120.9440270029429 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark06(-0.8503646458700334,-2613.4304280557144,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark06(-0.8515215659656011,-1.2485273123764669,38.928978132816056 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark06(-0.852160669378584,-1.5707963267948966,68.92947773355718 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark06(-0.8525931045223718,-1.5707963267948966,-99.56232477659691 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark06(-0.8528039700305043,-1.5707963267948966,52.05956771339599 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark06(-0.8528832378101046,-5.556896873712694E-163,28.436018216229485 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark06(-0.8532447211048091,-0.8663442619428975,54.42184640972622 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark06(-0.853501890344027,-19.360858623919974,618.8937469346392 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark06(-0.8537619839099472,-1.5707963267948966,-3.141592653589794 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark06(-0.8541481557670285,-88.34845705227508,1.47996275392061 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark06(-0.8544937917736529,-3.141592653813787,63.22476410765944 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark06(-0.8548186018559305,-1.4951261687444468,-1.570796326794898 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark06(-0.8551139952398494,-31.970579625875352,133.53729746095877 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark06(-0.8555616629742673,-1.5707963267948966,-79.47864797518952 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark06(-0.8562917782561463,-1.523977347971429,17.30487315279215 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark06(-0.856469590158352,-1.5676065829296937,85.27287778243014 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark06(-0.8572960147585809,-0.08740600071681603,15.111241019255516 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark06(-0.8575502630447147,-0.596873142787247,-34.45996854625949 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark06(-0.8579814787737577,-45.54461582427757,1.5707963267948912 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark06(-0.8604513329740726,2.465190328815662E-32,-84.3909778045622 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark06(-0.8626560731479714,2.465190328815662E-32,23.56047561729902 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark06(-0.8628220002506275,-3.552713678800501E-15,-42.92558471138543 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark06(-0.8640948378491402,-1.5707963267948966,-33.31144170687604 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark06(-0.8641297763398705,-0.1312385140444996,1.5707963267948966 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark06(-0.866996771220641,-164.69421193379907,-4.8481807806631885 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark06(-0.8683211650167484,-1.5707963267948961,31.499281929974472 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark06(-0.8683563390070363,-102.10175374563555,34.53489838909516 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark06(-0.8683573172567939,-1.0857841842111173,-31.415927641812726 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark06(-0.8692058954768581,-88.42623626491215,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark06(-0.8695394523842235,4.3368086899420177E-19,-83.18842371371484 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark06(-0.8698750301616041,-1.5707963267948966,25.760784462115602 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark06(-0.8702905722534436,-1.5498482077429485,0.0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark06(-0.871293736152395,-0.34511307433229543,-31.82466601487252 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark06(-0.8724531405331055,-4.3368086899420177E-19,-12.42622295935464 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark06(-0.87387722837736,-1.2378862888158455,39.27114766196034 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark06(-0.8742997655284299,-1.4123340380541225,1.5401125302419512 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark06(-0.8783255900842568,-1.5707963267948948,-70.60536101030704 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark06(-0.8786428869019061,-1.5707963267948966,-4.7142378808045144 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark06(-0.8802976420543653,-44.422099613203436,33.25967382081377 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark06(-0.8815878047738852,-1.5707963267948966,19.598488997810037 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark06(-0.8828695282894357,-0.34355963917450794,-88.21600462201079 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark06(-0.884037462134572,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark06(-0.8854491690658741,-0.08839430584802702,-9.945190081902231 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark06(-0.8871537961887138,2.6469779601696886E-23,-32.68037941516005 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark06(-0.887342857173101,-8.16330958319143,70.98475920173942 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark06(-0.8883838921320688,-1.4992418619332613,-88.14985868571375 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark06(-0.88847828133432,-95.41097210511828,77.0979252384541 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark06(-0.8886965602404686,-0.34558452011324814,-17.074745478460734 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark06(-0.8891726223517188,-1.0516521142113064,-504.9342975015373 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark06(-0.889253725617517,-0.7425422350591466,31.06567328110217 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark06(-0.8900142300549838,-1.5707963267948966,55.05311903911277 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark06(-0.8933982099399927,-1.5707963267948966,87.36538016748796 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark06(-0.8934148608947925,-0.030197415350072972,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark06(-0.8940752897823747,-1.1687801041793833,-62.34225110152969 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark06(-0.8971490493279288,-1.5260454986386822,-4.743751941516679 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark06(-0.897856719484528,-1.5707963267948983,9.9199657055876 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark06(-0.898324063864211,-0.6032462151631428,-3.141592653589793 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark06(-0.8985324950643161,-0.7519936437549863,88.73129992603546 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark06(-0.898841463724743,-1.5707963267948948,99.46116284789609 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark06(-0.8993513091022881,0.24691942656445112,19.02369986367222 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark06(-0.8993681973585583,-163.85256023187299,1.5707963267948963 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark06(-0.9001252078057833,-1.5707963267948966,66.11320371365315 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark06(-0.9002882878212026,-1.5707962159015472,-1.5707963267948974 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark06(-0.9008987580273775,-1.5707963267948966,-93.82023750446331 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark06(-0.9011238742678529,-1.5707963267948966,55.7692967713825 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark06(-0.9022892194033345,-39.19564103469046,1.570811585587755 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark06(-0.9023390996499365,-1.5707963267948966,-61.247962314667575 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark06(-0.9029150049426176,-0.47385968815681184,33.50804799071801 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark06(-0.9038823485252518,-1.5691053240472574,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark06(-0.9044829209167397,-1.3431641655883326,0.9175110905920129 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark06(-0.9061626956164086,-39.015823426534226,660.5717580325647 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark06(-0.9062465482783169,-1.3956242773463585,9.550546273761512 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark06(-0.9079604814924025,-32.767082645416274,1.5718109941094365 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark06(-0.9085744331730473,-19.4193907909809,64.45669145859767 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark06(-0.9093042287948329,-95.29080223984383,3.1415926533855902 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark06(-0.9096655285284527,-1.5707963267948966,-67.33331571827566 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark06(-0.9101425749377355,-2.2557930174986843E-15,19.63189785377253 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark06(-0.9113928764808134,-0.1416049069554941,24.1608663508825 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark06(-0.9119550152572372,2.465190328815662E-32,68.51637702075541 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark06(-0.9125804593411352,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark06(-0.9139693351594205,-1.5707963267948966,21.725764622557307 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark06(-0.9147508109232881,6.712388980384695,89.84855137253862 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark06(-0.9182081822239256,-37.69911184307752,40.366615166644074 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark06(-0.9186174593846205,-0.015999190980030997,-88.47717337204303 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark06(-0.9193265094106392,-1.5707963267948966,-21.21660557255241 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark06(-0.9199414350416656,-0.05680834712428595,-72.0520692943841 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark06(-0.919971664116274,-0.0563692387034535,-77.15300305447576 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark06(-0.9203942599147303,-0.12160337270072363,-1.5707963267947136 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark06(-0.9228696924410701,-0.593285066434126,100.0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark06(-0.9241150106275308,-0.04407365590934109,-60.41099748227205 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark06(-0.9247365691359446,-1.5707963267948966,-4.638321034150209 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark06(-0.9256803266236382,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark06(-0.9256973102611988,6.777469371329563,72.20565520841507 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark06(-0.9283113475845512,-0.22338249744522898,1.5707963267948912 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark06(-0.9298234805611313,-31.915875712740903,1.5707963267950105 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark06(-0.9303633619324656,-1.5707963267948983,7.5626929948012815 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark06(-0.9340136420254344,-1.5707963267948966,-4.712396613268337 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark06(-0.9340474957381693,-31.53277665869973,51.86151712298815 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark06(-0.9351636426721817,-0.23729778903364496,71.08070609790849 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark06(-0.9354769869255968,-94.2477796076938,32.51221577827789 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark06(-0.9367579861106925,-37.762762170416835,78.53902755818439 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark06(-0.9373547407069367,-39.05303920589583,21.375397922558534 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark06(-0.9390711335648452,-1.2631312399727304,3.1417205921404046 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark06(-0.939784593175915,-163.78139869245138,1.633308065775046 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark06(-0.9405529440170657,-1.5707963267948966,4.743638983285838 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark06(-0.9422557424037983,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark06(-0.9430093721506596,-1.778206999588062E-161,-15.706666120156076 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark06(-0.9439983648754513,-1.5707963267948983,249.7561013238354 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark06(-0.9455826066158579,-7.105427357601002E-15,-65.61785812620093 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark06(-0.9456591852558204,-45.08578300518562,8.274788110000497 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark06(-0.9462195959923817,-45.42586468524668,21.099307106993663 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark06(-0.9466394750338788,-0.18745906132621373,6.458942362681043 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark06(-0.9471594603982153,-1.5707963267948966,-62.507258813975966 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark06(-0.9476640099382999,-0.711028802907407,-453.9553782544591 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark06(-0.9482577694022777,-1.3028619211561026,-10.72651336235353 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark06(-0.9494355075976991,-1.5707963267947584,-1.4882717704090647 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark06(-0.9497356196057792,-1.5707963267948966,-4.713720728149419 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark06(-0.9523414980496785,-1.5707963267948966,44.333987000269026 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark06(-0.9535404880419336,-0.03510383863910432,-11.666900560029347 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark06(-0.9535685003023824,-38.99038674547847,59.05668457279371 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark06(-0.9539811055864789,-1.0008280775141147,-15.209299365848523 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark06(-0.9549562062310785,-1.5707963267948966,20.926119112491325 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark06(-0.9558087224373405,-0.8578121789453294,54.38809775613682 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark06(-0.9563135860773133,-1.5707963267948966,-67.29824778404 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark06(-0.9564304764262062,-1.5707963267946816,-28.648449509379418 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark06(-0.9567346073962967,-0.21926323580819884,0.0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark06(-0.9570758527172128,-0.7143699301105584,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark06(-0.957686727257507,-1.188665346761521,77.1314969961066 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark06(-0.9609290299117984,-0.061928716077849444,90.80052897701572 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark06(-0.9611879941651296,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark06(-0.9613334924889814,-35.88566912696051,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark06(-0.9615592446147698,-1.5707963267948966,-10.995698044331018 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark06(-0.9620733989634739,-88.39903665368983,1.5707963267731997 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark06(-0.9623589218343576,-32.96913090112285,31.453909242959085 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark06(-0.9632698517635674,-1.5707963267948966,60.54436792793176 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark06(-0.9633913448861532,-0.01650322901564305,49.98661165935684 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark06(-0.9635868735195643,-1.570723870199402,53.226638735084386 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark06(-0.9638500845247107,-0.6465226699139209,-6.712391382880304 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark06(-0.9651925880629062,-0.051209767675755274,-8.370508405882664 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark06(-0.965848105379741,-1.5707963267948961,-15.707964508111472 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark06(-0.9670849062243059,-1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark06(-0.9672513030434593,-32.62160967932218,78.08357886769235 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark06(-0.9685058343446646,-88.326358608293,25.136663949414743 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark06(-0.9706464907352543,-1.5707963267948966,-1.5048066022359308 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark06(-0.9713332189350001,-0.11863494385472184,-645.585150874456 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark06(-0.9719093296136947,-1.5707963267948966,90.63510344837069 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark06(-0.9728128741719723,-38.956172938950054,3.141592653478692 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark06(-0.9733328260237399,-1.5707963267948966,-3.2469043860967917 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark06(-0.9737922023116723,-1.54512419404112,4.887221255826333 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark06(-0.9779042165907372,-1.0794908970682537,90.77518488438704 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark06(-0.9783208489262434,-1.399732375833804,-36.39242372796605 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark06(-0.9788615276680117,-44.444180023022135,58.78140631966528 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark06(-0.9790809411968513,-88.11138560410576,88.1499839730827 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark06(-0.9807841732150768,-0.3550032178258938,-58.210992697941386 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark06(-0.9818117159549355,-0.8101796677865439,96.6514306491249 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark06(-0.9830464746853332,-3.1415926535898246,-66.42800919824177 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark06(-0.9832163174895499,-1.5707963267948966,45.24556890437156 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark06(-0.9836202462215204,-1.53337679706291,-96.56727837895045 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark06(-0.9836736378897267,-1.5699205556924523,89.47324816223627 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark06(-0.9843544240839635,-1.5077419515057497E-15,-24.88409607503219 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark06(-0.9851887707047703,-1.5707963267948966,3.26659265359177 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark06(-0.9852910939220083,-1.1294574206742685,0.056360397846556484 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark06(-0.9860209464581057,-31.41592653590095,6.681746686368633 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark06(-0.9862175544872263,-1.5702595178345982,-89.75638770612359 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark06(-0.9866030482307471,-1.5707963267948966,-6.712389007078035 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark06(-0.9866827460960665,-0.628948382442872,227.7649153364968 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark06(-0.9869538852189956,-95.45803628502664,1.5707963267948968 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark06(-0.9878760014975608,-1.5707963267948963,6.712388983085637 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark06(-0.9887625604341572,-32.788285248214294,122.00330173803223 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark06(-0.9892651759969637,18.849555940561967,46.41046330040339 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark06(-0.9910153364033079,-1.5707963267948966,-85.25204652405453 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark06(-0.992041414770652,-1.5707963267948966,2.070796326794922 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark06(-0.9921480183346927,-1.5707963267948966,67.81527147545103 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark06(-0.9922017761154912,-1.5707963267948966,69.77001185348269 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark06(-0.9923672308945515,-1.5707963267948966,-6.116932184430524 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark06(-0.9940471486174651,-0.8179888446141916,-6.555086561219241 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark06(-0.9955959766273818,-0.5707221288964518,32.50255826246599 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark06(-0.9959787606201621,-1.5518281886264194,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark06(-0.9974194505599983,-95.54901256894367,114.85374934527997 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark06(-0.9976365706709318,-1.5707963267948954,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark06(-0.9982847250689895,-0.03472473754906475,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark06(-0.9992914802769446,-1.5707963267948968,-30.735020198600672 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark06(-1.0003099341452817,6.712414459044305,6.550050634493797 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark06(-1.0008235745416183,-1.5707963267948963,1.5707963267950105 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark06(-1.0014901460468848,-19.34955592153932,0.5089092942562442 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark06(-1.0016812428750284,-0.7719669522514947,16.016325468402197 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark06(-1.0017410353044651,-1.9742063534922827E-177,-46.672288961387146 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark06(10.019433607724721,-27.369109139534714,-9.893381261687978 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark06(-1.0037668309199481,1.1102230246251565E-16,-0.20449325781389796 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark06(-1.003979739525409,-1.5707963267948966,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark06(-1.0058712912446002,-1.3502178278379307,1.570796326794893 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark06(-1.0061567763571055,-1.372727913404475,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark06(-1.0065239621448292,-1.5707963267948966,-3.266592658666982 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark06(-1.0070932645831276,-1.5707963267948966,1.5707963267949197 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark06(-1.007381089687586E-9,-45.392398015596,84.80414945970865 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark06(-1.0077755853794188,-1.5707963267948966,-25.12232705863373 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark06(-1.0087029616013368,-0.9324474054509173,45.323380827775026 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark06(-1.0090245361835626,-0.792274946319167,-76.3184110557128 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark06(-1.009126295015225,-0.9397275854908562,-39.01069344478829 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark06(-1.0097419688384508E-28,-1.570796326243476,-3.141592653589793 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark06(-1.0108515707721484,-1.295223865147571,1.5707963267948966 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark06(-1.0109691289121878,-45.37215211579092,21.923874855738635 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark06(-1.0110159476347382,-1.5707963267948912,0.2500808152550582 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark06(-1.0110771503117297,-1.5435625408223075,-39.6358892580299 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark06(-1.0133239585122307,-44.0906142759462,1.4326562135539571 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark06(-1.0133624521448796,-32.74424502742531,32.78576450128628 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark06(-1.0143942669651067,-1.5707963267948983,-0.49567250752270553 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark06(-1.0151767349262597E-115,-1.7763568394002505E-15,10.900624534534245 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark06(-1.0152763636756672,-1.5707963267948966,20.779045643940307 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark06(-1.0154408160954052,-0.907001563929224,-1.5707963267948968 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark06(-1.0167068422299206,-1.5707963267948966,-90.94982846719672 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark06(-1.0168781912983622,-1.5707963267948966,-146.3297416216883 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark06(-1.017448594558618,-39.244619091300294,64.27630681989706 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark06(-1.018794282439588,-0.5253697565731514,-100.0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark06(-1.019216449620894,-0.20320659973893995,0.522221781239933 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark06(-1.0206550668463814,-1.5707963267948966,6.938893903907228E-18 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark06(-1.0212551488425754,-0.1066298094618503,30.356460256042915 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark06(-1.0228945255255069,-164.64546453676283,0.6659266348968318 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark06(-1.0238007306960737,-1.56779679107501,-4.714343172939265 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark06(-1.0248085644627558,-1.5707963267948983,-8.066981315807325 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark06(-1.0250151036446793,-1.5707963267948966,54.36639491722397 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark06(-1.0261239799053143,-0.36074756277235126,-10.59624357086371 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark06(-1.0265329574848323,-1.5707963267948966,3.1415926535897962 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark06(-1.0265854734232538,-88.41320574184464,32.005321246512544 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark06(-1.0266158583238376,-1.5707963267948966,-4.712396661963231 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark06(-1.027088534773994,-0.7221531156225599,-9.869087113603337 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark06(-1.027278083783015,-1.4528056309308723,-56.37788879130086 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark06(-1.02761299766087,-1.128149083220571,-0.5731396002984496 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark06(-1.0282150351238968,-1.5707963267948966,26.83205360336543 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark06(-1.0305774738567681,-1.5707963267948966,4.987993832520411 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark06(-1.0332171823585763,-1.5570974742854276,-145.98937327515577 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark06(-1.033469768216464,-1.5707963267948966,12.134466111855085 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark06(1.0339757656912846E-25,-1.5425463300246651,57.84738462360031 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark06(-1.035167002841705,0.016462904979627133,76.81709718132485 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark06(-1.0358063191193103,-39.26797352341379,82.45733912099786 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark06(-1.0369105339511613,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark06(-1.0369731487849048,-1.5707963267948966,-56.990790181515294 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark06(-1.0377246911235347,-1.5707963267948966,3.2085856489957867 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark06(-1.0377803647103516,-45.014862519839156,1.5707963267948983 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark06(-1.0389986860448477,-1.2517279974172881,33.417813726166706 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark06(-1.0395392471605613,-0.10743050863468273,730.413762031644 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark06(-1.04067666419121,-1.5707963267948966,-6.712388980712667 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark06(-1.0421486831655264,-0.25719986000627215,23.207147426445268 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark06(-1.0424072710219385,2.7755575615628914E-17,44.29340478197659 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark06(-1.0425573396002499,-1.2572585568160477,0.0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark06(-10.42767543215433,58.1836463826842,-89.21268003740428 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark06(-1.0435516905254074,-1.5707963267948983,-10.957549961533616 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark06(-1.0442854509724655,-1.4071168934031633,-97.60208166243642 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark06(-1.0443883646728693,-3.1415926535897967,8.037751571587279 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark06(-1.0458128866855763,-1.4030699573961019,25.132741228718345 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark06(-1.0485629715062452,-1.5707963267948966,-17.621417665944094 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark06(-1.0501541395943177,-1.5707963267948966,40.66594331922576 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark06(-1.0502938111520548,-1.5707963267948966,-83.24632451996239 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark06(-1.050354917433088,-1.570796326794115,-6.712403840340312 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark06(-1.0505945258749865,-1.5707963267948983,-26.849006891328266 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark06(-1.0542197943230523E-81,-1.5707963267948957,1.5707963267949197 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark06(-1.054412479258556,-1.1859308979676295,-18.074954473680613 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark06(-1.0548045070019882,-0.9074921563297949,-83.5201431124477 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark06(-1.0549315559869736,-1.5707963267948966,-67.6824903784246 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark06(-1.0551616242119346,-1.5707963267948966,-0.5629319455576418 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark06(-1.055956893042796,-1.5707962946179508,-98.62035400810763 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark06(-1.0570344844401136,-31.919086373395913,88.6468803072308 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark06(-10.57611330221961,90.86904772363343,20.585531088250804 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark06(-1.0589750702529912,-1.5707963267948966,-68.22725813607009 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark06(-1.059502586347031,-1.5707963267948966,8.79125588080447 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark06(-1.0604332392663613,-1.5707963267948966,-46.1109724128582 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark06(-1.061264386578993,-45.55309311934079,59.415448319831256 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark06(-1.0612659742978222E-15,-3.7516185038485617E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark06(-1.0626697826534839,-0.019431774518583023,80.71671614454422 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark06(-1.063819229610849,-1.1083279376249942,129.55334514085146 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark06(10.638808225434687,92.67180558777397,-65.24023775384572 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark06(-1.0643389932285474,-0.8202313100862985,94.01284909805864 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark06(-1.0645930276391022E-6,-1.5707963267948966,9.425074614478218 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark06(-1.0648381204801505,0.04605339732311309,39.09903893184561 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark06(-1.0652933872342056,-1.5707963267948966,-51.37118235298164 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark06(-1.0657059661673083,-1.5707963267948966,-68.2347061169077 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark06(-1.066421921477867,-1.5707963267948966,-82.17743593642388 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark06(-1.0668511286337778,-0.7983467752490078,-1.5707963267948966 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark06(-1.0680514384553172,-1.5707963267948966,-78.87619962034024 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark06(-1.068533011685318,-44.464160870546124,88.12601056563463 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark06(-1.0687000442890413E-11,-5.591699959924902E-10,-30.565324840136057 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark06(-1.0698919239076932,-1.1187901288656898,93.51008281796194 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark06(-1.0703452516575909,-31.415926535985108,84.42113172527708 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark06(-1.0705826046418148,-1.5707963267948983,-944.02149219394 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark06(-1.0706648858416616,-26.927043816852915,7.136819946887572 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark06(-1.0715745061697532,-0.037574949675042726,-58.307748599509274 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark06(-1.0729934100946164,-1.5707963267948966,-84.52511910430226 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark06(-1.0735686844203367,-1.5707963267948966,52.879858070304856 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark06(-1.075173356331515,-1.5707963267948948,-16.984805868607666 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark06(-1.075737711069836,-1.5707963267948966,19.74499077928728 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark06(-1.0788866664046384,-1.5707963267948966,31.526757072177187 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark06(-1.0798172864895563,-1.1677301731398977,1.5707963267948966 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark06(-1.0798434280715092,-1.5437568294695394,1.5707963267949014 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark06(-1.0808945409126849,-1.5707963267948966,-1.5707963267949054 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark06(-1.0812429787750892,-0.784829481599502,56.37721177221262 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark06(-1.0820207238242543,-1.4036904060144995,-123.74973600009797 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark06(-1.0830515373034626,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark06(-1.083305762435643,-1.570796326794886,-97.45227725252543 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark06(-1.0834689132905897,-1.5676381509963484,71.48281255982276 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark06(-1.0836690733972216,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark06(1.0842021724855044E-19,-32.66528023759293,0.0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark06(-1.0845587580920872,-1.5707963267948957,71.64211060263305 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark06(-1.0849551599286684,-45.224532606967095,114.81202585661505 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark06(-1.0856060672908452,-1.7763568394002505E-15,11.6355672118015 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark06(-1.0856205410079212,-1.5707963267948963,-1.5707963267948966 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark06(-1.0866968490589188,-1.3126782224869196,-1.5707963267948966 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark06(-1.0875440026210037,-38.79759631133728,13.624945563504745 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark06(-1.0884810026133858,-1.5707963267948966,16.437594869147276 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark06(-1.088909531404131,-0.42522010235810936,1.5707963267949054 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark06(-1.0903995773529256,-1.5707963267948966,1.3720243901807387 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark06(-1.0924574628437345,-1.158713624568236,-21.82712947909264 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark06(-1.0929945717830396,-1.5707963267948948,17.279286913054193 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark06(-1.093514671956167,-1.5707963267948948,-37.98729771491397 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark06(-1.095058863838045,-0.9734868494028869,-38.90046633488307 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark06(-1.0954885695801266,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark06(-1.0959046745042015E-193,-1.5707963267948966,-64.89216037422214 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark06(-1.0970359120036208,5.551115123125783E-17,17.988527269717665 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark06(-1.0978929666208177,-1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark06(-1.0979684465090358,-1.4492528572862113,149.90163890576954 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark06(-1.097998616591044,-1.5707963267948912,-70.31561547478965 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark06(-1.0992051924985018,-1.5707963267948966,42.94002355750618 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark06(-1.0995210739532388,-1.185169598747632,163.59670618232394 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark06(-1.0997446384419192,-1.2851963205840544,-32.98648382997469 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark06(-1.1001842713735976,-38.886723390318444,1.5707963267948983 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark06(-1.1024982477619323,-1.5707963267948966,-72.7312282165631 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark06(-1.1038178912707441,-38.84483662203152,89.57742714189163 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark06(-1.1043142338131673,-37.790922766831756,101.90599438305227 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark06(-1.105489879330051,-1.5707963267948957,-54.89322771785693 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark06(-1.1058339985243846,-1.5707963267948966,31.415931332730846 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark06(-1.106103609526677,-1.5707963267948912,0.3161760998145727 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark06(-1.1076242290679272,-1.1437359537420106,43.04067656864618 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark06(-1.1079733630600008,-1.5707963267948966,46.4537448091445 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark06(-1.1084997787213418,-95.60106836989294,0.0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark06(-1.1090399670483042,-1.5651588906618927,3.2665933773483515 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark06(-1.1093373222338925,-0.6291949839375401,-79.61313292606498 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark06(-1.1099552603484816E-16,0.0,0.0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,0.0,0.0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark06(1.1102230246251565E-16,-1.5707963267948966,-1.484073569866441 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark06(1.1102230246251565E-16,-1.5707963267948966,-43.24148393647098 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1577.9808642568207,0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-56.43059257438811,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,6.681911775230489E-52,-1.081129608217309E-57 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-7.5480384478861,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-80.25659809379884,0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark06(-1.1104499081153827,-1.5707963267948966,-75.0868144773174 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark06(-1.112757884735748,-31.50276916246287,153.7790525945178 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark06(-1.1131598199866564,-0.5894098739338514,51.95736869084152 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark06(-1.113655853676695,-1.5707963267948966,-77.91716164397042 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark06(-1.114173901352969,-1.5707963267948966,-27.241571312270327 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark06(-1.1147999678293994,-45.35643017799676,0.597635011035721 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark06(-1.1148891846294349,-0.07557184446543203,-1.5707963267948983 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark06(-1.115013746524504,-1.5707963267948966,-3.266592654775349 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark06(-1.1157400752107538,-44.19385735298118,44.093738404673246 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark06(-1.1161986242990967E-103,-1.5707963267948966,-68.70066822925538 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark06(-1.116528371234073,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark06(-1.1166399322230323,-3.552713678800501E-15,80.65706526292813 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark06(-1.1167636546174236,-101.90773049276423,77.46857692424565 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark06(-1.1167885580295025,-101.08834681410832,75.81069358212571 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark06(-1.1183189925899426,-43.982297150257104,1.570796326794877 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark06(-1.1184329596503808,-94.37273372528044,1.5707963171507562 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark06(-1.1188299406243023,-0.7808806167027061,72.26223340982396 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark06(-1.1194529419368682E-84,-1.5707963267948966,-1.5707963267948912 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark06(-1.1195602854819777,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark06(-1.1195819992220788,-1.1695434619840367E-15,-54.28088784965726 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark06(-11.209904289728996,-80.25014047738226,26.526194410085367 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark06(-1.1213709268609042,-6.344854593289123E-117,-15.601356521351118 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark06(-1.1216485174851374,-0.14772753701663335,0.0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark06(-1.1228528818435777,-0.16454880464397603,14.949503806198193 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark06(-1.1231538419884495,-1.5707963267948966,73.28996725629013 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark06(-1.1233056667284966,3.944304526105059E-31,65.88390269618762 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark06(-1.1241324755313329,-1.5252548193306699,38.932837846451974 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark06(-1.1250309402196086,-1.5707963267948966,77.99656081661956 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark06(-1.1250473923750683,-1.5707963267948966,335.45060570529324 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark06(-1.1262234009842411,-1.5707963267948966,6.776263578034403E-21 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark06(1.1267353859827578E-22,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark06(-1.1270725851789228E-131,-0.42622805633773075,0.0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark06(-1.1273740675912812E-4,-44.403745837630694,214.63374365064493 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark06(-1.12769740645617,-0.39242332300376503,64.42549741563772 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark06(-1.1286101911760937,-1.5707963267948966,-15.771604693447898 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark06(-1.128699108079647,-1.5707963267948966,-72.21686710212389 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark06(-1.1287346534042761,-94.30232543428558,1.448908652612274E-70 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark06(-1.1289010632228518,-107.49932015974291,0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark06(-1.129847656045314,-101.60334566027086,25.13281674890574 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark06(-1.129986362438639,-88.47653120223278,58.00991010019828 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark06(-1.1309797642336623,-1.5707963267948966,152.02967643341276 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark06(-1.131405790584587,-1.5707963267948966,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark06(-1.1314846948042443,-1.570796326794564,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark06(-1.1319222386684948E-13,-1.5707963267948966,9.203623086622173 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark06(-1.1334565105955838,-1.5707963267948966,-11.823432802940275 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark06(-1.1351391718554849,6.712388980406671,37.90271872308804 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark06(-1.1358232386743674,-1.5707963267948983,17.542064857452672 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark06(-1.136328277508957,-0.3997986002119731,-11.233522148927111 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark06(-1.1370802832298024,-1.5707963267948966,38.21222094620777 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark06(-1.1373471735782956,-32.70965353791668,58.29241168789392 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark06(-1.1377652388860109,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark06(-1.1386295282003007,-0.6688268664126443,3.1501321191149714 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark06(-1.1391060975216787,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark06(-1.1401143902027542,-1.5707963267948966,16.989873085543955 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark06(-1.1405666747242922,-0.6354624201742796,-75.57631190340147 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark06(-1.1415592883456047,-45.13962278588404,2.470149392677287 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark06(-1.1419628925996865,-1.2338120208745544,25.932378045652897 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark06(-1.142716430799588,-164.84822458598575,1.5707963267948966 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark06(-1.1434484094075712,-1.5707963267948966,25.790202092484556 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark06(-1.144489557639936,-1.5707963267948966,4.283617178304695 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark06(11.448244231884459,84.2631874135283,3.834729609398906 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark06(-1.1448281660143513,-3.1415926537391843,0.0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark06(-1.1451192324624266,-0.38085035789253446,-9.780049667637883 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark06(-1.1456176632078723,-1.530024152248501,1.5707963267948966 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark06(-1.145668900193617,-88.2719195024138,89.7021567154406 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark06(-1.1459693096412351,-1.5707963267948963,-31.611713732100327 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark06(-1.1477739067975703,-38.91689414507219,2.3875972548040547 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark06(-1.1477989086807596,-1.5707963267948966,-0.570736467638486 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark06(-1.1485650364085442,-1.5707963267949019,-100.0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark06(-1.1488453306776463,-1.5707963267948966,-28.459037490437076 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark06(-1.1488995083389106,-1.5707963267948966,152.94186234359978 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark06(-1.1496305730102563,-1.5707963267948966,-63.62864760113034 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark06(11.497452843642748,29.95865695687897,-64.82599865633172 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark06(-1.1499061294267463,-1.345829093253569,-3.1633025333007776 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark06(-1.1500849845991832,1.9721522630525295E-31,-21.11562503818177 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark06(-1.1509593487914433,-1.5707963263356197,-1.5707963267948966 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark06(-1.1513213172311747,-44.24387803164646,1.5707964857091905 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark06(-1.1518578689651098,-0.05853682131071954,-1.5707963267948983 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark06(-1.1540428070266984E-16,-1.5707963267948966,-78.53981633979019 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark06(-1.1541856228961158,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark06(-1.155027868586144,-1.4439502466571386,-2.5737787947340145E-85 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark06(-1.1555426125566715,-0.5088381081915023,-227.7592860322976 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark06(-1.1570977926672967,-1.5707963267948966,-69.11503837897546 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark06(-1.159722928090865,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark06(-1.1604610609539634,-44.47310216864224,-0.002063258390297427 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark06(-1.161069560788353,-0.021652431183573295,-68.82706737711986 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark06(-1.1611407362371169,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark06(-1.1612684698973248,-1.2904002906835372,2.710505431213761E-20 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark06(-1.1623280158974933,-3.1415926535913945,80.09899235293986 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark06(-1.1626680271362584,-0.17061165787576016,-1.5707963267948974 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark06(-1.16292219050559,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark06(-1.1641854893726005,-45.08880081237652,0.4929723051269512 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark06(-1.1645972310519122,-1.5707963267948966,-47.75758420129581 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark06(-1.1647318727854596,-1.5707963267948983,-41.94799030672964 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark06(-11.657779753028194,21.620109009978506,3.685912047721601 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark06(-1.1678911960072895E-15,-1.5707963267948966,20.887875184762812 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark06(-1.16807411938278,-1.5707963267948966,46.34424994231756 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark06(-1.1680957327073784,-95.3499051883835,25.52970401632892 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark06(-1.1682237973248628,-1.5707963267948966,-9.959616964538924 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark06(-1.1685163412328515E-4,-3.1415926535897936,-52.63656562614696 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark06(-1.1687948859839423,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark06(-1.1690244924896596,-0.8603334055460863,-83.363890420823 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark06(-1.169514420928877,-31.475423861645357,0.0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark06(-1.1697796875245767,-1.3038097235859314,5.6902623986817984E-160 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark06(-1.169791959484571,-38.737241153855614,147.17783252879752 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark06(-1.1698769279176702,-1.570796326794877,-37.728441888596365 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark06(-1.1700080538606983,-1.5707963267948966,-88.58917276232528 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark06(-1.1701511116502115,-44.35577439893033,1.5707963267948948 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark06(-1.1702102448850984,-0.09901974452646689,59.201359699384625 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark06(-1.1712371168412892,-0.006327285782509767,36.737440260888334 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark06(-1.1722623413176159,-45.44902547675387,7.931310612874647 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark06(-1.175374025025094,-1.5707963267948966,2.5146832433981392E-17 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark06(-1.1769787234482556,-1.5707963267948963,39.025420635041115 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark06(-1.1775113651274096E-7,-32.981045041064895,53.40200359238519 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark06(-1.1781440715483815,5.17003533056679,0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark06(-1.178144644404421,-0.9203282627367899,1.5710405689387483 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark06(-1.1781663406295289,-88.24435444147348,3.1415926535897927 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark06(-1.1784460590676997,-0.11585109993294383,-88.30629343018204 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark06(-1.178881767066737,-1.5707963267948966,33.95602842936 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark06(-1.1790974037499526,-32.422268140694044,0.8142509332443204 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark06(-1.1798947823058548,-0.6892194342370033,-4.142318457533239 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark06(-1.181841163015545,-0.6475873037912359,-59.506249711624875 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark06(-1.1820608191916018,-1.5707963267948881,-137.57731031905894 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark06(-1.1824962963182357,-1.5707963267948966,82.38651088513663 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark06(-1.182545037473948E-4,-1.5707840842822858,-53.740627599901025 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark06(-1.1832412685322993,-1.2664701722142333,30.909277776429594 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark06(-1.1833456119815242,-1.5707963267948293,68.01065459553834 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark06(-1.1852292370232191,-1.5707963267948963,-2.185583573094861 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark06(-1.1872624706700279,-0.02061480375505481,-123.14786764910662 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark06(-1.187543180632084,-0.9731121087527485,39.41534296673345 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark06(-1.18756735291609,-1.5707963267948963,-0.3186086776079814 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark06(-1.1876547808530107,2.220446049250313E-16,81.67712819464938 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark06(-1.1887066120667082,-1.5707963267948966,0.301935744307378 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark06(-1.1892944661698213,-0.24257218713777462,-179.52467247801516 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark06(-1.1899215404370744,-1.5707963267948966,62.99281967743637 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark06(-1.1902466495090187,-1.0383888749516492,73.58934896346365 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark06(-1.1903585090351032,-1.5707963179150501,5.1574620863981195 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark06(-1.1911030066731971,-1.5707963267948966,89.06134646927777 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark06(-1.1917154831381627,-1.5707963267948966,72.5334054278693 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark06(-1.192922610279607,-1.323319012515476,51.61516942802183 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark06(-1.194350921987425,-45.118285896307974,32.34706862005309 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark06(-1.195420982329373,-39.12025622883626,1.4514655051113508 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark06(-1.1956924263646969,-1.4810411411924642,-1.5777218104420236E-30 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark06(-1.1985091468012028E-94,-1.5707963267948966,-67.46538899635915 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark06(-1.2010873771958641,-95.25422580612758,-11.011199287700459 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark06(-1.2014333373884352,-1.5707963267948628,0.23554576573455677 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark06(-1.2027760782712562,-31.49297628690168,284.21445450735877 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark06(-1.2035490212433437,-0.9228039743914807,-1.5707963267948966 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark06(-1.2035881970496232,-1.155527225339101,82.94033607468187 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark06(-1.2041312130675286,1.6543612251060553E-24,-1.5707963267948983 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark06(-1.204260323804926,-0.08541541424520123,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark06(-1.2047494829329697,-1.5453355733607654,-1.5707929919704047 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark06(-1.205331515011796,-95.39884595208096,88.28197408125888 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark06(-1.2056655971715884,-2.220446049250313E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark06(-1.206123891210456,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark06(-1.206587721154921,-1.5707963267948948,9.705416347907232 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark06(-12.066518110007053,-43.76446039084012,19.814681132361315 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark06(-1.207138157671095,-1.5301722312185215,-7.418412301374843E-68 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark06(-1.2081881543818163,-1.5707963267948966,-51.33804069435788 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark06(-1.208751951162641,-45.38223762087943,1.8677264098053872 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark06(-1.2110009602646088,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark06(-1.2117870435761924,5.141592653590048,88.2346431156906 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark06(-1.2125146298411038,-1.5206895834676046,17.27927244861085 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark06(-1.2128310133666571E-14,-1.5707953962404246,9.424786550835158 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark06(-1.2142075759008466,-1.5707963267948966,-1.5707963267948974 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark06(-1.215241740125993,-0.910959020127823,-6.16423027696549 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark06(-1.2160252391095845,-0.004216531195081384,-32.39616375954879 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark06(-1.2164269555566853,-38.73892584051623,6.938893903907228E-18 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark06(-1.2166986024289023E-209,-1.5707963267948966,54.90698872482584 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark06(-1.2198268458936168,-0.6891395955617317,-1.5717728897408925 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark06(-1.2202450664625342,-1.5707963267948966,0.4942889310632059 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark06(-1.2210845133048143,-0.5171914832356279,-81.90749933419967 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark06(-1.2223703974396931,-1.5707963267948966,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark06(-1.2238528627897636,-1.5707963267948881,1.5707963267948966 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark06(-1.2249085362384098,-1.5707963267948966,55.47952353175461 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark06(-1.2261095081441977,-1.570796326794896,-1.2206381976741024E-16 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark06(-1.226486061493375,-0.6034162837238171,62.038521771163545 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark06(-1.2267372024099037,-1.5707963267948966,4.755671512966225 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark06(-1.2278367373514083,-1.2432435975588785,0.0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark06(-1.229662447404702,-1.5707963267948966,-34.241126752395964 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark06(-1.2307295392070494,-1.4359235041274379,69.62706658139327 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark06(-1.2323034078627386,-0.9090792739838764,-74.1069086498767 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark06(-1.2337286779356162,-1.5707963267948966,-2.6344649962923707 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark06(-1.2341343782348462,-37.94090940977945,2.5707963256316 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark06(-1.234278431394403,-0.1003363503802356,-0.5730961167419792 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark06(-1.234423618096784,-1.5707963267948966,-4.677991916654477 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark06(-1.2347975267540667,-1.5707963267948966,-56.97835281871393 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark06(-1.2355593125352502,-3.141592654943393,100.0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark06(-1.235673643142801,-45.491953092246185,40.231602433734764 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark06(-1.2359765891577763,-1.5707963267948966,-36.644276364201815 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark06(-1.236343830416883,-1.5707963267948966,32.06475675059335 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark06(-1.2393161135328603,-1.1366260189279147,29.940231325929975 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark06(-1.241138994481829E-5,-1.5707963267948957,210.47386380481294 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark06(-1.24190884353852,-1.0877465052751623,-6.534410960793274 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark06(-1.2425601911254032,-1.375157234109123,-156.1567417833401 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark06(-1.2426334571027333,-1.5707963267948966,25.742100284422804 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark06(-1.2445656697776362,-1.5707963267948966,-86.91983947216102 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark06(-1.244826618386181,-94.2477796076938,1.5710414994446553 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark06(-1.2457713858291604,-0.28378096194037183,-65.9734457263224 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark06(-1.2476829570155594,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark06(-1.24813721273954,-1.4132038557003466,-1.5707963267727376 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark06(-1.2484622132717893,-1.5707963267948966,85.80657607081247 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark06(-1.2489307272595656,-1.5707963267948966,-97.53875080379 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark06(-1.2493057074537373,-95.43824597948642,32.824132106940766 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark06(-1.2503385626669268,-163.52827217921148,1.6381443874500239 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark06(-1.250698576596839,6.990718588970964,1.5707963267948983 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark06(-1.2523169743586955,-4.440892098500626E-16,100.0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark06(-1.252431781640933,-1.5707963267948912,70.76227865549006 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark06(-1.253476314661117,-31.480149461293216,1.5707963267948974 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark06(-1.2537377884681271,-1.538350364706991,25.132741228718345 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark06(-1.2543962076090556,6.938893903907228E-18,-36.796866235613976 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark06(-1.2549079190696553E-16,-1.5707865064614088,9.424430766936267 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark06(-1.2557116782752669,-145.08405839174796,7.105427357601002E-15 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark06(-1.2566577336268285,-1.5707963267948966,4.712389456542266 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark06(-1.256727927116218E-88,-1.5777218270270513E-30,100.0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark06(-1.257384597662508,-1.5707963267948983,65.02552728476925 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark06(-1.2576957896071421,-1.570796326794897,-4.71434233093983 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark06(-1.257847528410477,-0.12587757206055805,49.505219230444055 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark06(-1.258022699662574E-15,-1.150146527521673,1.5707963267948966 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark06(-1.2590976977149526,-1.547603441483588,-37.840632356144795 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark06(-1.2601243093376366,-1.5707963267948966,-86.77922308380782 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark06(-1.2601829132648115,-1.570796326783398,73.87053994014988 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark06(-12.625484899861661,-9.051934452847547,-77.70819634806163 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark06(-1.2629358057844122,-44.06944817891198,89.08765597744164 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark06(-1.2641505822479844,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark06(-1.2647074882750582,-1.5707963267948966,-24.43078759588405 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark06(-1.2654472009792914,-1.5707963267948966,70.00620858163613 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark06(-1.265491869330094,-1.1873702609310213,1.5707963267948966 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark06(-1.2657736223302607,2.710505431213761E-20,58.56369341451278 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark06(-1.2660044192382838,-1.5707963267948966,3.1415926535897896 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark06(-1.2662257963104595,-1.5707963267948966,1.6295281345429489 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark06(-1.266918610974543,-0.990381172267213,-1.5707963267948966 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark06(12.67025257564191,-83.71498668069835,-27.068116390327134 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark06(-1.2683059358706954,-1.570796304468352,1.5707963267948983 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark06(-1.2689782175956004,-1.5707963267948966,-43.91792610835572 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark06(-1.2692703686800968,-0.5275385023158261,-9.629674023837438 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark06(-1.270198127075449,-1.5707963267948966,-5.687906331294101 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark06(-1.2718635427950702,-1.4168659074009866,-3.141593621774634 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark06(-1.2718797659491372,-88.1635347871914,38.08201665202472 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark06(-1.2743387566912847,-0.5325978172497764,1.5707963267948974 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark06(-1.2747259630806895,-88.52789060284448,83.7237574856574 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark06(12.747403881238142,33.80540720532761,14.11156665354521 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark06(-1.2768023990040271,-1.5707963267948966,3.266620540605498 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark06(-1.2769734059979527,-1.5707963267948966,-79.61833789243592 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark06(-1.277450855867686,-38.85652668317603,1.5708001415110209 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark06(-1.2810413040729787,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark06(-1.2812026783593398,-2.1097278671967158E-15,1.5707963267948966 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark06(-1.281277643448628,-95.59498952776472,101.07043261117893 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark06(-1.2833375833970029,-1.5707963267948966,-122.6454382680183 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark06(-1.284066074119802,-1.5707963267948966,47.11198519039847 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark06(-1.2841163267669549,-5.747006299740515E-16,0.0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark06(-1.284499704626322,-1.5707963267948983,45.3910975093047 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark06(-1.2845221236577264,-0.0476649504372233,-44.08324620271043 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark06(-1.285664742796031,-1.5707963267948966,-26.752035748697672 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark06(12.862334364423276,62.72465419811306,22.498055210009056 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark06(-1.2863368682747651,-1.5707963267948966,0.335233612492118 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark06(-1.286674884587266,-1.5707963267948966,1.5707963204613955 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark06(-1.2868893973670072E-85,-1.5707963267948966,-71.29297151092196 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark06(-1.2877211083023123,-1.5707963267948983,-33.43385342943334 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark06(-1.287844730304186,-1.4770085768333605,-3.1415896363489573 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark06(-1.2887876587788525,-0.7952288162754395,-85.70115106118223 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark06(-1.2893778154821676,0.014214946501612062,0.8725864970170397 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark06(-1.2899801209082185,-1.5707963267948961,1.5707954026486342 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark06(-1.292869574924305,-0.3542194880334433,-0.4027282618507635 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark06(-1.2931406496740578,-1.2746623480559247,29.963220305213326 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark06(-1.2933903844276333,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark06(-1.2941871741555884,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark06(-1.2946134081187357,-0.06672562232142987,-1.5707963267948966 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark06(-1.2951158377658258E-15,-1.5707963267948966,3.141592653589793 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark06(-1.2958017626603253,-37.71121463818945,1.5707963267948912 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark06(-1.2962345905318988,-1.510332495903667,-24.89669981482217 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark06(-1.2967467368965,-0.6132912322871618,66.17147804836499 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark06(-1.2971749257007597,-0.4310362076447975,-97.41438601576284 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark06(-1.2983963609890488,-0.9912849275460419,-30.33724108800146 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark06(-1.2992531002990617,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark06(-1.2999665718477913,-1.5707963267948966,77.49671414547251 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark06(-1.3003965206568027,-1.5707963267948966,5.8688078074718945E-15 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark06(-1.3008863370577435,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark06(-1.302223853912038,-1.5707963267948966,3.1415926535897967 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark06(-1.3027118979110288,-1.5707963267948966,124.43235495696138 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark06(-1.3028469654764248,-1.5707963267948966,63.496085872704924 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark06(-1.3041353893238534,-0.85174857474086,-73.60609668123142 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark06(-1.3043746063200452,-1.5707963267948966,-4.71944751874123 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark06(-1.3045167876858776,-1.5707963267948966,-53.46352913058891 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark06(-1.3057562812301553,-3.1415926535897936,1.2413217491199062 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark06(-1.306315200334268,-1.5707963267948966,32.714460277454336 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark06(-1.3070978400537956,-5.551115123125783E-17,-31.415926540271343 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark06(-1.307293670186649,-1.00207693572386,9.139345874553344E-14 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark06(-1.3076954202164588,-1.5707963267948966,44.06126532079435 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark06(-1.3079910828046515,-0.7194896084355092,-78.04707776181672 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark06(-1.3108577286169116,-5.3546357529207786E-15,-31.769325946779766 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark06(-1.3108666114441283,-1.5707963267948966,-2.570796280159382 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark06(-1.3118063714904764,-1.5707963267948983,44.10469042622981 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark06(-1.3118416408320007E-14,-1.5707963267948966,22.597284967448765 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark06(-1.3122918182417642,-1.209620406540731,44.416816011652244 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark06(-1.3125624727493141,-1.5299086951189278,1.0165397077618628 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark06(-1.312614247800396,-88.39534145081281,14.388561675937623 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark06(-1.313134228391486,-1.5707963267948966,24.03467747608868 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark06(-1.3140888017010313,-1.5707963267948912,3.4832574861020947E-16 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark06(-1.3143559841316863,-1.5707963267948966,3.141592653589793 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark06(-1.3144773740490887,-0.26349142440315276,-4.359867659796921 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark06(-1.3149699697903947,-1.5707963267948966,-3.2665927630431484 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark06(-1.3153520483458638,-0.9733240132877814,-3.266701914801882 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark06(-1.3155308964473833,-0.6115172828582931,-91.82205186728227 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark06(-1.3170371549234403,-44.52169100154701,32.94815704158066 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark06(-1.317195669905474,-88.39723366563824,0.0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark06(-1.3175197177520441,-1.5707963267948966,5.551115123125783E-17 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark06(-1.318607689749322,-0.42594992004151894,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark06(-1.3191066929179456,-101.55053111703567,1.5193319818693856 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark06(-1.3199835894155427,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark06(-1.3204364045922596,-1.5707963267948966,45.01348918663642 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark06(-1.3210549979147612,-3.552713678800501E-15,-88.10895461577655 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark06(-1.321727668644735,-0.7020356433517764,39.59913921848358 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark06(-1.3224188722603318,-1.5680825439971458,-2.4333972048578046E-209 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark06(-1.3226643955174389,-3.1415926536044223,-71.54187419972281 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark06(-1.3226749668504842,-7.105427357601002E-15,-26.969257259221948 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark06(-1.3233390250458612,-2.7755575615628914E-17,72.6527037942632 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark06(-1.3234809376265986,-0.023711909389912713,-94.67803426772906 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark06(-1.3237420612849669,-1.5707963267948966,33.38937477866602 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark06(-1.3243323570569423,-0.43515031420272404,0.9153410677342808 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark06(-1.3251838691754743,-39.10825624615103,71.72189344209625 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark06(-1.3261102263033229,-39.02255093390259,44.454896974700006 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark06(-1.3267611965062704,-1.5707963267948966,-4.794036587204811E-94 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark06(-1.3268959137891585,-1.5707963267949054,-0.2574555758196293 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark06(-1.326963572413474,-0.17737804284547828,38.81001749553312 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark06(-1.3286621590375929,-0.9396855535434105,4.683424975516701 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark06(-1.3289661194864528,-1.5707963267948966,25.180396535354916 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark06(-1.329043434304601,-101.63368869176276,38.79401346681945 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark06(-1.3293509490825708,-8.673617379884035E-19,-47.27277548196103 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark06(-1.3294735985454034,-45.38721648333487,1.5707963267948948 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark06(-1.329547159346967,-1.5707963267948966,-127.38446783735202 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark06(-1.329666705005343,-1.1344829941136965,0.9264802118029967 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark06(-1.3302249319685817,-19.352179470364593,0.5841977381301547 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark06(-1.3306854026037247,-1.570796326399481,-31.6452447966213 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark06(-1.3313357872382916,-0.35351832003307526,-85.51958859463562 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark06(-1.3319983461951343E-256,-1.3496538008726184,-1.5707963267948966 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark06(-1.3320515659131371,-1.5707963267948966,52.622676862848955 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark06(-1.3340003025024743,-1.5554834122440104,-95.33936391008201 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark06(-1.3353096036840695,-1.5707963267948966,-59.52296205011724 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark06(-1.3362434153904634,-1.5707963267948948,-62.32348308126863 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark06(-1.3387419083910768,-88.34199699078134,1.6163181681781822 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark06(-1.3402684694814866,-0.3855406454771739,100.0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark06(-1.3406733030131741E-4,-1.570796047219667,-14.116310461717859 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark06(-1.3406852258781596,-1.5707963226508481,-74.51691128867918 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark06(-1.3413705856812435,-39.000178179388286,70.13410165085901 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark06(-1.3430608743300791,-31.5917046622466,82.56195332180361 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark06(-1.3474676802150225,-0.11767886247830818,4.7123890401036785 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark06(-1.347511409502794,-1.209649494526436,19.407167393192395 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark06(-1.3476596441628628,-3.1415926542179227,-66.93371506336506 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark06(-1.3477447291211886,-1.5707963267948966,-4.712411189227488 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark06(-1.3486051073675644,-1.3305828969793847,2.296855357952097 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark06(-1.3499045665298846,-100.92040499901876,555.4884936573831 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark06(-1.3517138182389767,6.455762415489155,-75.69698444042822 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark06(-1.3526694587978159,-1.5707963267948966,-91.97256336140353 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark06(13.526741513936827,3.490474516184676,-79.2667103219979 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark06(-1.3529121861866074,-32.44677313888918,45.55309245398741 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark06(-1.3535864361345586,-1.5707963240130416,1.5707963267948966 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark06(-1.3545154688128112E-23,-1.5707963267948966,-3.141592653589806 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark06(-1.3547925719798821,2.220446049250313E-16,-68.89076978236928 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark06(-1.3548663845203186,-1.5520357612828362,94.98062993674114 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark06(-1.3552527156068805E-20,-1.570793769098936,-1.5707963267948966 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark06(1.3552527156068805E-20,-1.5707963267948948,25.23815000684207 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark06(1.3552527156068805E-20,-32.983266012911734,58.501720167190655 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark06(-1.355874034129375,-0.07847988270037831,-39.279479865968774 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark06(-1.3565299266195012,-95.75295452811763,15.100479738283603 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark06(-1.3566466516167015,-1.5707963267948966,32.188512999349875 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark06(-1.3566642758087631E-166,-0.04725594077869564,88.62672418792056 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark06(-1.3585663559237648,-5.293955920339377E-23,-13.583730581621188 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark06(-1.3587686563812191,-1.2283518318053979,-16.084611866220342 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark06(-1.3607712167154171,-45.383165460565394,0.5922834638659987 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark06(-1.3612748389550022,-5.293955920339377E-23,21.834120291928038 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark06(-1.3613351460562373,-1.540190927543744,2.0707966914891136 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark06(-1.3616115598784186,-19.398506273793416,40.17363644662344 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark06(-1.3618523809324978,-19.376494395327654,52.07186375064207 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark06(-1.3627711302472068,-1.5707963267948966,3.141592653589793 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark06(1.3631294610917295E-16,1.321759460867296E-23,0.0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark06(-1.3633611913663988,-1.555710342795309,95.65681327937163 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark06(-1.3637163678490432,-1.5165281943168432,-26.655543623751917 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark06(-1.3651412340720936,-1.5707963267948966,0.15581191251072812 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark06(-1.3651532178830774,-45.21580822170742,53.22638014081892 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark06(-1.3653899477423392,-1.5707963267948966,-6.712389035795532 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark06(-1.3664375743262016,-0.2368719535765949,77.9809129003311 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark06(-1.3678360920949681,-1.5707963267948966,-488.34084824587114 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark06(-1.3699368539334613,-1.5707963267948948,0.29620875039892086 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark06(-1.3710428329824795,4.536760758853059E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark06(-1.371162235888551,-0.1870099137276977,1.5707963267948983 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark06(-1.372586734206944,-1.5707963267948966,95.5379402733051 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark06(-1.3726479340260662,-1.3473676672862305,44.010653624966984 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark06(-1.3727851888706095,-1.5707963207932552,6.140139144741958E-16 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark06(-1.374270248288538,-1.5707963267948966,0.0600603742693326 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark06(-1.3745029813270442,-0.5850831583873269,-100.5421752018728 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark06(-1.3747224461014134,-1.5707963263614195,0.0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark06(-13.751271942633792,32.72025802457716,0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark06(-1.3756974447733912,-0.9883482509770729,4.541350276558721 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark06(-1.3775369338555286,-1.5707963267948966,-59.691236983353825 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark06(13.782569399159968,68.32458978057733,-43.7388910204688 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark06(-1.3788992059768992,-1.5707963267948966,-32.3345471828509 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark06(-1.3798454726726794,-1.5707963267807532,-10.48043029807937 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark06(-1.3812799682199446,-44.32021262696374,-4.9448718384820864 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark06(-1.381621838219964,-0.5774431320302114,-165.43187140292181 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark06(-1.3825187414985873,-1.5707963267948966,14.21141548215104 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark06(-1.3832261657045163E-222,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark06(-1.3832261657045163E-222,-1.5707963267948966,-67.32557076770752 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark06(-1.3833130691501743,-0.0740118160076062,-47.74680403594276 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark06(-1.3835646359871874,-6.0834930121445114E-210,-5.0872454383053345 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark06(-1.3841264887265123,-0.1110019130113228,1.965472640269016 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark06(-1.384413861322228,-0.012429917609787497,-3.1415926285407134 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark06(-1.384587378213844,-8.881784197001252E-16,-49.25406039128224 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark06(-1.3850994240198262,-45.32992526282946,8.766496449339574 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark06(-1.385160152269248,-1.562702829513558,1.5707963267948966 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark06(-1.3855719794390025,-0.7405179381200341,-44.81990122193574 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark06(-1.386275693634352,-1.3877787807814457E-17,-18.510139898489072 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark06(-1.3867362362421462E-17,-1.5707963267948966,-53.40707511096695 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark06(-1.3869177226125906,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark06(-1.387087827694602,-101.89664953748735,140.9428967670952 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark06(-1.3874762084150276,-1.5707963267948966,88.87537790678506 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark06(-1.3877787807797752E-17,-1.5707963267948966,-65.97344553491278 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-0.704977629692805,1.5707963267948948 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark06(-1.3877787807814457E-17,-1.2874070821867933,-31.42174633711884 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-1.3662290772650547,8.506755122493391 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark06(-1.3877787807814457E-17,-1.5707963267919107,95.0686076487187 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark06(-1.3877787807814457E-17,-1.5707963267948966,1.5707963267950105 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-1.5707963267948966,44.237428782291566 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-1.5707963267948966,52.06044921635956 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-1.5707963267948966,-62.12605790724191 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark06(-1.3879087218295343,-0.9282878279872957,86.39399430477519 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark06(-1.388031094843039,-1.5227485678779593,-188.2506523269958 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark06(-1.3894798673998139,-0.2855957210160187,89.85516490835857 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark06(-1.389650726606888,-1.5707963267948954,0.0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark06(-1.3899378691013469,-1.5707963263550042,-45.477331312015615 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark06(-1.3904309498698724,-0.7958799830411056,-184.38197853961873 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark06(-1.390433476189941,-1.5707963267948966,-3.386448895594576 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark06(-1.3912533584374174,-94.34704846135028,44.43819572294541 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark06(-1.3920970524890883,-37.766886426454924,21.795579560377803 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark06(-1.3921495762252545,-1.456383624223023,50.610873830686955 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark06(-1.392233923984605,-1.5639289018804647,-74.52623460482451 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark06(-1.3949030783958412,-0.14342028266805773,88.27844713905705 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark06(-1.3953611719428307,-1.5707963267948966,-1.285519869692471 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark06(-1.3972458125961433,-1.4142386907181452,-36.656356338896515 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark06(-1.3972872557303537,-1.5707963267948966,-29.572412088169912 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark06(-1.3977666751393067,-0.43222569162036495,-1.5707963267948966 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark06(-1.3984406336078918,2.7755575615628914E-17,37.81735690226062 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark06(-1.3995449543415173,-1.5707963267948963,-36.12831551651268 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark06(-1.3999969732893902,-0.006682009963814451,95.63410495233649 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark06(-1.4020758144832546,-1.2402609262199782,-3.4928468199363722 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark06(-1.4024004776564192,-1.0330166749400698,4.930380657631324E-32 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark06(-1.4025462968202962,-1.5707963267948966,-1.5391915954849518 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark06(-1.402894035227431,-0.0799735212738924,3.1417424262634044 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark06(-1.4032928634226032,-1.5707963267948966,4.570189024901911 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark06(-1.4044818930713647,-0.8703956482437918,4.71578697464234 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark06(-1.404632883706578,-0.41965872498015816,-7.854014351707603 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark06(-1.4070833318486087,-1.1102230246251565E-16,-40.69638204965726 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark06(-1.4071063869112779,-0.24158981065794194,0.0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark06(-1.4079525603074226,-1.5707963267948966,-24.61841707061052 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark06(-1.408415087185547,-1.5707963267948948,10.20105931927995 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark06(-1.4088407314736535E-132,-2.8349437192156632E-15,99.0458939730492 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark06(-1.4089342699762806,-44.39220029861142,8.504863997426039 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark06(-1.4093441335370267,-0.2941286841316216,66.09008579864607 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark06(-1.4100857346685784,-3.1415926536145964,-50.24646392335579 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark06(-1.410432449545298,-1.3527321635908736,66.35174066217418 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark06(-1.4110388064493677,-4.004166190366202E-146,27.404977094826155 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark06(-1.4110759562254216,-0.9662125906983027,47.1395323365701 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark06(-1.4115162219753166,-1.5707963267948966,61.58777967567566 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark06(-1.411886606376814,-38.75350204135341,1.5707963267948912 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark06(-1.4118925311367019,-0.9869506654930044,-70.57524828296192 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark06(-1.4142505872886346,-0.39112396610522415,-1.5707963267948983 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark06(-1.4149498560666738E-73,-0.635542063301628,1.5707963267948966 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark06(-1.416233856352739,-45.405146409862354,71.45632812414685 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark06(-1.4174871698216642,-1.5707963267948966,-8.104128321776358 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark06(-1.4175754232161546,-1.5707963267948966,-63.33296477294504 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark06(-1.4180490148377443,-1.5707963263889475,64.81770380730006 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark06(-1.4189686285195768,-1.263104107555081,13.805788030498487 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark06(-1.419780860958992,-0.6737210892621239,1.5707963267948957 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark06(-1.4210854715202004E-14,-1.5707963267948912,-128.74818453026117 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark06(-1.4210854715202004E-14,-1.5707963267948961,72.05286801193469 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark06(-1.4210854715202004E-14,-1.5707963267948966,-10.855735776608327 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark06(-1.4210854715202004E-14,-45.03270284802888,77.3888299795642 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark06(-1.4212127314548262,-100.83445336293754,0.1856358595380223 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark06(-1.422372334163171,-0.911178839464885,76.93239932959031 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark06(-1.4225655996704496E-160,-1.16502318208628,-26.50687615880819 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark06(-1.4225655996704496E-160,-1.2755982358465998,-32.57547942858038 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark06(-1.4231476293597467,-100.877325664521,2.5079439447084644 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark06(-1.4235389153762215,-39.26068149322619,51.3442463482217 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark06(-1.424193563603444,-6.497131103528062E-114,-1.463820794752338 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark06(-1.4244745776023198,-0.1171821214661494,-95.8242448424697 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark06(-1.425082743797161,1.734723475976807E-18,59.842699805859155 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark06(-1.4255058455791656,-31.80037933203025,26.9934528059632 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark06(-1.4263959179288301,-1.5707963267948948,45.76557617170275 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark06(-1.4279810333071463,-38.94395305869287,116.05633965067506 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark06(-1.4282216494172653,-1.5707963267948966,51.2490787545919 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark06(-1.4284705367771333,8.57568247816204E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark06(-1.4287342391028437E-101,-1.3832549816309296,98.85150568477393 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark06(-1.4289284976580996,-44.473858551925474,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark06(-1.4293037187669382,-31.675301385305687,26.76332938655674 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark06(-1.4294687121714653,-45.08614270950737,15.01526523461779 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark06(-1.4296747315423404,-1.3676269997729678,-0.03204020102733567 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark06(-1.4297750632967696,-1.5707963267941616,-570.4816930134873 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark06(-14.30145491329688,-51.20509311486365,26.507641432961776 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark06(-1.4310848040577806,-0.5499156235964694,52.39368938518217 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark06(-1.431375667251354,-0.9714983797015053,46.7407568242243 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark06(-1.431551691846605,-0.0060867158916582485,-4.482207629707268 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark06(-1.4321951002689084,-1.5707963267948966,-77.06088317888643 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark06(-1.4325141543412974,-1.5707963260204074,1.6452950795406824 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark06(-1.4337309990067344,-0.026617672610273087,88.28949433033793 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark06(-1.434811963920166,-1.5707963267948966,61.22805931300968 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark06(-1.4350017355936722,-0.4392827270501972,88.08965406551255 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark06(-1.4356397224511737,-38.718174771295274,-10.995696459838701 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark06(-1.4358463673541682,-0.5492297075266839,71.85909039615487 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark06(-1.4369854224055127,-1.5707963267948966,-66.89361898184308 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark06(-1.4370392833042573,-1.5707963267948966,4.653160026112473 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark06(-1.437310867940747,-1.553239135852881,-52.61815235223486 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark06(-1.4373311125832535,-1.4510201808765326,0.0 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark06(-1.4378757518986962,-1.2984683772392358,-1.5707963267948966 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark06(-1.4380587108656808,-1.5707963267948966,33.85845762546188 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark06(-1.4384865271859315,-0.7213488929439458,-23.719425528819972 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark06(-1.4385835930649278,-1.5707963267948912,39.19130927112721 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark06(-1.4390069352908883,-0.5033790498847539,-6.131821106122786 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark06(-1.439486309015217,-1.5707963267948966,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark06(-1.4398780065497325,-43.982657823722974,1.0990269204655334 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark06(-1.4399646811018165,-1.5707963267948966,40.5090488308113 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark06(-1.4407764402338026,-1.5707963267948966,-9.757596172396902 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark06(-1.4411018847749055,-1.5707963267948983,-568.055608568701 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark06(-1.4412683290233745,-1.5707963267948966,-3.1415926319599614 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark06(14.429220180808514,0.0,21.453198675244007 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark06(14.430373786414009,-3.502651805864867E-17,-41.83521730394584 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark06(14.434867412926188,0.0,-117.47104375742718 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark06(-1.4434868062038144,-1.5192367491748835,-2.299989715902037E-15 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark06(14.436265665950032,0.0,-2075.4228919995703 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark06(-1.444810960638749,-0.7999079645875304,42.45673128195087 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark06(-1.444920435056734,-1.1390361077667583,45.49355790344916 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark06(-1.4449390461679172,-38.86503561360702,75.55098583258552 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark06(-1.4461547740907577,-1.570796326794893,17.34375343848886 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark06(-1.4462077364426777,-95.81415455119583,64.47856395719026 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark06(-1.4462908193846629,-45.36417780605767,72.25397443313793 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark06(-1.447393113715547,-1.0930310230380869,17.505763910866968 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark06(-1.4477497726977373,-1.5707963267948948,-11.227461544347227 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark06(-1.447793868084016,-0.1946847067698102,-3.1415926535897967 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark06(-1.4479224474810921,-0.423266572692813,1.5708453027301603 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark06(-1.4494809641128574,-45.3754760012147,47.11408524913351 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark06(-1.450198150628031,-0.01730640631105862,-1.5707963267948966 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark06(-1.4502087989788497,-32.45260187484351,-18.84955592153876 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark06(-1.450237099605077,-88.41171244820406,3.1415926535897967 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark06(-1.450360159567517,-1.2392294127517818E-119,69.74007087923466 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark06(-1.450671519120807,-0.03812173184483769,-1.5707963267948966 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark06(-1.4509676114544967,-0.27771094144015374,-67.40970204813594 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark06(-1.4510763787739773,-32.92468914277427,133.65343830697276 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark06(-1.4512099040853677,-1.5707963267948966,-97.40761518637083 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark06(-1.4516191344271758,-0.026092565988308114,0.4859143512429298 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark06(-1.45220669541301,-1.5707963267948966,42.111887396754156 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark06(-1.452446450547995,-31.730196831134478,0.0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark06(-1.4524658610869357,-1.2073996435116556,9.59826702941045 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark06(-1.4529788359558484,-1.1840220525567418,-1.339769858261619 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark06(-1.4538983459829649,-4.0756248648691643E-16,1.5707963267949054 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark06(-1.45432371869515,-1.5707963267948966,-103.28083191087046 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark06(-1.4552605429411773,-1.5707963267948948,98.65613587935954 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark06(-1.4553765286824725,-31.87752785421553,1.5707963267948983 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark06(1.4558645066955052,39.4619363347538,-31.23574892935237 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark06(-1.4566440878101188,-0.3179801804669296,360.9300956470648 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark06(-1.4567071740625404E-157,-1.5707963267948966,-12.700188859918413 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark06(-1.4571319148564186,-95.68366244296189,19.40032608739797 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark06(-1.4573759161612667,-1.5707963267948966,-1.5707963267949037 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark06(-1.457580735267383,-0.9494717117829262,93.63372252787846 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark06(-1.4577854348559063,-1.5208902492510123,1.578608826806054 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark06(-1.4583136038112627,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark06(-1.4588351052075808,-0.5176506101291443,-4.838530258668886 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark06(-1.4610181621464569,-1.5707963267948966,73.29953722440126 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark06(-1.4610334330360177,-1.5707963267948966,-15.088188745720773 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark06(-1.461220331078699,-1.5707963267948966,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark06(-1.4616600257536139,-95.70748901685305,95.77165635373895 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark06(-1.4619661065883265,-1.5707963267948957,6.7124930171954285 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark06(-1.4621445975216196,-1.5707963267948957,-50.06044259505087 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark06(-1.462365638435371,-0.9587248070635981,-60.95197912879492 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark06(-1.4626007410843098,-1.5707963267948966,3.26659265376369 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark06(-1.4630726301113317,-1.570539840237307,163.56543636004682 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark06(-1.4644895972394163,-88.13454713929802,-4.745131778398812 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark06(-1.4656909763309285,-1.5707963267948966,51.78673473585707 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark06(-1.4658718500504706,-3.1415926536222303,-65.5807216920448 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark06(-1.4662092824662305,-1.5707963265237102,-27.45617623691354 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark06(-1.466612066298541,-1.5707963267948966,-1.514727439271951 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark06(-14.68416695386668,-31.860675467051777,-30.880441940606744 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark06(-1.4686932868643294,-1.5707963267948966,-3.266592653596003 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark06(-1.4687574336012865,-45.266075454620704,304.5771143859475 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark06(-1.4688512919474317,-1.0407334804499158,5.141598127424192 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark06(-1.4695846958510377,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark06(-14.702683167354763,13.498648566971383,50.28578843017934 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark06(-1.4702836309800782,-45.21994842214412,95.59912273746559 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark06(-1.4713199143443796,-31.44302926553628,1.5707963267948983 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark06(-1.4722644402255007,-1.4105004446312566,0.23115846917575195 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark06(-1.4722886122347318,-1.5707963267948966,-99.4568937918761 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark06(-1.473370575863181,-39.00756687608424,14.643771454290045 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark06(-1.4738615235628707,-38.718876651309785,0.0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark06(-1.473966434528727,-1.5707963267948966,182.2356035749258 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark06(-1.4747231338829236,-44.15166695533582,1.7159165533586118 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark06(-1.4748826715690297,-1.5707963267948966,36.2344799822527 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark06(-1.4752393931043324,-1.5707963267948966,-30.327126716689445 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark06(-1.4760812638801362,-1.0940407283905416,1.497622159760662 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark06(-1.4764618394584101,-1.5707963267948983,181.38137462059157 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark06(-1.4765364727692267,-1.5707963267948966,4.837388980385146 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark06(-1.476804669568627,-0.7316310592573646,43.09870553390097 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark06(-1.4768879809832445,-0.43716843443707454,54.75919418094929 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark06(-1.4769162188915272,-1.5707963267948966,1.3646407111666248 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark06(-1.4772321541511673,-1.193207394661742,81.46561851751605 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark06(-1.4772744683623327,-0.9185943167145578,-56.606471069154864 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark06(-1.4772765788457177E-126,-8.364993718536928E-30,19.59431515928176 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark06(-1.47744017607525,-1.5707963267948966,-77.54427951731746 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark06(-1.4775899276850741,-0.2981431212812243,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark06(-1.4776548460214953,-8.881784197001252E-16,-1.4948230703504466 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark06(-1.477914945651878,-0.8297195328849332,1.5707963267948966 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark06(-1.4791564468634721,-1.5707963267948983,-1.5707963267948983 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark06(-1.479332866515672,6.712388980420525,1.5707963267948948 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark06(-1.480002142785388,-1.5707963267948966,-3.141592653589794 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark06(-14.801526215220619,-51.19429051247142,65.17315461045519 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark06(-1.480292496036368,-0.29021121238217124,-50.74338099642317 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark06(-1.4805638447796359,-1.5707963267948966,88.81014985084406 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark06(-1.4809474120054196,-0.6633401719110965,-12.007950948411604 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark06(-1.4815014760588952,-1.5707963267948912,0.0 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark06(-1.4821687256617193,-3.4741381373240554E-7,-7.861794164356412 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark06(-1.4828751809275,-1.5707963267948966,14.89007595011127 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark06(-1.4830821203402176,-0.3341118881068028,-17.96060358720101 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark06(-1.4831268596924787,-1.5707963267948966,-52.37952140280833 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark06(-1.4832431423339916,-2.710505431213761E-20,83.02894530300668 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark06(-1.4833074403689193,-3.1415926535933205,-1.5707963267948966 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark06(-1.4833384889995773,-44.45693627790985,64.45189238457495 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark06(-1.4833969564157703,-88.46011833093839,1.5707963425419476 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark06(-1.4837079214207989,-1.5707963267948966,-30.354284443339168 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark06(-1.4841521366373922,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark06(-1.4842073998553167,-1.0562723241783447,4.712396854223889 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark06(-1.484628563513263,-3.1415926535996386,-13.541002469209062 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark06(-1.485252967951361,5.421010862427522E-20,-26.267038007093355 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark06(-1.4869342197003184,-0.02164540798751169,79.88896924679221 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark06(-1.4899011018833463,-45.0157160272445,15.065221907364403 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark06(-1.4900238212475259,-19.40257180225572,0.0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark06(-1.4903515013892157,-1.5707963267948957,-5.481541094221392 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark06(-1.4911980896608021,1.3552527156068805E-20,6.766592707167719 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark06(-1.4913481014022278,-0.5312694057928253,-45.004392664883426 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark06(-1.4917665935322424,-1.5707963267948966,-4.7436390512035365 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark06(-1.4927743480751317,-1.0099857976321296,-96.24295326997684 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark06(-1.4927933216348996,-31.9292320704362,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark06(-1.4931112504229018,-0.81160324895926,-83.77862690172253 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark06(-1.4938871568469323,-0.3872721991672883,32.569099137281796 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark06(-1.4944569498942395,-31.56257175457877,39.93085788347099 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark06(-1.4946267787512735,-1.5707963267948966,-81.07500898789593 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark06(-1.49471391749637,0.32045804610272055,-1.5707963267948941 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark06(-1.494932729327638,-5.421010862427522E-20,12.268012099838128 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark06(-1.4952821735782489,-37.86420619757956,27.61377047666562 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark06(-1.4969355915143782E-12,-1.5707963267948966,14.998042849532917 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark06(-1.4970955403947857,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark06(-1.4976888875820338,-1.5707963267948948,-92.82832023092651 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark06(-1.4980304139738008,-0.37469205858474064,5.428067521459239 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark06(-1.4983592898653884,-1.5707963267948966,72.97504098194318 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark06(-1.4993574413077302,-1.5707963267948966,0.8109216117753797 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark06(-1.4998095938603342,-0.006818812232075197,17.76703677535739 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark06(-1.5002401149739228,18.84955592153876,1.4982421209814762 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark06(-1.5002577091805573,-0.46137240295758963,489.04964466299646 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark06(-1.500507831332415,-39.016181438894364,64.28827410474463 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark06(15.0054416980622,-0.28263217304038335,-53.951924016848075 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark06(-1.5008564143605596,-45.13768235982487,3.141592653589651 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark06(-1.5012865531197737,-1.5707963267948966,-589.0300721805758 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark06(-1.501554194253717,5.551115123125783E-17,-3.956049273233049 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark06(-1.5016675613635981,-1.082496493673055,1.5707963267948963 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark06(-1.503257882560066,9.860761315262648E-32,-42.879892389293005 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark06(-15.035648583312721,-26.933742017902617,-90.11504784934318 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark06(-1.5041236407958536,-1.5707963267948983,59.55232067847888 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark06(-1.5046401830387786,-1.5707963267948966,1.5709163107150863 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark06(-1.5047031058563913,-1.5707963263796874,-100.0 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark06(-1.504995309042492,-0.14310805141882127,-0.5358119068980371 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark06(-1.5053845942816737,-1.5707963267948966,-34.49252401564256 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark06(-1.5057876912122143,-1.109276022034368,43.5168124847194 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark06(-1.5068490556687335,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark06(-1.507331027608501,-1.0135432583088004,164.93352572200644 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark06(-1.5073319743632705,-1.5707963267948963,5.103466912287615 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark06(-1.5074288549898116,-31.772441012132077,-6.712388980795315 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark06(-1.5076374535425345,-1.235164922443963,-95.35890893499375 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark06(-1.5077552605486393,-0.39225016063535323,16.72978031662278 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark06(-1.5080048116819311,-5.3510970434775465E-197,74.0074959795534 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark06(-1.5088931585362313,-1.5707963267948966,7.853981634300917 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark06(-1.5091595704848988,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark06(-1.509605445634345,-4.0607069397050388E-115,-49.17871664442492 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark06(-1.5098784961251785,-158.18807615900477,32.83418216382469 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark06(-1.510095115581609,-3.14159265375984,0.0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark06(-1.5101543670163626,-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark06(-1.51035829045966,5.141592653590168,59.43504835008895 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark06(-1.5104872429933491,-1.5707963267948966,-62.03062458425639 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark06(-1.5105469166931256,-0.7127102514063441,85.09014284458496 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark06(-1.5112680682895518,-1.493213989947081,1.591956645868963 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark06(-1.5118548384715567,-44.475774279313775,0.808615452123057 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark06(-1.51251624969854,-1.5707963267948966,-49.33719290165998 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark06(-1.5125760262433965,6.7123889803846915,69.22011041070073 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark06(-1.5131413859802105,-45.17731200636898,95.45245020290591 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark06(-1.5132074921867054,-1.5707963267948966,44.24771052669132 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark06(-1.5132454797920132,-0.4577830086394194,-21.355341533972375 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark06(-1.5133467502658042,-1.5707963267948966,-13.894250217069038 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark06(-1.5133906639704462,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark06(-1.5135312320541552,-3.141592653589815,9.624894736165615 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark06(-1.513559074275266,-0.8567647179751162,-46.046169924362054 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark06(-1.5136651420464275,6.740352119731472,1.5707963267949054 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark06(-1.514963340905771,-1.5707963267948966,-4.8373889803851196 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark06(-1.5155922587337491,-1.3234436743520401,486.77094583848293 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark06(-1.516630420244832,-0.4362304493189555,6.489968124661925 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark06(-1.516753132763236,-1.5707963267948966,-77.42419002024369 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark06(-1.5171955214609998,-1.3752988735479619,-55.45908757659092 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark06(-1.5176271578385607,-1.524605820310577,-82.57838556310404 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark06(-1.5176396394395981,-1.5707963267948841,1.62122329796604 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark06(-1.5177594775304808,-1.5707963267948966,-1.5707963267948974 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark06(-1.5178085479551384,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark06(-1.517847731662991,-0.14494039825308558,-39.19200390538327 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark06(-1.5188121493309779,-1.5707963267948983,-49.30976977088321 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark06(-1.5190098526120923,-1.5707963267948912,55.37374228562331 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark06(-1.5191317109664697,-0.7646820664212552,20.420363679681742 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark06(-1.519853310767076,-38.87231033425289,8.055817058525761 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark06(-1.5199772637950155,-88.39689292005957,3.1415926535897953 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark06(-1.5203344913883499,-1.5707963267948966,19.1011407830848 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark06(-1.5204032690216607,-1.5707963267948963,3.1416426378928066 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark06(-1.5206958046996606,-0.4974931878353708,42.749868559625725 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark06(-1.5207169886366745,-1.5707963267948961,0.7502289852341344 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark06(-1.5207908169282636,-1.1726784043257348,3.1416243801512174 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark06(-1.5209378321560223,-1.5707963267948966,49.79127334509472 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark06(-1.5212074102915605,-1.5707963267948966,73.74341602491567 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark06(-1.5225798906140164,-1.5707963267948761,5.737335572005593 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark06(-1.522901828751145,-0.4475102197611225,5.293240243438333 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark06(-1.5229273346570225,-1.5707963267948966,58.048647666178034 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark06(-1.5230941158385898,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark06(-1.5243599386625821,-0.22348033818092766,-3.141592654200298 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark06(-1.5244497071960406,-0.39538726843132305,49.88837772143056 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark06(-1.5252874725397212,-1.5707963267948966,-88.77213461697815 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark06(-1.525897955734838E-17,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark06(-1.527137824142614,-95.36535075924543,-4.837388980384691 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark06(-1.528017347376808,-1.4640095732770098,-107.69345446073584 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark06(-1.5280457428261252,-37.69949987041868,1.5707963267948963 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark06(-1.5282109314540493,-1.5707963267949066,83.40696580551824 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark06(-1.5286890038311973,-0.20888420609312902,14.137167189841055 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark06(-1.5290993012292395,-1.5707963267948966,-86.85002221595568 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark06(-1.5291053821872505,-1.5707963267948948,-59.03286851984762 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark06(-1.529398064028876,-1.5707963267948912,-36.532860746896056 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark06(-1.5294102076217801,-0.5194219057395079,39.15510648092578 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark06(-1.5295927059254735,-1.5707963267948966,75.87304658815621 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark06(-1.5299950611076512,-1.5707963267948963,38.75485188666338 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark06(-1.5308761099778554,2.7755575615628914E-17,-0.9195083797568124 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark06(-1.5310704935577242,-94.2881246610068,88.37204964699086 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark06(-1.5314287277573253,-1.5707963267948966,50.26548428120623 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark06(-1.531506130262069,-32.965790431797174,133.57802943535611 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark06(-1.5336772827695532E-15,-1.5707963267948966,-1.571772889294898 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark06(-1.5337099681254163,-0.8246319097835871,-1.5707963267948966 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark06(-1.5339481104620585,-7.888609052210118E-31,1.574771442611618 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark06(-1.5347547801004293,-1.5707963267948966,-43.89344833701984 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark06(-1.5364421147057548,-1.5707963267948966,-0.3505234216767601 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark06(-1.5375466372079045,-1.0189648122900363,-3.1415927204657907 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark06(-1.5379767611236606,-1.5707963267948344,-67.27641344556594 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark06(-1.5384118106798184,-157.44438918857526,1.329569128210835 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark06(-1.5387940087034355,-1.5707963267948966,19.420255994490745 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark06(-1.5392417244977563,-1.548634984584297,-32.91473911777871 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark06(-1.5392613490406593,-88.31365684132882,153.099392476069 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark06(-1.5395428050813247,-1.5707963267948963,-93.51655349110641 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark06(-1.5395617543431739,-3.9484127069845653E-177,37.89680236712247 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark06(-1.5399005242161092,-1.5707963267948966,29.331233817433095 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark06(-1.5399589910989884,-1.5707963267948966,1.5707963267948974 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark06(-1.539990006884413,-1.5299871773255447,-10.944290268717879 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark06(-1.5402986815954653,-1.045612830409526E-15,45.804401691824964 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark06(-1.5410066449219793,-88.38646926776886,61.22075257621718 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark06(-1.542156463100894,-3.217223493417518E-86,72.35045558328002 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark06(-1.5427726274059639,-1.3938217430942594,1.5707963267948966 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark06(-1.5430573551253317,-45.07896318152912,84.36935065532444 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark06(-1.5435237469210163,-1.5707963267948966,67.135881490093 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark06(-1.5441298842296383,-2.220446049250313E-16,3.2665927207104835 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark06(-1.5444751091781463,-1.5707963267948966,4.712389133212057 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark06(-1.544875009560536,-1.5707963267948966,-3.141592654265688 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark06(-1.5450720177303616,-44.08793187409936,1.5707963267955876 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark06(-1.545568798964082,-0.8787545434197699,-10.99959925059462 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark06(-1.5456548702463666,-0.8297837834713128,0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark06(-1.546134788246849,-1.4891573688442639,4.712397108658961 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark06(-1.5463001810968533,-0.12029749264323963,-1.5707963139634586 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark06(-1.5463215498232574,-0.4886781105928946,-1.5707963267948968 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark06(-1.5469109394165437,-1.5707963267948966,64.55752633887266 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark06(-1.5479831223697618,-6.533615967282663E-16,4.743638980384694 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark06(-1.5484761560037297,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark06(-1.5485603884393129,-33.62467834582483,0 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark06(-1.5488670671332248,-3.1415926544299193,0.9394201522072922 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark06(-1.5489496676915555,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark06(-1.54901910389182,-1.5707963267948966,3.2665926542436785 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark06(-1.5493692742156,-1.5707963267948966,-26.869696696052813 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark06(-1.5500666705528097,-0.09369856810087039,-1.5708028115991224 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark06(-1.5507490963678734,-1.5707963267948966,-55.689193894462605 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark06(-1.5507839708376043,-44.46413794617362,2.5707957394122123 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark06(-1.5510311404430277,-45.3943491500072,1.5707963248448005 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark06(-1.5510397558230689,-1.5707963267948963,-2.7504720535904905E-15 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark06(-1.551243772664018,-0.22845614328813607,-71.25326875677834 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark06(-1.5515070971285954,-1.5707962241396187,10.957627813829982 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark06(-1.5518039446940537,-1.5707963267948966,39.633763493824375 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark06(-1.5519811961499101,-0.18311438747060935,51.28979205177233 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark06(-1.5523399307559764,-100.98231740864233,1.5707963138099805 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark06(-1.5524771215802244,-1.5707963267948966,81.17788479171975 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark06(-1.5530059548111714,-1.5707963267948966,-27.05535198226458 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark06(-1.5530269516088193,-1.5308857678888934,-99.59025497555753 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark06(-1.5530458415957968,-100.53191300151856,7.810606176995451 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark06(-1.5531648464988963,-0.3101767484406458,-23.79276604444074 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark06(-1.553325014829598,-1.3479825134335022,100.0 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark06(-1.5533829654519098,-1.5707963267948966,2.5243548967072378E-29 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark06(-1.5539327190603887,-1.5707963267948966,-78.13126186025896 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark06(-1.5543415564997338,-2.1684043449710089E-19,0.18306448396096187 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark06(-1.5543850404807662,3.469446951953614E-18,1.5707963267948966 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark06(-1.555162711891312,-1.5707963267144571,13.487776481041449 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark06(-1.555521995881919,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark06(-1.555729243560135,-1.5707963267948963,1.5707963267948966 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark06(-1.555730109611091,-1.5707963265404368,54.05925434432416 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark06(-1.556198163328949,-45.194551807113534,0.68514977825342 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark06(-1.5563229337868132,-284.3129789635448,39.20595703310264 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark06(-1.5566082845747484,-1.2558904570897893,18.560832937910504 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark06(-1.5568726111217905,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark06(1.557239354198316,-20.368086722353,53.75479934924101 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark06(-1.5578781917906543,-31.420766845415265,63.89730320377032 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark06(-1.55801777192676,-44.32229805402977,64.6328239399924 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark06(-1.5581041853910502,-7.514819092824632E-4,135.0715423574369 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark06(-1.5581783599700738,-1.2964903674399453,69.07379673674276 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark06(-1.5585593205075885,-1.4015003627512006,-24.22403707348333 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark06(-1.5587803224515564,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark06(-1.5588181149556717,-0.03917861753455365,-181.22728646447428 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark06(-1.5589558320116574,-1.429401698293388,0.0 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark06(-1.5589640580306805,-1.5707963267948966,51.91231979142833 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark06(-1.5592773812256975,-1.5707963267948966,-91.7259184670232 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark06(-1.5594131618216867,-1.570796326792953,-32.047742874896635 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark06(-1.5596408986074415,-1.5707963267948966,-70.72350164333126 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark06(-1.559818766982139,-1.5707963267948966,0.6624268266034479 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark06(-1.5599007918241565,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark06(-1.560212192133772,-0.5440786154163743,1.5707963267948966 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark06(-1.5607652216899757,-0.7821708720641317,-100.0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark06(-1.5607792728356928,-1.2651541211840183,62.06345024923601 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark06(-1.5610982545355794,-1.5707963258047974,1.6072602055252858 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark06(-1.5611250067935778,-1.515255361514639,-51.35651678454061 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark06(-1.5612354525083705,-0.04777795266106556,-61.605834334789435 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark06(-1.561333744118822,-1.5707963267948966,-16.137167133387575 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark06(-1.5617433637662559,-0.39825585671619024,65.74688566177576 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark06(-1.5618932604871518,-0.7008594345377486,-16.76244815669969 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark06(-1.562119331940238,-0.12732128527375802,-1.5707963267948983 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark06(-1.5624588417883336,-1.4309050978859947,22.565813642967278 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark06(-1.562611468211649,-6.264602149855431E-163,0.0 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark06(-1.5629448632803502,-44.383608388335524,1.5747025767994665 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark06(-1.5630738348828361,-3.9484127069845653E-177,-1.5707963267948966 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark06(-1.5635091079346528,-1.232595164407831E-32,0.16014024331878116 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark06(-1.5636426298341148,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark06(-1.563713101118977,-1.5707963267948948,468.0939668035024 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark06(-1.5641086725506015,-1.5029616968862114,97.50061297925197 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark06(-1.5646755169068793,-1.5381973024476987,55.76616147535064 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark06(-1.564848071189979,-0.12889454645980802,-1.5707963267948966 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark06(-1.5652469543661747,-1.548660582983007,42.98868852283055 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark06(-1.5653302207529163,-0.1818815215237023,-1.5707963267948966 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark06(-1.5657088667767383,-1.4672780516999808,-1.5707963267948968 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark06(-1.5657621727588993,-1.0261702386839584,-100.0 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark06(-1.5661516753584153,-44.28257302912545,21.976470593430136 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark06(-1.5664055657573994,-94.31519382308545,2.3898381924545657 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark06(-1.5666017254733449,-1.5707963267948966,70.18261289052396 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark06(-1.5667856689942967,-1.5707963267948966,9.103609460922856E-14 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark06(-1.5669373287678203,-0.1321162146942138,68.90069235428689 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark06(-1.5669900668375936,-0.7988531929667987,89.66285100017464 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark06(-1.5670740849186715,-164.37843829561166,114.37581004861043 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark06(-1.5671395380453959,-31.415926537067644,63.56075686137524 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark06(-1.5672254586583647,-1.0039574918854585E-5,97.39250546899987 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark06(-1.5673046662183923,-32.611979490496786,1.5755360468531368 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark06(-1.5673428897117294,-1.5707963267948966,1.235222695679643 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark06(-1.5675034951481934,-101.73744014767436,170.64689574319834 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark06(-1.567745899591759,-88.18174122116606,1.5747025800459962 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark06(-1.5678547381728438,-1.5707963267948966,-57.30063113576132 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark06(-1.5678666994386476,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark06(-1.5679271284266632,-0.5557362659314795,-14.549960497482386 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark06(-1.5679689235917513,-5.230068772886145E-4,20.804636424727704 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark06(-1.5680168534806365,-1.569134134368529,-100.53096703599789 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark06(-1.5681464955807904,-89.95390502169799,83.24529824934916 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark06(-1.5681483245122427,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark06(-1.568271050774602,-1.5707963267948966,1.5707963267948912 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark06(-1.56844812688951,-32.67662727724553,1.5707963267948961 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark06(-1.5685972139130886,-0.1741246713477218,31.559373688403902 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark06(-1.5687114320141884,-1.5707963267948966,-61.85788670715484 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark06(-15.68947576466229,-14.080014824799704,-10.307626227526939 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark06(-1.5690441018683194,-2.7755575615628914E-17,-65.06039768380803 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark06(-1.5691335706312028,-1.5707963267948966,-1.2014002993707384 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark06(-1.5691854212498667E-11,-1.5707963267948966,1.3467009608948544 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark06(-1.569415150138492,-1.5707963267948966,1.570796319389542 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark06(-1.5694213529305194,-101.92260167777505,63.94763289277384 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark06(-1.5694236651817233,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark06(-1.5695084435514552,-100.81098604545343,323.0115136717917 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark06(-1.5695836659603557,-0.8609035139599353,31.416143815997014 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark06(-1.5696206145338485,-0.46164691059690544,54.400342031473436 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark06(-1.5696546098918789,-1.5707963267948966,-22.09820451870845 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark06(-1.5696796838481175,-1.5707963267948966,8.877164402474946 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark06(-1.56976701562675,-1.5706836635470385,-94.24773976355289 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark06(-1.5698329051434556,18.857370299715416,0.751816601494519 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark06(-1.5700180123181497,-1.5704427394367295,163.5986162865663 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark06(-1.5701393837993312,-0.2221595344622514,1.5707963267948966 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark06(-1.5701408962623524,-163.38804085493373,9.280881728399892 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark06(-1.5701579841198952,-3.141592653674226,-1.213208753756522 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark06(-1.5701705942690272,-1.5707883365578919,-201.11990665385093 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark06(-1.5702914267633128,-0.002948600623217544,-47.03827173841776 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark06(-1.5703036045600982,-157.0885601886643,0.6937164085220786 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark06(-1.5703332361259428,-3.141592653589794,-32.25752442453236 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark06(-1.5703396762351258,-1.5707963267948966,-121.9068765484978 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark06(-1.5703773585547984,-100.53118016984789,72.14081790761804 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark06(-1.5704717040586988,-5.12800419870159E-7,-2.5678648568081233 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark06(-1.5704937707585132,-45.545670888641425,31.97935703869692 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark06(-1.5705182552949524,-1.570745171788439,18.849640604451903 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark06(-1.5705547890584524,-1.5707963267948932,-99.44703662255971 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark06(-1.5705585462956275,-0.9228378603379652,77.02382657989932 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark06(-1.570600424470302,-38.95141497682614,88.52019997888156 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark06(-1.5706042071879383,-1.5707963267948966,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark06(-1.5706384651229424,-1.5707963267948966,18.861659634015673 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark06(-1.570667346188322,-1.5707963267948983,-363.0570366531282 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark06(-1.570672237707689,-0.5539942980348754,15.63791626913704 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark06(-1.5706886505373003,-39.26990251470913,6.31220554282869 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707139438538946,1.9721522630525295E-31,-14.428711166729286 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark06(-1.57072671297928,-4.3368086899420177E-19,-91.1053438549995 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707274179071433,-1.0098134960126538E-4,110.21645355659183 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707317684416793,-1.5707795294015792,-31.986445710484745 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark06(-1.570752101502093,-6.938893903907228E-18,72.24460307111633 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707603412909468,-1.5707963263410605,-100.0 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707617035372108,-3.644096233277846E-18,9.427122552996961 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark06(-1.570766153871012,-45.552835137520475,44.532430044957806 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark06(-1.57076940750516,-95.81765388872962,213.63276447934538 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark06(-1.570773119238408,-163.3823167350183,58.1193833031378 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707762928240703,-1.6940658945086007E-21,-3.141592653589793 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707764362963033,-1.5707963267948966,25.13247663180119 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark06(-1.570776582436216,-2.4279492112061713E-4,84.79344757254837 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707817146781862,-1.5707218840845727,238.60947050838854 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707862153575394,-44.262742127001786,0.5356859987432726 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707862652374296,-94.2497354222225,3.140553361974019 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707865764698916,-1.5707963267948966,-56.548551153146015 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707874195431608,-1.5703046908199179,-25.202504971456754 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark06(-1.570789148525223,-1.5707963267948735,-56.5481054993891 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707891944997607,-1.570699994928129,43.23274059905008 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707909964123705,-158.16102896052246,190.32117554762127 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707913578805777,-1.5707963267948968,4.712450015540941 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707916846927397,-1.903882414608765E-9,-15.707802094391798 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark06(-1.570793552700779,-1.5707522114637815,-31.388823575593563 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707940157647649,-6.776263578034403E-21,58.108032081174905 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707942284572938,-7.888609052210118E-31,-28.278271914500092 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark06(-1.57079494438549,-1.5707963267948961,100.52878601685867 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark06(-1.570795368366174,-3.552713678800501E-15,47.130390163788526 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707954978042615,-201.5729163781473,52.137511836237806 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark06(-1.570795609437941,-1.5707963267948966,-14.160513743356075 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707956858629148,-1.570796094304441,0.0 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707956983261415,-1.5707963267948906,138.08027582335566 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark06(-1.570795856619203,-0.02671307786463245,-164.92819795522888 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707958973525338,-43.98229715646077,39.26510242470624 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark06(-1.570795954305329,-1.5707963267948966,-99.39459748830811 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707959602477242,-1.5707963267948966,100.53090587266848 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707959875821444,-1.5707963267948966,-53.94077330908539 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707960283450102,-1.5707963267948966,-99.96023777319863 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796033423685,-95.81789910845659,0.0010143748038962054 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796071225026,-1.5654740356578698,-43.84962768430424 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707961751391148,-3.469446951953614E-18,-1.5707963267948963 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707961867822862,-1.3307580970228883,-32.885508911545166 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707961877737606,-7.224091858296628E-10,-40.83929736308825 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962040362855,-1.7763568394002505E-15,70.67928362049948 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796210637932,-3.056698759410089E-5,34.57326848387051 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962141674572,-1.9470057459198813E-7,-53.65916765541998 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962322639468,-0.6730584462028353,139.28395059974935 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796234699271,-1.1535130752259735,100.66278845063815 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962424875654,-1.8111358157653425E-71,11.211667343964619 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962631617063,-1.5707959692514695,0.0 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962666980768,-0.5019693194704633,-68.73346312186725 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962794833248,-1.5707963267948966,37.51071290164482 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962830478277,-1.5707948685272954,88.5353646413736 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962903274957,-4.3368086899420177E-19,-55.22987468205352 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796299443786,-1.5707963267948966,39.39663649219426 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963002251648,-1.5374718637780889,9.98420017325084 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963003406198,-88.53503505598218,76.96886348680881 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963031282093,-1.5707963267948966,100.53080108701471 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963041011075,-0.4968860868682675,3.1111596174172016 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963061863086,-1.4978036748224937,-32.7374655306287 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963068927904,-95.6698382139552,84.64932251514152 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796315539791,-1.5707963267948966,-3.5757775834826447E-6 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963157845333,-1.5707963267948912,163.35305606833685 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963180996787,-1.5707963267948966,-1.5707963267948961 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796318289234,-94.24979369385841,3.1373083456750357 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963203128297,-1.5707963267948966,28.04131823822066 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796321034435,-1.5478347541184774,-1.5707963267948966 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963212267633,-1.5707963267948966,106.81729081464842 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796321645439,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963218244076,-1.5707963267948966,-13.87733050911808 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963222793386,-0.3868053272603156,1.5707963267948966 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796323795201,-0.09521199068212985,0.0 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963238811822,-1.5707963267948966,-25.140649603266425 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796324267604,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796324496096,-44.303338549719555,1.0557199205259669 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796324610657,-1.5707963267948948,-0.9243045287888136 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963246397756,-0.10539719211711097,68.95266824931805 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963249332342,-1.376882716319631,-34.79650557771685 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796325009405,-45.03446427493122,44.33780593432691 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963251676675,-1.5707963267948966,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963253678439,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963253730142,-1.5707963267948966,-4.379587817249305 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963254022008,-1.5707963267948966,-31.415792128480987 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963254085318,-0.8586253454101029,-1.5323488852483018 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963254130077,-1.5707963267948966,-30.339098701888947 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963254639352,-1.2685245930086948,1.6332963268135514 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963254731994,-1.4715882451859896,-35.56827811876043 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963255389321,-0.7206498318875545,-2.2779086407499096E-16 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963260450333,-1.570796326794893,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963260716031,-1.5707963267948966,56.580897678573855 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963261349291,-0.2354275683950841,73.81316972960616 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark06(-1.57079632613777,-1.5707963267948966,-46.420958098754525 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963262539963,-0.8145724100914691,93.62451713132312 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963262768576,-1.5707963267948966,95.64367794522366 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963262846885,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326302382,-1.437797638022705,-33.017387492819886 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263314413,-0.8412998297265563,100.0 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263393931,-0.2853839055638803,0.06982951872188807 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326348157,-45.168695131480945,20.31863647668143 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263508622,-1.5707963267948966,-23.08865875312785 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263520943,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263621005,-1.5707963267948877,-1.5707963267948966 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263770117,-1.5707963267948977,-38.523028092407046 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263804097,-1.5707963267948966,71.49077972682198 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263807734,-1.5707963267948983,-68.89859161251877 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264101847,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264147604,-0.7260744918866497,0.0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264318958,-0.0019513470428059961,-91.28676295720754 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264344957,-32.8135559440017,57.64041375265735 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264491394,-44.27003427653277,38.98166771927487 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264586489,-1.5707963267948963,48.30768560023954 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326459156,-0.20377044357851462,-30.943435402592257 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326461695,-0.821263680885091,-19.284723481128662 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264658467,-1.5707963267948966,22.444262665535557 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264820428,-1.333898577614072,-79.43620131192297 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265155114,-31.60219549231807,63.52116596952547 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265282694,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265331226,-0.030860258711290528,-32.95632263614333 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265418083,-0.6593298375617886,-27.409137124792146 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265565748,-0.1189773363475186,0.0 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark06(-1.57079632656821,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265712646,-1.5707963267948948,72.48519853470411 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266081792,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326618744,-0.2350833994653038,-47.09419699607035 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326632948,-0.2194774187646375,-72.26109567787276 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266351275,-0.20250007398263717,95.84285617033288 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266458647,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266459957,-0.04439889164118965,14.942094258799798 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326655014,-1.5707963267948966,0.7849890369279169 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326657621,-1.5707963267948966,55.152887746937694 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266798652,-0.9822958729597558,-90.35151773970743 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266871554,-1.3768045966787832,71.08483284676139 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326689989,-101.69837801788312,0.3472122044459507 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267203815,-0.667855219197988,-68.11518977767619 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267303897,-1.5707963267948966,-3.1429259292650214E-15 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267322924,-1.5707963267948912,15.155670137578852 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267325142,-95.81857593445065,7.105427357601002E-15 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267527665,-0.938041674621207,-68.60578198140107 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267578489,-0.8987354790257649,-1.5707963267948983 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267666392,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267712934,-1.5707963267948966,-1.5707963267949268 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326783487,-95.67233170607707,7.882647216490511 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326788259,-1.5650281474986565,1.5707963267948966 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326788312,-1.3291497695313274E-17,-37.27097929001548 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267886134,-3.291095717639275E-10,-44.93000087265622 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267900567,-1.5707963267948966,-61.906087281238435 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267900618,-0.5646474417873526,67.42354993945533 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267907414,-1.3456328112608205E-11,-2.5702255743381257 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267909264,-1.5707963267949019,73.63044847804885 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267910283,-1.5635797486718155,100.0 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267928984,-1.5707963267948966,-1.2338789709326767E-178 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267932503,-19.351353795645768,32.90140728025751 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267936798,-0.1533514635906723,-90.57335367428534 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267940634,-1.5707963267948966,-91.106186954104 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267942007,-1.5707963267948912,-39.32870241566194 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark06(-1.57079632679421,-1.5707963267948966,-14.340210855902399 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794291,-0.25422213668535854,85.34524640821658 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267944978,-1.5707963267948966,21.991148575128552 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267945892,-0.2432910281313454,-46.222481966358885 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267946212,-1.5707963267948948,2339.6013099054644 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267946585,-1.5707963267948966,45.54593880553571 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794668,-1.5707963267948966,-80.20640841430674 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794697,-3.944304526105059E-31,61.23879134924802 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947092,-1.5707963267948966,-12.567825787743388 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947136,5.421010862427522E-20,-53.93827761500691 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947211,-1.5707963267948966,1.5710404752210663 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947564,-0.2679284828972504,72.18270987467609 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947702,-3.552713678800501E-15,36.40721394070118 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794774,-1.5722762551905667,-310.32325092104384 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947909,2.8256226883431497E-17,1.4300943250496958 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947918,-1.328954112117212,27.476601536415885 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948033,-1.5707963267948966,-72.6732310707596 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948077,-0.5243762586852218,3.1415926029132484 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948273,-101.07741986192707,0 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948344,-39.043059270043784,59.7346670068967 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948413,-1.5707963267948966,1.570796754492413 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948415,-39.24558463552461,7.870970467739511 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794845,-0.3576975025424929,95.42889246510583 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948521,-1.5707963267948966,89.60382583666328 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794854,-1.5707963267948966,19.241986963889307 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948557,-0.06499247130879837,73.8553031404551 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948568,14.460621761982551,0.0 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948593,-1.5707963267948966,31.456493271460996 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948593,-32.46438640572765,27.511188506286416 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948655,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948664,-44.54194320892775,95.45821890071858 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948686,-1.5707963267948963,-36.34122363356018 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948686,-1.5707963267948968,1.5707963267948963 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794869,-38.872920953148075,849.7902359461016 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948695,-1.5707963267948966,-11.385929245031132 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948717,-1.086951665815512,-35.04522899946265 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948724,-94.30987173749028,1.5294375685942714 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948735,-1.5707963267948957,30.872245142887493 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948748,-1.5707963267948966,-87.9802964185761 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794875,-1.5053586096933902,-100.0 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948752,-1.5707963267948966,-39.810997535508754 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948761,-0.21337720498396393,2.3457274237698944 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-0.025754961814196772,-60.794475715462745 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-1.5707963267948966,55.7081257932459 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-1.5707963267948966,-87.67815192441093 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-1.5707963267948983,27.80907412463166 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794878,-1.5707963267948966,83.53736114475177 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948792,-1.5707963267948966,9.343362432454782 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948801,-1.5707963267948963,-94.30311489215896 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948808,-1.5707963267948966,92.74672591112471 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948837,-1.5707963267948966,-56.54863844835547 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948841,-0.8287525943469614,66.37515243905857 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948841,-0.9771613034330078,0.0 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948841,-1.5707963267948966,2.1998811650317194 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948841,-1.5707963267948966,73.04583713740097 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948841,-31.931733746152346,1.5707963267948983 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948857,-1.570796326794893,-47.5165732302713 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794886,-1.5707963267948963,50.42138224989398 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948866,-1.5707963267948966,-98.18655169328052 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948872,-1.5707963267948966,3.5051138078995168 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948872,-31.700916747908572,1.0279936574186999 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948875,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-1.351039819329304,3.141592655362171 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-6.278481277858244E-15,3.141592653589793 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948881,0,0 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948881,-1.5707963267948966,-0.14267824199683524 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948883,-0.10658064047661493,-1.5707963267948966 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794889,-0.7795502832102842,-1.5707963267948966 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794889,-1.3480959550660672,10.839128414325614 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794889,-1.5707963244860794,9.78125836360617 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794889,-31.552004657144728,7.667755605891216 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948895,-1.4074373250200591,1.5707963267948963 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948895,-1.5707963267948966,83.28107781105717 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948903,-1.5707963267948966,-54.29850515041386 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948903,-1.5707963267948966,87.76432703117945 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948906,-19.39686454736816,58.23156631914733 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948908,-0.09776912032005414,-0.8988903858722187 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.0016084623909726932,-12.913717777393401 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.01954350134831926,-35.43764504504752 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.030824866166847487,-6.462053296434107 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.04032100557905949,-78.23944260748036 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.04716470254773321,-6.712388988440706 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.10968861542955019,-94.55186360559063 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.23502710062119725,-33.28749711439366 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.4078038244649065,-45.56246202995609 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.4376636411949896,-64.22525732159073 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.5435863691927936,0.0 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.6790493563300999,-69.18837668950371 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.6906937746173334,-38.997624084378444 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.9654260293498651,95.3750944964653 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-101.08200593820966,84.38812814286499 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.0165204945039088,15.706127683649482 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.035515011074612,-0.20998013424743966 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.0947300475064679,73.78589364300649 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.1102230246251565E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.2156394910296964,-33.53188513128546 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.309828159333406,58.14570219139635 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.4780425835886937,-52.39838968973713 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5139954480108735,100.0 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5386705038154167,0.0 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,1.5662400601036965,0.41370827852424 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5670082393673672,11.538767012738944 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963259709365,43.98879682977086 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267942482,80.37118556324958 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948806,23.041253304968855 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948837,-10.611350481324692 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948877,57.147398898760315 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948912,32.70890382852488 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948948,-77.49119341392168 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948948,83.38659116984604 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948948,85.46372750976053 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948957,50.57430687451628 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948963,-11.20318620578536 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948963,-16.449900489285618 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948963,-5.098975232586241 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,1.765274778436691 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-18.874051985390984 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,2.710505431213761E-20 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-3.1415926535970593 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-3.439692277092803E-14 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,35.7927149776347 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,38.7938305884216 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-40.89578260493762 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-4.300279884223073 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-4.713106337761679 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-48.724058780619686 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,52.214291616911304 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-52.968986130457196 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,54.124692923707485 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,54.72125242257479 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,58.11359551672409 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-65.9828869908544 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-79.22964183911394 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-8.470329472543003E-22 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-85.14615679930944 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-9.192347507167497 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,99.99999999999999 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948968,0.0 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948983,-193.20781782440687 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948983,6.712388980384691 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948983,74.71931442821733 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267949019,-72.31222594673218 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-157.15825597921125,139.21437439044033 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-157.41307482637487,0.7139718992324902 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-163.58559206512462,0.6574389196993609 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-164.48385447040098,-6.92730517335811E-22 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.704957883129772E-254,3.2453533967471494E-15 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-19.34955592153879,96.8948814983415 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.9781300904218426E-15,-59.113074448336704 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-2.002083095183101E-146,-45.36791520072523 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-2.249603563543488E-13,-91.18965942972947 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-2.28597478256455E-100,1.9931686755080262 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,2.465190328815662E-32,-4.399491351327859 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,3.0122427924760315,0 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-31.60361140069521,-14.430004879283928 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-31.953860692629867,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-31.958592690168146,65.58430925119146 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-32.45461798760096,2.2509016038921636 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-3.469446951953614E-18,4.803914984024784 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-37.69911184307752,83.39047462259451 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-37.798417123966544,14.227240538014044 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-38.83007965747703,1.6935664417630933 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-38.86161694499256,53.319377484167745 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-38.87479723222975,14.320934381766872 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-39.152837502877624,2.054634435076708E-70 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-39.16027923866834,31.601583443351274 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-45.17482731319011,31.42223240309079 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-45.24517340482968,27.0672983514893 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-84.3486187451766,15.541946214269661 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-84.53162226736768,1.5707963267948963 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-88.1154503244858,14.055986451212817 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-88.14455072033024,37.91514464124961 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-88.34882566899394,58.41297307222223 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-88.51332293555443,90.18369854433065 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-94.32807456572144,90.44893202853446 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-95.41122133941187,47.29677643660453 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-95.41412610050574,34.038255107172354 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-95.58951943103386,1.5707963267948983 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-95.65239657374705,3.1415926535897936 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-95.7248038830969,122.0751750060013 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948915,-1.5666891177602944,181.44970331270991 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948915,-1.5707963267948966,-4.4367612524904985 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948917,-2.5626663618343692E-144,48.74064657352317 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948921,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948921,-1.5707963267948966,54.05491422642375 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948928,-1.5707963267948966,98.16081082679706 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-0.015027372710637041,9.581988973908821 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-0.17282633553916016,-0.45731114660495825 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-0.1813747591213326,-52.40650283253188 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-0.18521769607593022,-47.58696692501445 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-0.3364231215345983,6.298606218158142 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948932,-1.5707963267948966,-1.5707963267777894 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948932,-1.5707963267948966,74.86084074398246 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,2.465190328815662E-32,0.038291650065853604 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-37.70686748482131,-14.42949204465171 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-37.739216216754755,32.85165971902673 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948934,-1.5707963267948966,92.33553659464958 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948937,-0.42430159743699014,-29.047114230677487 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948937,-1.5707963267948966,-43.98229703861326 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948937,-1.5707963267948966,66.35360876473221 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794894,-1.1010162934693424,-3.141592669800698 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948941,-1.154122327223217E-128,31.42823813187278 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948941,-1.5707963267948966,-9.139621515060043 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794894,-1.2381598904437556,-49.19889457094639 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794894,-1.570796326794897,110.33143599863786 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948943,-1.5707963267948966,-73.34576772531388 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948943,-1.5707963267948966,-87.64207141301195 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948946,-1.570506598217832,-53.84046204870852 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948946,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.028981519415342216,28.04645619819351 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.050606991564978054,9.49055697639156 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.08475132629377669,-85.41430619055053 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.10228004741051955,-585.6536613763856 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.11906323862605481,-1.5707963267948968 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.2780402719123207,-8.708560975045424 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.31616860604078223,-14.430257966163396 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.38372468377921665,1.5707963267948966 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.4604932304813782,-51.65375988887721 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.5459701003927133,55.43916956083162 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.5575698705588932,63.693966590150815 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.7921303379093384,29.8999669536542 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.9194225893117316,3.944304526105059E-31 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.9871202454084553,63.48565036399117 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-100.0,0 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-101.64778203565156,1.1033957925401126 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.0226881712908495,58.65081358747628 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.0318664067300827,4.712389021433601 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.1228131545028175,-1.5707963267948966 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.2542465353221477,56.504835173171436 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.2995574541749875,-4.178968712600033 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.3763838483180209,48.1298483206319 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.4444044571871488,1.5707963267948966 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.461251503189499E-16,93.32439015738568 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5267596391789244,21.465586960574687 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5423487136658458E-179,-10.14528013523649 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.562053633590713,-54.06435466597068 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5666734980166304,42.32116876331722 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948912,82.4475653663589 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948912,-93.05266844834892 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948912,-9.468777667433969 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948943,-115.01422292449246 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948948,-67.64721441791849 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948948,-77.97189673907796 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.570796326794896,0.0 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948961,12.135402755995152 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-0.03246603632211621 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-0.05659844376999439 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,1.4260129813088298 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-1.4479319246526023 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,1.5707963267948957 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-1.5747025767949168 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,2.269937816715597 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-30.078732555140146 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,3.1415926535897936 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,3.219165001108988 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,40.85942513597921 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-46.09153375938682 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,46.54793200106638 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,49.379599710277375 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-51.996310299036 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,52.22001061402705 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-53.10180253614118 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-54.5494831117022 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-55.69869824905452 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-66.5206184489522 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,67.20788542521703 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-77.2219342731055 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-83.97336331346497 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,86.66793116266419 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-87.19385372622308 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,88.09012057177428 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948968,-1.6940658945086007E-21 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948983,-20.527663880968447 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948983,67.2068851866819 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948983,74.97787995357567 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,2.465190328815662E-32,-1.5707963267948966 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-27.018956305297166,45.4056828389134 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-3.1069845593075527E-15,-53.87930721216208 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-3.1415926567895416,100.0 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-31.426477177581507,39.55519718768534 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,4.3368086899420177E-19,66.60737638112202 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-44.32725126970148,19.090034620832185 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-44.454017925829525,51.92989264536462 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-44.998029004190194,31.415970972116874 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-45.058601734932395,2341.573653158159 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-45.236944627558884,0.3060569714712831 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,5.421010862427522E-20,54.3911864199351 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-6.392192703824278E-9,-53.40696776576392 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-6.776263578034403E-21,45.55309296580444 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-88.14475571500637,1.161905875930931E-88 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-88.272309320202,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-88.41825870378449,71.84856086684708 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-94.2477796076938,34.45556522237416 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-95.41240241303855,101.96816069390867 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794895,-1.2338789709326767E-178,1.5707963267948966 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794895,-1.5707963267948966,-53.65336968759702 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794895,-1.5707963267948966,57.58223987579271 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948952,-44.3945866250169,0.07314096589496691 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-0.03023456048593206,-1.5707963267948966 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-1.3975826339001864,38.979980140594606 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-1.5707809825211372,0.0 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-1.5707963267948966,-19.660759706151076 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-1.5707963267948992,1.569180355429874 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.011077599126373789,-4.714342106116736 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.012993749331070281,-45.93660689454117 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.08073571477773989,94.36761550964455 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.10628875149287027,-91.35979719949137 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.2461068223997556,19.374254950082847 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.376909471054091,-1.5707963267948966 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.0733916266905226,-61.09427031443852 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.287488667250344,-1.5707963267948966 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5162119049015623,38.327523586468175 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5587942956213192,-1.5707963267948961 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948912,30.064756962200914 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948912,48.453000735521755 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948948,48.51024198298225 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,-1.0496133439896258 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,18.093806293648285 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,23.03309557762833 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,3.1415926535897936 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,322.8032820649028 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,-50.57730192890668 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,54.04276118256101 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948983,-3.1415926535897953 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-2.119310687189783E-15,1.5707963267948983 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,2.710505431213761E-20,77.09600612325087 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-7.105427357601002E-15,67.22104456806929 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-95.7827440748553,0.6451315552963734 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.002162493000803671,-64.59705623003973 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.028790160269525564,-64.77565105347261 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.05851206339924353,-57.21357890460398 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.14850950783382894,-1.5707963246431111 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.259710736456607,-44.11454395661189 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.28953217966649,-25.955852474036824 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.6176662847837279,38.74148859620688 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.6280074827712004,-96.01068474765808 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.7491560156013465,-18.777219174119082 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.8276171926733733,-1.5707963267948966 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.947681498149985,41.97246096388213 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.9767731991248532,0.1999721915367038 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.104943124365775,0.7569281579271769 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,1.3877787807814457E-17,0.0 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.4124184259011665,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.4689841132629673,-70.7162742324873 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.4930230611332647,-92.23563690748738 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707962596764737,37.69900733749276 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963248012597,0.0 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963262906104,92.55288482812983 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963263418163,26.529298854767866 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948775,-1.5707963209817164 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948912,86.93191932484052 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-13.170879007118007 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-15.50398168794443 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,1.5707964536830223 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,17.44617532305341 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-2396.4265489169698 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,24.7745127625109 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-3.141592653589793 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,3.1415926535897953 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-3.141592653632531 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-33.72339893482971 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,49.567120466561576 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-5.06185334033826 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,67.3987005981233 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,69.93208166929192 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,75.8056482382207 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-81.68140898753386 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-3.4365421603523834E-16,10.99570365414875 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-44.25379200806821,46.9038953519662 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.4693679385278594E-39,0.0 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5233821969271326,-44.44483117685107 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948966,-1.235280691041013 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948966,-15.54114655760874 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948966,17.278759727794576 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948966,5.421010862427522E-20 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948966,73.59778154834004 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948966,9.517480594387934E-16 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,6.712388980480534,12.622976030962244 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-88.08959430052529,109.95203858999304 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-95.65693171590596,3.141591578708526 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.025076678704944993,1.5707963267948966 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.03271648519639303,4.744292317597031 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.06568822455863516,31.838211551381146 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.11247676651331506,-81.44000363169998 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.13138827169640246,-73.76488577946482 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.15449378112715317,-66.12212098032721 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.24690369792238998,4.712645607593994 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.2947290380886429,-1.5707963267948966 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.30976564331009826,-97.66066787780171 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.31849530699775197,-87.96528753053202 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.35698385118771353,-71.21139649736494 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.4196045079554267,46.539225050187895 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.47846990314867455,4.743716312552413 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.5447942664615185,68.04246609815674 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.678302513957202,27.340883343069237 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.6947455175676883,1.1222063866923024E-190 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.6964336490991093,-4.743639020628597 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.7752096696777819,90.37744577827823 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.8781880830501546,-1.5707962999645853 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.8957718579727587,27.614513914499113 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.9125000157467662,-4.712389218812009 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.9312907247267752,65.65300284160755 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.947488694691933,1.5707963267948974 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.0896835252119186,-95.67931210656108 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.1642497155245963,-70.5595654505543 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.2570012400093855,-1.2862851582726815 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.382664000523453,-1.5707963267948948 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.4065918245113564,67.48620149830114 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.4693176573872222,-63.6070728201328 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5298083458275045,-7.959898161660501 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5525546013686435,-57.9307657155449 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5623910636457419,8.673617379884035E-19 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948948,100.53089812593542 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948948,-44.11158213572753 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948948,46.21532676381992 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948957,-32.772136955573195 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,0.24185905831466672 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,10.848471852521886 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,14.451195276045063 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-1.5707963267948628 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,1.5864262320336389 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,17.35252042171126 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-19.226037144640028 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-29.92884368928648 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,35.91639146786156 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,39.176072394006276 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,44.09817494491561 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,52.64977441438346 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,76.00798390094603 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,7.646611933568395 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,84.82300927768871 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,85.97944441891671 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,90.32741307610931 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948983,31.57778178859727 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948983,54.40267214101381 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267949019,-510.4436651144687 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-19.349556361407224,40.83972662775056 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.9374284276111513E-16,16.815403191113056 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-32.70810972796244,0.0 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,3.3881317890172014E-21,27.87555743812581 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-39.16842703361334,1.5707963267948957 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-39.265169391498475,0.8400662715135495 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-43.98501320077576,78.22453942056399 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-43.98620352642917,15.700615817588258 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-45.42691975080833,90.33920772879065 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,4.930380657631324E-32,1.443471855996634 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-5.551115123125783E-17,0.0 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,6.71238898038724,0.9117959059340586 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,6.938893903907228E-18,-3.706939796065128 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,8.673617379884035E-19,1.5707963267948966 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-38.86592650948528,1.5707963267948966 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-9.489271333842138E-4,1.7514267686804033E-4 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-45.12046506767214,1.2852871943414508 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-6.344854593289123E-117,-0.4067003923002197 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-88.31610285605638,0.3760051178620866 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark06(-1.5793650827938261E-176,-1.5707963267948966,-61.60857778735018 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark06(15.917547438733408,22.07262413920843,88.75132291468145 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark06(-16.007240614869716,48.43394458911129,-18.75701469310316 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark06(1.6039624885707727E-26,-1.5707963267948966,-31.76234423577658 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark06(16.121722400527176,39.49117593155492,-27.199159295436544 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark06(-1.6341987789878225E-5,-32.98555157223245,153.91733327473202 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark06(16.366402736941012,-19.786774938723184,-37.79972141204975 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark06(-1.6458503040199715,-0.1999925276913885,-1.017544884671216 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark06(-16.472205130528167,-59.885237673113224,91.29768069630262 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark06(-1.656084321055619E-170,-1.5707963267948966,4.57041103620645 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark06(16.64487449949445,71.92851681065773,-80.8217299085012 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark06(-1.6704779438076223E-52,-1.5707963267948948,-1.5707963267949054 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark06(-1.671700140743776E-30,-1.5707963267948966,-16.654627157914007 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark06(-1.6801218171067045E-18,-1.5707963267948966,-53.407074656448465 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark06(-1.687686547810631E-15,2.465190328815662E-32,0.6219801786514675 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark06(-1.7197762835371747E-136,-1.5707963267948966,3.141592653589793 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark06(-1.7281546428055866E-15,-1.5707963267948966,-0.30398624683712777 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,0.2899803976355896,-1.5707963267948912 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-0.8229330814810717,31.78821011510086 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-1.1102230246251565E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-1.4478768550053882,-55.16358688611036 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-1.44861983293432,86.50577739741298 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-1.5657558350207672,1.5707963267948966 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-1.5707963267948966,-44.37518704301346 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark06(-1.734723475976807E-18,-1.5707963267948966,-59.09560220040242 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-1.5707963267948966,6.116427425869631 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-2.220446049250313E-16,66.4802337551375 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark06(-1.7534474792067224E-192,-1.5707963267948966,13.52279977680416 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark06(-1.7534474792067224E-192,-95.33197880173418,1.5707963267948966 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark06(-1.770344736145582E-5,-1.5707963267948966,1.5711625625926844 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.0267806750877293,-93.56635178700157 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.1705974457396082,11.151170079022684 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948957,-2.7139229093998187 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948966,-13.625196835542816 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948966,30.873887677006515 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948966,-7.171762371044684 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948966,75.69546878085544 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948966,94.48222260142887 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267949019,89.6757573522502 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-37.92214725327048,51.893685629722086 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,5.551115123125783E-17,50.75274949313456 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,6.71238898057609,-36.49635105920295 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark06(-1.778206999588062E-161,-1.5707963267948966,39.99443654615377 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark06(-1.796376815483599E-16,-2.220446049250313E-16,21.038632665677433 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark06(-1.8033161362862765E-130,-1.5707963267948966,-83.15426320806729 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark06(18.04265874698882,68.81925375870551,91.11408025511935 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark06(-1.8076052915275075E-26,-1.5707963267948966,62.124705159673915 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark06(-18.157575780329367,-61.41927727774954,12.856942116996038 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark06(-1.8228850223995598E-7,-9.245474668930281E-6,-3.141592653589793 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark06(-1.82877982605164E-99,-1.4715404128372513,-1.4304241095200414 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark06(-1.833396664520314E-13,-1.5707963267948966,79.94016384290848 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark06(-18.429384477027824,-40.75214449781714,96.51504440577193 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark06(-1.8486780472147733E-12,-1.5707963267948966,84.25112817395673 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark06(-1.88079096131566E-37,-1.5707963267948966,70.68466201677606 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark06(-1.8972046930769177E-15,-1.5707963267948966,-1.571772889300944 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark06(19.085319136785657,-30.179746127201085,0 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark06(-1.918531076190462E-15,-1.5707963267948966,-18.417269856129295 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark06(-1.9460308629969658E-9,-1.5707963267948966,72.25872555429767 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark06(1.9721522630525295E-31,-1.5707963267948966,-3.185325365929492 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark06(-1.9742063534922827E-177,-0.7390508346191328,0.0 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark06(-1.9742063534922827E-177,-1.3693971505275877,-43.35880408648429 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark06(-1.9742063534922827E-177,-44.45543143729906,0.3778365837425437 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark06(-1.980939431454841E-14,-1.5707963267948966,72.14076732399624 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark06(-20.002423656638356,-31.01149405946917,24.82597517743079 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark06(-2.002083095183101E-146,-0.10528564914025,1.5707963267948966 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark06(-2.0185900643165368E-10,-1.3430990406379806,-9.50046101621368 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark06(-20.190009822749616,70.87559633040138,84.79500131678816 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark06(-2.0398075792210026E-15,-1.5707963267948966,-22.926312817231548 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark06(-2.0590230357872116E-84,-37.892715078529534,7.361086797138796 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark06(-2.087366266575099E-9,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark06(-2.090638439190517E-11,-1.5707963267948948,-16.35192956479626 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark06(-20.97911821953467,-17.820137582482147,-69.81115092641872 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark06(-2.116962065944039E-16,-0.29935023230626473,-9.525644906437478 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark06(2.1175823681357508E-22,-1.5707963267948966,-24.77545896853956 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark06(-2.1175823681357508E-22,-1.5707963267948966,97.38928165461935 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark06(21.29390074753171,-37.606613827027836,-72.63914876942582 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark06(-2.1298166472957574E-15,7.888609052210118E-31,-73.67178286219541 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark06(-21.44788774767501,-32.70391320982495,50.51635497275541 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark06(-21.461224574070982,-88.91399727269244,-8.547104321233363 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark06(-2.1558075561693357,-89.61023443430454,81.99824156926152 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark06(-2.1607721192293288E-7,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,-0.1289878131186861,95.80502074228512 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,-0.5352387347024148,1.5707963267948966 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,-1.2058879347766753,-32.83374735346018 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,-1.5475040091159937,-10.596497066752452 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,-1.5541382005566367,-83.60699664414824 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,-1.5707963267948966,71.56370573302436 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark06(-2.1684043449710089E-19,2.90678807057052E-20,-1.1724004784579707 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark06(-21.826928992827916,22.5008250747822,87.84756204638387 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark06(21.93860611109966,-49.56471198137251,-87.14330524998422 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark06(21.963949886600133,75.50373834596155,25.298202725041904 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark06(-22.08683700039549,-90.61906314181876,-8.641130336829804 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.03014483323387379,-3.1415926535897967 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.9360391863963015,100.0 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.9986160181781724,-55.74220528764322 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.203549059814999,-3.2665927263567225 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.3796210410626302,-88.52802571907476 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.4177007784099322,-2265.697891932535 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.421032262058398,-61.056063435264406 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5553025868009254,99.51507867086087 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948912,53.804988066077776 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948912,67.43842215389547 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948948,-51.8418278923799 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948963,1.5707963268315226 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,-29.93768392400069 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,29.970120547289117 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,30.29140449268823 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,-3.2665926536242633 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,-59.47011996878903 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,-79.13003076285175 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-19.39008569497669,69.81384347881723 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-2.220446049250313E-16,-9.839629543150494 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-3.1415926535900605,90.2041414628861 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,4.3368086899420177E-19,30.137134938515942 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,6.469031636733534,58.47147096667295 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,8.673617379884035E-19,74.63031614597689 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark06(-2.2227587494850775E-162,-1.5707963267948948,-3.47252462387404 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark06(22.25261638706553,26.825854097496006,-17.772376294007657 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark06(-2.2323972485981933E-103,-1.1175766007260308,-45.58984126251582 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark06(22.348279717086598,99.68801244323603,27.30544613545736 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark06(-22.487382054699424,93.20366600175271,57.9350797842867 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark06(22.844215616729045,88.31908160109629,70.21193465994301 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark06(23.02350598028788,-9.101527882223294,-44.982100030047434 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark06(-2.309251506174381E-6,-1.5707963267948966,-78.53188658133458 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark06(-2.3094425249770943E-16,-1.5707963267948966,0.8906248432299252 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark06(-2.3408381773460992E-97,-1.2259454973028903,-39.05640701862548 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark06(-2.3408381773460992E-97,-2.536632756778845E-4,-1.5707963267948966 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark06(-2.348151569655929E-18,-2.220446049250313E-16,-3.141592653589793 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark06(-2.350988701644575E-38,-19.356227040600658,58.13062868777611 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark06(-2.3544213149594522E-5,-37.70785748087809,157.13374909201866 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark06(-23.79582173039765,-56.02622820513747,-19.805811879421697 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark06(-2.3995149022330095E-240,-1.5707963267948966,33.742759019019296 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark06(2.4017306988619396,0,0 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark06(-2.427065219751055E-6,-1.5707880586848126,-3.141592653589811 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark06(-2.4333972048578046E-209,-0.21263882165604095,-1.5707963267948966 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark06(-2.4409570474085776E-16,-1.5707963267948775,-3.1415926535897967 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark06(24.47240709916869,-97.62328527436286,-74.60632693668647 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark06(24.593901558466086,-81.68464650893381,50.09535677763955 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-0.4829536341449221,-78.83349712494761 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.4734518565737187,49.89185815611939 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark06(-2.47395229919027E-4,-1.5278342834058904,1.5707963267948966 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark06(2.484612346703304,0.0,0.0 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark06(-2.486390710898909E-8,-1.5707783633835803,-53.410378354082 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark06(-2.486430143528127E-10,-0.9059627799932798,-1.5707963267948966 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark06(-2.4873843684605437E-15,-1.5707963267948966,-93.47753483122618 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark06(-2.5026038689788762E-147,-0.7749903657480107,36.529824116899164 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark06(-2.5026038689788762E-147,-1.5707963267948966,-32.5810456709812 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark06(-25.204525779199628,79.26988656191807,23.36682647707336 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark06(-2.5266904901539286E-14,-1.5707963267948966,-4.743638983861826 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark06(-2.538052129765407E-16,-1.5707963267948966,63.495178524439886 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark06(-25.533556871333587,13.444337132727568,3.3565945673553585 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark06(-25.543599429585683,-21.03726253555746,58.35668165753219 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark06(-25.554311761240413,7.710959416933434,-83.28334912228519 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark06(-2.5555911696999446E-7,-1.5707963267948966,-2.5707962918490472 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark06(2.5706040719776513,0.0,0 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark06(-2.572122310627204E-194,-1.4143471626712343,1.5707963267948983 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark06(-2.5988524414112248E-113,-1.5707963267948966,1.5707963266652807 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark06(-25.997888062493885,-6.805139870642506,-47.36187801300298 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark06(-2.6101217871994098E-54,-1.5707963267948966,-3.141592653589793 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark06(-2.62515058608147E-14,-1.5707963267948966,1.570796326794936 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark06(-2638.907176008555,0,0 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark06(2.6469779601696886E-23,-1.5707963267948966,-12.975522331166136 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark06(2.6469779601696886E-23,-1.5707963267948966,-77.96162217615772 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark06(-2.6593781995525774,44.23294066771902,-12.412593042537594 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark06(-2.677503988843731E-16,-1.5707963267948966,53.865874291761415 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark06(26.933319779046116,-60.22172574695064,48.49299313258601 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark06(-2.693517008192633E-16,-8.1214138794100775E-115,-12.605017823991401 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark06(26.95732068889363,40.658640261993554,-38.71720367678619 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark06(-27.029898770216022,-35.92044394493537,0 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark06(27.075716821787736,-58.939120911515566,-78.57631714343891 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark06(2.710505431213761E-20,-0.5170857986348958,-0.7350588887498388 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark06(-2.710505431213761E-20,-1.5686527584663523,84.82279287721484 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark06(-2.710505431213761E-20,-1.5705922419136478,-3.125951338463754 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark06(2.710505431213761E-20,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark06(-2.710505431213761E-20,-1.5707963267948966,-2.5707923176571597 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark06(2.710505431213761E-20,-1.5707963267948966,-7.766137927078941 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark06(2.710505431213761E-20,-88.36713989714286,82.22135041375701 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark06(-2.728995387219446E-16,9.860761315262648E-32,-44.03731359298679 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark06(-2.7369110631344083E-48,-1.5707963267948963,70.68583470485244 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark06(-2739.1562314258695,0,0 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark06(-27.616470657445007,80.90801120264646,20.76058162766246 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark06(2.7755575615628914E-17,-0.9956073897393571,-1.5707963267948966 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,-1.1102230246252086E-16,-67.30336906895056 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,14.451195349660189,-1.5082477096209452 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark06(2.7755575615628914E-17,-1.5665302753422594,42.30644774586338 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,-1.5707963267948954,4.743638980386498 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,-1.5707963267948966,3.1415926535898313 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,-1.5707963267948966,31.9324148295699 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark06(2.7755575615628914E-17,-1.5707963267948966,44.787634117038635 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark06(2.7849450486170897E-19,-45.291123800349894,78.13084012290315 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark06(2.7857453379883334E-19,-32.638693497752215,1.5707963267948983 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark06(-2.795665492311252E-15,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark06(-2.7984298758433523E-15,-1.5707963267948966,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark06(-2.81627529612208E-16,-1.5707963267948966,-40.82365171797553 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark06(-28.41327882853659,-87.21043936704973,-10.133690493605926 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark06(-2.8485702170185215E-15,-1.5707963267948966,49.3014509388353 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark06(-2.8574684782056875E-101,-0.4640199820747039,-73.49214022394398 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark06(-2.8574684782056875E-101,-1.5707963267948966,-31.819948907059867 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark06(-2.857942873731787E-13,-1.5707963267948966,-82.73926398912002 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark06(-2.86911623578776E-17,-1.5707963267948966,-15.708277179312518 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark06(2.8720975603382915E-28,-1.5707963267948966,45.452359615771655 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark06(-28.87327839143971,0.48879954151317406,12.308584639471306 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark06(-2.897817305224548E-70,-31.81423446006287,26.056731803585993 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark06(-29.097655584480137,10.384094382415526,-87.38349825980407 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark06(-2.922526765218336,15.29871305199238,-39.96474276930451 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark06(2.9425472085427704E-17,-1.5707963267948966,2.8166495023699554 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark06(-29.44728840476772,59.91725072828581,8.983339973648356 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark06(-2.9488306489783685E-18,-1.7763568394002505E-15,-27.594974211486914 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark06(-2.9576304654169368E-272,-1.5707963267948966,1.5111358506832018 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark06(-29.611950653810325,6.247917537633143,56.51430491410022 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark06(29.64651790097281,-48.959172525183426,-90.15015581516738 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark06(29.718303967119596,49.323983000682006,-98.68807075137805 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark06(-30.236845440917804,-40.0558227428228,43.70334394685483 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark06(-3.024523882014637E-15,-1.5707963267948966,59.61511328139413 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark06(30.463813677566577,-86.18185133660819,-85.86222824522824 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark06(-3.0549363634996047E-151,-1.4518432091232927,8.881784197001252E-16 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark06(-30.794192221923964,-85.75613148924725,-71.62055276350011 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark06(-3.0846974273316917E-179,-1.5707963267948966,-36.94865698320689 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark06(31.141856391846403,37.226498326478776,43.643179982888824 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark06(3.1258268531954485,43.27737111994878,-23.12015744612151 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark06(-3.126210896125676E-30,-1.5707963267948966,71.04198595700467 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark06(-3.1282548362235952E-148,-95.45537275698028,-1.9418997852346086E-132 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948948,-10.906541925893336 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,1.4018703899895537 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,-82.1994523226028 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,97.48974502083544 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589794,-1.5707963267948966,-10.911276766002942 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897944,-39.198124702438555,69.88259823791094 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589795,-0.42202140992099113,-0.5341866949545382 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589795,-1.5707963267948966,58.44352541814692 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897984,-0.9336206088834509,-1.5707963267949046 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589799,-1.5707963267948966,-21.194069676215292 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897993,-0.5084148252465257,1.5707963267948966 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535898158,-0.8886575886098976,77.1478867201986 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589816,-1.5707963267948966,20.04578505116365 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589859,-1.5707963267948966,-5.717335095917605 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589889,-1.476377605729062,-95.44842497765902 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535899317,-1.404326470284217,49.90745185562774 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535899685,-0.06415952084686968,100.0 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535899747,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535901715,-1.5707963267948966,44.29619310652343 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535902403,-0.6191511379726131,-19.007504503882103 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653590634,-1.5707963267948966,90.04862841095917 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535941106,-1.5707963267948966,-1.5707963267952478 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653594675,-1.5647485142884683,66.56798464812083 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535947487,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535955756,-0.20072335480401882,94.42427815474971 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535966525,-0.205934714728516,-61.01878958505039 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535973457,-1.5707963267948966,68.74430272238948 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926536007963,-1.3228939965623965,28.256365221233207 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926536018963,-95.53288412288998,38.853420722425255 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926536316454,-5.551115123125783E-17,-43.47481267998407 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653634849,-1.5707963267948966,10.891771335358975 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653765569,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926540670713,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592654718604,-0.4536210104244679,-1.5707963267948966 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926549432602,-0.6971694793024806,0.0 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926550320155,-1.570796326794893,4.447769853080928 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592655253671,-157.5422344324382,115.96189203370699 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592655651944,-1.3778863333650921,2.8246877497443264E-15 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926558700185,-1.0500663578325773,-58.59784315020994 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926569940607,-95.3687278363482,0.20647046085959658 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926644071117,-1.478747846196652,32.903236553292054 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592668406938,-1.5707963267948966,-0.029487082846818474 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926744091003,-45.52602753576966,71.10916785514686 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592700143615,-1.5707963267948966,-91.86292428217125 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark06(-3.1481956964271347E-15,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark06(-3.155199842344757,-0.2168585246268957,-92.73815867604355 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark06(-3.2236401139360915E-11,-1.5707963266965195,87.62217090981996 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark06(32.273699201486494,50.27540118174511,-76.29814481079214 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark06(-32.36797564791483,-59.6272658921287,87.4509486550684 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark06(-32.42200496224498,35.90812322893896,-76.62789395252076 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark06(-32.483282894707656,57.84131980641399,94.70853915863381 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark06(-3.248565551764031E-114,-0.8897061209124075,-70.13604086208261 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark06(-32.546222138749386,98.73801255242776,92.67631050982524 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark06(-32.65415504170058,70.50208311782123,-90.66729786694967 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark06(-3.2968821184020053E-15,-1.259454137804301,1.5707963267948966 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark06(33.0342250274125,16.03620478252094,-31.132258600082352 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark06(3.3087224502121107E-24,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark06(3.3087224502121107E-24,-88.2570099029753,38.750586733895034 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark06(-3.3211445874269954E-15,-1.4548684674179189,2.8561492002443156 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark06(33.25072254229147,21.772453412726293,76.72619657731929 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark06(-33.328559418572794,-64.09094579874329,-1.58716540224448 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark06(-33.85251056612563,98.30264800529324,-16.957218066778353 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark06(-3.3881317890172014E-21,-1.5707877340555965,-3.141592653589811 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark06(3.3881317890172014E-21,-1.5707963267948966,7.767447528603384 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark06(-33.896912653960044,-80.4459364523407,-35.78813906069496 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark06(-33.91318390722088,-98.99605929727961,-76.5159361360819 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark06(3.405259406804708E-18,-0.5973563464258063,-43.23981189817446 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark06(34.24048748132873,75.8615848865173,-32.61892671479055 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark06(34.40249050099803,-25.395553535424014,35.415375434989414 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-0.11417562296793082,58.81929784227065 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-0.5345081455210181,2.670454965737533 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-1.0260650932643351,-1.5707963267948966 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-1.5372121548370243,47.77504611147637 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-1.5707963267948966,2.0298891595682185 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark06(-3.469446951953614E-18,-1.5707963267948966,-3.141592653589792 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark06(-3.469446951953614E-18,-1.5707963267948966,-3.141592653589898 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-1.5707963267948966,4.353313917657879 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-32.62257956562817,0.46921308236927095 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark06(-3.469446951953614E-18,-32.986722861765955,2.5407110960233386 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-38.87413016658333,1.5707963267948966 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark06(-3.469446951953614E-18,-39.26838516600243,-6.712388980384691 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-95.4470925211513,70.19300532553353 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark06(-3.4730605460704336E-164,-0.4590965495462345,5.792428778229783 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark06(34.83493930483098,-17.249664961207614,-53.266042570070525 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark06(-3.5066385347105807E-15,-1.5707963267948966,-4.863746218066803 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark06(-3.522101828684134E-133,-0.09724873493041426,-1.5707963267948966 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark06(-3.522101828684134E-133,-1.533287911915156,58.16875986767312 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark06(-35.29835899159586,-96.89734600206086,40.30138000272521 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark06(35.30875335138029,95.0508277188647,-64.16722724419267 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-0.23300582294176603,4.764167306688378 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-0.3192143532475338,-1.5707963267948966 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-0.4741926565928507,92.53813166139645 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,0.5578617786064045,-1161.4767760653785 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-0.576020532596445,-1.5707963267948948 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-0.5868122020115398,-44.73224823949844 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.112954474456114,11.297982890579421 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.1365097309940142,66.13046500746248 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.5620300351133725,1.5707963267948966 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.5707963267948966,0.9447341222110524 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.5707963267948966,43.30156200334076 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.5707963267948966,-436.61725113042434 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.5707963267948966,-51.5508783153127 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.5707963267948966,80.24269343800106 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.5707963267948968,34.26021947232218 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-164.59128795273378,3.5188901459795686E-6 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-3.552713678800501E-15,-4.746782686756016 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-37.69911184307752,40.176751277324485 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-38.78835837432834,6.157729478780529E-17 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-39.01210542801359,64.69772912693733 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-39.06222864617666,65.37681066780354 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-39.09981005879116,71.20741435718168 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-44.351881956107235,45.0870417028891 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-95.47330301282176,0.0 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800543E-15,-3.458065414261291E-223,1.5707963267948966 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark06(35.54405667509849,-53.57701707568025,69.17837360573597 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark06(-3.556413999176124E-161,-0.7342296334782216,1.5707963267948912 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark06(-3.5718355977571093E-102,-0.7143678890767816,4.292199425939634 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark06(3.5772539024716963E-17,-1.5707963267948966,-61.238361022759385 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark06(36.03054984558557,19.359034320020243,-14.674522932271799 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark06(-3.606632272572553E-130,-1.5707963267948966,31.821483896316558 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark06(-3.606632272572553E-130,-1.5707963267948966,32.76269175482558 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark06(36.10496352419591,-67.50420968494124,27.601329071269802 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark06(-36.226033045624575,-8.480964313490475,-10.876827025058276 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark06(-36.517774715033994,-58.62404272517983,-50.89137107513775 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark06(-3.668332448627033E-15,-1.0531734258296828,-1.5744336453021657 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark06(-36.82144541648591,26.686985044932143,14.320550879165353 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark06(-3.683842386414421E-70,-1.5068407134028725,-1.5707963267948983 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark06(-3.68992651471778E-15,-1.5707963267948966,47.867967032522664 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark06(-3.728376311146448,-5.743060773542183,74.25747197598147 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark06(-37.30553228939271,0,0 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark06(-3.74752902032715,-38.916412747644834,72.31378562333964 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark06(37.58788862784414,99.85833480979528,3.44529496566372 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark06(37.77134920625846,87.71763730462692,18.719147134942332 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark06(-3.809238337183276E-16,-1.5707963267948966,-65.55188507242279 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark06(-3.80987282466449E-5,-1.5707489649164905,-129.0586295552695 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark06(38.198114684137266,52.869958804359385,-51.634436711596486 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark06(38.663036444378605,-37.56475092035221,54.61395509552824 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark06(-3.910318545279494E-149,-3.552713678800501E-15,-100.0 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark06(-39.279757833090166,27.805897904662174,-9.105246908801817 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark06(39.3512686372909,45.29528307372698,-76.24083238480762 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark06(3.944304526105059E-31,-1.5707963267948966,1.186613144274232 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark06(39.72767831338112,-7.990134568045335,25.080645918608695 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark06(-40.17861871401192,13.804559226325068,47.940309211861205 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark06(-4.0215293667718976E-87,-0.036069485205413684,-62.60874742409683 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark06(40.347962282354956,-89.45721546167671,-89.51876313757809 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark06(4.048326900819717,76.4120860170982,-19.386170236059115 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark06(41.22890364467867,-42.993067865623246,-55.890043983978586 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark06(4.1359030627651384E-25,-1.1772807022005929,-45.56609550516295 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark06(4.1359030627651384E-25,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark06(-41.41519530861062,73.86906444403877,-58.6847862446181 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark06(-41.42424093408066,89.21681579371662,-92.44222009843139 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark06(-4.1624948318597947E-258,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark06(-41.94080226360546,-97.5593619827821,-60.294579502362964 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark06(-4.2168791772922093E-81,-0.4061086292691537,31.955110153367926 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark06(-4.225679037722516E-11,-1.5707963267948966,147.68624649858208 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark06(4.2351647362715017E-22,-1.345711730056623,-41.39699734582854 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark06(-4.2351647362715017E-22,-1.5707963267948966,-40.84272908706082 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark06(42.51702026779597,-21.084128956476377,-56.29642124848739 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark06(42.58087025965389,-79.38695368835882,-14.892162141128011 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark06(-4.271145622863425E-16,-1.5707963267948966,69.57365804242713 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark06(42.8736470364162,80.15058403454452,39.41127915275814 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark06(-42.93191987699934,-74.4582832671941,-63.15440107832624 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark06(-43.21095172183256,56.17874343980992,9.553235335363766 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark06(4.3368086899420177E-19,-0.07602466753288054,-42.839992092210025 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark06(4.3368086899420177E-19,-1.5467432886697192,73.70412777859379 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark06(4.3368086899420177E-19,-1.5707963267948948,1.029926075282165 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark06(4.3368086899420177E-19,-1.5707963267948966,99.61184176757997 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark06(-43.546746119961256,0,0 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark06(-43.58167673562319,-9.422887969025439,49.82538644779524 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark06(-43.68213239565368,38.301379683927195,69.4247088820155 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark06(43.90899200300481,-80.27080458314049,27.458184749134972 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark06(43.921653490892055,-23.7654681211245,51.52782005276322 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-0.04960097071764892,0.5253463849017872 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-0.08225990737826172,-1.5707963267948977 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-0.43012940896309226,9.57680796949956 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-0.616985236288528,-61.442383132535795 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-0.6246000363535404,-53.14336150917087 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-1.3170683208264422,-13.999541520776956 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-1.4210854715202004E-14,1.5707963267948974 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-1.5707960353370367,-3.1415454244942906 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-1.5707963267948966,63.9661524627265 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-3.552713678800501E-15,-80.48700537833324 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-82.51704430084895,0 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-86.9021380660554,0 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark06(44.43190372893861,76.39189393941399,-2.5331838493503938 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark06(44.642586140988385,18.786633648230392,17.78205942906534 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark06(-44.744638350196794,-27.43082144819485,-14.441094519295433 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark06(-4.496787335587243,-96.4400061994917,-85.36661964964189 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark06(-4.5082903407156913E-131,-0.9590651736002305,-66.94047507975375 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark06(-4.5082903407156913E-131,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark06(-4.528697180988016E-16,-1.5707963267948966,-51.836278784227254 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark06(-45.36677484692409,-38.06815681944033,-74.20410669447395 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark06(-4.5522099189454387E-159,-1.5707963267948966,6.252351966968647 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark06(-4.5569512622227484E-305,-1.5707963267948966,-0.17854588782284678 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark06(45.61948154069324,0,0 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark06(-4.5805626991681595E-15,-1.5707963267948966,-48.35078991700925 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark06(45.9577934026249,44.03199454415173,-85.82901283045774 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark06(-46.05443427824565,-74.19649386881142,-25.137643063127555 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark06(-4.616489308892868E-128,-1.5707963267948966,91.57800398392294 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark06(46.38447006089535,-55.468389575574896,-74.73010815732026 ) ;
  }

  @Test
  public void test3659() {
    coral.tests.JPFBenchmark.benchmark06(46.385851560746005,5.901701944781124,-80.32831661282513 ) ;
  }

  @Test
  public void test3660() {
    coral.tests.JPFBenchmark.benchmark06(-46.39420558174678,-39.71473858236545,-11.718771467573035 ) ;
  }

  @Test
  public void test3661() {
    coral.tests.JPFBenchmark.benchmark06(-4.6453789352814216E-6,-45.55302004775952,116.23890315251255 ) ;
  }

  @Test
  public void test3662() {
    coral.tests.JPFBenchmark.benchmark06(-4.65156446565544,46.54512475644938,-42.26349313113171 ) ;
  }

  @Test
  public void test3663() {
    coral.tests.JPFBenchmark.benchmark06(-46.51723162472901,29.683028475112053,0 ) ;
  }

  @Test
  public void test3664() {
    coral.tests.JPFBenchmark.benchmark06(-4.6844866427366E-15,-1.5707962325817197,34.54930492408157 ) ;
  }

  @Test
  public void test3665() {
    coral.tests.JPFBenchmark.benchmark06(-47.04290581317301,7.057078053078072,-46.19814187487676 ) ;
  }

  @Test
  public void test3666() {
    coral.tests.JPFBenchmark.benchmark06(-4.714589207099317E-9,-163.43442435961802,1.4316332096541213 ) ;
  }

  @Test
  public void test3667() {
    coral.tests.JPFBenchmark.benchmark06(-47.29799171212843,96.07192953402256,-44.975603376343386 ) ;
  }

  @Test
  public void test3668() {
    coral.tests.JPFBenchmark.benchmark06(-4.745162968524767,79.43727970005614,30.258693868189056 ) ;
  }

  @Test
  public void test3669() {
    coral.tests.JPFBenchmark.benchmark06(47.457045789608514,15.325586092228122,1.0740363767938845 ) ;
  }

  @Test
  public void test3670() {
    coral.tests.JPFBenchmark.benchmark06(-47.813284076993014,-54.97520553555599,79.89395732968518 ) ;
  }

  @Test
  public void test3671() {
    coral.tests.JPFBenchmark.benchmark06(-47.984914373580345,-50.72768342495577,41.1455244101906 ) ;
  }

  @Test
  public void test3672() {
    coral.tests.JPFBenchmark.benchmark06(-4.799029804466019E-240,-1.5707963267948966,48.90536210650036 ) ;
  }

  @Test
  public void test3673() {
    coral.tests.JPFBenchmark.benchmark06(48.318890075272634,30.649046117735367,-10.00596166448932 ) ;
  }

  @Test
  public void test3674() {
    coral.tests.JPFBenchmark.benchmark06(-4.8530781160647726E-4,-0.8916847984600764,1.5674033766450959 ) ;
  }

  @Test
  public void test3675() {
    coral.tests.JPFBenchmark.benchmark06(-4.85691719907898E-15,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3676() {
    coral.tests.JPFBenchmark.benchmark06(-4.866794409715609E-209,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3677() {
    coral.tests.JPFBenchmark.benchmark06(-49.03324150368347,-65.6302681764609,-72.93118083302971 ) ;
  }

  @Test
  public void test3678() {
    coral.tests.JPFBenchmark.benchmark06(4.930380657631324E-32,-1.469144382749279,-13.47635180199511 ) ;
  }

  @Test
  public void test3679() {
    coral.tests.JPFBenchmark.benchmark06(4.930380657631324E-32,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3680() {
    coral.tests.JPFBenchmark.benchmark06(-49.34292108547933,23.71302566517342,-91.87931717882813 ) ;
  }

  @Test
  public void test3681() {
    coral.tests.JPFBenchmark.benchmark06(-4.9355158837307067E-178,-1.5707963267948966,-47.05064558557307 ) ;
  }

  @Test
  public void test3682() {
    coral.tests.JPFBenchmark.benchmark06(-4.9355158837307067E-178,-1.5707963267948966,-9.08870403049097E-306 ) ;
  }

  @Test
  public void test3683() {
    coral.tests.JPFBenchmark.benchmark06(-4.949898006380881E-15,0.0,0.0 ) ;
  }

  @Test
  public void test3684() {
    coral.tests.JPFBenchmark.benchmark06(-49.76102025747466,-96.72373593285677,30.734879147883674 ) ;
  }

  @Test
  public void test3685() {
    coral.tests.JPFBenchmark.benchmark06(49.93503859804022,-76.9695489134815,-48.81496845261572 ) ;
  }

  @Test
  public void test3686() {
    coral.tests.JPFBenchmark.benchmark06(-5.0081413939200676E-14,-88.2682757957142,71.0460741403844 ) ;
  }

  @Test
  public void test3687() {
    coral.tests.JPFBenchmark.benchmark06(5.0487097934144756E-29,-1.5707963267948966,66.20456908835611 ) ;
  }

  @Test
  public void test3688() {
    coral.tests.JPFBenchmark.benchmark06(50.71870269762667,-75.48532162669426,40.66898152930585 ) ;
  }

  @Test
  public void test3689() {
    coral.tests.JPFBenchmark.benchmark06(-5.081246585093098,90.34618764325694,54.22210174065131 ) ;
  }

  @Test
  public void test3690() {
    coral.tests.JPFBenchmark.benchmark06(-51.582531552759825,-74.9621420474144,-73.88946570130909 ) ;
  }

  @Test
  public void test3691() {
    coral.tests.JPFBenchmark.benchmark06(-51.67009337521131,-71.43379711642231,15.768187611388143 ) ;
  }

  @Test
  public void test3692() {
    coral.tests.JPFBenchmark.benchmark06(5.169878828456423E-26,-1.5707963267948912,-37.92293608224977 ) ;
  }

  @Test
  public void test3693() {
    coral.tests.JPFBenchmark.benchmark06(-5.18179631752407E-83,-1.5707963267948966,3.1415926535897896 ) ;
  }

  @Test
  public void test3694() {
    coral.tests.JPFBenchmark.benchmark06(-51.88125688498866,-17.8950048088913,22.481946207014403 ) ;
  }

  @Test
  public void test3695() {
    coral.tests.JPFBenchmark.benchmark06(-51.895749588530094,7.5848683968880835,-56.06427127447864 ) ;
  }

  @Test
  public void test3696() {
    coral.tests.JPFBenchmark.benchmark06(51.923833497992604,39.653530508878276,65.75905268583219 ) ;
  }

  @Test
  public void test3697() {
    coral.tests.JPFBenchmark.benchmark06(52.36846439170051,-92.59803955319414,-92.03076890828011 ) ;
  }

  @Test
  public void test3698() {
    coral.tests.JPFBenchmark.benchmark06(-52.441761293373325,51.329210587736156,15.286251310960594 ) ;
  }

  @Test
  public void test3699() {
    coral.tests.JPFBenchmark.benchmark06(-5.256583882625424E-15,-1.5707963267948966,43.5747617571631 ) ;
  }

  @Test
  public void test3700() {
    coral.tests.JPFBenchmark.benchmark06(-52.79689551824451,69.49036079014792,-91.79735330807057 ) ;
  }

  @Test
  public void test3701() {
    coral.tests.JPFBenchmark.benchmark06(-5.302300340703695,0,0 ) ;
  }

  @Test
  public void test3702() {
    coral.tests.JPFBenchmark.benchmark06(-53.32606879459567,75.75410567988214,-28.034492559224745 ) ;
  }

  @Test
  public void test3703() {
    coral.tests.JPFBenchmark.benchmark06(53.5638723909218,-82.93152618550572,-39.35165071302047 ) ;
  }

  @Test
  public void test3704() {
    coral.tests.JPFBenchmark.benchmark06(-53.66090074983709,-89.41254431305101,55.116604000045186 ) ;
  }

  @Test
  public void test3705() {
    coral.tests.JPFBenchmark.benchmark06(54.0092844809472,18.394292775309353,-36.180273154978984 ) ;
  }

  @Test
  public void test3706() {
    coral.tests.JPFBenchmark.benchmark06(-5.421010862427522E-20,-1.5707963267948966,9.424774444617059 ) ;
  }

  @Test
  public void test3707() {
    coral.tests.JPFBenchmark.benchmark06(-5.4266571032350524E-166,-0.30241144329802266,86.25081894448743 ) ;
  }

  @Test
  public void test3708() {
    coral.tests.JPFBenchmark.benchmark06(-5.4266571032350524E-166,-1.5707963267948966,69.46660212254793 ) ;
  }

  @Test
  public void test3709() {
    coral.tests.JPFBenchmark.benchmark06(-54.79450853670078,11.711510809527638,22.759267542143974 ) ;
  }

  @Test
  public void test3710() {
    coral.tests.JPFBenchmark.benchmark06(54.80991631249759,59.958402229417516,27.62464694404001 ) ;
  }

  @Test
  public void test3711() {
    coral.tests.JPFBenchmark.benchmark06(55.08560982027842,54.441156459549575,11.597222094478994 ) ;
  }

  @Test
  public void test3712() {
    coral.tests.JPFBenchmark.benchmark06(-5.53699647925121E-4,-88.28743745151286,1.5707963267948957 ) ;
  }

  @Test
  public void test3713() {
    coral.tests.JPFBenchmark.benchmark06(-5.551115123125783E-17,-0.07256516730353864,-1.5707963267948966 ) ;
  }

  @Test
  public void test3714() {
    coral.tests.JPFBenchmark.benchmark06(5.551115123125783E-17,-0.631028099253105,81.60165350104889 ) ;
  }

  @Test
  public void test3715() {
    coral.tests.JPFBenchmark.benchmark06(5.551115123125783E-17,-0.8730730985598569,-67.1375421425725 ) ;
  }

  @Test
  public void test3716() {
    coral.tests.JPFBenchmark.benchmark06(5.551115123125783E-17,-1.5707963267948961,-26.69093121391054 ) ;
  }

  @Test
  public void test3717() {
    coral.tests.JPFBenchmark.benchmark06(5.551115123125783E-17,-1.5707963267948961,26.855974139060606 ) ;
  }

  @Test
  public void test3718() {
    coral.tests.JPFBenchmark.benchmark06(5.551115123125783E-17,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3719() {
    coral.tests.JPFBenchmark.benchmark06(5.551115123125783E-17,-1.5707963267948966,-16.188371535923515 ) ;
  }

  @Test
  public void test3720() {
    coral.tests.JPFBenchmark.benchmark06(-5.551115123125783E-17,-1.5707963267948966,3.141592653589793 ) ;
  }

  @Test
  public void test3721() {
    coral.tests.JPFBenchmark.benchmark06(-5.551115123125783E-17,-1.5707963267948966,-91.10618695399634 ) ;
  }

  @Test
  public void test3722() {
    coral.tests.JPFBenchmark.benchmark06(-5.555471752779739E-7,-95.81856837463611,91.08761921191562 ) ;
  }

  @Test
  public void test3723() {
    coral.tests.JPFBenchmark.benchmark06(-5.572729765193437E-15,-0.11678368700147337,-58.033584684046446 ) ;
  }

  @Test
  public void test3724() {
    coral.tests.JPFBenchmark.benchmark06(-5.632512584963976,75.8416853189864,66.18550191375434 ) ;
  }

  @Test
  public void test3725() {
    coral.tests.JPFBenchmark.benchmark06(-5.661224193286058E-17,-1.5707963267948937,-1.5707963267948966 ) ;
  }

  @Test
  public void test3726() {
    coral.tests.JPFBenchmark.benchmark06(56.926639216371,-52.51334781893695,-61.88266439525132 ) ;
  }

  @Test
  public void test3727() {
    coral.tests.JPFBenchmark.benchmark06(-56.99383101048916,-80.8627699860895,-59.16889001781176 ) ;
  }

  @Test
  public void test3728() {
    coral.tests.JPFBenchmark.benchmark06(-5.755274637922441E-17,-1.5707963267948966,84.82300164692867 ) ;
  }

  @Test
  public void test3729() {
    coral.tests.JPFBenchmark.benchmark06(5.7890369718123935,-52.44997579412984,78.31763621312811 ) ;
  }

  @Test
  public void test3730() {
    coral.tests.JPFBenchmark.benchmark06(-58.025557346278234,0,0 ) ;
  }

  @Test
  public void test3731() {
    coral.tests.JPFBenchmark.benchmark06(-58.10933619081897,-71.54903477709269,65.89639773588371 ) ;
  }

  @Test
  public void test3732() {
    coral.tests.JPFBenchmark.benchmark06(58.362192691974826,-76.78866054644995,-45.49660853983441 ) ;
  }

  @Test
  public void test3733() {
    coral.tests.JPFBenchmark.benchmark06(-5.852095443365248E-98,-1.4861420478040714,-8.274964006661444 ) ;
  }

  @Test
  public void test3734() {
    coral.tests.JPFBenchmark.benchmark06(5.885900790774556,15.351240089260301,-62.33777973274843 ) ;
  }

  @Test
  public void test3735() {
    coral.tests.JPFBenchmark.benchmark06(59.17535644838338,29.61140746305935,56.83258146809413 ) ;
  }

  @Test
  public void test3736() {
    coral.tests.JPFBenchmark.benchmark06(59.27794297754883,3.6195463369515153,-65.30033890334019 ) ;
  }

  @Test
  public void test3737() {
    coral.tests.JPFBenchmark.benchmark06(-59.34506892718734,0,0 ) ;
  }

  @Test
  public void test3738() {
    coral.tests.JPFBenchmark.benchmark06(59.47972329196875,25.68388554375582,56.62380709869734 ) ;
  }

  @Test
  public void test3739() {
    coral.tests.JPFBenchmark.benchmark06(-5.963027355575047E-16,8.673617379884035E-19,89.08869707878725 ) ;
  }

  @Test
  public void test3740() {
    coral.tests.JPFBenchmark.benchmark06(60.03103607228002,-23.669020573017164,6.239534416335999 ) ;
  }

  @Test
  public void test3741() {
    coral.tests.JPFBenchmark.benchmark06(-60.104194926982046,98.28280570438031,-17.52119481070271 ) ;
  }

  @Test
  public void test3742() {
    coral.tests.JPFBenchmark.benchmark06(60.1796888989216,-96.5149077478866,40.29907180865561 ) ;
  }

  @Test
  public void test3743() {
    coral.tests.JPFBenchmark.benchmark06(-60.40131455023783,-95.37316446687818,25.864231200405868 ) ;
  }

  @Test
  public void test3744() {
    coral.tests.JPFBenchmark.benchmark06(60.54871678205899,69.60476369746985,-49.00551376850402 ) ;
  }

  @Test
  public void test3745() {
    coral.tests.JPFBenchmark.benchmark06(-6.1005090750862365,-67.68090167416057,93.63879238632788 ) ;
  }

  @Test
  public void test3746() {
    coral.tests.JPFBenchmark.benchmark06(-6.123234008987933E-17,0.0,0.0 ) ;
  }

  @Test
  public void test3747() {
    coral.tests.JPFBenchmark.benchmark06(-61.538958397036644,62.516087833577046,19.982836209356947 ) ;
  }

  @Test
  public void test3748() {
    coral.tests.JPFBenchmark.benchmark06(-6.169394854663383E-179,-0.8673573144627632,31.94948197802256 ) ;
  }

  @Test
  public void test3749() {
    coral.tests.JPFBenchmark.benchmark06(-61.716928896926994,-25.5819609492643,4.982218231402811 ) ;
  }

  @Test
  public void test3750() {
    coral.tests.JPFBenchmark.benchmark06(-61.777126397232074,34.82298125806324,70.4407763730621 ) ;
  }

  @Test
  public void test3751() {
    coral.tests.JPFBenchmark.benchmark06(61.923380989515294,-78.02485172012157,-27.337489595012897 ) ;
  }

  @Test
  public void test3752() {
    coral.tests.JPFBenchmark.benchmark06(-62.348047173731594,98.68180462991688,72.66659934476851 ) ;
  }

  @Test
  public void test3753() {
    coral.tests.JPFBenchmark.benchmark06(-6.2565096724471904E-148,-1.5707963267948966,-34.62906408859383 ) ;
  }

  @Test
  public void test3754() {
    coral.tests.JPFBenchmark.benchmark06(-62.6076258236322,-56.776056102118645,-72.31126636370912 ) ;
  }

  @Test
  public void test3755() {
    coral.tests.JPFBenchmark.benchmark06(-6.3174603311753045E-176,-31.64344015621505,0.0 ) ;
  }

  @Test
  public void test3756() {
    coral.tests.JPFBenchmark.benchmark06(-63.18890574039695,94.67365442074251,0 ) ;
  }

  @Test
  public void test3757() {
    coral.tests.JPFBenchmark.benchmark06(-63.22954699995349,-21.729684953877808,-95.71842180300065 ) ;
  }

  @Test
  public void test3758() {
    coral.tests.JPFBenchmark.benchmark06(63.30346286981546,37.48952263519607,-69.04069237249146 ) ;
  }

  @Test
  public void test3759() {
    coral.tests.JPFBenchmark.benchmark06(63.880900247213106,44.60985511066556,43.71481393240762 ) ;
  }

  @Test
  public void test3760() {
    coral.tests.JPFBenchmark.benchmark06(63.97284473482989,-54.529344701068474,-4.0450708522311345 ) ;
  }

  @Test
  public void test3761() {
    coral.tests.JPFBenchmark.benchmark06(64.11608260416418,-38.06716567320976,50.575226909606045 ) ;
  }

  @Test
  public void test3762() {
    coral.tests.JPFBenchmark.benchmark06(-6.41832475487647E-18,-1.5707963267948912,-14.137166706742391 ) ;
  }

  @Test
  public void test3763() {
    coral.tests.JPFBenchmark.benchmark06(6.429203739152951,-22.411896777025397,0 ) ;
  }

  @Test
  public void test3764() {
    coral.tests.JPFBenchmark.benchmark06(6.436011521774966,5.431770964118105E-6,-1.2397196701289682E-4 ) ;
  }

  @Test
  public void test3765() {
    coral.tests.JPFBenchmark.benchmark06(-6.438765418408888E-4,-32.983053360000035,91.10618543000382 ) ;
  }

  @Test
  public void test3766() {
    coral.tests.JPFBenchmark.benchmark06(-64.55658789808203,56.9581096048189,-2.4253465500752753 ) ;
  }

  @Test
  public void test3767() {
    coral.tests.JPFBenchmark.benchmark06(-6.472665310144586E-16,-1.570796326656163,27.821252098209868 ) ;
  }

  @Test
  public void test3768() {
    coral.tests.JPFBenchmark.benchmark06(-64.88840818891998,87.58343167839132,-35.49358132581058 ) ;
  }

  @Test
  public void test3769() {
    coral.tests.JPFBenchmark.benchmark06(-6.497122377196543E-114,-1.5707963267948966,3.1415926535897967 ) ;
  }

  @Test
  public void test3770() {
    coral.tests.JPFBenchmark.benchmark06(65.23982026711872,72.62915415822164,33.52607941206716 ) ;
  }

  @Test
  public void test3771() {
    coral.tests.JPFBenchmark.benchmark06(65.90243685896837,74.57605911605654,97.36723735561947 ) ;
  }

  @Test
  public void test3772() {
    coral.tests.JPFBenchmark.benchmark06(66.11170846664726,-5.16196644312727,99.1252425930488 ) ;
  }

  @Test
  public void test3773() {
    coral.tests.JPFBenchmark.benchmark06(66.20948594675505,-63.74882271392628,50.03302407065854 ) ;
  }

  @Test
  public void test3774() {
    coral.tests.JPFBenchmark.benchmark06(-66.36262278276337,88.10816441756498,72.94592098739182 ) ;
  }

  @Test
  public void test3775() {
    coral.tests.JPFBenchmark.benchmark06(-6.642186622182053E-6,-1.5706293829699116,-40.803282376590836 ) ;
  }

  @Test
  public void test3776() {
    coral.tests.JPFBenchmark.benchmark06(-6.656013887802287E-31,-1.5707963267948966,-3.141592653589793 ) ;
  }

  @Test
  public void test3777() {
    coral.tests.JPFBenchmark.benchmark06(-66.58896110876462,-1.0173201499644051,-66.2141003302104 ) ;
  }

  @Test
  public void test3778() {
    coral.tests.JPFBenchmark.benchmark06(66.7115670420315,-63.10431621706052,9.907959402599715 ) ;
  }

  @Test
  public void test3779() {
    coral.tests.JPFBenchmark.benchmark06(66.77165212799645,-78.95880302781215,-42.236153495139874 ) ;
  }

  @Test
  public void test3780() {
    coral.tests.JPFBenchmark.benchmark06(-6.681911775230489E-51,-1.5707963267948966,34.55751918948642 ) ;
  }

  @Test
  public void test3781() {
    coral.tests.JPFBenchmark.benchmark06(-6.704728693456133,-51.47763171853059,14.863115298021825 ) ;
  }

  @Test
  public void test3782() {
    coral.tests.JPFBenchmark.benchmark06(-67.13398398448918,-77.68669365236804,-26.373437253848067 ) ;
  }

  @Test
  public void test3783() {
    coral.tests.JPFBenchmark.benchmark06(67.38781089357238,87.98293391773154,-95.78312679745262 ) ;
  }

  @Test
  public void test3784() {
    coral.tests.JPFBenchmark.benchmark06(-6.747596916249624E-14,-1.5707963267948966,3.8934355277724873E-208 ) ;
  }

  @Test
  public void test3785() {
    coral.tests.JPFBenchmark.benchmark06(6.776263578034403E-21,-0.5430776825304412,-21.25245643570041 ) ;
  }

  @Test
  public void test3786() {
    coral.tests.JPFBenchmark.benchmark06(6.776263578034403E-21,-1.5707963267948966,0.0322107875093073 ) ;
  }

  @Test
  public void test3787() {
    coral.tests.JPFBenchmark.benchmark06(-6.776263578034403E-21,-1.5707963267948966,34.55750061968548 ) ;
  }

  @Test
  public void test3788() {
    coral.tests.JPFBenchmark.benchmark06(6.776263578034403E-21,-88.37716419745624,1.0803835931480625 ) ;
  }

  @Test
  public void test3789() {
    coral.tests.JPFBenchmark.benchmark06(68.66940106628914,-32.5414105665035,-82.09000114669023 ) ;
  }

  @Test
  public void test3790() {
    coral.tests.JPFBenchmark.benchmark06(68.69142803823132,44.41759837253997,-29.61597267861515 ) ;
  }

  @Test
  public void test3791() {
    coral.tests.JPFBenchmark.benchmark06(-68.72971756418882,80.67168865507489,-2.6697100499114583 ) ;
  }

  @Test
  public void test3792() {
    coral.tests.JPFBenchmark.benchmark06(69.13924717880815,38.43445608963597,30.28548854039917 ) ;
  }

  @Test
  public void test3793() {
    coral.tests.JPFBenchmark.benchmark06(-6.938893903444544E-18,-1.5707962764878944,-55.40707519597553 ) ;
  }

  @Test
  public void test3794() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-0.030886011024172544,-1.5707963267948966 ) ;
  }

  @Test
  public void test3795() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-0.11754407247720383,-1.5707963267948948 ) ;
  }

  @Test
  public void test3796() {
    coral.tests.JPFBenchmark.benchmark06(-6.938893903907228E-18,-0.2243309604917575,-0.5593623673953979 ) ;
  }

  @Test
  public void test3797() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-0.3396546467573541,48.98385911764747 ) ;
  }

  @Test
  public void test3798() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-1.4552900405305371,0.0 ) ;
  }

  @Test
  public void test3799() {
    coral.tests.JPFBenchmark.benchmark06(-6.938893903907228E-18,-1.570788085529597,-116.23886600087035 ) ;
  }

  @Test
  public void test3800() {
    coral.tests.JPFBenchmark.benchmark06(-6.938893903907228E-18,-1.5707963267445757,-1.5707963267948966 ) ;
  }

  @Test
  public void test3801() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-1.5707963267948966,43.74765577792738 ) ;
  }

  @Test
  public void test3802() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-1.5707963267948966,66.56432018239089 ) ;
  }

  @Test
  public void test3803() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-45.53629631926103,0.0 ) ;
  }

  @Test
  public void test3804() {
    coral.tests.JPFBenchmark.benchmark06(-6.938893903907228E-18,-5.803137521484056E-4,1.5707963267948983 ) ;
  }

  @Test
  public void test3805() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-95.71012318381885,2.596680717104883 ) ;
  }

  @Test
  public void test3806() {
    coral.tests.JPFBenchmark.benchmark06(-6.942966733153143E-164,-1.5707963267948966,-3.1415926535897927 ) ;
  }

  @Test
  public void test3807() {
    coral.tests.JPFBenchmark.benchmark06(-7.103055732118421E-15,-1.5707958509748887,-91.10617480061656 ) ;
  }

  @Test
  public void test3808() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-0.020381025005399067,-96.78915801680859 ) ;
  }

  @Test
  public void test3809() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-0.3710142570505024,14.532909835834076 ) ;
  }

  @Test
  public void test3810() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.0760627625719792,-1.5707963267948961 ) ;
  }

  @Test
  public void test3811() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.5707963267948948,-82.24444955687405 ) ;
  }

  @Test
  public void test3812() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.5707963267948966,-3.14296483998736 ) ;
  }

  @Test
  public void test3813() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.5707963267948966,39.53073897097181 ) ;
  }

  @Test
  public void test3814() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.5707963267948966,44.32494733746513 ) ;
  }

  @Test
  public void test3815() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.5707963267948966,53.38409863851402 ) ;
  }

  @Test
  public void test3816() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-26.97458528487057,1.5707963267948912 ) ;
  }

  @Test
  public void test3817() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-95.7496958600141,-6.712389036566421 ) ;
  }

  @Test
  public void test3818() {
    coral.tests.JPFBenchmark.benchmark06(-7.109877728605205E-15,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3819() {
    coral.tests.JPFBenchmark.benchmark06(-7.134842119918035E-5,-1.5707963267948966,2.570796326794872 ) ;
  }

  @Test
  public void test3820() {
    coral.tests.JPFBenchmark.benchmark06(71.94407309819607,66.58501018291366,97.63720013273473 ) ;
  }

  @Test
  public void test3821() {
    coral.tests.JPFBenchmark.benchmark06(-7.199227955341564E-29,-1.5707963267948966,-122.85078463603432 ) ;
  }

  @Test
  public void test3822() {
    coral.tests.JPFBenchmark.benchmark06(-7.213264545145106E-130,-3.389060494942474E-5,-5.137776166125686 ) ;
  }

  @Test
  public void test3823() {
    coral.tests.JPFBenchmark.benchmark06(-7.2232635759455274E-9,-158.30121137914887,95.87917507908617 ) ;
  }

  @Test
  public void test3824() {
    coral.tests.JPFBenchmark.benchmark06(72.72019150324101,26.287519689462854,-11.564255870669072 ) ;
  }

  @Test
  public void test3825() {
    coral.tests.JPFBenchmark.benchmark06(-7.31511930420656E-99,-0.8662045122981803,-10.876613294133108 ) ;
  }

  @Test
  public void test3826() {
    coral.tests.JPFBenchmark.benchmark06(-7.31511930420656E-99,-1.2586873304912576,-1.5707963267948912 ) ;
  }

  @Test
  public void test3827() {
    coral.tests.JPFBenchmark.benchmark06(-7.34393729649502E-13,0.0,-1.2338789709326767E-178 ) ;
  }

  @Test
  public void test3828() {
    coral.tests.JPFBenchmark.benchmark06(-7.3501124335012E-7,-1.5707963267948841,-116.22748518266047 ) ;
  }

  @Test
  public void test3829() {
    coral.tests.JPFBenchmark.benchmark06(73.51393358901055,-43.010474164398914,-69.43899625935128 ) ;
  }

  @Test
  public void test3830() {
    coral.tests.JPFBenchmark.benchmark06(-74.16786881358783,-46.34657212544433,-97.88584367491408 ) ;
  }

  @Test
  public void test3831() {
    coral.tests.JPFBenchmark.benchmark06(-74.25812345979956,38.61521485488487,-26.61303978934643 ) ;
  }

  @Test
  public void test3832() {
    coral.tests.JPFBenchmark.benchmark06(-74.77729980612457,-67.71510165797159,48.280940917011236 ) ;
  }

  @Test
  public void test3833() {
    coral.tests.JPFBenchmark.benchmark06(74.78004542969362,-75.11199286161067,93.89782623539571 ) ;
  }

  @Test
  public void test3834() {
    coral.tests.JPFBenchmark.benchmark06(75.08121566763847,50.847973122326096,85.96562205314234 ) ;
  }

  @Test
  public void test3835() {
    coral.tests.JPFBenchmark.benchmark06(75.2121238412874,-86.99336763847943,90.24967185043025 ) ;
  }

  @Test
  public void test3836() {
    coral.tests.JPFBenchmark.benchmark06(-75.47119646048861,-97.01578740231366,39.50278868261455 ) ;
  }

  @Test
  public void test3837() {
    coral.tests.JPFBenchmark.benchmark06(7.555257406905262E-17,-0.557731609266193,-46.60808234261362 ) ;
  }

  @Test
  public void test3838() {
    coral.tests.JPFBenchmark.benchmark06(-75.72853693798777,-14.461278874655378,-43.127729102343395 ) ;
  }

  @Test
  public void test3839() {
    coral.tests.JPFBenchmark.benchmark06(-76.16671914403261,88.51139691096199,55.63545803387521 ) ;
  }

  @Test
  public void test3840() {
    coral.tests.JPFBenchmark.benchmark06(-76.60465790959618,-61.889282076619345,2.7475684270256977 ) ;
  }

  @Test
  public void test3841() {
    coral.tests.JPFBenchmark.benchmark06(-76.6986074846131,-47.458991172303435,-64.17397382755124 ) ;
  }

  @Test
  public void test3842() {
    coral.tests.JPFBenchmark.benchmark06(76.99670304604501,44.818413585340465,-56.52184340480299 ) ;
  }

  @Test
  public void test3843() {
    coral.tests.JPFBenchmark.benchmark06(77.06235239046131,-43.9599633459995,-40.47753303068718 ) ;
  }

  @Test
  public void test3844() {
    coral.tests.JPFBenchmark.benchmark06(77.24788821827721,-61.13379403433199,32.80828775176411 ) ;
  }

  @Test
  public void test3845() {
    coral.tests.JPFBenchmark.benchmark06(77.3742597205783,63.12504018872028,-44.20545272370329 ) ;
  }

  @Test
  public void test3846() {
    coral.tests.JPFBenchmark.benchmark06(-77.37642943457026,77.91682498006273,52.64618002185122 ) ;
  }

  @Test
  public void test3847() {
    coral.tests.JPFBenchmark.benchmark06(-77.37771362095667,84.06657239539584,-61.0513555917982 ) ;
  }

  @Test
  public void test3848() {
    coral.tests.JPFBenchmark.benchmark06(-77.43585021398914,96.07841938584008,-37.03187198834102 ) ;
  }

  @Test
  public void test3849() {
    coral.tests.JPFBenchmark.benchmark06(77.55587375105256,43.13455318423121,-4.602547344760708 ) ;
  }

  @Test
  public void test3850() {
    coral.tests.JPFBenchmark.benchmark06(-78.1249921920583,-43.336162297132304,73.28455840020689 ) ;
  }

  @Test
  public void test3851() {
    coral.tests.JPFBenchmark.benchmark06(-7.854804710270422E-10,-1.5707963267948983,109.27786021507205 ) ;
  }

  @Test
  public void test3852() {
    coral.tests.JPFBenchmark.benchmark06(-78.57656509264723,86.28047755051045,15.143822685916945 ) ;
  }

  @Test
  public void test3853() {
    coral.tests.JPFBenchmark.benchmark06(-7.857908042623921E-4,-1.5706393695939276,21.96869867187263 ) ;
  }

  @Test
  public void test3854() {
    coral.tests.JPFBenchmark.benchmark06(-7.89593986844579E-16,-1.5707963267948972,58.98345030253607 ) ;
  }

  @Test
  public void test3855() {
    coral.tests.JPFBenchmark.benchmark06(79.0908175530879,70.92037432667598,-2.407218589144989 ) ;
  }

  @Test
  public void test3856() {
    coral.tests.JPFBenchmark.benchmark06(79.11690534246395,-28.916100093814805,73.48257119064255 ) ;
  }

  @Test
  public void test3857() {
    coral.tests.JPFBenchmark.benchmark06(-79.5943626028322,38.775613854879566,-74.3408797855465 ) ;
  }

  @Test
  public void test3858() {
    coral.tests.JPFBenchmark.benchmark06(-79.71900393954473,-77.92049376390884,-71.72450366148284 ) ;
  }

  @Test
  public void test3859() {
    coral.tests.JPFBenchmark.benchmark06(79.80587685542079,57.36281309778019,-90.37904321508094 ) ;
  }

  @Test
  public void test3860() {
    coral.tests.JPFBenchmark.benchmark06(-79.83878001801989,-82.38131151609099,52.95179070006799 ) ;
  }

  @Test
  public void test3861() {
    coral.tests.JPFBenchmark.benchmark06(-7.985816417016816E-16,-1.5707963267948974,0.0 ) ;
  }

  @Test
  public void test3862() {
    coral.tests.JPFBenchmark.benchmark06(79.87281876334981,-20.576712955221794,-69.69547737085738 ) ;
  }

  @Test
  public void test3863() {
    coral.tests.JPFBenchmark.benchmark06(-79.89913182704464,-60.17864025942876,-36.101746520719715 ) ;
  }

  @Test
  public void test3864() {
    coral.tests.JPFBenchmark.benchmark06(-79.90993587174033,0,0 ) ;
  }

  @Test
  public void test3865() {
    coral.tests.JPFBenchmark.benchmark06(-79.93014468476454,-37.00600857806273,-37.57998785681824 ) ;
  }

  @Test
  public void test3866() {
    coral.tests.JPFBenchmark.benchmark06(-8.004430388431373E-15,2.465190328815662E-32,-24.164116219885074 ) ;
  }

  @Test
  public void test3867() {
    coral.tests.JPFBenchmark.benchmark06(-80.2428787947364,12.085567346637376,11.051323976236091 ) ;
  }

  @Test
  public void test3868() {
    coral.tests.JPFBenchmark.benchmark06(-80.2488137639809,-28.2454843782304,95.8718400950028 ) ;
  }

  @Test
  public void test3869() {
    coral.tests.JPFBenchmark.benchmark06(80.5834722863564,29.34166488430901,65.22126394873004 ) ;
  }

  @Test
  public void test3870() {
    coral.tests.JPFBenchmark.benchmark06(-80.5879437711734,-82.7989521124647,77.7940922888312 ) ;
  }

  @Test
  public void test3871() {
    coral.tests.JPFBenchmark.benchmark06(8.100702793150172E-12,-1.570796326794897,-1.5707963267949054 ) ;
  }

  @Test
  public void test3872() {
    coral.tests.JPFBenchmark.benchmark06(-8.1214138794100775E-115,-32.54663456033887,46.2298529699845 ) ;
  }

  @Test
  public void test3873() {
    coral.tests.JPFBenchmark.benchmark06(-81.41075859141708,81.87397203225365,13.284278110459752 ) ;
  }

  @Test
  public void test3874() {
    coral.tests.JPFBenchmark.benchmark06(82.08899575070566,37.55126716532541,-1.0862257328737854 ) ;
  }

  @Test
  public void test3875() {
    coral.tests.JPFBenchmark.benchmark06(82.74433863274285,-62.56948501078239,-25.255329090247102 ) ;
  }

  @Test
  public void test3876() {
    coral.tests.JPFBenchmark.benchmark06(-8.317534977153853E-15,0.0,6.123233995736766E-17 ) ;
  }

  @Test
  public void test3877() {
    coral.tests.JPFBenchmark.benchmark06(-8.333599735234117E-4,1.3552527156068805E-20,95.75905155024594 ) ;
  }

  @Test
  public void test3878() {
    coral.tests.JPFBenchmark.benchmark06(-83.55953669332266,25.380299305348558,-0.7876451336606038 ) ;
  }

  @Test
  public void test3879() {
    coral.tests.JPFBenchmark.benchmark06(-8.375485392277923,-55.348377678784466,87.97510645335836 ) ;
  }

  @Test
  public void test3880() {
    coral.tests.JPFBenchmark.benchmark06(-83.97683721662293,92.17309281098568,-15.948457250315727 ) ;
  }

  @Test
  public void test3881() {
    coral.tests.JPFBenchmark.benchmark06(84.34150201750666,31.558948089094883,41.425379365360754 ) ;
  }

  @Test
  public void test3882() {
    coral.tests.JPFBenchmark.benchmark06(84.3712688514029,5.927738059988911,-51.89593318652863 ) ;
  }

  @Test
  public void test3883() {
    coral.tests.JPFBenchmark.benchmark06(8.470329472543003E-22,-0.3952301247657517,0.0 ) ;
  }

  @Test
  public void test3884() {
    coral.tests.JPFBenchmark.benchmark06(8.470329472543003E-22,-0.7807352620090362,-25.01219584638881 ) ;
  }

  @Test
  public void test3885() {
    coral.tests.JPFBenchmark.benchmark06(8.470329472543003E-22,-1.5707963267948966,-71.47147167494015 ) ;
  }

  @Test
  public void test3886() {
    coral.tests.JPFBenchmark.benchmark06(-84.71687997357462,-92.26053722008807,-66.57973232291181 ) ;
  }

  @Test
  public void test3887() {
    coral.tests.JPFBenchmark.benchmark06(84.73707558041605,49.41763282364212,-10.38443360411651 ) ;
  }

  @Test
  public void test3888() {
    coral.tests.JPFBenchmark.benchmark06(-84.85813980326328,-20.394062559063002,78.63424322047334 ) ;
  }

  @Test
  public void test3889() {
    coral.tests.JPFBenchmark.benchmark06(-8.49631307881676E-14,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3890() {
    coral.tests.JPFBenchmark.benchmark06(85.49928135751745,-2.8330326818330747,-86.25249832362782 ) ;
  }

  @Test
  public void test3891() {
    coral.tests.JPFBenchmark.benchmark06(-8.552847072295026E-50,-1.5707963267948966,-40.841138395738135 ) ;
  }

  @Test
  public void test3892() {
    coral.tests.JPFBenchmark.benchmark06(-8.565092422660314E-19,-1.5707963267948966,-116.23887160489883 ) ;
  }

  @Test
  public void test3893() {
    coral.tests.JPFBenchmark.benchmark06(86.04619926736729,49.49965865181508,37.162910683802835 ) ;
  }

  @Test
  public void test3894() {
    coral.tests.JPFBenchmark.benchmark06(86.16678563058335,-57.23643860381977,-13.8973058152215 ) ;
  }

  @Test
  public void test3895() {
    coral.tests.JPFBenchmark.benchmark06(-86.17604680345804,0,0 ) ;
  }

  @Test
  public void test3896() {
    coral.tests.JPFBenchmark.benchmark06(-86.44165396266388,53.799587772404266,96.0893346254312 ) ;
  }

  @Test
  public void test3897() {
    coral.tests.JPFBenchmark.benchmark06(-86.64350076530792,67.8845251629543,83.73461679525275 ) ;
  }

  @Test
  public void test3898() {
    coral.tests.JPFBenchmark.benchmark06(-8.673617379884035E-19,-1.5707963209915818,-4.712645463303167 ) ;
  }

  @Test
  public void test3899() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-1.5707963267948966,-0.8588832048843675 ) ;
  }

  @Test
  public void test3900() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-1.5707963267948966,15.965509052672815 ) ;
  }

  @Test
  public void test3901() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-32.44392712450842,88.15329237020467 ) ;
  }

  @Test
  public void test3902() {
    coral.tests.JPFBenchmark.benchmark06(-8.679186524344075,96.98802914320126,-40.98922765746886 ) ;
  }

  @Test
  public void test3903() {
    coral.tests.JPFBenchmark.benchmark06(-8.682651365176084E-165,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3904() {
    coral.tests.JPFBenchmark.benchmark06(-86.84949483108915,82.41071956958936,84.04225221529103 ) ;
  }

  @Test
  public void test3905() {
    coral.tests.JPFBenchmark.benchmark06(-8.756829543622331E-16,1.1102230246251565E-16,2.3229753756000235 ) ;
  }

  @Test
  public void test3906() {
    coral.tests.JPFBenchmark.benchmark06(-8.767237396033612E-193,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3907() {
    coral.tests.JPFBenchmark.benchmark06(-8.801300678108682E-18,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3908() {
    coral.tests.JPFBenchmark.benchmark06(-8.805254571710335E-134,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test3909() {
    coral.tests.JPFBenchmark.benchmark06(88.3622813350201,-74.77482686344774,22.039547715708437 ) ;
  }

  @Test
  public void test3910() {
    coral.tests.JPFBenchmark.benchmark06(88.6229000427015,81.46317104577298,2.70319903882546 ) ;
  }

  @Test
  public void test3911() {
    coral.tests.JPFBenchmark.benchmark06(-88.73200220407516,34.11507562896867,-61.748187021827405 ) ;
  }

  @Test
  public void test3912() {
    coral.tests.JPFBenchmark.benchmark06(-8.881046412195291E-15,-1.5707963267948966,-56.241510283905406 ) ;
  }

  @Test
  public void test3913() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-0.009681802892274327,-68.85574467890763 ) ;
  }

  @Test
  public void test3914() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-0.1811723909878511,1.5707963267948966 ) ;
  }

  @Test
  public void test3915() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5093922749130613,13.054423502158357 ) ;
  }

  @Test
  public void test3916() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963263968496,-55.49111271944466 ) ;
  }

  @Test
  public void test3917() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948912,-19.539077749822052 ) ;
  }

  @Test
  public void test3918() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948957,-1.5685900055975424 ) ;
  }

  @Test
  public void test3919() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948966,-0.12179166125350795 ) ;
  }

  @Test
  public void test3920() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948966,10.58316769245809 ) ;
  }

  @Test
  public void test3921() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948966,14.432264140944625 ) ;
  }

  @Test
  public void test3922() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948966,1.5707963136792988 ) ;
  }

  @Test
  public void test3923() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3924() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948966,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test3925() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948966,-90.99298026707311 ) ;
  }

  @Test
  public void test3926() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-38.86693605546766,1.5707963267948961 ) ;
  }

  @Test
  public void test3927() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-44.1528050994298,44.38902070082905 ) ;
  }

  @Test
  public void test3928() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-86.33115117633949,0 ) ;
  }

  @Test
  public void test3929() {
    coral.tests.JPFBenchmark.benchmark06(-8.89103499794031E-162,-1.5707963267948966,-48.043843342760944 ) ;
  }

  @Test
  public void test3930() {
    coral.tests.JPFBenchmark.benchmark06(89.02590011049742,43.52606315278541,-17.603798843302982 ) ;
  }

  @Test
  public void test3931() {
    coral.tests.JPFBenchmark.benchmark06(-8.929588994392773E-103,-1.5707963267948966,9.937999701922248 ) ;
  }

  @Test
  public void test3932() {
    coral.tests.JPFBenchmark.benchmark06(-8.934073361530253E-16,-1.5707963267948966,70.82606226010998 ) ;
  }

  @Test
  public void test3933() {
    coral.tests.JPFBenchmark.benchmark06(-89.49350847031852,61.794343625436426,-19.539776737805852 ) ;
  }

  @Test
  public void test3934() {
    coral.tests.JPFBenchmark.benchmark06(-8.988439681560671E-16,-0.1397278139496535,38.54745589119695 ) ;
  }

  @Test
  public void test3935() {
    coral.tests.JPFBenchmark.benchmark06(-9.001614761688494E-5,-1.5707963267948966,-3.142207095941872 ) ;
  }

  @Test
  public void test3936() {
    coral.tests.JPFBenchmark.benchmark06(-90.15653209281302,94.21235198392114,62.9847282902532 ) ;
  }

  @Test
  public void test3937() {
    coral.tests.JPFBenchmark.benchmark06(-9.016580681431383E-131,-1.2470631379742656,8.532856819277114 ) ;
  }

  @Test
  public void test3938() {
    coral.tests.JPFBenchmark.benchmark06(-9.016580681431383E-131,-88.27701356997542,46.43687048545898 ) ;
  }

  @Test
  public void test3939() {
    coral.tests.JPFBenchmark.benchmark06(90.32693994950532,66.38578720357066,81.82085123231565 ) ;
  }

  @Test
  public void test3940() {
    coral.tests.JPFBenchmark.benchmark06(-9.055679078826712E-72,-1.5707963267948966,-49.58185047793192 ) ;
  }

  @Test
  public void test3941() {
    coral.tests.JPFBenchmark.benchmark06(-9.055689265011117E-4,-1.5700693537814912,-40.885103004539374 ) ;
  }

  @Test
  public void test3942() {
    coral.tests.JPFBenchmark.benchmark06(90.56890462096672,50.94694577962986,82.64928446390485 ) ;
  }

  @Test
  public void test3943() {
    coral.tests.JPFBenchmark.benchmark06(90.59968156758805,76.01421375567557,94.16675570490176 ) ;
  }

  @Test
  public void test3944() {
    coral.tests.JPFBenchmark.benchmark06(90.64746463573547,-42.13750779455096,-92.02243549055224 ) ;
  }

  @Test
  public void test3945() {
    coral.tests.JPFBenchmark.benchmark06(-91.27202926399673,-53.19605862940231,0 ) ;
  }

  @Test
  public void test3946() {
    coral.tests.JPFBenchmark.benchmark06(9.128936412390544,61.83593293471304,-72.57232015317612 ) ;
  }

  @Test
  public void test3947() {
    coral.tests.JPFBenchmark.benchmark06(-91.32222690176172,-29.828794045428623,-17.003328101200637 ) ;
  }

  @Test
  public void test3948() {
    coral.tests.JPFBenchmark.benchmark06(-91.59858296155039,94.22264198247291,-77.34248303010567 ) ;
  }

  @Test
  public void test3949() {
    coral.tests.JPFBenchmark.benchmark06(-9.273015376718553E-69,-1.5707963267948966,-21.115577549611444 ) ;
  }

  @Test
  public void test3950() {
    coral.tests.JPFBenchmark.benchmark06(-92.9842055775173,-35.660192274181,-82.90212709030041 ) ;
  }

  @Test
  public void test3951() {
    coral.tests.JPFBenchmark.benchmark06(93.07184594114949,-25.86042634532197,-3.4062151999942643 ) ;
  }

  @Test
  public void test3952() {
    coral.tests.JPFBenchmark.benchmark06(-93.1825729322602,-14.34430055452411,94.20996825440534 ) ;
  }

  @Test
  public void test3953() {
    coral.tests.JPFBenchmark.benchmark06(-9.324069263692033E-11,-0.40837086122080635,3.141592653589793 ) ;
  }

  @Test
  public void test3954() {
    coral.tests.JPFBenchmark.benchmark06(-93.36884704015564,-94.17818276082888,-26.546371004193574 ) ;
  }

  @Test
  public void test3955() {
    coral.tests.JPFBenchmark.benchmark06(94.26460563526393,-84.64457313403446,-57.146722497693794 ) ;
  }

  @Test
  public void test3956() {
    coral.tests.JPFBenchmark.benchmark06(9.47692359934183,-88.83787793731564,2.074616478236436 ) ;
  }

  @Test
  public void test3957() {
    coral.tests.JPFBenchmark.benchmark06(-94.78561151257561,63.23740663546175,-63.409541520160985 ) ;
  }

  @Test
  public void test3958() {
    coral.tests.JPFBenchmark.benchmark06(-94.92994998282501,-0.4059586007417124,-38.497390463386225 ) ;
  }

  @Test
  public void test3959() {
    coral.tests.JPFBenchmark.benchmark06(-95.1211650587031,-18.316964737205296,-76.58488559322848 ) ;
  }

  @Test
  public void test3960() {
    coral.tests.JPFBenchmark.benchmark06(95.39054448522012,-98.8964812659088,96.20206246758457 ) ;
  }

  @Test
  public void test3961() {
    coral.tests.JPFBenchmark.benchmark06(95.44808039131559,-49.10071633608326,-27.00389896487205 ) ;
  }

  @Test
  public void test3962() {
    coral.tests.JPFBenchmark.benchmark06(-9.550809227538746E-14,-1.5707963267948966,31.857011390192095 ) ;
  }

  @Test
  public void test3963() {
    coral.tests.JPFBenchmark.benchmark06(-95.92647278748542,0,0 ) ;
  }

  @Test
  public void test3964() {
    coral.tests.JPFBenchmark.benchmark06(95.9296870730683,28.14094351508919,0 ) ;
  }

  @Test
  public void test3965() {
    coral.tests.JPFBenchmark.benchmark06(96.12116548451718,-89.74849353324748,97.38839900579376 ) ;
  }

  @Test
  public void test3966() {
    coral.tests.JPFBenchmark.benchmark06(-96.46651565181142,-57.99407920879622,-66.47508211006885 ) ;
  }

  @Test
  public void test3967() {
    coral.tests.JPFBenchmark.benchmark06(-9.654953585083775E-10,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3968() {
    coral.tests.JPFBenchmark.benchmark06(-96.55645577819472,-62.732266940988815,24.941673547745324 ) ;
  }

  @Test
  public void test3969() {
    coral.tests.JPFBenchmark.benchmark06(-96.56344017513076,72.11478245770365,0 ) ;
  }

  @Test
  public void test3970() {
    coral.tests.JPFBenchmark.benchmark06(-9.678859352154335E-19,-1.5707963267948966,61.43494979596341 ) ;
  }

  @Test
  public void test3971() {
    coral.tests.JPFBenchmark.benchmark06(96.85250419246213,70.43576205020713,-30.61075830933224 ) ;
  }

  @Test
  public void test3972() {
    coral.tests.JPFBenchmark.benchmark06(-96.85962456948045,2.859594720673499,45.512162647947235 ) ;
  }

  @Test
  public void test3973() {
    coral.tests.JPFBenchmark.benchmark06(97.10874200078669,-57.855559966915315,27.46250587865768 ) ;
  }

  @Test
  public void test3974() {
    coral.tests.JPFBenchmark.benchmark06(-97.73972178612387,-29.380637264620972,80.88790942180538 ) ;
  }

  @Test
  public void test3975() {
    coral.tests.JPFBenchmark.benchmark06(97.83466738875418,16.73878123945569,61.12898588424062 ) ;
  }

  @Test
  public void test3976() {
    coral.tests.JPFBenchmark.benchmark06(-97.88776333147122,-14.410979188060196,-59.138592840515635 ) ;
  }

  @Test
  public void test3977() {
    coral.tests.JPFBenchmark.benchmark06(-9.810246228756057,8.445747036730666,-22.11845173919606 ) ;
  }

  @Test
  public void test3978() {
    coral.tests.JPFBenchmark.benchmark06(98.41690037248202,-55.51155366762834,31.74447884485707 ) ;
  }

  @Test
  public void test3979() {
    coral.tests.JPFBenchmark.benchmark06(-98.5093307346883,1.3433303042398137,39.427348398741515 ) ;
  }

  @Test
  public void test3980() {
    coral.tests.JPFBenchmark.benchmark06(9.860761315262648E-32,-1.5707963267948966,-14.237047497791337 ) ;
  }

  @Test
  public void test3981() {
    coral.tests.JPFBenchmark.benchmark06(-98.72455130031076,0,0 ) ;
  }

  @Test
  public void test3982() {
    coral.tests.JPFBenchmark.benchmark06(98.98018819656053,-6.854282447722724,-45.10937604329251 ) ;
  }

  @Test
  public void test3983() {
    coral.tests.JPFBenchmark.benchmark06(-99.03451140326256,-5.219906026274643,-3.5971052908573995 ) ;
  }

  @Test
  public void test3984() {
    coral.tests.JPFBenchmark.benchmark06(99.19091053537215,13.883440134939647,-43.80658145316083 ) ;
  }

  @Test
  public void test3985() {
    coral.tests.JPFBenchmark.benchmark06(-99.23428220011041,-8.81108139105362,12.286715483780512 ) ;
  }

  @Test
  public void test3986() {
    coral.tests.JPFBenchmark.benchmark06(-99.37548730274924,-32.366519612542604,-86.81175999029942 ) ;
  }

  @Test
  public void test3987() {
    coral.tests.JPFBenchmark.benchmark06(-9.949936767024425,-26.61522648594452,-46.62981505781345 ) ;
  }

  @Test
  public void test3988() {
    coral.tests.JPFBenchmark.benchmark06(-99.584161768129,-51.41621724048977,33.517665064259376 ) ;
  }

  @Test
  public void test3989() {
    coral.tests.JPFBenchmark.benchmark06(99.73313751608396,-78.85293381609006,-13.66611841061642 ) ;
  }

  @Test
  public void test3990() {
    coral.tests.JPFBenchmark.benchmark06(99.79630070114857,-30.218874110333033,-49.434183104876396 ) ;
  }

  @Test
  public void test3991() {
    coral.tests.JPFBenchmark.benchmark06(9.98835100638911,95.46304966616407,-74.71805144101076 ) ;
  }
}
