import org.junit.Test;

public class Sample30Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark30(-0.00295089891602629 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark30(-0.005088613613949633 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark30(-0.013694044671197503 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark30(-0.04724667590826925 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark30(-0.11612722334520242 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark30(-0.14702209702564062 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark30(-0.15441336628913405 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark30(-0.20669024612696774 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark30(-0.20714760297077817 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark30(-0.2144825932450516 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark30(-0.24331937650630664 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark30(-0.2739174626878338 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark30(-0.2867716536928242 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark30(-0.29629998067277086 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark30(-0.31437487261693775 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark30(-0.33439285410450736 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark30(-0.3728478340067056 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark30(-0.38693756304549254 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark30(-0.42871902555793895 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark30(-0.4504193055637984 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark30(-0.45686968871736156 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark30(-0.5439693068283873 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark30(-0.5540371738419481 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark30(-0.5747579986887956 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark30(-0.5998612411561197 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark30(-0.6459063362635078 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark30(-0.6681608463226638 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark30(-0.672204753305266 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark30(-0.7129580460808 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark30(-0.7133745372875637 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark30(-0.7712510251288904 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark30(-0.8840364451541518 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark30(-0.894350613386635 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark30(-0.9405074525290473 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark30(-0.9651530208399066 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark30(-10.010011636407242 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark30(-10.020792816212449 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark30(-10.065506059234664 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark30(-10.070660419443428 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark30(-10.08124712241532 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark30(-10.136683463390767 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark30(-10.183273746873468 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark30(-10.225274662686033 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark30(-1.0243191109604766 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark30(-1.026116305771339 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark30(-10.295769737926236 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark30(-1.0320309335388487 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark30(-10.339104292148036 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark30(-10.379572225536833 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark30(-10.384927612094515 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark30(-10.3890189840903 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark30(-10.39488325453199 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark30(-10.40203952402112 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark30(-10.409783885232414 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark30(-10.439718175234788 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark30(-10.451352342309647 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark30(-10.457215200917375 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark30(-10.504106604578695 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark30(-10.526749620868031 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark30(-10.561078985285334 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark30(-10.564478369862911 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark30(-10.604645355202095 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark30(-10.64953246338547 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark30(-10.650447646945494 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark30(-10.657707448524917 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark30(-10.674066221970364 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark30(-10.68113919986314 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark30(-10.8140811674444 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark30(-10.852148544156037 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark30(-10.8712461805832 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark30(-10.888098822247485 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark30(-10.921598196300948 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark30(-10.928173191759399 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark30(-10.95559752762884 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark30(-10.95787401891404 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark30(-11.008033994204453 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark30(-11.035529881852682 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark30(-11.128213590055694 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark30(-1.11284421039106 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark30(-11.179737015519294 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark30(-11.196080932275137 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark30(-1.1199226115318908 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark30(-11.204532371820463 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark30(-11.211004853801086 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark30(-11.246335500735952 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark30(-11.26023692996337 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark30(-11.269929161332797 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark30(-11.275331335249447 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark30(-11.27748899428154 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark30(-11.31760168344313 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark30(-11.32147173374733 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark30(-11.361518112307834 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark30(-11.373514429630731 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark30(-11.387717690997562 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark30(-11.430178009635043 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark30(-11.529525782105537 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark30(-11.55153687091348 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark30(-11.557886497884112 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark30(-11.571729477387251 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark30(-11.580197534710976 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark30(-1.1604998229217216 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark30(-11.65508497471319 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark30(-11.758277804951447 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark30(-11.760371461296401 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark30(-11.816471149252877 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark30(-11.818153174253581 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark30(-11.855040946151291 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark30(-1.186138327045171 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark30(-11.87729518780138 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark30(-11.952759620406255 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark30(-11.977075442329195 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark30(-11.97900932142619 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark30(-11.979726806690465 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark30(-12.025827141191243 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark30(-12.045375300228272 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark30(-12.082894316926243 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark30(-12.120128337533657 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark30(-12.13325436611197 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark30(-12.16264709499238 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark30(-1.2190143533799187 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark30(-12.192278083501336 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark30(-12.239621519011763 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark30(-12.278067987161023 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark30(-12.391316736022318 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark30(-12.399023701903161 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark30(-12.502451835750605 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark30(-12.522401739628108 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark30(-12.533761769176223 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark30(-12.561575787242973 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark30(-12.622139524297978 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark30(-12.636137119043298 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark30(-12.718177618428214 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark30(-12.724086244278567 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark30(-12.745094843394014 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark30(-12.818986519761921 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark30(-12.83627473159386 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark30(-12.852315086887415 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark30(-12.87487859569059 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark30(-12.878553249567943 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark30(-12.889472390901886 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark30(-12.922575874309558 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark30(-12.945321492396673 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark30(-12.980229138783159 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark30(-12.991794493619807 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark30(-12.998639441379595 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark30(-13.02596013336003 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark30(-1.3036251561233456 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark30(-1.3061030440959485 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark30(-13.103711816571632 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark30(-13.143287531821642 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark30(-13.14818111919216 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark30(-13.159782088110845 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark30(-13.17745055785835 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark30(-13.270422995272895 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark30(-13.276438125366369 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark30(-13.305151645120205 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark30(-13.31985511680233 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark30(-13.326689416114618 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark30(-13.465528568353164 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark30(-13.47704793850724 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark30(-13.480013989762469 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark30(-13.490488743054783 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark30(-13.562185848839107 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark30(-13.62113409352321 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark30(-13.623524214703593 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark30(-13.628739673655858 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark30(-13.711556156011937 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark30(-13.731528025614253 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark30(-1.379490958865631 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark30(-13.854465364819163 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark30(-13.863154799776183 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark30(-13.895786198943739 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark30(-13.914350161840574 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark30(-13.922235835801217 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark30(-13.941485480692322 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark30(-13.945477324133336 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark30(-14.002219879448319 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark30(-14.011730772934783 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark30(-14.020460880631418 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark30(-14.079111828315234 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark30(-14.086048940493171 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark30(-14.12469267610848 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark30(-14.128852184327243 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark30(-14.152933336383683 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark30(-14.155924562348304 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark30(-14.182638808763443 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark30(-14.195552962635972 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark30(-14.210785754364608 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark30(-14.213407154013595 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark30(-14.215000508266783 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark30(-14.220842054496899 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark30(-14.250608137123749 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark30(-14.260316281511791 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark30(-14.274195164520904 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark30(-1.4284445242521713 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark30(-14.413419618051762 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark30(-1.4413887919237425 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark30(-14.456830342915495 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark30(-14.476746142440916 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark30(-14.49536596537699 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark30(-14.541156517313823 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark30(-14.568233837643845 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark30(-14.607601375973545 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark30(-14.612721303964065 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark30(-14.617644406361848 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark30(-14.645504402828749 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark30(-14.65931685583368 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark30(-14.714287642025113 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark30(-14.739501388188202 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark30(-14.748810008935862 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark30(-14.777340720790505 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark30(-14.828903082295966 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark30(-14.887751667820709 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark30(-14.906065759645642 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark30(-14.947917584348033 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark30(-1.4957320456572347 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark30(-14.986258264599073 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark30(-15.045818952704806 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark30(-15.093588222975967 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark30(-15.09928013791044 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark30(-15.161827387713586 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark30(-15.20413767159701 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark30(-15.278855670247466 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark30(-15.309990195120179 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark30(-1.531030676296922 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark30(-15.333813633447363 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark30(-15.364116587101336 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark30(-15.377082583452122 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark30(-15.469825210069985 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark30(-15.487192581243676 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark30(-15.555287276725664 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark30(-15.55593782037883 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark30(-15.59541085678255 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark30(-15.605410012748692 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark30(-15.61540704777127 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark30(-15.654730146547905 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark30(-15.711451807804508 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark30(-15.732880310318919 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark30(-15.752309760175535 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark30(-15.81314880764873 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark30(-15.84044647345118 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark30(-15.857558126076938 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark30(-15.889760403400118 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark30(-15.896247965230287 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark30(-15.902211710508894 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark30(-15.927872766129354 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark30(-15.936429261873869 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark30(-15.948947286021763 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark30(-15.999899441840242 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark30(-1.60095455448743 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark30(-16.062419296072548 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark30(-16.09359308010177 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark30(-16.107259391589125 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark30(-16.114902470652638 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark30(-16.127245147532236 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark30(-16.12953566322139 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark30(-16.131125792037878 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark30(-16.13636999219466 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark30(-16.148668038975217 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark30(-16.181216011870063 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark30(-16.205881962342673 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark30(-16.239066780552918 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark30(-16.250295715986482 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark30(-16.261367638956187 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark30(-1.627177150526407 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark30(-16.273117155810056 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark30(-16.335776539124836 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark30(-16.336591010179973 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark30(-1.6345716101596963 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark30(-16.346330768087583 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark30(-16.37916391056187 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark30(-16.414067586009722 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark30(-16.416754828334817 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark30(-16.427978837504014 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark30(-16.468443862343435 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark30(-16.495622570035977 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark30(-16.536255238220093 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark30(-16.536788358076123 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark30(-16.541721312889408 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark30(-16.571356739210046 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark30(-16.574271378401306 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark30(-16.593325915466323 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark30(-16.642483192766292 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark30(-16.651652718077557 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark30(-16.651686494207183 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark30(-16.666525013917692 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark30(-16.69111211358792 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark30(-16.691443131844025 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark30(-1.6705416825163013 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark30(-16.771680899053678 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark30(-16.793268509105346 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark30(-1.6856090170061435 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark30(-16.89338586451285 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark30(-16.899668603300526 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark30(-16.91844546126326 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark30(-16.95416209137379 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark30(-16.95963113858329 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark30(-16.96016840147084 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark30(-16.982382434090184 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark30(-16.99748886782828 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark30(-17.00280129619493 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark30(-17.03934177598876 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark30(-1.7058130389095112 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark30(-17.0860381672488 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark30(-1.7122817889475783 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark30(-17.151107287177368 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark30(-17.182350303156653 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark30(-17.19744212990861 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark30(-17.21824869203732 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark30(-17.223691248131786 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark30(-17.224898506403477 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark30(-17.237406453408994 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark30(-17.260787353860138 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark30(-17.31354240174234 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark30(-17.33816841006552 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark30(-17.342318614612992 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark30(-17.34548702290033 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark30(-17.357441755606118 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark30(-17.377497982294756 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark30(-17.383298445973082 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark30(-17.41738409787368 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark30(-17.419220109511627 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark30(-17.43863969776396 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark30(-17.46033173299884 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark30(-17.467447795698575 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark30(-17.49865827668036 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark30(-17.55226799029836 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark30(-17.55845690593236 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark30(-17.662331699477548 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark30(-17.681858750495593 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark30(-17.704726189315394 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark30(-17.716960287733528 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark30(-1.7759222115198128 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark30(-17.778149715810997 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark30(-17.779692134252272 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark30(-17.78320609363051 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark30(-17.783250675090272 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark30(-17.795416426010917 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark30(-17.883192062784573 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark30(-17.95538083302364 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark30(-17.980137081357526 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark30(-18.00437620182491 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark30(-18.062780975711917 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark30(-18.100578138793068 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark30(-1.8104127835305803 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark30(-18.167150612745743 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark30(-18.215117994237048 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark30(-18.247332470684867 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark30(-18.247796668561506 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark30(-18.251632119186056 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark30(-1.8257726085190882 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark30(-18.25996623571112 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark30(-18.28435478528465 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark30(-18.295878094119146 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark30(-18.308168543294116 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark30(-18.33766000197285 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark30(-18.338237822370473 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark30(-18.343475168705112 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark30(-18.35043106854772 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark30(-1.8366915481606583 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark30(-18.37318356989654 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark30(-18.40727118332164 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark30(-18.47386888916151 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark30(-18.595685182426692 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark30(-18.620369170341576 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark30(-18.641201930853242 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark30(-18.667386021502068 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark30(-18.68076343846876 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark30(-18.68321557430275 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark30(-18.692643138256116 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark30(-1.8720856310357874 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark30(-18.746119066487992 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark30(-18.78162335533908 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark30(-18.788730021295237 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark30(-18.862106679400455 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark30(-18.891656700496924 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark30(-18.899610383428495 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark30(-18.902458463319988 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark30(-18.93057726294755 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark30(-18.996014784906535 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark30(-19.04007912606606 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark30(-19.050685457065413 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark30(-19.104208026130863 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark30(-19.111952638522595 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark30(-19.11492817440073 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark30(-19.1328060411994 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark30(-19.198258406537704 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark30(-19.20720133816043 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark30(-19.219118114552927 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark30(-19.240074356791624 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark30(-19.280079302182187 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark30(-19.280763583644656 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark30(-19.281292270926713 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark30(-19.296799846711025 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark30(-19.300159906764748 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark30(-19.314463254648942 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark30(-19.31714223732166 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark30(-19.339969028872915 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark30(-19.383260994481503 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark30(-19.38578053101756 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark30(-19.406944789017743 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark30(-19.41562457389152 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark30(-19.511177972279484 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark30(-19.517863918110706 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark30(-19.539097818214927 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark30(-19.592548635495405 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark30(-19.630584441413774 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark30(-19.63562819229496 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark30(-1.9643832827875798 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark30(-19.650137356092642 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark30(-19.67536426111593 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark30(-19.700797717915847 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark30(-19.71062127322311 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark30(1.9721522630525295E-31 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark30(-19.735857291434826 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark30(-19.742291143502968 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark30(-19.768583181406598 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark30(-19.77377165043461 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark30(-19.79232124820669 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark30(-19.955384522470453 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark30(-2.000031428729315 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark30(-20.019452857609068 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark30(-20.05691826964589 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark30(-20.07287831030338 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark30(-2.0074452133618195 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark30(-20.08336087828542 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark30(-20.106665652182826 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark30(-20.10848998001326 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark30(-20.108793055723666 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark30(-20.12828721783994 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark30(-20.13485745655599 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark30(-20.195937235062274 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark30(-20.221508853056093 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark30(-20.22951562385788 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark30(-20.268170570053414 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark30(-2.0279876074567227 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark30(-20.364113869619786 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark30(-20.37050143723509 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark30(-20.41374973983963 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark30(-20.4717330344389 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark30(-20.488751544778808 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark30(-20.49807259135798 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark30(-2.0559747880902535 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark30(-20.600473105212203 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark30(-20.638324584736537 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark30(-2.065533961090921 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark30(-20.664398765286734 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark30(-20.70747183166901 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark30(-20.73712539233827 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark30(-20.758705960956675 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark30(-20.777137569913066 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark30(-20.782761114637154 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark30(-20.792404192355377 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark30(-20.797479419236907 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark30(-20.800959757074764 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark30(-20.83550489829271 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark30(-20.84888306092192 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark30(-20.872083996452304 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark30(-20.905044078313637 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark30(-2.092795861790009 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark30(-20.97115840262991 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark30(-20.972374828217283 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark30(-20.99531113256279 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark30(-21.018894787576684 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark30(-21.0343665621092 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark30(-21.03668875184374 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark30(-2.1038726210252463 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark30(-21.056292655006132 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark30(-21.122013440548585 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark30(-21.177362682890106 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark30(-21.184601477584835 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark30(-21.242485090390147 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark30(-21.243761023760527 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark30(-21.255519825496563 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark30(-21.286435779148576 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark30(-21.301060693252566 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark30(-21.314376044373248 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark30(-21.325192272136377 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark30(-2.133570768276499 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark30(-21.3583609997237 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark30(-21.361718442645767 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark30(-21.375457512277876 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark30(-21.38028032243973 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark30(-21.39813182774317 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark30(-21.412114204428477 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark30(-2.1424247120871485 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark30(-21.431952903212007 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark30(-21.446290914394027 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark30(-21.447987610809463 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark30(-21.453179232602366 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark30(-21.472346309247143 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark30(-21.477055857274124 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark30(-21.506246449922898 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark30(-21.507047613725618 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark30(-21.531212570091853 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark30(-21.56206931424161 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark30(-21.57217110013451 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark30(-21.57559315963273 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark30(-21.57572740711109 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark30(-21.588672585206808 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark30(-21.5904263159766 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark30(-21.6181171098186 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark30(-21.659706133549392 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark30(-21.68925841675444 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark30(-21.708251726350497 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark30(-21.725828605868173 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark30(-2.1734364512041964 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark30(-21.770729761288337 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark30(-21.77079226285737 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark30(-21.860239539690113 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark30(-21.86263894963541 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark30(-2.1865776405686006 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark30(-2.1898622277199564 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark30(-21.975329846343044 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark30(-21.986982505899448 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark30(-22.002110865650934 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark30(-22.017961444708405 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark30(-22.045015480381025 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark30(-22.093907331609202 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark30(-22.099893684350036 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark30(-22.181569266188433 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark30(-22.26763373552585 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark30(-22.29116552608228 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark30(-22.314053349863087 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark30(-22.327881313276947 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark30(-22.34973676799747 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark30(-22.36214666479303 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark30(-22.364536469869577 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark30(-22.431052470024213 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark30(-22.46621769071959 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark30(-22.473272149341625 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark30(-22.477965925300865 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark30(-22.48293800844847 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark30(-22.486484984793947 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark30(-2.2644413529205423 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark30(-22.659757814583983 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark30(-22.676834222811152 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark30(-22.70508601069872 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark30(-22.718234151593663 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark30(-2.272994320778892 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark30(-22.764635447277783 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark30(-22.768371677477944 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark30(-22.769437357925256 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark30(-22.856650400398593 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark30(-22.898045389347075 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark30(-22.90786605283344 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark30(-22.91192834494207 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark30(-2.291696699637626 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark30(-22.918832351044145 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark30(-22.930705274195006 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark30(-22.94778265854147 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark30(-22.988844100016138 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark30(-23.0071516275717 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark30(-23.00741703534463 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark30(-2.3019291133887805 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark30(-23.06033108692256 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark30(-23.06504584241867 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark30(-23.107703405400244 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark30(-23.120113536646485 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark30(-23.127136782795787 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark30(-23.15102185599072 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark30(-23.158781722130243 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark30(-23.190817275418937 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark30(-23.204611414848102 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark30(-23.204980082350147 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark30(-23.291086144927476 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark30(-23.29419727714412 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark30(-23.30109808562868 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark30(-23.32415422781125 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark30(-23.329687226292165 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark30(-23.36316005991037 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark30(-23.367077624667147 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark30(-23.374868306694736 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark30(-23.381855859121984 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark30(-23.40798761925531 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark30(-23.412702326998144 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark30(-23.461565855917144 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark30(-23.46497427987744 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark30(-23.466524345512198 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark30(-23.469831993860964 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark30(-23.495273050516204 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark30(-23.505791814090756 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark30(-23.507131812175672 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark30(-23.518140526310475 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark30(-23.52845207732088 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark30(-23.572192397036943 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark30(-23.583339573601364 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark30(-23.591458147817818 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark30(-23.631844086481692 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark30(-23.638031288524957 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark30(-23.644155725657257 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark30(-23.661420624712278 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark30(-23.663810893045394 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark30(-23.67755544961669 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark30(-23.718813835644738 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark30(-23.732392035209628 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark30(-23.770964993483304 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark30(-23.787565792171478 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark30(-23.834897335953187 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark30(-23.899777399813573 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark30(-23.962756478982314 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark30(-23.980756418065454 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark30(-2.3993121512498163 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark30(-24.00647671959102 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark30(-24.017550146005235 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark30(-24.01782335549298 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark30(-24.04385949055022 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark30(-24.051957744146208 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark30(-24.062152991384124 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark30(-24.104562504270802 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark30(-2.4169807174768465 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark30(-24.205071036675577 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark30(-24.26590659374213 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark30(-2.426649789500715 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark30(-24.275352031729653 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark30(-24.33180312434824 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark30(-24.337174895222915 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark30(-24.349629437793 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark30(-24.367328291488377 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark30(-24.381666255092597 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark30(-2.4382887657594665 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark30(-24.384182137487656 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark30(-24.398333026097646 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark30(-24.441324501222468 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark30(-24.496636180128917 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark30(-24.50153868015039 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark30(-24.550740833329158 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark30(-24.551482280300064 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark30(-24.570673969538603 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark30(-24.611368975973292 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark30(-2.4611765253440296 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark30(-24.614683330867976 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark30(-24.617266201089706 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark30(-24.6273818141796 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark30(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark30(-24.664089160030827 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark30(-24.700697455871975 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark30(-24.758345633048904 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark30(-24.775147705318346 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark30(-24.7985100373225 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark30(-24.830099844331514 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark30(-2.4899314132874224 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark30(-24.928658665961365 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark30(-24.93106318059681 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark30(-24.94954633024014 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark30(-24.990562665607513 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark30(-24.9955914089866 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark30(-25.010532471416354 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark30(-25.02060737993719 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark30(-25.024557416066415 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark30(-25.049076922131874 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark30(-25.050675543525188 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark30(-25.105678580642873 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark30(-25.121974854236527 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark30(-25.124090994212295 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark30(-25.130809858475175 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark30(-25.175234529138123 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark30(-25.193326949973695 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark30(-2.5215832401167546 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark30(-25.220242336978018 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark30(-25.248641897206454 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark30(-25.24875884784055 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark30(-25.25339234834732 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark30(-25.2830905850999 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark30(-25.392259404226763 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark30(-25.40276353746094 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark30(-25.481402546226576 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark30(-25.494064561067617 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark30(-25.512181011744588 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark30(-25.521942336829312 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark30(-25.55703048284319 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark30(-25.58677365139654 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark30(-25.606853795655056 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark30(-25.625406331257025 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark30(-25.629084226710972 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark30(-25.655693342782456 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark30(-25.689610491439737 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark30(-25.74189300258962 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark30(-25.75089312891204 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark30(-25.77364288366506 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark30(-25.783048706567314 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark30(-25.787664400235897 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark30(-25.831189178469714 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark30(-25.83184243131322 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark30(-25.868198496202837 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark30(-25.88193825530516 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark30(-25.93986599629345 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark30(-25.947113776061386 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark30(-25.968156109728866 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark30(-25.971968797265973 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark30(-26.01139586937238 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark30(-26.035892627554517 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark30(-26.041039134327534 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark30(-26.065579292924568 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark30(-2.6093490184560437 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark30(-26.096089727645918 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark30(-26.136986943059554 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark30(-26.145958171005816 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark30(-26.19476101615568 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark30(-26.198710155048005 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark30(-26.215237330772595 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark30(-26.234890512993772 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark30(-26.2438084462336 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark30(-26.247711726697702 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark30(-26.313092659536892 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark30(-26.356652959939524 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark30(-26.36422695384495 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark30(-26.374399417674653 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark30(-2.639249423918713 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark30(-26.39591433699063 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark30(-26.45955347413711 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark30(-26.472434737388298 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark30(-26.50776282035298 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark30(-26.51914555442687 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark30(-26.52137606300616 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark30(-26.57722094315666 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark30(-26.6153746723661 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark30(-26.629006109554922 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark30(-26.67117180829166 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark30(-26.67199066063837 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark30(-26.69018556228346 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark30(-26.691509771864148 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark30(-26.70240208243655 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark30(-26.73140692326332 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark30(-26.735083334622516 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark30(-26.742269038775788 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark30(-26.773173558004373 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark30(-26.780566539979816 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark30(-26.812200457872166 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark30(-26.81698606703229 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark30(-26.818260133667707 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark30(-26.853780244692004 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark30(-2.6891144259266753 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark30(-26.893857676491123 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark30(-26.912868915619853 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark30(-2.69160895687493 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark30(-26.990214733020636 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark30(-27.012600882921276 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark30(-27.01684410405427 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark30(-27.108015136420576 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark30(-27.189645881196483 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark30(-27.202814059868416 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark30(-27.24061094325772 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark30(-27.24533893302423 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark30(-27.279086630704285 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark30(-27.349912642357538 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark30(-27.359823560361377 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark30(-2.737872952339231 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark30(-27.405391883710095 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark30(-27.41284117337652 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark30(-27.42295014725768 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark30(-27.44881395094731 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark30(-27.478236501592733 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark30(-27.49765718182273 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark30(-27.5223386651126 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark30(-27.52982954707943 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark30(-27.589732880492107 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark30(-27.590204892493404 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark30(-27.59583535383412 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark30(-27.617742478080245 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark30(-27.648746869155417 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark30(-27.652107643722417 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark30(-2.768095235652339 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark30(-27.69774746191436 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark30(-27.704056862632427 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark30(-27.731667408763897 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark30(-27.73717241939606 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark30(-27.747073262442655 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark30(-27.752052759539225 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark30(-27.944106232232684 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark30(-27.94553514199562 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark30(-2.797382242300799 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark30(-27.982435112863044 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark30(-28.010320129732662 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark30(-28.043288983743793 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark30(-28.04549198301025 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark30(-28.100021500663175 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark30(-28.106261112487132 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark30(-28.111750472891245 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark30(-28.13133920249041 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark30(-28.162755271042684 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark30(-28.204685754272106 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark30(-28.24754162325489 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark30(-28.248410948684395 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark30(-28.26007480715819 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark30(-28.262044698561667 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark30(-28.26642508705639 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark30(-28.319656752367422 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark30(-28.412678509365193 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark30(-28.456256773519442 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark30(-28.48771905560045 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark30(-28.513218271778243 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark30(-28.532567992736404 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark30(-28.538625659798342 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark30(-28.548584644245963 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark30(-28.621048489206927 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark30(-28.645895842215197 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark30(-28.671806582037334 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark30(-28.756393790077524 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark30(-28.846974412339478 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark30(-2.886199543375696 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark30(-28.877052339690422 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark30(-28.90828656335414 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark30(-28.921972414183372 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark30(-28.937209623487973 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark30(-28.964604446579926 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark30(-28.992553309710516 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark30(-29.053551309732924 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark30(-29.057723549724273 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark30(-29.062584422552362 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark30(-29.101161041975104 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark30(-29.11802542583351 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark30(-29.163022185500893 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark30(-29.172580821037442 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark30(-29.182512923544053 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark30(-29.207510369523646 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark30(-29.215057710997655 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark30(-29.2193194968404 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark30(-29.230667529727512 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark30(-29.241711222818907 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark30(-29.243032481784965 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark30(-2.924319465742613 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark30(-29.26396607602102 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark30(-29.318006190587198 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark30(-29.324741547422278 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark30(-29.359064763492725 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark30(-2.9406409775397435 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark30(-29.441664905716152 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark30(-29.442305953724542 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark30(-2.946024915193874 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark30(-29.47967330651838 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark30(-29.48264064961998 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark30(-29.493320184409953 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark30(-29.501211834492324 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark30(-29.564526736733043 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark30(-2.9565025590861325 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark30(-29.57103250402764 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark30(-29.620916751008636 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark30(-29.679797822614788 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark30(-29.687688451543366 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark30(-29.739446799665203 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark30(-29.74599453539433 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark30(-29.76967658090834 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark30(-2.978017669297344 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark30(-29.806159482839405 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark30(-29.86032188493502 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark30(-29.93709059208453 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark30(-29.937740722139665 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark30(-29.964479098470974 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark30(-29.977779190816477 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark30(-29.991376764677597 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark30(-30.012482219436194 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark30(-30.0480676117175 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark30(-30.05828725071906 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark30(-30.066574618906557 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark30(-30.069680187759445 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark30(-3.007167515903248 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark30(-30.114222758258563 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark30(-30.11818202041738 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark30(-30.134787349360565 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark30(-30.142319027128735 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark30(-30.16951660305031 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark30(-30.26335079930857 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark30(-30.327316628343937 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark30(-30.376163856991624 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark30(-30.428120213077975 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark30(-30.433786102135187 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark30(-30.43506988049431 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark30(-30.437459199807293 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark30(-30.441352314039733 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark30(-30.599355659316444 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark30(-30.615137189548108 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark30(-30.618284137278607 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark30(-30.716774869352605 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark30(-3.0723981108963727 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark30(-3.0734330845272524 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark30(-3.0794006777081933 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark30(-30.857200090355036 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark30(-30.910384761183835 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark30(-31.008718462315855 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark30(-31.016970735403575 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark30(-31.050908034971798 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark30(-3.107341248691611 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark30(-31.093407377844898 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark30(-31.12912378112314 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark30(-31.1654478590782 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark30(-31.19114028854426 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark30(-31.238087483653175 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark30(-31.239815479483084 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark30(-31.275579099539243 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark30(-31.29195795737563 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark30(-31.303303809414658 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark30(-3.1305444386566847 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark30(-3.1357707203299583 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark30(-3.136763871183561 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark30(-31.381173922881928 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark30(-31.384101272925037 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark30(-31.391383028695486 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark30(-31.41287821974406 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark30(-31.463346438182853 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark30(-31.483742801462583 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark30(-3.149423201982529 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark30(-31.50129417508512 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark30(-31.5048272497842 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark30(-31.54936300171913 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark30(-31.570547137160546 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark30(-3.162849094948058 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark30(-3.1648058417233216 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark30(-31.689758069735575 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark30(-31.69048102692922 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark30(-31.727549261944745 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark30(-31.7450956524673 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark30(-31.784820606469324 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark30(-31.803515284169137 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark30(-3.180612430783981 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark30(-31.810295479782823 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark30(-31.830882491086854 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark30(-31.86265137260949 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark30(-31.86831993379748 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark30(-3.1884076229239895 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark30(-3.188659296385012 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark30(-31.913937800208018 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark30(-3.1955853895631208 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark30(-31.975182913163323 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark30(-31.978699250495566 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark30(-31.98372177620905 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark30(-32.02125533316618 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark30(-32.08548646308802 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark30(-3.21083112931413 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark30(-32.13901231113255 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark30(-32.14177793303341 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark30(-32.155429922543874 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark30(-32.21210029876565 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark30(-3.222344603032795 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark30(-32.251007652253236 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark30(-32.367880294570384 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark30(-32.40884929157161 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark30(-32.41036092604578 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark30(-32.429130962109284 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark30(-32.449341654208126 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark30(-32.47500741410532 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark30(-32.49247277772433 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark30(-32.51595559890983 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark30(-32.51808870874649 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark30(-32.53830104950117 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark30(-3.2538466760121167 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark30(-32.61427938643173 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark30(-32.63728119201596 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark30(-32.639894148567805 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark30(-32.64361559926816 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark30(-32.65071350114532 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark30(-32.65821457011499 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark30(-32.692596606356105 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark30(-32.70338382065141 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark30(-32.72118461151008 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark30(-32.74943220448792 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark30(-32.75952954602816 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark30(-32.79227415864921 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark30(-32.80639167966271 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark30(-32.81366894149143 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark30(-32.81977825653203 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark30(-32.82407712138075 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark30(-32.85273566280944 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark30(-32.85416966517394 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark30(-32.885367485507714 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark30(-3.2899248481104593 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark30(-32.919271311513555 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark30(-32.93394640881995 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark30(-32.954051781749484 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark30(-32.98738009888595 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark30(-32.98851757642997 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark30(-32.99376054633103 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark30(-33.03584065240412 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark30(-33.040251316473814 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark30(-33.05450261170992 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark30(-33.070440514435816 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark30(-33.072010092737585 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark30(-33.08606613766665 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark30(-33.1212477730995 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark30(-33.12457830063376 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark30(-33.162123178111315 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark30(-33.18967949481157 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark30(-33.282448272930694 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark30(-33.2914638936243 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark30(-33.3310028477141 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark30(-33.339948801116705 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark30(-33.348094974107 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark30(-33.37215901476837 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark30(-33.37847221981478 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark30(-33.38462517858953 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark30(-33.422468557900274 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark30(-33.43468343094503 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark30(-33.44586436216083 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark30(-33.44971250392945 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark30(-33.45085655930038 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark30(-33.49220998534244 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark30(-33.50805970068397 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark30(-33.51930850416073 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark30(-33.54135225434814 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark30(-33.5463456030467 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark30(-33.54940967820002 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark30(-33.56566892142277 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark30(-33.59585796654471 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark30(-33.67662229518969 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark30(-33.69536113382212 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark30(-33.752815955736764 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark30(-33.754983113828075 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark30(-33.75868293156164 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark30(-33.81879358816519 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark30(-33.820715263856485 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark30(-33.851106079916676 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark30(-33.86163974812169 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark30(-33.90699002520631 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark30(-33.91089697103868 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark30(-33.92030272250682 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark30(-33.92781845269994 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark30(-33.941875098788074 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark30(-3.3959024079478013 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark30(-33.98471787875779 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark30(-34.04255670976899 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark30(-34.08121596143499 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark30(-34.165636404187 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark30(-34.176933698765396 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark30(-34.17946766504738 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark30(-34.202403655711194 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark30(-3.4235452983584196 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark30(-34.246360939252554 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark30(-34.25223117068626 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark30(-34.259609794131535 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark30(-34.30025882702397 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark30(-3.4341263079057853 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark30(-34.34372025081842 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark30(-34.35181279517849 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark30(-34.3603782137516 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark30(-34.393787101312185 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark30(-34.47048174922449 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark30(-34.471129349920275 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark30(-34.50632489678182 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark30(-3.4521084874721737 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark30(-34.54879979245962 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark30(-34.60041865379236 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark30(-34.601561534243956 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark30(-34.63934893373076 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark30(-34.65097315133907 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark30(-34.661433749676476 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark30(-34.71927853680428 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark30(-34.739876302178516 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark30(-34.74725164878696 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark30(-34.77738850683052 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark30(-3.4801211375891796 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark30(-34.869701263742314 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark30(-34.892647701836495 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark30(-34.90009530982138 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark30(-34.93263254248838 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark30(-34.93791419333934 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark30(-34.94074873141453 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark30(-34.943271855797846 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark30(-35.03081286892893 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark30(-35.0683654986678 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark30(-35.068772455720335 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark30(-35.136467314311616 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark30(-35.15693656093018 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark30(-35.18244511985837 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark30(-35.22320679119149 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark30(-35.27445267485383 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark30(-35.29451538509743 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark30(-3.538655265664218 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark30(-35.401457207150486 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark30(-3.540945100842535 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark30(-35.420586838920926 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark30(-35.444133786130536 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark30(-35.452137819147424 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark30(-35.466650484472325 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark30(-3.547350898326229 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark30(-35.482669996461325 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark30(-35.51251814093578 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark30(-35.56776387920972 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark30(-3.5588042146146677 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark30(-35.608987763723405 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark30(-35.6670523040177 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark30(-35.692086755831326 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark30(-35.747955945130045 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark30(-35.836789002147924 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark30(-35.87393330116271 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark30(-35.88380199465084 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark30(-35.896105360065846 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark30(-35.921030461607685 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark30(-35.97523844794472 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark30(-35.98187976716767 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark30(-3.6000445051666503 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark30(-36.01597986709597 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark30(-36.02127524632734 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark30(-36.099171956603705 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark30(-36.132166208088854 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark30(-36.1676767345332 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark30(-36.20298658906766 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark30(-36.244003409001245 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark30(-36.2505334829228 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark30(-3.6264588513442106 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark30(-36.27916361168766 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark30(-36.28932310375947 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark30(-36.349429783745094 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark30(-36.38662403727444 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark30(-36.388912212955745 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark30(-36.4277828770234 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark30(-36.43237168060431 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark30(-36.458806876517016 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark30(-36.47209644160561 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark30(-36.514241532386606 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark30(-36.58007945630417 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark30(-36.58999681082711 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark30(-36.623497129534584 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark30(-36.63015493234714 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark30(-36.630305103312956 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark30(-36.64325657491978 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark30(-36.68033708938694 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark30(-36.78218743611528 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark30(-36.79559292139785 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark30(-36.82217224055753 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark30(-36.83548307452804 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark30(-36.84305735973725 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark30(-36.84351184060204 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark30(-36.89306325516204 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark30(-36.9305634024226 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark30(-36.93814385871661 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark30(-36.94137904418797 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark30(-36.97786083251311 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark30(-36.98948868027085 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark30(-36.99610532394868 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark30(-3.7040325382330366 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark30(-37.07896332742286 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark30(-37.10048518908018 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark30(-37.117955564691215 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark30(-37.135098631891815 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark30(-37.14169123594549 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark30(-37.1865219365892 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark30(-37.19512050512472 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark30(-37.196126388889404 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark30(-37.20679906669879 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark30(-3.72091334244638 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark30(-3.721372067951563 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark30(-37.255705383905635 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark30(-37.290576929298915 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark30(-37.30920595439686 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark30(-37.336059216675196 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark30(-37.355149881262115 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark30(-37.43101925280923 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark30(-37.545419377853605 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark30(-37.608349226987926 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark30(-37.609814129403496 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark30(-37.64204250871936 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark30(-3.769857965474287 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark30(-37.71948799275051 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark30(-37.7414845787458 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark30(-37.78627000901624 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark30(-37.7879601322751 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark30(-3.7839344456119193 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark30(-37.96754147853949 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark30(-37.97136075382481 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark30(-38.01717674859984 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark30(-38.027619107265245 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark30(-38.04268877498982 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark30(-38.07576390525731 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark30(-38.12676176442484 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark30(-38.14571902047446 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark30(-38.187513529583896 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark30(-3.819638017291666 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark30(-38.21340948668244 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark30(-38.23362522477418 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark30(-38.24587425165973 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark30(-3.834357782885263 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark30(-38.35178890931257 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark30(-38.357248882645514 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark30(-38.41858401858455 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark30(-38.42004093554245 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark30(-38.49054112504204 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark30(-38.49101496625475 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark30(-38.501655491393436 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark30(-38.50725593108568 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark30(-38.51751049296879 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark30(-38.527312798378134 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark30(-38.556540788199655 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark30(-3.860793462143235 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark30(-38.62483200198022 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark30(-38.64314877943955 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark30(-38.66678351734632 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark30(-38.68805597811669 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark30(-38.7421720400509 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark30(-38.781224227406994 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark30(-38.7818092712942 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark30(-38.78943912363131 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark30(-38.80187352852704 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark30(-38.86695437790224 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark30(-3.8867878511888136 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark30(-38.91274416980784 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark30(-38.91883457538099 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark30(-38.92735289799128 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark30(-38.92977270321687 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark30(-38.95573417774833 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark30(-38.95616563390405 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark30(-38.98178335191058 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark30(-39.00511888122262 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark30(-3.901748229156766 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark30(-39.03205050231697 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark30(-39.06436121401888 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark30(-39.08613481636587 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark30(-39.08813266971176 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark30(-39.09986798576573 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark30(-39.146039299652145 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark30(-39.192700095520586 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark30(-39.29017892238533 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark30(-39.29110392279647 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark30(-39.33887958577622 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark30(-39.356932789044265 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark30(-39.40869869551869 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark30(-39.41587055244402 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark30(-39.421889787193585 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark30(-39.47038893564048 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark30(-39.513052970191765 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark30(-39.550055276663024 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark30(-39.57160767794012 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark30(-39.610988567414516 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark30(-39.62850450547543 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark30(-39.720394844409945 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark30(-39.73917348399756 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark30(-39.83379664309052 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark30(-39.84767857653107 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark30(-39.856166398838 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark30(-39.85691462113068 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark30(-39.91333283505172 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark30(-39.918312433519446 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark30(-39.92010305536622 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark30(-39.97000239713206 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark30(-39.99947002358879 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark30(-40.128036994107184 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark30(-40.14889396202253 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark30(-40.16312533915245 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark30(-40.17001436582108 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark30(-40.180905258773066 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark30(-40.18175876488863 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark30(-40.185808553795475 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark30(-40.24955856258041 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark30(-4.027404638190532 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark30(-40.28329017124281 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark30(-40.34045374307047 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark30(-40.34167804890636 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark30(-40.34449088463325 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark30(-40.34905038295036 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark30(-40.454418130653025 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark30(-40.455041605172596 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark30(-40.45762967950597 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark30(-40.477863866548944 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark30(-40.50977330448091 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark30(-40.54656432546868 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark30(-40.54793929454159 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark30(-40.561615373109895 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark30(-40.58301679154592 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark30(-4.068627660405895 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark30(-40.713917617291195 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark30(-40.73054583393683 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark30(-4.075075702522128 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark30(-40.778323828707805 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark30(-40.796956910026964 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark30(-40.83861915046858 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark30(-40.85583865092537 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark30(-40.862457708616475 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark30(-40.87544817846342 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark30(-40.89196976153702 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark30(-40.896106720158 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark30(-40.9030295946615 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark30(-40.914184183055056 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark30(-40.94422199259047 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark30(-40.96532659953225 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark30(-40.97018872021616 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark30(-40.98516088168538 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark30(-41.02157586226809 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark30(-41.05529057489845 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark30(-41.08435848089902 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark30(-41.095951156371704 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark30(-41.104272128426956 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark30(-4.117336757909129 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark30(-41.174984159600214 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark30(-41.18615625838045 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark30(-41.19245855216529 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark30(-41.241860088468485 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark30(-41.30773650640918 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark30(-41.320645814518684 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark30(-41.348466778807634 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark30(-41.35166083937642 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark30(-41.38186513557345 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark30(-41.39648558577762 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark30(-41.413479946480706 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark30(-41.44520598502774 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark30(-41.4463851999898 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark30(-41.44884152089732 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark30(-4.146567844649923 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark30(-41.47801442420382 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark30(-41.48224665469839 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark30(-41.526873947096796 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark30(-41.570163768300496 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark30(-41.57198686917953 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark30(-41.600705760374915 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark30(-41.691881189642956 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark30(-41.69537033130697 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark30(-4.172074039309976 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark30(-41.75357908494923 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark30(-4.176801984957535 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark30(-41.78214228567385 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark30(-41.812568263210295 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark30(-41.870629531941894 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark30(-41.87744244752145 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark30(-41.88161484085222 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark30(-41.88310667663322 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark30(-4.1919281356829 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark30(-41.92070706165387 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark30(-4.192635173122156 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark30(-41.9443097748089 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark30(-4.203100552141507 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark30(-42.05963180877652 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark30(-42.08881072393667 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark30(-42.09300739587321 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark30(-42.1100260277258 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark30(-42.13924447128847 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark30(-42.14717850682999 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark30(-42.260683008303566 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark30(-42.26813184697138 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark30(-42.276129384705015 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark30(-42.281650828137685 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark30(-42.29718943981384 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark30(-42.333117078065975 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark30(-4.233410189151996 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark30(-42.3471006686738 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark30(-42.355269933154794 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark30(-42.39362438145247 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark30(-42.397521090535406 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark30(-42.3981173877543 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark30(-42.40546130941052 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark30(-42.434009650060325 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark30(-42.4520296811316 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark30(-4.247246553575778 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark30(-42.489278404844995 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark30(-4.24899502476579 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark30(-42.499671575603415 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark30(-42.50400371374745 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark30(-42.5101777431592 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark30(-4.252201739053405 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark30(-42.533165308820365 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark30(-42.53564910751051 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark30(-42.56199257115409 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark30(-42.56330130538588 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark30(-42.66082848558006 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark30(-42.664592148431055 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark30(-42.667224835896825 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark30(-42.66837539673054 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark30(-42.685208815952016 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark30(-42.71938658759622 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark30(-4.274368476171617 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark30(-42.744303352696164 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark30(-42.785750862371486 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark30(-42.83362977422136 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark30(-42.931129660305125 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark30(-42.933343144881064 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark30(-42.9725864384277 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark30(-42.98747173647701 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark30(-4.302277480587335 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark30(-43.059785286016705 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark30(-43.10493696703968 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark30(-43.15956755172034 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark30(-43.1636986623887 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark30(-43.219750253275826 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark30(-43.22631224433806 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark30(-43.23131125861048 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark30(-43.23513725565731 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark30(-43.24859766620763 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark30(-43.24974479707737 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark30(-43.276094918427944 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark30(-4.327669338981394 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark30(-43.27735197091069 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark30(-43.303691367705085 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark30(-43.30955897227384 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark30(-43.3205543871984 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark30(-43.35848916211857 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark30(-43.376588823384225 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark30(-43.3968194317071 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark30(-43.41327575794549 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark30(-43.41877270141481 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark30(-43.45814975296365 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark30(-43.45989561016073 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark30(-43.464686568484034 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark30(-43.465995144944515 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark30(-4.350190373939071 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark30(-43.507004124028434 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark30(-43.53193454183724 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark30(-43.55609286084685 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark30(-43.55749533275684 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark30(-43.563625531783366 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark30(-43.57685522511032 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark30(-43.59134886209481 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark30(-43.62881686763633 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark30(-43.64385088353164 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark30(-43.66248024825366 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark30(-43.72493395548205 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark30(-43.736290529435976 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark30(-43.75255447458664 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark30(-43.768112831020915 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark30(-43.82462582567832 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark30(-43.828234830827405 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark30(-43.85663122313688 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark30(-43.929601782746474 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark30(-43.97426895876488 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark30(-43.9821130200132 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark30(-43.985759796714554 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark30(-4.405838727414206 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark30(-4.405925572924119 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark30(-44.08039809789565 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark30(-44.12412314830079 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark30(-44.14815010670996 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark30(-44.175957367231256 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark30(-44.185307106736474 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark30(-44.201039987607246 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark30(-44.21453130444206 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark30(-44.23539227386839 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark30(-4.4267363372164255 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark30(-4.429123400504963 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark30(-44.31442416571447 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark30(-44.40874287283321 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark30(-44.48934165731475 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark30(-44.50394877401238 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark30(-44.51206084555699 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark30(-44.51436970765379 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark30(-4.461631583124287 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark30(-44.64522942056202 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark30(-44.65582931913114 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark30(-44.678337929656294 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark30(-44.74511502786622 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark30(-44.76187439429009 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark30(-44.76936212739942 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark30(-44.78136117446005 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark30(-44.78368072179164 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark30(-44.812925628542 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark30(-44.853390043256525 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark30(-44.860856068824994 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark30(-44.87950760174799 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark30(-44.88556508475836 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark30(-44.917209164922234 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark30(-44.926010320166924 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark30(-45.011666841577245 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark30(-45.016403881595224 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark30(-45.02110583711567 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark30(-45.0226076121077 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark30(-45.10802816898911 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark30(-45.13083155782655 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark30(-45.18867821497281 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark30(-45.24846194932459 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark30(-45.25218383816403 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark30(-45.26688001075079 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark30(-45.27430441101554 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark30(-45.27466818969286 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark30(-45.27853005642517 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark30(-45.28832874372088 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark30(-45.31760277543131 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark30(-45.32804974472129 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark30(-45.36679039598832 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark30(-45.36690427465242 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark30(-45.42277662968986 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark30(-4.5426549615383465 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark30(-45.48448928901492 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark30(-45.51098750931026 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark30(-45.537916365665666 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark30(-45.53930502862058 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark30(-45.60632418218506 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark30(-4.563605014871925 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark30(-45.647413237078325 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark30(-45.65328005262623 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark30(-45.65401159503908 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark30(-4.569143733984319 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark30(-45.7048407638037 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark30(-45.72070100243475 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark30(-45.7741946594868 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark30(-45.79752591341544 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark30(-45.80931701310569 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark30(-45.80964169659896 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark30(-45.84322107756223 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark30(-45.85876009729073 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark30(-45.887731113864774 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark30(-45.908646112926085 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark30(-45.930198906343556 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark30(-45.956492183787304 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark30(-45.99698277128308 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark30(-4.600466097749646 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark30(-46.012260897588405 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark30(-46.017997823314616 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark30(-46.018974616491604 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark30(-46.066440026175925 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark30(-46.07407615365615 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark30(-46.15241740613762 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark30(-46.173897344483095 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark30(-46.175116338530174 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark30(-46.20020118453325 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark30(-4.624915785776523 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark30(-46.25148071180618 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark30(-46.28000566234272 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark30(-46.2911042345052 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark30(-46.29927769336051 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark30(-46.30841271931671 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark30(-46.317281632910664 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark30(-46.344495828658715 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark30(-46.35716379005772 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark30(-46.36585573663239 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark30(-46.37481424310601 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark30(-46.42684726166384 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark30(-46.431464451973056 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark30(-46.467965677991984 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark30(-46.498683506481676 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark30(-46.51757031093191 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark30(-46.52324322096153 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark30(-46.6208662670913 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark30(-4.664214833448057 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark30(-46.654631216705965 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark30(-46.67489467465293 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark30(-46.67974055977784 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark30(-46.72530362025231 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark30(-46.73887109607753 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark30(-46.76297535257077 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark30(-46.80226909707377 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark30(-4.684471903190058 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark30(-46.868453709444566 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark30(-46.87428578007833 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark30(-4.690591385685593 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark30(-46.921504223613766 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark30(-46.95911713349823 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark30(-46.98098210710842 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark30(-47.02355800534734 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark30(-47.03376022850949 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark30(-47.0504628290002 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark30(-47.05131970894587 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark30(-47.05412117529772 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark30(-47.06725365332074 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark30(-47.06861393708757 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark30(-47.11641653311067 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark30(-47.134553795876144 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark30(-47.152535898735024 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark30(-47.16233223032356 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark30(-47.163180462199364 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark30(-47.16775061684595 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark30(-47.21252900291199 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark30(-47.22813132282471 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark30(-47.24800113630803 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark30(-47.25250957780449 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark30(-47.323435350235464 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark30(-47.32654017805058 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark30(-47.328359005477004 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark30(-47.368877877538026 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark30(-47.37058124020168 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark30(-47.391820184646875 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark30(-47.39760264809245 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark30(-47.42490597217692 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark30(-47.44454176084994 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark30(-47.448305732063666 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark30(-47.44965665201726 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark30(-47.45130159659428 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark30(-47.471771530337634 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark30(-47.47241356746987 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark30(-47.47939031507131 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark30(-47.50901833496386 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark30(-47.52599348874542 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark30(-47.5329983719601 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark30(-47.542311732947226 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark30(-47.54685444928073 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark30(-47.64550663552662 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark30(-47.67695959202855 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark30(-47.69588881944824 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark30(-47.810526907738435 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark30(-47.825001467387864 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark30(-47.850116719959715 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark30(-47.85087357376574 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark30(-4.785964436988138 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark30(-47.889196015255855 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark30(-47.91066772792403 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark30(-47.92379013342409 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark30(-4.793456792361738 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark30(-47.948052962524976 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark30(-47.95447889463054 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark30(-47.95856655751207 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark30(-47.972341289030695 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark30(-48.00884617276644 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark30(-48.02208463372395 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark30(-48.08119496267196 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark30(-4.808532436558181 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark30(-48.086829411408694 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark30(-48.12148755719734 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark30(-48.12477965593616 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark30(-48.13060399294962 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark30(-48.15710837468905 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark30(-48.16081493450062 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark30(-48.18761495270935 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark30(-48.243286990599785 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark30(-48.25873861924252 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark30(-48.27916843973055 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark30(-4.834696658492405 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark30(-48.40064885006894 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark30(-4.840284172172886 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark30(-48.48318774565756 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark30(-48.49755614171705 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark30(-48.51818042265275 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark30(-48.53550073370296 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark30(-48.58533291049652 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark30(-4.861534982637991 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark30(-48.67921071460739 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark30(-48.71970892037201 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark30(-48.731734719662654 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark30(-48.73848798154368 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark30(-4.883781964044289 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark30(-48.854126685944266 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark30(-48.86220455349544 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark30(-48.884737770284836 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark30(-48.886225340085 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark30(-48.89920330639068 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark30(-48.932177305641545 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark30(-48.95280513200881 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark30(-4.8988394699361635 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark30(-49.00403486110332 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark30(-49.03867224063061 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark30(-49.06473609662492 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark30(-49.0850857091385 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark30(-49.10846434007037 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark30(-49.12230845141294 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark30(-49.14460465583108 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark30(-49.173555928319914 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark30(-49.18050223268724 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark30(-49.21242234623073 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark30(-49.22824662336187 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark30(-49.254317218210076 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark30(-49.268752337797395 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark30(-49.283152787545426 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark30(-49.28480282731549 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark30(-49.32120277758605 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark30(-49.34137384305595 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark30(-49.34376273952592 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark30(-49.45756920634603 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark30(-4.946056598432747 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark30(-49.46258757741142 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark30(-49.463423198772084 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark30(-49.48082957786679 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark30(-49.511911564305436 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark30(-49.54585617113436 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark30(-49.576048110905255 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark30(-49.58827064386817 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark30(-49.59094499612462 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark30(-49.593108848262716 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark30(-49.62803041609678 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark30(-4.963179252575969 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark30(-49.67276048461695 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark30(-49.703653926980486 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark30(-49.7119043500728 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark30(-49.74015852844049 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark30(-49.75056006200587 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark30(-49.75655338806877 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark30(-49.773963748628745 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark30(-49.792684358057706 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark30(-49.796212545598515 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark30(-49.8236516396547 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark30(-49.839066799980245 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark30(-49.84580992474943 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark30(-49.870141155619365 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark30(-49.9214139456243 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark30(-49.92380414907118 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark30(-49.93515124717129 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark30(-49.9512176510394 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark30(-49.95817666783455 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark30(-49.97969558950797 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark30(-50.00610510512864 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark30(-50.0364531651128 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark30(-50.038269509748254 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark30(-50.07424922026775 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark30(-50.086953433690496 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark30(-5.009127593194165 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark30(-5.010097653296469 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark30(-50.16420893234188 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark30(-5.0168773170232726 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark30(-50.1895996142941 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark30(-50.24485738839732 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark30(-50.27139105726233 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark30(-50.27947897858831 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark30(-50.28506315786034 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark30(-50.30181903724304 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark30(-50.33998229663863 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark30(-50.36443877201964 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark30(-5.03995502934778 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark30(-50.418702455100984 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark30(-50.432812395193 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark30(-50.55818627968547 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark30(-50.59110907835838 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark30(-50.596355841051334 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark30(-50.61432120484777 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark30(-50.625360560284996 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark30(-50.635551633615925 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark30(-50.64163883232964 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark30(-50.64180890057888 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark30(-50.6616017053185 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark30(-50.67936413839051 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark30(-50.714965141890644 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark30(-50.756780606357445 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark30(-50.76498308447155 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark30(-50.803704668628626 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark30(-5.085651268080966 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark30(-50.88696803601318 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark30(-50.8971506807129 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark30(-50.89775834084096 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark30(-50.906054414641865 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark30(-50.951751957252725 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark30(-50.98951237148979 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark30(-51.01212609308299 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark30(-51.01794038065015 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark30(-51.024631329617634 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark30(-51.032770881707634 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark30(-51.09383761290598 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark30(-51.10402439549071 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark30(-51.114413007086924 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark30(-51.11591150525774 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark30(-51.15804074499779 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark30(-51.16037627331562 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark30(-51.16493713840515 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark30(-51.18928003868466 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark30(-51.19304752395666 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark30(-51.19796482999297 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark30(-51.280158497009445 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark30(-51.331301042678156 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark30(-51.39324950306432 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark30(-51.397714003751574 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark30(-51.39840166021761 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark30(-51.43749880699726 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark30(-51.47226551974662 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark30(-51.488630869469155 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark30(-51.56646955127036 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark30(-51.57948928687628 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark30(-51.61177685263028 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark30(-51.634932299845374 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark30(-51.695251013246434 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark30(-51.726982104422746 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark30(-51.74470957715756 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark30(-51.80158946436833 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark30(-51.83601423030755 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark30(-51.86922516678747 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark30(-51.871911448943365 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark30(-51.89363304038124 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark30(-51.927611211880674 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark30(-51.93255482629249 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark30(-52.002069412461 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark30(-52.01418852860491 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark30(-5.207722085266113 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark30(-52.08193284825051 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark30(-52.0832409551629 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark30(-52.08860399979927 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark30(-5.2097783778286555 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark30(-52.099871660621446 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark30(-52.135874555692865 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark30(-52.190086826717106 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark30(-52.191267451231084 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark30(-52.22788405298542 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark30(-52.257672887098394 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark30(-52.29160869970843 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark30(-5.229343457783926 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark30(-52.3404517262005 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark30(-52.34722298770018 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark30(-52.36311055406884 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark30(-52.381970651202096 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark30(-52.395092513220696 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark30(-52.401297975882486 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark30(-52.408134819664554 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark30(-52.48860995776461 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark30(-52.491488908726325 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark30(-5.251261552397864 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark30(-52.549395514736744 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark30(-52.55269733682984 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark30(-5.255747973435135 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark30(-52.6013547128821 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark30(-52.60380991964939 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark30(-52.65113856815251 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark30(-52.686731762075986 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark30(-52.70027944754114 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark30(-52.708533101319574 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark30(-52.71631727125374 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark30(-52.73622400383336 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark30(-52.766704420185384 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark30(-52.83380330449927 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark30(-52.83471522326933 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark30(-52.84401868966866 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark30(-52.90883487864999 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark30(-52.91680273799424 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark30(-52.95411660006521 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark30(-52.984374696635214 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark30(-52.9976699203925 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark30(-5.305898085559662 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark30(-5.306465383641481 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark30(-53.0915112489198 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark30(-53.10313776553293 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark30(-53.20314124382577 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark30(-53.22733333803953 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark30(-53.312133854582264 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark30(-53.35569234754378 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark30(-53.36949956496382 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark30(-53.369523618101766 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark30(-53.371481981694366 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark30(-53.398223532643655 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark30(-53.43082243487578 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark30(-5.348897997592289 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark30(-5.349628917111133 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark30(-53.57054724014026 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark30(-53.57755942515998 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark30(-53.63765591944614 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark30(-53.70564569961216 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark30(-53.715699291363414 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark30(-5.372795020618113 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark30(-53.778719171974856 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark30(-53.78899242973097 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark30(-53.850064414870815 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark30(-53.85446938556348 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark30(-53.85839140330078 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark30(-53.86181841217914 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark30(-53.901428629060824 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark30(-53.93261197184302 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark30(-53.95167079386596 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark30(-53.957371521835064 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark30(-53.99497549243999 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark30(-53.99820855620676 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark30(-54.01257403368505 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark30(-54.045562280568895 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark30(-54.142652070124655 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark30(-54.15865923414256 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark30(-54.16396572864821 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark30(-54.193961240563596 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark30(-54.222849292126995 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark30(-54.25387309645937 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark30(-54.26863208137691 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark30(-54.296683877554756 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark30(-54.43353589982587 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark30(-54.48517023721882 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark30(-54.52256909462505 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark30(-54.564768482002805 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark30(-54.63345077491086 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark30(-54.661269764313715 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark30(-54.87145235217192 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark30(-54.90769078812641 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark30(-54.977652716827286 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark30(-55.00525532821423 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark30(-5.503452478722508 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark30(-55.035816342756426 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark30(-55.08947845722276 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark30(-55.13520844448405 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark30(-55.16458982704597 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark30(-55.18260533026385 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark30(-55.2055431953893 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark30(-55.22098871283894 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark30(-55.23564197436088 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark30(-55.25769849932327 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark30(-55.26045149527094 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark30(-55.27691321295567 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark30(-5.528925584498111 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark30(-55.289708887438785 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark30(-55.29072686970922 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark30(-55.29404029660743 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark30(-55.30952755133642 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark30(-55.31585461592074 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark30(-55.320679896519145 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark30(-55.33639154796766 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark30(-55.34088770981995 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark30(-55.38767712025931 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark30(-55.47555759395679 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark30(-55.48443918160315 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark30(-55.48593983842112 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark30(-55.48799056902543 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark30(-55.51023656218015 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark30(-55.578309249380744 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark30(-55.58030469983586 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark30(-55.6402641180818 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark30(-55.672279723506456 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark30(-55.70425905386456 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark30(-55.78273170845836 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark30(-5.579741500716267 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark30(-55.80476242219869 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark30(-55.84554153758121 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark30(-55.874192746298654 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark30(-55.87915359083151 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark30(-55.9114973994016 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark30(-56.006430559348445 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark30(-56.028578462508925 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark30(-56.06473870956423 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark30(-56.071491793484675 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark30(-56.080109086953755 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark30(-56.08111963274467 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark30(-56.13187643956836 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark30(-56.162948889068296 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark30(-56.24144226729246 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark30(-56.24879123821249 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark30(-56.25049066776986 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark30(-56.32834779570069 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark30(-56.33987162839615 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark30(-56.344550470070786 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark30(-56.35818923569285 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark30(-56.36102472487081 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark30(-56.36659142426057 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark30(-56.36932276214899 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark30(-56.37180069897276 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark30(-56.39757556625917 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark30(-56.448136961145764 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark30(-56.62308291098368 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark30(-56.636362171502164 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark30(-56.65615001930138 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark30(-56.6978852091625 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark30(-56.70507425544062 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark30(-56.718335533154814 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark30(-56.72462588037512 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark30(-56.763813950141916 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark30(-56.76697961679733 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark30(-56.7745776066029 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark30(-56.81834741288219 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark30(-56.84928089276233 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark30(-56.851335080142576 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark30(-56.85886389730028 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark30(-56.8666629663652 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark30(-56.9014296881347 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark30(-56.91890193668225 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark30(-56.93674111897378 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark30(-56.93982041820329 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark30(-57.02925628170388 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark30(-57.037368788860206 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark30(-57.04788420741727 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark30(-57.06043388922233 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark30(-5.706813319552964 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark30(-57.107575255146045 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark30(-57.12977383321809 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark30(-57.131891607849305 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark30(-57.202134015840336 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark30(-57.207621623478545 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark30(-57.25262647301663 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark30(-57.275540662224685 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark30(-57.32336229253683 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark30(-57.326432622436954 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark30(-57.341470889023036 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark30(-57.36496425640378 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark30(-57.42203827027175 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark30(-57.44007551748085 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark30(-57.50068905338339 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark30(-57.50455027806076 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark30(-57.53787622311999 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark30(-57.56304584512182 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark30(-57.59152076117331 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark30(-57.59983557504778 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark30(-57.628161866088234 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark30(-57.63831433451825 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark30(-57.643456359054234 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark30(-57.646117946787 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark30(-57.67258405629951 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark30(-57.70393531869242 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark30(-57.727298033315066 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark30(-57.77676778265284 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark30(-57.827139771949064 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark30(-57.835186202351906 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark30(-57.85584989176942 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark30(-5.790322162545863 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark30(-5.794305793853454 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark30(-57.959777989503 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark30(-58.0192731722192 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark30(-58.023280466004756 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark30(-58.034959861339864 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark30(-58.040133181794175 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark30(-58.04398881156088 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark30(-58.054524185636055 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark30(-58.06881240360049 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark30(-58.09329060482425 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark30(-58.149252160794006 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark30(-58.193848629582256 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark30(-5.82703865397589 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark30(-58.27789271058273 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark30(-58.3119370300568 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark30(-5.8433675940465974 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark30(-58.44087130293965 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark30(-58.49131824107905 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark30(-58.49261531946182 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark30(-58.52148519533371 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark30(-58.583627012030306 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark30(-58.63488452864378 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark30(-5.869925301927708 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark30(-58.701202581774425 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark30(-58.71966240658186 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark30(-58.736933610032736 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark30(-58.7697322039332 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark30(-58.79036163793474 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark30(-58.84665007044691 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark30(-58.856681099450746 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark30(-5.887289566295337 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark30(-5.888466409017639 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark30(-58.90233962337046 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark30(-58.91824830231671 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark30(-58.95342430511141 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark30(-58.96010162847476 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark30(-58.96609052329551 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark30(-58.97256539537159 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark30(-58.975501089418046 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark30(-59.010765435194614 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark30(-59.07797484316424 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark30(-59.126973629701894 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark30(-59.13816233817766 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark30(-59.17936915097917 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark30(-5.918730968364287 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark30(-59.20234566086427 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark30(-59.2176553245821 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark30(-59.22374163017787 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark30(-59.223826294947536 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark30(-59.284487743665814 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark30(-59.2979271098792 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark30(-59.30322099417924 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark30(-59.35363681591597 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark30(-5.936802298470383 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark30(-59.410552843729626 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark30(-59.46734832939489 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark30(-59.49237934469631 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark30(-59.496716715249654 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark30(-59.504228140748914 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark30(-59.50449178293296 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark30(-59.63062785970086 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark30(-59.64668185286983 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark30(-59.654867438004786 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark30(-59.65900914662061 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark30(-59.66864362195325 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark30(-5.9692762496071055 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark30(-59.714220543657134 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark30(-59.800006227488936 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark30(-59.825139360618905 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark30(-59.871907646799926 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark30(-59.8896909208497 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark30(-59.88972249886038 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark30(-59.9184713728724 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark30(-59.94595086870109 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark30(-59.97035662970869 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark30(-60.003861710795434 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark30(-60.06317758109574 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark30(-60.081650863939615 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark30(-60.09327430046527 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark30(-60.099373155089175 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark30(-60.1247075065138 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark30(-60.1314829076385 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark30(-60.1518144223693 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark30(-60.163474914498494 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark30(-60.18519971848275 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark30(-60.19916908236995 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark30(-60.210742808424136 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark30(-60.302854870247955 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark30(-60.34567661504517 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark30(-60.38007984388176 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark30(-60.38284357483366 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark30(-60.408990733049286 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark30(-60.42882485317058 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark30(-60.43617998176782 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark30(-60.464446108810456 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark30(-60.47167893814325 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark30(-60.472521207522 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark30(-60.49565513744937 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark30(-60.538507151360285 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark30(-6.061923628207765 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark30(-60.69696916782359 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark30(-60.71098152719263 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark30(-60.72593785103757 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark30(-60.82718167231036 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark30(-60.83307264224133 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark30(-60.85990632106495 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark30(-60.87140849205315 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark30(-60.88959158491616 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark30(-60.96332290242679 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark30(-60.9768199902686 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark30(-6.100359797787931 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark30(-61.024539154257255 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark30(-61.08561102607211 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark30(-61.11002530117729 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark30(-61.14967070286521 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark30(-61.16866809616812 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark30(-61.20122427541108 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark30(-61.20248069172671 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark30(-61.20746344926229 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark30(-61.3552585582583 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark30(-61.36939696164143 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark30(-61.40886586790586 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark30(-61.466684487163924 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark30(-61.55218783505296 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark30(-61.590378689982984 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark30(-61.59178483096619 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark30(-61.65610397417094 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark30(-61.68170211057258 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark30(-61.741410934361696 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark30(-61.756673033200535 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark30(-61.770749318014474 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark30(-61.829348020081355 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark30(-61.832611914094215 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark30(-61.84861711046703 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark30(-61.852456510395484 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark30(-61.85612484237411 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark30(-61.88346271324636 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark30(-61.90409658422864 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark30(-6.190986338113348 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark30(-61.95982489859435 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark30(-61.96233472461772 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark30(-6.1970470444192784 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark30(-61.996255158415714 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark30(-61.99918003020408 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark30(-62.00179875502596 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark30(-62.009769950626236 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark30(-62.01616122521354 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark30(-62.03059575164567 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark30(-62.05656465291989 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark30(-62.09136903695509 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark30(-62.096657648138276 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark30(-62.16595174785731 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark30(-62.219455204714414 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark30(-62.24407862307153 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark30(-6.229245002567566 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark30(-62.334572499255295 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark30(-62.336964066430035 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark30(-62.33708631980779 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark30(-62.38917496858725 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark30(-62.435869874242165 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark30(-62.462931834207836 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark30(-62.485114426568636 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark30(-62.4935702500582 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark30(-62.5011845875306 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark30(-6.251693907401261 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark30(-62.52779969506514 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark30(-62.539605596474665 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark30(-62.54869883190726 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark30(-62.68112395882315 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark30(-6.269219505747017 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark30(-62.69258631217169 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark30(-62.69910508257328 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark30(-62.70426373454383 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark30(-62.77308005558761 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark30(-62.834615329678954 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark30(-62.83735688039247 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark30(-62.867974466529915 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark30(-6.287800762312898 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark30(-6.288276459105035 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark30(-62.88781584386791 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark30(-62.89874513977747 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark30(-62.92099441546548 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark30(-62.9468378520855 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark30(-62.95220804760462 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark30(-62.95467174428657 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark30(-62.960360478283796 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark30(-62.97686239591871 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark30(-62.97875774657204 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark30(-62.9835576544463 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark30(-63.0139962156053 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark30(-63.018836008556356 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark30(-63.032305624916575 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark30(-63.033258585672144 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark30(-63.07755125019994 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark30(-63.089640467498384 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark30(-6.31051228761514 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark30(-63.12194045657029 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark30(-63.15582272929681 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark30(-63.19851056790693 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark30(-63.21079815176809 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark30(-63.21935018166154 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark30(-63.22484466066691 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark30(-63.23973029712431 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark30(-6.329937341492851 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark30(-63.31271260052071 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark30(-6.335200766062243 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark30(-63.36625212947264 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark30(-63.37164711704164 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark30(-63.39043510111326 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark30(-63.40139940390679 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark30(-63.410650331053645 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark30(-63.43645654451353 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark30(-63.48379123250296 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark30(-63.55585197126712 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark30(-63.687968010377816 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark30(-63.707358098079105 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark30(-63.71228083546032 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark30(-63.716971302527355 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark30(-63.72068095897119 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark30(-63.722244587552645 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark30(-63.73290374461795 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark30(-63.75710893797986 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark30(-63.775642364975546 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark30(-63.7858489130793 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark30(-63.787988827405016 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark30(-63.78846412132435 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark30(-63.83400271722937 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark30(-63.854180763125925 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark30(-63.91649060440494 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark30(-63.93739099688458 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark30(-63.955815087093825 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark30(-63.97400938545283 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark30(-63.98332315612225 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark30(-6.401567117634087 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark30(-64.02281988397985 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark30(-64.0750428545382 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark30(-64.07832417555217 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark30(-64.08236537570883 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark30(-64.11131594366643 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark30(-64.11376912351676 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark30(-64.16836756985944 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark30(-64.18833519201262 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark30(-6.419518906834625 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark30(-64.20921299503495 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark30(-64.21892186187551 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark30(-64.2438734221493 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark30(-64.25597194917444 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark30(-64.27288831161921 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark30(-64.32728449371037 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark30(-64.33764058443478 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark30(-64.4046625296987 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark30(-64.40753782596313 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark30(-64.40776683296123 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark30(-64.40945847311804 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark30(-6.441506008938362 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark30(-64.43310408851139 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark30(-64.4458323880503 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark30(-64.46151808105299 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark30(-64.5061976643269 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark30(-64.5299237886088 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark30(-64.54549468438955 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark30(-64.54950467062886 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark30(-64.55703016607816 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark30(-64.57143185081492 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark30(-64.64578786746553 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark30(-6.465033845959624 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark30(-64.6673767193439 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark30(-64.68390601195591 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark30(-64.69386643373284 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark30(-64.72959529409331 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark30(-64.76790557996593 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark30(-64.79926898103203 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark30(-64.82895917158584 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark30(-64.83143967510725 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark30(-64.84476140493422 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark30(-64.85667073100905 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark30(-64.87173326659783 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark30(-64.87731485433233 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark30(-64.8811263597775 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark30(-6.491423306454209 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark30(-64.91500057320074 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark30(-64.9486450927806 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark30(-64.96150973619051 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark30(-64.97838599077602 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark30(-65.01638853837046 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark30(-65.04075627311556 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark30(-65.06700289812252 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark30(-65.13467696690142 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark30(-65.17350066110987 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark30(-65.1830948723527 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark30(-65.23866557199909 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark30(-65.27797271874034 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark30(-65.31323765417824 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark30(-6.531754473815596 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark30(-65.35546576410623 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark30(-65.40770017092112 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark30(-65.42912814859474 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark30(-65.44498806330796 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark30(-65.4480435783448 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark30(-65.47222674071705 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark30(-65.4748727263065 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark30(-65.4952760107091 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark30(-65.54591849853233 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark30(-65.59095386006632 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark30(-65.5947144264526 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark30(-65.60871497208514 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark30(-65.64748382619902 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark30(-65.64791747468495 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark30(-65.67764564737173 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark30(-65.6808992180413 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark30(-65.68243612473202 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark30(-65.68485076288079 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark30(-65.73450257642423 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark30(-65.78134585258198 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark30(-65.78270609995349 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark30(-65.79327792686216 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark30(-65.80095616816149 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark30(-65.81456239122949 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark30(-6.585456360282109 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark30(-65.85504289400544 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark30(-65.90392626598495 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark30(-65.93483764180527 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark30(-65.93865504517373 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark30(-6.594323518127879 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark30(-65.94446927646501 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark30(-65.96101532846734 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark30(-65.96847683359272 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark30(-65.97789686632262 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark30(-65.99267024843394 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark30(-65.99269219219897 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark30(-66.040905631686 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark30(-66.07320525012128 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark30(-66.08724019766971 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark30(-66.11010276302889 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark30(-66.11434199332749 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark30(-66.127454615413 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark30(-66.1564223308196 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark30(-66.15930513902583 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark30(-6.616805652818101 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark30(-66.18415806236996 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark30(-66.186757724947 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark30(-66.22591302162823 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark30(-66.22811621872602 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark30(-66.22867472073114 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark30(-66.22976233149339 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark30(-66.28778607164338 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark30(-66.28928494209518 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark30(-66.32345238203101 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark30(-66.32482988153615 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark30(-6.63954592526359 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark30(-66.47372375280827 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark30(-66.49273165072054 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark30(-66.52984733934005 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark30(-66.57060002168195 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark30(-66.60917278791877 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark30(-66.62800284435492 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark30(-66.65518002367085 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark30(-66.66263067118908 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark30(-66.67882844747857 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark30(-66.78607771238785 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark30(-66.80114712295571 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark30(-6.6837567358782906 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark30(-66.94222278571948 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark30(-6.6965831425573725 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark30(-67.06796956773843 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark30(-67.07009750788933 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark30(-67.127390354077 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark30(-67.1329838293374 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark30(-67.13589510274838 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark30(-67.13774231210706 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark30(-6.714172087154438 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark30(-67.15331099755721 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark30(-67.15526050389977 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark30(-67.16334242037038 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark30(-67.19841736662215 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark30(-67.22637888161029 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark30(-6.725748710506039 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark30(-67.288858427597 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark30(-6.731577888210822 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark30(-67.32127294809874 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark30(-67.32178716535003 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark30(-67.39767993885788 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark30(-67.44480539421365 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark30(-67.44576354423023 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark30(-67.49142619008907 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark30(-67.50871321274576 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark30(-67.51720541686566 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark30(-67.53729123845966 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark30(-67.53851251684095 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark30(-6.755586627280067 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark30(-67.59694775911265 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark30(-67.59754991663138 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark30(-67.63055705968185 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark30(-67.63514026389979 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark30(-67.70437892271528 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark30(-67.72318327245151 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark30(-67.7300985906892 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark30(-67.74697370249467 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark30(-67.79157538823173 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark30(-67.80330152416742 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark30(-67.90761102557818 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark30(-67.93916330759286 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark30(-68.0447915390888 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark30(-68.05404390381787 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark30(-68.06327154428892 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark30(-68.11478056859968 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark30(-68.14971977722983 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark30(-68.15249300754436 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark30(-68.16223786661033 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark30(-68.19206937632079 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark30(-68.22323293428249 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark30(-68.2592572138979 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark30(-68.27119144362271 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark30(-68.27743898007313 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark30(-68.28024131812816 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark30(-68.29674643081758 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark30(-68.30045840346261 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark30(-68.34586342157769 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark30(-68.37551731440712 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark30(-68.41089192155935 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark30(-68.4248354365144 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark30(-68.43989727260421 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark30(-68.5633461230601 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark30(-6.857285908416216 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark30(-68.58605533056343 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark30(-68.6210586481451 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark30(-68.63645074512645 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark30(-68.67162149866746 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark30(-68.6939965942758 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark30(-68.71505334615351 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark30(-68.75133511162954 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark30(-68.7761308383281 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark30(-68.81767576284112 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark30(-68.85748971618564 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark30(-68.86706604090193 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark30(-68.90971245411315 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark30(-68.94098339337349 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark30(-68.94265136666455 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark30(-68.94607964729451 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark30(-6.894919914135315 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark30(-6.895072828972104 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark30(-68.9547326353059 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark30(-68.95918823571603 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark30(-6.89836171656772 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark30(-69.01068160203485 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark30(-69.03153257797408 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark30(-69.06054957651048 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark30(-69.10393881600443 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark30(-69.12429724921094 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark30(-69.13836557497817 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark30(-69.1601353565284 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark30(-69.17600535917722 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark30(-69.20300319575506 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark30(-69.2393757415357 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark30(-69.27079093410265 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark30(-6.927220280798068 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark30(-69.27777731856213 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark30(-69.29218361069205 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark30(-69.2954741654372 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark30(-69.30239737387475 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark30(-69.3442831876534 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark30(-69.41950003866633 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark30(-69.4322450071084 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark30(-69.4402719756702 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark30(-69.44417857988401 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark30(-69.45350013107935 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark30(-69.45437963165742 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark30(-69.45631156478458 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark30(-69.46750538671617 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark30(-6.948647615755192 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark30(-69.49369627042587 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark30(-69.6046153808155 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark30(-69.6172929174245 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark30(-69.6248726515625 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark30(-69.65293332331662 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark30(-69.66844916205494 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark30(-69.67436297563626 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark30(-69.68814866154611 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark30(-69.69964724258773 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark30(-69.71428983584804 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark30(-6.973492556454204 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark30(-69.74185814199683 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark30(-6.982285497646174 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark30(-69.84036829298839 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark30(-69.85189419679082 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark30(-69.85512946324735 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark30(-69.87426218807946 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark30(-69.88826669247581 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark30(-69.91484754128018 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark30(-69.91832995339489 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark30(-69.93947802127771 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark30(-69.97516161580731 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark30(-70.02364428839732 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark30(-70.0775036990606 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark30(-70.08630066520104 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark30(-70.0883346012523 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark30(-70.12275449551193 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark30(-70.13779401710516 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark30(-70.20679140302735 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark30(-7.022746279767091 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark30(-70.23354728228755 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark30(-70.23500000732065 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark30(-70.2599560392122 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark30(-70.29950017059328 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark30(-70.30362393253735 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark30(-70.4245268312624 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark30(-70.43553198108721 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark30(-70.44770225285124 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark30(-70.4665633425672 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark30(-70.50703584806124 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark30(-70.52933819491557 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark30(-70.54155319676897 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark30(-70.54287146811069 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark30(-70.55091814593234 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark30(-70.63429651225437 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark30(-70.63703158715478 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark30(-70.65191647857851 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark30(-70.65497569113124 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark30(-70.70719938942321 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark30(-70.73805214646028 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark30(-70.75275021270755 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark30(-70.7736981326558 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark30(-70.79897847283772 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark30(-70.80354750180044 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark30(-70.80440958061133 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark30(-70.81251268717712 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark30(-70.87520598487602 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark30(-70.91285409394942 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark30(-70.93205273525696 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark30(-70.98033645831472 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark30(-70.99831361542361 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark30(-71.01376657229858 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark30(-71.01755118153086 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark30(-7.104380215943436 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark30(-71.12855895249754 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark30(-71.14139008062925 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark30(-71.17716516376609 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark30(-71.19739313130226 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark30(-71.22951015108004 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark30(-71.24054313671671 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark30(-71.25224909655256 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark30(-71.25337573275431 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark30(-71.25393823946578 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark30(-71.29414059097101 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark30(-71.35305922578175 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark30(-71.3687231344966 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark30(-71.37866529019207 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark30(-71.40044697784695 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark30(-71.40826619033544 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark30(-71.45814556878736 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark30(-71.47278026513173 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark30(-71.48057466593585 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark30(-71.48885343806043 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark30(-71.53062393604696 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark30(-71.53752040592485 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark30(-71.54309268339382 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark30(-71.55969048454432 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark30(-71.57477032866947 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark30(-7.16053085611874 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark30(-71.62322936452448 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark30(-71.62825191859065 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark30(-71.63375681848818 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark30(-71.66837312395944 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark30(-71.70396562660737 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark30(-71.72585320542022 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark30(-71.75323718368855 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark30(-71.78782531148558 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark30(-71.79190614484222 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark30(-71.80425944613604 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark30(-71.83575031242614 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark30(-71.84410031345605 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark30(-7.186239906929572 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark30(-71.90364485125455 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark30(-71.91725929966415 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark30(-71.97008160073835 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark30(-72.00560776150932 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark30(-72.01172222318337 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark30(-72.01765599724861 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark30(-72.04022193219166 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark30(-72.0452969176159 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark30(-7.208553304459798 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark30(-72.08912683393976 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark30(-72.10016433017034 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark30(-7.211167869147943 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark30(-72.12303254700657 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark30(-72.1309903336665 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark30(-72.13137302215915 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark30(-72.16754492877413 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark30(-72.21113720231111 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark30(-72.2342429882078 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark30(-7.225821502863198 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark30(-72.26024797480552 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark30(-72.3002859820509 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark30(-72.3132733209055 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark30(-72.32157181295483 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark30(-72.33691021892227 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark30(-72.35420941244881 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark30(-72.3592784148969 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark30(-72.36284931136359 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark30(-72.38311537613922 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark30(-72.39682147270503 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark30(-7.2443876111227326 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark30(-72.46109482936116 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark30(-72.46215313516532 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark30(-7.250400673672928 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark30(-72.52831882691886 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark30(-72.52880793460865 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark30(-72.52895591124025 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark30(-7.259112826738772 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark30(-72.59510943425019 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark30(-7.262601351898638 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark30(-72.69103217960362 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark30(-72.69834523617394 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark30(-72.71448249804185 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark30(-7.272172197052313 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark30(-72.82753242625512 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark30(-7.2894424382691625 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark30(-72.89495645092406 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark30(-72.90418111556541 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark30(-72.92661322458684 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark30(-72.92769331722138 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark30(-72.9423012248291 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark30(-72.94273004446438 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark30(-72.98563050824725 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark30(-72.98634819095504 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark30(-72.99685538200475 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark30(-73.03707897967293 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark30(-73.04517650777407 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark30(-73.05930745874093 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark30(-73.06591041721092 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark30(-73.07101508941692 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark30(-73.09017980633016 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark30(-7.309427343333795 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark30(-73.16747720469724 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark30(-73.20823474913345 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark30(-73.2259441542812 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark30(-73.25741403539041 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark30(-73.257504482206 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark30(-73.25976901920457 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark30(-73.26194785811049 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark30(-73.28918302275291 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark30(-73.32960127762115 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark30(-73.33277008299902 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark30(-73.3572601014599 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark30(-73.36873739021644 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark30(-73.37515545603537 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark30(-73.38733103909297 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark30(-7.341058044920118 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark30(-73.43588690935707 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark30(-73.46892337030224 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark30(-73.47681712985138 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark30(-73.50615700183482 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark30(-73.51166812198912 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark30(-73.52065657965923 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark30(-73.55270254148414 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark30(-73.57055560320825 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark30(-73.59774945238698 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark30(-73.61096888137244 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark30(-73.61799130124847 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark30(-73.62238318729153 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark30(-73.63935379245616 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark30(-73.6632760011392 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark30(-73.67299428575805 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark30(-73.67901289388851 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark30(-73.68801953102226 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark30(-73.68894425407791 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark30(-73.71920793311335 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark30(-73.80724801488137 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark30(-73.89037374484113 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark30(-73.92235047586058 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark30(-73.9457831286837 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark30(-73.96079285094754 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark30(-74.00867307639432 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark30(-74.01196490504474 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark30(-74.0438587755722 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark30(-74.06654473382497 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark30(-74.07869003880873 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark30(-74.12450358444701 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark30(-74.13668898328783 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark30(-74.15527435669375 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark30(-74.1621497280631 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark30(-74.21897951124484 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark30(-74.2325559282966 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark30(-74.27464119495028 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark30(-74.28751703932453 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark30(-74.30138830881103 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark30(-74.31991825940803 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark30(-74.39834278703528 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark30(-74.45622585968849 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark30(-74.50342484495422 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark30(-74.52592488421612 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark30(-74.55439045898349 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark30(-74.56977368943265 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark30(-74.58445785766898 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark30(-74.59561270931673 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark30(-74.60487467621972 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark30(-74.60857081366565 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark30(-74.6240321974671 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark30(-74.6298032418267 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark30(-74.63160505270037 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark30(-74.67499335274263 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark30(-74.70656985269677 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark30(-74.72735788041243 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark30(-7.473504609027955 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark30(-74.7449283287053 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark30(-74.75970223782433 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark30(-74.77201047597306 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark30(-7.480637128866107 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark30(-74.81020934551019 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark30(-74.816711316409 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark30(-74.8211369915471 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark30(-74.88056184056396 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark30(-74.97392416405441 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark30(-74.99272956882119 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark30(-74.9962746266917 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark30(-74.99909622525918 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark30(-75.00976902112802 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark30(-75.03622875703675 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark30(-75.06541542398921 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark30(-75.0903203995329 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark30(-75.09813508846423 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark30(-7.509852955281573 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark30(-75.10021998003333 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark30(-75.10671245939709 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark30(-75.12010379289194 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark30(-75.1317909565052 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark30(-75.1746767497285 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark30(-7.523767316582081 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark30(-75.28785148150736 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark30(-75.31099083811853 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark30(-75.34017206246378 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark30(-75.36372576240382 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark30(-75.38706085804698 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark30(-75.38760972385295 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark30(-75.41057211862814 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark30(-75.46434752729236 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark30(-75.46467838169113 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark30(-7.551417787400766 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark30(-75.63799859842575 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark30(-75.66674189911438 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark30(-75.67928160855095 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark30(-75.71520401427985 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark30(-75.73703944677086 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark30(-75.74910723576194 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark30(-75.7637340488781 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark30(-75.80690702656926 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark30(-75.82829529372665 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark30(-75.85759695208705 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark30(-75.89099687574242 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark30(-75.89606828529556 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark30(-75.93098436448304 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark30(-75.94918200647683 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark30(-75.97686102806878 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark30(-76.0099118486587 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark30(-76.01805449148735 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark30(-76.02133461761707 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark30(-76.03727542174938 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark30(-76.04312473507584 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark30(-76.04954212794009 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark30(-76.06914674307438 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark30(-76.08083695314143 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark30(-76.08755073275427 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark30(-76.16075328106919 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark30(-76.17298534148432 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark30(-76.17761077063642 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark30(-76.18208862051145 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark30(-76.19132020252479 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark30(-76.22205304867407 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark30(-76.22668502314201 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark30(-76.2320063669797 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark30(-76.23372552301196 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark30(-76.26579263377143 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark30(-76.35266457668637 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark30(-76.37167491047678 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark30(-76.37767792783862 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark30(-76.38303906586374 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark30(-76.44157274642794 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark30(-76.46041053028745 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark30(-76.48435933039187 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark30(-7.648448780968025 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark30(-76.4992268922172 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark30(-76.5127686808193 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark30(-76.5291650463951 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark30(-76.53752436002337 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark30(-76.589018572362 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark30(-76.5955897337092 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark30(-76.63111155148621 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark30(-7.669040915566043 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark30(-76.69247120276592 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark30(-76.75888103504164 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark30(-76.76185900512205 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark30(-76.81684017814743 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark30(-76.82536252635558 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark30(-76.87173830963847 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark30(-76.89258642271295 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark30(-76.89646062563915 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark30(-76.96823169282013 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark30(-77.02998386321838 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark30(-77.03690035071014 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark30(-77.04076569324113 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark30(-77.08493028328509 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark30(-77.09009044758733 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark30(-77.1104645296692 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark30(-77.11778121948743 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark30(-77.1268254118268 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark30(-77.16875238756256 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark30(-77.2351271497284 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark30(-77.27548561099587 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark30(-7.731978162289494 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark30(-77.34741660276252 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark30(-77.36551232057826 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark30(-77.37632257842685 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark30(-77.39045143361403 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark30(-77.40324472189656 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark30(-77.40569675296693 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark30(-77.45116117378888 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark30(-7.746828290822634 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark30(-77.47571085411356 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark30(-77.4796101261269 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark30(-77.4889097557065 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark30(-77.50766479650271 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark30(-77.51882156383836 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark30(-77.54401465573815 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark30(-7.757655844453254 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark30(-7.763534314989954 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark30(-77.65723015468993 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark30(-77.68328989460073 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark30(-77.73935851121493 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark30(-77.74253092030274 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark30(-7.7799393364735465 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark30(-77.80006351610733 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark30(-77.80481765123164 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark30(-77.81043912724093 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark30(-77.81976549759047 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark30(-7.7825739665805145 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark30(-77.90031936107513 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark30(-77.9258008233745 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark30(-77.94622169322238 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark30(-77.95354577121012 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark30(-77.96552518398252 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark30(-77.97377740051066 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark30(-78.03116181139826 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark30(-78.03641995306016 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark30(-78.04550433080294 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark30(-78.05226370453107 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark30(-78.10302531931083 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark30(-78.1265711612135 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark30(-78.13027619253833 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark30(-78.14289467621867 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark30(-78.15646432426297 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark30(-78.19796960882277 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark30(-78.28404228216554 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark30(-78.28884656324053 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark30(-78.31489434972443 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark30(-78.31502715175947 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark30(-78.32279325845141 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark30(-78.32281520320039 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark30(-78.3241510638025 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark30(-78.34193725600514 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark30(-78.35220496367475 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark30(-78.38345912308726 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark30(-78.38992445752436 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark30(-7.839431213808837 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark30(-78.39718031067069 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark30(-78.40511161329091 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark30(-78.41559176181656 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark30(-78.43434376723404 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark30(-78.44179092844101 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark30(-78.46488627202079 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark30(-78.48090343865269 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark30(-78.48767420446367 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark30(-7.849470773577252 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark30(-78.50516675014487 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark30(-78.5754553099855 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark30(-78.57637578726788 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark30(-78.5785095394014 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark30(-78.60779958277485 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark30(-78.60811867039439 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark30(-78.661014409951 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark30(-78.67202376888599 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark30(-78.68604839583948 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark30(-78.7226869474396 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark30(-78.72940015513205 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark30(-78.7325303532807 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark30(-78.73264169093844 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark30(-78.73419669283106 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark30(-78.78754255572294 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark30(-78.78879230539009 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark30(-78.791089778722 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark30(-78.81894351936813 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark30(-78.84349753750008 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark30(-78.85266164867113 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark30(-78.85364768388817 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark30(-78.89259755030494 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark30(-78.89640544093133 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark30(-78.93586251915394 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark30(-78.93721344205717 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark30(-78.945475081204 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark30(-78.94951298466304 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark30(-78.97647061332059 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark30(-78.99167022987777 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark30(-79.00734724667961 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark30(-79.01422659558139 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark30(-79.02871579112977 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark30(-79.04752730948444 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark30(-79.04754449112004 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark30(-79.06384194262561 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark30(-79.0845170005052 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark30(-7.910872996484542 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark30(-79.13440125243937 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark30(-79.16891665763404 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark30(-79.18890612751818 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark30(-79.21420033614308 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark30(-79.23493344911421 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark30(-7.924005196335912 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark30(-79.2515536187765 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark30(-79.26294426854903 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark30(-79.2651451715664 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark30(-79.38595795618595 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark30(-79.402588758209 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark30(-79.48669596377506 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark30(-7.952013183724532 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark30(-79.53301371358859 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark30(-79.54606079909657 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark30(-79.55309258520037 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark30(-79.64374924122255 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark30(-79.66673135262164 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark30(-79.6775642354832 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark30(-79.73439412201053 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark30(-79.73735998176015 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark30(-79.77103002982912 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark30(-79.7798047629761 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark30(-79.83364998145741 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark30(-79.8394346456746 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark30(-79.85965201903558 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark30(-79.86242671791871 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark30(-79.87508911656533 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark30(-79.88075296540589 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark30(-79.90078722765182 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark30(-79.94085271826611 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark30(-79.96517509190122 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark30(-79.9754824334695 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark30(-79.98027055189804 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark30(-80.0217284201253 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark30(-80.02694129442281 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark30(-80.02815931812188 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark30(-8.00403752914589 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark30(-8.014477825947381 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark30(-8.029528568489908 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark30(-8.031760026766449 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark30(-80.32112662331478 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark30(-80.39035484059724 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark30(-80.3953428240645 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark30(-80.40891997307247 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark30(-80.42725024257484 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark30(-80.45284136273065 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark30(-80.4671758869296 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark30(-80.50926251152852 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark30(-80.52836470148294 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark30(-80.53377280132278 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark30(-80.6118172463101 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark30(-80.64825398302239 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark30(-80.70000980762217 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark30(-80.71134526636979 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark30(-80.81818790778767 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark30(-80.8949194551519 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark30(-80.89680494016824 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark30(-80.90628684128771 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark30(-80.91276279157955 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark30(-80.91300496254297 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark30(-80.91302972425207 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark30(-80.93226830303455 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark30(-80.98772027833856 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark30(-81.05761207548925 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark30(-81.06918899080624 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark30(-81.09402638347119 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark30(-81.15183158457968 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark30(-81.15312347351761 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark30(-81.16223978321901 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark30(-8.11848946712226 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark30(-81.20676225409261 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark30(-81.21965874091075 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark30(-81.22157069582215 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark30(-81.23648402218579 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark30(-81.28436739538805 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark30(-81.28718642056458 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark30(-81.32132206541473 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark30(-81.32596136928278 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark30(-8.132857431102963 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark30(-81.33451763458046 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark30(-81.3633333444784 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark30(-81.39833577786844 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark30(-81.40038705210716 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark30(-81.41012421451023 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark30(-81.41516705978387 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark30(-81.49151213503822 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark30(-81.50850294941765 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark30(-81.52186128770869 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark30(-81.52682994382481 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark30(-81.54051127161569 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark30(-81.54503643664609 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark30(-8.154964924860437 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark30(-81.60970396687935 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark30(-81.64869165737909 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark30(-81.65335892747976 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark30(81.70232024319958 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark30(-81.71039392431958 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark30(-8.171590920974253 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark30(-81.7596673762807 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark30(-81.80488735544043 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark30(-81.92829418313408 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark30(-81.96907085042685 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark30(-81.97542865256138 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark30(-82.01012916846182 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark30(-82.02122330087396 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark30(-82.07915272892237 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark30(-82.11926607625229 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark30(-82.20247111179928 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark30(-82.20379367302068 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark30(-82.20472362932223 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark30(-82.21622791326458 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark30(-82.22263575140052 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark30(-82.2268976607421 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark30(-82.25054398409819 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark30(-82.25795709691567 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark30(-82.3377965210305 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark30(-82.34265350155479 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark30(-82.37893281166022 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark30(-82.39897547429248 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark30(-82.40964077689135 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark30(-82.42046074669756 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark30(-82.44694240886312 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark30(-82.46885081852437 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark30(-82.5915557256365 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark30(-82.59789688895043 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark30(-82.62313156411724 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark30(-82.64289348829601 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark30(-82.7854818868208 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark30(-82.82838604808917 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark30(-82.85061397472472 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark30(-82.8570928608584 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark30(-82.87676082902581 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark30(-82.89322948134652 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark30(-82.9340689016997 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark30(-82.96415258614694 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark30(-82.97535764412149 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark30(-82.98782063606085 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark30(-82.99616350326846 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark30(-83.0053129461092 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark30(-83.02141096713238 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark30(-83.08902934794489 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark30(-83.09120380229784 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark30(-83.09816100523769 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark30(-83.1062258534273 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark30(-83.1321606732898 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark30(-83.19615463091358 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark30(-83.19745817116349 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark30(-83.2375897140791 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark30(-83.29131722282207 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark30(-8.330522486369361 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark30(-83.36100818452792 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark30(-83.37535219187369 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark30(-83.44182202472507 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark30(-83.4562935375854 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark30(-83.45888165247328 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark30(-83.46358650243302 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark30(-83.49372251556912 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark30(-83.50035327819887 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark30(-83.53943586855513 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark30(-83.57666038064488 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark30(-8.35936071597851 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark30(-83.61046275104631 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark30(-83.61073701767911 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark30(-8.361685603273528 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark30(-83.62125640536675 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark30(-83.69750580140717 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark30(-83.71832741636116 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark30(-8.37524478003266 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark30(-83.75718018919596 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark30(-83.85367047316761 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark30(-83.86755349962067 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark30(-83.88640588750567 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark30(-8.391732053618156 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark30(-83.93620368888317 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark30(-8.394603478529177 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark30(-84.061302742701 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark30(-84.06249131598645 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark30(-84.07402522144069 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark30(-84.07866557660431 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark30(-84.11579742646138 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark30(-84.120467772545 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark30(-84.13382431252363 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark30(-84.14122246623867 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark30(-84.18031290960877 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark30(-84.1865502412991 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark30(-84.18914678549723 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark30(-8.419027643422709 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark30(-84.19655233306338 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark30(-84.21073184657514 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark30(-8.42218136373387 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark30(-84.24692877761338 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark30(-84.31509799600425 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark30(-8.436856938281196 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark30(-84.38284440879178 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark30(-84.3889022295232 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark30(-84.39626791616242 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark30(-84.43354683615746 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark30(-84.4484850670548 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark30(-84.45634146863034 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark30(-84.49047897920418 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark30(-84.50331610167183 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark30(-8.454543743481807 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark30(-84.55169777332489 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark30(-84.5799499061768 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark30(-84.5955014340303 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark30(-84.61109124140248 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark30(-84.63068012115411 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark30(-8.463761267637167 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark30(-84.70012449927793 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark30(-84.74253592126439 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark30(-84.78341347437733 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark30(-84.78892008664505 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark30(-84.83429127390971 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark30(-84.85170678442262 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark30(-84.86457391220104 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark30(-84.8719445790442 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark30(-84.90608301262104 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark30(-84.94784201953986 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark30(-84.94801417819593 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark30(-8.49624820265042 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark30(-84.97355054512602 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark30(-84.98635102353482 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark30(-84.98795739357143 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark30(-84.99947359985633 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark30(-8.503757476893512 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark30(-85.09370467537607 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark30(-85.09720429393171 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark30(-85.1126292079922 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark30(-85.12359627609165 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark30(-85.13515001713577 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark30(-85.13571632977741 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark30(-85.1405162359226 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark30(-85.17842505720856 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark30(-85.19629689546949 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark30(-85.20672944362273 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark30(-85.21411397679282 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark30(-85.21771194537769 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark30(-85.23075470100294 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark30(-85.23871898245348 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark30(-85.24152002014517 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark30(-85.25330064963212 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark30(-85.30744274198557 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark30(-85.33435302151415 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark30(-85.34145647384692 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark30(-85.34546949750587 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark30(-85.41295402381883 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark30(-85.43034999278498 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark30(-85.43452408423953 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark30(-85.46631327622089 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark30(-85.47937954745626 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark30(-85.49907917510369 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark30(-85.52085595584158 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark30(-85.52570500393146 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark30(-85.56589041703299 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark30(-8.557615779801878 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark30(-85.59809618858397 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark30(-85.60226239388501 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark30(-85.62625142543187 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark30(-85.74376192692377 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark30(-85.80690860454354 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark30(-8.586280841421654 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark30(-85.86418851795975 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark30(-85.9338274940369 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark30(-86.0144729268793 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark30(-86.02731834618118 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark30(-86.04672514674618 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark30(-86.0468494036665 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark30(-86.0603573759233 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark30(-86.0748986724328 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark30(-86.10060493103873 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark30(-86.11095417965899 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark30(-8.612708364330302 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark30(-86.1461305267845 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark30(-86.15129842060824 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark30(-86.16439041479174 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark30(-86.23423871022624 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark30(-86.24316812707676 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark30(-86.2509429690477 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark30(-86.26265681745159 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark30(-86.28830425285977 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark30(-86.3361392045789 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark30(-86.34419529428715 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark30(-86.35968831513976 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark30(-86.36744203585857 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark30(-86.42864412776296 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark30(-86.50026258342018 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark30(-86.51915226632212 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark30(-86.60897853359879 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark30(-86.61045636271379 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark30(-86.61182885671403 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark30(-86.67343644255574 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark30(-86.75011580187468 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark30(-86.75648689644031 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark30(-86.79971219810022 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark30(-8.686814969936464 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark30(-86.86843755843275 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark30(-86.89976955910323 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark30(-86.94009684148607 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark30(-87.01469661970471 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark30(-8.705574874678732 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark30(-87.07012824790583 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark30(-8.708275065143184 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark30(-87.08277838238064 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark30(-87.1125852062449 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark30(-87.1335810981079 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark30(-87.14321891478649 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark30(-8.71481684087263 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark30(-87.15908309813123 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark30(-87.16202494389833 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark30(-87.18461889528547 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark30(-87.21058314108703 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark30(-87.21696955535161 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark30(-87.31194877433705 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark30(-87.31776176843853 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark30(-87.32781153842733 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark30(-87.37832823303661 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark30(-8.73842005403958 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark30(-87.38455353848249 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark30(-87.40055960328219 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark30(-87.4339085657594 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark30(-87.43982484328939 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark30(-87.44094553067087 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark30(-87.44753499586086 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark30(-87.49822439657318 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark30(-87.57839030227832 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark30(-87.62019838796297 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark30(-87.6538863022058 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark30(-87.69115457322204 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark30(-87.69625147821091 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark30(-87.81290891635444 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark30(-87.95930187894038 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark30(-87.96795975341016 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark30(-87.99535196676858 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark30(-88.0035321652373 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark30(-88.04459566830582 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark30(-88.04653299138916 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark30(-88.04870777018132 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark30(-88.07321558812976 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark30(-88.09357118747063 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark30(-88.13569728867014 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark30(-88.14822272361155 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark30(-88.15475300455313 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark30(-88.15888612533931 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark30(-88.16883588238869 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark30(-8.817199489993442 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark30(-88.20153326938487 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark30(-88.20181890494419 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark30(-88.20906715273358 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark30(-88.21331264368888 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark30(-88.23634604531338 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark30(-88.26297983494915 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark30(-8.827099364782626 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark30(-8.828352288683462 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark30(-88.30180183928802 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark30(-88.34181704856654 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark30(-88.3641920226273 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark30(-8.841053069239322 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark30(-88.41531240603146 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark30(-8.850531157632702 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark30(-88.58480563116895 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark30(-88.59262106651707 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark30(-88.63361778245633 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark30(-88.6517559637937 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark30(-88.67700459073602 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark30(-88.68259100254032 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark30(-88.73221090644499 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark30(-88.73686717282703 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark30(-8.875860047584652 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark30(-88.77915923913343 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark30(-88.79338134824644 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark30(-88.85111697025275 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark30(-88.87171964743412 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark30(-88.91899613841045 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark30(-89.02268486123175 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark30(-89.03813015774946 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark30(-89.05679585709971 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark30(-89.12997699645081 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark30(-89.13531733152875 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark30(-89.14274145800891 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark30(-8.916255871606566 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark30(-89.16878634569004 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark30(-89.17849127724224 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark30(-89.25715363325091 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark30(-89.27342096469812 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark30(-89.28009618427903 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark30(-8.930105939422361 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark30(-89.32721585498406 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark30(-89.3311350347425 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark30(-89.3393586627858 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark30(-89.40739665908323 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark30(-89.42797079787346 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark30(-89.43034802869542 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark30(-89.49109170572838 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark30(-89.54828296354205 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark30(-89.56540616054659 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark30(-89.61910204292369 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark30(-89.62712283062983 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark30(-89.64990128897605 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark30(-89.65552770554852 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark30(-8.966005703169017 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark30(-89.66452428982608 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark30(-89.7201137037271 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark30(-89.72282530731445 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark30(-89.72396379483169 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark30(-89.73397111219916 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark30(-89.74247763170935 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark30(-89.74610564813605 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark30(-89.7685398055873 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark30(-89.7738774001688 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark30(-89.82231603533643 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark30(-89.91758119531409 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark30(-89.94089010795429 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark30(-89.98290789375743 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark30(-90.04257248747894 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark30(-90.0475369546009 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark30(-90.10883700783216 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark30(-90.14610136665111 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark30(-90.17243194252094 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark30(-90.21120906492719 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark30(-90.28285761982346 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark30(-90.28819484551104 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark30(-90.30580896282758 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark30(-90.31633408893778 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark30(-90.33578191207184 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark30(-90.37502270637657 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark30(-90.38086545900535 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark30(-90.3973845145067 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark30(-90.4036996890059 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark30(-90.40806061126689 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark30(-90.43039727496571 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark30(-90.45981900245155 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark30(-90.48311429183687 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark30(-90.49687834104412 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark30(-90.53446046838027 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark30(-90.56440283013983 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark30(-90.56589523081213 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark30(-90.57008918945579 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark30(-90.57884868340975 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark30(-90.58887702584799 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark30(-90.60038727272747 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark30(-90.62621612441615 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark30(-90.6364522363948 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark30(-90.66125763894243 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark30(-90.69427805964699 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark30(-90.71121734234784 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark30(-90.72828742314618 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark30(-90.79970485082877 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark30(-90.82157684224225 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark30(-90.82604328192534 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark30(-90.87869368239447 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark30(-90.90058805097831 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark30(-90.91711873246602 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark30(-90.93533114135148 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark30(-90.94796257555795 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark30(-91.0375806516945 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark30(-91.06861734763586 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark30(-91.06985440960233 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark30(-91.08363668793027 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark30(-91.10743938266297 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark30(-91.12588598510783 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark30(-91.14029584763377 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark30(-91.16897691839955 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark30(-91.2683042501428 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark30(-9.127599497926838 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark30(-91.32068530851443 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark30(-91.34501639538442 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark30(-91.3743288931264 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark30(-91.38952375284654 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark30(-91.458984282565 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark30(-9.146853689082633 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark30(-91.488079888812 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark30(-91.50140832966915 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark30(-91.52479366377393 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark30(-91.55972543100815 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark30(-91.585853768821 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark30(-91.60940045165688 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark30(-91.64407110085389 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark30(-91.65081095390128 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark30(-91.6572039743204 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark30(-91.6745681296198 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark30(-91.75388790914111 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark30(-91.81604477900815 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark30(-91.83364480980293 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark30(-91.84600364485274 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark30(-91.84950679225724 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark30(-91.85594006224295 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark30(-91.94548619816842 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark30(-91.97952050532747 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark30(-92.00009825305668 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark30(-92.00193548617743 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark30(-92.03108758074458 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark30(-92.0321287792031 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark30(-92.04141817411666 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark30(-92.06388422455409 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark30(-92.13431056638075 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark30(-92.15771899390654 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark30(-92.15849763056947 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark30(-92.17593634863424 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark30(-92.19539881483495 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark30(-9.21958504265055 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark30(-9.227697082073291 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark30(-9.229550911072664 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark30(-92.32664052042084 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark30(-92.33199891608112 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark30(-92.3539078446122 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark30(-92.39221142167466 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark30(-92.4298304779384 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark30(-9.247079251880862 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark30(-92.47174178834214 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark30(-92.47781466359449 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark30(-92.50414681330696 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark30(-92.5245561934148 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark30(-92.53170775387221 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark30(-92.58473639826823 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark30(-92.61025610897462 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark30(-92.63976865241908 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark30(-92.64148339061178 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark30(-92.6630709760404 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark30(-92.66493240700429 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark30(-92.70913110171972 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark30(-9.271357373650034 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark30(-92.71982755521393 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark30(-92.75094424726814 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark30(-92.7514746376382 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark30(-92.75451879768089 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark30(-92.79218982225271 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark30(-92.84802487357133 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark30(-92.84860059091069 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark30(-9.286077149922136 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark30(-92.89246170516007 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark30(-92.90698203773493 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark30(-92.93943609852724 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark30(-92.94104176053013 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark30(-92.96259411111996 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark30(-92.99559855557928 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark30(-93.01032096634086 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark30(-93.02689252282829 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark30(-93.05338619173256 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark30(-93.07325191661198 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark30(-93.080955899456 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark30(-93.0961337823154 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark30(-93.11673363995807 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark30(-9.319605390430397 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark30(-93.21057381228492 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark30(-9.321772172487158 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark30(-93.28778154865056 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark30(-93.29985635700004 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark30(-93.30586121213196 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark30(-93.31781906437196 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark30(-9.337223877656626 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark30(-93.39330640026242 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark30(-93.40044853343916 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark30(-93.41692430340352 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark30(-93.43250330167487 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark30(-93.43901760332211 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark30(-93.46008384290916 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark30(-93.47088011512072 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark30(-93.47268137697336 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark30(-93.48569160434495 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark30(-93.49597082637764 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark30(-93.56582576291362 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark30(-93.58723425209674 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark30(-93.59997066766559 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark30(-93.63392455045721 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark30(-93.67536588137094 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark30(-93.68046201528087 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark30(-9.369411791990089 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark30(-9.372224263165634 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark30(-93.7268105438215 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark30(-93.7559837498889 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark30(-93.76689222160923 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark30(-93.78002772077596 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark30(-93.80800339608624 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark30(-93.82830153275205 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark30(-93.92988629531598 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark30(-93.94099924970054 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark30(-93.94532197244745 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark30(-9.395939408305722 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark30(-93.97178151267434 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark30(-93.9846567947692 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark30(-94.00266052040362 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark30(-9.402368427855052 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark30(-94.04530303666236 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark30(-94.079204115025 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark30(-9.40955008244633 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark30(-94.11203367028051 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark30(-94.15624952829928 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark30(-94.21158386429988 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark30(-94.2269630124667 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark30(-94.23084983098464 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark30(-94.27131409901767 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark30(-94.29530638901436 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark30(-94.49449010322688 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark30(-9.451736442977008 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark30(-9.454906347442062 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark30(-94.5898534366209 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark30(-94.61259971932651 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark30(-9.465125370697905 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark30(-94.65716806972033 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark30(-94.66470394524606 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark30(-94.68148360456776 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark30(-94.6888216867522 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark30(-94.6909626931122 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark30(-9.470365005552466 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark30(-94.70677687826851 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark30(-94.71633735422441 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark30(-94.76141771581614 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark30(-94.76544745442068 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark30(-94.80101333559124 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark30(-94.81011109147603 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark30(-94.81072643527986 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark30(-9.481242993284809 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark30(-94.86723155376013 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark30(-94.8964286621697 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark30(-94.9068665944038 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark30(-94.95757619300448 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark30(-94.96191385862087 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark30(-94.9767290901468 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark30(-94.98260236381586 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark30(-94.98332547445227 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark30(-95.06118165885087 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark30(-95.0660081928352 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark30(-95.0968220748507 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark30(-95.17707346424962 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark30(-95.18060059615301 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark30(-95.21676079242116 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark30(-95.23062698231641 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark30(-95.28246619831155 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark30(-95.37100172478532 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark30(-95.39833688686147 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark30(-95.43777429826883 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark30(-95.47269944096153 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark30(-95.61773609762294 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark30(-95.61834184956759 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark30(-9.562736600472334 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark30(-95.630701253541 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark30(-95.63953068524008 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark30(-95.66151552902981 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark30(-95.73082051936004 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark30(-9.582658843489341 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark30(-95.85547669019473 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark30(-95.88918176624846 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark30(-95.89178254284305 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark30(-95.94499207913252 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark30(-95.9941864096177 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark30(-96.03987792617441 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark30(-96.05529041239822 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark30(-96.07775358505313 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark30(-96.09260369528359 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark30(-96.09956983059962 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark30(-96.1131797145209 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark30(-96.14292907180007 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark30(-96.15448609825603 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark30(-96.16094073648058 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark30(-96.20606407843242 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark30(-96.20833454687363 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark30(-96.25884491192058 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark30(-96.25922698985579 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark30(-96.26336679227319 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark30(-96.26707189326589 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark30(-96.27960483122958 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark30(-9.633183815327627 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark30(-96.38784901589031 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark30(-96.39150209487875 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark30(-96.41344637243903 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark30(-9.641406828639504 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark30(-96.42748779421358 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark30(-96.43886331998952 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark30(-96.44170073817708 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark30(-96.47515615140709 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark30(-96.52965366575839 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark30(-96.53790714129558 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark30(-96.5670533536601 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark30(-96.64398874626747 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark30(-96.65935674023206 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark30(-96.71091596190044 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark30(-96.71267392424569 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark30(-9.67315133007807 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark30(-96.78385994138961 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark30(-9.678613806591855 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark30(-96.87660868578757 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark30(-96.91214755996623 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark30(-97.01004018921296 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark30(-97.09943889865049 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark30(-9.71456023568878 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark30(-97.2279986832234 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark30(-97.25606945492389 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark30(-97.32105805442029 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark30(-9.732993701016014 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark30(-97.36140805757817 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark30(-97.36489933998887 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark30(-97.38505192099292 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark30(-97.46736458704555 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark30(-97.47589865107291 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark30(-97.48601982294547 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark30(-97.48673385892567 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark30(-97.581815633104 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark30(-97.58278020794873 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark30(-97.58531089771023 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark30(-97.62788795745074 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark30(-97.65951410207671 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark30(-97.7091186167995 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark30(-97.71297331788995 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark30(-97.74368587194841 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark30(-97.7527369777767 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark30(-97.76341184650548 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark30(-9.777900908074159 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark30(-97.78291053743328 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark30(-97.81621369316873 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark30(-97.82075940134425 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark30(-97.83045080934943 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark30(-9.785286565215017 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark30(-97.85850446590084 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark30(-97.93156629166022 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark30(-97.95257343468874 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark30(-97.95572845110112 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark30(-9.79612449922169 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark30(-97.99338299737721 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark30(-98.02118475238669 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark30(-98.04289929205679 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark30(-98.05246297135062 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark30(-98.05883487296857 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark30(-98.18018325531226 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark30(-98.19444619024227 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark30(-98.21598250682872 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark30(-98.24862261359128 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark30(-98.29752815993038 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark30(-98.34235145331654 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark30(-98.39382734244295 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark30(-98.40126836488679 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark30(-98.43396192137457 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark30(-9.845960348172937 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark30(-98.52220409139008 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark30(-98.52382111338439 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark30(-98.53260131030919 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark30(-98.58973715396078 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark30(-98.61127795748806 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark30(-98.61156486133589 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark30(-98.62409606145457 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark30(-98.63589090482121 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark30(-98.64103042585278 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark30(-98.66940931635668 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark30(-98.68509827442622 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark30(-9.870389077290099 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark30(-9.872052342411862 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark30(-98.7216859360282 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark30(-98.728634986885 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark30(-98.81716278566925 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark30(-98.8379876067262 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark30(-9.89030903715819 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark30(-98.92118141801691 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark30(-98.93593828189364 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark30(-98.94710271952829 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark30(-98.95747054723611 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark30(-98.98221925966104 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark30(-98.98675043908077 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark30(-98.99855873137378 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark30(-98.99900760424087 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark30(-99.07044959020924 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark30(-99.07842646969438 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark30(-99.09128836748107 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark30(-99.11438625317153 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark30(-99.120349186797 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark30(-99.18536853267614 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark30(-99.19522780503955 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark30(-9.919781994423388 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark30(-99.20618245911311 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark30(-99.2273657999629 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark30(-99.38909920898588 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark30(-99.42112439335098 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark30(-99.42377660126542 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark30(-99.46126687619987 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark30(-99.46321275190809 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark30(-99.47982115989056 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark30(-9.948475056758994 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark30(-99.56730242522023 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark30(-99.62192291798007 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark30(-99.7418549424379 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark30(-99.74846114011626 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark30(-99.76187623709039 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark30(-99.77710034027515 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark30(-99.79495697219778 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark30(-99.7997945354272 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark30(-99.80702729674336 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark30(-99.88630084051255 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark30(-99.940855747917 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark30(-99.95304772053306 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark30(-99.99838033552906 ) ;
  }
}
