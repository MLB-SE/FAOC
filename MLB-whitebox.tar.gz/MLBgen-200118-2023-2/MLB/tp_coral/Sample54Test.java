import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.005387602664135638,-7.590642810222945E-16 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.04304282367461337,-25.648500343964088 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.05621480287204779,1.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.065080273601727,88.0253798621664 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.10077226970244346,-0.6833750379323899 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.1570563745451904,13.495009250051027 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark54(0.001684339491765504,-1.5707963267947491,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.20734700142700946,38.68685423359526 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.24746139211975737,2.1084395886461046E-81 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark54(0.0033746648850607242,-1.5707963267946212,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.40901041997884907,1.00000000842571 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark54(0.0047124827377469855,-0.738756292589569,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.5821178841275592,85.86630089070536 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.5837718948001704,-0.45433746865618174 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.5840125075839955,-0.1006316950013203 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.5859778904227813,1.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.5908708403436269,1.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6017066636446498,98.79112309834477 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6170783126515439,0.06255286838721484 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.625240368823583,1.0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6437630851155054,1.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6607615420747521,-1.0000000063180579 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6848303869948765,-100.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6880016906468427,1.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.697659687206306,0.9086154148103518 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7012884974784421,-4.2168791772922093E-81 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.71218684311299,-1.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7173172606718708,-50.03279492560078 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7234114705896388,-1.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7296658663054366,1.0000000372918778 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7389275767036017,-40.18002345524781 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7406118379192463,-0.9999922024107696 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7421079041592211,-0.03626940600742454 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7600403273820465,-0.01977947990735325 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.766824281530068,-1.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.77817092699672,-28.477757320265997 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7821585452571518,1.0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7871038607691638,-0.8831413634695597 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.79362828642427,-1.0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7964051804938449,-26.596249725318803 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8038212712896794,52.32970486376472 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8164081298977358,-2341.2552517355653 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8262187223339978,0.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8345295098460587,71.00761365403987 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8457970656268259,-1.0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8500253865167738,-1.0000005064940078 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8575064289774601,-22.806208408562483 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8699383456479359,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8796736079161547,1.0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.885898769069707,0.9753838046587759 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8890214670776828,-1.0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8910946775489897,92.80200216616885 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8973188892854309,-85.15206723074081 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9050375530397314,-1.0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9076888657852117,1.0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9129503322712164,0.9651301229798668 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9193943083775514,1.0000000000000002 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9372634828275096,1.0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9388565682245974,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9445419277900999,0.4107442912794348 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9467941971740519,-0.06256569530920382 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9468464854195744,-84.17471905302354 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.948363211652391,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9572824646442651,-0.05336836041054585 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9603944746760191,0.712483713056681 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9659894604290086,-0.3042160049086915 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9723610925587849,-0.9417553992208911 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9759295775236667,-1.0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark54(0.009770695080028991,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9796108975277207,1.0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.0027830790911403,-100.0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.0098679137359046,-1.0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.0134985348488923,8.534837505052712 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.0179748806567785,5.23948779323156E-15 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.0343098523524876,-0.9345661956362041 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.050927725229912,2271.8036978997466 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.0625071749094421,-1.0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.0642950555388917,-21.941881977750114 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark54(0.010728572043007322,-1.5707963237589337,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5111245314651307,0.033186943824328075 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5148321241292635,-35.624323927320845 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.515382902987493,-0.227765789232946 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5198406739037806,-5.965692172452628 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5254750758194098,-0.24614015950577528 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5260013531239056,1.0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5282778265309678,1.0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5288068490564504,0.643883789155228 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5321285109931968,1.0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5327187236142736,0.9737750454980681 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5344136578990861,0.023290482908196353 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5366076796155668,-1.0417424979803416 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5373017807707408,60.33067018713649 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5481879464752755,-0.9999999999999929 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5498250566510725,48.51021836990569 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5507759778291605,2185.523374705606 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5630023002938969,23.82025507074627 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5704810247035428,-98.60124304071974 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707678774118272,0.017503128204914127 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707962922995458,1.0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267394314,5.421010862427522E-20 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.570796326791804,-36.062238647033325 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267919016,-1.0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267940293,-0.041532803483383396 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267941345,-100.0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267942873,-1969.8144780203145 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267943406,0.3471389871746112 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.570796326794445,1.0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.570796326794458,-0.9122087841735188 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.57079632679448,82.70337356584892 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.570796326794575,-1.0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267946035,0.8010211660451176 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267946639,100.0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.570796326794703,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267947316,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267947642,0.0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267947656,59.30638832616561 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267947713,0.41631395052581865 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.570796326794781,-1.0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.570796326794896,-0.046533747532434666 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267948961,0.06213520723939436 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267948961,0.6739588042541662 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267948961,0.9996986705069277 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267948961,-1.0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267948961,49.79199237851646 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267948963,0.817833238020731 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267948963,-0.9702065362021393 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267948963,0.9797432456092772 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267948963,1.0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.5707963267948963,-100.0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark54(0,-0.1594071896431415,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark54(0.0,2.670208929283102,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark54(0,0.2900978413478157,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark54(0.031074073392446167,-1.570796326794735,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark54(0.042688991903026614,-1.5642070254213332,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark54(0,-0.4342906094889951,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark54(0.04457336311829993,-0.8824651080580181,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark54(-0.04490322421918367,-0.9433510829160291,-0.5766829187828215 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark54(0.048031133519361585,-0.9705860505709865,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark54(0,-0.5223414904463596,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark54(0.06429697040643584,-1.5707963267947056,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark54(0.07206425014502059,-0.6602805809098882,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark54(0,-0.815728483306267,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark54(0.08484408593788118,-1.0634427198698653,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark54(0.08619177114514973,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-9.217731736766284E-11,-76.25882994793186 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark54(0,-0.993671373457143,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.025436720709223,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.0643970267276899,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.0898345751692489,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.2717796581258671,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark54(0.12936328698847652,-0.564835980633224,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark54(0,-12.996657717096213,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark54(0.1426289228794776,-1.5273207388473204,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.5540520377136193,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.5707963267948806,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.5707963267950105,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark54(0,-17.288460729844218,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark54(0.21737284278532065,-0.0029962066776254015,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark54(0.230688744803345,-1.0686605861989449,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark54(0.23988515401471475,-1.5707963267947767,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark54(0,-2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark54(0.24866514519251837,-0.9042864021017735,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark54(0,-2.5188264487089655E-10,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark54(0,-2606.3049025357236,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark54(0,-2732.312330575065,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark54(0.2750940931297165,-0.25144759548682394,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark54(0.2874460929922464,-1.57079632657216,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark54(0.2988789927424619,-0.9793830458033006,0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark54(0,-31.276146776127135,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark54(0.31874047528461347,-0.6656766616312977,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark54(0.3384306268485325,-0.600768576571986,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark54(0.3601231613906979,-1.0235481807880142,0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark54(0.3894823915593406,-0.6915915003164015,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark54(0,3.9432865382323,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark54(0,-40.28410705133787,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark54(-0.46273120793590367,-0.7782123847862398,-9.186626897101693 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark54(0.4719424920968253,-1.5318694970299418,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark54(0,4.748053124713223,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark54(0.48364626629852064,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark54(0,-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark54(-0.5148336827032269,-0.5095494592133373,2196.685331713498 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark54(0,-52.39636542214572,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark54(0,-53.838385274081176,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark54(0,-60.38112810294434,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark54(0,-60.73011403465387,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark54(0.6125311921512804,-1.570796326794298,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark54(0.6181762161058941,-0.5997397120659684,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark54(0.6182662020002015,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark54(0.6263005054817584,-0.9410018485885421,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark54(0.6514686718273737,-0.5348837211974339,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark54(0.6827786304810055,-0.6794222170312598,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark54(0,-70.12321326124764,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark54(0.7075359364741947,-0.7100702846407516,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark54(0.7171524636873698,-0.8709013302260828,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark54(0.72014977078463,-0.6983364122078939,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark54(0.7230950879875164,-0.6384789513705389,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark54(0.7266661490757258,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark54(0,77.25729691434336,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark54(0.8390733047948942,-0.6423083935756773,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark54(0.8525143653724796,-0.7093571457820216,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark54(0,-8.63388139214429,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.009028532190684113,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.014778884012364317,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.026178624378399795,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.03042006254824836,23.66581676592807 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.1330536405175896,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.30652576793297726,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.3154749516261818,1.0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.34381839343374104,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.5748047741211464,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.5752668699858043,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.5868514402358355,5.551115123125783E-17 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.5880240444893872,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.5904955607289724,8.881784197001252E-16 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6009861975285702,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6246344342935811,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6433925489062011,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6504093024277965,0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6597898390332658,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6622388323242419,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6697159085734832,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.67650737287933,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6942985361527692,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7073460820454692,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.7116781186081802,-0.3777519522101116 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7171852910382768,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7310719177298131,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7413974894362887,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7503615911830464,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.756094130312424,16.58605544825714 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7565440298715541,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7588587237863917,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.760395046757739,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7669658116142406,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7882908692287407,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7938932361109465,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.796901699818815,-1.0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.797185824238765,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8074054457341893,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8164573630790024,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8242358854685,0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8318272997466941,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.8348176292558338,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8435993724936807,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8589228835532547,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8930501891882296,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9079983552274806,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9417545079741725,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9468883363509354,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.9473708992258092,96.45281082427746 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9482433422425294,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9616888907069336,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9660367883582239,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9684436067190192,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9739441859473033,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.9750520886909158,1.0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9786928275030402,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9836701337600509,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9925234688846043,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0064465993959288,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0118727215430126,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0224704578475499,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0283596177734946,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.036100414553558,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.0382574332234835,83.27905546256541 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0467338757944864,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0578120530292239,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.0593535071238116,0.6717060830459092 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0626034585744,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0681442810448556,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5091430927711111,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5104442892165766,0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5119777173449482,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5123035643668725,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.512371577498791,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5135087501447781,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5147324445135435,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5147505602399716,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5156783577062387,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5165477340658011,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5174413749744184,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5174885376681106,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5176507215126223,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5190053345893793,0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5196539136361236,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.5215444074027156,-1.0000001549336814 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5244844148820014,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5259196921765317,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5322069709795698,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.535836918597956,-1.0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.546266015534208,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5479418131280218,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5487405889928698,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.551270994240892,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.552218573587984,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5547886285991848,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.56564174880693,-1.0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707718199476894,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.570794169000356,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.570794493083968,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.5707963244040322,0.0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963266435883,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.570796326761183,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267915304,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267916085,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267918643,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267920348,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267927856,0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.570796326793026,1.0458649816480474 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267930332,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.5707963267940235,-1.5197027909234935 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.570796326794035,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267940386,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267940777,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267941936,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267942269,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267942446,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267942517,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267942624,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.570796326794264,1.0000000000000002 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267943248,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267943477,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.57079632679438,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267943925,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267944471,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267944827,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267945004,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.570796326794504,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267945253,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267946141,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267946248,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267946279,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267946674,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.570796326794671,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267946745,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267946958,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.570796326794711,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.570796326794742,0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267947562,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267947573,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267947598,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.570796326794766,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267947687,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.5707963267947689,-1.000000030533238 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267947704,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.570796326794771,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.570796326794772,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.570796326794773,-0.02364370898336767 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.570796326794896,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.5707963267948961,-0.7047499632694685 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.5707963267948961,-19.905767137453402 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.5707963267948963,0.9999999999999999 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-2.3081484186881397E-9,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-3.4163827554445136E-7,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-3.717786365061365E-5,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-9.847708528235314E-9,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark54(10.027630806870988,-0.6014550100611149,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark54(10.051992310946176,-1.5707963267947562,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark54(1.0063756830776274E-5,-0.6118781191822918,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark54(10.090279529644802,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark54(10.112411410356717,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark54(101.40137036945345,-0.6675677707377835,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark54(101.46755189681035,-0.8918059376742988,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark54(10.152114915586951,-1.5420393049589751,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark54(10.175778419539583,-0.6061966379925456,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark54(1.0204856784111245,-1.5707963267943086,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark54(1.0237943474794768,-0.23932623254761654,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark54(10.315600117311192,-0.5907096334451831,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark54(10.329723287040048,-1.0239281169434749,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark54(10.359082108900381,-0.5509302914212056,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark54(1.036253989034023,-1.0118229234421223,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark54(10.4653597097097,-1.0125633141006003,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark54(104.76631329773141,-0.9536728965679119,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark54(-10.546177207491183,-0.5819209371379402,1.0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark54(10.548820185980336,-1.011006477804419,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark54(10.549324266877093,-1.048487715729124,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark54(10.579312252292155,-0.7363011779812272,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark54(10.606487464759605,-1.5160873672842325,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark54(10.693464087322083,-1.5707963267946745,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark54(1.0842021724855044E-19,-0.9675953657052092,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark54(10.966040551962138,-1.5351977923558244,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark54(11.047795073539124,-1.5707963267947775,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark54(-11.056723064382126,-0.988503501750813,13.36610767510232 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark54(1.109162979027019,-0.07015445354251593,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark54(1.1102230246251565E-16,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark54(-1.1102230246251565E-16,-2.479719713265052E-4,-1.0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark54(1.1111866336459997,-0.08285045360974758,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark54(11.148775284270634,-0.6145326468884247,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark54(11.16127928626183,-0.4802619954239614,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark54(1.1168673990751467E-5,-0.7573044084103203,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark54(11.17091808025674,-1.0144426557512536,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark54(1.118982418605816E-11,-1.5707963267919287,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark54(11.200546093199563,-0.6918918991323295,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark54(1.1247497970826572,-1.5707963267944258,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark54(11.268618472806507,-1.5707963267921439,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark54(11.316789900314618,-0.6177048253673352,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark54(11.322008977699838,-0.23170510581236858,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark54(11.350216463467227,-1.5707963267427203,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark54(11.359371520992344,-0.6616635003830398,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark54(11.371983431863114,-1.067508948771411,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark54(11.384689004130337,-1.0553578941953883,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark54(1.143458567004112,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark54(11.507812604772965,-0.8123206621615537,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark54(11.564797990117356,-1.5707963238763532,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark54(11.579563227918925,-0.8277210256892003,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark54(11.700027541812915,-1.52536122011837,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark54(11.782388333157371,-1.5707963267947767,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark54(11.813810955835468,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark54(11.884903590548006,-1.0121552674900638,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark54(11.920062062501842,-1.5351535852825902,0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark54(1.1981105134474745,-0.9416830622146222,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark54(12.023539767616946,-0.5810148964252161,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark54(12.031148235480622,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark54(1.2048834145108782,-1.5707963267945004,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark54(12.059729351377442,-1.5513419647758,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark54(1.215578047715748E-17,-1.5287461917536185,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark54(12.184807627151343,-0.6489096971140631,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark54(12.204798991600626,-0.8145566803711652,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark54(12.29371799308791,-1.066370046601969,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark54(12.312629798635982,-1.5707963267946385,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark54(12.331065279456238,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark54(123.39502547184657,-0.8842801970746397,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark54(12.387339969921062,-0.8202011466079047,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark54(12.425087600446552,-0.7006031303793092,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark54(12.44876229670109,-0.801171688377031,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark54(1.2448826688151942,-1.5707963267943974,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark54(12.500926342035427,-1.5411948683980257,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark54(1.2524976476613716,-1.5634205045491871,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark54(-12.530271096564563,-0.9806312066794397,-1.0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark54(12.549553474842327,-0.7803131655273168,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark54(1.255710398940053,-1.5301625847361748,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark54(12.561525763148182,-8.821175041629364E-9,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark54(12.578543081426574,-0.7979780993960457,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark54(12.585798371154672,-1.5707963267940137,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark54(12.629928158757807,-1.5707963267940244,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark54(12.662185624713018,-1.5108142394621444,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark54(12.721822758815971,-0.5900195821309402,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark54(1.2759265240679127,-1.0539441075216962,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark54(12.850225820531705,-0.9572750048654481,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark54(12.874993481525935,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark54(1.2924697071141057E-26,-0.6481024621612675,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark54(-12.946680917374565,-1.5206602282696178,-100.0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark54(1.2993889665817475,-1.5499933505705732,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark54(12.997522801710275,-0.6937229900355554,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark54(13.008407404607077,-1.569922168503002,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark54(13.079409528027576,-0.9879906151760416,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark54(13.126269336818467,-1.5338365703651875,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark54(13.179480959964735,-0.7885572758413816,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark54(-13.221963717439806,-1.0063600223683808,-0.023370048168459334 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark54(13.253905397556935,-0.9484157944345757,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark54(1.3271880983468378,-1.5114390839436354,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark54(13.30037900883751,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark54(13.322496943920484,-1.0090393658078092,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark54(13.418932243725097,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark54(13.445529078950642,-0.6594506249365679,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark54(13.46649961547925,-1.5707963267927312,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark54(13.47105084055569,-1.5707963267946425,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark54(13.510601325372775,-0.4676095298712629,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark54(13.56766863972041,-1.5160115073080158,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark54(13.569970467150142,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark54(-1.3593030305917466,24.204765622382965,-40.435869827447554 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark54(13.630500106186828,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark54(13.632715815103325,-0.7611445372564225,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark54(13.639066552406057,-0.8655757579835623,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark54(13.682109997036179,-1.5524517487357337,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark54(13.704841829308762,-1.003634695981326,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark54(1.3714494575236955,-0.6729653964082587,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark54(13.744946699367034,-1.5707963267947456,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark54(13.776535674882165,-0.004038614714838962,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark54(13.781704919889586,-0.2864205689347562,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark54(13.803930842048558,-1.516684797459436,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark54(-13.861206621967218,-1.5707963267940734,-53.10198099914071 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark54(13.890862826433263,-1.51285697719109,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark54(-13.911570662966767,-0.8456499709812976,-0.03056053242746437 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark54(13.964471679439043,-1.031627385493504,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark54(13.989846583601441,-0.11554922581428617,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark54(14.00281305670769,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark54(14.017397743351097,-0.9801290952045998,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark54(14.057702454460143,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark54(14.074361562878629,-1.5707963267944345,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark54(14.088547091939915,-1.5707963267929443,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark54(-14.15111186641637,-1.570796326794781,-0.9505699079865564 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark54(14.15786594753212,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark54(1.4163606401781921E-15,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark54(14.165205587742946,-0.9896649004766997,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark54(1.4210854715202004E-14,-0.5966319841377326,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark54(1.4210854715202004E-14,-0.6104049843339396,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark54(1.4210854715202004E-14,-0.8398930826905655,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark54(1.4210854715202004E-14,-0.935641145605052,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark54(1.4210854715202004E-14,-0.9696499980303033,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark54(14.220735972735227,-1.509933872386152,0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark54(1.4226800586198518,-0.07986833542196614,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark54(14.267067045181982,-0.1987405553932497,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark54(14.318599742233744,-0.6386916479555413,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark54(-144.23954036931744,-0.519411350398309,-0.4660532617813544 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark54(14.480403717919131,-1.5304178312854466,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark54(1.4512187978173745E-10,-0.7902537760602328,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark54(14.550471581519735,-0.8429800824613612,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark54(14.567121887058462,-0.6352018702805688,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark54(1.4573853644878056,-1.025995875722737,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark54(14.589794308418917,-1.5707963267943938,0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark54(14.627294087996091,-0.7564128154049219,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark54(-14.662341657088874,-0.8493357609241922,-0.36209105998669194 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark54(14.688784886044585,-1.5707963267947767,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark54(14.732620899851987,-0.93496711892766,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark54(1.4757340172742435,-0.19990573803967704,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark54(14.770251257498051,-1.5320534173211433,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark54(1.4792197968743395,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark54(14.881663360215839,-0.9301598656997574,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark54(1.496237540431693,-1.0117428939537376,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark54(14.977529649416965,-0.9143691300311747,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark54(14.98428312896772,-0.9242894373802848,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark54(15.00311300624902,-1.5088885537662404,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark54(15.095128750587492,-0.9996154141423954,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark54(15.09568639492474,-0.8532436257011486,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark54(15.100112632003485,-1.0160206799611302,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark54(15.164569341562393,-1.519342843037913,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark54(15.209649176665323,-1.5365168450382223,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark54(15.252060715343474,-0.935393547947367,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark54(15.278263413818717,-0.7038398082324656,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark54(15.293222839414454,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark54(15.43235879402632,-0.6714631889134637,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark54(15.456020666507484,-1.0104700473671357,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark54(15.465536069455545,-0.790694622330632,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark54(15.560200137159464,-0.8243921854769599,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark54(15.608548193203678,-0.2679738970266931,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark54(15.610978166329986,-1.0250206759557003,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark54(1.5614700607427494,-1.570796326794337,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark54(15.645734220516076,-0.7757744073531256,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark54(15.647313256055313,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark54(1.5661692722058513,-1.5631864665906368,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark54(15.67862164277102,-1.047708713947269,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark54(15.70141651688995,-1.028170614703754,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark54(15.7411972602555,-1.5371785944338057,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark54(15.742519601256756,-1.0598095954980105,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark54(157.89868760864658,-1.518181291218728,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark54(1.5802307594657727,-1.5337254176027288,0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark54(-15.83283175680397,-1.5707963267948963,-7.115475628174257 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark54(15.847198174027303,-1.570796326794896,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark54(15.868935042664866,-0.8018391137453333,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark54(15.88276964163542,-0.8411541695356541,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark54(15.963610571002912,-1.554090167156117,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark54(16.01134108289992,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark54(16.089272137705024,-4.4589263799999636E-5,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark54(16.095043671231863,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark54(16.09790824014712,-1.5470023535598352,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark54(16.13448004713038,-1.5423611821031078,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark54(-1.6155871338926322E-27,-1.2289468818778255E-13,1.0006042887160156 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark54(16.217707358396765,-0.6855903790507624,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark54(1.6263612998408519,-1.5707963267924123,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark54(1.6300091868275135,-0.5084335101571861,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark54(1.6305616791881965,-1.5707963267929372,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark54(16.34615446171526,-0.8102707232826658,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark54(16.352564220453317,-1.522393629453888,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark54(-16.379330923254905,-0.8781790785643068,0.26395559218506504 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark54(16.4082839035258,-0.6991652262058068,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark54(16.416254551734312,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark54(16.418473017943143,-0.7147716719089052,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark54(16.420104025858123,-1.5328264402848708,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark54(16.5027962966243,-0.8886154135063098,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark54(16.527036910614783,-0.729577514369462,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark54(-1.6565520610445076E-25,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark54(16.578449989859035,-0.7330232703762221,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark54(16.696878741210597,-0.8971984844895502,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark54(16.762314287539425,-0.6144643703714429,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark54(16.850715485221777,-0.8258628576032907,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark54(16.924073157857805,-1.0666724917302233,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark54(16.979918221609715,-1.570796326794028,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark54(17.028300425145375,-0.7769822490359353,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark54(17.03429028820967,-0.6347536607873314,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark54(17.05224531665533,-0.7212500602696679,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark54(17.09232772858613,-1.570796326794647,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark54(17.108775576036578,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark54(17.11762613454448,-1.5127159186744175,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark54(17.27061318928741,-0.90523276050926,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark54(17.271062937569734,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark54(17.400139713041895,-0.8906374773937791,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark54(174.18700635128152,-0.635442130751815,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark54(17.419672446772676,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark54(17.657147818026125,-1.5219790789865613,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark54(17.67801499693685,-0.8351742682786416,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark54(1.7763568394002505E-15,-0.769574616283144,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark54(1.7763568394002505E-15,-0.9665190636211918,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark54(1.7763568394002505E-15,-1.5146558264108165,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark54(1.7763568394002505E-15,-1.5707963267944614,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark54(-1.7763568394002505E-15,-1.5707963267946516,-1.0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark54(17.82835038295292,-0.8402509664025768,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark54(17.91015910800438,-0.6425282321590359,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark54(17.952682747771473,-1.570796326794896,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark54(17.992940975095024,-0.9479083718000743,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark54(18.039536918342407,-1.0335861190988604,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark54(18.04261146019259,-1.5547870880925017,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark54(18.067077388520943,-0.8967803360362012,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark54(18.124536994332736,-0.7344911072251712,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark54(18.150035951168533,-0.9807980889353285,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark54(18.228152468542945,-0.7743163206097989,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark54(18.229671922152363,-0.7480105940575458,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark54(18.243842252576947,-0.7914835086436594,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark54(1.8264360092513385,-0.6099782903768469,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark54(18.294521901201733,-0.8722912949934454,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark54(1.8312884511050527,-1.5707963267947065,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark54(-18.352248187529412,-0.8916158922051128,-76.52144093846856 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark54(18.438197783503327,-0.8406800393554681,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark54(18.476137784378025,-1.5359726670874285,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark54(18.479154619067245,-0.7129983918810192,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark54(18.554095712874357,-0.6367100383821901,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark54(-18.604725274248203,-1.5707963267948963,-1.0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark54(-18.608676548348903,-1.5707963267948963,-0.38351856457459554 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark54(18.698515381611074,-1.0006524343121943,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark54(18.715494558158746,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark54(18.75730325475177,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark54(18.762020361487554,-1.0551641999100307,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark54(18.80741275704196,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark54(18.821206358219147,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark54(-19.067229955270548,25.331368300274804,88.30945383801361 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark54(-19.136261835254825,-1.5707963267948961,0.18233282664033457 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark54(19.225502344895798,-0.8926802509059613,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark54(-19.238850020706334,-1.5707963267947385,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark54(-19.24156767646484,-0.9918386497380975,-1.0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark54(19.248249676491312,-1.5180350548695807,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark54(19.279572473042677,-0.7273163051282587,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark54(19.325497527481033,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark54(19.372256968286518,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark54(1.9394559751466858,-0.832138255832811,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark54(19.430717330011674,-1.566172684374998,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark54(19.441593288701547,-1.5529412974312782,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark54(19.482957087745746,-0.7941564498887104,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark54(19.491631787987302,-0.9103779060097468,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark54(19.53244730145589,-1.5707963267942517,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark54(-19.569355410631193,-1.5310521189931248,-1.1006568214637918E-134 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark54(1.9605959508535165,-1.5707963267946663,0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark54(19.630970702980505,-0.8997714220249264,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark54(19.665435467742668,-0.833667101088376,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark54(19.672102781553622,-1.5662422567965952,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark54(19.737936969632607,-0.7893882096476688,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark54(1.9800392773368394E-15,-1.0606540455789255,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark54(19.879077617892804,-1.5263963737932476,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark54(19.892177020787738,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark54(1.992709365287952E-5,-1.519184205707298,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark54(19.960916960549575,-1.570796326794702,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark54(19.976736572672394,-1.5333128249428056,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark54(19.977489553638964,-0.08755478581392326,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark54(19.989851703275797,-0.6154510513146221,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark54(20.0045210424107,-0.8737913796240662,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark54(20.0061561416164,-0.6378243080900603,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark54(2.0060995293006267,-1.5707963237605493,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark54(20.074015236039273,-1.052004199117551,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark54(20.122220013655465,-0.6828452099242519,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark54(-2.0237E-320,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark54(20.305124364660614,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark54(20.324327514275936,-1.0347627425615584,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark54(2.0345988194288225,-1.5707963267945768,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark54(20.350762739165106,-1.546352735518925,0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark54(20.355500014139437,-1.5707963267942269,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark54(-20.363199247516395,-0.6350588111156573,1.0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark54(20.42799061352349,-0.7197529939284522,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark54(20.502312983406405,-1.5123580801950856,0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark54(2.0522684006491881E-289,-1.5707963267918252,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark54(20.576104438620575,-0.6625538926671197,0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark54(-20.63312231691934,-0.9087219040489369,-86.4742330845271 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark54(20.74296826641057,-0.5811584486825865,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark54(20.759789455829146,-0.8128948901034856,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark54(2.0872546764770383E-14,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark54(20.922329116721226,-0.8202599080654567,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark54(2.098727985657787E-12,-1.5707963267942606,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark54(21.023035502662623,-0.8280811643156909,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark54(21.05565470314798,-0.7346157000451361,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark54(-21.065692786669004,-64.22574068702343,86.59859901490441 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark54(21.06578279771449,-0.8267403865465468,0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark54(21.070865399593487,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark54(21.106258687198967,-0.7920710203035313,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark54(21.145687891094425,-1.541281418976915,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark54(2.1209764022748865,-0.636366194187147,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark54(21.224896803817003,-1.5707963267395826,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark54(2.1282980620285734,-0.7450938531402471,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark54(-21.335457766091892,-1.0694221894851683,-87.7831057330115 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark54(21.335807418222668,-1.5707963267943654,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark54(21.37613234753111,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark54(21.38603336076956,-1.0541021397708814,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark54(2.138619061493244,-0.6843605718276198,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark54(21.403360197937584,-1.0510903286436413,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark54(-21.40502235349999,-1.0449656364778974,-1.0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark54(21.427523983323375,-1.5707963267929341,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark54(21.490562219188952,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark54(21.60728574118906,-1.5707963267942802,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark54(21.608272758809647,-1.0336706754595402,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark54(2.1628174988554936E-6,-0.8516519796702084,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark54(21.666873301084287,-0.0881660533070644,0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark54(2.170686772063334,-0.7510300626284104,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark54(21.71062813801838,-1.0037046374120524,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark54(21.748753289322593,-0.748761113757368,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark54(2.1791264894371167,-1.0280825550780248,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark54(21.848712540371764,-0.649128318327443,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark54(21.899080279506396,-2.4588264024310378E-8,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark54(21.977684545973915,-0.09937493568704006,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark54(22.070813329481155,-0.723662261807124,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark54(22.10229037713492,-1.570796326793058,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark54(22.11132603146993,-0.9268588812163134,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark54(2.220446049250313E-16,-0.12187833268385584,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark54(2.220446049250313E-16,-0.6872743114091066,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark54(22.209964320564172,-1.0060465037977888,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark54(22.23140771201774,-86.61256354047381,-84.26776208897577 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark54(22.2754020512769,-0.6984517533609527,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark54(22.28283641850048,-0.6280605857363639,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark54(2.228916617809668,-0.31006970918607285,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark54(22.34433334088743,-0.20049935293712384,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark54(-22.476792525830135,-1.528109245502777,-1.0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark54(2.250009710339924,-0.2310816630229108,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark54(-22.528629727496796,-1.5707963267946043,-0.009825866917982484 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark54(22.537873889345022,-1.0105775637923724,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark54(22.56512532772825,-1.0291088153387786,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark54(22.58070860654469,-1.5438721638523145,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark54(22.591504487705425,-0.9190820970611497,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark54(22.600337752436886,-0.7880518922949549,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark54(22.634674605950362,-0.9795605110103962,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark54(22.884124880197604,-1.5294907005909495,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark54(22.909513616641817,-0.8524078156804364,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark54(22.92153451589641,-0.6301014047260478,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark54(2.293405609286923,-0.9351351029584292,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark54(22.97543027090599,-1.5707963267945502,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark54(23.008935845907004,-0.6018354644363075,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark54(23.03600375557203,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark54(-23.198062656283568,-1.5404075935529677,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark54(23.23626768287926,-1.5240859332220165,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark54(23.285171684336408,-1.5378111858857488,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark54(23.365747491228944,-1.0577798468820427E-15,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark54(23.402781761248434,-1.57079632679191,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark54(23.434848095205993,-0.7306926852490113,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark54(-2.3468400873398156,-1.5184532446464032,0.9082090299164642 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark54(23.476019851765045,-0.5825967035651853,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark54(23.55673277260128,-1.027164857387422,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark54(23.607600313259653,-0.7084719830474189,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark54(2.36153804327463E-10,-1.566561798284761,0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark54(23.62635454139112,-1.0693979512002842,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark54(-23.72848613081304,-0.9672820974307521,-1.0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark54(2.3753619415376193,-1.000167683590372,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark54(23.78631360087884,-8.538335311077553E-11,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark54(23.81886647944347,-1.5139452259724369,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark54(2.3831736194055596E-11,-1.5134359398182036,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark54(23.880357991164395,-0.7464004043294921,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark54(23.962648634530353,-0.6595066517243571,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark54(23.984168302503537,-1.5707963267922758,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark54(23.993364707323433,-3.923717979869536E-11,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark54(24.045519888541797,-0.8236605909635526,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark54(24.11192122916955,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark54(-24.172309172819723,-1.570796326794163,7.04723509485072 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark54(24.175159817846723,-4.038884403457454E-9,0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark54(24.249081094654514,-0.8086605390582725,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark54(24.348958870221516,-1.5707963267944156,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark54(24.37897942657814,-0.7465868659895579,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark54(24.385972508337392,-1.57079632679444,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark54(24.3940316331378,-0.5736564813235565,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark54(24.40609779291171,-0.7320254989366628,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark54(24.40776830045661,-0.7713885187792986,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark54(24.481063481595598,-1.5312513129706002,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark54(24.503007551059227,-1.570796326794607,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark54(24.537983452042592,-1.5453920218016086,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark54(24.571035350469003,-0.6202700006205646,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark54(24.595685771311764,-0.6036252133195426,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark54(24.64187905570502,-0.8903329424487563,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark54(24.674481700099346,-0.06799856182198638,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark54(2.4719414984418933,-1.570796326794781,0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark54(2.4769663799962913,-1.5103229367784246,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark54(24.8022458253603,-1.555103878472071,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark54(24.86423757988929,-0.4113730935934012,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark54(24.906653878151417,-1.5707963267946852,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark54(24.919856940049883,-0.9793788496134594,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark54(24.92550657978579,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark54(24.991316773421005,-0.6199530080730771,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark54(25.01128735816549,-1.5332693143499458,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark54(25.01844094426464,-1.5707963267946603,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark54(-25.060367111257236,-0.9191581696583206,92.7789054767442 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark54(25.069524487927396,-0.06381830659374112,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark54(25.194371715969737,-0.6553346079995537,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark54(25.289028238102727,-0.10225066133806061,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark54(25.480605886550805,-0.6549546593302591,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark54(25.496959246903444,-0.9481577362022762,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark54(25.505547177175433,-1.5707963267945177,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark54(25.698139520060202,-0.8217047941276598,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark54(25.732145465728706,-0.6863332841740353,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark54(25.748754501403162,-1.5361528307674126,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark54(25.875127117214802,-0.15591409528826258,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark54(25.902943232686443,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark54(2.594103525265183,-0.9712815834518551,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark54(26.039011213581546,-1.0151895083112121,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark54(26.1633503775905,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark54(26.176399460272165,-1.51820915070697,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark54(26.26578361526298,-1.5519316031806074,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark54(-26.33173318698951,-1.846273256249618E-9,-5.293955920339377E-23 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark54(26.34945421559502,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark54(26.365096105470755,-0.9229763406720086,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark54(26.437497480245753,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark54(26.445780367291903,-0.7680414421437511,0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark54(26.454962384158094,-0.9537352779344663,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark54(26.55053030938204,-0.2127774305500555,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark54(26.558419808365095,-0.8293965163159136,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark54(26.570640027103792,-1.538936942190361,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark54(2.661401046003503,-0.7771028247928928,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark54(26.64927049357793,-1.5392076446329788,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark54(26.715325299922085,-1.5707963267945857,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark54(26.75089627934922,-1.0427398220350086,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark54(-26.802959459310383,-0.6114625960593748,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark54(26.85711863215063,-0.5852667831905052,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark54(26.88063291655852,-0.6409941982511188,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark54(26.913629722723,-0.698314349394277,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark54(26.937215165191294,-0.5863803194645065,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark54(26.96382317373465,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark54(27.052150741571346,-1.569999973955551,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark54(27.05796474383115,-0.1796955642923107,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark54(27.058716568472548,-1.0635158827416893,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark54(27.077804220651032,-0.8784611036453178,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark54(-27.117353220966223,-0.8990343554964255,-17.045940267464573 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark54(27.140360827791326,-0.6235370542015346,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark54(27.19475971737657,-1.5411761534046127,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark54(27.20900227242184,-0.801859917596697,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark54(27.220124470586853,-0.9909005083483322,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark54(27.25462036523373,-6.56537438082782E-10,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark54(27.256277464015724,-1.570796326794896,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark54(-27.287357378897468,-25.405840564254234,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark54(27.31964080732863,-0.6118460665838655,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark54(27.335686937539933,-0.5787478435552917,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark54(-27.38427137558289,-1.5707963267947764,1.0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark54(27.413257950853936,-0.6191686453889166,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark54(27.43462601550064,-1.5233991748363076,0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark54(27.476856001076122,-1.0537959670089805,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark54(2.753112313692275,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark54(27.535304917519127,-0.6953003877035762,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark54(27.53694627041361,-1.5268210661595445,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark54(27.55868823329675,-0.7442119797908617,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark54(2.7572395108013374,-0.9284243254012177,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark54(27.584394797737758,-0.5814651023344152,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark54(27.64077553778332,-0.7226339754776774,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark54(2.7664523314090327E-222,-0.6469809702640098,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark54(-27.720775776855916,-0.5718253383930403,-70.78885823971466 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark54(27.73614211876385,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark54(-2.7755575615628914E-17,-1.53903098550754,0.7214033616503522 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark54(27.765933349003703,-1.570796326794742,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark54(27.840194433592938,-0.7762116975329008,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark54(27.87585447246903,-0.956661641981583,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark54(27.880224310283026,-0.7896053578994504,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark54(2.7930724338178963,-0.5851245879161552,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark54(27.93649216964932,-0.8151929798460467,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark54(-27.965863286330453,-1.546137494783004,0.8353730501063263 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark54(27.979406831088326,-0.871401218958944,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark54(28.03478061020016,-0.8379481443274983,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark54(28.073190819953,-8.570063618243656E-11,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark54(28.092408164631706,-1.5707963267946106,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark54(28.128740255635314,-1.5350352330969912,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark54(-28.141235430902736,-1.5707963266694038,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark54(28.279364325672873,-1.5394160471487655,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark54(28.34779216797533,-0.7784281072466612,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark54(28.36436692996253,-1.570796326794703,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark54(28.49641276758982,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark54(28.56594493864148,-1.0203930654954423,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark54(-28.58936607698646,-1.5183800124717526,1.0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark54(28.61417866081778,-1.5707963267946807,0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark54(2.867120736591901E-7,-0.8406046191005422,0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark54(28.694717521159284,-1.5699639508994396,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark54(28.72892637850179,-1.0019656393138323,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark54(28.780660776402826,-1.53414896391281,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark54(28.855107515319304,-1.550935085086828,0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark54(28.879095928374568,-1.0026556992250084,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark54(29.00056642557425,-0.9692958130542131,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark54(29.01091103993691,-1.5707963267944507,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark54(29.02710458520579,-0.7947941443691968,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark54(29.052697011953,-1.5707963267945433,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark54(29.097607728156362,-0.5815962152141503,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark54(29.11637265097366,-1.5707963267917733,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark54(29.168726538920417,-1.0579250234733004,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark54(29.179442267669657,-0.8547890474559203,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark54(29.19116408343932,-1.5509728610863982,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark54(2.921920639780822,-0.9193024125669943,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark54(29.249898328847678,-1.5134429091023351,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark54(29.379014843295323,-1.053227717593515,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark54(2.938282656230841,-1.0234525974472604,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark54(29.397044013571787,-0.808961553880422,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark54(29.456997374647784,-1.535230140737343,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark54(2.949906520346474,-0.9289545358878746,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark54(29.51109018423507,-0.8211895116384118,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark54(29.55024750191778,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark54(29.568228834543213,-1.5707963267918603,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark54(29.5831123180472,-0.590146117599615,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark54(29.58909457536681,-1.570796326647055,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark54(29.609757043542725,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark54(29.657252788216425,-1.5703199933288772,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark54(29.70843453914722,-0.7748149948098535,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark54(29.75136287944335,-1.5092104829786641,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark54(29.85943345663395,-0.6259305041597132,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark54(29.897417017371115,-1.539884910948187,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark54(29.932781481317722,-1.4685537651143749E-15,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark54(29.96477627252915,-0.8005350977013763,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark54(2.9999708980875397,-0.8523388186288328,0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark54(30.163683942912428,-1.5333619419197422,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark54(30.16702192617859,-1.5654476881171069,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark54(-30.18691974139405,-45.31058352924053,97.82087898189354 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark54(30.200694395771606,-1.5707963267943954,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark54(-3.032129874470453,-0.675025052259401,0.9999999999999982 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark54(30.353107679520008,-0.636243722119084,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark54(30.359392607278064,-1.5707963267942533,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark54(30.38398833571938,-0.8660418954871574,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark54(30.44319555427708,-1.5304231230704903,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark54(30.54795980189644,-1.5318528656471546,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark54(30.62993528901356,-0.6135459811855402,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark54(30.648788664969683,-0.5883921614214103,0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark54(30.658023979093286,-0.7497695857756639,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark54(30.67231484033963,-0.6870705046818301,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark54(30.822649498220798,-0.7246630438264894,0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark54(30.845154030071754,-1.0244348941777972,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark54(3.0882414073799964,-0.1517865913419082,0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark54(30.914392510166635,-1.542135866855563,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark54(30.94186538255864,-0.7754806705256883,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark54(30.945971374597228,-0.6659847912432353,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark54(30.960817964226713,-0.595588216764708,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark54(30.96739410131829,-1.5108048425365799,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark54(31.027796395493255,-0.8510476551807147,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark54(31.095793976574612,-1.5197529814982573,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark54(31.259985544540285,-0.47022118674520164,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark54(31.281347514700258,-1.03162319760024,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark54(31.342446238324236,-1.5533448454817123,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark54(31.440506168039548,-1.5707963267947775,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark54(31.459355977380497,-1.0250169483213298,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark54(3.1467187215028076,-0.846549214629988,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark54(31.52194601489225,-92.57799798084656,81.04712724375608 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark54(31.60979324097243,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark54(31.758957556709028,-0.8741988491646597,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark54(3.18046841404977,-0.8505005355294415,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark54(31.832809745238144,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark54(-32.00901880084656,22.75363280142406,69.56706362639244 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark54(32.010318058929734,-1.0316864470384957,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark54(32.069279148174445,-0.6422778366000967,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark54(32.07847836335753,-1.060344336608774,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark54(32.09822133928868,-0.7792779725962156,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark54(32.1019541207684,-1.5707963267944791,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark54(32.12535391571979,-0.9020863677259725,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark54(3.214096870568369,-1.0686280660775813,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark54(3.222835230202435,-1.5707963267946745,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark54(32.28400915081474,-0.772914331425467,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark54(32.30171616327354,-0.6734773601572837,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark54(32.31101974420184,-1.570796326794896,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark54(32.31243779916997,-1.570796326794735,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark54(32.33562177675028,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark54(32.35739563736476,-1.5438651568058712,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark54(3.250810710208593,-0.7558749686471539,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark54(3.2631880870058296,-1.565829268020729,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark54(-32.659756685831454,-0.8775568678351142,-1.0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark54(3.2687366411563517,-0.7605468111703448,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark54(32.702804118548585,-0.717660517887527,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark54(32.711346665381924,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark54(32.73975050115754,-4.518222364433886E-8,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark54(32.74576073122611,-0.5977180554235619,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark54(32.75445926345334,-0.6446332818601075,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark54(32.75961033544159,-0.8129763537241588,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark54(32.78733344765084,-0.628857138521539,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark54(32.795459235011435,-1.5707963267916085,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark54(32.82329202336485,-1.0004150221244572,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark54(32.870823850430675,-0.8036560162199298,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark54(32.88963620131697,-1.5519241815676008,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark54(32.89580281597193,-0.7284409421434197,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark54(32.91956586312899,-0.7799762491079765,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark54(-3.2950400579839615E-12,-0.9189363454138841,-1.0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark54(32.956193633163956,-1.0634195079815014,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark54(32.97326323511195,-1.570796326794774,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark54(33.01482238528341,-0.8210882504185419,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark54(33.073253359036975,-0.34968644549602396,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark54(-33.087233334361514,-57.816125676437366,49.58127481506375 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark54(33.24458184985707,-0.7822139131266233,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark54(33.260291205235944,-0.8388986482655127,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark54(33.28082672533074,-0.7093597078455995,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark54(33.32712009592018,-1.5707963267945941,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark54(33.46645647160619,-1.5261333591812651,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark54(33.46810505628668,-0.8634897399935837,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark54(33.479467733513104,-0.7421466694692977,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark54(33.50484862512374,-0.9867030454708008,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark54(33.52292249793689,-1.5646223429684463,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark54(33.64827605145538,-0.839771340464246,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark54(3.3676095532328145,-1.0520837800589988,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark54(33.71845417370244,-0.5898155280664872,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark54(33.75476331170262,-1.0335185632038435,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark54(33.820283413644546,-1.0204659262689404,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark54(-33.89869238335891,-1.5536673688143339,0.5474776127615586 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark54(34.004737467906345,-0.7453910772856526,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark54(34.13723958203985,-1.0265745830572548,0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark54(34.16854068448512,-1.5707963267477147,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark54(34.20436186614472,-1.5375551133502017,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark54(3.4228770520079705,-0.9406060841488286,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark54(34.23211582973373,-1.5707963267552008,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark54(34.263614758340225,-0.9259745856219306,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark54(34.272764110815125,-0.7299553827521763,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark54(-34.2808072307826,-1.5226111657395482,-0.9999999999999964 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark54(34.356286553147676,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark54(34.41801891782168,-0.8661050256231749,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark54(34.42158713787722,-1.570796326655545,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark54(34.44789952154389,-0.9650088052683019,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark54(34.47318838722154,-1.5352887920044678,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark54(-34.53103010402589,-0.6605490686420268,-1.0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark54(34.55195818796212,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark54(3.4576007990346787,-0.9273397875560203,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark54(34.60332044957832,-1.5491070895021757,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark54(34.75931288222952,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark54(34.897078659604205,-1.5198371372163346,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark54(34.978691840057905,-0.942359993265697,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark54(-35.01745915569994,-0.7119662503227691,0.22389716782020808 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark54(35.09675695733837,-0.9326666777421995,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark54(35.15259089598133,-0.8545262925036129,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark54(35.220589496369,-1.5707963267945502,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark54(35.257974377907374,-0.5857448193312802,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark54(35.30787923882772,-0.8428903765325417,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark54(35.346374478088265,-1.5661070401788213,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark54(-3.5363258743705545E-35,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark54(3.5447959536183236,-1.0707027350929037,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark54(3.547627759128651,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark54(35.4986909051129,-1.5707963267947638,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark54(3.552713678800501E-15,-0.442902544931851,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark54(-3.552713678800501E-15,-1.5707963267947385,-48.415996144199866 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark54(35.6241919545248,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark54(35.64392281365747,-0.7896768170125436,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark54(35.68332817515616,-0.6520882204195733,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark54(35.73349446488493,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark54(3.573973105499215,-1.5278540777704195,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark54(35.74543995936152,-1.5394110740783258,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark54(35.789936102260896,-0.9700037705117679,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark54(35.91448226550607,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark54(35.91917878180391,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark54(35.968089476377656,-1.5707963267942946,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark54(35.97818159776917,-0.971936313486097,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark54(36.08741830072901,-1.5387327335257313,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark54(36.092658155427884,-0.88810456544627,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark54(36.2256360684287,-0.5032590991732045,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark54(36.32432120123653,-0.6178991838295823,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark54(36.38199276887687,-1.008230355403988,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark54(3.6400832094080315,-0.9483762118516053,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark54(3.6423804688259622,-0.9795003150698847,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark54(-36.4594865263012,-1.548082760852201,7.896825413969131E-177 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark54(36.48070801198878,-0.6117313777567484,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark54(36.49779136116213,-1.0469959940595022,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark54(36.5072895145887,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark54(36.52730591722778,-1.526289144327034,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark54(36.59488654539905,-0.7756791961706213,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark54(3.663830254201161,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark54(36.672653222788966,-2.8922948291214626E-4,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark54(36.68867640832891,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark54(36.694779080658506,-5.985486261298206E-11,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark54(36.71510521760596,-0.8032379267086078,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark54(36.71831260229453,-0.26222269957485683,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark54(-36.72276504380164,-1.0227329684215583,-1.0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark54(36.942467932763975,-1.5319026974601475,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark54(36.95925747599484,-0.77936245758769,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark54(37.03379576227783,-0.7749397735412344,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark54(37.10652390658138,-1.570796326794896,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark54(37.10989608352614,-0.6175760433265935,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark54(37.12058819500115,-1.5707963267913385,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark54(37.26925915892156,-0.7837694292723398,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark54(37.27107569166296,54.745755294937624,-34.96197776275771 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark54(37.322843626170936,-1.525558233455842,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark54(37.37316453444254,-0.8729075100689231,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark54(37.46783392688407,-0.8173289438947493,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark54(37.475533411050094,-0.613451766382326,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark54(37.4889759753394,-0.77899280862907,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark54(37.494912935905006,-1.547995437206623,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark54(37.65296002295878,-0.74571516038508,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark54(37.70480765586913,-0.7018114673958413,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark54(3.772485712796538,-1.0568399324985238,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark54(37.75090503164549,-0.5967707954371502,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark54(37.764682793515725,-0.8220618357743232,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark54(-37.77628501949619,-1.021307936397027,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark54(3.778482011390077,-1.535989395289355,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark54(37.873200914185446,-1.5707963267947385,0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark54(37.91161198429484,-0.9547171936910065,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark54(37.99126192658508,-1.5099430259920983,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark54(-3.803047801211193,-0.8371298827059358,0.007389766389031168 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark54(-38.055942085225546,-1.5707963230487323,0.9716842409613065 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark54(38.08651410106219,-0.8305506996154151,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark54(38.095394626697214,-0.08957134945003109,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark54(38.139747464935226,-0.6775534523115994,0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark54(38.14515626211474,-0.7510495384328806,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark54(-38.15162241334271,-1.5707963267948961,-34.690845620353464 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark54(3.816556340848721,-0.9617307538497735,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark54(38.20049942893026,-0.8197581588534462,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark54(3.8265120204659837,-0.7654775070758717,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark54(38.356077410453736,-1.5144674954682007,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark54(38.3802604071397,-0.7368190848582908,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark54(38.4242743187649,-0.6282821599189323,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark54(38.45919831776084,-0.9805389892741516,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark54(38.47688877929855,-0.6284740178449173,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark54(-38.51129768891299,-0.10710066873091278,1.0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark54(38.555889085330136,-0.9591271004564792,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark54(38.63645746469484,-0.9020603437182325,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark54(38.64653153748081,-1.5642248676397925,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark54(38.71210906375714,-1.5707963267946639,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark54(38.7742508543777,-1.5452070963775693,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark54(3.878069643135567,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark54(3.878334788992973,-0.6177541654694079,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark54(38.784268725742294,-0.4462216576173691,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark54(38.80275199933919,-0.8511290330936832,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark54(3.8818496395167017,-1.570796326794657,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark54(38.88440693428112,-1.5707963267941594,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark54(38.90000920712475,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark54(38.98148857848966,-1.5707963267944756,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark54(38.98688836101658,-0.8722337880027595,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark54(39.010568646753235,-0.5555594096297954,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark54(3.907915505079041,-0.666466564210296,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark54(39.08217194506986,-1.0363024227224464,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark54(39.106877841380594,-0.6048592575856873,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark54(39.147436506590424,-0.5800219746188873,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark54(39.158835935683236,-0.6123263325311747,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark54(3.9171161785003505,-0.8231439978104423,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark54(39.173986162589614,-0.9404940330162734,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark54(39.21085732756312,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark54(39.267793843723865,-0.9954355060355766,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark54(39.27449142020531,-0.6094026762479421,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark54(39.30468642427607,-0.6856229783311316,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark54(3.9438981406279714,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark54(39.46711920650188,-1.545590101390971,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark54(3.950849904960225,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark54(39.52265986803735,-0.8506102451577684,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark54(-39.616266484220475,-1.5426408638278106,100.0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark54(39.62383507996884,-1.062842859003991,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark54(39.62923034596275,-0.995436758901604,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark54(3.972377859169356,-1.5707963267915093,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark54(39.7268593828922,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark54(39.777496520094275,-0.7256915861558291,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark54(3.9919371870295635,-1.5650698563865564,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark54(40.07974235433258,-1.5707963267947092,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark54(40.23626855347514,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark54(4.023927281684627,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark54(40.2752660896048,-1.0511017329017651,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark54(40.29255806884663,-1.5208638360760447,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark54(40.2981094876437,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark54(4.034726328381724,-1.570796326794896,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark54(40.42179396772897,-75.87484051341451,64.45307144742671 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark54(40.45644971412062,-1.063691545638617,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark54(40.471328202374316,-0.9171362044456077,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark54(40.49566842653584,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark54(40.530702667669956,-1.0325662023154347,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark54(40.54558847117665,-1.5415516334174884,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark54(40.56397594428395,-1.5707963267569802,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark54(40.64433756469987,-1.5707963267947527,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark54(40.64910256042555,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark54(40.69890271699086,-0.5965129392096715,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark54(40.717051114014225,-1.5460473632172,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark54(40.72257879367443,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark54(40.72762771155368,-1.5707963267940244,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark54(40.81380937909068,-0.8824393483907129,0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark54(40.82503326475873,-0.644586752732683,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark54(40.842157839863205,-1.0592281348281283,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark54(40.84854711493338,-0.7324004708205494,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark54(40.85497662098714,-1.5707963267945573,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark54(40.87096441175518,-1.0212226389683803,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark54(4.088197857006222,-0.586073423352957,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark54(40.89445362743811,-1.0640061685693212,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark54(4.092666886493387,-1.570796326794896,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark54(40.967442222158354,-0.5842528462329142,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark54(40.9754494270505,-1.5175916258220445,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark54(41.00249874433905,-0.8277328807331243,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark54(41.0913018854709,-0.6309806747535447,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark54(-4.110840436109863,-1.0702512294052733,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark54(-41.14213425493216,-1.5707963267947702,0.4713282148523854 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark54(41.179037395532646,-1.5707963267940386,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark54(41.25535146249726,-0.97829069974641,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark54(41.27738873823458,-0.7205347356518441,0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark54(4.130007595371481,-0.9353153955899756,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark54(41.34827680397456,-0.6378959107527091,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark54(41.39234180226978,-0.8658610262027003,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark54(41.408342246150426,-0.46528305433421846,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark54(41.42305541697391,-0.6014143203053309,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark54(41.46540964325931,-1.0686062553840117,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark54(4.146998640117346,-0.887782938158125,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark54(4.163079449578864,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark54(41.73267640260525,-0.16613758854547114,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark54(41.741647724267864,-0.8030927426871151,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark54(41.78047930225398,-0.8467756309408081,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark54(4.1791714254636645,-0.6580676972473503,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark54(41.857427189607975,-1.5707963267947385,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark54(41.916684374251986,-1.5707963267946532,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark54(41.92108610781129,-1.0243205935169053,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark54(41.97292159460876,-1.003153031541566,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark54(41.987443345273704,-0.2153184075884108,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark54(41.987564567092846,-0.9316758236002447,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark54(42.02623977671481,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark54(42.05160290808573,-0.8713590409359018,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark54(42.05627705758323,-0.6719927554291747,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark54(42.18900115939446,-0.7118780851147886,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark54(42.22269204817982,-1.5707963267947826,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark54(42.22980972567285,-0.33113827035455967,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark54(42.238954558372825,-0.9969216228253011,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark54(4.226642943285924,-0.7044201521289246,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark54(42.40841280149931,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark54(42.41831325934692,-0.8743977973309327,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark54(42.507466828214625,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark54(42.52481501165076,-0.5650789816105622,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark54(42.55914207218093,-0.6018532028747394,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark54(42.638062642505446,-1.5499979552472976,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark54(42.664205905837946,-0.8524368787797982,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark54(42.6678970725049,-1.570796326794512,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark54(42.692594494344746,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark54(42.70981219639417,-0.5289765480007423,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark54(42.72020542033821,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark54(42.723364314642595,-1.5707963267946674,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark54(-4.272590781336718,-0.7455274986411444,-1.0277352281691476 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark54(42.778270443278075,-0.9325949589969749,0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark54(4.288254747773408,-0.7951672495548792,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark54(42.9430879401051,-0.7609410508037158,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark54(42.950352784534076,-1.0232684582047522,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark54(43.03583155357816,-0.5712386090038102,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark54(43.10427799748609,-0.8478396685366087,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark54(43.152933397754786,-0.6004822486563197,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark54(43.25072372621676,-1.5256292552948256,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark54(-43.31314103282805,-0.3139387436430535,1.0000000000000002 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark54(43.372595016644766,-1.5707963267947491,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark54(-4.343131587733808,-1.5707963267944223,15.104632465467128 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark54(4.3537022452512275,-1.5434347007845235,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark54(-43.554664376853665,-1.5131073781232405,0.0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark54(43.683695086039705,-1.5707963267943796,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark54(4.368484293746523,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark54(43.813318183370484,-0.916961616570398,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark54(43.83601421745243,-0.6450837078839329,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark54(43.85405686658005,-0.7189477934527417,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark54(43.99255696804511,-0.8000780914435524,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark54(44.05834066959699,-0.5325651073063468,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark54(44.064806550992564,-1.0547533372115194,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark54(44.1560908183771,-1.5707963267947667,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark54(44.17209816226739,-0.39923195373297415,0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark54(44.183450869417705,-1.0218730638437121,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark54(44.2176620826406,-0.8795259561220201,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark54(44.25085078114297,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark54(4.426501141868897,-1.0467489218920454,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark54(-44.35520068643696,-1.0000538229338367,1.0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark54(44.39688760871063,-0.7226138718010873,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark54(44.469872518554396,-1.552108489177064,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark54(-44.543889386266926,-4.2163290799734856E-11,31.369925600063677 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark54(44.610976610009345,-0.853988628415741,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark54(44.618503884105465,-0.1508383013469904,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark54(44.64103347487756,-1.565631150098778,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark54(44.64616431501548,-1.5707963267943228,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark54(44.650514588915996,-0.6692644438812039,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark54(44.65564569034558,-1.0520474364024632,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark54(44.67906938876399,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark54(44.68358408065792,-1.570796326794896,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark54(44.76046454515959,-1.5495201775079266,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark54(44.87222426676519,-0.7437990102172023,0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark54(44.966363353550975,-1.5707963267947234,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark54(4.504499549159419,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark54(45.06119997319014,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark54(4.509097840963786,-1.047573758937573,0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark54(45.098264836448564,-0.7585596821430018,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark54(45.18231793228253,-0.7931906555109265,0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark54(45.19258515510366,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark54(45.256585252656656,-0.7871144950119022,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark54(-4.538024930358928,-0.6707614622285946,-0.37650732330009795 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark54(45.49112319540001,-0.7566834516761411,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark54(45.539106703891775,-1.0045721677262698,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark54(45.543200968753894,-0.9303578975554383,0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark54(45.58936363894339,-4.5677535802876357E-4,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark54(45.64847897499598,-1.553915244708866,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark54(45.70661614472005,-0.2191570655961853,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark54(45.70815784427623,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark54(45.71590884622144,-1.5353672533653224,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark54(45.75099297841359,-1.5472817520801787,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark54(45.77007896186265,-0.8361383491861814,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark54(45.77321247164449,-3.516546673201725E-16,0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark54(45.80591404838333,-1.5707963207228597,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark54(45.813377893823336,-0.7920331135854325,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark54(4.585775075378578,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark54(45.88566781592015,-0.5138886464135587,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark54(45.9488564775328,-0.007089055503259334,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark54(45.996850094525556,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark54(46.10937396075608,-0.6816577634010219,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark54(46.12835230329247,-0.0915252188791077,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark54(4.6143749661818845,-0.685967381572011,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark54(46.25802782918399,-0.851534636374947,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark54(4.629702450245658,-0.6055517912543755,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark54(46.32986642635617,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark54(46.34490663962812,-0.8953399921938932,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark54(46.35893048315856,-1.570796326794683,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark54(4.643727424176116E-10,-0.7837512971703264,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark54(46.54508262491801,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark54(46.57215184917746,-0.9539043768740791,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark54(46.57628886079394,-0.6416935435387509,0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark54(46.61291267835154,-1.5707963267947196,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark54(46.667825912340895,-0.9463628895899636,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark54(46.67221134783472,-0.632959552177482,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark54(46.69853701805141,-1.5664344612299355,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark54(46.7898801947249,-1.563799237347489,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark54(46.83069081329241,-0.5798122620841122,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark54(46.992165470851845,-1.5707963267946172,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark54(46.99844842437088,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark54(47.03858351311263,-1.0007782823266829,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark54(4.70649407128478,-0.7885009318715674,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark54(47.07729640270564,-0.007328489223371704,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark54(47.10840179315599,-1.069969735910665,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark54(47.122798330707866,-0.9567274702017166,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark54(47.142323332405965,-1.5707963267947243,0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark54(47.18255505657987,-0.8380467003869558,0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark54(4.731451043905123,-1.570796326794099,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark54(47.37866302392847,-0.5943389458595298,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark54(47.38408677031728,-0.8929452237962461,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark54(47.44522555080485,-0.8484315062830934,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark54(47.4519683145534,-0.7366048775892251,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark54(47.49460061441318,-1.5135941246814109,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark54(47.532843138798356,-0.5966809881075759,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark54(47.552200857897134,-0.9750175546656693,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark54(47.619532644106506,-0.9255791210839122,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark54(47.62821761832924,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark54(47.72260743350966,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark54(-47.76786058509535,-0.9110808630076601,1.0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark54(47.79898560527906,-0.31564457841642823,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark54(47.83454881370637,-0.7449366902994852,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark54(47.88131652772917,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark54(47.938948517976854,-0.5376631660704899,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark54(48.140263975857565,-0.6558429627711162,0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark54(48.14424275816188,-1.5707963267927738,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark54(48.22516245266869,-0.8858063330496506,0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark54(48.24883831676677,-1.57024168143554,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark54(48.25163695595282,-1.55429591990708,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark54(4.8282520339868285,-0.7069769985254981,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark54(48.28708420122473,-0.7734120732731498,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark54(48.33713429090427,-0.5953630151653944,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark54(48.39465013717572,-1.5707963267946816,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark54(4.846129263529965,-1.5261900664002197,0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark54(48.50821932022074,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark54(48.73066966788821,-0.8680828555041251,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark54(48.73615521835066,-0.6334915422809766,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark54(48.789308000300736,-0.583306100253008,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark54(48.91815930553321,-0.976848905094786,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark54(48.951534737789615,-0.8142143651741423,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark54(48.9675660752456,-1.5413173277822168,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark54(48.97166457600882,-1.0066888208589413,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark54(49.06083245962927,-1.5703404328458643,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark54(49.085285609544115,-0.7099003879994634,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark54(4.9115450190304415,-1.5301619686866719,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark54(49.16260138915476,-1.5280548928429423,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark54(49.28742718813075,-0.8707297179768463,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark54(49.306978481783034,-0.8092536495564924,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark54(49.38392429911062,-0.9796856970640846,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark54(49.387326528858864,-1.5130572238300424,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark54(49.40737978306683,-0.9014254785281759,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark54(49.47651882746436,-1.051421746406061,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark54(49.48488097050614,-0.8369389315378118,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark54(49.515533436431696,-1.052460485991229,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark54(49.57706856886429,-1.5707963267945217,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark54(49.583628892318984,98.70063410857486,-85.75917733132694 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark54(49.596735491830415,-0.9192822127230098,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark54(49.60353316488941,-1.0520736241953976,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark54(49.695418762857,-0.058536395149769174,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark54(49.70653833234937,-0.8828925031170529,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark54(49.746054582252974,-1.5955707093204144E-8,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark54(49.755171978104556,-0.7477799329843133,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark54(49.81890094620266,-0.9913520728583435,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark54(49.91581674567939,-0.6802998412473712,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark54(49.92175088257858,-0.1522181235702157,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark54(4.992984870183207,-1.5367070902687112,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark54(50.030411456309494,-1.5134535261605468,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark54(50.038453690664284,-1.5707963267945102,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark54(50.117103631552254,-0.7771247093748599,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark54(50.192202621674454,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark54(50.23293569683435,-1.5707963267946854,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark54(5.024325358750659,-0.7792563136673927,0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark54(5.02759857047596,-1.570796326794579,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark54(50.2760815053872,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark54(50.29138163146385,-1.5707963267945289,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark54(50.35498669532238,-1.5707963267944152,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark54(5.046264216626639,-0.8224373686829551,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark54(50.46976074539637,-1.5116652052548765,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark54(5.05274577593671,-0.7236919739789847,0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark54(50.56423083633811,-0.6280046335830018,0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark54(50.64618289155115,-0.7344429250326368,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark54(50.650646247996264,-0.8310707437870131,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark54(50.656633765853286,-0.3267738912965636,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark54(50.74593490345255,-1.0660379020807893,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark54(50.93110746727061,-0.9343842685422481,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark54(50.93246061504111,-1.5507654691391966,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark54(50.96293458742815,-1.5707963267944116,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark54(50.984830524080536,-0.6941368831436732,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark54(50.99694250493522,-0.7755994631595406,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark54(51.10915935179747,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark54(51.19118340733516,-0.9047350678825179,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark54(51.20931405214611,-0.7126508089463792,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark54(-5.123346398032474E-21,-1.5488427101106839,2.1175823681357508E-22 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark54(51.24978638712818,-0.737507387658269,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark54(51.25892567360347,-1.5707963267946035,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark54(51.27955533700032,-0.678256638559362,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark54(51.28302298789393,-1.5404764699476718,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark54(5.1306710016229703E-290,-0.9212103838848669,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark54(51.34183188097526,-1.5707963237484752,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark54(51.360075550616244,-1.5707963267925351,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark54(51.36724331690709,-0.008648053357515617,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark54(51.46140087535351,-0.657967061544388,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark54(51.46601848701302,-0.6627399383643213,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark54(51.524446912268274,-0.9828428418279702,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark54(51.60137489495668,-0.9537529186257192,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark54(51.658900484941256,-0.17929320137484972,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark54(5.16644349415948,-1.5707963267918024,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark54(51.71673765617524,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark54(51.731011251748015,-1.001864336160688,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark54(51.76904184310508,-0.37704291714216515,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark54(51.79647840639359,-0.7987409668996435,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark54(51.804764231830376,-0.9694188071233212,0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark54(51.87959382591205,-1.0299927072529471,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark54(51.897147642461114,-0.9139451893969124,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark54(52.064310699308976,-0.6974941870796018,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark54(5.207922301032984,-1.5707963267947371,0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark54(52.09790815757634,-0.8787644810701924,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark54(5.215454748479715,-1.065543916789212,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark54(-52.19899825057407,-1.570796326794106,-0.6749179250221995 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark54(5.240863190024598,-0.6243098643024481,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark54(52.438377519154386,-0.21463412369240953,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark54(52.527650361145945,-1.570796326791445,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark54(52.55382665364007,-1.5525204871737663,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark54(5.256292028101257,-1.5707963267945715,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark54(52.563499043785555,-1.5707963267947704,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark54(5.256962615849327,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark54(52.57989630882657,-1.530625980998931,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark54(5.261822680263744,-0.6018693874236858,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark54(52.759696852177775,-1.570796326794772,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark54(52.78855541233358,-1.5433878056495498,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark54(-52.79496782511555,-0.7583873653363788,0.0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark54(52.797104529478325,-1.5097010589349136,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark54(-52.844349238637406,-0.9311003891143671,0.0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark54(52.85038929663087,-0.8286947852086399,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark54(52.85860164654497,-1.5512743909345008,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark54(52.90100076351831,-0.9438043952572368,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark54(53.00749359457225,-0.8029050118101821,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark54(53.05608202184973,-1.5225343327656176,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark54(5.310187713994523,-0.9050152795100053,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark54(5.3158019497854525,-1.538812336684902,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark54(53.191487934886915,-0.8728905623013634,0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark54(53.26151808822632,-0.22450942330513776,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark54(53.29552836065246,-0.9942861763731035,0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark54(53.3298356450571,-1.5707963267944676,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark54(53.35158765987293,-1.0599350302007977,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark54(53.454329988827524,-0.3181670300243139,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark54(53.46383962112051,-0.9017293787503071,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark54(53.47137643689314,-1.0097689352651702,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark54(5.349473041656675,-0.9924783369310852,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark54(53.55270669436915,-1.0608485408856394,0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark54(5.357997465564665,-1.57079632679476,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark54(53.599736222183544,-1.5707963267947498,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark54(53.611209084066246,-0.5438280888339527,0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark54(53.63154586250203,-1.0511226801137343,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark54(5.363589291373572,-1.0687220020256007,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark54(53.6789122868465,-1.5707963267947258,0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark54(53.69355678587584,-0.7617455020607393,0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark54(-53.78813339381958,-1.5707963267942064,0.684343985103975 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark54(53.80060464291367,-1.5528356904209746,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark54(53.876509197082015,-0.68522209557789,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark54(53.878095918475196,-1.5285636953378514,0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark54(53.92150487500615,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark54(53.93416703019733,-1.520664627040053,0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark54(-53.94927481817421,-1.5707963267948963,-1.0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark54(53.961947292443654,-1.5707963267920775,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark54(54.027478293886446,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark54(54.109123778688314,-0.20632018243327024,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark54(54.11836479025786,-0.6328107638897507,0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark54(54.14261550474879,-0.8795578688564936,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark54(54.16514007884355,-0.30242363451881016,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark54(54.20097512600614,-0.6804814291336214,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark54(54.25017024594425,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark54(-54.2685416261811,-0.9450056687326054,1.0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark54(5.43357599804542E-23,-1.570796326794659,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark54(5.440954538387217,-0.573868439736084,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark54(54.4157477685427,-1.5477890841619242,0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark54(54.421544630739504,-1.527020090724329,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark54(5.442398157379674,-1.5707963267946106,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark54(-5.4464467767013645,-1.5702983715514325,-32.383024836797894 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark54(54.56506490620745,-0.8055554334548418,0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark54(54.571148946073244,-0.6026084397474705,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark54(54.697039523103825,-0.9099802772136663,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark54(54.70075586814173,-0.20425977587114694,0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark54(54.73399330144774,-1.5240301015644153,0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark54(54.836279902963234,-0.7720138089389725,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark54(54.858475988207346,-1.041749794848764,0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark54(54.966797129869775,-1.0144686303069061,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark54(55.01924697410965,-1.018411145659897,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark54(55.105636441405125,-0.9602249762212022,0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark54(55.20794566853459,-1.5428405160356835,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark54(55.312063938119955,-0.8299485006176227,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark54(5.537353347488022,-1.5242563911766256,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark54(55.41199396585956,-0.6352778945342141,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark54(5.550293197323114,-1.063966470743253,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark54(5.551115123125783E-17,-0.9258798203089339,-0.7214181684786496 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark54(5.551115123125783E-17,-1.5451711308995382,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark54(55.523914863192964,-0.9368032391904615,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark54(55.55327308200236,-38.49201547850802,0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark54(-55.57278266418415,-0.7864942447183061,-84.08741258403406 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark54(55.57893250357671,-0.9018360891640071,0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark54(55.60139195636707,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark54(55.603763563296866,-0.49447435039266596,0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark54(-55.663736707382384,-1.537284520827603,13.726389489339926 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark54(55.721059799526046,-0.5044698900047008,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark54(55.73699764382957,-1.0532770781509608,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark54(55.74577250686872,-0.9138534830432197,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark54(5.5830422962364405,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark54(55.88553586635817,-0.9805050760687624,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark54(55.90426018299434,-0.6806864435141484,0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark54(-55.98867415374215,-0.6013407368097855,0.636410748308462 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark54(56.01353862044658,-1.0458549620824016,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark54(56.156777496843304,-4.2164623067364406E-11,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark54(5.615766012320279,-1.5494966502616414,0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark54(56.1853179752037,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark54(5.622670361961349,-1.570796326794164,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark54(56.249465759661476,-0.7880946569714884,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark54(56.27195607304011,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark54(5.629881231262997,-0.3525030028737971,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark54(56.318694443654934,-0.8985289426683551,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark54(-56.34451929389522,-1.545455157676671,1.0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark54(56.535902109510374,-0.9558252655468407,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark54(56.572044382272225,-0.8382198336771635,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark54(56.616351769494486,-1.5707963267559704,0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark54(56.66380744668095,-0.6629723915182653,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark54(56.668435499323465,-0.9515407601210706,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark54(56.67944366506799,-0.8872547220458102,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark54(56.760350833320885,-1.5707963267924696,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark54(56.761141494788774,-0.3719697886620587,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark54(56.83071135440815,-0.6266764938033731,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark54(56.883834279449246,-1.5707963267423963,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark54(56.99791600280892,-0.5779429061042212,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark54(57.00568160308096,-1.0425794237849622,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark54(57.01904424234684,-0.9540641186598959,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark54(57.03267019700476,-0.5730834633707037,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark54(57.096134794278825,-1.509273216991888,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark54(57.21697263117511,-0.2634461203130817,0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark54(57.26530452358043,-0.9498152343256059,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark54(5.728346323849536,-0.8495154913829879,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark54(57.28896653459553,-4.284407709271473E-10,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark54(5.732770147451392,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark54(57.4124511078133,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark54(57.5085443467012,-1.5707963267929443,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark54(57.528017776573705,-1.570796326794735,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark54(5.760814669002826,-0.7020974079543343,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark54(5.762054816101482,-1.550139448084042,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark54(57.620830828583564,-1.5496678360439542,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark54(5.763932671437843,-1.009980492893464,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark54(57.66834774442806,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark54(57.70165451679989,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark54(57.73806985372243,-0.7512040151466834,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark54(57.76638893803877,-0.5024717982704044,0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark54(57.767688936599654,-0.8980942672739705,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark54(57.837294344468035,-0.7618694704569737,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark54(5.785113016228067,-1.0155589433714285,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark54(57.90269797309011,-0.8329452093945473,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark54(57.95911900715183,-0.899893057333349,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark54(57.985675513253426,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark54(58.01132491887214,-0.6401052549460804,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark54(58.026201481542074,-1.5707963267941984,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark54(58.072153588848124,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark54(58.20222010178708,-1.0677970724383705,0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark54(58.458934952261075,-1.536694996509448,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark54(58.478904239919075,-0.029980529683943852,0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark54(58.54351629036592,-0.7049243662950619,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark54(58.59040968224424,-0.7519956822842414,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark54(58.6109781246835,-0.5836018263717859,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark54(58.64345220042099,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark54(58.64799125343299,-0.9826576296728577,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark54(58.6507161312399,-0.918441510373242,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark54(5.868195100628782,-0.6456554300786834,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark54(58.82835476151181,-5.962889149356221E-11,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark54(5.883861137939547,-1.0218742940240801,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark54(58.867887982276216,-1.5266708315017834,0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark54(58.90090215896038,-0.8346769662748592,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark54(5.908870366142011,-0.15486472867597473,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark54(59.08968233684192,-0.9666683393130557,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark54(59.11015366443019,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark54(5.929178959483033,-1.5506413447903422,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark54(59.29257880921091,-1.5394776701143194,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark54(59.35127011697372,-1.5707963267947656,0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark54(59.35826829335339,-1.570796326794774,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark54(59.38163464543662,-0.6584028789197287,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark54(59.40173013976183,-0.9560625899846382,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark54(59.43697251754091,-0.6290284730748341,0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark54(59.44228598912815,-1.0108268468045645,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark54(59.461483655313685,-0.8778359693345581,0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark54(59.59646576067286,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark54(59.599528684291826,-1.5188214716463344,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark54(59.60989847105,-1.5096687943158411,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark54(59.638617501450405,-0.6109816358891709,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark54(-59.66105636965883,-0.8371466175348399,-67.63123702898763 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark54(59.66470368144948,-1.5384704061758525,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark54(59.751800827580304,-0.9083773684976535,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark54(59.7764053891396,-0.6308836478138292,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark54(5.982536098298647,-1.570496404205535,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark54(59.88143670505394,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark54(59.88972464451088,-0.8758170884618508,0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark54(59.90246420502288,-0.937924170372884,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark54(60.03291281735225,-1.5707963243965715,0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark54(60.09549504438763,-0.8710370254316135,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark54(60.109230790447384,-0.6453042073479105,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark54(-60.11134410453107,-0.6047303420931847,-0.21310273662040147 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark54(60.191572045013714,-0.7059132433278954,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark54(60.205258670127506,-1.5707963267946319,0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark54(-60.25947724640839,-1.5707963267944471,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark54(6.031435485505909,-0.9719875627921646,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark54(-60.32865202908217,-0.6556957832897936,-2412.7653214811603 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark54(60.32878929347942,-0.45479199095851397,0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark54(60.332593229072415,-0.7913449637888972,0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark54(60.35442223724013,-1.5319231486089468,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark54(60.41434892967691,-1.570796326794896,0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark54(60.42475866434833,-1.0056371076643975,0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark54(60.49329179023851,-0.8695761959317072,0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark54(60.59964577909662,-0.7083332534322286,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark54(60.69702982481764,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark54(60.752386305210656,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark54(60.765213028369914,-0.9565423059312903,0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark54(60.8999952990586,-1.5707963267924716,0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark54(60.911010966938505,-0.8526078146692342,0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark54(60.97628902875318,-0.7446620850611516,0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark54(60.993927649703494,-0.6422060006005061,0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark54(61.00350439536602,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark54(6.102068290400343E-20,-1.5195020425328019,0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark54(61.02645990259634,-1.5707963267942797,0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark54(6.102737635421164,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark54(61.06856418853627,-1.5537311466616226,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark54(61.17352697352962,-0.8245030718262782,0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark54(61.20501562187053,-0.8098144232919253,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark54(61.218773876002786,-0.6490830242450922,0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark54(61.22020240900696,-0.3263477216119663,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark54(61.27527090535665,-1.5707963267944294,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark54(61.3072976962456,-0.6927388402205779,0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark54(61.32217849262199,-0.8913822790667751,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark54(61.34972492558318,-0.9926182965299579,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark54(61.40325021271403,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark54(61.442292362398746,-0.8192984208981928,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark54(6.145833992483178,-1.552276288145899,0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark54(61.530919386921795,-0.8019828087420411,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark54(6.161039102751566,-0.9689304192987088,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark54(6.166656984222787,-0.7816418601165775,0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark54(61.8219252091681,-1.5162894450284907,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark54(61.824325156107534,-0.9112615917044278,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark54(61.83047535434957,-0.8897552765742932,0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark54(6.184196953836571,-1.570796326794703,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark54(61.85384364995494,-0.7287894022194773,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark54(61.891816863268446,-1.0533731690349912,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark54(61.95751142745917,-0.5952680551693512,0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark54(62.034771430353715,-0.9292535746226178,0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark54(62.10980904861509,-1.5707963267946126,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark54(62.122657845358006,-1.5707963267947782,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark54(-62.13893744837322,52.73313752514275,-64.78469326723801 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark54(62.154887954412715,-0.949144846982692,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark54(-62.26778690182273,-0.7293231130866121,-31.495538533615616 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark54(6.237757494106539,-0.6925121746835146,0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark54(62.38231022322674,-1.5707963267942944,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark54(62.39714186609635,-0.9852681467259004,0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark54(62.58775627015946,-1.5707963267947571,0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark54(62.58956426525146,-1.0287767650162498,0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark54(62.596046212001454,-0.9354603734309991,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark54(62.68567100830843,-0.8644539339510682,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark54(62.689812022696835,-1.030583945855261,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark54(6.2704052344944685,-0.802264146154215,0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark54(62.807409225506774,-0.6296789458762406,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark54(62.841627695413855,-1.570796326794896,0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark54(62.853474589758065,-0.9543804818024361,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark54(62.866425170393924,-1.0312624973328024,0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark54(62.8781583653191,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark54(62.994898772643936,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark54(63.00482554685489,-1.535914598717424,0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark54(63.00544481457142,-0.5757607214078195,0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark54(6.308701208843853E-5,-1.570796326755925,0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark54(63.11838711566182,-0.8128997127177198,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark54(63.14839322347952,-1.48844634382241E-15,0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark54(63.203216983994466,-1.5379304527270794,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark54(63.231802889905566,-0.8022100275063693,0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark54(6.3306039452914,-1.5707963267940905,0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark54(63.325769203172506,-0.788504758156524,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark54(63.34252245529871,-0.9944155075576075,0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark54(63.40946436075177,-1.5707963267943228,0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark54(63.467773632637105,-0.9018523761187605,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark54(63.50768127789334,-1.54992391253559,0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark54(63.532217931030345,-0.6438758206312372,0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark54(63.624942345662475,-0.7178371231142364,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark54(6.365856867859023,-0.1371835371421931,0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark54(63.71870768985451,-1.570796326794484,0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark54(-63.83764886517387,-0.9382698806184645,-0.6501842625245172 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark54(63.895227771831685,-0.816284144996466,0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark54(63.940094306402386,-1.5707963267944933,0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark54(64.19192867642738,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark54(6.431775253527476,-0.8401290699244628,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark54(64.41639613096828,-1.017869339357092,0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark54(6.445116262233782,-0.7120315883993928,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark54(64.5482257773154,-0.702502416075589,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark54(64.57121616689449,-0.9682459984517546,0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark54(64.59614181078955,-0.5877416819696055,0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark54(64.62847424613801,-1.5707963267945644,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark54(6.4635099789757575,-0.7008707908006191,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark54(64.7736126458973,-0.682820039536324,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark54(64.93633197171815,-1.0350627079498973,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark54(64.94029997667309,-0.6187022746580166,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark54(64.95258309851488,-0.8789565540934996,0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark54(65.00451693824272,-0.8920305561441806,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark54(65.08458753243295,-1.0665900194246272,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark54(65.1559372240356,-1.5410351702966598,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark54(65.2206394238353,-1.5177073832703467,0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark54(6.522172617863099,-1.5231594886284259,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark54(65.25994729329364,-1.5707963267942056,0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark54(65.26793459402452,-1.5707963267919802,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark54(65.35211634942303,-0.7756147331284255,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark54(65.50067790200637,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark54(-65.54746841155658,-1.551971214612958,-0.8651710818714848 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark54(65.56463059309394,-0.6425370769647198,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark54(65.6390731756394,-0.734144489975702,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark54(65.67187398275037,-1.5707963267918927,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark54(6.568190975861656,-0.2824995420244599,0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark54(65.68806163285319,-1.5707963267947809,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark54(65.69846863343236,-1.5255054925993505,0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark54(65.72817317366295,-1.5141182557881019,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark54(65.73970037044528,-0.5999438623710465,0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark54(65.78925174372606,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark54(65.80327134237584,-0.7920001792350035,0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark54(65.81573123099392,-0.057996351204808005,0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark54(65.82141819515564,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark54(66.10351164391909,-0.36769014198954475,0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark54(66.12428030139192,-0.6180291782060943,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark54(6.6138826308120855,-0.7946479860559013,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark54(66.20096532116116,-1.5152822461707913,0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark54(6.62748969420916,-0.8224544143646026,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark54(66.42512979184609,-1.570796326794896,0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark54(66.44390236925253,-0.666034460483772,0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark54(66.46798413527495,-0.8026246889393638,0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark54(66.471926585224,-1.570796326794896,0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark54(6.651719594927128,-1.0444818572808834,0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark54(66.5317212579156,-1.5256715020600708,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark54(66.59632609579356,-0.9552733444428938,0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark54(-66.68168513672578,34.24563660885059,-90.98729356897425 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark54(66.69573931111081,-0.1763665355495535,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark54(6.670006356737687,-1.5707963267944507,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark54(66.78433523618418,-1.5406908783438942,0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark54(66.84715859844053,-0.8644922744492902,0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark54(66.86767056976802,-1.5707963267923617,0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark54(66.91568309966101,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark54(6.692061477228137,-1.5404027761380519,0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark54(66.94315349351518,-0.7773986144272415,0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark54(66.98258226354967,-1.5631332181124775,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark54(67.06927395416506,-1.5130655501906318,0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark54(67.12352227920081,-0.9467748791257051,0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark54(67.15979124370119,-1.5707963267947456,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark54(67.23805352493056,-0.6153316013404905,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark54(67.27850102229468,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark54(67.29830156406031,-1.5471439016562831,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark54(67.39703678852678,-0.8829691871403078,0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark54(6.773755557448361,-0.8418761781459523,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark54(6.781931385370669,-1.0089752950984339,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark54(67.85334682020462,-0.8553339526681814,0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark54(67.93832308043324,-0.7806628288008555,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark54(67.98810124549786,-1.5133982663116412,0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark54(68.03348789163246,-0.7789543800017604,0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark54(6.804839313791228,-1.570796326794896,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark54(68.0748484651713,-1.5143063940573,0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark54(68.1315027366307,-0.6372856686845925,0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark54(68.17324772996591,-0.9247439556672665,0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark54(68.36140885253155,-1.0254780653523794,0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark54(6.836624298571664,-1.027373489940567,0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark54(68.43381235018498,-1.570796326794376,0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark54(68.4892774264125,-1.5250651773987445,0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark54(68.49829644254974,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark54(68.50992488430848,-1.045488749673205,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark54(-68.51274334367037,-1.5707963267941552,-1.0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark54(68.53032795158367,-0.8604521675234196,0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark54(68.62377259022973,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark54(68.70152258260691,-1.5646758699661802,0 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark54(68.76716549082613,-1.5518175462969026,0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark54(68.77716716822177,-1.517916194356094,0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark54(68.83910496517919,-1.5707963267947633,0 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark54(68.93134799609429,-1.570793473989831,0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark54(68.97548541434331,-0.8425110795552584,0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark54(68.98316729951861,-1.5108436115571424,0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark54(68.98941777623861,-0.7523293797925984,0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark54(6.899062603580646,-1.0696091775931635,0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark54(69.00383688613684,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark54(69.0806225384263,-0.49528318012239486,0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark54(69.10281640123472,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark54(6.911463240138644,-0.5803878568638989,0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark54(69.14138134291886,-0.20991681470789547,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark54(69.19112043423297,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark54(69.1946463375621,-1.5707963267450362,0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark54(69.23321912766411,-0.645310376191907,0 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark54(-6.924018191260686,-5.891268932908926E-16,-100.0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark54(69.28289712223804,-1.5707963267925606,0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark54(69.32509421666438,-0.6350428243361055,0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark54(69.37938463478574,-1.5125082465733002,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark54(69.49405705476198,-1.5707963267946923,0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark54(-69.52679911495923,-0.6944002761944233,0.06165392003303451 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark54(69.63923637155767,-2.6782012575953766E-10,0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark54(69.67616149245237,-0.7782613520276933,0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark54(69.69764451897116,-0.16181465871354173,0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark54(69.77866482347571,-0.9841744257377911,0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark54(69.7912343427553,-0.71070511776396,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark54(69.84622063732863,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark54(69.8861564619279,-1.0161549835883836,0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark54(-6.99106664549906,-1.0059915076222694,-1.0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark54(69.94764975693809,-1.0360609953140352,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark54(69.95079002312883,-0.3145985507722637,0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark54(70.14237891511054,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark54(70.16457592045657,-1.001682769664673,0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark54(70.23461135334716,-0.7844786362133025,0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark54(70.24151360043092,-0.6511376683903762,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark54(70.2451779073838,-1.547973365964582,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark54(70.25735288344484,-0.6666631925987688,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark54(70.26719458317777,-1.5707963267945786,0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark54(70.29427573183057,-0.9431633746048078,0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark54(70.30340657716884,-1.570796326794896,0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark54(70.3181379891617,-1.0563487811190058,0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark54(70.34252559595868,-0.8541682090107927,0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark54(70.4019143328689,-0.5926348458195687,0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark54(70.52452903005043,-0.804136382473354,0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark54(70.60267487422533,-0.8350630468528379,0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark54(70.65981836181274,-1.5707963267947764,0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark54(70.68333036640192,-0.8601472976138638,0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark54(7.0741296791664325,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark54(70.74674258961818,-0.9639210051762163,0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark54(70.75220808815544,-1.5256151322012488,0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark54(70.79715151257798,-1.5707963267947775,0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark54(70.82438244873822,-0.9588844629031552,0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark54(70.82744343889192,-1.570796326794388,0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark54(70.83658612691964,-1.003051679673488,0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark54(70.83747365548898,-0.980955600735011,0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark54(70.9418969985398,-1.5707963267945948,0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark54(70.95930280342094,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark54(70.98041342498196,-1.0049901395369236,0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark54(7.1054272670115335E-15,-1.520990141869458,0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark54(7.105427357601002E-15,-0.813336472873587,0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark54(7.105427357601002E-15,-0.9105947326639559,0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark54(7.105427357601002E-15,-0.9731031345561689,0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark54(7.105427357601002E-15,-1.5303301033213668,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark54(7.105427357601002E-15,-1.570796326794575,0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark54(71.0806220008024,-0.824721862285771,0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark54(71.15570693708604,-1.3175833180108994E-8,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark54(71.16085017455121,-0.8335886444463956,0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark54(71.17631265106971,-1.549016180534249,0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark54(71.19549428061686,-0.735158667850726,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark54(71.21291417277794,-1.5130653500190112,0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark54(71.31529578128269,-0.9007468587840748,0 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark54(71.39194518424588,-0.8341549275215927,0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark54(71.56000231405534,-0.8425144014211376,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark54(71.57082897334647,-0.8023910786805173,0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark54(71.63691400436367,-0.8720619524720261,0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark54(71.6773683181217,-0.7131002333936358,0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark54(-71.68676901389803,-1.1562518272582477E-9,55.11069766469592 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark54(71.71587857523596,-1.5538285573046882,0 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark54(71.72435467451803,-0.6094347035902601,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark54(7.176652680860869,-0.9279262258632173,0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark54(71.78819527835779,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark54(71.7930943174282,-1.0035639022789398E-4,0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark54(71.79475582248216,-0.7300407144809451,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark54(71.88021849173205,-1.5707963267942446,0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark54(72.09759457838189,-1.04348478506733,0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark54(72.13553671109932,-0.756579519336988,0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark54(7.220210953036907,-1.5391182405193613,0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark54(72.29114236129624,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark54(7.231307442857743,-0.8237910620242563,0 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark54(72.36822642399669,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark54(72.47539413409368,-0.632293587235317,0 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark54(72.50100480550265,-1.5707963267946639,0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark54(72.52154910022992,-0.0822573136760997,0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark54(72.55901041948525,-1.5646302541139476,0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark54(72.56634572403178,-1.5707963267947669,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark54(72.590609637438,-0.7750172714618304,0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark54(72.66323805245473,-1.0329327648501456,0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark54(72.69130518034534,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark54(7.271432853741562,-0.6216663354490997,0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark54(72.71565140379533,-0.6235706694636631,0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark54(72.75413678930452,-1.5272954268743795,0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark54(72.75740963752452,-0.6054390127889797,0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark54(72.80931195523337,-0.6012061514004827,0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark54(72.87783725628083,-1.06156586116467,0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark54(73.02850457948625,-0.765227905800316,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark54(73.03115093829877,-1.5285805975704823,0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark54(73.12259557745205,-0.6652405760628683,0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark54(73.18361803938973,-1.5707963267502763,0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark54(73.24667707660234,-0.5907317564526018,0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark54(7.3252947453114245,-0.6591838213467742,0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark54(73.39820923295136,-1.5469749265939423,0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark54(73.41529930722126,-1.0085735963221367,0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark54(73.41688457644133,-1.570796326794742,0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark54(73.4303330435531,-1.040139865941496,0 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark54(-73.4370550853058,-0.25297121023239477,-0.6804445571399962 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark54(73.44666580459602,-0.6250670956190415,0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark54(73.49065317115219,-0.18324016042280858,0 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark54(73.50682183815277,-1.5104658232781332,0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark54(73.52043731045434,-0.9663360533540963,0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark54(73.52619570751965,-0.9596012164150526,0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark54(7.353996243325169,-1.9812676975257407E-6,0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark54(73.62667515596812,-1.5247369196236074,0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark54(73.62943381009786,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark54(73.63675783838174,-1.5707963267942584,0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark54(73.74302114383748,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark54(73.97217939939827,-0.9158674348107515,0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark54(73.99548695112048,-1.047263079336005,0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark54(73.99697027974754,-1.0256344772950605,0 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark54(7.406335848480696,-1.5309952168500855,0 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark54(74.14191229112464,-0.5985634488581724,0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark54(74.20299083199673,-0.44475923461117917,0 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark54(-74.30452476852543,-1.5707963267946095,0.1972322259840508 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark54(74.30519751133107,-1.5165915678447097,0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark54(74.37202220674922,-1.5115918230782341,0 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark54(74.38543894419755,-0.9541085016196988,0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark54(74.48691812597865,-0.7366462288522442,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark54(74.49698336662827,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark54(74.51664603196949,-0.1982215238211783,0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark54(74.57442065394036,-1.5254485176215118,0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark54(74.61024678415467,-0.7069271841580331,0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark54(74.63052680640247,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark54(74.6428344889479,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark54(74.66448902036126,-0.8992937611593325,0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark54(74.74914852287868,-1.5428677891727547,0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark54(-7.48082125335668,-1.5707810144753576,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark54(74.81701560136062,-1.570796326794774,0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark54(74.81897031089727,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark54(74.83198100054187,-1.529375993912982,0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark54(74.8349277564823,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark54(74.84577520331396,-0.6875099373489268,0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark54(74.89392668499178,-1.0686048616494226,0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark54(74.90114858628388,-7.091550699934362E-10,0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark54(74.90425914425268,-0.7863574952766808,0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark54(74.97062155141913,-0.664089155512288,0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark54(75.00252291541761,-0.12311829131422822,0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark54(75.00648061601484,-0.8291046840284473,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark54(-75.23716574967914,-0.7035618144917921,64.26777375748428 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark54(-75.33116952918157,-0.6022123794079866,-0.94578950360714 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark54(7.534944256019118,-4.308982813097324E-10,0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark54(75.36675166109612,-0.9244269312633833,0 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark54(7.545252601398975,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark54(75.47424420452215,-0.895488917044122,0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark54(75.65957440901053,-0.7002066106117573,0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark54(75.6801554981916,-0.9561177721176763,0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark54(75.69425318341624,-1.5083609871999701,0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark54(75.71336428119977,-1.0493011546839535,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark54(-75.76390639460682,-0.6765904920893817,-49.28468922835651 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark54(75.85454984503663,-0.8438628130938923,0 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark54(75.87509739373473,-0.7149321346581132,0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark54(7.591454238111673,-1.5091684870728423,0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark54(75.94972122031817,-1.5097008526077187,0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark54(76.04530162408109,-1.059290055362045,0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark54(-76.13070512712378,-0.7704533213843918,0.027728488704496932 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark54(76.2296260900532,-0.6296943727838664,0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark54(76.27598212356594,-0.903872114894134,0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark54(76.37301831107524,-0.7592879996776496,0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark54(76.4228917346573,-0.5876131688267576,0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark54(76.52289769815634,-0.3627223008089814,0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark54(76.5664190012847,-0.8564781987678813,0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark54(76.64825869384367,-0.43430304103302836,0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark54(76.65576658439511,-1.570796326794408,0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark54(76.67914476199815,-0.7873582540938115,0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark54(76.69861523764952,-0.15000784148923244,0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark54(-76.70225234609708,-1.5707963267946567,1.0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark54(76.80183320457638,-0.15513586954847092,0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark54(76.9141133661839,-1.5421643012039714,0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark54(76.96155279152637,-0.2606861036150184,0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark54(77.08259016740914,-1.5707963267946141,0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark54(77.18884837875254,-1.5373446690576262,0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark54(77.28237097090056,-0.6239865489301657,0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark54(77.29674860049722,-0.2715909401937685,0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark54(77.43985042697255,-1.5707963267946958,0 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark54(77.44965190426318,-0.2944539035985042,0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark54(77.59975225845906,-1.5707963267944542,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark54(77.7014619228722,-0.8985202217590498,0 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark54(-77.73370260450794,-9.548017994086962,-0.7392839423159501 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark54(77.79172615682613,-1.5707963267946923,0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark54(77.91598196552684,-1.570796326794896,0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark54(77.97629500026252,-1.5707963267947562,0 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark54(77.98722377753057,-0.7955398693348315,0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark54(78.0510237897637,-1.5247644001309222,0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark54(78.14565179703717,-0.7578008891282972,0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark54(78.16977331019395,-0.7629369132921298,0 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark54(-78.19684397452883,-1.5707963267947562,59.75344275790323 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark54(78.20249889438145,-0.736780207775392,0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark54(78.20583165739941,-0.6770060572457979,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark54(7.825416702559149E-11,-1.5207592524117657,0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark54(78.26026538030355,-1.5650891518533292,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark54(-78.3086109601938,-1.5707963267929728,1.0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark54(78.38210657950638,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark54(78.42597873773875,-0.6241558014609718,0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark54(78.44304734497231,-1.5707963267943832,0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark54(78.50046710654726,-0.7976851997322456,0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark54(78.60283211246309,-0.7609607258017599,0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark54(78.93583717368709,-1.5707963267947116,0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark54(-7.906392755248966E-18,-0.5713637818060154,-1.0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark54(79.16610152411795,-0.951104634083288,0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark54(79.24957313715714,-0.631805801527114,0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark54(79.26663422093597,-7.538387599276213E-5,0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark54(79.26960725455308,-0.822947628494673,0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark54(79.29006675028283,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark54(79.29786180831223,-0.6736431729372503,0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark54(79.43398794460273,-0.6061777521253102,0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark54(79.58252131452608,-0.93566890211393,0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark54(-79.60303415619782,-1.0655929663054933,-0.06255528842039879 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark54(79.62281688378448,-1.5707963267945466,0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark54(79.63430162638774,-1.5707963267947385,0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark54(79.66266885555692,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark54(79.77348251331448,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark54(79.79480786980025,-0.9113941251725475,0 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark54(79.80986435211878,-1.5707963267947171,0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark54(-79.84245064522092,-0.73489795710897,43.729029534153014 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark54(79.84641097531187,-0.7384265304568021,0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark54(79.87058740657545,-0.7806958023053951,0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark54(7.996631217014421E-20,-1.570796326794896,0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark54(80.02569930822116,-1.5295136825466482,0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark54(80.03870874767354,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark54(-80.04045809618603,-0.7449295163510695,-0.11739097788225605 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark54(80.05206633615119,-1.0527231696467623,0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark54(80.0553183075356,-1.049332626018094,0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark54(8.008531644471347,-0.8552061142305334,0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark54(-80.10353276912983,-1.531486116033048,53.669074345051484 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark54(80.124963851281,-0.9318996384089608,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark54(80.1433944735603,-1.5406450176981754,0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark54(80.17515296262624,-0.7332837597927124,0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark54(80.18210453137058,-1.0445550425127568,0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark54(80.19140904634705,-0.7192271147659848,0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark54(80.31571703455634,-0.5125360113775096,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark54(80.32481320936256,-1.0681922049802242,0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark54(80.34580774582021,-5.300185522669409E-9,0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark54(80.40485032857795,-0.7927048598377766,0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark54(80.52934556944501,-1.529452198051933,0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark54(80.55576779157774,-0.7972087859765868,0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark54(8.063305909482565,-1.025876554525425,0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark54(80.73795640730032,-1.5707963267947407,0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark54(80.77370127692527,-1.5707963267947278,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark54(80.7768455208163,-0.8777652217587965,0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark54(80.80089210067024,-1.5707963267945289,0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark54(80.82800052220239,-0.08210617020386268,0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark54(80.84384544871887,-1.0477838770437915,0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark54(80.98989025937517,-0.6698604384209204,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark54(81.01942321134254,-1.5707963267912817,0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark54(81.11388247177243,-0.7521995963339041,0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark54(81.1315963507434,-0.8059715224280689,0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark54(-81.1608250937173,82.39970992166784,55.99996715404055 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark54(81.20807664545418,-0.7203102851497807,0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark54(81.49686008601412,-1.525041415305168,0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark54(81.65703682275735,-1.032144021846491,0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark54(81.69069517026989,-1.570796326794896,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark54(81.71604999731022,-0.2024388007709043,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark54(8.183928602091783,-0.9326738107751971,0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark54(81.97663796896427,-0.5880034003409946,0 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark54(82.04108071045167,-1.5542415899126845,0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark54(82.30245824615645,-0.7345686374001144,0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark54(82.38154149148863,-0.9719479324086746,0 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark54(82.4538950633106,-0.7209363362334003,0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark54(82.47324671855705,-0.6805276375720726,0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark54(82.61420210398441,-1.536935379769898,0 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark54(82.68982203625288,-0.6112798866006721,0 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark54(-8.271806125530277E-25,-0.5884645239239914,0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark54(82.73686207648585,-1.2676241673625981E-8,0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark54(82.85025133679343,-0.9856857151003906,0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark54(82.85436558601171,-0.7982290596895878,0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark54(82.89328020436677,-1.5481246418324335,0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark54(8.292182252492328,-1.5473574241705375,0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark54(83.00019762772928,-1.5707963267913385,0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark54(83.02830071842695,-1.5707963267919427,0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark54(83.2784539018258,-0.1852722378391748,0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark54(83.35927823826061,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark54(83.37778442992979,-1.5191016231870296,0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark54(83.39494633975603,-1.5707963267944542,0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark54(83.40322655494667,-1.5707963267606857,0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark54(83.40807622885788,-85.29674285005795,-10.895169450484232 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark54(8.343852030428451,-0.5530487548531989,0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark54(83.4899736344839,-0.8156839229180832,0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark54(83.50891407845171,-1.5296093575025427,0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark54(83.55104244632926,-0.7934808012707464,0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark54(83.59280476328377,-0.6276622201554698,0 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark54(83.61824487968852,-0.9458306294103618,0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark54(-83.63336229240731,-0.7978363075771696,0.0625525315771446 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark54(83.68500215270356,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark54(83.75278516723881,-1.5327134451943345,0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark54(83.80431104592924,-0.33046889362033494,0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark54(83.81494125983903,-0.915063467393562,0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark54(83.82718121084176,-0.8953762577076532,0 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark54(8.384810331221644,-1.537721299052516,0 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark54(83.88288080220474,-0.9811021528410073,0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark54(83.98153047545918,-0.7092583396575796,0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark54(84.0161814554686,-1.5381350239795522,0 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark54(84.11200107378842,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark54(84.24473383349806,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark54(84.32374161364766,-1.5549261216406682,0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark54(84.32454654247215,-0.7195768565944167,0 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark54(84.68656859040078,-1.5707963267946994,0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark54(8.469858042760725,-0.5745628482715261,0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark54(8.482624360819123,-1.534715007182232,0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark54(8.484226947982338,-1.5114950991500251,0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark54(84.86047868750413,-1.5140968105780441,0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark54(84.90623059298191,-0.7466883851646273,0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark54(84.95856360781826,-0.9979115826150339,0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark54(85.069750899806,-0.8843865697595505,0 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark54(85.13673358169919,-0.984536385641445,0 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark54(85.17231990608371,-0.5588049446034916,0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark54(85.28111732528018,-0.6922970023250983,0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark54(85.37639085269902,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark54(85.39638526693679,-0.7918461986569285,0 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark54(85.44851175352,-1.0420227781060578,0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark54(-85.55293914166151,-3.181953769820232E-5,2461.2621203279687 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark54(-85.61346696078266,-0.9437209532941292,-1.0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark54(85.6196201396186,-0.9850035020566614,0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark54(8.562233016976833,-0.9071740689568779,0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark54(85.74749351498699,-0.7684358645183692,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark54(85.82698510662351,-0.6507857231550913,0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark54(8.584040221558567,-1.5707963267946319,0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark54(86.12060579573111,-0.7827031504732271,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark54(86.21932633456888,-0.7625184932934039,0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark54(86.22298711672309,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark54(86.3540279827051,-1.0427485906764,0 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark54(86.3648518825043,-0.3916288647014562,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark54(86.42377314836008,-0.9592782228291554,0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark54(-86.47940347340902,-0.5772886253229128,86.10847835190172 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark54(86.58330586460085,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark54(86.58589758141235,-0.9398012860577638,0 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark54(86.65696183361132,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark54(8.675696776461805,-0.8968392004288894,0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark54(-86.77788661750087,-0.0472553241406398,1.0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark54(86.78175683302837,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark54(86.80728871964584,-0.7580766088442772,0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark54(86.81036413121225,-1.5142621609784452,0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark54(86.81807123001914,-0.729940534186789,0 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark54(8.694934013567845E-6,-1.5707963267947394,0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark54(86.95082247033517,-1.570796326794114,0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark54(86.96290823550976,-1.5637448245314358,0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark54(87.0847756977991,-0.6813283283095704,0 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark54(87.10120716932121,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark54(87.13840182779165,-0.03969011554640652,0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark54(87.1420905661295,-0.6543308569996418,0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark54(87.19648840527444,-1.5707963267941238,0 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark54(87.26733560759413,-0.7520783736601375,0 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark54(87.27699403012465,-0.7407955760750153,0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark54(87.3239354020902,-0.9987637832410482,0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark54(87.34261000640441,-0.7378573784595739,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark54(8.742656147896021,-0.636080091167095,0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark54(87.43480244191821,-0.814453894026542,0 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark54(87.4991346768783,-0.7140042024614104,0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark54(87.5821555249461,-0.8358992456032643,0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark54(87.59089129372526,-0.6392385780764442,0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark54(87.65621549439399,-0.7974806177530063,0 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark54(87.68181293370438,-0.6050894119403267,0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark54(87.73286234891307,-1.5420955620102474,0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark54(87.75086645708221,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark54(8.777054040243428,-0.8577377303055727,0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark54(87.77634331229777,-0.9761567148367902,0 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark54(87.907778362606,-0.9164098166474535,0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark54(87.93197153654552,-0.3030007484461018,0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark54(87.94132952987206,-1.516558162815992,0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark54(87.98145631378304,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark54(87.99891785999372,-0.7322635974927438,0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark54(88.00478753173553,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark54(88.00782223615192,-1.5540009598034885,0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark54(88.12891748864573,-1.5707963267946616,0 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark54(8.814060958698283,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark54(88.28796238636785,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark54(88.41522127893,-1.027216324091849,0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark54(88.79829476480666,-0.8617419769472225,0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark54(88.80653891949164,-0.7539681960139557,0 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark54(8.881784197001252E-16,-0.21871413561763245,0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark54(8.881784197001252E-16,-0.6202567515661481,0 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark54(-8.88227529944888,-1.534406350306068,-1.0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark54(88.85427885749884,-1.0627833575577332,0 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark54(88.86741972017613,-1.0214281202339777,0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark54(88.89108311054821,-1.57079632679471,0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark54(88.90675260569282,-0.8723789268889084,0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark54(89.00353658991577,-1.549541060498577,0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark54(89.03771339432498,-0.5735049649519519,0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark54(89.06650245259226,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark54(89.13749132315067,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark54(89.15345464012854,-0.7261973909688493,0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark54(-8.917967030736975,-1.5151924998395174,1.0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark54(89.28867033899314,-0.9795715415694666,0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark54(8.92999158028843,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark54(89.32718765240772,-0.8954264567749788,0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark54(8.93905900689834,-0.1947208854962063,0 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark54(8.942814936671562,-1.5525521100012956,0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark54(89.45708123653077,-1.5488778703614903,0 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark54(89.46371228378976,-0.7699880772078903,0 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark54(89.69883030496138,-1.570796326794536,0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark54(89.71825243689446,-1.5707963267943725,0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark54(8.972883084503835,-0.7162409570347812,0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark54(89.7353549594751,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark54(89.73657137205407,-1.510376596105668,0 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark54(89.7536429334565,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark54(89.75773493639377,-0.6067219531231842,0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark54(89.87195407183023,-0.6095419252542967,0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark54(89.89192302453219,-0.9163134472746187,0 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark54(89.93727498259156,-1.5707963267945217,0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark54(90.06013819740485,-1.51784353288693,0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark54(90.06349804988696,-1.5415053816576876,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark54(90.19603509764814,-1.570796326794433,0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark54(90.29141281490917,-1.5707963267912965,0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark54(90.3427819247801,-0.7119074029505015,0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark54(90.3613780943403,90.51907106851618,-15.889061098841736 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark54(90.36828837010506,-1.570796326791769,0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark54(90.39717913380201,-1.0119741925781243,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark54(-90.39893554720382,-0.5947793370535883,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark54(90.4753154838979,-0.8094899382455623,0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark54(90.49224619789891,-0.9138834499540378,0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark54(-90.49365584839686,-0.873284459614819,-0.600882740122815 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark54(90.72837843529328,-1.570796326794896,0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark54(9.07325290826708,-0.4164677692488216,0 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark54(90.74936893389466,-1.5707963267947456,0 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark54(90.82743842246009,-0.8768705904903982,0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark54(90.94357897707525,-1.5707963267944933,0 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark54(91.07885455841583,-1.5707963267930296,0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark54(91.1273945740856,-0.6702929639471842,0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark54(91.13702481863763,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark54(9.12414208672618,-0.6107127675003952,0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark54(91.26578992977016,-0.8851276361097993,0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark54(91.28285067386682,-1.5699641437433502,0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark54(91.50177976999754,-1.5233157145972207,0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark54(91.54113782793297,-0.673562732597162,0 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark54(9.156895304544179,-0.8524945263871411,0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark54(91.93967853533945,-0.8869708196564938,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark54(91.95398515820308,-1.570796326792482,0 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark54(91.97833245301,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark54(92.02138210992706,-0.1444310055668948,0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark54(92.06732849874575,-0.27062919546238395,0 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark54(92.08891488716762,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark54(92.08952706296967,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark54(92.09760168985923,-1.5657118764666027,0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark54(9.210002030093744,-1.5698427879528225,0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark54(92.10203814456884,-1.5707963267943086,0 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark54(92.11168424259566,-0.854520004748715,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark54(92.23483119032446,10.180729044020012,74.11124222136934 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark54(92.28915323132017,-0.9352177935285226,0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark54(92.29809451078336,-0.9887993883943551,0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark54(92.36490694235113,-0.8584248317129664,0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark54(92.41326387376893,-0.8032126363420673,0 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark54(92.4518933629622,-1.5707963267946745,0 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark54(92.6203350055792,-0.9982323721857111,0 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark54(92.63444978150521,-0.09920846602097388,0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark54(92.63515823760972,-1.0093211729772111,0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark54(92.68376240945153,-1.5707963267943121,0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark54(92.73794939252888,-0.20411804293086075,0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark54(-92.79673433007872,-1.0211369932713814,0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark54(92.81372893442051,-1.037898568748068,0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark54(92.8442012066493,-0.6863905138120852,0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark54(92.9157811741274,-0.8069549535564615,0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark54(92.99938826309969,-0.8305127014941776,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark54(93.0747902372361,-1.0132874257144375E-4,0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark54(93.0750370215305,-0.6949421659468609,0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark54(93.17667973249766,-0.9869189436016222,0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark54(93.25367098718476,-0.19449305913412535,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark54(-93.34893411532333,-1.5551465239763456,1.0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark54(9.33787727269808,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark54(93.39845758875231,-0.4383070632819196,0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark54(93.44371449892677,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark54(-93.59075646004734,-0.24902004604962888,-3.3087224502121107E-24 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark54(-9.362228544806953,-0.895256300661937,9.042551847136977 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark54(-93.66073579834571,-0.7573705604872466,1.0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark54(9.376215295436879,-1.0657020504207395,0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark54(93.77084947152503,-0.8373065273334248,0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark54(9.377932597054988,-3.6853776054472625E-11,0 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark54(93.84163932914058,-0.780779415223714,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark54(93.92302983820139,-0.7884116402084781,0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark54(94.0087821606327,-0.65144394980274,0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark54(-94.09174913252943,-0.828355599302391,0.15465772981460724 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark54(94.09746871276643,-1.5707963267947385,0 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark54(94.14989224326479,-0.524268595381241,0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark54(-94.16344355235977,-1.5382582644919414,-100.0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark54(9.416797606194635,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark54(94.18915442288622,-0.9341790157533363,0 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark54(94.21590145689133,-0.9098080010659402,0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark54(94.21639557552733,-1.5445819263183633,0 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark54(94.27144546092404,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark54(94.36175019401298,-0.60181496306806,0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark54(94.41394499316579,-1.0519130975109743,0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark54(9.44411162528776,-0.574941741365194,0 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark54(94.54311929368609,-0.2513915612626373,0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark54(9.462853878800642,-0.6161076417742788,0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark54(94.66923784032004,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark54(9.469637180701117,-1.0534808145726953,0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark54(9.476191592763655,-1.5465605643406075,0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark54(94.78968019659081,-0.9749797814005774,0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark54(94.87922843883138,-0.9461943350633675,0 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark54(94.94977368338849,-1.5152107354357818,0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark54(95.02024590343493,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark54(95.05395842040357,-0.6184826658872282,0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark54(9.51825800579116,-1.0678357458378258,0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark54(95.22163848790842,-0.9011387650236884,0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark54(-95.34217728592944,-1.5707963267948961,0.6944783849916937 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark54(95.34276084699567,-0.9967478317621001,0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark54(95.3600483150189,-1.5707963267946887,0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark54(95.3654276138615,-1.5392287184830113,0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark54(-95.43817457218584,-0.8974066873539006,-2401.6594055722744 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark54(95.49795707532036,-0.8580799910018502,0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark54(95.59983385195467,-0.7604941553014841,0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark54(9.56731946702386,-1.0120663018863105,0 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark54(95.68742120364642,-1.0407605266904665,0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark54(-95.7011316457735,-1.5707963267948961,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark54(-95.72936937549436,-1.5707963267948961,52.28553218689288 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark54(95.74699060145163,-1.570474882182247,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark54(95.91255425939198,-1.0597384521027957,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark54(96.0756555559637,-1.0647785657275541,0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark54(9.612675090577696,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark54(9.61543105691635,-0.6044314627313607,0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark54(96.19784148152269,-1.5707963267946,0 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark54(96.20495480723054,-1.028861888192494,0 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark54(96.21239852178209,-1.0163751132786385,0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark54(96.33426143626994,-1.5707963267919554,0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark54(96.35027962309255,-0.9463403101197839,0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark54(96.36096378648008,-1.570796326794896,0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark54(9.639567211409855,-0.9645441654956457,0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark54(96.39569083556037,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark54(96.45604198148419,-0.7612191055433881,0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark54(96.4563446461603,-1.542265106457257,0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark54(96.45852945460632,-0.6574446236340634,0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark54(9.649789456280175,-0.8229982348514004,0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark54(96.51994562570701,-1.5707963267411944,0 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark54(96.52115879556888,-1.5253019407037316,0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark54(96.54239386682121,-0.9897810316583122,0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark54(96.55343778710008,-1.0629925276827228,0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark54(-96.56190816906457,-2.5428643438203832E-15,100.0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark54(-9.660712891387348,-1.5707963267942198,-1.0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark54(9.662457093016053,-1.5432489861298206,0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark54(96.64205797083702,-0.6275392066406272,0 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark54(96.66863904507537,-1.570796326794337,0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark54(96.68762464203871,-0.6643943939293565,0 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark54(96.70093207968878,-1.5478667791086251,0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark54(96.79721939252093,-0.5982613211145136,0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark54(96.88142858234781,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark54(96.90662745487236,-1.5707963267944756,0 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark54(97.01265031216764,-1.5524017937992127,0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark54(97.18128067193845,-0.9711847580584893,0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark54(97.4131549355096,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark54(97.51529371745136,-1.570796326748649,0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark54(97.52034271465072,-1.5661547471637847,0 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark54(97.5893363685879,-1.5391696868137903,0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark54(97.68941421471953,-0.7348303173381971,0 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark54(97.71449031524583,-0.8668552671231886,0 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark54(97.73008447569211,-1.0513313476605146,0 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark54(-97.86326175828482,-1.52264770051229,0.0022685899727692234 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark54(97.88737407669038,-0.6760958695056858,0 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark54(9.794013106956528E-5,-1.5087610008041135,0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark54(98.04169980285394,-0.10257835669104709,0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark54(98.09372943057093,-0.6784278635780652,0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark54(98.09739233270355,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark54(98.13720827058354,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark54(98.16130624548828,-0.574576995750443,0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark54(9.818212177943636,-0.13865091600769536,0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark54(9.818432236560426,-1.5707963267947207,0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark54(98.18669994399895,-0.8893222942309271,0 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark54(98.21165550365686,-1.5707963267947573,0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark54(98.27237898596091,-0.8917127723653133,0 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark54(98.2861030151178,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark54(98.30215680104558,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark54(98.32964879661645,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark54(98.45552456362714,-1.570796326676127,0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark54(98.50662309045524,-0.8782146647039433,0 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark54(98.64564175032655,-1.0707872361349953,0 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark54(98.64723148073455,-0.6977608897610905,0 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark54(98.72978198744485,-0.7659487855480478,0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark54(98.81411011347461,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark54(9.886235185423342,-1.57079632679433,0 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark54(98.89592754076594,-1.5707963267941685,0 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark54(99.03246881560048,-1.5707963267946807,0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark54(99.05012893428639,-0.9095888830100138,0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark54(-99.16311782295475,-0.8290807391571064,0.02226580493813724 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark54(9.917818217595524,-0.9446405675532801,0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark54(99.18726166254392,-0.48686872240019013,0 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark54(99.19324334506405,-1.0153240282752414,0 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark54(99.21171856672945,-1.5707963267945395,0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark54(99.22628004427199,-0.7902764727418218,0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark54(99.25706417203787,-1.525062809201342,0 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark54(99.27701983422426,-0.7957692741912012,0 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark54(99.42430124962235,-1.5277378105569444,0 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark54(99.4309647478774,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark54(99.43973136242721,-0.7048348924112133,0 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark54(99.48050463101728,-1.5147654063468876,0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark54(99.49709388325203,-0.7465761705227387,0 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark54(99.4978186329709,-0.6529806448887245,0 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark54(99.58403681818044,-0.7916295316508686,0 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark54(99.67515056816808,-1.565766146151055,0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark54(99.6982925305403,-0.9716180295923439,0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark54(9.976750357546321E-6,-0.7489452676089899,0 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark54(99.81212158878816,-0.6536937392634314,0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark54(99.81843852423299,-1.5707963267941238,0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark54(99.85903639349425,-1.0392703675956199,0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark54(99.99213991729755,-0.8831900416193976,0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark54(99.99999999994147,-1.0295443725360578,0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark54(99.99999999996922,-1.5707963267923515,0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark54(99.99999999997952,-1.5707963267923986,0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark54(99.99999999998026,-1.5707963267919258,0 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark54(99.99999999999069,-1.570796326794084,0 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark54(99.99999999999096,-1.570796326794255,0 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark54(99.99999999999154,-1.570796326792287,0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark54(99.9999999999922,-1.5707963267917224,0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark54(99.99999999999311,-1.5707963267923464,0 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark54(99.99999999999993,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark54(99.99999999999994,-1.570796326794896,0 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark54(99.99999999999997,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark54(99.99999999999999,-1.5703908914422535,0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark54(99.99999999999999,-1.570796326794896,0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark54(99.99999999999999,-1.5707963267948961,0 ) ;
  }
}
