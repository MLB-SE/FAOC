import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(-0.11727377212488532 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(0.1741337348534806 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(0.29334332701672317 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark31(-0.4999999999999982 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark31(-0.4999999999999999 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000000000001 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000000000004 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000000000009 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000000000018 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000000006783 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000487539162 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark31(-0.5175886156994949 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark31(11.779104454363747 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark31(2.2080500415434368 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark31(-2618.0818599590657 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark31(2641.3816396132115 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark31(2647.9340840294462 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark31(-2747.5846325367747 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark31(-3.1078195794005126 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark31(-33.99059468373997 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark31(-34.5 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark31(3.4603570595244153 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark31(34.75368450154636 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark31(-3.5 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark31(-43.243274119983234 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark31(44.93328476779601 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark31(4.555195750037238 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark31(50.56647718752947 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark31(-57.3275858342061 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark31(-58.90804051887682 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark31(-62.782256958680364 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark31(-6.5 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark31(-77.15319299287373 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark31(8.14510887247802 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark31(97.17952804725488 ) ;
  }
}
