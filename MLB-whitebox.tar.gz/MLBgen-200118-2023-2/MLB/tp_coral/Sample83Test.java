import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(0.9999999650628658,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(0.9999999965370244,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(0.9999999998801623,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark83(1.0000000000000004,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark83(1.0000000039329957,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark83(1.000079913470614,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark83(-17.592744707026228,44.04274804366963 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark83(2.006186934008719,4.024785670902399 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark83(24.841153146519872,58.065926149945824 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark83(3.4094645424489807,11.624448466216847 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark83(-3.7582006154215977,14.124071873762944 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark83(-39.232145754301825,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark83(5.073136099869261,25.736446243455866 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark83(-5.908578432158903,34.911198769837085 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark83(-6.621551667835011,43.84494648902653 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark83(-69.79116045654112,98.82485350667133 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark83(7.165158064909652,51.34040496027261 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark83(-73.09751746187439,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark83(-9.124408265770521,83.2548262004616 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark83(95.99143748925371,7.802360227044119 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark83(96.95807506667782,0 ) ;
  }
}
