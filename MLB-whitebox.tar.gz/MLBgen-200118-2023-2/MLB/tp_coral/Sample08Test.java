import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(-0.0011850060599539745,25.816955577232427,52.86597273417445 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(-0.002721236743864012,-5.954334244489367,40.61980798902577 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(-0.0033399822761310746,15.024547582823791,30.06003940369204 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark08(-0.003686570631697171,-29.6595282139684,-59.33011613073607 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark08(0.014082818427204767,-9.80216241119166,14.936165671741348 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark08(0.024875580737206304,18.45607228311201,37.95775229731217 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark08(0.0,-29.531218552042816,-57.78257847724206 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark08(0.03202061897015148,6.445631267597958,35.53912976853642 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark08(0.03676975432049566,6.197921864115723,12.61584086765275 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark08(0.03748843055243331,-10.804649781047898,-1.799214593696947 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark08(-0.06802051437656392,-13.349342102284652,-25.331949420904166 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark08(-0.06847276678678363,-44.44593855921143,-88.79882189392474 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark08(0.08193339799191855,-29.439587030395497,-57.06988553639001 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark08(-0.12387050206569317,-60.50730670156971,-120.24494859442387 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark08(0.12972111921391763,21.93717339839766,45.81488824990304 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark08(0.15709347750451397,24.86435420519544,50.268341006484526 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark08(0.20439761555288408,-11.81002019993545,-21.48620543943133 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark08(-0.2097727653536796,0.07175781498945877,-0.485802666082121 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark08(0.21074246361281931,-17.98147762954138,9.577548776579079 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark08(-0.24790874104185812,-29.553733972006327,-58.94801675192931 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark08(-0.27059665688968226,29.082376772494502,-0.5004331454112062 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark08(-0.3052190631696757,-27.450396226726383,-54.248144283469195 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark08(0.35987900349966756,-14.261344810313812,-26.986146113663853 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark08(0.3805111676820445,-5.278303728152233,-7.8647536657990464 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark08(0.3884659390023302,44.232644929637644,89.80505696831526 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark08(-0.4458685269749275,28.63758681759214,57.50836438105439 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark08(0.4565757822649225,26.1560579102708,55.13219374625223 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark08(0.6175671441275821,-5.141423404147287,-8.371737007813024 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark08(-0.7146861989488628,50.28663113502585,100.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark08(0.7582986957582337,-1.0174845024695378,0.735352611925515 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark08(-0.7905585187947124,0.3904778462167417,5.088496205468118 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark08(0.8632457924207324,33.25513831809747,70.21737617614293 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark08(0.8637484554914958,-51.95981375352931,-100.0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark08(-0.8938785529666646,4.596867296268485,7.788972576763982 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark08(-0.903032194197487,33.90111918783646,65.10303926856676 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark08(-0.9095004357319177,-16.589922989957415,-35.90834728711058 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark08(-0.9406236838171012,-1.6681496001269451,-6.158170251705174 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,100.0,-57.86512952162608 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,100.0,-98.42920367320511 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,100.0,-98.52202655659431 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark08(100.0,-100.46676379887177,100.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark08(100.0,-124.93497907315522,51.18751818953159 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,99.866544500907,-100.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark08(100.68770695423487,-106.69826117246349,92.20869250368291 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark08(-100.77280979834033,238.5226978729862,175.6356736079724 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark08(-10.144854126765425,61.7056577868928,93.00651056214093 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark08(1.0170645547610753,28.106687093993745,60.5518040419098 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark08(-1.0250626207719862,5.228674877133958,8.82252216261419 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark08(-102.55732892823116,94.79113522721696,-12.78809553572357 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark08(-10.497616715885883,-34.46877150268382,-98.8595968262304 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark08(10.501196957021804,59.03148641729184,-47.73234396118445 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark08(10.609138871817425,-46.523697897876325,-59.64918285350548 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark08(-106.22524286240406,128.88309950503213,-42.32794608293359 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark08(-10.712271438722901,25.580162613651023,20.41300723504082 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark08(-10.7347254865503,-6.743300709252047,25.68602708306803 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark08(10.745900962974162,-98.44271966881276,-33.03911921624743 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark08(10.774009759720002,-18.696029281344895,-5.070029283529777 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark08(-1.080341968203527,6.342547154730646,-97.66638180679517 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark08(-10.868570238450998,13.969383419184952,-3.1009885698544712 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark08(10.876025265695015,-5.887053299162708,21.97513534339637 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark08(1.0907413507629329,-26.00017848622768,-48.72813292016655 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark08(10.932318078999796,28.37785158338768,89.57679145934588 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark08(-10.940819130739238,43.2949285750036,-26.008552635038388 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark08(10.951760783843692,-36.859410627851986,-39.701278771363235 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark08(-11.382780358487558,-18.38243423958031,-70.76575115626649 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark08(-113.9155002622084,162.79376333261493,-163.85293947182183 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark08(11.419254407674591,-10.400670172967889,15.002577587588014 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark08(-11.454388373271234,-26.09034823214844,-85.21917997190008 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark08(-11.45891747013294,-11.363964992543536,-55.12687349042861 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark08(11.74072500992367,2.201842606579067,41.03530398209973 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark08(11.750414918054345,-2.276533523866322,0.01856603199976317 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark08(-11.825507426382373,-11.668290590275959,-57.242307132904145 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark08(-11.97036656140413,24.70856346296712,-58.131483986350474 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark08(-12.087809776145228,63.054930624322964,91.41722824700514 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark08(-12.09799118163909,1.0825056961751383,-33.16298122176734 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark08(-12.152305368389008,-40.08961227011436,-63.44465333235176 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark08(12.167693269274334,-21.73949745085541,-5.967990921573194 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark08(12.274364165432555,-16.348359920233587,4.126372655830493 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark08(-12.319773338994189,16.38574900986716,-2.6170256704533545 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark08(12.400217275932908,-20.8325653022546,-4.464478776710475 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark08(12.402190743570316,-65.75186819200741,-94.0920630583372 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark08(-12.419209675920087,15.99179734083788,-3.8957812199336623 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark08(12.449456889453586,-44.804381644762124,-50.6895962943686 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark08(1.246833691126062,-38.71089894330842,-60.756758784748946 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark08(-1.258492353694808,48.42793125749942,93.08069903455004 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark08(-12.593595491744068,15.43222979349312,-5.523405806779476 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark08(-12.65924384745471,42.70066578546749,47.42360002857089 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark08(12.678558883596324,30.246381229203976,99.73731969368046 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark08(12.733058513816369,-23.84021234428138,-7.974062982168502 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark08(-12.757788132859492,26.80197489046648,15.823213103535348 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark08(-12.7820585532548,23.44727221281171,10.119165092653919 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark08(12.80267872656844,-7.7267189807996886,-31.885088065672534 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark08(-129.3108174529212,258.1586988697735,128.6243020123 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark08(13.009951432063332,-17.336235289031773,4.357383718126452 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark08(13.048943587869152,-24.994153038355755,-10.841475313104048 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark08(-13.13303097803837,18.30052686229018,-2.798039209534748 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark08(13.209814425935406,27.772969307682963,95.17538189317216 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark08(-13.214968589177191,10.571078950445303,-18.502747866640966 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark08(13.216702188273677,2.827103289891605,46.202339841197826 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark08(-13.26754285181119,-6.950916183823398,-53.63135828645597 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark08(-13.27804930390397,-16.07543781756459,-70.4142272200462 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark08(-13.32863125795932,1.284669836485751,-35.84575777411157 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark08(-13.331096752820939,35.68178754787664,32.9288479732555 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark08(13.339495716298128,-17.4235303848041,5.171426379286186 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark08(133.56457628460996,-210.38793187673414,117.22968119655212 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark08(-13.377094110024814,39.65633327361658,40.752180543953614 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark08(13.39942879758561,-32.222545655096084,-23.22803300672715 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark08(13.518430545726213,-19.0215131526227,4.083061658728136 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark08(13.518772800446074,-68.489348432729,-99.31271904523886 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark08(13.526356112784407,11.291944561077596,60.57616411132125 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark08(-1.3526507615621666,19.729837296562568,36.97251863523353 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark08(-13.560520827637447,31.90708117395784,24.241583977236314 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark08(1.3669136505527858E-4,-45.1225495591281,-88.67389271736614 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark08(-13.680685072146074,-3.9794468902437865,-47.4301526701309 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark08(-13.684836308530215,44.15211499268206,48.73153577792308 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark08(-137.08248433368047,270.1555530408843,130.47262032325895 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark08(13.796570054719213,-32.0255547226594,-21.090602954366265 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark08(14.16856957482147,-26.291617761261698,-8.50673047126409 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark08(-14.19176868438166,18.408953602220457,-4.217184917838798 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark08(142.72192777728762,-101.06077986178951,227.6083905881517 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark08(-14.27530141241785,-21.706441525150463,-86.23878728755447 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark08(14.295676583960143,-55.74769758271663,-67.03756908675794 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark08(-143.0214163997152,100.0,-227.49345287343473 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark08(14.329562436674022,-19.10608453540167,6.347314566013617 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark08(-14.34170244271926,61.728999848678725,82.00368869599455 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark08(143.56192009540862,-119.08743433745222,194.02794318899078 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark08(143.70463013577407,-100.0,231.49801946546808 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark08(-14.375157648069573,18.749618706024794,-4.374461057955224 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark08(143.75282883987427,-100.0,231.28375128221265 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark08(143.92956590276066,-100.37871271879425,231.64104770037443 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark08(14.42424227526384,-19.1928009114553,4.887138742123885 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark08(144.7420052726921,-105.555664041172,220.3136662757476 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark08(144.83358614719953,-99.03182730486762,237.3253239201336 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark08(144.99988854123737,-99.65356670466322,237.39526810139552 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark08(145.19002536745398,-131.28559558413892,174.64234143258443 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark08(145.23737675746418,-100.0,237.26861579985462 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark08(145.289088416367,-100.0,237.131511987491 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark08(145.30867891614926,-100.0,236.94736260000826 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark08(145.4011546439651,-131.58555922431015,174.5993729521387 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark08(14.545591187412928,10.19685975006298,65.60128938915963 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark08(-145.6341649402783,269.46500840343964,102.178334594808 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark08(-14.584474476543607,24.680201738170062,7.177776373504199 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark08(146.07228002616228,-139.99387719613745,162.56760703433258 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark08(14.627558063368495,-21.936783250250443,0.009107689604597706 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark08(14.630432818501317,-21.944764031691385,0.0017703921211865118 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark08(146.8684050718759,-127.40147061696341,187.15154267268537 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark08(-14.722960064518134,15.440727370467746,-8.571748939938843 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark08(147.8281092925798,-128.33600501721213,187.09640769528656 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark08(-14.844512808008492,7.286003606390813,-28.393001679406765 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark08(14.868554162424365,-4.364415742719704,37.44684516684245 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark08(148.93578423794054,-112.93712492304671,221.12543380681856 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark08(149.05150676273493,-151.12676070093502,146.27555480477682 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark08(149.62987125318125,-106.27096551298993,237.8191945923756 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark08(-14.96855165329232,-8.19690457845,-60.086749088387315 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark08(150.16176041410122,-100.0,250.50927204922283 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark08(-15.089259623238647,34.595682327083374,25.4943821112457 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark08(1.5092908500366518,-35.690851450790454,-65.28303402467606 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark08(150.98708611094335,-107.3788665220268,238.32966831499783 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark08(151.1610012329077,-145.26642879296037,163.12182987756654 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark08(-15.168260901194575,20.321521914616262,-3.607986524997344 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark08(151.68596158926144,-141.16263875885886,157.77784585441265 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark08(151.7206346621441,-152.4831713948118,150.99473840843288 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark08(15.19851109345604,-20.836367067974297,5.380045449602345 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark08(152.10360693963887,-151.11396440640834,155.6334931135417 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark08(152.52984316946552,-106.67269098104744,244.57254472261394 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark08(-15.308086204170547,37.64171292454302,30.929963563369295 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark08(-1.5418093393835606,-0.4348308583457161,5.5888390443012375 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark08(154.39385401064436,-143.72876894122496,177.11840365325781 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark08(154.58584755818188,-160.5568697093025,143.4643801075155 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark08(154.69264340480683,-156.31881746318163,151.6196990753105 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark08(15.511209453509167,14.370162941386457,76.9327791474113 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark08(155.4074289911195,-136.6335055288176,193.82661933741974 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark08(155.89060159718318,-156.27043669709659,156.1621518603492 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark08(155.90116867919232,-156.20768546960522,156.39404347346922 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark08(-15.62757959538326,20.065283302543836,-6.657874559865379 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark08(156.39061554151502,-100.0,269.22941891056644 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark08(-156.5504566875668,155.15185029912644,-157.60814791262874 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark08(156.68677805730482,-112.77378883815936,244.5242657382607 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark08(15.742548248662871,-11.203609513205437,24.82042571957774 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark08(15.780729480607258,-28.91002238756494,-8.907102484998466 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark08(-1.5836781217539797,0.0,-4.104629692328629 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark08(-15.865835610115965,69.07095422213993,90.66775635780363 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark08(-15.915792191270818,22.16859844707157,-1.8467554474880812 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark08(-15.990525318816402,48.32194068497463,50.14517041627457 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark08(-16.076135174317244,21.88393773275802,-4.237006231645881 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark08(-16.225074014742844,40.164870997414226,31.654519950600076 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark08(162.32231468937616,-112.04253262325363,263.22903029353347 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark08(162.84444297347062,-100.1897224739276,288.36696371258535 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark08(163.1128482680317,-153.08242328401363,183.19217518629108 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark08(-16.322406947273315,-0.16513487778877473,-47.72669427060261 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark08(-16.323511083528004,0.0,-48.70343385587266 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark08(-16.34914091694706,21.823657735330194,-4.0814268210316165 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark08(16.359523810028648,-22.624133268198754,5.401101220483328 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark08(163.6519477503832,-193.37913682518902,104.73827252190704 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark08(163.69378306818388,-155.9340647023092,180.72360785690836 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark08(16.44414776462306,-24.07835285199378,1.175737589881622 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark08(-16.498356583131894,35.32237568941435,22.72047795622791 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark08(165.0705689353481,-157.80851707221868,180.5914526223935 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark08(-16.52333554867016,2.1729925934064684E-4,-48.78056336748042 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark08(165.7100151797303,-198.75390964768948,100.0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark08(-166.10148341470125,199.48520875343257,-98.98083139686509 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark08(166.28329039359255,-156.27666416139778,192.04712305285528 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark08(16.635343243210894,-56.47579346009909,-63.04555719056545 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark08(166.60710543191038,-100.0,220.9089277783254 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark08(-16.74883216582977,-24.79204046453443,-98.26000037538046 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark08(16.866884043381944,-57.61497039739548,-63.85662549665603 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark08(169.73544120854572,-157.9927641707155,194.77674726007712 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark08(169.85972937330303,-164.04228731316198,181.96372159040803 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark08(170.7616693667528,-207.37458562934333,98.89371333906507 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark08(170.78180375394754,-175.78890496176547,161.32975178215239 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark08(171.3482802553533,-174.15948956198565,166.45773515197413 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark08(1.7228909323116643,-19.474245624459183,-32.64011461857318 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark08(-1.7230450433845217,18.257062377368335,32.91578595137799 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark08(-172.54834149486004,168.7979127416824,-143.05309113837674 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark08(-17.27806558126087,8.424451531474347,-33.41449735403903 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark08(1.7328239110990058,-3.1640472894611644,0.0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark08(17.339533450720406,1.4898726957238682,56.568817778129386 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark08(-17.352885896697313,-24.728460122385208,-99.94478169667404 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark08(-17.353235926584603,13.25681038200047,-23.98674677418236 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark08(17.359075363003463,-26.168978097358767,-0.2607301057071283 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark08(-17.374402369134703,43.58139866161792,35.03959021583173 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark08(-17.394924624059218,58.18296856488485,65.75195358622244 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark08(174.12264280982566,-180.16613962774267,162.23987515356146 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark08(17.439495020784612,-74.71309824279376,-78.9341128913731 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark08(17.456408912200374,-8.336658910268957,35.88926856972532 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark08(175.21528055822856,-100.0,326.1927266298051 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark08(175.62873271084658,-214.03337987275404,100.0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark08(-17.614705563936944,-15.151941310059701,-83.14799931193022 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark08(-17.65935546103994,-37.50063019113778,-93.60209661080266 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark08(177.3135090560775,-184.57704593350388,162.83108835457858 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark08(-17.74987386767099,-26.109772346185732,-103.90786881255316 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark08(-1.7763314525107383,15.895682760544792,26.959483294142405 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark08(-17.83755738489865,42.78074612138189,32.048820088069846 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark08(17.863298835810127,-31.85583582411821,-8.550978814011145 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark08(-1.7950812696480445,39.475835326575535,73.5718514700119 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark08(179.59859102185425,-219.26001012402722,101.15437456371663 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark08(179.78361330568066,-236.04767297115168,67.2979401513326 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark08(-18.02938400386972,-20.503806371872933,-93.52496842856013 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark08(-1.808745193495048,51.821805151997765,99.78817105030528 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark08(181.4360420769286,-194.268273884569,156.7290650603843 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark08(-181.4499188918292,183.64926114528708,-176.438672198494 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark08(18.1564129179755,-0.0015501010658924088,55.81228601019675 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark08(181.85992837507064,-169.50314865468775,207.45534779287735 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark08(-1.8194887918559435,-7.486374545182034,-19.590773988786978 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark08(182.0987710899999,-195.51671505736348,156.5896828906519 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark08(-18.233699480069603,76.78051127844181,98.85992411667485 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark08(182.62530996971068,-158.24085054910128,232.5383528558085 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark08(18.265755982174607,-4.782479110464304E-4,56.041379036305045 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark08(182.8115398810483,-176.79303181043684,194.96661710024208 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark08(183.05411080130517,-196.19254432891648,157.15840955601473 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark08(-18.3440202263962,4.101126014297619,-46.736620150641166 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark08(-18.351969224345755,-17.965125933075413,-89.42752502659224 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark08(1.8372014841865603,-39.10583046626302,-72.69645716842695 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark08(-18.448356390034938,41.1414647343509,28.508656625391872 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark08(-18.465102879735802,-3.8561335496990488,-62.17261630104714 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark08(18.46863870944228,3.299955718831847,62.67405464018901 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark08(-18.553417225174027,0.052050315518774905,-54.089455348727995 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark08(186.07596880592624,-208.080140332606,147.5794492899818 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark08(-18.683321294474496,83.76336005156764,32.31408665023193 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark08(1.8697706944201962,-0.12762908050855157,2.3994510397019635 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark08(-18.708218973324886,24.833513673404592,-6.125294700079703 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark08(-18.742616805358793,-22.671472955359253,-100.0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark08(187.8784009697588,-163.22327622842064,237.6852939037529 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark08(187.94833398181316,-244.46267162734284,74.97291717527406 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark08(187.9769324411451,-186.69645902588897,192.08178941620645 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark08(18.88569933670385,-26.269465358655538,5.673146806459987 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark08(-1.8896295985026488,17.51080205936634,29.418698033692614 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark08(-1.9119716335706738,22.59137755597378,41.01763653803043 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark08(191.52579333061107,-191.2774382063297,193.1326861730196 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark08(-19.172585102362508,18.59673186283513,-19.84816780878859 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark08(191.7630845911067,-235.43512988958224,105.80465286496005 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark08(-1.923021067986558,2.8845316019798384,0.28317866725352364 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark08(-19.259500976778714,-0.3790631235428457,-57.01763278719438 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark08(19.293531977272433,-26.690078427936573,4.500439075944155 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark08(192.97676683760625,-195.16651176068297,189.62175542287696 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark08(1.9377954343692423,-8.246042033906031,2.9456252904206415 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark08(-19.404653303169717,-2.8937970953102763,-62.43075777333482 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark08(19.4612965458439,-41.42881628311014,-24.30574059405997 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark08(-19.48526804357576,26.07013255972542,-5.016836261135185 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark08(19.486526293620322,-26.34735879760736,8.093272111445525 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark08(19.524228870814365,0.001394726967943016,60.08181622514096 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark08(-19.60551071190556,12.18142999020221,-34.453672155312255 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark08(196.3556856290108,-216.06019820009362,157.85290550774621 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark08(19.64496628051696,-30.98857012043045,-1.4775641151252898 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark08(19.65055321115962,-63.37546969750048,-66.23088037598093 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark08(-196.91633359244406,241.06156980844509,-108.57635327425358 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark08(-1.9711439842275544,-99.5566439925817,-200.42236125155077 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark08(19.73271154140855,-25.842542103882828,7.513050416459995 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark08(19.752842613107546,52.059134850892434,163.80747152438016 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark08(19.842581055639318,-25.119927279112126,-2.576638183372843 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark08(-19.94328722176483,56.612093121336294,62.24821506370122 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark08(-20.07992856618072,25.529924962375144,-7.610533103484242 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark08(20.20010227789816,-9.093137466033111,43.984828228423154 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark08(202.36387086466962,-253.83498981460124,100.62441360369988 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark08(-20.25205016234064,7.541962613948243,-45.47107372850052 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark08(20.45703208719,-18.984140539430285,24.31510623789874 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark08(-20.517361766648804,31.081679987985293,2.182071002819063 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark08(20.561024929384228,-24.632629164879145,12.4178164583944 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark08(-2.0589210966652733,2.458753340121481,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark08(20.67120664087831,-48.05182947231944,-32.51924269520906 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark08(-20.779580519413486,-9.82713070319177,-80.4222066378291 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark08(2.081659692680257,33.51041408743471,74.36562223470617 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark08(-20.88121340747202,32.38013829052531,-39.74456049390362 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark08(2.0888051601438433,-1.7662133434001592,4.262401559152205 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark08(-2.0942190695698475,-68.83175737488048,-144.26514495165955 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark08(21.15354397913609,-28.45725553889249,7.60126184529442 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark08(-21.16121220251086,35.556808648190355,7.6305991788007255 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark08(21.19553495188091,2.8421709430404007E-14,63.58660485564279 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark08(21.265435095623765,-64.61642552642584,-63.92697503182223 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark08(21.302926023277493,5.630355172314863,76.7402847412571 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark08(-2.1355407494716303,19.461217158688097,1.644580333089729 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark08(-21.43047939407326,-13.63336725503222,0.05376316865740299 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark08(21.466182225146987,-6.839429969155717,51.58862593904779 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark08(-21.473902097187974,7.3016343447436745,-49.818437602076564 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark08(-21.588278986950904,26.189972441737385,-11.321818493072328 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark08(-21.629749794978387,33.805553645934864,4.292654233729455 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark08(-21.63015236507899,-11.123243346101514,-87.13694378743999 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark08(21.63401000473946,-61.102373989073826,-55.731921637134384 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark08(-21.649254061182212,46.587992989153264,28.22822379475989 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark08(-21.70372919949414,-19.67211053470628,-100.0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark08(-21.953078316344104,-9.87066766501012,-85.60057027905253 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark08(21.96008323953475,0.17876283139208643,67.80857170818308 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark08(-21.963987026412745,11.265674065589517,-43.360612280533246 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark08(-22.02866382623621,-2.739373382953977,-69.9939419178217 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark08(22.121110402502502,0.49421108247131385,83.62260427166896 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark08(22.13355613082205,-42.10582822861397,-17.962278763519553 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark08(22.18783373475316,-28.577904156188225,10.835610225429313 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark08(22.24485103449996,15.141757222634478,98.58886387556373 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark08(-22.63706300903626,2.002853120178385,-62.334804728947546 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark08(2.288343991201458,2.114235875023957,11.954810179246568 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark08(22.90287352302744,-9.766149425047832E-4,70.22739149498932 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark08(22.92285214838992,-8.458027603362529E-5,70.3391836114126 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark08(-22.952344821037038,32.88506740355371,-1.527531380796811 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark08(22.996711202037808,-32.39818370579433,4.259865610750752 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark08(23.25816526962092,-23.93960325440753,23.466085626842595 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark08(2.339898296852498,0.02572605196476591,8.63168671702709 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark08(23.459799759155704,-37.208566200003666,-2.4681962109165467 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark08(-23.48003304743512,-10.286621808939046,-89.44289406348217 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark08(23.53787132276653,-81.86432764174147,-92.68795260162257 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark08(-2355.6321657602007,-778.9378280149973,60.0857057350953 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark08(23.595026379397325,-31.33051843587504,4.594314050592892 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark08(-2360.01449999708,-720.2298533589347,41.60321183801619 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark08(-23.60713322173276,44.053060316762625,17.28472096839309 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark08(-23.607440090718363,79.03658994477185,88.8210347624532 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark08(23.712152005404633,0.8358298377690636,74.37891201854691 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark08(-23.746303898253046,43.18208743816799,15.129115755613148 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark08(23.812688903043508,-58.63327752911061,49.41238803554393 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark08(-24.17914156255166,15.129025680754324,-41.86821963947571 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark08(-2.429134688645202,-21.40510405409963,-49.99862180054507 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark08(24.414489321125117,0.13722947963616738,74.97924607691303 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark08(24.4250398406372,-5.3405640008858395,62.63027828892365 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark08(-24.488888254728934,-15.07283664647719,46.100277122760566 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark08(24.61433035912573,-14.459871988283485,44.92324710081023 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark08(-2.462301438743058,17.191112195977063,26.995320075724955 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark08(24.694509988449973,-33.378021412859795,8.683511424409822 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark08(-2.4778278420689133,52.53740553080562,97.64132753540451 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark08(24.811978478129753,1.9440761888673922E-13,74.43593543438965 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark08(-24.89363391848225,-65.61763884066632,47.4598255168377 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark08(-24.939645594489775,-19.540402877633767,90.96833012098978 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark08(-24.942385065447258,62.10979960225665,49.44702778626647 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark08(-24.991590816418594,77.91569302087638,30.798035486111104 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark08(-25.005681588816667,20.862892807379293,-30.732986724537597 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark08(25.105210411845775,-8.565477043780763,59.75547347477068 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark08(-25.144737497010148,2.0554957030195293,-69.6395483371538 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark08(-25.15178919761964,37.41872713523619,0.3085251785247987 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark08(-2.5160447513351807,3.7116871471044615,0.0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark08(-25.184705440554268,33.23134531761029,-8.046639877056034 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark08(-25.19445438424289,6.933811512705645,21.40223743655266 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark08(25.23453144486018,-18.238980255445423,40.78079681778875 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark08(-25.267372674858745,34.77657550152105,-4.678177598039961 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark08(25.29372873900482,-38.071443345988534,17.781971506185272 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark08(-25.29462738179716,53.80199745007212,32.29309421795964 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark08(25.424527345940746,-34.05253167460184,8.628004328661092 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark08(-25.43310343368887,13.61213650008991,-49.07503730088306 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark08(-25.61725997486325,8.020476142408696E-4,-76.48806816884445 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark08(-25.671811003647512,-8.828807974725407,-94.60014997080673 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark08(-25.756762728215246,-3.8848806543241485,-85.02648850171309 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark08(-25.78988926374183,40.38054398509719,3.3914201789688976 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark08(2.603430930230234,34.01256432847789,76.48134124312753 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark08(-26.059206640946414,62.39127538272715,48.17572716940995 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark08(-26.116619925022157,17.151160599131458,-42.47674225000901 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark08(26.19103283106094,-25.927962487375694,24.942608881968816 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark08(2.620415222562225,45.259895241123516,99.9432094145438 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark08(26.32285020368586,60.5645526081621,-48.87318399289327 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark08(2.633491042147569,-2.633491042147564,-3.8651912994072986E-15 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark08(26.341820222479452,-37.735714146531485,3.5540323743753968 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark08(-26.35204302074282,16.997243161506283,-45.06164273921588 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark08(26.469987305779267,-42.83992245298911,-4.699086661845529 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark08(26.475302793829556,-26.17378448447321,27.15728280219038 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark08(26.49393763131305,8.16187357399284,97.37628140336669 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark08(26.665815972423847,-65.995061444015,-51.91768203814643 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark08(-26.84900857201501,15.242425643303344,-48.49137810264345 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark08(26.879066814568503,-12.938080170994892,55.20902509267978 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark08(-26.952490058873636,31.724302775367168,-17.40886462588657 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark08(26.973002017222232,-64.7995968775046,-47.10939137654761 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark08(-27.146860587817052,2.901321821176623,-74.06714179430303 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark08(-27.274835310147875,83.30141350969895,86.34901266226905 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark08(-27.435126541233675,0.5178144452856105,-81.26921911821717 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark08(-27.46298886280371,36.26090725389814,-8.29635575381995 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark08(27.47993699515522,-34.3088480310252,6.8289110358699805 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark08(27.486410695565738,-75.4597639598148,-68.46029583293236 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark08(27.60255347874073,-36.48568079480407,9.83629884661406 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark08(-27.65037936696869,48.523028679389284,14.133189554155962 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark08(-27.68425903877856,0.21350420725018715,-81.0550923486335 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark08(-27.690477920774278,0.014588397874991704,-81.47657950604838 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark08(27.760467864793338,-72.78712809822406,-62.292852602068095 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark08(-27.837514158955692,-2.4536301449626652E-20,-82.66809762489335 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark08(-27.884440301554676,83.0092576446435,82.36519438462297 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark08(-27.973584033491996,38.509851585320156,-5.834027599858298 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark08(-28.045525932747204,-0.7565091660472358,-85.62621712417999 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark08(-28.127696344863324,37.84443784785587,-8.178073439303649 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark08(-28.148012519316776,-7.003875595135631,-96.8809924214267 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark08(-28.254422613506108,25.835013147893044,-33.09323302091437 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark08(-28.27983867001534,79.04367799057776,73.24783997110951 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark08(28.335180231546918,-49.68664900757756,-12.796960993719466 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark08(28.481870777034466,-59.486685346439764,-32.42707467719953 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark08(-28.59277284817978,65.84037812684761,35.03947674454985 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark08(-28.64304028573782,42.833097755676285,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark08(28.671624015458747,-12.050985585333883,63.27562018135773 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark08(28.69971782759288,-40.966758988042805,4.412689140964367 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark08(28.725444082032634,-18.176430857543075,49.82348649378651 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark08(-2.8843447447120902,3.9257496038890407,0.13872352451449582 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark08(2.8955585809296944,-16.964646254876676,-23.915172995687296 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark08(-29.0309936817262,100.0,106.1271155916814 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark08(29.074367979836197,-58.15353388928171,-27.513460676473063 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark08(-2.9088618406881612,-33.32297736972262,-75.29473926352247 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark08(-29.14626710809708,35.83906818594236,-14.546782752548092 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark08(-29.222931722385088,88.89621565541748,91.42066157390468 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark08(-29.323323108264077,71.5303607227699,55.09075212074758 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark08(29.396796996986424,0.3837893214243855,74.52876596057949 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark08(29.469824506156627,0.003449463768362229,88.68227618935374 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark08(-29.481722758340545,78.36186523810436,68.27856220118709 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark08(29.60167892892254,-58.915025765333255,-5.7941670582859075 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark08(29.61794881251955,-84.83972800342674,-80.82560956929483 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark08(29.715415390331877,-49.469185176423636,-8.790184486229876 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark08(29.750321722442244,-44.666459826990355,1.488841840140919 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark08(-29.81570348614422,85.07244488361383,82.26857563558988 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark08(29.845246310377284,-11.580576016630923,67.5129911030319 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark08(-30.377375641301143,0.7617698481508342,-88.04117352794813 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark08(3.0613845138736373,4.575607114452028,18.335367770524975 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark08(30.676398182427267,-79.91220918247558,-62.02788623022085 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark08(30.7085485728455,-67.39692294930259,-42.258460847617194 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark08(30.73728249918587,-76.2731434743343,4.651222915270971 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark08(30.835678840226898,-40.89853837877992,10.70995976312086 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark08(-30.87424337878293,29.143260913057958,-32.76541198343811 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark08(30.93233002347772,-61.65173282934595,-28.935679261463847 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark08(-30.966344195484496,50.32433020434777,4.625620453361558 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark08(31.24509591088961,1.1133698909230765,96.44689034642232 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark08(31.412931953085018,-14.316738539335535,67.17603112844515 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark08(31.44457717680047,-15.767043036549376,63.86940193965177 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark08(31.471252723979063,-42.498674449080355,9.456625398306434 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark08(31.510656732809085,-2.6077424243062732,90.45562295432049 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark08(31.572185439556772,-45.86510681638041,14.966662809417832 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark08(-3.166760402282498,-66.22198537995807,91.61375274991772 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark08(31.722505327099,-24.379522962680866,46.408470055935275 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark08(31.748544144806374,-94.0120500264543,-92.46068566956065 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark08(-31.806570155597537,17.378119427093445,-63.77098304577933 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark08(31.826778029071725,-35.46244589145173,25.622515062377655 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark08(-3.1913296734924006E-4,49.220747697805564,100.0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark08(-31.95866131559182,40.59084117734177,-13.124793000144587 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark08(32.00130533694605,-11.369304482450076,73.3996287346355 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark08(3.2070758157260273,-26.930509498180797,-42.66899522238862 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark08(32.16053433893134,-43.11802598204378,11.816347379501355 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark08(-3.223401251714343,0.008744184048674154,19.468328293943983 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark08(-3.2245975817723274,4.4597956989892005,2.220446049250313E-16 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark08(-32.28435663336961,22.475077976412436,-51.44317937386661 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark08(-32.40119133126526,71.38348211166598,47.13418655633108 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark08(-32.429573659447726,-39.23085839186571,-175.5445088122382 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark08(32.679833250354505,-57.75593685456066,-15.901577631262917 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark08(-32.74084327325534,40.719717981193845,-15.216679644921363 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark08(32.8328993710919,-50.77132904685281,-1.4731636536350408 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark08(-3.285481711859369,5.398821032016119,1.028283851015105 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark08(32.86575043652161,-51.68349441917415,-3.2078041991512163 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark08(-32.94579460480353,12.002220474100698,-74.8329428662092 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark08(-33.00705753149681,97.33811432890093,97.22585239010631 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark08(-33.03617263628774,17.097522999711508,-63.3426755826453 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark08(-33.24231379747758,79.0321766213755,58.337411850318276 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark08(33.30510304991826,-100.75237134415683,-100.42382391791807 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark08(33.64720892280732,-13.816920466731858,47.99571770455452 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark08(33.65567654650081,-50.77493090266474,0.6216130011127273 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark08(-33.74031898803673,95.9020589662955,92.15395729527572 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark08(-33.77714205601796,8.655536491582465,-82.8556589809356 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark08(3.3805042766598525,-48.05068810408768,-84.38906705140091 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark08(-33.81269657200405,4.6489541337107484E-4,-99.86636359839751 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark08(-33.956399943991194,28.426881471982274,-45.0145170642584 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark08(-34.20868338869714,82.13893825593478,62.13970718319476 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark08(-34.36346921592205,28.166527997128135,-45.18655532745784 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark08(-34.51184424451247,46.01605475885365,-9.93341418754628 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark08(34.609294799466326,-69.8868728606252,-35.94586132142665 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark08(-34.627342264669444,-28.577799550954026,-166.61588119639794 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark08(34.77199665845868,-50.484096785112314,4.918592731946312 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark08(-34.792720639993135,53.74164504205591,4.063853735559867 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark08(3.483396469181862,32.05887520526335,76.13873614486712 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark08(-34.894299685407525,39.17157706983761,-24.768948589752465 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark08(-35.009574308790015,35.00508384559605,-33.447758908383065 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark08(35.025706727256825,-86.23692457677738,-65.8259326449894 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark08(35.07503415718642,-100.0,-93.20410120164584 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark08(35.23251973803639,-96.39278053435835,-86.90359072915408 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark08(35.29445301096959,-48.04749789928425,3.341094134546303 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark08(35.296519358959216,-81.91595354392518,-57.942349010972706 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark08(35.39483017726685,-47.531996328408766,12.137166151141924 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark08(3.545549121488064,-0.0022925963503297453,10.938085759700783 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark08(-35.45899259409047,89.69640010604682,74.58499071520265 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark08(35.535321646983775,-47.0763409887128,12.453282963525727 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark08(-35.90373182504266,77.27905490605842,46.846936025467954 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark08(35.98346745027863,-59.46097298983119,-10.880376886876647 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark08(3.607526195567253,-14.635763425758904,-16.878151938021155 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark08(36.21044460909207,-25.409477439665295,57.827366027533444 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark08(3.624143370299176,11.56541173143742,35.076213153522914 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark08(36.252760104068535,-60.365594627059856,-11.972908941914095 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark08(36.283950005816266,-53.13215468388335,3.981871969110014 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark08(36.43651219056607,-93.58955585173396,-77.86957513176971 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark08(36.50970007517244,-49.22294405715206,11.142447655184727 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark08(36.57325428391003,-33.04617328129999,48.12901646002678 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark08(36.58156161042687,-95.14057906605724,-75.64212972463848 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark08(36.716940267129864,-54.323121588834724,1.5836777156209854 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark08(36.73442186293008,-98.27610885683742,-84.77815579808973 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark08(37.041217110718605,-16.4786151599682,78.45701697266827 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark08(-37.111985826612795,60.41118365172855,-79.68782470226965 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark08(-3.712431805772482,33.0496358048398,54.96197619236219 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark08(3.7434808191675,-13.929685467257725,-16.54996636552106 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark08(37.496587444301355,-56.48476879584889,-0.47977525879371835 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark08(3.7628995431082792,26.42295271112396,65.60427105726237 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark08(-37.74067501014998,22.17642960766772,-67.29838621596974 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark08(-37.81514895481748,33.678828984671476,-46.087788895109476 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark08(3.7960852508554224,-32.89268449347432,-53.607679799357896 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark08(-38.00374461271946,21.061057683706018,-71.88894053374102 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark08(3.8011241440000845,-26.26361590868693,-94.62577024025785 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark08(3.8066969843445477,-6.149343305807062,-0.06710313792627472 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark08(-38.069492954672626,70.07706349158846,25.94564811915905 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark08(38.14402872512801,-38.756367339381995,37.83976843361421 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark08(38.287095696273816,-67.5346319720454,-12.301108729635086 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark08(38.32346385861557,-48.97034814970385,17.029695276439007 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark08(-3.8374529819331684,39.66268192272151,69.38380122643841 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark08(38.53076449606405,-92.58382511738523,-69.57535674657828 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark08(38.60364203685768,-35.479352029258095,44.87561384348203 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark08(-38.622006167686756,51.299823678644096,-12.67781751095734 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark08(-38.727205155102645,99.69416043961131,83.2067054139147 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark08(38.756078873041616,-45.641326915358576,26.55637911520258 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark08(-3.8766570926675E-4,0.2621212112270218,36.74362672350687 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark08(-3.892346396605362,-17.3880468360075,-44.76981937413776 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark08(38.951884304375284,-42.137763005485,33.42800977866968 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark08(-39.04967893323879,15.644651991265548,-84.28893649039037 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark08(39.05467465067824,-46.427136712157356,25.880546854514314 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark08(-39.16666253007129,-11.738542881215935,-131.57699545150686 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark08(39.169978031954514,-95.3007482905471,-71.52076615843578 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark08(39.18714173690677,-52.903901646470395,13.324418244574389 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark08(39.22179021325162,-99.54388740943497,-79.85161024490188 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark08(39.48973037271876,-48.84177991922354,22.014373670972734 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark08(-39.53009911813729,60.17746284443908,3.335424661261186 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark08(-39.53301792304449,37.22344769858516,-42.58136204516824 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark08(39.568031926313836,-46.41551378713879,27.443864531458814 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark08(39.65645952679851,-89.44756109542139,-58.519454349725606 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark08(39.72872286503419,-93.87455960700788,-30.34809833764788 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark08(39.8623091818559,-77.5428900769495,-35.45460168678376 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark08(39.935241328685116,-56.92497108765032,7.5265781375495955 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark08(-39.97757228613287,-1.8402711238737948,-122.71767546232088 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark08(-40.00262938875932,16.083037042962996,-86.27101775355706 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark08(-40.04798725645004,68.61345370952674,18.653741976498225 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark08(40.25754750636207,-99.15273530306759,-77.53282808704893 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark08(4.032382272238312,-5.674524956793364,2.2654734399843464 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark08(-40.34243115829586,62.354915788024,7.6433090519956535 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark08(40.432269178338174,-61.68555199568797,-0.9868248477700835 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark08(-40.52809197953385,17.841490676768437,-84.33049825826978 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark08(40.63540304728474,-54.371132708482364,13.1639437248895 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark08(40.83106819946397,-92.01416603533295,-60.163209448886136 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark08(40.86388093119699,-79.08992683589946,-35.5610307936407 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark08(-40.879382550553984,42.95977253722127,-36.71605009875209 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark08(41.029259490930855,-92.99376843498332,-53.477431911127816 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark08(41.03152439301919,-76.72158578872592,-30.348568477690492 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark08(-41.071048861559355,85.13014247816452,48.617889664293735 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark08(41.099873404929966,-53.02318710414828,18.09258151288799 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark08(41.17193230053359,-47.771232518952694,14.724116756510847 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark08(4.118185676665157,38.53305114092981,90.99145563864998 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark08(4.118777785363121,-36.945962474132585,-61.53554681332439 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark08(-41.18812793413821,25.555399520769903,-72.45358476087478 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark08(-41.213721845886255,-10.890171901045512,-105.27751856207638 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark08(-41.2855078498484,70.8321637349946,-56.40392342396698 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark08(-41.3769598836993,44.82550512375198,-32.90914130862467 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark08(-41.48437325153038,48.526637878317985,-11.184281636353257 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark08(4.159143510853707,-68.43539330665104,7.367577254207106 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark08(-41.80311941103505,79.64602254712301,35.45348318793576 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark08(-41.813387416462945,27.26296935707153,-70.91422353524575 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark08(41.82773043820313,-26.722353408120142,73.609280825164 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark08(41.84193012969589,-14.504915319883851,96.51595974931998 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark08(4.187477088934819,-8.483081117870652,-3.558377605046145 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark08(41.89521963087291,-90.95879698248432,-54.66094652504366 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark08(-42.00153649674512,91.07833985566334,57.72286654788611 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark08(-42.06862159477298,29.69237875580655,-66.82110727220353 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark08(-42.15852668148656,72.08658106641944,19.078084858088392 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark08(42.17057354913219,-77.3528903331042,-28.194060018811808 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark08(42.17558091989787,-89.68644432202362,-51.27534955755874 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark08(-42.27264094150719,49.82107346472291,-27.17373874707488 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark08(-42.28760337894446,-5.6069827609648115,-61.07684833213545 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark08(42.38411701513114,-44.5504036087248,38.88383272419148 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark08(42.51070321460041,-90.05638979887595,-54.5252352749005 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark08(42.52392500564964,-20.661055080142834,87.82046118345814 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark08(42.56805052682255,-74.8429567866355,-21.158027678863196 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark08(-42.68639270574658,63.245071717282805,0.0017616157327080577 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark08(42.696209728332775,-19.700675315320478,90.2580748811522 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark08(-42.928886525594564,-64.40019196993087,-15.090799450944132 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark08(-43.05042153791023,35.11698531883375,-58.91183155461802 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark08(-43.1515119227879,16.749377279502554,-94.3849848825637 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark08(43.36088537019057,-35.2244078880956,59.6442519796321 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark08(-43.57787825853004,50.88072436052873,-28.972186054532635 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark08(43.852208988248954,-38.07463968484013,55.41251497863209 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark08(43.98924998565051,-86.92630846070068,-40.62678514652178 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark08(-44.11891194241423,59.07650811141674,-4.534248390738494 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark08(44.12975587041571,-100.0187853434469,-67.6330052769342 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark08(-44.13390384240773,10.603752904018473,-100.0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark08(4.417020185151374,10.7154574862064,36.252771854661816 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark08(-4.4224604124599553E-4,-42.17965041760297,-84.20792134060018 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark08(-44.41420626923208,20.0642001855576,-93.11421843658104 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark08(-44.4449651345837,65.88555883628958,1.1966460199307407E-4 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark08(4.4474285880179725,-7.365992542867405,0.015263056625154463 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark08(-44.6593416029763,66.3190722995816,0.23091611702920556 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark08(-44.811197790611935,46.49742221859665,-39.86795260784763 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark08(-45.05420452111446,-8.789468823139627,-156.74146698477352 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark08(4.511200905318589,33.065125372698034,80.15818149972853 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark08(-45.17299037474203,39.644474547932774,-0.754669480373979 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark08(-45.3104187800649,-4.43390130367483,-144.02462092606072 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark08(-45.435721244773404,87.85782810378156,39.40849247324292 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark08(45.65002325579668,-50.29842859409023,37.51426161486172 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark08(45.68148844353512,-88.77918535492473,30.529370298022496 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark08(-4.5916195866590635E-4,40.96865364581327,83.5030397378272 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark08(45.9254387825056,-61.168624650863855,15.439067045789091 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark08(-46.178217676448504,98.60603358565488,58.8011603512935 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark08(46.357710223720915,-64.82285639152508,10.99821421490747 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark08(-46.410688308127895,62.60869669879356,-14.009588030543915 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark08(-46.451627615251724,12.895349546808333,-43.67660352128906 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark08(46.46868005893959,-58.69962296566277,22.00679424555172 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark08(46.887767516615504,-97.64723446236903,-53.06037004809666 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark08(4.706858996274581,-14.39919184187737,-13.869619646616968 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark08(-47.24063539145276,38.880187601013006,-63.62584919187131 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark08(47.2819737231286,-64.56829154216678,13.342101789638512 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark08(-47.30624005706186,30.055788724343582,-80.66798459013953 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark08(-47.31977523602296,34.46565096765778,-71.45722744595844 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark08(47.3976962283848,-59.86471397057789,22.463660743998638 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark08(-47.41377482740262,91.90823023106012,-64.29906564794142 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark08(-47.46609613302915,69.93385416670749,-1.0569277151584517 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark08(-47.51458194729987,63.17948823301843,-15.66490628571857 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark08(47.78342154992165,-70.93646021962792,1.4773442105091157 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark08(47.80189796360804,-63.94507695293906,17.086336311740894 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark08(-47.80227318842147,45.62166468884737,-52.06674169683108 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark08(47.83169008124304,-65.78080970125653,50.91538296723587 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark08(-47.93782968943321,37.01338209162003,-9.532749077804574 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark08(48.07523024423057,-120.69240433795298,-81.8456852705732 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark08(4.82005511557983,26.040271201511157,68.10000703899507 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark08(-48.23774192676302,101.05625372992453,60.26895684144785 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark08(48.25418222129369,-27.95809138356988,90.4171602235362 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark08(4.829182169932482,21.242628502102725,58.54359984079779 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark08(48.33518929468587,-64.81376604466334,16.478576749977453 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark08(48.528314441213695,87.36622092213887,89.5338248686779 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark08(4.857547329894625,-15.746373764681023,-16.91463130378795 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark08(-48.678376881060586,59.41021506483327,-27.139843133070837 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark08(-48.726570918918114,92.01164424240224,39.41437205484502 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark08(48.77011429331524,-65.92207911850257,15.581168498392431 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark08(-48.85793169380959,56.08588662624277,-34.34435124104891 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark08(-48.94637661826508,28.07250514463348,-89.12418284486901 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark08(-4.898681021142589,6.170953377366898,-1.0913377684606287 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark08(49.013786006895884,-0.2261135539070694,137.3405580614037 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark08(49.10650134293784,-67.64104301424098,12.037418000331574 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark08(-4.917522955291638,48.36591181993407,83.55005110078812 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark08(49.50779342743671,-93.49037070919653,-36.886564809288046 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark08(49.6124378506487,-48.29284687433762,53.822416130065754 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark08(-49.64365973102971,6.810301853976751E-5,-147.88831546610604 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark08(-49.805457968898395,43.01790415991684,98.4890202802091 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark08(-4.987133347613096,37.12455592858576,60.85850814112702 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark08(49.960677794747156,-99.99999999999886,-48.547197662234055 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark08(50.37603094014113,-71.47544900908967,12.69384671825878 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark08(50.487201270614975,-75.19201326812046,2.648373602398893 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark08(50.71214717288467,-67.66921290961292,17.081825999339873 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark08(50.77053435160657,-37.85339802459806,78.17560333241849 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark08(50.77964267548469,-80.10220635530294,-6.294688357356939 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark08(50.97021154989847,-67.33643095787777,19.808569060734786 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark08(-51.111672361451035,86.11159822737247,20.458975697186702 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark08(-51.27396431324425,31.22377072265719,-91.08785780553414 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark08(-51.4483156219533,46.42277650176491,-61.49939386233007 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark08(5.154003792718001,-51.00414579918155,-84.97548389341421 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark08(51.69339950996139,-38.53094059551374,78.29789196717395 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark08(51.694625079862476,-16.5318027605437,123.17412947437273 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark08(-51.76977227566888,72.23740269180783,-10.834511443390948 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark08(51.782824352511255,-98.82555263854135,-42.275403006971146 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark08(51.88780407413568,-85.80020012512395,-14.758497555612731 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark08(5.19925824309459,-95.19274214706586,17.096932069072096 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark08(-52.10031572913223,76.69861097487484,-2.903725237646357 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark08(52.12588564313527,-74.73720177642159,7.340409353111985 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark08(-52.16580595896738,-82.83013309809739,25.286134828800513 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark08(5.228014824355746,1.5676769268247668,20.149373253647553 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark08(52.59502508810228,-49.76798566418079,45.48483386313344 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark08(-5.270153693785121,36.41156972443537,57.013220220287735 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark08(-52.84167148268628,67.86406985963679,-22.682923248312918 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark08(-53.233842798430366,64.16866845435705,-29.81388328550349 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark08(-5.324304707661157,-41.61008790523005,-97.62229360664868 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark08(-5.324644561644424,31.153362910328767,46.55436125396457 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark08(-53.26843583358563,66.66802920125582,-19.763106003949634 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark08(53.418676045596555,-43.54685718241331,-78.52048233557778 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark08(5.353214372606954,-0.016819408644861034,16.086859358984803 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark08(-53.93160670256438,20.877393657032343,82.56730181371213 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark08(5.3987998874569385,-16.650295481699047,-17.104191301027257 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark08(-5.407367431280193,33.65986720435588,51.444852200946045 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark08(-54.07685644557615,94.307280206697,26.38399107666557 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark08(-5.436378904865322,17.107104936592236,-84.24753430111747 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark08(-54.603800074290575,81.75061932025297,0.002467133431487249 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark08(55.34844523730749,-65.12437420679834,35.7965872983258 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark08(-55.41614670137639,56.056003113811855,-54.13643387650544 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark08(5.5471245345341424,-6.898470418272679,2.8444327670570706 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark08(-55.547719269511546,98.27300556210591,30.532000169955577 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark08(55.55972359904563,-100.0,-40.8391420516715 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark08(55.6158577193915,-61.5042857063431,13.201965220451541 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark08(-55.66498526693812,35.342091793054934,-99.99976742968211 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark08(-55.74040807502435,35.445389817044486,-96.33044459098406 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark08(5.596906929875765,-0.011346824863345036,17.772246859158088 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark08(-56.01655291311312,40.6970779295018,-86.65550288033573 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark08(-56.04400206959611,51.36221608104564,-65.40757404669694 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark08(56.143799725283316,-44.2331103105551,80.28099275961964 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark08(-56.25629795847273,93.66739173640245,19.234246493025747 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark08(-56.275252094137215,2.961912176535738,-167.8017632017699 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark08(-56.45313584955682,82.84678313419752,-3.665841280275414 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark08(-56.537446265183,63.23631108582888,-42.71261379393988 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark08(5.662282958720869,-9.956200790725084,-5.489222793881366 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark08(-56.89524620028501,43.277851264111575,0.7901319693100533 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark08(56.90062203784646,-70.83270891620703,29.036448281125335 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark08(57.04906660675795,37.50079116025182,-22.670981680586806 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark08(5.716101665548663,19.435906395224496,57.59091411388987 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark08(-57.35407658816274,60.16327497880869,-78.1702735449879 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark08(57.526748326264936,-68.34113154409961,19.15335135763418 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark08(-5.756573489741083,-7.41829671583252,6.044182691324438 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark08(-57.81943562579901,127.38343394558578,81.67221106542374 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark08(-58.17972891702023,58.33769260411852,-57.334872197916866 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark08(58.238017448791936,-71.79756255962971,31.118927227116416 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark08(58.360574246912535,-83.26270515240853,8.643334252351979 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark08(-58.4873100994233,67.37547119269605,-40.71098791287777 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark08(58.50457103013425,-78.14446899326313,19.224775103876496 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark08(-58.86188213663309,100.0,24.98514991689561 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark08(5.89278112119774,13.475191460161389,45.03467681723162 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark08(-5.914436618519811,-5.7898034769515565,-27.75224027201252 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark08(-59.352242677119065,50.39835489487012,-75.68953475014725 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark08(59.456117797062255,-91.38481047933068,-2.8816166051771637 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark08(-59.6269011821615,79.15687812968751,-18.99615096031472 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark08(59.72685387038878,-91.55269123674387,44.869728302499325 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark08(5.979570170422234,-42.493968222123804,-65.47842960618601 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark08(60.031883364136405,-61.61378880891113,56.86807247458697 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark08(-6.00674992441833,-15.553232892459715,-49.12585190512041 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark08(60.23252736145633,-73.72340006081434,34.82157828953518 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark08(-60.24271460607384,62.15298960055016,-56.42204675368984 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark08(-6.066568213273347,10.787529016463274,3.384540931476701 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark08(-60.75101707825817,73.65863600452415,-34.54158924590886 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark08(-60.93405742251338,87.8976884752914,-6.52732995569103 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark08(61.03057793152051,-90.2036441729105,16.47955268078087 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark08(-61.111078809906545,46.07326760718135,-89.61590488862596 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark08(61.143097600078846,-42.500044563515715,100.0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark08(-6.126355418513013,7.688433953548313,-1.5620785350353006 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark08(-61.42671046468692,-17.598993367017698,-141.95957854418077 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark08(-6.159254562960179,54.80448654526653,92.7020057284474 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark08(62.12425367254525,38.24403926724568,11.862869080681477 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark08(-62.24436622672358,61.962917416616875,-61.2364675201421 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark08(-62.27633211871895,65.85874015301783,-54.7975102134354 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark08(-62.28574462984815,23.272177542701726,-82.39238904323147 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark08(62.426336477050484,-20.365020675375046,135.0094486751337 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark08(62.57873288591168,-65.51912720061917,58.26874058329159 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark08(-62.60093920104226,-30.109567149537266,13.917437022788103 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark08(-6.278675293242825,49.01251465617239,80.75979975941121 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark08(-63.08187132843695,-45.16741584516324,25.935911152685094 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark08(63.09616122454788,-63.86376486167723,61.58625198933666 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark08(6.309774711818034,-12.80016058155388,-6.575494372614116 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark08(6.314594217704317,-45.61587870604123,-70.71717843217462 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark08(63.18100920759684,-65.84601823637762,57.850991150035284 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark08(63.46232681417226,-66.8223124961327,7.126312787208574 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark08(63.5959224516275,-93.98212378238392,4.3943161169095495 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark08(63.77974164003739,-84.70396446001338,21.93208248855638 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark08(-63.87416096139469,76.2564016223312,-39.10967963952166 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark08(64.30594866005313,-86.20770988765703,22.07322253164021 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark08(64.38802589007534,88.8912112151221,69.13819630614273 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark08(6.448520039399,-43.641093715553254,-66.36583098611462 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark08(64.64071986079887,-86.01042703546,22.189698281177876 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark08(64.84127367160536,-62.30531042133778,75.82484095336358 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark08(64.99053031862545,-91.59614275210832,13.350101778454585 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark08(-65.06737804238206,83.18510517706518,-27.261951004960572 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark08(65.27077076022992,-61.73200026709826,73.91908895307458 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark08(65.33537681246554,-98.39295381925962,0.7910191256722499 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark08(-65.58600555080108,60.90307222034227,-74.95187221171828 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark08(65.63056329064082,-48.44584493596124,100.0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark08(6.582296788587392,-43.299801581439795,-65.39863035556105 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark08(-6.58686151776992,-68.43947771399954,-151.3257389003812 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark08(66.20545245006734,-88.3885453548058,23.120263099653645 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark08(66.3771900079607,-100.0,0.6898260218695569 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark08(66.5266494535763,-100.0,1.1507446875237797 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark08(66.66456815801185,-99.26509125430998,3.034318292210469 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark08(-66.83213573439784,153.4957111496331,62.288445504316364 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark08(66.95297435849973,-96.80040531219473,8.828908777904633 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark08(6.69683193324761,-46.62297947469683,-71.58546207372322 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark08(-67.09853866015655,-49.176526759540074,-45.484335414264066 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark08(67.5001498665248,-42.56029755407062,64.44233447432995 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark08(-6.784502300781988E-21,72.91009770543734,146.48716974479242 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark08(6.811384383467523,-33.11370132686132,-44.630519037454015 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark08(68.21172119142993,-80.58507244833561,43.46501867761857 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark08(-6.826366324189977,23.17058310750813,32.97097372615494 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark08(-68.37579653169811,77.09169353096115,-49.37320620637716 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark08(-68.66672630875543,81.66224536991021,-42.59915795954543 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark08(-6.903240118286884,-1.7763568394002505E-15,-20.709916909648452 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark08(69.05392661541664,-79.76416067345846,49.204254826127894 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark08(-69.19225829940147,85.49856144128006,-35.17952264304206 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark08(6.960941512063936,-10.61817494167747,1.2028388123675466 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark08(6.962305987106234,0.12024385037864274,22.03244837167567 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark08(-69.87660786606189,90.96860178336982,-27.69262003144601 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark08(-69.89167079910575,75.55386873689899,-58.61037671733332 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark08(-7.005386884172526,2.3254157683342065,-16.354455091980235 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark08(70.09622330873957,-97.04116881504875,16.992502819497442 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark08(70.117953157577,-74.99088198261103,61.94289183430385 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark08(70.17503610936005,-69.03585648863302,66.91148389009462 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark08(-70.44147395713827,-39.57518598194112,-3.788966235417874 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark08(-70.82766281006705,66.51631408762331,-77.87956392815964 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark08(7.101996967505965,0.8624868872315298,24.451442682000668 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark08(71.43814087871652,-26.12624259206207,56.73213321316905 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark08(71.54679700529991,-73.09514716057885,68.45009669474206 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark08(-71.55894162395006,69.73349567773619,-75.19981069506944 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark08(-7.158069017732201,34.01334793613521,49.04289335832818 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark08(-71.6211970917509,87.77296320394233,-37.74686854057316 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark08(-71.72553247414285,-37.7720088282197,19.946181025876356 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark08(7.2264498224559865,-13.08967707916059,-2.929208364158324 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark08(-72.35982334343363,30.357541730064696,-140.27404809960825 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark08(72.5193262301626,-96.6614270008265,24.2351246888348 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark08(-72.55317906380625,115.64115752446403,100.0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark08(72.74557014894,-81.99151099425448,54.244377488867634 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark08(-72.88279194445757,82.42885160662574,-53.790665798104314 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark08(-73.00932669555509,97.33957545460062,-24.330248759045524 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark08(7.303429838350274,33.92501685284801,91.33111954754173 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark08(-73.03587285575087,61.83367899138602,-93.86946425768565 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark08(73.27479415826429,-70.23828954652234,79.34780338174821 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark08(-73.33480247797578,96.53619195044917,-25.361227206234137 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark08(73.44454147884923,-34.35389790109173,-10.885098418590204 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark08(73.44509640138958,-79.72522100652922,-0.003185705376148999 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark08(-73.9669917514095,70.80273593771155,-80.47709646268912 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark08(-7.406603362374076,-12.38852922150087,-46.22158368543865 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark08(-7.428560015650815E-4,32.23361264509511,65.60036533291097 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark08(-74.42174272567154,98.72279403648493,-24.301051310813385 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark08(7.472548511241624,-9.496620438135107,3.424404657454659 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark08(74.80737080079264,-67.04841139628824,90.32528960980146 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark08(-74.97693357184822,89.53076848772966,0.6650652653002851 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark08(7.515224174561765E-6,-5.288755330035655,-9.534416859955417 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark08(-75.82209401438422,-40.631326713540304,63.8374226349878 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark08(-7.59601967828813,21.23523280003811,21.250887468970177 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark08(-75.9666840810689,82.19204147017089,-4.816543866815181 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark08(76.13681942096667,-92.93309446650146,1.6443645684034465 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark08(76.19016689764355,-71.40920233110285,87.32219978322924 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark08(-76.67699763879119,93.70124686221784,-41.05770286514301 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark08(76.80276248742388,-25.90448137561856,17.18895584734004 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark08(7.707778682630927,32.50225021655743,89.69863280780253 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark08(-77.15272530420765,56.51132919343371,-53.7899777000455 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark08(77.38920695276056,-76.14887850769196,81.44066016969265 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark08(-77.7036393556944,92.09436284756053,-47.35139604516726 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark08(77.77492805859865,-80.07198470967928,74.74962100826372 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark08(-77.86099483165171,70.29460517802357,-91.42297781211309 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark08(7.796283996969549,7.432219797281949E-13,23.388851990910137 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark08(-77.99241134861343,233.17854117981003,233.92372998348446 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark08(-7.833696446867439,-75.02957408721336,-175.22613184247786 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark08(7.839491880131875,-10.043923019461642,3.4306296014723414 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark08(-78.73949967939222,-26.297294947509613,-9.151178066795154 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark08(7.890672865657372,37.37859253811651,100.0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark08(-78.97968218818508,67.68791167978286,-99.99999999999999 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark08(7.930085739534075,20.795246429088394,65.82812271651346 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark08(79.51055215827499,-70.01673337418747,98.49818972645006 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark08(80.04969888963743,-82.79747591211198,75.3550542589436 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark08(-80.34823449359934,100.0,-40.475404541549295 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark08(-8.040791942182587E-4,31.15827287631532,62.69713211355794 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark08(-80.48345977622337,68.57683917303137,-86.76305356413226 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark08(-80.91724084163737,-38.86098765237769,-98.91840076125393 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark08(-81.4859096596242,88.29716312144944,-67.86340273597368 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark08(-81.76957700554036,86.63983812877751,0.27133153046071357 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark08(82.05580316772613,-76.92614059568727,93.88592463859757 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark08(8.214931361888533,0.0918475740418262,25.955484880207205 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark08(-82.18709426704046,100.0,-44.990486474330254 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark08(-82.27887083330879,218.0836988844982,190.65563048563857 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark08(-82.48541485491602,100.0,-46.7007283114027 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark08(-82.65819123655348,79.44948201320284,-87.50481335645986 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark08(8.278927253905735,-16.440781199414914,-8.044780637112622 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark08(-82.81686723891755,-63.59397684628352,-68.21038091466835 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark08(-8.288332559303328,41.71750652866385,59.04286342602564 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark08(-83.59938640150557,73.77740032337988,86.4661190053757 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark08(83.75011912636116,-97.66694807084767,55.91646123738869 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark08(-8.418373686283436,23.04665028652024,22.402341589696796 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark08(-84.27967489808985,-26.863744428296485,99.73673559805533 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark08(84.46502327039698,-82.20371381773225,88.98764217572646 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark08(-84.5785973418366,-98.37880274177657,-74.41577830014319 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark08(-8.46946989066314,10.768978985677379,-3.870305421809136 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark08(84.74935120388415,-83.3953464799454,87.4573774770557 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark08(-85.33124922473621,84.36935721815847,-87.25503323789168 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark08(-85.66698187215962,98.50424667697948,8.318768406379107 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark08(-85.74134182080472,91.80027214703357,-77.15304997740255 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark08(8.592144118401125,-63.67359904971352,-99.99998411365631 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark08(-8.60686875515224,8.088765550156467,-8.285063332643533 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark08(86.119136049648,-94.82883590726561,64.27133529257111 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark08(8.668533028520027E-4,-30.4963102033689,-59.41922352003435 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark08(87.0672069404676,-99.87861175154241,61.63181325664751 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark08(-87.33299621408828,89.27617228011518,-81.8758477552397 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark08(8.734896746701162,-12.139910768303034,3.4956650302923133 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark08(8.761560143045772,-19.05578610408095,33.52232580019384 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark08(-87.65769423960681,32.13468847224516,26.58487957585787 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark08(88.07832037083247,-228.32660266727663,-189.04180167885244 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark08(-88.28652146945623,4.416166325158372,-6.688684153905129 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark08(8.832410117299183,-9.654830715406499,7.187568921084553 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark08(8.844145296171657,-4.06566706055301,19.971898094203844 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark08(-88.80784444737071,99.72172147584924,-65.40929406361877 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark08(8.881784197001252E-16,-47.10758841567149,-92.70104266640875 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark08(-8.934417007060645,4.1683603822968855,-16.89573392979327 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark08(8.945946562342058,-11.2590468046187,4.319746077788776 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark08(-90.23889372224325,55.8795172412523,-3.1783928904470145 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark08(90.25408681518198,64.79216731463168,93.60587005578353 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark08(90.31430703951665,-92.32976953728893,87.854178370767 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark08(90.41587426036597,-100.0,71.91346523633108 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark08(-9.093212585612202,21.23137275263708,15.183107748437552 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark08(-9.137439895886077,50.94880597701929,74.48585177872259 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark08(9.172642794399039,-61.23924459171387,-93.39057028273605 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark08(-92.16456378707466,99.82905339491853,-97.35104913738495 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark08(-9.23489564864542,8.103961977310487,-11.494284254497614 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark08(92.64610939937661,-124.941968846999,35.563537514638234 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark08(93.08279588162952,-100.0,79.26394687548073 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark08(-93.35807047282944,-14.903175418182315,88.34774435141071 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark08(93.52285848365983,-100.0,79.70439177908368 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark08(-93.75602259237772,-3.7533922434178284,-49.797261975191915 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark08(9.377344521561938,-13.161453982110373,3.3799219272599523 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark08(93.98843289083824,-220.53035389857345,-159.0195059578033 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark08(-9.414276870309386,4.7032346479725735,-18.836361314970038 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark08(9.45574168507463,-7.104487095498374,14.947941627889907 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark08(-94.64431206017767,100.0,-83.61970152821675 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark08(94.99445806175257,-20.92860749250056,92.82131306893845 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark08(-95.22855569834398,98.91120531281052,-87.86316907576605 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark08(9.540480177316516,24.684792217545183,78.87235645481904 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark08(96.30750728207492,-219.76846794470794,-149.91986413754182 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark08(-9.633878362541322,-8.81637629431577,-45.95239474175617 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark08(9.647028091516447,-12.621654339047252,3.6977755964548376 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark08(-96.73983308392859,99.79283844504485,-89.34798536047357 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark08(-97.0676740445585,100.0,-91.20302213367549 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark08(-97.15554722343893,46.1411701842768,-64.23960912807146 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark08(97.41042503465144,-97.05718192905677,99.68770757263567 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark08(-97.59903990217386,97.17255747778192,-98.45189364638844 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark08(-9.776492258699047,18.324024815267617,7.318572854438095 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark08(98.92762306676941,-99.48521421666332,99.3832370937765 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark08(-99.06697667534098,83.67718598131854,22.033956854759584 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark08(99.38533182898469,-100.0,99.67383413462873 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark08(99.68808216834982,-100.0,100.0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark08(9.970050186614877,-31.84514681706917,-32.20934674749884 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark08(-99.77630978741915,99.17358379145156,-99.41096545255942 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark08(99.78474626620905,-72.6254400118545,154.61457836985684 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark08(99.86038612004916,-100.28062772694611,100.57412018809542 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark08(-99.87619868523434,80.10430079515655,-6.058260826048084 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark08(99.88861708583445,-100.0,100.0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark08(-99.93402222924553,100.0,-98.23127036094243 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark08(-99.99804287775196,100.0,-98.60052807083923 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark08(-99.99992141369991,105.95973461440792,-87.84148905251735 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark08(99.9999380721413,-100.0,92.16998730624219 ) ;
  }
}
