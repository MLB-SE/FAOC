import org.junit.Test;

public class Sample78Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,0.0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-11.131472489372896,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-1.1222063866923024E-190,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-11.70494916222438,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-16.354571570176518,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-1.9963327466403075E-8,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-20.48696798613247,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-20.507457425645896,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-21.551740427302548,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-22.074023984047273,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-2629.0611516721438,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-2641.5471134291806,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-3.127292608659843,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-38.68220327733647,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-40.82039761173755,0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-42.33859671772435,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-4.23572119809792,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-43.324135692719665,0,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,4.440892098500626E-16,0,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,49.789600393289874,0,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-50.59883629684989,0,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0.5205593862922553,7.418405457368705E-15,0,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,5.329070518200751E-15,0,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-5.506276954761489,0,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-64.07244009513681,0,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-64.36388658902683,0,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-6.445073614096188,0,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-6.47582E-319,0,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-74.32706131376756,0,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-74.52496839391327,0,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-8.001326062714725,0,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-85.97238537633574,0,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-89.99999999999993,0,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-89.99999999999999,0,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-90.0,0,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-90.9892985768832,0,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-91.54212350075994,0,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,100.0,-3.5083546492674388E-15,0,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-100.0,-5.6843418860808015E-14,0,0,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,10.945238791960833,-4.65500127901683,0,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-1.3872518348796206,0,0,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-1.7763568394002505E-15,-32.704207522666835,0,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,21.278201786702013,-9.445003371731644,0,0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-22.90799282991678,-77.80031722664287,0,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-23.800208799293586,-0.02554766203242309,0,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-24.308401589582555,-32.70369929006348,0,0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,24.55347214215219,-1.2017043869937492,0,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-29.228282598894737,-32.68968021132284,0,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-30.597444152526563,-4.263256414560601E-14,0,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,30.78190628673491,-73.4201389799429,0,0,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-33.40367502367985,-66.77003847252037,0,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,33.40749321323341,27.665157076924956,0,0,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-34.23635588201438,-14.02290106419333,0,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-36.374879372136576,-6.900491890197529,0,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,37.68009638595257,-9.239280769122502,0,0,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-43.231739185599636,-32.69397880212669,0,0,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,46.0201158921208,-32.70409058250876,0,0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-49.378134597965875,-18.56143195883348,0,0,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-50.3216349368118,-1.9327722995840984,0,0,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-50.7979055426105,0,0,0,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,5.083667962068034,-0.5278719636816191,0,0,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-52.815069730703215,-32.691489468398295,0,0,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,5.858371434719532E-9,0,0,0,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-59.43305332379181,-32.6898206476202,0,0,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-61.19764596464424,-4.535631336962522E-15,0,0,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,63.319768528029186,-25.44907893268109,0,0,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-6.3659380337833305E-37,0,0,0,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-6.484020341313512E-38,0,0,0,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-65.60070464529096,-6.761722965368961,0,0,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,66.08013596584013,-6.891411780467626,0,0,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-66.66560773038296,-5.209447117823419,0,0,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-72.31023571999475,-4.190571772504995,0,0,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,74.97871522380132,-3.552713678800501E-15,0,0,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,75.13341240467446,0,0,0,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,77.89745195786595,-17.75222793577127,0,0,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,8.70587740497696E-9,0,0,0,0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,87.20017608017648,-46.72995082615095,0,0,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-90.49440506654203,-17.259966868971247,0,0,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,9.271899572176057E-5,0,0,0,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,95.713485728151,-3.5083546492674388E-15,0,0,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,97.2358803033637,-9.545315286988657,0,0,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,9.774659066521534E-9,0,0,0,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,99.99999999999889,7.227418711324843E-15,0,0,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-99.99999999999964,-3.50835464926744E-15,0,0,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark78(100.0,-100.0,-100.0,99.99999999999979,-23.007326868386755,0,0,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark78(100.01365642334893,84.94086484082717,100.0,100.0,-4.178761524337986,0,0,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark78(1.0025783374603464E-8,0,0,100.0,-3.623767952376511E-13,0,0,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark78(12.831457461099262,32.63335827368056,91.02229885440914,-14.548921058229709,-31.520839078093243,0,0,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark78(16.63264802428686,78.55995303338693,100.0,-95.77457333610283,-12.098377094091836,0,0,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark78(-18.3384750672469,92.83361177111732,92.83361177111733,18.48867871025452,-30.59238260670293,0,0,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark78(18.37656771362417,0,0,70.67514722441524,-7.309329166440335,0,0,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark78(-2.270384252972868,28.574888423155542,28.574888423155546,-43.20386731439365,-5.544290253933559,0,0,0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark78(2.711661822211626E-13,3.1756550215325188,3.1756550215325205,100.0,-30.749466422724623,0,0,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark78(28.22697172405571,-1383.2481047954136,1093.5019489785475,-76.36358640132013,-25.06077422770897,0,0,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark78(29.267941861136336,30.894137704703923,-97.32253145869669,29.74681468190701,25.524676758896717,0,0,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark78(-29.499052643174295,-61.092329717016284,95.22318125268791,79.60947982861865,-29.827057893068613,0,0,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark78(-3.3266769207908013E-29,0,0,87.56063713122448,-13.926930184663185,0,0,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark78(35.76106478601284,96.06168199247952,40.35691696432838,-83.66845247527881,50.07405323553155,0,0,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark78(-3.630803987769959E-25,0,0,-12.827513091691422,-1.9209127728916116,0,0,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark78(4.0718666780388266E-29,0,0,-33.229370470652015,-6.185335721649324,0,0,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark78(42.100920459770464,-99.23961451982554,-99.23961451982551,-50.00391384451008,-10.617097943386796,0,0,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark78(-47.35704785742452,0,0,76.70703552126878,-32.45902579369786,0,0,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark78(-54.204470096051786,-23.301537633255805,101.5773635068384,62.071280964733035,-0.4549148536139995,0,0,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark78(-54.59521503383511,-1.8502191362492368,94.30508550026755,-92.51367484077606,-4.263256414560601E-14,0,0,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark78(5.551085655315972E-9,0,0,-100.0,-13.201879617364554,0,0,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark78(57.568791390359706,17.02593663041567,55.407941156400284,-94.93449850592471,-11.161445186918868,0,0,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark78(67.76359706216329,17.117900301074144,38.39322834719361,-78.22053307743792,-29.668304154202147,0,0,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark78(68.19908035752422,-1176.0267187520717,1234.3322910962468,-2.8153384780828645,-0.3425775680674431,0,0,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark78(-7.556205088139019E-5,0,0,-4.404789386084495,-8.854319087973423,0,0,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark78(-7.702721643432916,10.0,100.0,-29.28592732399909,-12.937608989138113,0,0,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark78(-82.48562726379956,0,0,60.27798801767071,-26.682418373099566,0,0,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark78(89.71782950968772,-61.62295838096223,32.59194479549894,19.563378235438854,-5.321999915502968,0,0,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark78(92.04204786709452,-32.257978043667805,2.0488834325512855,80.10820652468136,-3.7053054881507705,0,0,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark78(95.99338677048323,72.81701103865771,-62.8114052421856,-72.24924716352314,-1.1997342816524537,0,0,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark78(-99.19372736292877,0,0,58.22478259196646,-11.849739649336641,0,0,0 ) ;
  }
}
