import org.junit.Test;

public class Sample32Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark32(18.88450835822691 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark32(24.999999999999996 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark32(70.28617096551685 ) ;
  }
}
