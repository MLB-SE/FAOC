import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(-0.5837591045326085,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(-1.0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(-1.0000000000000004,-0.23495566530436857,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark15(-1.0000000000000142,-1.570796326794816,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.0010155310884901588,0.0,0.3304779832535277 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.0019331212436580411,0.0,84.70061819449998 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.001959231983756334,-1.0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.0026298406388252744,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.002629840638914615,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.00444702032665409,0.0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.007419380800005255,-36.08793302561769,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.009951271373721829,0.0,-84.00241899272076 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.013145226606914818,-0.010525731323133641,-100.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.01555001237786365,0.0,0.873589343843663 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.027230176667998762,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.040924009177547876,-0.6189177016521313,0.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.04339513261043079,0.0,-97.71374741257404 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.1609571655933336,-0.7987143616672805,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark15(-1.000040548460327,14.430570512086433,0.0,0.0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-1.5707963267948775,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-5.246615143460146E-4,0.0,0.01197396617446922 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,6.429209034568047,0.0,-100.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,6.591390488021109,0.0,7.95492984340642 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-8.615215855661551E-4,-0.31612463280611497,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark15(-100.8033715192012,-0.2455844218046429,0.0,-2066.9666975451055 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark15(-10.361120849706614,-0.004488012249009474,-1.0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark15(-10.719530145223374,-0.02570547976047772,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark15(-10.838947097841633,14.429358707711202,-4.440892098500626E-16,95.041683622199 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark15(-11.033634259016594,0,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark15(-12.151795566092664,-0.0012036618487826119,0.0,38.05848110381271 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark15(-1.2199163728273927,-2.4707614103837257E-12,0.0,-18.394777630020805 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark15(-14.650984406924522,-0.6450233472425708,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark15(-16.143158231812464,-0.28297722554084714,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark15(-167.10062984171591,3.311718225821662,0.0,0.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark15(-16.940286796665635,-0.005256631021978025,0.0,-19.980633400485736 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark15(-17.284101476084874,-2.211655921274355E-12,0.0,-39.62757881899403 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark15(-1.7613988767377577,-0.11615418828030499,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark15(-177.58147020245408,-0.022584652590426833,-1.0,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark15(-17.911336654399605,-0.003536337796159356,-1.0000000000000009,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark15(-18.603673799794873,-5.891512904062067E-9,-1.0339757656912846E-25,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark15(-19.377061204791975,14.442943578231386,-6.612782138051155E-5,-0.0037924394822953403 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark15(-19.67201439612304,-3.3622750352889016E-4,-1.0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark15(-2.0939849750474906,-84.58212259773353,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark15(-21.389617672875943,-90.54714829695054,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark15(-21.44729423471466,-1.1102230246251565E-16,0.0,8.673617379884035E-19 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark15(-2.2122866400616905,-2.1975574527527656E-5,51.21190338997451,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark15(-22.223629022476416,0,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark15(-22.43792157670014,-1.5707963267948948,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark15(-22.547943377148552,-0.0024958373462543107,0.0,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark15(-23.064396104342833,8.6111333701991E-4,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark15(-2.344032649537951,-0.7605505732084907,0,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark15(-23.46712009356786,-6.9850325304868015E-15,3.9484127069845653E-177,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark15(-25.928599503107947,-0.0760525913673914,0.0,-1.0004748353867592 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark15(-26.102552807572707,14.430664467644661,-4.3368086899420177E-19,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark15(-2.737664984866374,-0.0025807678264238676,-1.8991135491519597E-65,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark15(-28.29492005101785,-7.729845494107545E-4,-1.0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark15(-28.739964629528746,14.43012351030638,0.0,-77.12941695143265 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark15(-28.916131966577915,-0.9824464983306159,0,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark15(-28.963219263305987,-55.462137804632405,0,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark15(-29.35986341617116,-2.095329093918377E-16,0,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark15(-29.530561837895554,-1.48678245763206,0,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark15(-2.9737861721559717,-0.002629840638929189,0,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark15(-30.524588994648635,6.429945768506987,0,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark15(-3.160490387192457,-0.16934353876445896,0,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark15(-32.768892603302206,0.0,0,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark15(-33.23440659417638,-0.13618349013185294,-2163.5732015712297,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark15(-3.36699245092635,-0.9604735249647822,0,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark15(-34.19312331282939,-1.5396168200052842,0,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark15(-3.5669297672205755,-0.1544961487439925,-0.4482400132774924,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark15(-37.490016376287116,-0.011044293020975832,-1.0,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark15(-37.55287698769025,-0.007868178805422343,0.0,1386.5016104141275 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark15(-38.11461760411908,-1.1796937490036712E-15,-2457.3403590471444,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark15(-38.200156020006396,-1.1102230246251565E-16,0.0,-42.38995948340941 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark15(-39.48269615813724,-3.84322332625694E-15,0.0,-86.82589287400977 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark15(-39.62325508395141,-0.06780388264618516,0.0,4.980936432601349E-5 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark15(-40.34057181651932,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark15(-41.184399613979956,-1.570796326792365,0,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark15(-42.224408377489866,-0.5678639862227414,0,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark15(-42.823509259315486,-0.768400454633194,0,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark15(-45.00379778026028,-0.001853420156833275,0,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark15(-47.35369770808266,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark15(-47.38705616587418,-96.62878478882317,0,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark15(-48.526384142052976,-1.0303378429269714E-6,-53.157689152841805,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark15(4.936048015973142,0,0,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark15(-51.289035677620134,-2690.334411125712,0,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark15(-5.143816679615307,-0.18178327435297137,0.0,-1.0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark15(-52.80252717725391,-1.5707963267948948,0,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark15(-54.15428258759206,-1.371921336632566E-5,-22.399246149777888,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark15(-56.48474831725263,38.916530374200676,0,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark15(58.948568578260904,74.58223090516907,0,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark15(-59.35622388509695,-0.02533623628120004,0.0,-7.458287152379338E-16 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark15(-59.52903368695493,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark15(-59.85023440525765,-6.645124113123103,0,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark15(-60.26405748230116,-6.5514525728096424E-9,0.0,54.86575756733017 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark15(-60.507861298820444,-0.04614780620551928,0,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark15(-61.31644722868426,-9.133829874346354E-10,0.0,38.84724389374836 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark15(-63.32678338597863,-0.010663802004560739,0.0,0.3622768869251983 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark15(-6.339974108708709,-0.4436572271867433,0.0,971.9884026743384 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark15(-63.596505670611904,-1.5707963267948888,0,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark15(-63.634072373343,-0.0025426414530874504,0.0,-100.0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark15(-63.68767984587977,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark15(-65.35752274234984,0.48672370368029083,0.0,0.0031210547621973728 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark15(-66.15238402134963,-1.284677486401217E-10,-70.28594985831577,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark15(-66.42688660569816,0,0,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark15(-66.91636373079396,-0.00218242130521228,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark15(-67.61337347997494,-67.55088846779967,0,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark15(-68.2923664646349,-0.7451738692122216,0,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark15(-72.35062790701484,-1.806839078181765E-14,0.0,0.16895934788079506 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark15(-72.93968796232707,-0.005003310170765242,0.0,1.0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark15(-7.343985019498891,-0.0025823734196608952,0.0,-1.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark15(-7.368278045442834,-0.00262984063887835,0,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark15(75.24133921677074,0,0,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark15(-76.39912453433057,-0.0010769979884111915,-1.0,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark15(-77.04196114099936,14.429204577600359,0,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark15(-77.55368855428814,-0.006970759802293315,-0.05749911697033264,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark15(-77.70184700137335,-0.0017747025162367439,-11.63518622380074,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark15(-77.86452892373259,-25.999552340822163,0,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark15(-79.41932569866042,-0.0024802026957238665,-1.0,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark15(-79.99607917261514,0,0,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark15(-80.19773009902653,-2682.7732724858756,0,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark15(81.51790152256211,0,0,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark15(-81.76195351203471,0.023931317954464827,0.0,0.5172270042360423 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark15(-81.80066556401012,-0.001994631969008571,-1.1732017053399565E-13,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark15(-83.52750248703602,3.481466255858905,0,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark15(-83.79704684187992,-0.002629840638828667,0,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark15(-84.04425580375573,-0.4044758117341881,0,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark15(-84.07620136683076,-0.0025970923038133296,-1.0,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark15(-84.12902153513083,6.454655469590937,15.48482716284742,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark15(-84.79965140667582,-1.299474481460436,0,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark15(-85.67292767474606,-1.4454096889418055,0,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark15(-86.39550743391979,-0.20052459882246865,0,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark15(-88.49383961499356,14.429210247193552,0.0,0.4775214045979982 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark15(-88.59210886810376,-0.0010391881896532973,-0.7729567052067162,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark15(-89.13849404667806,-7.425304554576871E-4,0.0,-85.16209335659795 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark15(-89.39973526222893,-0.00411420280969399,0.0,1.0010887074672659 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark15(-92.54242454870031,-0.002629840638799627,0,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark15(-98.02434475606204,-1.2450766897074317,0,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark15(-99.99999999999997,-0.002425699022542925,0,0 ) ;
  }
}
