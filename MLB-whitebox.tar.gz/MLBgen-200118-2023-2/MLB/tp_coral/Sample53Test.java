import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
//    0.8352084510287684;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.008476955305266902,4.930380657631324E-32 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.012948110253544637,0.999999999896499 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.017293647510335214,30.773625777936743 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.017947235872902034,-7.175274104261199 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.021017952673025777,51.609257953440135 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.04898367403579547,-1.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.05026070069593,-26.844697756792787 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.05431646036575388,-74.42665668495657 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.05555146263033528,-1.0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.08875740748716751,1.0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.09419833547649081,0.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.10294908537215586,1.0000000000000002 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.11060759934859174,-1.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.11434797842269617,0.10423391514533176 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.12385834131397422,-1.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.1379945236155409,-1.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.14133959459405132,-1.0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.15994918996254132,1.0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.16338112582631464,-0.00575282109756499 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark53(0.0016611808066159472,-1.3828698988920767,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.1851348489510546,-1.000000000000007 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.19021293991629573,2.1175823681357508E-22 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.2146019120513793,1.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.22021935680928095,-0.5561536796256893 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.22096156398528288,1.0000000006041332 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.2282000837126164,-0.7875200733995856 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.2838054589548742,-1.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.29190120800877806,-1.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.29345862586594285,-0.9999999999999991 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.3673356385813734,0.4169307012794763 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.43199582620752264,4.440892098500626E-16 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.4355946072701593,-50.54780130028915 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.4533624768588873,-1.0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.502263100374731,1.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.564858723382784,-69.80658787859363 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.5693244476694757,0.9868752303820891 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.5830995490540363,-0.4675155004791094 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.5834701016339473,1.0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.5863793331378098,-48.75023746718686 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.6055497850274887,65.94735200579433 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.6079888462124101,-0.9999999979200925 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.626138723619951,1.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.6448280819664438,-0.01628806057932589 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.6469530442759055,-0.04298845109917021 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.6660849584103505,-38.95732320971914 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.6671799522485998,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.6709583754364539,0.9932290025196745 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.6739016881068155,39.02643817647371 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.6906318779923896,1.0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.7605194569606464,-6.6174449004242214E-24 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.7708823841679631,-46.531017484111004 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.858568105573051,0.6667262242597376 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.8601749525789723,0.9999999999999929 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.8690887427807166,-1.0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.878888824463606,-0.47613022363465163 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.9200749075218242,0.9089101590093801 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.9251348089913235,0.9503240206196848 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.9346100821150823,2345.03727550372 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.9629471904510619,-0.4773517688685194 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.9631718961231115,53.3561688400412 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.9841250376153475,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.9984849218044205,0.8188769460633459 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.020586336770711,53.85627682094727 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.0388803305401932,26.731366307726802 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.0604349654066192E-6,5.701823487917707 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.0671690536350962,1.0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.0734473027217144,83.53231634665454 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.0813472457945077,0.0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.1227495167269486,1.0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.1239772901971896,-23.949153859417066 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.1707200678395717,1.0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.179176072648577,-51.88632419682468 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.1944216408437824,0.011968389679053027 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.2286091194618993,2346.344781392111 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.2563813235018968,0.9999485213090039 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.2854593549579396,-2239.0867857576827 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.3160281665900428,70.32447412089499 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.327256571013379,-60.347186111126064 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.3438750683715424,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.3850024556908316,5.484264505944461 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.390317185379402,-42.269020989913656 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.3906245668561037,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4071663516987423,-0.5729546929146121 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.415451252057592,-0.6500068969815249 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4304368536156498,-0.06255253859625862 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4318744929411746,57.00047761851556 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4443982983891184,-0.848225222421241 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4642872647092797,82.83540233430591 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4737766127916656,-0.030426860492833274 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4878016829822829,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4894816967022089,1.2449987933998585 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4921937509439118,36.248613170400745 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.494427523051016,-0.031098812411047394 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.499472657120915,0.011149783291173776 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4997015336349562,1.0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4998265315756583,-100.0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4998546833762565,-0.2139827571583771 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.499999965243257,-5.653890667954149 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4999999997229505,-1.0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4999999997389517,-0.7940682983766882 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4999999999999927,0.06255252551706136 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4999999999999947,0.8612905991502982 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4999999999999964,-9.252863008634844E-72 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4999999999999982,1.0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4999999999999991,15.728183093823901 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4999999999999991,-35.3765403203879 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4999999999999991,59.35118867939876 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4999999999999991,-67.92285835998817 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4999999999999996,0.9999999999999998 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4999999999999996,-2415.3051557774584 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4999999999999998,-0.6033336957807816 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4999999999999998,0.9999999999999996 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4999999999999998,-8.873197078810742E-4 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark53(0.015501507376518975,-0.3255118268941368,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark53(0.015945677097718325,-0.48065456886581237,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.6499111987711502E-15,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark53(0.0,1.76442783029433E-18,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.8259631069383886E-6,-1.0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-2.220446049250313E-16,-1.0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-2.220446049250313E-16,1.0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-2.220446049250313E-16,-73.57306699555603 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark53(0.02393300306525248,-1.292749760886256,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark53(-0.024806784330964504,-0.8669487484351911,-0.5775697614191881 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-2.819794308076888E-9,-0.14099919877942899 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark53(0,-0.29736442925609075,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark53(0.03133513840268165,36.584189807650546,46.07684356632501 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-3.7652406326381405E-15,8.102609029697626E-19 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-4.2279370607988133E-4,1.0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark53(0,-0.44313222239412653,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-4.443896668295586E-16,-1.0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark53(0.048223388043073356,-0.10680366539835129,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-5.551115123125783E-17,0.36208927338337316 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-6.265349444311023E-15,2.002083095183101E-146 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark53(0,-0.6381516189828015,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark53(0.06766834564804469,-1.4999999999961346,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark53(0.06889193204507016,-0.9547785888924967,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark53(0,-0.7853171616850123,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-8.483261205977599E-10,-1.0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-8.881784197001252E-16,-1.0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-8.881784197001252E-16,1.0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-9.242744366484594E-4,1.0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark53(0,-0.9468337902721196,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark53(0,-0.9688210029667061,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark53(0.11044998674958606,-1.1495898413351568,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark53(0,1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.211316101584245,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark53(0.13988909638865876,-1.4962860350367317,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.4530299246450367,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark53(0.14643527076787474,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark53(0.1471681444675852,-0.389441145138818,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.5,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.5254963812367297,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark53(0.17035184357920308,-0.19434315519214618,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark53(0.17592619865017944,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark53(0,1.907446401563817,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark53(0.19775267553114872,-0.33697423182336195,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark53(0,-20.12088316640977,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark53(0,20.59846560878013,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark53(0.22549890066294154,-1.4769424956852073,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark53(0.25606132874989385,-1.186948273646367,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark53(0,-2607.6248126314085,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark53(0,-2651.6543740965926,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark53(0.2828528053878987,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark53(0,-29.8494131671186,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark53(0.30258821929719204,-0.9327047548126011,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark53(0.3265940990145629,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark53(0.34755302286213674,-1.651217843814342E-8,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark53(0.3675486331340254,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark53(0.37858907851677603,-0.47103332321545194,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark53(0.41347631742837315,-0.03222457758241595,0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark53(0.4272954436090073,-0.1721453567803053,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark53(0,-44.01359929416753,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark53(0.4591905633590727,-1.1190021520608657,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark53(0.48067577346411383,-1.3682473232335344,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark53(0,-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark53(0.5083440427969736,-0.8958662503805719,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark53(0.5252945657082648,-0.37455985669653735,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark53(0,-5.271974390293877,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark53(0.5278615985282897,-0.913033610198311,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark53(0,-54.18503126653476,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark53(-0.5515162510501455,-0.39336774275131337,0.24868614332339156 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark53(0.59446805106478,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark53(0,-62.74088165838201,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark53(0,-63.19631871415938,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark53(0.6427281901456778,-4.5995683311700537E-4,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark53(0.6644837411119013,-0.0480771993798772,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark53(0.6991061395050447,-1.488140696356037E-9,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark53(0.7511994177938384,-1.4226731115944773,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark53(0.7928210361939501,-0.2986080488251156,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark53(0,79.77639492067388,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark53(0,-7.9E-323,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark53(0.8818367683800941,-0.0472241880784388,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark53(0,-89.89631471253392,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark53(0,-96.5533887093724,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark53(0,98.12330255220937,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.004430006201063859,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.010120707921431379,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.02510529296784303,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.02685387214381718,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.04116171612777486,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.04757574564981626,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.04763411687803523,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.05181634323863948,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.06441261893562855,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.06536982809408487,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.07001294120743173,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.09467011645237045,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.10182944293937057,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.10754607513007741,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.1287088956932326,0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.13328004473231764,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.15625477257049006,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.1763227794350617,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-0.18844249599897303,-1.0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.19795718254430061,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.21512370090195754,0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.22132962919482124,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.22484551093526317,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.2542728119112586,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.26001622883982023,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.2801179666845243,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.28499969348137794,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.287455585474758,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.2900467548299417,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.30819782965400166,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.3162794078714648,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.32061154624945076,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.3208800074401117,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.3308203820343728,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.3354147930346003,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.3377405298643425,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.3516891999352738,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.37734483806974684,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.3828999736669565,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-0.38956764035637415,1.0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.3992012606843387,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.4019753042545831,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.4049212391004411,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.41356393599853786,0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.4136246794777476,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.41937924076852084,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.42387249708884234,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.43825603968453697,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.4974884611003263,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.5001477666258605,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.5222138885260159,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.5438909500384206,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.544192893092116,0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.5483220336585128,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-0.5669560229947407,100.0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.57343255406452,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.5830740703866859,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.5858534571231898,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.5935543108262245,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.5982700286577731,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.6136844824444978,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.6150649012005489,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.626877115117657,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.6315014736874695,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-0.640348534091171,-0.6625441509711385 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.6469616610561325,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.6723125501439159,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.6945051616070138,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.698194820735807,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.7517860271306149,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.7602062472131854,0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.7651596125129808,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.8073348297203691,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.8133323772947889,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.836696533862261,0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.9143061716465518,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.946265210908235,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-0.9515800339541745,-0.1317799181705832 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.0318984443052153,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.0388558647364637E-6,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.047000579935513,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.0598823372225217,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.0689379632772154,1.0000000000007863 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.0810497899165145E-4,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.1053333134188166,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.1102230246251565E-16,-0.06255420951346988 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.138353171677979,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.147328262137398,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.1511907448994398E-9,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.1691921578634E-4,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.2004145756953943,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.2107848084681199,0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.2186536170844033,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.2476430828387934E-5,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.2515942984321282,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.2701225014950186,-2.8574684782056875E-101 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.283059589717082,0.9056974999549438 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.2861036580880139,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.304742293291409E-4,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.3068744532253768E-15,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.3462449777926222,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.3562503423603633,1.0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.3595045647298394,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.364126281781875,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.37396033888355,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.3811015039374157,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.3927804019071512,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.395509890227963,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4031835475683598,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.4199281061126428E-13,1.0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4217981679579788,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4455156431755248E-8,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4610525141735238,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.4714707544588028,0.044852669584463975 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4837934206208327,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4950685843112825,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4953738952183917,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4992018535984322,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999156525337,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.49999997839969,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999928850392,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999992012714,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999997812947,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999998472804,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.499999999999997,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.4999999999999998,-100.0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-2.157783927639948E-7,100.0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-2.220446049250313E-16,-2368.676757700667 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-2.8602351409766304E-4,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-3.4486191631073836E-15,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-4.0552712922893566E-10,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-6.118009479958743E-5,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-6.874051450134946E-10,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-7.032555831177531E-7,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark53(10.079025248093295,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark53(10.114891778686296,-1.4999999950650367,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark53(10.147778097186858,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark53(10.181327082962682,-3.3116533636047194E-9,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark53(10.182648429644264,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark53(10.186442994151562,-0.051620245467370096,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark53(10.21683993619014,-0.834916943169921,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark53(10.229714232012354,-1.2784213581203483,0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark53(10.232795879654617,-1.1771288471460606,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark53(10.24796273183603,-1.2166741405198316,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark53(10.258990201782908,-0.005230683399707559,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark53(-10.26895015552563,-1.7386060566938928E-9,-19.421612425513064 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark53(-10.276139966305227,-6.36668851664335E-8,-1.0000000000521352 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark53(10.304938135091149,-1.093777139956444,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark53(10.32713969409625,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark53(1.032910835303176,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark53(-103.47611439931241,-0.05362451150423886,-84.69384864329245 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark53(-10.347813306596967,-1.343881959635153E-9,0.0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark53(10.363384748648002,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark53(10.389957068986035,-8.133339097199984E-10,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark53(10.471525268095789,-0.005523787413675793,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark53(10.501803740250821,-0.8880583519815417,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark53(10.516511943427659,-0.07845201202389229,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark53(10.547156221185404,-0.5206819653281229,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark53(10.555234919871182,-0.006944102959489107,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark53(10.595385807671777,-4.7762406904106817E-4,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark53(10.636601123945212,-0.6218233031288491,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark53(10.687968793997419,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark53(10.702071162394395,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark53(10.731265335224197,-1.0560203501304293,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark53(10.790796993708655,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark53(10.819725179057988,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark53(1.093031812777781,-0.7408819567742028,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark53(10.943171949404643,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark53(10.94379103418288,-0.8984301675756541,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark53(10.950906568472341,-1.7414253281497283E-6,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark53(10.957260067093209,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark53(10.969948774340224,-0.9089995262469122,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark53(11.006187360089001,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark53(11.066663634519841,-0.4301735170977452,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark53(11.079374499453001,-1.1514992960769863,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark53(11.087517299462501,-0.40942212678528067,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark53(11.104187324346967,-1.0291833009645615,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark53(11.119046622636503,-0.7038263951814354,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark53(11.122788065112061,-0.37176864124953113,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark53(11.19893530319824,-0.12026418874238853,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark53(11.227955462883644,-0.4634664253995375,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark53(11.260515282690864,-0.5688969025265767,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark53(11.276977896716136,-0.14577104577745204,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark53(11.294786164033358,-0.5603885527793592,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark53(11.311785657758662,-1.4869057169060862,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark53(11.346886737364684,-0.0624160966531524,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark53(11.400008387688956,-0.9702437907324921,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark53(11.403510182731399,-1.4999999919660396,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark53(11.408123866480032,-0.5517934003921283,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark53(11.419904030565057,-0.7280794767653251,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark53(11.433346061394493,-0.01338476713428298,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark53(-11.450565429423502,-1.812912598943918E-8,79.81862874461973 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark53(11.466132768043334,-1.7125646791613674E-7,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark53(11.472239621671406,-0.32549515078159946,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark53(11.481752407226011,-5.412724302443381E-4,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark53(11.492612167241234,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark53(11.508513571998915,-1.1934054007335675,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark53(1.1515484170004981,-0.9084392265544845,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark53(11.517427348699897,-1.2523574614313873,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark53(11.5190946313013,-0.6673664205164727,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark53(11.582385398243488,-0.5919653430122853,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark53(11.611438468810917,-1.1519048299997563,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark53(1.1677244662932835,-1.4999999999679519,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark53(11.687782202545513,-0.6987418397446263,0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark53(11.777242159508964,-1.4996223234237074,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark53(11.998461578637379,-0.87445806715017,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark53(12.006418899082675,-0.5887045155508428,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark53(12.079486655825278,-1.2429535372778076,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark53(12.094325864721068,-0.09587009133579803,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark53(12.143918808438485,-0.12197737157961797,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark53(12.163332592205506,-0.1434500611785493,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark53(12.1879377585373,-0.256070425758544,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark53(12.205267396648821,-0.44709095900449825,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark53(12.2546335829741,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark53(12.258507452877993,-1.2832702981047532,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark53(12.265181775614337,-0.6674686490373318,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark53(12.30769342096329,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark53(12.322480855206006,-1.4798253023580759,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark53(1.236994918491476,-0.062453910597356554,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark53(12.390032278592386,-1.2025224574245783,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark53(12.440707396658432,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark53(12.44354101753484,-0.03892941172518816,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark53(12.469048517393194,-0.6032450300731422,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark53(12.497515253561371,-0.665927270498412,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark53(12.520594567918536,-0.41458435270662597,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark53(12.6023494980074,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark53(12.62822481412455,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark53(12.717180640576096,-1.1289117317411326,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark53(-12.73287986656683,-1.2269242004732677,-55.76749131394566 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark53(1.2736403062327213,-0.007715869572243239,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark53(12.754727698137671,-0.0978854674759666,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark53(12.758159927769853,-0.09124566058966366,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark53(12.79266523034191,-0.9636433488598122,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark53(12.91307676573635,-0.7678093241846606,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark53(-12.918944564783958,-0.0028556045636993037,0.9785370706845699 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark53(12.926251956951432,-0.7501235406152347,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark53(12.952829353140146,-1.4328045455176586,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark53(12.968522366739508,-8.934111016376157E-5,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark53(12.980753150623059,-1.0803793928042378,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark53(12.98097602268112,-0.36334746682948094,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark53(1.3074026036340887,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark53(13.105913688351094,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark53(13.108434156544702,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark53(13.192180007326225,-3.1685414970379455E-5,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark53(13.25639932408717,-0.5112194528610843,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark53(13.363280740592193,-0.10251971627562534,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark53(13.44565088149104,-0.17916008970513675,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark53(-13.456937972938194,-3.4089656293401634E-6,44.439255259160205 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark53(13.47028567765339,-0.2305905197548037,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark53(13.482965550063454,-7.582375377261417E-17,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark53(-13.490527586142235,-1.498159759836054,-1.0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark53(13.494906796174647,-0.17893739360012106,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark53(13.50028313355574,-0.3481890897068247,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark53(1.3502267091771216,-0.8244986692454006,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark53(13.588473321351454,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark53(13.595400261026668,-0.1375799831005168,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark53(13.61505801298324,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark53(13.632048415838113,-1.4782206356672987,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark53(13.716064955359158,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark53(13.72124324932831,-0.16716875729780156,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark53(-13.76541338987596,-1.4714207920922522,1.0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark53(-13.907994809119302,-0.6018321786179482,-6.557315327538186E-17 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark53(1.3962019451985128,-0.9103398370297131,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark53(1.4005164845041493,-1.4999979987499539,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark53(14.057824923911724,-1.3401459223971273,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark53(14.07340122618108,-1.4754963105100805,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark53(14.09285643389562,-0.6299747987187079,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark53(14.103325679219843,-0.44413071098573975,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark53(14.128153831038716,-0.6663427215946918,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark53(1.4158053978771055,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark53(-14.18837179063501,-0.9640343652603753,3.3642769650272157 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark53(14.355146288104425,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark53(14.357721441848764,-0.5177961740982306,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark53(14.394905048523682,-1.0779260665943927E-7,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark53(14.39650237762558,-1.1921293460245108,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark53(14.435553635662497,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark53(-14.46801642572038,-0.4415350013933247,-0.8618985002487007 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark53(14.494119663933873,-0.7346182641153112,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark53(1.4497883035840857,-0.9724670141926626,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark53(14.532124851935723,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark53(14.55397677215565,-0.010190388993480431,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark53(14.576954942110381,-1.6721228431737822E-6,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark53(14.600873516386855,-0.5195397158467063,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark53(14.613776072528239,-3.776229851057763E-9,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark53(14.621559842963926,-1.4318957157596124,0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark53(14.626099390004143,-0.1769146587459951,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark53(14.658825909773626,-0.4261661233018101,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark53(14.66803553366162,-1.499999997913409,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark53(14.697771299364312,-1.2864324336653539,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark53(14.706516155965346,-1.211047893386065,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark53(14.72889661379439,-0.5684045293441669,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark53(14.747677345722238,-1.4782151567270583,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark53(14.808180199150588,-1.4999999923434095,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark53(14.835311036317236,-1.4710658681297701,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark53(14.884992431275393,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark53(14.964181183505573,-1.419181846877425,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark53(-14.994810927796989,-0.23818614442402755,-0.9328767768475718 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark53(14.996509845769907,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark53(15.03362030609201,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark53(15.046640609160537,-1.1606398167062286,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark53(15.058313572365826,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark53(15.058877259448161,-0.511153774792081,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark53(1.5079658213529266,-1.2956340548884762,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark53(15.124480182975896,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark53(15.125451160296128,-1.2614665391036612,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark53(15.135898424329257,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark53(1.519424418967617,-0.99054966823158,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark53(15.228457259065832,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark53(15.232110162483067,-0.045681072943182244,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark53(1.5232645419205966,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark53(1.5255387309434156,-0.04999785515943716,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark53(15.258570053018854,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark53(15.276672670393722,-0.20363019101571567,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark53(15.396655926941108,-0.43512832961287806,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark53(15.458057903939766,-1.4999690573230706,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark53(15.509915389400703,-0.21682602004038642,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark53(15.583196064687257,-0.23901572624650846,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark53(15.598961435821735,-0.2523331265043396,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark53(15.65380777240128,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark53(15.686212619069856,-0.23155089586570934,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark53(15.694218475642174,-1.4999752930868386,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark53(15.701122479648717,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark53(15.748641234671751,-0.409646847763252,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark53(1.5749176174702062,-0.8925945079427173,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark53(15.752661509936516,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark53(15.83320173873149,-0.33743348282872887,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark53(15.871539330365607,-0.9620967309878218,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark53(15.930802174633257,-0.1237354540441391,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark53(15.934971611773392,-1.3656347511615188,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark53(15.95071794257633,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark53(15.96128591747268,-1.022313308271773,0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark53(15.976946721897775,-0.0013742548218687034,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark53(16.021504117662445,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark53(16.064662901742476,-0.5384870623873128,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark53(16.159733481704848,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark53(16.17121047235152,-1.499999997486538,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark53(1.61895E-319,-1.0624047190298814E-8,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark53(16.196268807654292,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark53(16.200939433294632,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark53(1.6254237841836812,-0.15861361138659213,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark53(16.285624232700926,-1.2786548466744065,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark53(1.6341158572721497,-0.035844414150224324,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark53(16.35001866442984,-1.02377332624512,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark53(16.352836170751768,-1.0363558118888976,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark53(-16.417203156818896,-0.38942488752039495,-11.248601305310803 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark53(16.427234082286276,-0.11418328813498291,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark53(16.43356238428872,-1.065983188488289,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark53(16.43412713206476,-0.22282380893957598,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark53(-16.466980176082036,-1.4999999999999991,-29.715085801795755 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark53(16.480584759609854,-0.8455199485352409,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark53(16.48545382353557,-0.10404303186329744,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark53(16.532530143979088,-1.4999999999996803,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark53(16.5550990523122,-0.31240645200294637,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark53(16.575012572214334,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark53(16.623158066505844,-1.067673460977577,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark53(16.65818951959035,-0.35866961010549936,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark53(16.705933122334486,-0.7389336695150136,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark53(16.733337921706877,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark53(1.6734949066661926,-0.7899462359280858,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark53(16.738049495732938,-0.9545201639467074,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark53(16.741301575029375,-1.120162254831861,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark53(16.75617193343126,-1.2490857239175137,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark53(16.796767577339637,-0.45306299807402084,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark53(16.854599185623798,-0.03132703918796485,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark53(16.86057146409179,-0.5013900696066429,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark53(16.90673466650984,-0.6622710301556253,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark53(16.938523076033647,-0.913685854790967,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark53(16.94680554040457,-0.5127692756099265,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark53(17.063685157565445,-0.8849471549578949,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark53(17.13083036693071,-0.40304341912670694,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark53(17.141748130278955,-1.213275848932256,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark53(17.15697233959045,-0.9349233809987245,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark53(17.15984667826524,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark53(17.180948929122543,-2.2619787412695974E-6,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark53(1.7203578698577502,-0.4152322713928207,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark53(17.222365693083155,-1.4730676282658812,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark53(17.267655522999334,-1.1668597254676953,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark53(-17.282916982824005,-0.40855977410198996,-0.6601192686308757 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark53(17.283707582635643,-0.6647503090355915,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark53(17.285371724692638,-1.3078618027715962,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark53(17.298276877265366,-1.440360354319349,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark53(17.33963105096454,-0.06662038012058277,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark53(17.37349098303143,-0.5447354768752953,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark53(17.404188030516437,-0.01920823545749073,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark53(17.43977916625936,-1.2354799752693668,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark53(17.463714459934117,-0.08405808922074387,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark53(17.50013486674999,-0.8224608603180454,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark53(17.509611235617566,-1.499999981976655,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark53(17.568996559360926,-0.15292498952640093,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark53(1.7571045695469678,-0.24943954440436755,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark53(17.603150098911556,-1.00282775960261,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark53(1.7608997019286363,-0.00813809974706653,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark53(17.64166127608378,-1.3127398151062204,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark53(17.671325417993543,-0.6732122449120705,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark53(17.675423012785622,-0.9190892166291976,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark53(17.71159326636986,-1.467205237811827,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark53(17.71189492377533,-1.2314610347569785,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark53(17.72111695450665,-0.8543665560565736,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark53(17.721471406217717,-0.7137813709607376,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark53(17.74634133465179,-5.993685829093732E-10,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark53(1.7763568394002505E-15,-0.200131910422711,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark53(1.7763568394002505E-15,-0.6281287071257964,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark53(-1.7763568394002505E-15,-1.4470629882913262,-0.013808114818656986 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark53(1.7763568394002505E-15,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark53(17.78141235903012,-1.1655917503063138,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark53(17.792104914477818,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark53(17.84592069190171,-0.6372437716040722,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark53(17.848446644799793,-1.027984706131548,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark53(17.912179164853214,-0.9083624845561055,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark53(17.91363997599678,-1.1938594502950126,0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark53(17.995948346747188,-0.37608439848666864,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark53(17.99846338305325,-0.08626587756461368,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark53(18.0111991369444,-0.04513548861661709,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark53(18.03567497860945,-0.40824206749804753,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark53(18.036911752265933,-4.086847249662297E-8,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark53(1.8057721777658697,-1.3947418620550498,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark53(18.128209837798448,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark53(-1.815922564549325,-0.15449403134500084,-48.68546161663838 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark53(18.252528438933354,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark53(18.276299600075106,-1.3010284381064015,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark53(1.8283004458464092,-1.3386864545021433,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark53(18.327445115474973,-0.7834779687999358,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark53(-18.39189292593303,-0.2757839954124819,0.05222265277408139 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark53(18.394864840053387,-0.6622664301273229,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark53(18.564556059031297,-0.840006899859988,0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark53(18.5836396068773,-0.4545757271783213,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark53(1.8604203443752145,-0.5241829608921478,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark53(18.63025668643268,-1.3868458169800653,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark53(18.690683345440593,-4.90585566601588E-16,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark53(18.707383869519887,-1.3830459109929238,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark53(18.715017409724652,-1.2701568468263629,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark53(18.748512700483673,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark53(18.771384114291266,-0.32934272815535337,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark53(18.775062136932902,-0.2908503659996944,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark53(18.77918671650795,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark53(18.785700919336378,-0.07341117882859172,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark53(18.791788665719935,-1.0081714962703865,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark53(18.79851275003018,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark53(18.81604994090288,-1.2317523001563258,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark53(18.851988999854186,-0.24152706332109108,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark53(1.887099301222637,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark53(18.879667548212822,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark53(18.91335647378665,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark53(1.892761454671885,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark53(18.941871347621174,-1.4999999999999662,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark53(18.950988379914932,-0.5600937152936445,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark53(18.956010509062708,-0.24528502537583563,0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark53(18.95775807081104,-0.8570392047998237,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark53(19.045828542410568,-0.266276820555873,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark53(19.089490320948954,-1.30613171884107,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark53(19.153310803125006,-1.4913208768827513,0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark53(19.154126343335378,-45.85973602487074,31.268224172135348 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark53(19.18323611358288,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark53(19.21440139441267,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark53(19.218356660810503,-1.4999999999334848,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark53(19.305153332551313,-0.008065849473810616,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark53(19.308191912645288,-0.5441403664754536,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark53(19.31011944658248,-4.3466408252624956E-10,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark53(1.9330389328776558,-1.4968062754244733,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark53(19.333169904527743,-0.8163382273190791,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark53(19.33743181319376,-9.149234381331534E-9,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark53(19.33803578009241,-0.5871216516300564,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark53(19.377410490791846,-0.16338053990806345,0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark53(1.9398555693037578,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark53(19.438566719481685,-0.5809297189575773,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark53(19.44550934471919,-0.005291156720013337,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark53(19.459631486559516,-1.4999998710901086,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark53(1.9462383334661268,-0.17088029175866815,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark53(19.481356527202422,-0.31080249600935883,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark53(19.512188419942007,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark53(19.5410397721249,-0.6989325478585551,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark53(19.565360524872517,-0.8650587874842142,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark53(-19.574964216336866,-2.3100615056706E-6,86.99619264598974 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark53(19.57870169592435,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark53(19.58687178458378,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark53(-19.61146954924261,-0.9248817790422699,5.5809931214954833E-104 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark53(19.669457512845863,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark53(19.675297557188088,-1.0303920569582046,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark53(19.71810076380533,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark53(19.754782835923763,-0.9811035192351909,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark53(19.843465841702113,-1.4861891227862856,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark53(19.868821476282292,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark53(19.87567657139246,-0.9904866819163516,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark53(19.93286744904958,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark53(19.933502446987234,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark53(19.943195840699147,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark53(19.952207506569465,-0.1549572974904745,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark53(1.9961890555068038,-0.39468465129368396,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark53(19.96673484411126,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark53(-1.9E-322,-1.2941415153363984,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark53(2.0007269738108135,-2.849410262108377E-4,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark53(20.063360454738493,-1.2690501165752908,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark53(20.068823301578753,-0.8281872194007667,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark53(20.073616765532922,-6.106464259193435E-9,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark53(-20.201689752165528,-1.3805728102137846,-0.8800588191448278 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark53(20.227262729243016,-0.20707537184432212,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark53(20.260879035880848,-0.11531067333076805,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark53(20.296958010237624,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark53(20.304847115121262,-1.3812510303742915,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark53(20.334799009981634,-0.28523580338636045,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark53(2.038581187692265,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark53(2.0393235290222584,-1.4999999831099642,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark53(20.399912619793167,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark53(20.4511775807012,-0.8872787825755164,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark53(20.485086318772616,-0.40222428902822394,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark53(20.49565068169485,-0.04798673511487239,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark53(20.51991344373393,-0.9083138432625084,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark53(20.525038204470818,-0.654025380635731,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark53(20.578282669926296,-1.2400293578920127,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark53(20.59919587518688,-1.4999999999999951,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark53(20.61077135086006,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark53(20.624385001024265,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark53(20.728313301508933,-1.4999999999999325,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark53(20.733314903843493,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark53(20.837212578007183,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark53(20.876373331214047,-4.3537742322723015E-4,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark53(2.0880813552742525,-0.6240484270228919,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark53(-20.894622748705963,-1.1833069116182882,-84.42805664887821 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark53(20.940782238766445,-0.007095626796369098,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark53(-20.948277037257014,-4.808404915028132E-10,0.0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark53(20.968072524320604,-0.2657613870391078,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark53(20.975906732632556,-0.17852011750486607,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark53(20.977416582492552,-6.137445200302601E-9,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark53(21.08250729767301,-0.48869050064491243,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark53(21.126897938753714,-1.3477690258929278,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark53(21.175904465735158,-0.8166568719375027,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark53(21.214997954991443,-0.04073065276973892,0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark53(21.21753932345623,-0.004139168564561901,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark53(21.293375292521716,-1.249673619296864,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark53(21.305184418130683,-0.9585103757941739,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark53(21.323971276541954,-1.3501944452931225,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark53(21.327807692497064,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark53(21.353789413681938,-0.6599703994322699,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark53(21.46832177759825,-0.6635187005450471,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark53(-21.48555083874503,-8.048704636559969E-8,0.4284560944591414 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark53(21.490401972755436,-0.237663972474067,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark53(21.51274088042801,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark53(21.513656638038924,-0.8170526513974181,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark53(21.518330544786025,-0.2028720206929937,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark53(21.530259575818004,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark53(-21.53028057678255,-1.3716164731184541,-1.0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark53(2.157525807534654,-0.19704779229066627,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark53(21.576061872769667,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark53(21.63703014255998,-1.2686628360818295,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark53(21.645685205369574,-0.9638695660606773,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark53(21.696894284854444,-0.05384556959850095,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark53(21.716524242390705,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark53(21.718847223478427,-0.1426599861052317,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark53(21.72424682699934,-0.6840517631785903,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark53(21.731221316610345,-1.0992700928789834,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark53(21.73443262356622,-0.48674065271207323,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark53(21.74630277509661,-0.4579964015231894,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark53(21.766952785907264,-2.078414742229884E-9,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark53(21.794239007082446,-0.6726973839340014,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark53(21.81373479820842,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark53(21.81464720970142,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark53(21.89520414428661,-5.040796907147359E-9,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark53(21.911071055029694,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark53(22.05255933464391,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark53(22.05284760055804,-0.1431171813270845,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark53(22.091409251755636,-1.3734738721428177,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark53(22.208649435464437,-0.7431360224642276,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark53(22.219055898216823,-1.3265565591728006,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark53(22.231313163121502,-6.764452746223902E-9,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark53(22.256800690529726,-0.10830640895254998,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark53(22.299581540777393,-1.1029336335324889,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark53(22.327994369626218,-0.0957385161350105,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark53(-22.36105508768478,-1.4257058920467922,-0.3622987497614987 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark53(2.2370662353544954,-0.9018424240550833,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark53(22.429463525392904,-1.3065857384917434,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark53(22.434000249156945,-0.661014420832247,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark53(22.55015263206768,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark53(22.568339366199574,-0.5504974155802671,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark53(22.685864924021796,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark53(22.774890421172326,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark53(22.780984515917666,-0.12148101799851951,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark53(22.856598655721044,-1.317307475231729,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark53(2.2897017320127873,-0.043226374626459174,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark53(22.92083611211678,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark53(22.92232884574272,-2.2820809637797606E-9,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark53(22.952894303863673,-1.452188915023059,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark53(23.009849448495686,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark53(23.10181210841911,-0.17190919555136475,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark53(23.11540226507308,-1.2273774943899838,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark53(23.143913638994746,-0.9118768324147444,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark53(23.16099584246045,-1.3853818572986878,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark53(23.16993291052316,-1.3664027953467985E-8,0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark53(23.234770737370567,-0.4812793147613448,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark53(23.243550862315722,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark53(23.243677364578257,-0.24475712736440025,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark53(23.262131695400562,-9.29202778160274E-9,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark53(23.273417531324007,-0.6763260160138501,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark53(23.322555442710183,-0.35129280215700387,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark53(23.323765126781467,-1.1445423127516379,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark53(23.341912416550414,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark53(23.353387355953345,-1.067074699512708,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark53(23.372709144946896,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark53(23.388754542541093,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark53(23.474498908661687,-1.1547053057364725,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark53(23.47748524433962,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark53(23.477529056632644,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark53(23.4849308002174,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark53(-23.486365063435954,-0.017577525363636652,0.41835398195314416 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark53(23.495433336050382,-0.6354060329494899,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark53(23.519068049508007,-0.5051871127237106,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark53(23.54191150747616,-1.9998112015614204E-9,0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark53(23.58515088432181,-0.5953011002788826,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark53(23.60411142180838,-0.5771596594940906,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark53(23.61013210109821,-1.0211048675992403E-9,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark53(23.65583075432731,-0.18830233526621395,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark53(23.728310535496647,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark53(23.752611547477958,-0.11128781544608746,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark53(23.765702685691977,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark53(23.780647849816667,-0.2719450788410033,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark53(23.81750679256109,-0.07186713188346969,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark53(23.829329968575934,-5.425134711660275E-4,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark53(-23.89421468775634,-1.4999999999999996,0.9597105048404856 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark53(23.907260456313367,-0.3282949077628361,0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark53(23.922785210451394,-0.07479132972392177,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark53(2.3950070907707897,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark53(24.071348753033796,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark53(24.083022600020087,-0.304458611607322,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark53(24.093624679204837,-0.17788512296646913,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark53(2.4138054767519232E-17,-0.6190755756366614,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark53(24.156101007305416,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark53(24.156487757725458,-0.3264739173289872,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark53(2.4157720442327957,-1.001241179588689,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark53(24.166622302605973,-0.48734253352629864,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark53(24.18117348343452,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark53(24.18212177390025,-0.01712749920000811,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark53(24.183404460181993,-4.8098141684730256E-4,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark53(24.205714702098152,-0.23270377534575926,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark53(24.221137528791402,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark53(24.231844855631365,-1.0721857874933978,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark53(24.248046035661595,-0.037789004225928124,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark53(24.27465001694378,-0.4608674076236525,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark53(24.339090947132846,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark53(24.34756880888152,-0.5303415696697216,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark53(24.361468475091712,-0.003463330604240533,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark53(24.363614254331736,-1.297772919908283,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark53(24.477024685354692,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark53(24.514232856875893,-0.27907255273637416,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark53(24.526400842059687,-0.5277496638745438,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark53(24.559302377578163,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark53(24.572943674750316,-0.30597911421284374,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark53(24.63206870547755,-0.272955612241059,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark53(-24.662769783204265,-1.3978576647464056,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark53(2.4682011487929665,-0.7844454748823173,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark53(24.712372620907164,-0.08760558572419361,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark53(-2.4740675032677046,-0.6159548508959245,1.0000000000000033 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark53(24.83529663095687,-1.169636473883974,0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark53(24.87940957826791,-0.639363747835215,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark53(2.4889139730132835E-8,-0.17647604202651682,-0.3620894365820599 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark53(-24.908199822469328,-0.5995334033129645,1279.9363087309132 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark53(24.90921146876311,-0.31036258622630375,0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark53(-24.925695102553675,-0.20757957931459473,1.0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark53(24.926247970445203,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark53(24.961129903556483,-1.0359402630708185,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark53(24.985687840968637,-0.3516851027516217,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark53(25.018927326550155,-1.4999999999999254,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark53(25.03566661759519,-7.655227635014813E-10,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark53(25.0622912802112,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark53(25.072729638646535,-0.2951934925227846,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark53(25.085267864952485,-0.3190250701014774,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark53(2.5106425434797472,-0.5232212195294963,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark53(25.11132910470606,-0.8187861161015775,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark53(25.113615891264047,-0.45579662247990216,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark53(25.137719507402153,-0.06064406467492911,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark53(25.159836551543112,-0.47176482280194154,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark53(25.176721430622983,-1.2127456637653071,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark53(25.187303733373795,39.613937954394686,-71.42468439457537 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark53(25.218747394004353,-0.23893760520702045,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark53(25.225919544497724,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark53(25.23393243065628,-0.18767068668964892,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark53(25.253131985633743,-0.5751496604064528,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark53(25.271833304667545,-0.0017633641010268326,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark53(25.303866237425595,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark53(25.36580484779634,-1.3024934444652834,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark53(25.370825065021947,-0.7805241787280365,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark53(25.381795536201594,-1.47224856032965,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark53(25.3890098172962,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark53(2.5389851020635317,-1.4999999999697258,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark53(25.438520258039077,-0.09066739601374663,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark53(25.448708177429562,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark53(-25.49695177254224,-0.05422653419895229,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark53(2.552884595305965,-0.9186949597474552,0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark53(25.557125578319642,-0.20707537056495084,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark53(25.615193800505637,-1.0347482463340043,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark53(25.64373757127877,-0.2211661721996836,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark53(25.890085101934915,-0.6132474862441954,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark53(25.93268978538903,-1.1142200266633233,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark53(25.95058803198008,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark53(2.5969800724055894,-0.15813831533338307,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark53(26.00745681183399,-0.5789054171769514,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark53(26.06430309854116,-1.1865620154087413,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark53(26.066274342871083,-0.13692107005948767,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark53(26.076264396849428,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark53(26.087471997819264,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark53(26.10746039129849,-4.1706477163144627E-8,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark53(26.113744621903024,-0.20205773057875298,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark53(26.12888998564415,-0.8253687378658014,0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark53(2.6144570690175453,-0.47882889202808254,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark53(26.161006903538837,-0.7383204128769164,0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark53(26.227052485447356,-0.34668515167096103,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark53(26.288099703398743,-0.18184986119165103,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark53(26.29475443765354,-2.771704388540725E-8,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark53(26.30137039860523,-0.34576162308503156,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark53(26.308764283258554,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark53(26.318916445439918,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark53(26.3553445876626,-1.0108849173456633,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark53(26.356701786477707,-3.291195930114068E-4,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark53(26.36308997949257,-1.4605002531342954,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark53(26.365486982974232,-0.7888764953402756,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark53(26.440867561840903,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark53(26.455554537871876,-0.7784866077708241,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark53(26.461024712702383,-0.1167847967266038,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark53(26.531412974254337,-1.3681233194753675,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark53(26.533551515194805,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark53(2.667896880071896,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark53(-26.69600520669256,-0.7421449889209699,-1.0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark53(26.696888337807835,-0.12875047395664296,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark53(26.698777196721863,-1.3245930356113718,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark53(26.71591414726761,-0.688867074169853,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark53(-26.740614917021446,-49.6737104299378,-69.45798419749136 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark53(26.751093622947053,-0.055695780888795676,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark53(26.753201284266524,91.53061597329355,60.11038688371849 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark53(26.78926840207363,-0.9456407102277637,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark53(26.797082979327413,-0.518601572009942,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark53(26.830014984103798,-1.0371201494493028,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark53(26.841061690268916,-0.3634543222005959,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark53(26.914669000836575,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark53(2.7063926386673227,-0.04842995442558974,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark53(27.181142280873217,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark53(27.20348378015269,-0.35334703742443585,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark53(27.222704285805523,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark53(27.229077889286103,-0.7739667289851582,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark53(27.259827923180275,-1.2964335634421378,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark53(27.335443234344112,-0.9734148850715694,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark53(27.425918770663515,-0.9468455471914465,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark53(27.442411578638357,-0.6563756071650765,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark53(-27.484985073076032,-1.1887646131785452,2361.7611203797883 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark53(27.49703064780556,-0.002475032167338043,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark53(27.52469747531861,-0.31482717406475025,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark53(27.556154519056847,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark53(27.558373430158525,-0.6174503576397381,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark53(27.589548964551184,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark53(27.597396472504585,-0.3931584921454959,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark53(2.760476228650526,-1.4864964957160396,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark53(27.656821673053248,-0.02991546446953844,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark53(27.663262696140393,-1.1289435421016036,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark53(27.684779358110198,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark53(27.7171816951535,-1.497251851095954,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark53(2.7755575615628914E-17,-1.4710412890495628,1.0200923162694575 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark53(27.79394643863681,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark53(27.82423318339637,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark53(27.847395071233578,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark53(27.848147268561334,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark53(27.85895433799135,-1.199980867920857,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark53(27.967143049090538,-1.4733432406174787,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark53(27.984476657613143,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark53(27.990992583126584,-1.3564228628429058,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark53(2.8027133111527434,-1.2214077835399242,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark53(28.029109089225344,-1.1900424786951223,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark53(28.041307191289178,-0.5280683637862755,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark53(28.056791449543113,-0.9877942853734965,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark53(28.117412067634262,-1.474341778906945,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark53(28.139923162230954,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark53(28.14436150310854,-0.845199140489652,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark53(28.165247427625616,-0.44913151067976287,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark53(28.22994502541883,-0.969979185995669,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark53(28.23485863715048,-0.19602714724083903,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark53(28.26434476340378,-6.0054785088045E-9,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark53(28.28154900217162,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark53(28.300183295793033,-0.3721309780713645,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark53(28.332817796092996,-0.8694188254125912,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark53(28.376491665126704,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark53(28.381688398827208,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark53(2.8389500141914743,-0.04671219318889319,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark53(28.417747797440718,-0.30337512328159155,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark53(2.8423811109727524,-0.4845061080542621,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark53(28.425071897782516,-0.2109592942082962,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark53(2.84411941753406,-0.31363212502255067,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark53(28.50992299512374,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark53(-28.63697258304196,-1.4999999999999998,68.56161764029984 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark53(28.68010306432504,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark53(28.704310912731966,-1.4999993790421993,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark53(28.751057152834846,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark53(28.75328080974342,-1.1868641241750196E-8,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark53(28.762511686884793,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark53(2.8765474528862853,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark53(28.776233884965944,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark53(28.778227385348686,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark53(28.83744466417005,-0.29446317786663556,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark53(28.84960220903667,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark53(28.851258236242984,59.5607648655523,1.6272987366029241 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark53(28.883681289398965,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark53(28.89624813634868,-1.18588899403033E-15,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark53(2.891067757476762,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark53(28.927611153152156,-0.5790713505562337,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark53(29.042046381112755,-0.6764479371990848,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark53(29.05657082374186,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark53(29.073873957439968,-1.4999999308260585,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark53(29.089822351650888,-1.2757938660830006,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark53(29.10106484010876,-0.4211749950083554,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark53(29.109094283670913,-0.10988683163724744,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark53(29.122376843315237,-1.343943735251588,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark53(29.134273593146673,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark53(29.135978966377806,-0.040639883837728874,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark53(2.914036923412283,-0.7753675379712925,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark53(29.152458087769755,-3.199192413027495E-5,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark53(29.164114820781975,-0.001063474760899935,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark53(29.1716122221101,-1.3449419332516257,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark53(-29.172139443854107,-1.4999999999999982,0.9833970826379056 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark53(2.9298124330644693,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark53(29.329600876397933,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark53(29.351776397276353,-1.3553739270684493,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark53(29.353469602042964,-0.06865056693054372,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark53(-29.43263467640081,-1.499999999999999,-1.0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark53(29.44720216639388,-0.037175807884723744,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark53(2.9469847773949252E-9,-0.29376643421601983,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark53(29.541018737590576,-0.5123663075292425,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark53(29.571623039524603,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark53(29.58799525391197,-0.46023298877126706,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark53(29.665356845659034,-1.499874513386402,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark53(29.76695364396724,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark53(29.780569649007298,-1.076015543184316,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark53(29.823051114314183,-1.3640594211723425,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark53(29.8303839296145,-0.40511400447317314,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark53(29.886159772175308,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark53(29.95448762988252,-0.8481310772990032,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark53(2.9986379479252747,-1.0592241762297714,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark53(30.037428645903788,-0.44119386335905686,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark53(30.050790991465085,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark53(-30.093730525020277,-0.7833007202369184,1.0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark53(3.014275597212631,-0.3104914777877923,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark53(30.192844504326693,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark53(30.21793763194424,-0.9981896691497516,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark53(30.222822768358295,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark53(30.244932136310815,-0.18153240367887513,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark53(30.275058409647812,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark53(30.29415677698279,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark53(30.310188140802037,-6.0863757230740854E-9,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark53(30.33233508248371,-0.1497930459503957,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark53(3.0347970125937387,-1.4999990055159376,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark53(30.34970863885468,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark53(30.4041979748784,-0.24435497984839216,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark53(3.042914729068094,-3.548753246065038E-7,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark53(30.463690303426226,-0.8549728400220377,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark53(30.47364170647949,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark53(30.48958162457012,-0.98083088927185,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark53(30.520804917639644,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark53(30.615177377915728,-0.4162501533808296,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark53(30.66532817773151,-0.7896351909077293,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark53(30.68482509517736,-0.5009434083540545,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark53(30.777825028825276,-1.464541763236383,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark53(3.0871983504391523,-1.206952268016494,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark53(30.909356643093105,-0.7484863133121471,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark53(30.92741868874597,-0.6097058154098581,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark53(30.94918176167991,-0.5979914516949942,0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark53(3.100593939135223,-0.9022227058826839,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark53(31.007638808760092,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark53(31.012511418465806,-0.9173495913222429,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark53(31.016020456529134,-1.4999999999999822,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark53(31.093799922942168,-0.6764356189898111,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark53(31.1367352784076,-0.6041272869125436,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark53(31.155354173782428,-1.0434423977670918E-8,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark53(31.160409090903528,-0.08621400060315754,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark53(31.17413306489791,-0.06685579785471647,0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark53(31.188159061451415,-0.15581104585353955,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark53(31.196991082248445,-0.6303085114433561,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark53(31.227672263195302,-1.0289558161913697,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark53(3.127364310954494,-0.10919425322887578,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark53(31.321284834626628,-0.08786050420924524,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark53(31.329719117741547,-0.4898117347044959,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark53(31.373803648019123,-0.44057575575889296,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark53(3.137468220376384,-0.30774225598442684,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark53(31.379787921134685,-0.28125838385902746,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark53(31.390255415401867,-1.1488319550580002,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark53(31.43468553719353,-1.1565275296424176,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark53(31.44320305743622,-0.07399105813166784,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark53(31.44821165861495,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark53(31.46905665512847,-0.6605839162942848,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark53(31.50647898521072,-0.43833270773763444,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark53(31.51959400340408,-0.16394639150676293,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark53(31.53449898708936,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark53(3.154549254869046,-0.10527971925576407,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark53(31.54841888930539,-1.6488414410266833E-6,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark53(31.54980463203634,-0.13844594931424148,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark53(31.55658163009855,-1.4594542086467017,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark53(31.570094593588884,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark53(-3.158591809516762,-1.17614308459653,1.0000000017067463 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark53(31.589588858631288,-1.3227647527776762,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark53(31.656629746653806,-0.2524467708632363,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark53(31.666051148748068,-1.2274904146909602,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark53(31.703098965730348,-1.499999841470511,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark53(31.77969558614442,-0.09541161265135445,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark53(31.786081993831317,-0.8904848995074441,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark53(31.81014685949563,-0.6126575927409448,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark53(3.1838312359972605,-1.1774245912502526,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark53(31.83976022649705,-0.07559670562676235,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark53(31.852589475406035,-1.116946682605362,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark53(31.854450421177518,-1.2468763340188929,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark53(3.1860350503913395,-1.1518885109074404,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark53(31.87907799877512,-0.18740381202434597,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark53(31.88977976157375,-1.2178572822719822,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark53(31.91368866222047,-0.6903087672072482,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark53(31.964584336391653,-0.5447329053972167,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark53(31.993619523449734,-0.9531985900925272,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark53(32.04381290442879,-1.3061892843801894,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark53(32.098448530967914,-0.03213463759533397,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark53(32.21093465257078,-4.392463967859863E-10,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark53(32.3046273018506,-0.46865258690984923,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark53(32.30892252486777,-0.9744021533105192,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark53(32.32049393603606,-1.455473060441307,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark53(32.3294168288025,-2.710036189507929E-17,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark53(3.2340836411267992,-1.499615172123,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark53(32.47201303423341,-1.1123696834268524,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark53(32.472104111746084,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark53(3.2520007847459507,-6.137345971483331E-7,0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark53(32.524242278531524,-0.6984023594050861,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark53(32.56787988844309,-0.1389483616018526,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark53(32.610460820044096,-0.6532887263172285,0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark53(32.63710754867284,-1.4999999871815195,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark53(32.64721898752328,-1.2025304330722661,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark53(32.699549388857356,-2.6849929718958554E-8,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark53(-32.71973532566703,-0.32083623690377205,-59.37539156978467 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark53(32.80742200104998,-0.5412379811991902,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark53(32.822922986999984,-0.028947510674993862,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark53(32.84634519721398,-0.02256624044671675,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark53(32.86513270533311,-0.2254162063828744,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark53(32.86753094099506,-0.34941680518478524,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark53(3.293841545147897,-0.8011883238036006,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark53(32.93901411067188,-0.8303475356110677,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark53(32.947845184197575,-0.2039711484938406,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark53(32.955511357280706,-4.2354645236942294E-7,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark53(32.98429133008193,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark53(32.9923551198159,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark53(33.0109455788984,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark53(-33.023010333572955,-78.37651597082865,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark53(-33.05528589503703,-0.9678658979805963,1.0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark53(33.092269637638516,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark53(3.315178358293764,-0.24378876682290063,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark53(-33.158382093010275,53.19967832398933,69.58315795100748 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark53(33.17241963385736,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark53(33.18826534259014,-0.3851198440419849,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark53(33.19057003705902,-1.2990375770143743,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark53(-33.24377074212974,-0.26549089598642794,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark53(33.245359497294714,-0.2242134202545758,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark53(33.2572817610677,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark53(3.328593965414676,-0.09523795173748795,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark53(33.329504491896834,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark53(33.34063850221105,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark53(3.3341572867433347,-2.2825751765986087E-15,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark53(-33.37098019497505,-0.11564700896461061,1.0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark53(-33.41431886861496,-0.0050624792548994435,-0.05882091635332376 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark53(33.46536335861404,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark53(33.48381616550942,-0.36329441837718246,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark53(33.48413876480422,-1.2257503095546127,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark53(33.492117874685015,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark53(33.512830736858405,-0.17465508225728577,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark53(33.5394666069371,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark53(33.60452793423092,-0.4019945553203941,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark53(33.62496538031601,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark53(33.63454617202577,-0.14362516060265126,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark53(3.3644658176857263,-0.2486704194695477,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark53(33.66039192654961,-1.487980040699881,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark53(33.704204170651074,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark53(3.3709703070566706,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark53(33.710682195009014,-0.3230457437878458,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark53(33.722865481956774,-1.3725153035592825,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark53(33.74860004621383,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark53(33.761809738082064,-0.8378226446483175,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark53(3.379290905252759,-1.0445060340332333,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark53(33.83299097112008,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark53(33.85983457467526,-1.4999999999998934,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark53(33.878462182169585,-0.8593729987996145,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark53(-3.3881317890172014E-21,-4.437733564019682E-6,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark53(33.8884364736233,-0.2481090532145575,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark53(33.89713343213904,-0.9829036975890886,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark53(3.3926714207295703,-0.42235376293756133,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark53(33.93470848751204,-0.8473206702132847,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark53(33.96634192850826,-1.4650895075229022,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark53(33.979438330988216,-0.18487542774748267,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark53(34.021737776455375,-0.9002525857237229,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark53(34.0691086630344,-0.05921010219928746,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark53(34.088141474699086,-0.2910534306072097,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark53(34.11559684392992,-0.6449978999644195,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark53(34.152780706742675,-1.1491364767304475,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark53(34.157400925245405,-1.1656504948421136,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark53(34.18256422241532,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark53(34.19331497583792,-0.2626993526288467,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark53(34.23854523641742,-0.4949091739731415,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark53(34.252902831960284,-0.9165218393009864,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark53(34.27125368448888,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark53(34.28269105382515,-1.2342534911089942,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark53(34.291832141265076,-1.3193669715930785,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark53(34.29236624480333,-1.4243359914955818,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark53(34.33200763888357,-0.052053281189884615,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark53(34.353762824402224,-0.35349238296202756,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark53(34.372807141644614,-0.857584265547672,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark53(34.39327865987374,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark53(34.394525866343464,-0.7254802246434533,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark53(3.4452523215056488,-1.0071368229965607,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark53(34.47014138031034,-1.568227148691668E-8,0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark53(34.48447417516901,-1.009847335052561,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark53(34.49961673123255,-0.049316465089460415,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark53(34.52332555205666,-1.4999999999999805,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark53(34.59439666724623,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark53(34.59804853032588,-0.21827258888042422,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark53(34.60981749644077,-1.110267224752235,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark53(34.61112304566919,-0.10040759855592896,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark53(34.613239420427476,-0.21728206486162494,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark53(34.62477955488499,-2.357066132591932E-6,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark53(34.71544476670374,-1.2743021843239148,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark53(34.742616252501705,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark53(34.74528732758981,-0.26376291543016234,0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark53(34.81302084148527,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark53(34.8459463898232,-2.8344920868125935E-8,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark53(34.94019911927391,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark53(34.97295128827079,-0.3568029023230479,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark53(3.497475208240928,-0.16654047044614328,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark53(3.4991689752234407,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark53(3.499530105925089,-0.8799706132006122,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark53(35.10675718703676,-0.6649534519030145,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark53(35.11355232963436,-0.3555298417690267,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark53(3.5151444822389095,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark53(35.17757331445455,-1.2077869518360227,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark53(3.51879649842418,-1.477298607913238,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark53(35.21258337835059,-1.387595074531859,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark53(-35.243079020701614,-0.8034588158772128,1.0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark53(35.263675854776125,-0.9521092796583908,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark53(35.33390788700595,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark53(3.535857792598907,-0.241773648539791,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark53(35.41193164322101,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark53(35.414734048761815,-1.2401304053030113,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark53(-3.542E-320,-1.0507614211323843E-286,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark53(35.459485253228536,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark53(35.465964568007934,-1.0431868428937088,0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark53(35.47375906207422,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark53(-35.489210882147376,-8.881784197001252E-16,-0.4267165716192034 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark53(35.50368010793386,-0.42462260735639923,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark53(35.5170322329227,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark53(35.53613578759695,-1.2530979301611538,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark53(35.57364354118852,-1.1597177761051027,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark53(35.58270508957622,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark53(35.62163359029685,-1.4838238968457436,0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark53(35.626139853674665,-0.8678695437032653,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark53(35.650566613641274,-0.7935340440461509,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark53(35.65889477844903,-1.3189926931197151,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark53(35.66049737500944,-1.2221350336733252,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark53(35.70402882282098,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark53(35.71427634900138,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark53(35.75921018619428,-1.0531043728145164,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark53(35.7670187755974,-0.007352828431086048,0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark53(35.86847058921745,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark53(35.90336099105323,-0.34849678229200265,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark53(35.91604901970018,-0.3319165827292431,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark53(35.976223277348424,-1.4871489592552778,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark53(36.002616111107486,-1.101181650126442,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark53(36.045598975483216,-0.6176683962391962,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark53(36.0649393342717,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark53(36.103065161780535,-0.3712738321735003,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark53(3.615323731309573,-0.22912827792279913,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark53(36.189927435578625,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark53(36.20953248733001,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark53(36.250876802359045,-0.019278598060536778,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark53(36.26147176734657,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark53(3.632838326224231,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark53(36.33024945659826,-2.9889406921553266E-8,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark53(36.3408734897358,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark53(36.34234273764855,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark53(36.42992368634307,-0.3531916630898908,0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark53(36.44212772852049,-1.202166978933437,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark53(36.47282878978081,-1.1088991904629433,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark53(36.486736558838146,-0.8496731256486498,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark53(36.486802229419986,-0.1962780928185106,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark53(36.50209467771406,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark53(3.65530354109562,-0.2108615243248897,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark53(36.55439583560562,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark53(36.55751708346122,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark53(36.56608492050596,-0.4709340557680737,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark53(3.6568413344091795,-0.5057465599163602,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark53(36.71765868241147,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark53(36.73550149714086,-0.3701818463544755,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark53(36.76579170789296,-0.6863710782817777,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark53(36.82419366473326,-0.4365883189017643,0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark53(36.831377447066984,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark53(36.85962391053003,-0.3097289270045147,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark53(36.92216928747288,-1.3034191264228383,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark53(36.94111483031337,-1.4300792551407966,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark53(36.97438713144396,-0.9456825003838278,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark53(36.994932672066305,-0.5033080279370092,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark53(37.05416764892515,-1.4999989787195864,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark53(37.08788669479,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark53(37.0916552551453,-0.0909736484834287,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark53(37.163088884813035,-0.17694516235413937,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark53(37.23637485835346,-0.04023041227698343,0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark53(37.277262247808466,-0.4725168406470033,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark53(37.2871164413297,-1.0623011129856597,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark53(37.31896005619171,-0.08205851562617472,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark53(37.32968976725144,-0.5561847334509036,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark53(37.335071606477015,-0.37086830833958695,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark53(37.43617977062806,-1.2521848954765922,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark53(37.508595970317096,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark53(37.53884690824107,-0.9331861933239662,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark53(37.650062144130516,-0.3013435306697498,0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark53(37.68880567276844,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark53(37.83967403191292,-0.6449443424710921,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark53(37.84333028314012,-1.499999999999961,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark53(37.856112529766136,-0.10731527242391792,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark53(37.85872463758639,-0.3091066168382217,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark53(37.873461781568665,-0.25390472062435165,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark53(37.89486432436317,-1.0447885003714674,0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark53(37.9221880623777,-0.08398275274425428,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark53(3.7945465377444236,-4.0552712922893566E-10,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark53(37.97083577029166,-0.28264642318721167,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark53(38.06797747039221,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark53(38.14398159064092,-0.46233657610277135,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark53(38.16789868999726,-0.9900929857965481,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark53(38.19104154234792,-1.1325362050412937,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark53(38.23751129056177,-0.48644707540045307,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark53(3.823755446147427,-0.2826672845160205,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark53(38.279519974025995,-1.4999999998876703,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark53(38.34058262138379,-1.0206330983395446,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark53(38.372745861807374,-0.19889816990328946,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark53(38.416826386179,-1.1460587133264752,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark53(38.4913538989764,-0.06916654031183,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark53(38.60520314152977,-2.011373342881188E-7,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark53(38.60545759077593,-0.33704716000208634,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark53(38.667471181783675,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark53(38.671432590062835,-0.8535531559090177,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark53(38.69616952458932,-0.4028840781217649,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark53(38.77897942949764,-0.6633227567297411,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark53(38.860959728962754,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark53(38.89628881325021,-0.22682405711215858,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark53(38.93982216769908,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark53(38.954980739019874,-1.3916213966521696,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark53(39.01641846624374,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark53(3.9026744847829056,-0.8083332647967182,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark53(3.9033354506498528,-0.9606985354839503,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark53(3.90759004578436,-0.8895486621546929,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark53(39.12388973174874,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark53(39.19051329670975,-0.6238495848674974,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark53(39.21591535969272,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark53(39.22859052157483,-0.5360465287670877,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark53(39.24422011687364,-0.4540093507408782,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark53(39.26988210492476,-0.27166212995321,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark53(39.298208775414594,-0.9730272295298152,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark53(39.31112245884049,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark53(39.311893714473456,-0.8877114396691894,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark53(39.312663453052444,-0.5491271604070456,0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark53(39.33833809851694,-1.3384203395958054,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark53(39.3479890634478,-0.7310090490166975,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark53(39.35295552245748,-0.6577026039290994,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark53(39.43004920549936,-1.4588069512196427,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark53(39.450302410597175,-0.8364350857947755,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark53(39.464126423308194,-0.08800181451761291,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark53(39.46755230070545,-0.8850924292455384,0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark53(39.54596735597116,-1.2785779820156051,0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark53(3.9578209905941737,-1.3962071865854437,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark53(39.61747806056775,-0.9783754934205176,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark53(39.61784221758745,-1.4292080297980485,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark53(39.63810398781784,-1.119000755902128E-8,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark53(39.66623687824464,-1.4999999999457467,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark53(39.694697888853696,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark53(39.695336700765694,-0.208096410532292,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark53(39.80497261681734,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark53(39.822965180157404,-0.9571203680032165,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark53(39.86101540390371,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark53(3.9867925016370975,-0.5505793302181015,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark53(39.922385589136304,-7.845366012399678E-10,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark53(39.933171992212536,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark53(39.94905806156348,-0.6872917310336568,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark53(3.9982385051253857,-0.12163512409660537,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark53(39.982793505473374,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark53(40.068803140391,-1.0191408913174778,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark53(40.11397243153277,-1.1028585666284947,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark53(4.012179216981834,-1.3190173004415773,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark53(40.17452859378844,-0.34820361336448424,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark53(40.17584072978224,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark53(40.192999494721136,-0.05779912125414066,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark53(40.25059985088171,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark53(40.26039043573574,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark53(40.331881288957526,-0.1976686846222322,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark53(40.33270653467191,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark53(4.039277315316681,-1.4999999999999858,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark53(4.041904263063904,-0.012157489836264898,0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark53(40.42163361874972,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark53(40.52548278851765,-0.19004683159622004,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark53(40.54197441432507,-1.0063532536024073,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark53(40.550075546343095,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark53(40.60156322515102,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark53(40.607004836429695,-0.6621674993453537,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark53(40.68237246482042,-0.8087942994215069,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark53(40.714841638666826,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark53(40.743001795449615,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark53(40.757029574704916,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark53(40.80137201589723,-1.1224630433452711,0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark53(40.81501982669417,-0.016449047754643953,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark53(40.82100954297391,-1.438263674193919,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark53(40.854680328891476,-0.46890860803286216,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark53(40.866781369524176,-0.9772718472106021,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark53(40.875492603337165,-1.133857112582966,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark53(4.088216053918973,-0.8162181107416016,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark53(40.94770130404623,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark53(40.95364092109267,-0.03087146525965423,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark53(41.05671473097278,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark53(41.1305567651151,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark53(41.149574608673845,-0.14673238079450712,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark53(41.161202665051945,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark53(4.118037346589903,-0.8831757499739012,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark53(41.23285993539625,-0.05093261314591868,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark53(4.125603933623623,-0.13246041802055686,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark53(41.26127398304456,-0.6957700605859802,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark53(41.296038621737516,-0.05424670536177656,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark53(41.35539366330866,-0.4681940023115161,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark53(-4.1359030627651384E-25,-1.1571668083711806,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark53(41.380164766871665,-0.23003321664035614,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark53(41.38562295299449,-0.6310266993611213,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark53(41.396333783538466,-0.05150417597315027,0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark53(4.140582709421627,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark53(41.49731209291113,-1.2199454244957177,0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark53(41.50312173525598,-0.7830946535025476,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark53(41.51557799048546,-1.269961739187019,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark53(41.53104450584371,-0.4687585025367939,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark53(41.605188000142334,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark53(41.645744915904395,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark53(41.698112955088746,-1.4888836021918923,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark53(41.746687343166,-1.16858282300341,0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark53(41.79684045371653,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark53(4.181009131859003,-0.5956715208071016,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark53(4.182184253288645,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark53(41.843851236306534,-1.2773449296058363,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark53(41.84960374079597,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark53(-41.86435537898112,-1.2122233773112647,-0.056087476773388656 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark53(41.89132602575981,-0.48391935901388794,0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark53(41.90879488424296,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark53(41.922434352103615,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark53(41.9485588319323,-0.3872810754732237,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark53(41.95183868328019,-0.14322779966616386,0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark53(41.9596006661518,-3.8589332159348985E-6,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark53(41.9612300196266,-0.3893135102868386,0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark53(42.008674655816876,-0.6552800063884838,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark53(42.01383893709223,-0.14556790426492153,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark53(42.04277069502055,-0.7117955753489402,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark53(42.049914695707,-1.281234035174726,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark53(42.08776708746919,-1.4672030011744068,0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark53(42.1043680786872,-1.3634702429501075,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark53(4.211583229875544,-0.6894939110583866,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark53(-42.15075879348026,-1.3300541509507349,-1.0000000000000018 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark53(-4.218179740221586,-0.43004675144336885,0.02939015533987341 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark53(42.20478458510945,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark53(42.274904463223606,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark53(4.234364505591273,-0.028004485176612803,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark53(42.34552157151953,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark53(42.421005060631416,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark53(-42.475355255385836,-1.499999999999936,-6.486514179055874 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark53(42.508225088819984,-0.3254586471756742,0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark53(-42.52074464397841,-1.5727136958825013E-9,0.8909683112655283 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark53(42.52344402892237,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark53(-42.54717149489834,-0.785503106113616,-1.0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark53(42.62328952909408,-0.6175747253977022,0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark53(42.626178847335744,-0.8695670048369362,0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark53(42.66130294281757,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark53(42.69409039656495,-1.3102065639422857,0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark53(42.726481631986644,-1.4999999999246756,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark53(42.80902025352785,-0.03425102615797876,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark53(42.86542607571617,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark53(42.887826752412906,-1.3083607852010406,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark53(42.889756887406605,-1.1797608627990712,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark53(42.938693620281725,-0.8990501402577975,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark53(42.980800332894546,-1.4999997402242666,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark53(42.9841804205856,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark53(-43.004180792531805,-1.4281241285747015,1.0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark53(43.01594402615612,-0.4145311466017265,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark53(43.107768678294946,-1.2317658722893732,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark53(43.112947110328854,-1.072777026388922,0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark53(43.165180512338644,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark53(43.188634630777564,-0.023739703129106823,0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark53(43.21079974435181,-0.8142175688420583,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark53(4.323830118747125,-1.496551561127871,0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark53(43.252525069719866,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark53(43.26012190857364,-1.1695256305193737,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark53(43.32960425476339,-1.6994509257143683E-9,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark53(43.360882853989324,-1.1891712999689288,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark53(-4.3368086899420177E-19,-1.2728163453076875,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark53(-43.407809793516876,-0.27631724527942936,-1.0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark53(43.442485619271544,-0.061592683024552564,0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark53(4.345062330771171,-0.0763197624878238,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark53(43.490442824150875,-0.14294011761807113,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark53(43.540753700201634,-1.4378971798661553,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark53(4.364935118307712,-0.06748491229822987,0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark53(43.71315972202039,-0.298767880749252,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark53(43.74281632283946,-0.5799071213137137,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark53(4.379214673645123,-1.530350333021731E-9,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark53(43.83867432358389,-0.1981203660970401,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark53(43.86573955317655,-0.07048180692333528,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark53(43.87390903851854,-1.3132598238431346,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark53(44.021233255795664,-0.3661575577960292,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark53(44.07845532018549,-0.2823756824430781,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark53(44.09739421411675,-0.6005066711978237,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark53(-44.14370421702094,49.876692902064974,36.583756569281746 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark53(44.18919783651788,-0.2913969585741194,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark53(44.19099587871057,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark53(44.20960497847136,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark53(44.21596377580036,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark53(44.2578400443501,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark53(44.280724277412425,-0.27581964579862017,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark53(44.29040395868627,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark53(44.3552437233214,-0.3904695440864856,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark53(4.436121397227436,-1.795731954958049E-5,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark53(44.406551030832816,-1.3020481404133184,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark53(4.440892098500626E-16,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark53(4.4481080354031475,-0.5632975981024608,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark53(44.488378986714906,-1.2257512007926814,0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark53(44.496922416358956,-0.06044869489845439,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark53(44.54879440478757,-0.10436635332085586,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark53(44.54961853291897,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark53(44.55058572221196,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark53(44.58489994312354,-0.012665887136132687,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark53(44.60982299714708,-1.315936564820017,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark53(44.67243019535589,-1.463775784995566,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark53(44.69005277564628,-1.3928991056543123,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark53(44.693177951379226,-0.11849926114042475,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark53(44.70127653077441,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark53(44.72412836016136,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark53(44.75103780982255,-0.6087571686334794,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark53(44.7700639386177,-1.296131228512877,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark53(44.776548959823856,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark53(-44.77675480658841,-1.4999998442767164,-0.5828999803580155 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark53(44.788732502473096,-0.9792048056558498,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark53(44.88259478954724,-0.7771775316024607,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark53(44.914556250153936,-1.2000032192433354,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark53(44.92819429839305,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark53(4.494802098907073,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark53(44.9639042381523,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark53(44.987035635731374,-0.34102177163951275,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark53(45.10405422547244,-0.2633957575337367,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark53(45.128571019533695,-0.48971908304586087,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark53(45.1680548368025,-0.15283445831440245,0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark53(45.17031407565557,-0.5560246374544797,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark53(45.190804431873495,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark53(4.519674130498942,-1.4319356321129242,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark53(45.23418367830243,-0.5036658951441141,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark53(45.24741869967656,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark53(45.26331193906249,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark53(45.303895013247924,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark53(45.306400302089,-0.11450115611879674,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark53(45.311508773702464,-0.6258184554933037,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark53(45.320331164428936,-1.1110816124523089,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark53(45.3723826221146,-0.7826887926090933,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark53(45.38985494234842,-0.8943775037202779,0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark53(45.435322016476675,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark53(45.47852447630584,-0.7990878202962213,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark53(45.510853480348885,-0.325592272593324,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark53(4.553990550714971,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark53(4.5576968704896785,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark53(45.58759988980748,-0.7547554805335341,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark53(4.56097122673976,-0.19033739085555812,0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark53(45.68238018107729,-1.4242144342345617,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark53(45.69021295168034,-1.4506981785040234,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark53(45.724440173012994,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark53(-45.79435211192098,-8.881784197001252E-16,100.0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark53(45.88441408260048,-0.19164887503847633,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark53(45.89410771385154,-0.8930689218332141,0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark53(45.92069921462755,-0.5496395542097394,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark53(46.00361316336276,-1.2774715778871184,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark53(46.016172731291846,-1.442144379156172,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark53(46.02656892079807,-0.06408670520610826,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark53(46.072587201568616,-1.2109553695308732,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark53(46.14718497320801,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark53(46.19744959027818,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark53(46.20780625870344,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark53(46.21649862182119,-1.3204169369709633,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark53(46.32191722673099,-0.018161424339324533,0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark53(-46.326351507619215,-1.4999999999999998,0.9999999999999998 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark53(46.376268505741606,-1.001234412461304,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark53(46.38545519487127,-0.11673218371793467,0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark53(46.386705911309846,-0.14584281445896174,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark53(46.43464860576253,-0.42613578006548636,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark53(46.43969169204305,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark53(46.548604283501454,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark53(46.65422998173787,-1.4999999999999978,0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark53(46.69692617315235,-1.4999999996940798,0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark53(46.736819523275784,-1.2762977983401547,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark53(46.76676766809908,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark53(-46.77876697953444,-1.49999997932133,1.0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark53(46.80644361727043,-1.4999980614424617,0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark53(46.80757008946591,-0.605304006457411,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark53(-46.83539909577543,-1.337786125452928,-1.0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark53(46.83607604745158,-3.3505616226628205E-7,0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark53(46.84739689590621,-0.15476368650422767,0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark53(4.690472009133018,-0.7982074061607705,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark53(46.986249014747415,-0.1876835868031037,0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark53(47.0111203103117,-0.5740937808302489,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark53(47.01738219810039,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark53(47.0243255567945,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark53(47.033062232619415,-0.27770673385312383,0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark53(47.047233132579464,-0.24388987414060725,0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark53(47.06438624257891,-6.043591100692251E-10,0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark53(47.09820823358206,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark53(47.17578866619435,-1.386334564907348,0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark53(47.23361412723898,-0.23890495060347572,0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark53(47.24987886347711,-0.4449525774297527,0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark53(47.31724575009062,-0.11930904318082035,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark53(47.350496743236704,-1.1406181900488757,0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark53(47.35094642820016,-4.830564995566634E-10,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark53(47.36213291059238,-0.9472240693465268,0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark53(47.41067208153092,-1.4034594035435077,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark53(47.45388171832823,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark53(47.46066158893259,-1.1645527421563067,0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark53(47.48104645794896,-0.6654978895206796,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark53(47.48381059174349,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark53(47.49305399093521,-0.6358630908137644,0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark53(47.541750528814646,-1.0260595224587306,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark53(47.56264583621841,-0.5759975930795682,0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark53(47.70143902096347,-0.05323751600927177,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark53(-47.7247972530348,-85.05461692233645,20.846139575884365 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark53(47.73944411742127,-1.2869290182110178,0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark53(47.75300228785815,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark53(47.75584281147408,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark53(47.76045726321302,-1.0100262981822872,0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark53(47.87151460459583,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark53(4.788200420443901,-0.2559360758077103,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark53(4.7899551284235,-0.623569588966487,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark53(47.914152165211554,-0.3638591227347199,0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark53(47.92293822454147,-0.828728348687207,0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark53(47.97199740078776,-0.22637174425311768,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark53(-48.049354788348424,-0.7052735167091077,-1.0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark53(48.04976513078228,-6.010066177760259E-4,0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark53(48.05591966247595,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark53(48.155006100680225,-0.4667547625911109,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark53(48.19864998641922,-1.4903326374322585,0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark53(48.19956996282492,-1.011407513407291,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark53(48.20363096998824,-0.9501018095250071,0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark53(4.821435383779061,-1.1292293240765685,0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark53(48.21490600396561,-0.9198245325233343,0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark53(-48.224878969836695,-1.0698936164891821,0.2909523049948657 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark53(48.24547163987323,-1.234942997557333,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark53(48.28279909225721,-0.5414940757606226,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark53(-48.31316349954628,-0.06391496282345828,1.0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark53(48.31406971507442,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark53(48.328987030038974,-0.2921260744459222,0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark53(48.38963052988663,-0.17671805332630752,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark53(48.45702938828103,-0.39286097266479747,0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark53(4.848462406929684,-0.2597916174256983,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark53(48.49550777379345,-1.1560424939173757,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark53(48.49994302117082,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark53(48.50980914510581,-1.2778527956106371,0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark53(48.51051519130294,-0.6412161288302833,0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark53(48.57518010239147,-0.40471140596231825,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark53(4.860301204874311,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark53(4.862239845750411,-1.6383797475451164E-7,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark53(4.8637366355864655,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark53(48.65218498048759,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark53(48.73956327638413,-0.8830113542183238,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark53(48.78622647581995,-0.2952673813117481,0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark53(48.96088959719867,-1.7408937370248024E-9,0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark53(48.967056521536165,-1.499999999999997,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark53(48.985756918332,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark53(48.990534613047174,-0.49556732917987745,0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark53(49.00658147393759,-1.289904545641797,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark53(49.02444383872651,-1.1258845573797684,0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark53(49.095405495827116,-0.31577288333495845,0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark53(49.11875138615923,-0.8212161407004737,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark53(49.128836633872794,-1.4767527758019994,0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark53(4.9132494000082225,-0.025368640469444315,0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark53(49.20924967948739,-0.0426260709436459,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark53(49.226875681977134,-0.12225908124486817,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark53(49.262288491719225,-0.7172331346581755,0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark53(49.272049027648904,-0.754931873276389,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark53(49.27407504525928,-0.1062364846297017,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark53(49.34858051548764,-0.8286681603929082,0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark53(49.490854099165475,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark53(49.522670411468596,-0.7266672867634825,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark53(49.52335495998207,-0.966336172328063,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark53(49.536873522763926,-1.0590297241463729,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark53(4.956067223696635,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark53(4.956853560731261,-0.28500558375348817,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark53(49.57553072649867,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark53(49.59592989231676,-1.9830800436478523E-8,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark53(49.6139997371009,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark53(49.61568876077544,-0.3701448150679649,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark53(49.61805252414892,-0.3513440724632684,0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark53(49.65465352922206,-1.0195593534413376,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark53(4.968651919716962,-1.1812516692200905,0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark53(49.70122005695444,-0.14145205901893831,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark53(49.71134056809285,-0.9353721392327734,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark53(49.71980950443947,-0.9011777004640038,0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark53(49.803979732385876,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark53(4.981668849788321,-0.5495435758200804,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark53(49.82268920883891,-0.7861798189392255,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark53(49.82710331660405,-0.08975013240100793,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark53(-49.85038949027136,-0.297417953554874,78.14554595440751 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark53(-49.86809851578727,-1.4161470011803905E-6,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark53(49.88598854167215,-1.3796234312215265,0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark53(49.917608753525656,-1.2188257137749563,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark53(49.933957389752095,-0.07085879248788451,0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark53(49.93937552251174,-1.128141240048802,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark53(49.969759990430816,-0.4919570550377871,0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark53(49.97778111405965,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark53(49.97996808747763,-0.9569138128664463,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark53(4.998558430054686,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark53(49.998789331690716,-1.3969731553595182,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark53(50.04960014620218,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark53(-50.05146624268954,-0.4453085047492582,-91.95854968333698 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark53(50.10539340487355,-1.4428601474961127,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark53(50.106427280333705,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark53(50.19064632427145,-1.188291857220868,0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark53(50.19665660197738,-0.5350420941959684,0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark53(5.020423821412166,-1.435484722580972,0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark53(50.28509137140199,-0.11869457685397489,0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark53(50.28611594895975,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark53(50.29674457022619,-0.17145791307150282,0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark53(50.35256376080342,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark53(50.373773666570685,-0.06740188119893165,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark53(50.38899076232837,-1.2110998865423625E-9,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark53(50.40621842579203,-0.8795087210740156,0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark53(50.43155862697179,-0.6394392037635726,0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark53(50.44067053109697,-0.1577940813757973,0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark53(50.44884272514685,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark53(5.047919666406557,-0.400445390382687,0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark53(50.51315535819762,-0.1307414217073819,0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark53(50.52826846913098,-0.3637444260876497,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark53(5.0541412225003945,-1.0969106670333442,0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark53(50.56225199174169,-6.646759629392906E-4,0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark53(-50.59445308832806,-1.36786060045408,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark53(50.60007114598005,-0.19435453601189145,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark53(50.63804410724939,-0.9548215246399286,0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark53(50.66436774536277,-0.10715180774433009,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark53(50.68796165138785,-0.08469469256161855,0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark53(50.70236137254358,-0.03885338024055962,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark53(50.724911607388066,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark53(50.765453536280035,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark53(50.79140811563621,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark53(50.793492962378934,-0.38076650309967874,0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark53(50.80733545074443,-1.3735431295019964,0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark53(50.86988979948529,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark53(50.87230514960743,-1.0847707431163477E-7,0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark53(-50.899954909752296,-1.7763568394002505E-15,-51.91595256513641 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark53(5.09176732932896,-1.461195686333383,0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark53(50.92082963340911,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark53(5.092149510505338,-0.4305324861972247,0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark53(50.93732965904141,-1.1208216325030573,0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark53(5.0950596534385255,-0.0394039220466027,0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark53(50.98506720700931,-0.9885391979287697,0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark53(50.98561515949498,-0.9225324139028923,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark53(51.075090837061296,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark53(51.12291075468553,-0.09778956151708296,0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark53(51.17268801999984,-1.3429670879012336,0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark53(51.184582366602314,-0.18657704762591554,0 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark53(51.20639728979535,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark53(51.20660579113704,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark53(51.23043872845432,-1.4979633652304507,0 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark53(51.440421721800526,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark53(51.441279403222474,-1.2129594398300183,0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark53(51.47193639288761,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark53(51.50264285944408,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark53(51.52944242725269,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark53(51.55210854594063,-0.5333472958058829,0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark53(51.566865866348984,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark53(51.57683239685775,-0.7337302271703829,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark53(51.58450167431701,-0.0028630926881909554,0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark53(51.61239590772135,-0.5391799202334937,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark53(51.70843221491691,-1.282864775694557,0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark53(51.73817329727845,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark53(51.894359760856574,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark53(51.907535511829764,-1.0275092040826053,0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark53(51.951035606662316,-0.09996495224770957,0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark53(5.201700094915424,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark53(52.02830884256809,-0.963873791667776,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark53(52.05777368827651,-0.36245790541591916,0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark53(52.07915690223959,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark53(52.13839131308097,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark53(5.214130229176334,-1.1379440203969224,0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark53(52.17630878475072,-1.4545662034704812,0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark53(5.223147042489519,-2.678357261107777E-4,0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark53(52.23684036439337,-0.17268806764174371,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark53(52.24426678459798,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark53(52.25653626035722,-0.35757690174293,0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark53(52.27642329105004,-1.1575855831140671,0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark53(52.29583174785922,-1.2625428209652334,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark53(-52.36909340161091,-0.851123112637989,-30.073945948201313 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark53(52.388311118740944,-0.011565347066753464,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark53(52.43361780515414,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark53(5.244368512684844,-4.058730052354994E-8,0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark53(52.48473852766287,-0.38354154863923734,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark53(52.496356657402345,-0.09975754704929063,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark53(52.50047601935074,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark53(52.54203855753365,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark53(52.55451597292819,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark53(52.556987476442984,-0.24448120676031238,0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark53(5.260100445239116,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark53(52.60604747322901,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark53(52.65801588465996,-1.1167854768501986,0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark53(52.671723736174336,-1.1737430864843056E-7,0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark53(5.267441153725191,-5.666637892349452E-10,0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark53(52.69981696279697,-0.3726294500243337,0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark53(52.70596946705902,-0.9005780374822905,0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark53(52.76517909485207,-1.3696770421410651,0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark53(52.77860944179423,-1.1959404458127478,0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark53(52.78283006623238,-0.10180742656804398,0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark53(52.86882015532343,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark53(52.900061719299345,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark53(52.95371328445319,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark53(52.96647787488733,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark53(52.966769923465904,-0.2291016580892049,0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark53(53.003624728525864,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark53(53.02442244830067,-0.28715257815497974,0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark53(53.052694183100215,-0.27895762357911735,0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark53(53.053537180835235,-3.664766923316564E-4,0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark53(53.0600589778917,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark53(53.10255425709087,-0.5700541154777028,0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark53(53.12319638622208,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark53(53.17467178090345,-0.08063653079000144,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark53(53.207989274974125,-0.12928715113538658,0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark53(53.21550275564968,-1.498994664908198,0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark53(53.23848869855352,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark53(53.28300577989399,-0.36860042771121027,0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark53(53.29345010534229,-0.46204081589851853,0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark53(53.370766434365216,-6.606509997630491E-6,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark53(53.4042957221296,-0.3174668602526456,0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark53(5.342343432132614,-0.011717213885514381,0 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark53(5.344639533404404,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark53(53.45067348335638,-0.8086656643006536,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark53(53.49846774020102,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark53(-53.50956793043316,-2.220446049250313E-16,77.43108919773637 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark53(53.52213215316591,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark53(53.5486066429939,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark53(53.59922334417982,-1.4944248491725123,0 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark53(53.60611869302973,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark53(53.638150276709794,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark53(5.373574457799048,-0.9254927022164736,0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark53(53.742671218607484,-0.9916800272425206,0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark53(53.829005564463074,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark53(53.84898252876286,-0.3458542548170678,0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark53(5.385259669012097,-8.499544338886089E-16,0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark53(53.85301594430865,-1.094874689410733E-9,0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark53(53.97780750320922,-1.4900282968850433,0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark53(53.978102230042026,-1.3073406752703596,0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark53(54.010227398095296,-1.4377714179563081,0 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark53(54.014616043520704,-0.1365886389479556,0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark53(54.02885248220722,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark53(54.04159337133905,-1.1967416049581274,0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark53(54.056203023546935,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark53(54.07120792126827,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark53(54.13066787302651,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark53(54.19291329869237,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark53(54.2839613483938,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark53(5.430616588163538,-0.7946284355297395,0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark53(54.34180661993867,-0.8090602904414913,0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark53(54.34714021818996,-0.5212689450843935,0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark53(54.41492933450132,-1.3703852373973506,0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark53(54.423290925708294,-0.9012971401269891,0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark53(54.478398794548355,-0.44183017711870276,0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark53(54.492241826503204,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark53(54.51218354401948,-0.8049781548920647,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark53(54.53097412069354,-0.8979880331694361,0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark53(54.56990187092657,-0.001422403943670325,0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark53(54.628484037884874,-0.40758704279583635,0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark53(5.463711495548807,-1.365685362884073,0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark53(-54.66285834245792,-0.11943559672012727,-1.0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark53(54.693591486029845,-0.826266279704015,0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark53(-54.73800736800063,-0.20952704475886655,-1.0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark53(-5.474095105802734,-1.1148897947890386,-100.0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark53(-54.76772609715397,-1.4982476142392551,-0.6064332100568179 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark53(54.774894177621405,-1.0277204108678717,0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark53(54.78243131054603,-1.4736837153794162,0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark53(54.83457846281889,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark53(54.85002444791613,-1.1974146630267037,0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark53(54.87203595171771,-1.4999999993741298,0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark53(54.87225962109417,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark53(54.89439408182326,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark53(54.909880264193674,-1.0293726915838555,0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark53(54.924571313288965,-0.3611925147843298,0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark53(54.931096805632876,-1.2464097302774917,0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark53(54.94801840742215,-0.6364827269115824,0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark53(5.4958133651897185,-1.2358047946881499,0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark53(55.01124096765972,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark53(55.119570025585176,-1.1673160804024292,0 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark53(55.121865580378284,-0.20304970212686158,0 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark53(55.127518643643924,-1.2468441109638064,0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark53(55.12897510741428,-1.3016034725027986E-9,0 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark53(55.184126597229884,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark53(55.2004120751846,-0.743738830118474,0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark53(55.22189505227746,-0.3303701226636093,0 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark53(55.30612478063308,-0.7622998273908907,0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark53(55.31475811215114,-0.2288812407088101,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark53(55.31697813975167,-1.4107613037579523,0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark53(55.31703929276027,-1.3557532302449582,0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark53(-55.31840335350719,-1.4999999999999964,0.0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark53(55.32878337446624,-1.2172337565288274,0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark53(55.46442808497872,-0.6787006572923957,0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark53(-55.47296105189795,-1.0949273946255411,0.4232168498248283 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark53(5.5497947768223845,-1.1644437643748233,0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark53(5.551115123125783E-17,-1.4999999999999991,92.28238861115281 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark53(55.595030110937756,-0.976809071695925,0 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark53(55.602813685522875,-0.8431130935059548,0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark53(55.621951349274525,-1.2137722092451804,0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark53(55.674023320391214,-1.1813884941349948,0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark53(5.572874559670723,-0.3180798459025451,0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark53(55.748851249736184,-1.4795793876543366,0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark53(55.767362028306906,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark53(55.78205229618035,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark53(5.582368817030372,-1.0394121458913828,0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark53(55.88429448010632,-1.4328270157477947,0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark53(55.898875680333674,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark53(55.963269390058876,-0.005264933610135181,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark53(56.05297493424919,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark53(56.077237149064025,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark53(56.10683468723397,-0.08760915141642078,0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark53(56.1184484360119,-0.18813591749666614,0 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark53(56.15901377720479,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark53(56.16643056892451,-0.9428495319897365,0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark53(-56.17043399515342,-0.2567075512403708,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark53(5.622247600019776,-0.856497163659962,0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark53(-56.24564659740757,-0.023668292281396552,0.06255252732077765 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark53(56.283587295158625,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark53(56.3410025090694,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark53(56.34987246415187,-1.157471809242365,0 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark53(56.35113185960617,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark53(56.35647586273106,-0.15071259029494155,0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark53(56.42145607598462,-1.1135836309827343,0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark53(56.45752928220591,-1.0327520513457813,0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark53(56.47767255483831,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark53(56.4778408447024,-0.006494515606135565,0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark53(56.4898081738626,-1.2584692374877768,0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark53(-56.525454589534775,-0.17858476602829787,12.085779676789187 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark53(56.57563670553779,-1.4876555588150495,0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark53(56.576246830690025,-0.3109733643241762,0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark53(5.662516158618693,-0.140573176943256,0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark53(56.62608716308884,-0.22584338119249037,0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark53(56.62905257436192,-1.0544187118619726E-9,0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark53(56.64893513357566,-1.0767709539108725,0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark53(56.67836681610788,-1.067396469681599,0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark53(56.70344021033118,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark53(5.682798188276378,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark53(56.985846274125365,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark53(57.05948140911872,-0.6871481399376272,0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark53(57.084953272401364,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark53(57.0885494246868,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark53(57.12608322679185,-0.9821521387016432,0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark53(57.15565378837095,-1.3502210242768721E-9,0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark53(57.16865207098138,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark53(5.720773500181892,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark53(57.25702711610134,-0.46739499530198714,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark53(57.35371491485378,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark53(57.41114450228133,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark53(57.452202709525494,-1.499999999999996,0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark53(57.45688026699642,-0.8176458616093614,0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark53(57.4581993040112,-0.6493250719989634,0 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark53(57.55580096294025,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark53(57.57822240088208,-1.152115091176064,0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark53(57.60655329366,-0.12278432717313237,0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark53(57.61970543777888,-1.0573666971814144,0 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark53(57.65681095085475,-0.7977910967969684,0 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark53(57.668868217716096,-1.0911958705976872,0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark53(57.74277449112759,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark53(57.77470318977262,-1.1108660692174799,0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark53(57.82366845572858,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark53(57.84427410634976,-0.10632988683868305,0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark53(57.88531526268136,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark53(57.959232973995256,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark53(58.001738878348604,-1.4999994060952264,0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark53(58.01701779828255,-1.3684998980954752,0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark53(58.03002758713313,-2.8217122558982826E-9,0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark53(58.032845430813595,-0.03013887663305238,0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark53(58.06482675678625,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark53(5.806838574940926,-0.9538866401877835,0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark53(58.097269710735624,-0.25707147022863663,0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark53(58.14081290798872,-0.3074813264655525,0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark53(58.14829159903735,-0.08654602165382519,0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark53(5.817448363966129,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark53(58.175902850503235,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark53(5.818365070158478,-0.6189413962016754,0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark53(58.184156166733004,-0.5955889139389514,0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark53(58.205976149110114,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark53(58.20961493314013,-1.3604879553354428,0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark53(58.22874209277725,-0.9964335282470813,0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark53(5.822925412863405,-0.47875302754935906,0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark53(58.32272540182822,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark53(5.838016158636853,-7.038821693585237E-10,0 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark53(58.42889435784927,-0.06074759862191659,0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark53(58.43784369523937,-0.04658578077121512,0 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark53(58.44181914112582,-0.18319862791429742,0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark53(58.4607744452297,-0.43403890566904124,0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark53(58.46326351117475,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark53(58.49856146047963,-0.22560496630827576,0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark53(58.54713665906647,-1.1586334520888357,0 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark53(58.57041553798633,-1.4999999999582578,0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark53(58.57164944596167,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark53(58.576048761987494,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark53(58.60282218644355,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark53(58.605554749032805,-1.9169915223210124E-8,0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark53(58.609447339579276,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark53(58.62570470979452,-0.394224758073511,0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark53(58.81491151777993,-1.2148285383237827,0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark53(58.835130758849644,-1.1121344715855344,0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark53(58.89027157749837,-1.1223906150062248,0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark53(58.90944234494066,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark53(58.920398715652965,-1.4645413676286747,0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark53(58.93748860889795,-0.22006126967620032,0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark53(58.98376663714373,-1.3977603841089614,0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark53(58.98840295910628,-66.47585367176019,-12.635365290022165 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark53(59.01039203245665,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark53(59.07787739183457,-0.438163945167116,0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark53(59.132382073102754,-0.5728680708726017,0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark53(59.143373777016166,-0.13420195218005673,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark53(-59.185488893563445,-4.440892098500626E-16,8.952486516443221E-16 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark53(59.20227003084227,-0.6510732760455031,0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark53(59.20825498581064,-0.17516340695265598,0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark53(59.20862656248829,-0.2673737030892003,0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark53(59.2115993949831,-0.4955452321677636,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark53(59.23148189030019,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark53(59.25766235905009,-8.457724919233875E-10,0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark53(59.26378510063748,-0.9295553203062079,0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark53(59.2789597566304,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark53(59.27987158093274,-1.3075090898789009E-6,0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark53(59.291299650496455,-0.38284389372503214,0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark53(59.34917131604516,-1.1863132216768616E-8,0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark53(5.935723106236139,-0.28498027034520845,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark53(59.44668112466513,-0.5462208351276576,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark53(59.46479829825611,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark53(59.47613913038171,-1.4557186984730466,0 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark53(-59.52691209419696,-0.4138565166339415,0.037906628165390345 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark53(59.54012566364531,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark53(59.554430391402605,-1.2550701587948474,0 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark53(59.57762813965067,-1.0478117187708383E-4,0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark53(59.60608446223619,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark53(59.66214124984691,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark53(59.73940204541238,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark53(59.75649428807213,-1.2213414206173212,0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark53(59.77096139393851,-1.4414968694569978,0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark53(59.78622375067724,-0.3185960416804104,0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark53(59.79945929777702,-0.497368151863153,0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark53(59.87399415719713,-0.529322587781337,0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark53(-59.87437701824074,-1.4999999999999964,-1.0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark53(5.98939105102418E-9,-1.2620644146573934,0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark53(59.90586445403799,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark53(5.995759571762462,-1.454616310650566,0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark53(60.00783522450374,-0.6334047207837663,0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark53(60.028610777136805,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark53(60.051661498234836,-1.1183991397342892,0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark53(60.06863071172447,-0.4782592674881698,0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark53(6.0097249069070475,-0.2969986812053844,0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark53(60.12308781414974,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark53(6.013308817329225E-14,-1.499999999999985,0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark53(60.13975826162303,-1.378976942781863,0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark53(60.14613733177495,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark53(60.152848077167846,-1.495913977930698,0 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark53(60.16029837024697,-4.804191077133393E-10,0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark53(-60.1768995984608,-1.0517782414487917,98.39756074307348 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark53(60.20160710464555,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark53(60.22067683048591,-1.0496169996311604,0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark53(60.24029018359232,-1.464000100861802,0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark53(60.26810270264466,-0.3649969374002556,0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark53(60.297453990949535,-0.19267896656827532,0 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark53(60.31104208872787,-0.6561640336020247,0 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark53(6.033337443147233E-20,-0.08094442641626737,-1.000000000321651 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark53(60.379548244517466,-0.6662281263585497,0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark53(60.39224489855705,-0.24661440996714007,0 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark53(60.43055845136886,-0.48668937507389387,0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark53(60.521390211343146,-1.4464188120540125,0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark53(6.055650130353115,-0.2663951454539423,0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark53(60.5927759601806,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark53(6.05975122180981,-1.1781250820352103,0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark53(6.064063111568982,-0.30864779419612365,0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark53(60.661141061065294,-7.0613518374487675E-9,0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark53(60.686475410697284,-1.3105328015115418,0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark53(60.691628764204495,-0.5680029468667752,0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark53(60.716881223536234,-1.3807404727720733,0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark53(-60.72147639049662,-1.499999999999999,-0.10129967699270237 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark53(60.762487287372736,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark53(60.8405622559791,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark53(60.85193318090302,-1.1549234594146487,0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark53(60.86036988729518,-0.29361030605951766,0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark53(60.90310629571006,-0.8148208975203615,0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark53(6.091978505212037,-1.147089328825217,0 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark53(60.92705494009377,-1.1552548847020094,0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark53(60.92869215179692,-1.2021671474441256,0 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark53(60.97952545905268,-1.139732327915717,0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark53(60.98287121883884,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark53(60.99090234417622,-0.7460837802252058,0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark53(61.058356046250935,-1.1088250785852094,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark53(61.063526516404266,-0.07356583624826385,0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark53(61.06884616337217,-1.3434366810905018,0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark53(6.1101162767958925,-0.873361416572457,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark53(61.106762167823376,-0.5889829786159275,0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark53(61.109708549921336,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark53(-61.17203484362151,-0.12295998756266258,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark53(61.19256381328378,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark53(6.125283079251645,-0.9594279176186511,0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark53(61.33049722599027,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark53(61.33991859732158,-0.032003718582261254,0 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark53(61.406726886470935,-1.7637755842056663E-9,0 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark53(61.410242975328345,-0.06993653906550001,0 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark53(61.420664782693166,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark53(61.43001892321287,-0.14531472121126887,0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark53(61.43194305822371,-0.5277210949177018,0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark53(61.4477608876289,-0.08837171557005519,0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark53(6.14880581437059,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark53(61.49690665003717,-0.6805645485684904,0 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark53(61.52855824741022,-0.5127219742150881,0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark53(61.603869146223474,-0.10914049148631344,0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark53(61.6188578868902,-0.1544332263736592,0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark53(61.664687606332365,-1.2137091489628498,0 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark53(61.68117084848723,-1.0590856885511108,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark53(61.68492335633836,-0.017873160991475026,0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark53(61.787365736402336,-1.448128912520815,0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark53(61.85889566836574,-0.14286736625377583,0 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark53(61.88525292017695,-0.9483037969336436,0 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark53(61.89398139019992,-0.3119147603233774,0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark53(61.90958984663493,-0.3752336092180286,0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark53(61.91672641801893,-0.7367605468910057,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark53(61.95486894908571,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark53(61.99139318540457,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark53(61.99940578735584,-1.3073370974547283,0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark53(62.00952566600192,-6.598360659195927E-10,0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark53(62.06670283707021,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark53(62.11948733090159,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark53(62.12864331634862,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark53(62.166614573055,-0.43254780760368305,0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark53(6.219598793330633,-1.1124163314008806,0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark53(62.20625316050379,-0.8893055972712389,0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark53(6.222433472297382,71.67701927606666,73.78262200188027 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark53(62.253923453406316,-0.9331498558643171,0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark53(-62.3411626416702,-1.2046798627254902E-8,0.8881431059354385 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark53(62.35238292843772,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark53(62.36145967855896,-1.4106555502284834,0 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark53(62.40549935304208,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark53(62.433059310053636,-6.061305496819845E-10,0 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark53(62.49127280254251,-1.4999999999999538,0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark53(62.517069408063854,-0.8477416269689265,0 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark53(62.55146358283329,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark53(62.5621043163098,-0.15575605930340308,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark53(62.593860974588466,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark53(62.61831371305425,-0.7523174650633422,0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark53(62.62430308406266,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark53(62.63799660335806,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark53(62.69625849047242,-0.4674285671516706,0 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark53(62.71078528808499,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark53(62.720488941096086,-1.2251943056629448E-7,0 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark53(62.765150770237845,-0.43004569946276305,0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark53(6.277881484277338,-0.003181823895382479,0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark53(62.817262707456905,-0.5347485968045653,0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark53(6.283795234112381,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark53(62.8594094652609,-1.2929462622144179,0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark53(62.90523459313084,-1.3342414643615825,0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark53(62.91811437305874,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark53(6.295362790437725,-0.18600980639806153,0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark53(63.0105588918443,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark53(63.03883494722156,-9.847953947686932E-10,0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark53(63.05985951926661,-0.8131080435702508,0 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark53(63.13066247353693,-0.4114111220767431,0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark53(63.1322223093169,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark53(63.158999871679754,-0.011946182330831334,0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark53(63.16219797757433,-2.328673585537781E-7,0 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark53(6.317280573512301,-0.22926848038871128,0 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark53(63.21821958355346,-0.07770389876998962,0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark53(63.25521040145735,-0.45554730310649205,0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark53(63.26231419797938,-0.3930738827204312,0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark53(63.267723640587064,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark53(63.270704218171545,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark53(6.328521213242986,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark53(6.330664268928924,-0.717976502071918,0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark53(63.33185029186053,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark53(63.35789112544572,-0.5924378751360617,0 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark53(63.46121609363942,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark53(63.48811107808288,-0.2963732593643318,0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark53(63.50972449585521,-1.4181095963458623,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark53(-63.575881007685716,-6.154621783291422E-15,1.0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark53(63.58162204447375,-5.497481839147563E-5,0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark53(-63.69722975095819,-1.1446946067856345,-74.77962149943332 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark53(6.371200658679914,-0.9709640316183579,0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark53(63.71243293899977,-0.5652040459324024,0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark53(63.97626058108856,-1.4960978208219609,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark53(6.400264034739962,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark53(64.04467750863367,-1.4330325452754238,0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark53(64.04689916072965,-0.26345131380676223,0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark53(-64.05252399618598,-0.7394347868349919,0.014826491527736962 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark53(64.09688999944488,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark53(64.12614779574395,-0.2666232433962261,0 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark53(64.17093102779802,-0.5377516101687974,0 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark53(64.17465080356709,-0.15657317158401396,0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark53(64.17693781420937,-1.3624629973465403,0 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark53(64.27306693743856,-1.0188199941529472,0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark53(64.28497117768453,-1.1250869856367922,0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark53(64.28734984606419,-0.5092698010334109,0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark53(64.28783883791368,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark53(64.31272483865934,-1.2004460158331796,0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark53(64.33168372646006,-0.12195267063982926,0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark53(6.434130402855761,-0.012589390401714917,0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark53(64.3614103930727,-1.4121789689659947,0 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark53(64.3727210899473,-1.3396936331463394,0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark53(64.428159185131,-0.23542629419133831,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark53(64.49010338623881,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark53(64.49619718794258,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark53(6.4515499999838255,-0.31925904111511727,0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark53(64.52442849403417,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark53(64.55690472806477,-4.854662230527045E-8,0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark53(64.57058050388426,-1.2130540419262206,0 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark53(64.57867521943544,-1.490670298339683,0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark53(-64.59182924429832,-1.4999998758228166,1.0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark53(-64.6821148186531,-8.875230772759416E-5,0.1816054736486039 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark53(6.473728285787317,-1.2848656598705936,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark53(64.7555068811254,-0.08034345095785067,0 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark53(6.476241138924294,-0.7394228736787358,0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark53(64.95333819389504,-0.7750079276978834,0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark53(64.95475447611656,-0.3005929059824808,0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark53(65.00615702147084,-0.444305171639214,0 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark53(65.04447216045287,-1.3925098234483113,0 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark53(65.10188582168168,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark53(65.13241355600755,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark53(65.1391648514038,-1.0196303338695714,0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark53(65.15699762645423,-1.421684739176115,0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark53(65.1826683491534,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark53(65.18845267222451,-0.1470214573766706,0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark53(65.2532176567023,-0.5119280260318959,0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark53(65.27495508491455,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark53(65.28578307239934,-1.0980854255925578,0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark53(65.36739283899755,-0.7095927142583918,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark53(6.542445357981885,-0.04659451352986321,0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark53(65.44078472672496,-0.4157388362349863,0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark53(65.50784202496641,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark53(65.5784093311934,-1.0656402771847144,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark53(65.61796202563114,-0.044810168010572804,0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark53(65.6529970242994,-0.23004746317253932,0 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark53(65.66304058564225,-0.7036242865542448,0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark53(65.71098550631555,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark53(65.72120063057828,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark53(65.7396687857877,-1.1534077111756176,0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark53(65.75573259307163,-0.14987792517315723,0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark53(65.8027810063083,-0.8944382264411441,0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark53(65.85130718856533,-0.0016854319733888496,0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark53(65.87051928047532,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark53(65.96122257457952,-1.3780104614566655,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark53(65.9727027831216,-1.443568591986029,0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark53(66.00477464025263,-1.46035232069738,0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark53(66.00532969657235,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark53(66.05761705927281,-1.338471635183538,0 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark53(66.06701201248995,-0.6191356622919164,0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark53(66.09206033794061,-0.1495921374283995,0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark53(66.12124248052959,-1.0305418134412685E-8,0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark53(66.13012048440918,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark53(66.16915069930883,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark53(66.17233289530142,-0.37011400503341885,0 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark53(66.17337199848711,-0.09264921618549238,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark53(66.21334120776316,-1.1446536940935028,0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark53(6.623454542870511,-4.659097858517322E-8,0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark53(66.30723140566717,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark53(66.34924704639155,-0.7010567544033511,0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark53(66.34983630898685,-0.5053800365717769,0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark53(66.36443582208582,-1.1748194526834084,0 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark53(66.41320495696506,-8.787723814811808E-10,0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark53(66.45218042522654,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark53(-66.59063818649284,-0.6764941325003105,-2242.874669011078 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark53(66.63709884924626,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark53(66.65009587810431,-0.5869755377956916,0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark53(66.729809260699,-0.4236140792515686,0 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark53(66.73823984199187,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark53(66.73981318328853,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark53(66.7616011144303,-1.1975666339171056,0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark53(6.678704262917699,-0.7984086452008361,0 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark53(66.79110684767548,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark53(66.81359152039747,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark53(66.81576743589349,-0.9633783569296117,0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark53(66.89949255419128,-0.10735814387108178,0 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark53(66.93330184429163,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark53(6.6936764390687244,-0.1391574590575376,0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark53(66.94746668240333,-0.5441063007101032,0 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark53(66.94753501768463,-1.2508094704270576,0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark53(66.99746362490339,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark53(6.700569352128966,-0.014059155657941247,0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark53(67.0571334447445,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark53(67.06416879258214,-4.03942639981865E-9,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark53(67.12775691464232,-0.36403629572891694,0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark53(67.1335546174958,-1.3786215335051972,0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark53(67.14309705970555,-1.072040988494845,0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark53(67.1499363230174,-1.0088664909448322,0 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark53(67.17000640622066,-0.3659512230259976,0 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark53(67.1907652882021,-0.008427196998173514,0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark53(67.2131986417882,-0.4134858330979798,0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark53(67.21944869630673,-1.2389574003791664,0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark53(67.2645837730689,-0.33682205375157004,0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark53(67.29140589252722,-0.34885397384628325,0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark53(6.729185485780064,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark53(67.29948210876532,-0.006930495448182139,0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark53(67.30779737851262,-0.26643679137966547,0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark53(67.31432551393164,-0.14665043457101845,0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark53(67.3476994111729,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark53(67.35592467976738,-0.9957976929318022,0 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark53(6.736115526320651,-0.8350560617057141,0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark53(67.366946383602,-1.369289696050707,0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark53(67.3801567075348,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark53(67.4607206602941,-0.5409160932113348,0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark53(67.49214100172237,-0.5113190745689877,0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark53(67.51314570417006,-1.2357662189942238,0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark53(67.51698495372217,-0.20103325810212613,0 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark53(67.55280375361619,-0.1536748571876032,0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark53(67.57349443619663,-0.26340514932599757,0 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark53(67.68533204630484,-1.1360551236373624,0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark53(67.70925963753533,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark53(6.7748643584490065,-0.013884006578607855,0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark53(67.75405156733856,-0.07092850158066244,0 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark53(67.78223440645621,-0.19369719411875064,0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark53(67.82521433474012,-0.5060208345318349,0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark53(67.83976473826594,-1.4809853621145057,0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark53(67.84548814310708,-4.683917073364309E-10,0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark53(67.91494734340097,-0.003375155368175767,0 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark53(67.97572285293087,-2.617343291656652E-7,0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark53(68.00718177763275,-1.084938853800077,0 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark53(68.0283471841983,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark53(68.03835402895295,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark53(68.04080832615853,-5.144468907609912E-10,0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark53(6.807176995233078,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark53(68.16143169325142,-0.1955826707575028,0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark53(68.17592320921929,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark53(-68.19188423027279,-0.053496877743897955,0.9999999999999986 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark53(6.82009997034125,-1.1541580672065002,0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark53(6.821989936669024,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark53(68.2544508259009,-0.36717684396786865,0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark53(68.36374796945879,-0.4683464869191969,0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark53(68.3963983182575,-0.19354644813906452,0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark53(68.3988448608845,-0.9141887177345098,0 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark53(6.840586602245779,-0.13619505556984413,0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark53(68.44186569637367,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark53(68.45286679445569,-0.9045737379278176,0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark53(68.46077098249395,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark53(68.49475868485743,-1.1582175222738726,0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark53(68.52423251853452,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark53(-68.5778720483807,-1.4999999999999964,35.83921820666163 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark53(68.63965923461765,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark53(68.71893704653576,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark53(68.73797032705163,-2.898774669470202E-7,0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark53(68.75550970343195,-0.9329386799931876,0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark53(68.77861889082834,-0.015473959176347307,0 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark53(68.78730501430121,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark53(68.79889348461279,-1.9629476866444227E-9,0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark53(68.92184456225914,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark53(68.9284036978604,-1.1937529136329825,0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark53(6.894550560773098,-0.965901841868587,0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark53(68.94635684722167,-0.518604137255287,0 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark53(68.96414223039949,-0.6486694490026563,0 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark53(69.01248234019825,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark53(69.0190945561101,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark53(69.05811388702764,-1.0296933479696473,0 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark53(69.13625292282362,-0.8799827865716168,0 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark53(69.18154716371347,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark53(69.19247198499485,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark53(69.20713328248024,-0.7857392947091029,0 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark53(69.23494664306534,-1.2745680549890555,0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark53(69.26725344385508,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark53(69.32994184400007,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark53(-69.37416214806592,-2.220446049250313E-16,-0.34232004222797996 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark53(69.37956942250494,-1.02111673293154,0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark53(69.43186570444982,-0.7249286996937769,0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark53(69.44356913128021,-0.372347363559443,0 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark53(69.45093494907917,-0.33949054543562784,0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark53(69.5304104985795,-0.01524554648555932,0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark53(-69.60684745708394,-3.9069464028458953E-4,-1.0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark53(69.64243787084982,-0.44025412186073254,0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark53(6.965072501580806,-1.4600881508599595,0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark53(69.69036883647982,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark53(6.972753457552568,-1.2240983160051686E-9,0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark53(69.76317295550672,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark53(6.977789511030572,-0.5197100425463415,0 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark53(69.79212051320042,-1.0170746444201342,0 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark53(69.82402239227248,-0.8091113839912447,0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark53(69.83031372002714,-1.0763329529614358,0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark53(69.85497784572021,-0.6519811602868266,0 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark53(6.988272896769601,-0.5396912702091202,0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark53(69.91082401251094,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark53(69.93145275583353,-0.8356174328363153,0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark53(69.94431503011697,-0.2501412184367613,0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark53(69.95025612693948,-0.30264052142254627,0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark53(69.95771236875541,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark53(69.99110737719943,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark53(69.99328394099328,-0.8378333192116116,0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark53(70.00099599332202,-19.76182076937863,34.44371233081887 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark53(70.02878120199483,-0.2405794906985932,0 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark53(7.011191042623864,-1.471218440879404,0 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark53(70.13584088172036,-0.18525801041059609,0 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark53(70.1714207492322,-0.13730177470892913,0 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark53(70.17548055519197,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark53(70.19265403373852,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark53(70.28111019552247,-1.2598937948610134,0 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark53(70.28633177806708,-0.20576516917188203,0 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark53(70.29519830660868,-1.1031406034523659,0 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark53(70.3227271998585,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark53(70.38942245768153,-0.25287970833713047,0 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark53(70.43536470908322,-1.0407293298205205,0 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark53(70.44305275081271,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark53(70.49703353532934,-1.4999999999999787,0 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark53(70.51971930468625,-0.11536898091528208,0 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark53(70.53323146932729,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark53(70.57126904623908,-1.3571767546226852,0 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark53(70.60805702005914,-1.1271817618623317,0 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark53(70.60976231351461,-0.5532708587789585,0 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark53(70.71390074591288,-0.21944293976454887,0 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark53(70.74266237292596,-0.4112112550999881,0 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark53(70.7575182360768,-0.2825972587166916,0 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark53(70.776359989019,-0.444184228423687,0 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark53(70.8362624735376,-0.03690780650899686,0 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark53(70.88406270586188,-0.40917539547976306,0 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark53(7.089951289549724,-0.16065290739039462,0 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark53(70.90045461869465,-0.6729839648898697,0 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark53(70.90801775617045,-1.2983642251592291,0 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark53(70.91548158172205,-0.048540431867152734,0 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark53(70.93810285197597,-0.284179660150732,0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark53(70.9970149335926,-6.900429382291345E-8,0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark53(71.01421040259632,-0.0950801124836258,0 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark53(71.02193817053127,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark53(71.02446689896072,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark53(71.02545625712452,-1.2405175107299868,0 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark53(7.10357921185296,-0.38582973809158005,0 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark53(71.04660610822053,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark53(7.105427357601002E-15,-0.3326361214025422,0 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark53(7.105427357601002E-15,-0.49749831340850914,0 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark53(7.105427357601002E-15,-0.888239686305937,0 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark53(7.105427357601002E-15,-2.3428530829007394E-15,0 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark53(71.06321699106402,-0.6722631395526837,0 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark53(71.11673949024936,-0.7068066182253248,0 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark53(7.117700757432519,-1.3280346966152983,0 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark53(71.18717381244984,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark53(71.19249041019395,-0.03689223580079215,0 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark53(71.25828562509183,-0.6774960040128093,0 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark53(71.26662070180097,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark53(71.30279614559268,-0.3841219810134251,0 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark53(71.31501080969306,-0.6798200605342455,0 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark53(71.3509019421991,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark53(71.37046163846654,-0.6911750445073324,0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark53(71.37594612278201,-0.997221479376972,0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark53(71.42169641309025,-1.0985415660820697,0 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark53(71.43341982933714,-0.26311194959269013,0 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark53(71.54004243218023,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark53(71.55678419601179,-0.6164113675623044,0 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark53(71.59603578445547,-0.5439214984052825,0 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark53(71.66877665005643,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark53(71.68138822566436,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark53(71.70273416969597,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark53(71.70404469456828,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark53(71.73934125280533,-1.3385880586412497,0 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark53(7.183225923730303,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark53(71.8605707071786,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark53(71.89162427382684,-1.267104150397432,0 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark53(71.9334461391631,-0.0865134658638927,0 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark53(71.95524773438208,-1.2901748720828219,0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark53(72.02136398815925,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark53(-72.09345934996702,-1.285825807586962,-0.2027319162297817 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark53(72.1446144979806,-0.17234403215864447,0 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark53(72.17682676251532,-0.22218136994969395,0 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark53(72.20025960964597,-0.3564761638644458,0 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark53(72.25865059226268,-0.8733908969731345,0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark53(72.26638756034885,-1.499972301087739,0 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark53(72.2757648211809,-1.2892409796105173,0 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark53(72.35260811470268,-0.0025478820702451023,0 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark53(72.35876577996156,-0.042715336444809696,0 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark53(72.3789737410033,-0.2995319226950923,0 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark53(72.37988219929582,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark53(72.38738559862313,-0.9002761024967008,0 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark53(72.41815072805025,-0.789819451136168,0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark53(72.43918784028014,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark53(72.43948465387116,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark53(72.46500211758527,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark53(72.46929914721704,-0.41406124833991953,0 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark53(72.5187723027168,-0.3728234434878037,0 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark53(72.58395638504396,-1.2010608823408297,0 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark53(72.59059965859188,-1.2343977674213562,0 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark53(72.65224991589905,-0.35341915033440485,0 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark53(72.70772714133312,-1.3702386476978319,0 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark53(72.7077421766027,-1.3664265858009417,0 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark53(72.71778244247422,-4.3263781265361297E-7,0 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark53(72.7464467888147,-1.0133313774414887,0 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark53(72.74929668040653,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark53(72.82715799890428,-1.4019401259111754,0 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark53(-72.83329889786658,-0.946191214854113,27.414331628799403 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark53(72.87027055775292,-0.4619778332840987,0 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark53(72.88263757209009,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark53(72.88913200074961,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark53(72.90849032345383,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark53(72.92111059947473,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark53(72.92153051964357,-6.011828931841804E-7,0 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark53(72.96509433891535,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark53(73.00589609685139,-0.5640466933269201,0 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark53(73.06346200235222,-0.423014225869218,0 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark53(7.307135320364846,-0.8208363209222114,0 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark53(73.07562207045592,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark53(7.308394157195839,-0.4068370120829915,0 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark53(73.0997875377131,-1.4155419278781096,0 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark53(73.17230701956909,-0.681998443840909,0 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark53(73.24721398934025,-0.42996680651665997,0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark53(73.27557380146537,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark53(73.28461964485328,-1.0295559295309022,0 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark53(73.33493003188929,-0.3905475998901722,0 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark53(73.34187529654835,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark53(73.35234869500493,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark53(73.359018214885,-0.7193235517273591,0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark53(73.35983032985814,-0.762538511324621,0 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark53(73.37983998656574,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark53(7.345533278097288,-3.013530153758369E-8,0 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark53(73.5710142357934,-1.421770389825399,0 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark53(73.58086907553997,-1.323408019248923,0 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark53(7.35927994671237,-1.214327929450846,0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark53(73.60893040209947,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark53(73.64144632548243,-0.23579660700517024,0 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark53(7.366876314540448,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark53(73.70957992796653,-0.07331206843520233,0 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark53(73.73328216960192,-0.4289103469722253,0 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark53(73.74406998442967,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark53(73.75441702903478,-0.20260357588286126,0 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark53(73.86967043790861,-0.6314008380573739,0 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark53(73.90492957240203,-0.7757930143018589,0 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark53(73.98523875634419,-1.4765316237524928,0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark53(7.399136537588616,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark53(74.12457789014414,-0.5996467819919076,0 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark53(74.17317955610653,-0.6174590251527974,0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark53(74.17739381002494,-1.3699028113875498,0 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark53(74.19951492622259,-0.7653592918340988,0 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark53(7.421586375975252,-0.06480645199035706,0 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark53(74.25421985402804,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark53(74.30083683601256,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark53(7.431440449645805,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark53(74.33351138424044,-0.7532641453724267,0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark53(74.35741633691617,-9.963949295346385E-7,0 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark53(74.39348902680797,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark53(74.41842035348353,-0.22394173191537448,0 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark53(74.45977488095357,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark53(74.46634887957336,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark53(74.48397035979642,-0.6630810034174743,0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark53(74.48431196004233,-0.1933531946730227,0 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark53(7.450826694859813,-1.299259660027535,0 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark53(74.54542056931373,-1.364703439613045,0 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark53(74.5548995403114,-0.005440370968264281,0 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark53(7.457719542533674,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark53(74.58759998521447,-0.9754363674134692,0 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark53(74.64960265745884,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark53(-74.65937519268094,-1.4999999999999998,-0.20529005225584473 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark53(74.66864233884273,-0.02033351705612639,0 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark53(74.73986924602622,-1.106309955524381,0 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark53(74.74539056548399,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark53(74.7553397374009,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark53(74.91011319567943,-0.43143860636905274,0 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark53(7.494568093936664,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark53(74.97496229918738,-1.4055418346796529,0 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark53(74.98777533361692,-0.06154073582469266,0 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark53(74.99044070837334,-0.7859642886157303,0 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark53(75.12352080638324,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark53(75.12391032319245,-1.4999999735542373,0 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark53(75.13043104544167,-0.17125702194241033,0 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark53(75.13915667092786,-0.10489293631190222,0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark53(7.514478792940459,-0.8401111857930605,0 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark53(75.1657159797108,-0.19369418315286602,0 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark53(75.18034963738552,20.47884824572968,75.67149218854163 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark53(75.20465834187942,-1.3954361219815266,0 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark53(75.21215942640146,-1.0505852705375816,0 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark53(75.25204927141041,-0.6456009648174685,0 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark53(75.28544357236487,-1.0673118192024125,0 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark53(75.28966290223829,-1.0244112908638385,0 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark53(75.34942575314761,-0.6057464537545769,0 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark53(75.36782511796753,-1.4445901124964529,0 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark53(75.38766097849384,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark53(75.38906092479496,-1.1121502221057398,0 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark53(75.39489656059497,-1.4822500460901402,0 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark53(75.41569357841885,-0.9027150423522794,0 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark53(75.44252880136864,-0.5657314219610532,0 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark53(75.46149599792912,-0.1214345452335911,0 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark53(75.53766951918377,-0.5664002096794718,0 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark53(75.55187824021546,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark53(75.6015553893788,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark53(75.66421642142058,-1.4200547285857539,0 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark53(75.78545180115273,-0.20957310096352444,0 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark53(75.78777169120195,-0.015773803229993444,0 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark53(75.80138435604877,-0.8285449203549712,0 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark53(75.80855126976175,-0.6093800036878505,0 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark53(75.81692336816039,-0.6731453111780703,0 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark53(7.59126189277805,-0.13040838422301304,0 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark53(7.5945298617973815,-2.6804831752287256E-6,0 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark53(75.94783052706147,-1.3868250411978793,0 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark53(75.9899749269085,-0.49241456557930974,0 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark53(76.0193230252295,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark53(76.04538426285151,-0.09786342518549546,0 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark53(76.05143460404108,-1.4999999999999978,0 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark53(76.13157147277758,-0.13383988016082693,0 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark53(76.22401760058045,-1.3097981253717936,0 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark53(76.25366175931171,-1.4999999999999645,0 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark53(76.25786641838783,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark53(76.3016191153948,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark53(76.3117520396894,-1.272450632117596,0 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark53(76.32098933258777,-1.1198353360452344,0 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark53(76.38231510613599,-0.10371199130040598,0 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark53(7.6412789490391475,-1.1644194158780392,0 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark53(76.57006944263878,-0.11919745348826288,0 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark53(76.65812064717,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark53(76.6714524713559,-1.0622730927775068,0 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark53(7.66719688100909,-1.1373149443381871,0 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark53(7.667808248313435,-0.49440464248729654,0 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark53(7.66876663064042,-0.45595501668540606,0 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark53(76.70251379907094,-0.04218964273377157,0 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark53(76.76763880380463,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark53(76.78215130019396,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark53(76.78448521548378,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark53(76.90814163733697,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark53(7.692287898180391,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark53(76.92433929943265,-2.407764298463655E-7,0 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark53(76.94237993230513,-0.7914345559726903,0 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark53(76.94996717557387,-0.7655111992452674,0 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark53(77.04973029315428,-0.6631429933728441,0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark53(7.708707139994299,-0.3600682039373555,0 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark53(77.11371024309713,-0.21220201386447002,0 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark53(77.13204603898751,-1.493071997057129,0 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark53(77.1864992626536,-0.4756322961075419,0 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark53(7.725084100934637,-0.26882920177754954,0 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark53(77.29034534594103,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark53(77.29164190935478,-0.03886669973178926,0 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark53(-77.34610581504161,-0.9493250887878564,-0.03327219161865913 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark53(7.737114771541158,-0.519153414431401,0 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark53(77.3727288221692,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark53(77.4217552277384,-0.5458322104267834,0 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark53(-77.42566572594504,-0.012534015423596135,-1.0 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark53(77.44292413095586,-0.9333556474696483,0 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark53(7.753602390620436,-0.2556253440652789,0 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark53(77.5717084366307,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark53(7.760596831534805E-16,-0.45571832055320866,0 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark53(77.61081821947971,-0.2559623216615554,0 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark53(77.6273299032073,-0.1381864348070212,0 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark53(77.65757381997419,-0.9368227009693217,0 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark53(77.66899931400451,-0.8221626423567017,0 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark53(77.73843232128252,-0.8615018873856606,0 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark53(77.79208878733269,-1.2719627008111778,0 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark53(77.79925274308647,-0.6706425082562424,0 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark53(77.809650269613,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark53(-77.86279578489247,-1.0390959974569178,1.0 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark53(77.89014021617089,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark53(77.94836647212776,-0.9414152048532751,0 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark53(77.95240215974263,-0.599753102909375,0 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark53(77.9764216586093,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark53(78.09689457213204,-1.3815844781366413,0 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark53(78.10557330303033,-1.2661939553493937,0 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark53(78.13078744117121,-1.4999999999999805,0 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark53(78.1550663192294,-0.9744692497422296,0 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark53(78.17717868647523,-1.3540697590726012,0 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark53(78.20986837634051,-0.4184785980343513,0 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark53(78.21335946107234,-0.22534852958995089,0 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark53(78.27657816738639,-0.022355037059133664,0 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark53(78.31574049063394,-0.2752401386242078,0 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark53(78.32365698504279,-1.496729846396523,0 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark53(78.40208189910481,-0.7163911315612328,0 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark53(78.40227983588706,-1.274020570311793,0 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark53(78.41926660936656,-1.514063452311342E-8,0 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark53(78.42266706657973,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark53(78.43902734652207,-0.12059243397176989,0 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark53(78.46881321597797,-1.2628969264977457,0 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark53(78.49356594689428,-1.3623279462010824,0 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark53(78.50506368630789,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark53(78.54775956697996,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark53(78.60933558943282,-2.622784091576697E-8,0 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark53(78.61068126000302,-0.4994368466296302,0 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark53(78.63054002468147,-0.5561195473476914,0 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark53(7.8638827256278,-1.223835655867843,0 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark53(78.70597518506156,-1.1541262349552692,0 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark53(78.75604435861123,-0.29135670780550527,0 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark53(78.84989724385619,-1.204438531664609,0 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark53(78.87234521402289,-1.3063020201816429,0 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark53(78.89406282639901,-0.24187932165561365,0 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark53(7.892362772281922,-1.1502020144658516E-9,0 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark53(7.895165801407,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark53(78.95294021404945,-0.02586075771403129,0 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark53(78.96468185586508,-0.02961836859154232,0 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark53(7.89673185050448,-1.4907862629764916,0 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark53(79.07375625133488,-0.5712620829140524,0 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark53(79.15453178289101,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark53(79.15731441817638,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark53(79.20681246397774,-0.12729630084844246,0 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark53(79.21583605057799,-1.0996727063566105,0 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark53(79.3117525596029,-1.4977855857790874,0 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark53(79.32729347851202,-0.7471143588299913,0 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark53(79.34525911974822,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark53(7.935984108739577,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark53(79.36753980343784,-0.7464227676607362,0 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark53(79.50581962793575,-0.2722679928526528,0 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark53(79.51387015038728,-0.7683383548922578,0 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark53(79.51554795333243,-0.8781140448816026,0 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark53(79.54348913183094,-1.3780338737121038,0 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark53(79.55619276835691,-0.055200086586656205,0 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark53(79.58432882467258,-0.3822940242963435,0 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark53(79.59426254078147,-0.5962522988507706,0 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark53(7.9602731821829025,-1.4596647945996208,0 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark53(79.62000115821789,-0.15220126511168264,0 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark53(7.962444731819417,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark53(-79.64037817804271,-33.96607609846309,80.77120900395303 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark53(-79.64262339459293,-0.4585672102035383,1.0 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark53(79.7191662609807,-0.4966142728408869,0 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark53(79.76456226210763,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark53(79.79911354766972,-1.3584495121360214,0 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark53(7.98740641196494,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark53(79.88951842775342,-1.1162377841940554,0 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark53(79.90462009116573,-1.3428601266695495,0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark53(7.990707742128251,-0.14092310045490342,0 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark53(7.993519752496709,-0.3825069263086319,0 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark53(80.0656601286604,-0.9602474624330837,0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark53(80.09000111686086,-0.49873094101902193,0 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark53(80.09923704244588,-0.3540577231609916,0 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark53(80.11028759504552,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark53(80.16023298619548,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark53(-80.22850968778528,-0.5254023498376476,-36.37181979965565 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark53(80.26862233622352,-0.04090342440096961,0 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark53(80.28499901735316,-1.3061907059061637,0 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark53(80.2852785462556,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark53(80.28903297316052,-0.27631738711440623,0 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark53(80.29218147822885,-1.3148011598483125,0 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark53(80.33077284489201,-0.08492758401827905,0 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark53(80.34914501171357,-0.26956604487621405,0 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark53(80.55190318930475,-7.253376411067488E-8,0 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark53(80.65279365396012,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark53(80.69551550107892,-1.4861730167494223,0 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark53(80.70952447744165,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark53(80.75926978420856,-0.8531500419449074,0 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark53(80.8128850193643,-0.6916360402930062,0 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark53(80.82340065223599,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark53(80.8361041237896,-1.4117301843791132,0 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark53(80.8459969983982,-0.2776577511841157,0 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark53(80.93981454105827,-1.2086408205945531,0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark53(8.09409531804593,-0.9859434403618108,0 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark53(8.0948E-320,-1.259991753941631,0 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark53(8.095330176966826,-0.9949793197257178,0 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark53(81.00058989724913,-0.2793541923363745,0 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark53(81.05690889070817,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark53(81.08178109847974,-0.5000792041006008,0 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark53(81.16043849446444,-0.1516974006653129,0 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark53(81.1796790796719,-0.2591961790517492,0 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark53(8.118733670139566,-0.2608121120417536,0 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark53(81.25919053105582,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark53(81.29324640389498,-0.9216618060523416,0 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark53(-81.31924086083342,-1.2262457143888135,6.430137917084498E-7 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark53(81.32353693207217,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark53(81.3463010804561,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark53(81.45583494711809,-5.798215577832556E-10,0 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark53(81.45805034882267,-0.4395263282259015,0 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark53(81.47472342762592,-1.771392086432315E-8,0 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark53(8.162904270346232,-0.27217157570557227,0 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark53(81.67696914471506,-0.44888033899625324,0 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark53(8.18197032212673,-0.060325430825316995,0 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark53(81.83105876651084,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark53(81.8777922680504,-0.42929686719685023,0 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark53(-81.877874809145,-0.054290616838778116,-1.0 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark53(81.89000435104981,-1.0120261895946954E-15,0 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark53(8.18954436052363,-0.9201604808482615,0 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark53(81.89731046539492,-0.1468603260596052,0 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark53(8.193165092643632,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark53(81.94267184256643,-0.8787966450663719,0 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark53(8.195656502818998,-1.1386644768502492,0 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark53(81.9598397288286,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark53(81.97018360775833,-2.4356296758004466E-4,0 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark53(82.02971960580297,-1.0718101910907416,0 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark53(82.03207039214206,-0.8646802074617561,0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark53(82.08533494712617,-1.4789042609612308,0 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark53(82.11614509616055,-0.8864187244203021,0 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark53(82.11704542717303,-0.24553037067813796,0 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark53(82.18057458528159,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark53(82.2416415823931,-0.3355207019448727,0 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark53(82.36214299102741,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark53(82.36922992518751,-0.2126666354122584,0 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark53(82.37134809957328,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark53(82.45290674008555,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark53(82.45996480949898,-0.2982122156487357,0 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark53(82.4725112756385,-1.4301623264922654,0 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark53(82.47700565063543,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark53(82.50239729969347,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark53(82.51035378079794,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark53(82.61480235452964,-1.378754291089411,0 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark53(82.68914341834972,-0.09888232020273624,0 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark53(82.6958150037427,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark53(82.70041951589536,-1.4358163422534886,0 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark53(8.2711639102362,-9.573137024150517E-9,0 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark53(82.75397158992547,-0.5069323765213218,0 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark53(82.777433826356,-0.6339567080476094,0 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark53(82.80478854692356,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark53(82.85671974121635,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark53(82.94878794005103,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark53(82.95301795582768,-0.5969341821479972,0 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark53(82.9668286065851,-1.148931555192334,0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark53(82.97864632498414,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark53(8.308423124385097,-1.210356946057678,0 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark53(83.14997076200751,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark53(83.189859809506,-0.6134531918772503,0 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark53(83.20462550955781,-0.42242686861902357,0 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark53(83.29647566632872,-0.550808485905474,0 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark53(83.33066447506498,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark53(83.35250722033356,-0.5636877592590537,0 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark53(83.35700338721125,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark53(83.35933138477122,-1.3611405508225272,0 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark53(-83.3741899317258,-2.7755575615628914E-17,-0.039288295355437236 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark53(83.37508493435344,-0.6540516772448832,0 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark53(-83.38740426925338,-1.0690642677222968,-1.0 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark53(83.42676460206755,-0.5174063006586027,0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark53(83.45157903609433,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark53(83.46271053684723,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark53(83.51918478110105,-1.4345739346521365,0 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark53(83.57577388056964,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark53(83.62968984286559,-1.125284961541226,0 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark53(83.63306846733694,-1.012543852441664,0 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark53(83.73127543409286,-0.7999424604881966,0 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark53(83.84507861379345,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark53(83.87641323782444,-0.22435988604880563,0 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark53(83.90857045389794,-0.4809984783443326,0 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark53(8.393201103512936,-1.3427556090605122,0 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark53(-8.398060941239789E-18,-3.924352133825147E-15,-1.0 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark53(84.03511537679555,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark53(8.404295263799327,-0.6142003578182982,0 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark53(84.09351577271582,-1.0486353289203914,0 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark53(84.1793713832439,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark53(-84.1966966452917,-1.143597469624202,96.89392609561892 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark53(84.26211736906593,-1.2205554615959258,0 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark53(84.28950306985676,-1.4691969518292708E-6,0 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark53(84.37080734996601,-0.502733521178115,0 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark53(84.38125130655783,-0.5022788739001953,0 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark53(8.438773063694864,-1.4999999997796243,0 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark53(84.41617411368911,-0.5182714498924889,0 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark53(84.44622293166883,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark53(84.45786059123861,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark53(84.50099692965284,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark53(84.5071110103934,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark53(84.52589302248154,-0.6557566575519758,0 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark53(84.53958208079914,-0.09852065327247317,0 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark53(84.66535701364955,-1.186183836474525,0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark53(8.46835677063179,-1.3395425812116744,0 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark53(84.76258953307983,-0.9110100219494677,0 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark53(84.77110971149546,-0.0783966265700542,0 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark53(84.77198229014061,-1.115099169006271,0 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark53(84.80465735454479,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark53(84.81247830447529,-0.9883463435248006,0 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark53(84.84028777347976,-7.105427357601002E-15,0 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark53(84.87374700173659,-0.8888890169462401,0 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark53(8.487608899230523,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark53(84.89472224227396,-0.6842008165273796,0 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark53(84.90599968677878,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark53(84.95155097286403,-0.6464034232663334,0 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark53(84.99948551782784,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark53(8.4E-323,-0.7986217350779654,0 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark53(85.00482019045882,-1.3367526442453332,0 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark53(8.501745349788777,-1.4137558406037718,0 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark53(85.03306940191129,-0.760975491500723,0 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark53(8.503757260286829,-0.08455204669178007,0 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark53(85.0934931350998,-1.499999999788511,0 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark53(85.09566156395661,-1.2877319279013903,0 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark53(85.15727010851887,-0.02245723346320647,0 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark53(85.20534200914392,-0.4858982686813045,0 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark53(85.24303054541335,-0.19865655245034475,0 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark53(8.527272012312755,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark53(85.28917082734878,-1.4758704744265136,0 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark53(85.29972433098345,-0.1414370543522332,0 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark53(8.539587468376785,-0.0019649919624136697,0 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark53(85.4260675800173,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark53(-85.43755651551236,-1.3323580583113668,-1.0 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark53(85.44720559189896,-0.018556809977024635,0 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark53(85.45246010305391,-0.0067166573127934726,0 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark53(85.50665318680687,-4.0552712922893566E-10,0 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark53(85.53186564495601,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark53(85.69142932252285,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark53(8.573824758486964,-0.11192067075261591,0 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark53(85.74962291624558,-0.8804059399271598,0 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark53(85.77493389949504,-0.7618822834738961,0 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark53(85.80397501049939,-0.3783732994025404,0 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark53(85.87739075694833,-0.2424356051477472,0 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark53(85.96456953173521,-0.8389514909401345,0 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark53(86.01679281316417,-1.5400227941009072E-16,0 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark53(86.05385181063163,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark53(8.614202966389499,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark53(86.15511569087367,-0.5414115715570631,0 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark53(-86.174010181434,-1.029976279177232,0 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark53(8.617779467532245,-0.4342548569202549,0 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark53(-86.18351112887893,-0.34839039783502174,1.0 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark53(-86.20271762118806,15.335287963709803,89.84405603590895 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark53(8.622332382089294,-0.22022835515972528,0 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark53(86.23071549655265,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark53(86.23384475257112,-0.26461516769774107,0 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark53(86.26635575575642,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark53(86.34302263561416,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark53(86.34904627406809,-0.6923357747740566,0 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark53(86.35286525411813,-1.9496885663101217E-8,0 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark53(86.35310157790352,-0.994270456516146,0 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark53(86.38605485864528,-1.434138873714006,0 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark53(86.4121539674758,-0.9853955336914515,0 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark53(86.53523573545894,-0.9679195885062574,0 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark53(86.55024602946517,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark53(86.57095287833195,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark53(86.5896761118518,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark53(86.61888228487956,-1.0895919342668998,0 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark53(86.6282217667142,-0.9953621787701477,0 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark53(86.65509606317994,-1.1413041267678738,0 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark53(86.67504630152817,-0.20368419793495773,0 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark53(8.673617379884035E-19,-0.12077736469742767,0 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark53(-86.76588652846891,-1.4999999999999223,1.0 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark53(86.80147562577616,-0.1102019261858258,0 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark53(86.81143122093314,-1.2585589430354476,0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark53(86.84733419187681,-1.193314260773873,0 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark53(86.93732803437132,-0.15030203184213398,0 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark53(87.05410885797673,-0.33957186267959116,0 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark53(87.15212503809117,-0.36655831114851445,0 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark53(87.15645287047244,-0.8841747382278982,0 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark53(87.26120902075996,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark53(87.26586324115527,-1.0819576355768667,0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark53(87.28610103952016,-0.7722391806537701,0 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark53(87.29850190787857,-0.3827147953447252,0 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark53(87.30233790928477,-0.3453517740753256,0 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark53(87.31387842938318,-0.43324319850432746,0 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark53(87.34575053309797,-0.30650646290019357,0 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark53(87.37515312991101,-1.0050983602895682,0 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark53(87.43877275323192,-0.23747231075509093,0 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark53(87.44262747580919,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark53(87.49038902499814,-0.46187491917155166,0 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark53(87.4912098683408,-0.08783105494069865,0 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark53(87.49344165805454,-1.4162198747725672,0 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark53(87.55836333914186,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark53(87.5646254588292,-0.16698168980060446,0 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark53(87.5962559589324,-0.8429950689809731,0 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark53(87.64110178731019,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark53(-87.65771171382451,-0.2854881879387139,-1.0 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark53(87.68114721267546,-0.6123204555438052,0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark53(87.6825911951162,-0.9440619666925869,0 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark53(87.70690051621978,-1.1368057316364713,0 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark53(87.71159257705253,-0.4926193807143331,0 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark53(87.71829914706257,-0.027661358091607746,0 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark53(87.72222563546401,-1.3043566229832775,0 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark53(87.72776116101619,-0.44140681692082406,0 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark53(87.7515500385887,-0.047639271811650924,0 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark53(87.76307314786621,-0.24941313496305462,0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark53(87.80477055674972,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark53(87.83299075015066,-0.09788021485660892,0 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark53(87.8472054210581,-0.8521346343475216,0 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark53(87.90121031798421,-1.169737524978309,0 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark53(87.91178540059633,-0.009941062034787451,0 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark53(87.95409664915243,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark53(-87.97515866533952,-0.6414486425823402,0.8202056916555924 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark53(88.04808132299279,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark53(8.811794498120932,-0.26573459812816624,0 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark53(88.16382151970038,-1.0867126350544614,0 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark53(88.18479881811206,-0.22573146529668975,0 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark53(88.19144784100718,-1.0761153917325579,0 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark53(88.25020315875159,-0.3066400201192039,0 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark53(88.2511838952672,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark53(88.26269750375745,-0.008288287354005568,0 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark53(88.33482507229853,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark53(88.34316541038936,-0.14552315040370445,0 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark53(8.83529979694147,-1.2016313751754097,0 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark53(88.35608489982614,-0.5907390941090134,0 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark53(8.844824877972599,-1.1564278696764356,0 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark53(88.46552583459973,-0.034786936340665875,0 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark53(88.52065771702229,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark53(88.55897147926933,-1.17936690824421,0 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark53(88.67137467853291,-1.47071534351457,0 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark53(88.67307181048525,-1.4649361602808226,0 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark53(88.68955968155973,-1.2384573123154041,0 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark53(88.69441204773892,-1.3717845091370744,0 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark53(8.871957124296394,-0.9556914178957426,0 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark53(88.74930695345031,-0.8022620044563205,0 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark53(-88.7762315782242,-1.338729482795636,0.3620916933000942 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark53(88.80669117481432,-0.11023677618392232,0 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark53(8.881784197001252E-16,-0.6159083611073299,0 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark53(8.881784197001252E-16,-0.9752315490690164,0 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark53(8.881784197001252E-16,-1.4533325724214257,0 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark53(88.85564643343022,-0.7224098986717138,0 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark53(8.887140038514602,-0.7258809796268293,0 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark53(88.8982930339618,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark53(88.8998391935384,-0.7811811018092857,0 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark53(88.90215936909212,-0.18233183699932098,0 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark53(-88.9124588705266,-0.40856089861637646,-0.43661670742963565 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark53(8.892386115629947,-0.1845254350171217,0 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark53(88.97451230360252,-0.25397686447877976,0 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark53(88.99575638764567,-0.6276218423177113,0 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark53(89.07055733191115,-0.21574986802612095,0 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark53(89.12738399235388,-1.4622096517579877,0 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark53(-89.15099824992254,-0.6136544974037277,0.21401462145557437 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark53(89.16340842855075,-1.4798110780914622,0 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark53(89.17889086740297,-1.4320375985817293,0 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark53(89.18358082453184,-1.011457576797544,0 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark53(89.2021054140711,-1.1082315437665784,0 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark53(89.25702415307396,-0.827264637235922,0 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark53(89.26272880955835,-1.2332720658582055,0 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark53(89.35993292112724,-1.3464562281242394,0 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark53(89.41560920709588,-0.1971226170892617,0 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark53(89.47035288016842,-0.43966576278534997,0 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark53(89.50070836689565,-0.8862055512194127,0 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark53(89.6485805444887,-1.0204261829500325,0 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark53(89.78310441575283,-1.4619007142939893,0 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark53(89.79063899618622,-0.13373231332923663,0 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark53(-89.8173639899104,-4.440892098500626E-16,-97.04431958147381 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark53(89.82146537668584,-0.5143578201019612,0 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark53(89.82333923025558,-0.010397614467155591,0 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark53(89.83747388398103,-0.2633752098305919,0 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark53(89.87472695926836,-1.1087302466214197,0 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark53(89.90395121356693,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark53(89.91536005144155,-0.7913436347204761,0 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark53(89.92739690031057,-0.9317134059918146,0 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark53(89.96306119022583,-0.20762645418958314,0 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark53(8.999331276788991,-1.5572698231588375E-7,0 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark53(9.00360767529962,-0.7303039871354386,0 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark53(90.03718302430033,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark53(90.09418487566143,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark53(9.012111565789695,-1.0309539009084059,0 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark53(90.1227123196974,-0.24322584464361174,0 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark53(90.15829741730182,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark53(90.27259540447079,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark53(90.28427057231593,-1.4018082002929209,0 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark53(90.37162434939583,-0.4369535671577012,0 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark53(90.3874924219592,-1.094407354505855,0 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark53(90.41285325087345,-4.8078208440666545E-5,0 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark53(90.42170085241247,-1.0746182666629682,0 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark53(-90.44672213323368,61.135948411457775,0.09035894565832336 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark53(90.47596985412974,-1.3780349755758055,0 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark53(-90.53441158628748,-1.0615544628754536,0 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark53(90.53601163564085,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark53(90.56348381113898,-0.7782464744759778,0 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark53(90.57350588510923,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark53(90.60769974760154,-0.7465697978867617,0 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark53(90.76692406302516,-1.0547311647130897,0 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark53(90.776592010469,-0.21611324384321384,0 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark53(9.07832130297443,-0.4102509977317923,0 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark53(90.7988989707097,-0.2177564470664901,0 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark53(90.81077796088425,-1.1034120143368424,0 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark53(9.08503996302639,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark53(9.085976672673198,-1.0016487317465537,0 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark53(90.89531774405415,-0.7632285162769872,0 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark53(90.90583416401284,-0.17617974093150301,0 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark53(90.92218888853526,-1.182708578817536,0 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark53(90.93730988507697,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark53(91.10595775738108,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark53(91.14586364938467,-0.09365851105529488,0 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark53(91.28217094667927,-0.49192847052092614,0 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark53(91.3047692004294,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark53(91.35126720620434,-0.2052317913096834,0 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark53(91.35440583921647,-6.805978767581058E-9,0 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark53(9.136728483080844,-1.386872240260407,0 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark53(91.40349794726063,-0.0013547764468768916,0 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark53(91.4083535073815,-1.2307749754914457,0 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark53(91.41129994275954,-1.2741646204221694E-8,0 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark53(91.44495068774579,-1.4999999929849845,0 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark53(91.45024293840876,-0.9320697237340159,0 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark53(91.4859161054128,-1.1541131118194272,0 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark53(91.51176349659684,-1.39698953108463,0 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark53(91.5818859234766,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark53(91.61755452787108,-8.05061933368867E-5,0 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark53(91.64719413400928,-1.1023661158573732,0 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark53(-91.70621770048668,-0.9257807876656301,-57.67711262652959 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark53(91.73062330007195,-1.0637847693628892,0 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark53(9.17919456158154,-1.2729163353874862,0 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark53(91.89864997840317,-0.7150632073802186,0 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark53(9.189910444597324,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark53(92.01572595322492,-0.5434453413646594,0 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark53(92.1566306070855,-0.47496146911380777,0 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark53(92.22295546071686,-1.499999999218065,0 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark53(92.22638809401421,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark53(92.27111093739359,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark53(-9.229274643470173,-8.820048301335071E-6,5.879505640405937 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark53(92.31252972287476,-0.9982001685030042,0 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark53(92.38454578172147,-0.7279602602111197,0 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark53(92.404535745707,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark53(92.41438260315846,-1.1323692559608673,0 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark53(92.44899334072667,-0.09146318103467266,0 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark53(92.4823105847387,-1.497205239999172,0 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark53(92.54699701062954,-0.46763117664245657,0 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark53(92.55950054822151,-0.11832117492015304,0 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark53(92.64884063951192,-1.3598719671666943,0 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark53(92.65561442967072,-0.4497039955526345,0 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark53(92.72472075516686,-0.6976521061236518,0 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark53(9.278133869762826,-9.102417513853408E-16,0 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark53(92.84050480472945,-1.0676415556964773,0 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark53(92.87462945293296,-1.4999999999999822,0 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark53(92.88657585868671,-0.8356742514378881,0 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark53(92.90850673991176,-0.63098530700538,0 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark53(93.00461546321765,-1.422261448755739,0 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark53(93.00638342056112,-0.7890489134710919,0 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark53(93.00833342809361,-0.7419210106622902,0 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark53(93.01915098007981,-0.06741604469343399,0 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark53(93.10900486079026,-0.7267113216798577,0 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark53(9.32575498690386,-1.3920580681500034,0 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark53(93.3398532307902,-0.5068698293069747,0 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark53(93.4708499626652,-0.9918285438247627,0 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark53(93.50253224849453,-0.8171846051040461,0 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark53(93.5501958392943,-0.31789175116497687,0 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark53(-93.56295590656649,43.504226114106245,-87.0881898310823 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark53(93.56448418327426,-1.1545458718755839,0 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark53(93.59418717142452,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark53(93.62348428927632,-0.7056405383332964,0 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark53(93.64870300431579,-0.1371838546520081,0 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark53(93.6574270625152,-0.7738987014829122,0 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark53(93.67828346848688,-0.42085004592828335,0 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark53(93.68198321785476,-1.258316680948175,0 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark53(93.78547408194385,-0.1437495282742689,0 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark53(93.7878858536223,-1.384502473536075,0 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark53(9.3846585093156,-0.4896337444960057,0 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark53(93.90367712873518,-0.6271356636650331,0 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark53(9.39180249272939,-0.3691471622342313,0 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark53(93.96707934435307,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark53(93.97062366009419,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark53(94.01265415871686,-0.7477013061490112,0 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark53(94.10548952007295,-1.4094514020977713,0 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark53(9.433344275877964,-1.1787806638962515,0 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark53(94.37726426732905,-0.21322667718273114,0 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark53(-94.43037180839644,-0.7100108715295885,-1.0 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark53(94.44860042054145,-1.499999913495891,0 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark53(9.445476749118868,-1.458202642515571,0 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark53(94.4708800049313,-0.7844515380726413,0 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark53(94.49100895534403,-4.309694453719386E-8,0 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark53(94.51598238997329,-0.1605866082017684,0 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark53(9.455240915046986,-0.2066061879037573,0 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark53(-94.56970889130524,-2.220446049250313E-16,-1.0000000709689616 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark53(-94.64817677982981,-1.4999999999696427,14.527009946003696 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark53(9.466831504409853,-0.3114901224033492,0 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark53(94.68953732247068,-0.47751678135677234,0 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark53(94.69657565031974,-1.0096068233066262,0 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark53(-94.70501119080782,-7.666513010027556E-5,78.47717045899023 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark53(94.73107873655448,-1.3206648937873702,0 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark53(9.473604146368245,-1.4337933808351577,0 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark53(94.75639334184237,-0.8887437425436673,0 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark53(9.476164385316622,-0.9591506679229385,0 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark53(94.89001867838468,-0.14772961357954956,0 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark53(94.92671929252612,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark53(94.95007069049737,-0.8157952303337233,0 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark53(94.97716853912829,-0.1459242371797782,0 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark53(9.510895295904234,-0.9264070853456676,0 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark53(9.516569178805126,-1.0391944237955568,0 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark53(95.16601666865482,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark53(95.19329555836975,-0.5211644612690804,0 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark53(95.29444388359518,-0.5442426784216536,0 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark53(95.36433987438704,-0.13547313491201862,0 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark53(95.4382375858751,-0.7336482301007123,0 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark53(-95.4502059319476,-0.8672581298632993,-75.00166924015869 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark53(95.5209574840967,-0.11344966681616886,0 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark53(95.52297041191628,-0.4831730926316644,0 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark53(95.61728266395005,-0.4192782450753718,0 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark53(9.561853016114853,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark53(95.64694521158484,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark53(95.68999268289423,-0.38766789070831464,0 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark53(95.73998743163264,-0.29846571192754734,0 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark53(95.75437517108254,-1.4396865894088189,0 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark53(95.83812108006964,-0.1815578563467964,0 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark53(95.85768065807827,-1.4999999999999902,0 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark53(95.88647779783508,-1.4559215359579383,0 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark53(95.92688137663794,-0.6911914418521403,0 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark53(9.594220592246133,-3.6904459588012464E-8,0 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark53(95.95708340373687,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark53(96.05210255971079,-1.4010316510212748,0 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark53(96.14506189198642,-0.3688581501457744,0 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark53(9.61626998351558,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark53(96.24060573060743,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark53(96.29493063630973,-0.2152510653037336,0 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark53(96.3107583866598,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark53(96.35109624380725,-1.499999885563396,0 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark53(96.3811890881926,-0.2760121296154683,0 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark53(96.39496670331252,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark53(96.3984685310044,-1.4888317262206385,0 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark53(96.39899227897425,-1.450106052483875,0 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark53(96.44003545501448,-1.3128288017461376,0 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark53(9.64699893457393,-1.4999999999388682,0 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark53(96.48570212835523,-0.0040621318022573405,0 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark53(96.50004200987615,-1.3261277588073686,0 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark53(96.50809380925588,-0.0951108212860845,0 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark53(-96.53544274355077,-50.82249610743159,-31.21526858205877 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark53(96.57306404388322,-0.43882180960931194,0 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark53(96.59746867638566,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark53(9.665132639792247,-0.14768884855389397,0 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark53(96.68450357416862,-1.1964177780963396,0 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark53(96.689351525072,-0.8012730092260629,0 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark53(96.72242412672557,-0.1591053731955867,0 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark53(96.73642803873958,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark53(96.7892503745301,-0.5897537046508363,0 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark53(9.679240718982058,-1.13657146652054,0 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark53(96.97546577709974,-0.5410943815579401,0 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark53(96.97864441094796,-0.3892323537647968,0 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark53(96.98114505185623,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark53(97.07669344794418,-4.629596967879394E-8,0 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark53(97.08630052009323,-0.9667301344626236,0 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark53(97.08672780566039,-0.8585219110977604,0 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark53(97.09561589347572,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark53(97.1240010005902,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark53(-97.18364951847146,-1.4999999999999982,-26.714674321124647 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark53(9.723409391956949,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark53(97.26686028393888,-1.4999999999999805,0 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark53(9.7308850719172,-1.0608199173544612,0 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark53(97.3209983372587,-0.2203630113073224,0 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark53(97.48338419896413,-0.2441455904826073,0 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark53(97.5305526261156,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark53(97.55766802849607,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark53(97.59693662237606,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark53(97.63257309024726,-6.595652843885011E-6,0 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark53(97.6340469460644,-1.3372069768041046,0 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark53(97.64027121092579,-0.20101528207598562,0 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark53(97.64333215670663,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark53(97.72261796252008,-0.2973598637987118,0 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark53(97.86815875926683,-0.5087179774698569,0 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark53(97.89000440649029,-1.2519206613731564,0 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark53(97.93895453273605,-0.29291843210784235,0 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark53(97.9497143031456,-6.1943163313620895E-9,0 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark53(97.9849862393717,-0.5778041481772931,0 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark53(9.801715308364905,-1.4800637027208796,0 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark53(98.0412901148811,-1.200704103755987,0 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark53(98.05546428385142,-0.12983612305592374,0 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark53(98.07962579019042,-0.3652604421935155,0 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark53(-98.08944431368027,-4.05004419683616E-9,-0.9999999967470471 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark53(98.09518532245096,-0.06597577607731464,0 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark53(98.11838517164728,-1.3421656537320246,0 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark53(98.19974427661168,-0.6799212570824835,0 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark53(98.24096076958179,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark53(98.25673748456046,-1.3964691834706997,0 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark53(98.28842266406727,-0.3567650194929623,0 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark53(98.29793017383516,-1.0253928767621916,0 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark53(98.31065315765596,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark53(98.34330731360782,-1.2757014035716452,0 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark53(98.4024637458144,-1.476385448348716,0 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark53(98.48754215424725,-0.9972783979708311,0 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark53(98.4912537002422,-0.9052348463881685,0 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark53(98.51028429456551,-0.5174314406421843,0 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark53(98.51184886528696,-0.8012447008858858,0 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark53(98.52016193355556,-1.2176484608787286,0 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark53(9.861051552496372,-1.4999999998568387,0 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark53(98.64210163829128,-0.9047392185522791,0 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark53(98.74120172600314,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark53(98.76414459656647,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark53(-98.77902735837505,-0.5912557141831019,-1.0318854277945043E-8 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark53(98.86852110239124,-1.4999999999999876,0 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark53(-98.88827047132676,-0.797562705107167,0.7144472974490204 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark53(9.889345717894372,-0.44854199267290085,0 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark53(98.8962392919837,-0.870040968974763,0 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark53(98.93432994794257,-0.23302840677659298,0 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark53(9.89700676748673,-0.8438836729621486,0 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark53(99.09836254693923,-0.9796649183336404,0 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark53(-99.28114048040347,-0.8094252966617518,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark53(99.2871189388785,-0.052659129428136886,0 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark53(99.3143389423885,-1.396482874953036,0 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark53(99.33455113788852,-0.02435619400606459,0 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark53(99.45725060119074,-0.9298135003795096,0 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark53(99.4609219323066,-1.3739347785239442,0 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark53(99.47806413075824,-1.3145225154554865,0 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark53(99.49656024801129,-1.0871496900200992,0 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark53(99.51224451094384,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark53(99.51658440818912,-2.6847177299530927,0 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark53(-99.61326091249221,-0.004334970066780741,13.025490210575015 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark53(99.66939928022012,-1.393010322443227E-5,0 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark53(9.982184149538114,-0.9725898779237453,0 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark53(99.85620448746928,-0.4126482879026795,0 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark53(99.86462024968733,-0.6326697734788347,0 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark53(99.87055195563397,-0.21640948165077578,0 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark53(99.90205983991765,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark53(99.9266006378536,-0.9359212643201147,0 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark53(9.997766539789211,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3258() {
//    	UnSolved;
  }
}
