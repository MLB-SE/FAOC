import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(-0.0018123935802819983,-3.3785343660200045E-14 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(0.001871210000084167,-71.30416334717466 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(0.0,0.6327378877929419 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(-0.007868141823166896,200.64902020149287 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(0.008783225724080737,185.9850527556745 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(0.010299896599684801,153.26618179356655 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark21(-0.014017972660434358,147.72438051990585 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark21(0.014525227577679873,-142.87996170572728 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark21(0.01484725215115387,-111.16297579490684 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark21(-0.015306433267445444,-102.63922626335717 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark21(-0.015707530248815018,100.00350106788864 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark21(-0.015707963267948974,-100.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark21(0.016089213095503412,-97.63040103147783 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark21(-0.016108690666967018,-97.51235275850324 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark21(-0.017065837195992313,92.04332074395842 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark21(0.017846462393539125,88.01723793526526 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark21(-0.018041042174445465,87.06793718490816 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark21(0.0,-21.21816850008986 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark21(-0.021334493749397457,73.6270729104721 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark21(-0.02161921336912992,-72.65742281991805 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark21(-0.021860903643027164,71.85413523818004 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark21(-0.02191322969894996,71.6825565366191 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark21(-0.02250773779227517,-152.33113118540678 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark21(0.0,23.524974063418853 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark21(-0.02478851284664163,-63.36791305363481 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark21(-0.024944996052427327,-62.970397890363614 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark21(0.025145020480276833,129.91447036628762 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark21(0.025676936550695473,61.26203347823304 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark21(0.026714182121645953,-122.28037773932074 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark21(0.027087590382919115,-57.98951861681314 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark21(-0.02747167157313984,61.18550255539375 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark21(0.027889499961756294,56.322140194297646 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark21(0.0,2.8878789505288722 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark21(-0.030056082111830574,52.26217844862106 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark21(0.03051718449017926,-8.9022142296961 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark21(-0.03064874561874148,51.25156984677267 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark21(0.03135934029957636,-104.16649824157687 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark21(-0.031415964134359056,-100.0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark21(-0.03266592653589836,-100.0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark21(0.03299770548257872,-95.25582327767074 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark21(-0.03300725107209603,47.58943189070449 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark21(-0.03372321210035637,96.86524355951852 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark21(0.033735555476844224,96.91437628250031 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark21(0.03447687426448316,7.459708748927312 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark21(-0.03463622092274293,45.35126191447401 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark21(-0.036358503833426696,43.2029968557387 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark21(0.03706085663362091,-42.384242529442794 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark21(0.03833303373106833,-40.9776157508192 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark21(0.03845192138446407,40.85091902402446 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark21(0.03914441369526316,-83.45813598616509 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark21(-0.03914872525499652,-82.01598180673159 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark21(-0.03995514573313446,39.31399317841178 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark21(0.040367631534074674,-38.91227369802397 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark21(0.041417593505924215,100.0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark21(0.04158918115618309,37.76934969928749 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark21(-0.04240026086461057,-37.04685524956201 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark21(-0.042480027156467544,-76.89813948821696 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark21(-0.04261325610578126,-36.861682733083015 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark21(0.04381910344276559,35.84729497824157 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark21(0.04390517489359005,74.4744815022704 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark21(0.0,44.022296805233026 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark21(0.04775325192763997,66.27217013347266 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark21(-0.05148822330950914,61.88698495262711 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark21(-0.05168252230666324,-30.393182389095195 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark21(0.0,-52.77168946264836 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark21(-0.05553626283385605,10.271990624762944 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark21(0.05777264784109192,56.54220165159999 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark21(-0.059673910621930254,26.322999622847355 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark21(0.060065469727528006,26.151403359043556 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark21(-0.06121976899569002,-51.324571326372805 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark21(-0.0669381300394889,-23.466390917607384 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark21(0.07283284186031475,34.63157121906055 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark21(-0.07388471150644454,44.21202463949598 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark21(0.074489388797776,-21.08751799614714 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark21(0.0,-75.96586768924958 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark21(0.07797531238158834,-44.072918618695674 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark21(-0.07815510264031944,20.098448773383183 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark21(-0.0845012925358759,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark21(0.08818470901166,-35.6251989781527 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark21(-0.09689091479844267,-16.21200842269419 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark21(0.09690166270146763,38.10654020650338 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark21(-0.09836263852488927,-17.590886900191535 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark21(0.0,9.881845486997605 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark21(-0.10345139846460384,-5.517499021186043 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark21(-0.11477778207417078,-13.685543477219568 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark21(0.11552435992033881,-89.14378510435533 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark21(0.1164256757483774,94.43942422198042 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark21(0.12503826795139678,-121.06025659925581 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark21(0.12629940279977192,-25.42823126756851 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark21(0.12634012757103655,-21.142994689632328 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark21(0.12634240319261478,14.733757876705274 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark21(0.126386671087389,-12.428496717892088 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark21(0.1361722572443324,11.535362331377337 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark21(-0.136190017954609,11.706233680090701 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark21(0.14777582062637315,28.026186429704943 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark21(-0.15106308261591184,21.624030156706944 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark21(-0.15215544833708852,30.970885681574195 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark21(-0.15531502166620248,21.033402974793987 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark21(-0.18865223817526378,-8.326412355286124 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark21(0.23944370164782558,-17.368739643408283 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark21(-0.24853963465710824,-6.320103950269381 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark21(0.25795950696676617,12.178641098105356 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark21(-0.2598554185014108,36.30898509123256 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark21(0.2700691185648668,-37.28561034102275 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark21(0.2705765967128144,-40.19535067085747 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark21(0.30125456763489905,5.214182606846313 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark21(-0.30183802820940286,-56.446822717460556 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark21(0.3029875681893941,29.04748673711512 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark21(-0.30435414841709585,10.732867196419893 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark21(0.3070623350662065,5.115561719597466 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark21(-0.3214564938051396,-34.2054819217941 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark21(0.32649616676070536,-82.49302136471394 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark21(-0.34508217842464717,27.3137163812339 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark21(0.353838565787143,-5.329070518200751E-13 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark21(0.3544437573777184,-4.431722372440332 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark21(-0.3709401575190512,72.20029813720829 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark21(-0.39919901697185445,-6.24217509608603 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark21(-0.41741047252882857,100.0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark21(-0.42991922056177434,3.653701094690163 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark21(-0.45269876924072716,-6.940037718133497 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark21(0.46859039475787156,62.031964076647284 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark21(0.53365013024372,6.121226872192734 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark21(-0.5444415456622614,-2.8851514718337157 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark21(0.5704073128458462,-5.507630394721782 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark21(-0.5815980792405525,2.7008279134037627 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark21(0.5888974444166186,2.667351236939022 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark21(-0.6083798023753241,-100.0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark21(-0.6280679636309264,-5.039739970956138 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark21(-0.6302411903848482,2.4923733179605594 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark21(-0.6322046459500954,-17.392160396150473 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark21(-0.6597344572538569,100.0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark21(0.6864304227853483,3.7444293153226025 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark21(0.7102535230086583,13.697202301081049 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark21(0.7212928875401445,-45.12781712426297 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark21(-0.730771397783953,100.0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark21(-0.7322216963994349,-100.0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark21(-0.7828195029076538,-5.795914326220941 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark21(0.78511170446087,-84.10817782419193 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633157652,-2.000000000208402 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark21(-0.785398163395239,100.0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633969659,-3.4954764490893924 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974313,100.0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974412,2.0000000000000275 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974453,-133.19810859512447 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974456,-100.0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974456,130.04731900828642 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974456,-13.504050229239354 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974456,13.811577695107463 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974456,-2.000000000000007 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974456,21.163374290304404 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974456,66.65412786947957 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974456,-77.5539539433882 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974478,92.76729148028107 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974481,-100.0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974481,100.0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark21(-0.785398163397448,-27.291133181922724 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974482,-74.83091193326626 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-100.0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,100.0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-100.0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,100.0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-11.43159214694628 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,12.471585518320193 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,13.505821876355576 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-13.599311031792173 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-13.677463632635565 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-18.065207250518295 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-19.733978949164623 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,2.0000000000000036 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,2.000000000000007 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,2.000000000000008 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,2.0000000000000284 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-2.000000000000526 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,2.000000000000583 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-2.0000000000032117 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-2.0000000000088427 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-2.0000166166765894 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,20.525439071561266 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,2.1375825055410544 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,26.44983289773732 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,26.669722602823867 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,27.801534080533692 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,35.988974328057566 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-3.6300573114910297 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,4.002667002076246 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-4.004733723317758 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,4.1608900138613265 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-43.10854174311146 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-4.352097877538658 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-4.4529387839686345 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-45.33955185770359 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-50.985537683591566 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,52.8415867189099 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,5.5163957384340545 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-5.623901970243867 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-5.666226431618905 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-58.5326594482692 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-61.30884098971375 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-68.66080748448515 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-69.25236154266155 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,69.75523436014379 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,69.96441746993557 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-82.48506788159075 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-90.98043994657681 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,91.93425331546256 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,98.92938795724446 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,99.01720714116176 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-99.08078239011513 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-99.8023631431903 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-99.98448814366795 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-99.9999999999954 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-99.99999999999989 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974484,100.0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974484,-100.0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974484,10.86507293363347 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974484,-19.388059689823613 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974484,-27.442535726766778 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974484,61.14642461744728 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974484,67.03915758865628 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974484,-99.90825973592548 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974488,-58.77333329686763 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974492,-100.0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974492,2.000000000000014 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974492,2.0000000000001847 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974492,-27.0144355223714 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974492,27.234045053571613 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974527,-13.978192710051736 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974965,-2.0000000000000018 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981656534578,75.41103811195887 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981785071049,-2.0917500223524685 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark21(0.7920475217207752,-40.07775306182473 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark21(0.8307434799850446,5.552818935856232 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark21(-0.8640291131834088,-45.832041045200874 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark21(0.8921287798937425,1.7607282291486965 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark21(-100.0,-100.0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark21(100.0,-100.0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark21(100.0,100.0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark21(100.0,20.134932628511606 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark21(100.0,24.918272825255073 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark21(100.0,-70.9658190015025 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark21(100.0,95.20837315871782 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark21(10.049210897935595,69.7484261337598 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark21(-1.0107368532240926E-11,1.4488563393170268 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark21(1.011669795057082,65.31611901156211 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark21(1.0179100008401392,9.599050255460256 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark21(-10.239853993491074,-54.26614269020353 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark21(-102.5844732252831,-0.005563881410909225 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark21(-10.385697340346951,7.563963454334143 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark21(10.395222846424417,99.96900423528103 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark21(104.03162769234598,141.0436654819372 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark21(-10.428390591651674,-98.45852961491964 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark21(10.438556302781919,22.64762193541074 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark21(104.45076786145057,-37.149472513671064 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark21(-1.052611483663239,-62.05069961005862 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark21(105.97796627928906,0.005385053081751515 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark21(10.655659184381804,-36.70615572476389 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark21(1.0835282631206524,49.289969564155186 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark21(10.86923415999324,-7.692776225118246 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark21(10.870700063163937,-62.78400604749336 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark21(1091.0136287734479,-149.30691110355917 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark21(-10.95226214209783,-0.14342209001345907 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark21(10.96493974009932,-4.1744760491172395 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark21(109.8784557868332,-12.337242588494936 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark21(-1.1015120186275498,89.84029853017837 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark21(-11.121914415135313,-0.16022942244879346 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark21(-11.137179125514336,40.82268729480069 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark21(-1115.7317242047795,-0.4081845414584393 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark21(-11.191030401836947,-0.14169652069997696 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark21(11.332597742140265,67.99369249113735 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark21(-1140.177888853162,-85.54617461732741 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark21(1.1411171590005107,-2.0256675547646523 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark21(114.67021853143578,-63.19094530737487 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark21(115.48215557793769,-115.69882342176348 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark21(116.335156373678,-98.82277238288408 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark21(11.659356023030583,0.13472410686251202 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark21(-120.16591261596237,70.03488118213886 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark21(-1203.5346499272102,69.0766609171021 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark21(12.08585739984862,20.510422475030495 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark21(-121.07765729077808,-0.018504883622783908 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark21(12.125106325392792,86.42013282590099 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark21(122.48464670983195,16.99440596860941 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark21(1242.350143388424,-95.33222861636534 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark21(-12.440030486788137,0.12774811229581323 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark21(-12.441478549239452,39.531880491264126 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark21(12.514189490661611,38.9571890964336 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark21(1.2544341026011403,-3.7565855158220622 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark21(12.566370614359172,-87.66123174692089 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark21(-12.566370614366608,0.24141341585645856 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark21(-125.68392863625152,0.01612511708929798 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark21(12.581754041402494,-0.12484716531780293 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark21(12.64791220728846,-54.51068677555528 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark21(12.69271074193021,-1.128495431178134 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark21(-12.837774914275784,16.797010892467682 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark21(1294.1393741686072,-1396.6981306588843 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark21(129.6977396846204,-94.7316987336595 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark21(12.974676622625807,47.693300730092204 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark21(1298.592629073806,1395.10954953014 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark21(1.302974934337022,100.0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark21(130.96296397940452,-22.439151018729802 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark21(13.11204249704889,0.0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark21(131.49948151747117,0.0163710726035724 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark21(13.186724786944822,-51.640995023232804 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark21(13.192057045096234,-56.398570615237745 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark21(13.27724062078157,29.934919955573072 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark21(-1.337810531273135,1.4210854715202004E-14 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark21(134.84254945720477,52.99397796674975 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark21(-13.527708737148917,144.10698394800875 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark21(-1353.4532071761414,-1292.0265653801914 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark21(-136.57273707487818,48.056108144536836 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark21(-136.78562055872703,-71.68820666570873 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark21(138.2989206111968,-0.016528848167904897 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark21(13.832485352663326,9.866195886314344 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark21(-13.901479628056283,-68.02658881144242 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark21(1394.6306495267165,-1284.83094031739 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark21(13.993525730585247,61.65617173357322 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark21(-13.999533681753931,-0.11220347495160787 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark21(14.003343010443587,79.67117113494007 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark21(14.010826813583034,90.26080501862486 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark21(141.24096055912605,-67.45825476277554 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark21(-14.137166941129411,-0.13665991821134932 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark21(-141.38784654539523,-61.96046515862003 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark21(141.49800953911173,0.017484834634771573 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark21(-14.232095442185383,-62.40444735632491 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark21(-14.3614846920224,-64.7874219355727 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark21(14.416195499121343,0.10896053170829845 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark21(145.54496864029994,23.472536906216508 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark21(-1.4639686164141044,-100.0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark21(15.383319030654192,-16.456867137191097 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark21(153.8574609916279,-20.73093483623663 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark21(154.0643801534709,11.324854932993716 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark21(-15.58162314037793,-96.5910449971747 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark21(-156.7394449039086,36.339676732591045 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark21(15.707963215785998,74.92964151801891 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark21(-1.5707963250527357,-50.68335569862853 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark21(15.707963267450012,43.87561204077736 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark21(1.5707963267958063,70.83447047793135 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark21(-1.5707963267979135,-45.430023178781845 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark21(1.5708049110780513,-29.232257675753203 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark21(1.5716896373052867,10.900535337612952 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark21(1.572791430713977,-80.85176232198836 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark21(-15.855963507482382,27.540513614509305 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark21(-15.880047182801304,42.853557759090194 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark21(160.21726268363776,-63.47202035930101 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark21(-16.043840041969236,15.564534798162441 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark21(161.88562488966062,0.019395017097863843 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark21(-162.53350079572485,41.10832637261605 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark21(-16.306877686477407,-0.09632722812436612 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark21(-16.38314788467021,87.15811956674563 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark21(-163.8658876833291,0.023554927899937184 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark21(16.396449498405318,-62.32650477912661 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark21(-16.627263813600976,26.202952648049376 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark21(-16.657176152194467,74.89795431763781 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark21(-16.661626715688662,-29.548828682086253 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark21(167.4039156261637,-54.00022691177385 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark21(-16.765104935250285,73.68327461768408 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark21(-16.913072666572617,-44.023273095210286 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark21(-1.697136454365933,5.192650061481725 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark21(-1.697136454365933,6.297706984369715 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark21(-1.6971364543659806,1.3385729360519236 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark21(1.7010641071023542,-16.261999805214927 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark21(17.152419467172827,34.63474699210664 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark21(-17.278720613908717,0.8510341475620438 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark21(17.279247875993864,21.328492876169115 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark21(-172.81884596644525,-53.02978658842004 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark21(1.7299564016641202,0.9079976381392498 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark21(17.30403950991488,-153.7750185086031 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark21(-17.342358109067934,-0.09057570584784358 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark21(-17.4050997223149,0.09665650372822747 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark21(-17.4050997223149,37.05618617943732 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark21(-17.43448068332759,-0.09032116500386903 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark21(-1.7505369578531818,1.8805329186805477 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark21(175.39081238197855,0.016807228728939805 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark21(17.648402779976745,-64.33555796366986 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark21(177.85547491527817,5.564072433996025 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark21(179.30640070350202,-100.0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark21(179.9439781844385,69.12599714748748 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark21(1.7995714479053504,-88.8307092833503 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark21(-18.114031873912495,-0.08671710073874445 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark21(-18.19712272375878,0.0863211371731868 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark21(-18.63568205385986,24.16737025170796 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark21(-18.72466385641904,0.1054087827819327 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark21(-18.739674486020668,-25.915394916237034 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark21(18.84955562294061,-88.24616453210005 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark21(18.849555921538755,-40.83001296075186 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark21(-1.896407352827211,18.17963848942665 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark21(18.975896049109796,1.779802895924279 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark21(18.9758960491098,-0.08277850658678025 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark21(19.028745895147058,-13.375501506250885 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark21(19.280134786648205,2.6645352591003757E-15 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark21(19.513752135461402,-7.289329970790021 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark21(19.61161534322434,-46.65336100597281 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark21(-1.971258194700395,-0.7968496115926865 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark21(-19.894213502072773,-21.90407950731801 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark21(20.421715154450276,0.21704808947218446 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark21(20.435977248333657,0.07694780098568543 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark21(-20.65910832601132,44.219269119766096 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark21(-2.070796326795038,0.7668202347562835 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark21(-2.0707963268433938,-23.228550655612963 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark21(-2.070796328136086,-5.110564816899512 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark21(-2.0707963291913942,-31.65492039873768 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark21(-2.0708341382879913,6.894646515615545 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark21(-20.903882254233807,-0.7255345207219648 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark21(-2.1009090340696766,-118.30101755706247 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark21(21.10725902505517,61.86144750665622 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark21(-2.1286554861756883,28.639723925104732 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark21(-21.288328857555413,-139.16018255303413 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark21(21.455784891093952,-38.484061933097536 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark21(21.465487927703617,0.07317776013689459 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark21(216.98373779925694,-8.47713465046479 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark21(21.91991900075429,65.42779851770283 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark21(-21.934677444520602,-8.959335310039236 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark21(21.98685899941925,-11.33879532685516 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark21(22.338797586334014,107.28109696742385 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark21(2.23404715490787,9.39302946146529 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark21(-2.2353035418100333,-96.86058837479548 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark21(-22.646421319173733,2.6082680922434776 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark21(22.699321067759882,-51.12207302289278 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark21(-22.776546738525994,-8.62924227346819 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark21(23.25504372207168,76.6604696797043 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark21(23.29538024785494,32.7879495190447 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark21(23.38144441471546,-0.06718132117647498 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark21(23.435604774352413,0.10122555282705292 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark21(-2.3563166922064194,-0.6666320923628479 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark21(23.72461764023035,69.02052132110859 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark21(-23.788304042244903,-25.972790288278787 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark21(-23.812004264104846,89.89271540938789 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark21(-23.8356297351785,48.64634513391624 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark21(2.389989207471397E-12,-0.47997859479723104 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark21(23.91918933302583,18.75322353889301 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark21(24.176006057257737,-0.19492007775080822 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark21(-24.181674277686103,43.8247172653235 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark21(24.367656231766734,86.70185755431416 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark21(-24.672013707295676,73.41259797071348 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark21(-246.8731534943207,-53.87354624158374 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark21(-24.762559508412224,-80.8557992436256 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark21(-25.006401101147308,-65.50410903382692 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark21(-25.040761768513498,4.437522347060799 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark21(-25.096969472594093,67.94732747020797 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark21(25.13274122868997,-53.816309149560674 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark21(25.280412816425184,69.44637327949425 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark21(-25.386811069669868,-171.39230581749382 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark21(-25.395072879826827,-46.12707644988876 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark21(25.646726418356906,-54.52376605494973 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark21(25.832530598530038,-29.126509215383294 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark21(-26.243588351459593,-3.1810007056000558 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark21(26.30524144878607,22.87053682186249 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark21(-26.372547508987182,54.704006642607084 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark21(-26.398784065981072,5.128060171102106 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark21(26.577197427942206,-0.1469030456021513 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark21(26.594032704023483,22.08140927484925 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark21(-2.6645352591003757E-13,-0.35171528917092587 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark21(-26.703541215103648,0.5867745991564506 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark21(26.753351274189228,-2.7033064474659234 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark21(-26.87136916694601,36.38587995752545 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark21(27.177505883936135,0.6099885570693289 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark21(-27.613734892036163,-79.5941926818056 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark21(-27.7400412517419,92.63934003617936 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark21(-28.175384739462544,-30.198101052222952 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark21(-28.180714409721197,2.169738119759505 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark21(28.19800593788935,-21.68555731690654 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark21(28.352816048404748,63.258196699850885 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark21(-2.838483759387309,-0.5533927476597427 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark21(28.39627406064792,-0.05535137764673477 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark21(28.40731227453996,-9.833841501722873 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark21(-28.72120337727013,86.59474653442663 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark21(-2.88832895131005,-1.0876852001796573 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark21(29.267367730755865,32.7331389820709 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark21(-29.359273668513808,93.64558712457718 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark21(-29.38212922629897,79.40358910990633 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark21(-29.390089040935408,-56.32674071075885 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark21(-29.43504196656805,87.18906447369511 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark21(2.9686241097711705,-94.64232053421455 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark21(-29.84179890764831,99.01236240505591 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark21(-29.845135666591467,-0.10006763078648864 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark21(-29.971470336674074,27.13250263546147 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark21(-30.297412540916323,49.40913345038611 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark21(-3.058217037412092,-0.5136314092750354 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark21(-3.058951691888756,60.39072337153992 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark21(30.645774174041442,-7.915498613406143 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark21(-30.67152623699659,8.545575950357742 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark21(30.71381345227823,-8.128700291123877 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark21(-30.751899704282863,-23.402623162428007 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark21(3.0923552477527396,0.6696500344322394 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark21(31.052175099935084,70.73650964207829 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark21(-31.153769980902297,-2.717439359225466 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark21(3.1323948244636295,73.21434317120195 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark21(3.141439063519393,21.06450578182867 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark21(-3.1416231711679186,5.2020802026945825 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark21(3.1448298761477975,53.08388761488334 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark21(-31.631875611182572,-4.4748132357113235 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark21(-31.710493226779477,38.70898836563009 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark21(-3.1823166976036035,95.8585516124244 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark21(-31.85649394595083,-26.75993760663313 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark21(-3.1962072408481674,77.60040945737305 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark21(-31.963237157271607,79.86497905917071 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark21(31.97074161675221,-55.30706199960251 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark21(32.0084819563026,90.54685237254283 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark21(32.07446194854684,-18.74596077803726 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark21(32.140943255777586,80.57117870148761 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark21(-3.2141756789391565,-5.227547233258458 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark21(32.14295576763891,-36.471837983536005 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark21(3.2205145455119257E-15,1.5358457719748686 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark21(3.244717432170752,0.48410881983766957 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark21(-32.56152202233761,-37.946863845694104 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark21(3.26793278116083,0.4856292840652472 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark21(3.26793278116083,-1.1948633605302943 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark21(3.26793278116083,4.693701371579092 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark21(32.805173902553406,31.367549107652252 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark21(-3.28461427809606,-67.90889400491206 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark21(3.2858254560792757,0.7829620421663464 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark21(32.868824550623,0.16912807127273713 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark21(32.9690350581736,73.35382096251712 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark21(-32.9785655129196,-25.80062551774938 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark21(32.98672286269283,16.866237274085474 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark21(33.04922286269283,-50.099204027778256 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark21(33.15530233362599,12.211520002073499 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark21(33.243952609003486,-63.629400171440295 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark21(-33.58383314186432,96.11445783609122 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark21(-3.36891581355178,69.549652145864 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark21(-3.384454774671511,-145.3798755796252 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark21(-3.3886220091574963,0.46355017542527294 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark21(-34.16856045449704,55.46495873412648 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark21(34.41844320565056,75.6736955848086 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark21(34.42004039043158,-75.07560266984035 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark21(34.59612703707919,-0.016446283611743304 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark21(34.628970561431245,92.81701600771768 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark21(34.68385931705877,29.97302896465311 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark21(34.78060089677396,61.76939953338274 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark21(-3.4893856932548255,-63.81930719957636 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark21(35.11296367914823,50.02323920285093 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark21(3.543341131783084,7.886580744177474 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark21(-35.72968377413068,34.17821504449944 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark21(-35.82387300106396,-49.5839845335387 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark21(35.85726000041143,62.10219901164581 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark21(36.0435459392325,-59.34851929303495 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark21(36.07842828869396,47.63220776740971 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark21(36.098841793181265,68.98208892940389 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark21(36.128437588942354,-0.043518987578224415 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark21(-36.19189160641305,31.136880054797984 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark21(36.25745229052263,-3.418691661485558 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark21(-36.34017721138564,-14.635666114819983 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark21(36.4344971441238,-11.254261108987976 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark21(-36.49707583326362,-14.039554789561137 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark21(-36.50964929941936,-93.8996524835996 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark21(36.61230844003822,-67.16735805711443 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark21(3.6613513902439725,-8.151397401688428 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark21(-36.65562389815307,5.88066207358311 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark21(36.66012811173252,-83.93195603534178 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark21(36.71286665198442,-64.91675599505629 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark21(-36.72794845882839,50.516171073848994 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark21(36.83815827489009,91.85246259525431 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark21(-3.7114423549385314E-16,11.80042511697799 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark21(37.17790619475039,-57.527309474940466 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark21(375.2306579663507,146.41255987631598 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark21(-3.7592824299427567,-2.9249130631910827 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark21(37.634970425080624,31.442624030248396 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark21(-37.74353550318512,27.384402563421588 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark21(37.89090039268066,63.062385527059746 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark21(37.99306487498936,-16.92306360292335 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark21(38.004795525264825,-3.8726500645657467 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark21(38.09209938636562,-89.66347978806326 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark21(38.64717880363017,-44.59952023109997 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark21(-38.6900413859278,-8.859470377453633 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark21(-3.870024099728039,-2.841772055535593 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark21(-38.727147538012716,0.0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark21(38.765443434151564,14.182921673539884 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark21(-38.870185614669,-0.04041134103054311 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark21(38.931058514146244,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark21(39.027282615419224,-0.04024867276243038 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark21(39.14356804230138,13.739106303239256 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark21(-39.2345299672347,-11.46723635455932 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark21(39.243441730618656,-39.34621173458426 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark21(-39.48520523182242,0.039781895968772574 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark21(39.69053534553763,79.10004901488966 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark21(40.227157016383416,-50.209017422322226 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark21(40.2805306405482,-51.54858192831044 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark21(-403.5029169265473,7.760924352797915 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark21(40.412889427751395,65.06668787025248 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark21(-40.500109629141036,54.82592052542281 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark21(40.50551918782409,73.59388885480762 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark21(-4.060840590500021,-33.45490789232586 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark21(4.071170074653635,-85.73448324936393 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark21(-40.78788817384908,0.05808369704971028 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark21(40.840608049786006,9.948125374027548 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark21(-41.2306628476529,53.887746591828034 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark21(-41.29599774507544,38.54570425725697 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark21(-41.50396151997518,-0.03784690109737454 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark21(-41.62145505769995,-36.5875942967485 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark21(41.6756527976042,79.26413753612563 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark21(-41.90557631395491,47.731729040824945 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark21(-42.074847797768285,27.69616659651966 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark21(42.09731327807481,-31.388167578055644 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark21(-42.17786661425143,11.0611127789048 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark21(-42.26727151982885,-48.05769644227732 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark21(42.28516069589117,-49.97346942258432 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark21(-42.3488843138323,-83.00758531441663 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark21(-4.239656645150906,-36.67958265690159 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark21(42.41160900655404,81.67673464499794 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark21(42.430828228225096,5.670621684828134 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark21(-42.68197575835057,-11.987024062309544 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark21(42.710395563628026,68.50466417775164 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark21(4.29395257166469,99.03283948112863 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark21(-43.031040025634404,-62.6910120220139 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark21(43.20401840952844,28.143797300079736 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark21(-43.37788452073688,92.41771326491639 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark21(43.546179854636875,-4.851638471997262 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark21(43.7589819271351,-65.25558051253711 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark21(-4.380684874310575,2.4981084018209856 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark21(-43.98266915714825,2.045137226187464 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark21(441.044392795189,-0.6457418129253085 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark21(44.108637277828144,-6.051218178038582 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark21(-44.14477083549652,71.37688690234305 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark21(-4.41883285928958,100.0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark21(44.2544557209789,-30.446607634483996 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark21(4.426990816987242,39.05147007482407 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark21(4.426990863100925,-0.43584049739256675 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark21(-44.78888529070235,22.212245602441158 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark21(-4.485388926318235,30.123353801927657 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark21(45.13915805400043,93.36564363360348 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark21(-45.16880925376816,45.54263697590124 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark21(45.31772735337791,0.06728676343844775 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark21(-45.33592174246205,72.42033215296004 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark21(45.393665899002535,64.18476888605866 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark21(45.42675334948097,-0.07234832453085097 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark21(-45.55311961777886,-0.3233341686408062 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark21(-45.679433604623036,-12.29890294048645 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark21(-4.5784659951805935,-95.48774617916416 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark21(458.06296740060935,-6.851571255857152 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark21(4.587496915264968,35.99817070613335 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark21(45.91057079407486,-39.19192144064899 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark21(-46.0617467824773,40.00744357435656 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark21(-46.085995174649796,44.8935975760687 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark21(4.625453886482816,26.366948472670074 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark21(-4.633623204059255,-53.561933871210556 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark21(-46.4283486854407,-63.69058627288244 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark21(46.42900627480327,42.99534908054659 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark21(46.57424637488964,32.88039868126401 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark21(466.6553646797064,22.115103857922037 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark21(46.66929536092218,-23.792747505689626 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark21(-46.67674775312082,0.03365265153225832 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark21(46.692676002761004,-4.269987308474787 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark21(46.740254270608006,-23.609326573778304 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark21(46.77989572442033,5.331860927677383 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark21(-4.678840261658251,-72.91820289390346 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark21(-46.846097417205954,-55.346249048551584 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark21(46.88552763666982,30.367271874793346 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark21(47.087907009203526,76.78850860816823 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark21(-4.711257858290749,-73.00990917021755 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark21(-47.11988523392894,-84.81994609449967 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark21(47.12388974029106,-118.22377448756538 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark21(-4.712388975183749,6.049118599796019 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark21(-4.7123889794191385,3.3207450895002277 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark21(-4.712388980384689,-96.93615853585871 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark21(4.712396609779336,-28.57223995879687 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark21(-4.712435529355055,4.938246117111702 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark21(47.18863023287062,-12.858943467833456 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark21(-47.21236203112751,-22.435280846990818 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark21(47.379061026135034,69.260302971316 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark21(47.437324640267775,-9.057190325551858 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark21(-47.687059253034924,-7.029859024865303 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark21(47.75421549242972,-42.84606891586957 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark21(-47.75939108392731,-19.40086227679997 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark21(47.85011969116995,27.008934462948766 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark21(48.023959531845065,-33.67979584597826 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark21(48.11395170203065,88.76440452012875 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark21(-48.12689627067441,-11.694640970072214 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark21(-48.26836303587025,70.72735015627757 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark21(-4.83389659936168,-122.53603085922533 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark21(-4.835248007868216,-54.24609839180763 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark21(-48.45304305959801,25.607217516219578 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark21(48.57062316734235,38.08675276363911 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark21(-48.6946861306418,0.03273112395685917 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark21(-4.875177533264579,100.0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark21(-48.89329434695375,59.294603480262346 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark21(-4.898917045504888,-0.32064154428502034 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark21(48.989929935763,-88.54485302015613 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark21(-489.9308579551405,-62.550458332373495 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark21(-4.903438707309419,-32.517256231487494 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark21(-49.16569112982018,52.994651953744125 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark21(-49.41982868969848,19.514907202865103 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark21(49.433413645180764,-10.040340509697216 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark21(49.60842967377914,-75.32074214965061 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark21(49.71153652637764,16.91831903986298 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark21(4.974304090780521,39.51942865301431 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark21(-49.82708132900686,43.56342381657079 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark21(50.26548245743668,-0.03134002302947181 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark21(50.281833602064694,-46.45363883166145 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark21(5.050012542463283,-14.407218120581533 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark21(-50.522885655630276,72.42180139326766 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark21(5.056573857909541,-26.583029816298804 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark21(-5.0579662549723405,-100.0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark21(50.753602646583495,-100.0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark21(-51.18150451571566,-46.77360582035994 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark21(-51.274926207007866,14.456024212455702 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark21(51.58327831514248,-29.50840614267228 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark21(517.1976053597145,33.461555683837474 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark21(-51.763897792641636,-90.7071141920744 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark21(51.814681203264406,-36.8111715049942 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark21(-51.83942533291978,-4.556304451323824 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark21(-5.212618619176683,23.43838525313629 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark21(52.15703893071941,-41.02552217302954 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark21(52.179676778609405,-68.685985410961 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark21(-52.601234611855865,-1.0451821964626062 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark21(-52.697166313341974,37.01825906388797 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark21(-53.03801651261966,-6.093243047478381 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark21(-5.320596079309482,39.526231873838896 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark21(53.31076451536424,8.096393391975207 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark21(53.4070751764874,37.79584213301879 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark21(53.450482326278404,4.540348126134774 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark21(-53.51366178819592,40.18568137372236 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark21(53.522126457131584,0.029348541075867415 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark21(53.53341523859752,-21.892228235992317 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark21(-5.384464572323622,-0.2917274885359773 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark21(5.390330490715908,-0.29141002198295496 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark21(-53.96986131775812,-72.01445467929469 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark21(54.1067397436975,-53.47984121997269 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark21(-54.632731324782455,58.6058352594479 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark21(-55.031921508355786,0.02854336689957826 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark21(-55.107665755360706,-16.47538995899194 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark21(-55.11449600308606,-89.87886416208786 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark21(55.19738611478766,37.9151330064702 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark21(-55.4013955706355,-5.495267690948339 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark21(-55.41628772794627,1.3260458975253956E-13 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark21(-5.551115123125783E-17,-63.46946899510406 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark21(55.62558273741214,51.365168019058046 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark21(55.6567845655493,-78.07643445548456 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark21(-55.7476927090796,59.221841835504506 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark21(55.77548418991936,-2.2105979463818337 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark21(5.57973436636037,-110.77758209353091 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark21(-55.871069347473146,8.166775420108635 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark21(-56.470692279214,4.0410111511860975 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark21(56.505589758350986,-99.67689451536866 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark21(-56.56876940618054,-28.614927835383167 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark21(-57.591074346697035,-0.8474151669464192 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark21(57.65505284252963,95.28042909500545 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark21(-57.697059504014554,-110.0219507159543 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark21(-57.81259453982268,67.01449699864321 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark21(57.898544222041295,95.56308553145098 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark21(57.99312396384014,-14.23650336000048 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark21(-58.11946409126037,-0.14178612944897245 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark21(58.24321645838121,65.20188420425904 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark21(-58.26877223994782,-62.687817994013926 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark21(58.35539717453665,-10.28888680619346 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark21(58.45417423025779,71.86090746252285 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark21(58.74048519218948,61.156520796615126 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark21(-58.82254140410086,-43.18424474232255 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark21(-58.905987776464706,92.73456299525722 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark21(-58.915513581468964,-100.0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark21(58.9300683827509,5.577606499917502 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark21(-59.001406067952075,42.95837032674834 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark21(-59.17175974562778,-11.81364962806638 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark21(59.39418278570372,72.85044428207416 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark21(59.42795913071589,-55.115485773278074 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark21(-59.49461745564302,51.469415568070815 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark21(59.54053448990787,-100.0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark21(59.69026041816544,-41.5524740950304 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark21(5.969901193594261,-72.10630411075469 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark21(-59.7215104182064,-0.026302019666630372 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark21(59.8002161610817,-100.0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark21(59.816600545777106,-0.026296338175384903 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark21(59.869646657670614,-12.245946724911358 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark21(-602.5702082533844,-161.79786621649257 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark21(60.514835977250925,74.36772768018659 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark21(-606.6670236636685,5.338643461400082 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark21(-60.76440471097866,-75.423319784737 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark21(60.97717747954459,39.91829974566451 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark21(6.116660819898388,0.2917833853852573 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark21(61.226045457584775,-23.771092644655084 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark21(61.27929420798097,-11.209883204199244 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark21(61.571353956307405,-91.77856630749088 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark21(61.734629167190434,-38.837891552691374 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark21(61.90672279261986,40.4669389611557 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark21(623.477480403832,89.7893060293297 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark21(62.48248822138033,87.31984770000639 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark21(-62.552116169341446,-3.1546867919902297 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark21(62.56541815606694,-88.32435507274718 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark21(-62.778185997344885,58.89399201849096 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark21(-62.788273722124856,80.71426133477061 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark21(6.283185307032402,0.2812232172235777 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark21(-6.28318530741242,12.624559746198036 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark21(-6.2831874493659035,-7.274976996681314 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark21(-62.90622962923251,61.07289644565003 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark21(62.910709043825904,98.63467624470778 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark21(-63.01551242505954,-5.400124721878532E-13 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark21(-63.0459061005316,78.50466252441771 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark21(63.26851623273214,-38.1646520784833 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark21(-63.34130996740676,-0.024798923918737614 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark21(-63.35788717452901,9.327328864359075 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark21(-633.9353061277103,8.649666988192578 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark21(6.345684957478715,-0.258065107342505 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark21(6.345685307143984,30.104531634324545 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark21(63.72158710837098,47.10323161463879 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark21(63.72725574381158,-39.40819210714848 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark21(-63.82620139574857,-23.05500771157955 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark21(6.409408424566865,-90.59482037690798 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark21(6.409525434750623,15.194816452467805 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark21(6.409525434750623,-85.59350665923097 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark21(6.409525434753522,-132.03991213669053 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark21(64.27630927101973,62.70733900459331 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark21(-6.435747077745225,-11.448934097374368 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark21(-64.39073645465587,27.392863657039968 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark21(6.442089342165033,13.238642084398592 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark21(64.45993423596602,-47.5970484781915 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark21(646.7572259274679,28.711010672329948 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark21(-6.477319885756757,9.399694618161519 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark21(64.7988772586788,0.6196297325489155 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark21(-64.98452528343017,-81.75004554834685 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark21(65.06170743441717,-85.32431460034307 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark21(6.510812142056579,81.07383057694025 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark21(65.11775651076218,9.100945929887388 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark21(6.519199478674739,5.06894743759657 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark21(65.22370271696275,-61.785756167906605 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark21(-652.7048862151428,109.6288870362228 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark21(-65.29842196152663,5.551115123125783E-17 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark21(65.33592667536605,4.94044093200822 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark21(65.72575107442796,1.9142434523228076 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark21(-65.84690734675796,15.032526494136107 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark21(65.9734364400287,56.22963844698301 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark21(66.05347127414265,-9.370430160860554 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark21(66.16211282315462,28.08005237366686 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark21(66.43793123825198,-68.12744649071473 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark21(66.48720078629637,28.323470430250467 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark21(-66.65035064449717,66.41407676541479 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark21(672.1498270746276,-115.66571421774555 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark21(67.23426641696605,99.55735192790237 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark21(67.54162960278512,58.56545288709461 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark21(-67.54424205218054,58.81926466321479 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark21(67.5973316749565,57.87816617143689 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark21(-67.63881577950315,-72.97647274862715 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark21(67.6586279595059,-20.845212282004567 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark21(6.787549892635127,-46.67311687594014 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark21(68.1025788119322,50.75967485246795 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark21(68.1219151135369,-26.803174418339125 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark21(68.16623961093079,-86.85330253797149 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark21(68.2154654224309,55.68225282745627 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark21(68.58674654548119,-31.17250100920046 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark21(-68.69010881416827,-75.22905971996514 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark21(-68.73251860821266,-78.39647174235441 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark21(68.86041292354923,65.09442507618292 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark21(69.3255482688644,48.45809367828949 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark21(-69.39297941831427,2.571334447993575 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark21(6.9430039958523935,85.37211214435555 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark21(69.89892688739309,55.11492797792857 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark21(69.92868885216939,20.18769498558057 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark21(-70.44318699834346,-58.270887364403514 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark21(70.56670654269905,16.894954638690592 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark21(-70.6129427355196,11.095612604771517 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark21(-70.68581395489966,98.98521467832762 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark21(-70.70834738878025,81.60464662240602 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark21(-70.82155071339207,-33.469296631078755 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark21(-70.82998193532165,-40.57603830972545 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark21(70.86088606286475,-14.587437204786838 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark21(-7.104027196809028,29.692115488830296 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark21(-71.38756861737052,-21.521552446637997 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark21(717.0362436192241,-29.00831136635381 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark21(7.185652356258757,-9.181274358189945 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark21(72.04432566626917,-50.89061419129126 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark21(-7.209082533775101,-65.13233061209766 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark21(72.14132538872965,-44.266286396556296 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark21(72.2376720407932,-81.12699952065242 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark21(7.224020197929519,-0.2174407440396005 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark21(-72.2721135694465,52.10094977555164 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark21(72.29226168023015,18.109352468139193 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark21(72.59744605310516,159.6353407863362 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark21(72.60082179752004,-53.77689640790724 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark21(72.67472508964426,-65.70300914875543 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark21(-72.77078008996105,53.129106775697636 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark21(72.89629773288334,47.088350834512056 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark21(73.08410137320581,-0.021492996387458163 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark21(73.1163201989593,-0.4625239428448702 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark21(73.13922833243626,36.97817843307112 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark21(-732.6364174852753,-56.33413088684186 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark21(-73.32742735712414,25.991914754255113 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark21(73.61722977839287,11.30051575361854 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark21(-73.69597596072234,19.47011444285393 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark21(73.73411621654802,-16.49678546915115 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark21(-73.75438300191627,72.02097195047273 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark21(73.79039667959319,13.362976955972968 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark21(-73.82742735936013,0.021307728127709424 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark21(-741.777287938839,-15.20799966516567 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark21(-74.5914165424133,88.91497215142786 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark21(74.66199282630527,-81.59807212219698 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark21(-74.8889247452071,30.486048508503906 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark21(-75.18284837495275,69.24509312565397 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark21(-75.23494335927525,-18.414878756764494 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark21(75.3668077590518,100.0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark21(75.52456381372608,44.400346992105824 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark21(-75.6871516633234,47.78963477268022 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark21(7.576127676521008,-60.230392358173624 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark21(-75.87930501040714,-100.0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark21(-75.96247805374254,20.906046341275175 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark21(-75.9676761134169,78.13318844986924 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark21(76.20347648438897,-94.26905131994684 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark21(76.23427756868571,54.01912221884322 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark21(-76.30124745293857,-17.17369847280829 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark21(76.42543899479806,6.6121187625259665 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark21(76.81059014821224,0.020450257233591333 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark21(-76.89768645307363,-58.69350343834591 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark21(-7.698578291254037,-1.0903620983407194 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark21(-77.09536014052097,-0.5194388659454567 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark21(77.16445211922822,-1.6856311641211619 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark21(7.729089568854761,-5.196293483368214 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark21(-77.30498962545376,-31.66986064166734 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark21(77.5388509287677,18.10935835238412 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark21(-77.77658909651842,89.13324057450907 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark21(78.10000799415462,-31.58057976808128 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark21(78.10725311292062,0.4389706526070629 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark21(78.18277281342665,-74.6098162837273 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark21(78.18823259073977,68.67889445512759 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark21(78.51331803723076,8.61563223207645 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark21(78.53412055563277,-44.2953587077831 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark21(-7.853981633974482,-88.54424788719761 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark21(78.60186562365442,-149.54075714250976 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark21(-78.63436257167831,79.68655199897819 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark21(7.884438883938344,-88.78167064111433 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark21(-7.896353918244301,87.05609949541491 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark21(79.21858225181364,-9.799518593984715 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark21(-79.25484353158407,-29.21692645291354 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark21(79.32316796110202,-89.78063842424082 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark21(-7.947703430337754,-88.98440712749627 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark21(-7.9600295590644485,73.80651954069386 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark21(-79.6032005170322,53.22468877827899 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark21(79.60411362314808,-40.21253210177819 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark21(-7.977735464364471,-95.59274732045935 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark21(-7.98032176154552,2.740004700525091 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark21(-7.98032176154552,-9.89973848866099 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark21(79.94092345924844,-94.02904433615127 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark21(80.0339277965054,-0.021524919414048327 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark21(8.011331789938623,-0.19607181027849663 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark21(80.13506274369374,30.36445718969705 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark21(80.1552195011071,26.16313812685938 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark21(80.23561266653974,0.020370813270101668 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark21(80.26341867335032,-9.659525374035482 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark21(80.38366327073811,-10.578548911730508 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark21(-80.48124672497397,-23.690996247307993 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark21(-80.51194892948376,-22.578266841517134 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark21(80.61785402468394,-43.624122572755674 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark21(-80.71233521727486,18.96553311549071 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark21(-8.076408980672767,70.38987383357875 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark21(8.103981633974485,0.3140461585105072 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark21(81.23071574725705,22.316844495014607 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark21(-81.34927295090858,-77.28266090064757 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark21(81.53529459139841,51.65960202730494 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark21(81.72663143221914,43.79209427574699 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark21(81.8065042024386,-29.625786309953696 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark21(81.80774912090565,80.36251969965149 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark21(-81.8514014938193,87.85025725620952 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark21(81.90825738359479,-20.314454001196538 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark21(-8.22626475543705,37.04456429593964 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark21(-82.44481528185823,-12.455370228806984 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark21(-82.5281108928738,0.709779140962354 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark21(8.262249333841241,-0.19011727476694418 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark21(-82.79730991278215,46.30797691473447 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark21(82.83784913384294,-73.22474666753591 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark21(82.84744243438396,20.598440048496116 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark21(83.09155126015298,100.0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark21(83.15349902490084,-48.3081113780826 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark21(83.23307236319738,9.867506045252963 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark21(-8.325119253967912,-79.54271956320687 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark21(83.37217310787082,72.21880285111735 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark21(83.41569692507363,7.176787622038816 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark21(83.48797378033574,-11.760689766858633 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark21(-83.58014002687754,-0.4964636098054049 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark21(83.64511208162338,38.415529504648504 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark21(83.81896594393487,-39.87224213351415 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark21(841.3442891185051,114.3186917298636 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark21(-8.440554310821819,-22.886591178353115 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark21(-84.47072713912733,16.613597147693213 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark21(-84.5241280370537,-0.05575199756356995 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark21(-84.60722318430985,-27.73298047765242 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark21(-84.69666151935338,43.19593095076368 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark21(84.79037055571752,38.877877409135266 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark21(84.7974467272571,-60.344873307351115 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark21(84.81770575388329,-68.47464198137777 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark21(-85.17855920423507,-37.645359336366184 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark21(-85.27782575956802,-11.587094812966157 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark21(85.50848193657316,3.0486913749136875 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark21(-85.90091343505921,-30.245149163571455 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark21(86.26745784614828,23.356707630530323 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark21(8.62977574049408,-0.06614265748970195 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark21(-8.639379797371932,-64.448866571947 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark21(8.660629672050106,-10.819017642390236 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark21(86.89035637276766,-43.13629802392933 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark21(86.92611244995979,-20.42229421494639 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark21(87.260671799221,-45.74370090058486 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark21(88.03335971383208,-17.59920765265754 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark21(88.05452608282607,80.67858378204312 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark21(88.08959430051421,15.861912759685747 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark21(88.28721584443988,-0.017791888800328757 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark21(-88.39342590333696,28.33301856716841 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark21(-89.18195203970674,-26.68240279716825 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark21(89.56454113105784,13.50853180690117 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark21(89.59789062733307,-0.02216360744621726 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark21(89.59789062751015,21.900819687368827 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark21(-89.66173075488014,13.123454752358704 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark21(-89.79111398206234,20.391416193290794 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark21(89.886524821286,84.12776834174517 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark21(-89.9574871154786,11.619636972504395 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark21(89.97771455370948,-15.45394928760756 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark21(-90.01285759031468,-42.547439398292866 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark21(-90.1102558210886,60.70421968930242 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark21(-90.52457403670381,22.720795918442093 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark21(90.82617112405444,18.021955216055574 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark21(-90.97705956792477,-8.031035759468155 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark21(-90.97984682653296,64.76197126671424 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark21(-91.02220817082052,-100.0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark21(91.06026100099494,-45.00906838065079 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark21(91.0832034356271,-53.83124973167202 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark21(-91.08367789149305,-100.0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark21(-91.08396187780335,-58.31158362394344 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark21(91.09536349960663,86.2597312342802 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark21(91.10423846132399,-93.9118280405756 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark21(91.10618693115859,-101.54919708477456 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark21(-91.21645337664863,-19.421234189726547 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark21(91.50521556529256,33.59524603388678 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark21(91.57062676579665,19.92030679109378 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark21(91.63551877276956,76.9945769974295 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark21(91.72402517869276,-6.387716072785268 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark21(-91.94163681851623,11.022918238312357 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark21(92.01792524507249,-100.0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark21(9.215289307935521,-58.17057793506946 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark21(92.30009737153827,-0.579869413851668 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark21(-9.237055564881302E-14,-0.048836496055542966 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark21(-92.38342191188104,-89.06930769563314 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark21(-92.3998141186215,51.661698117468895 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark21(-92.45959045807251,32.17097328271629 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark21(-924.7761965771646,50.92601158250247 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark21(92.55761671625656,-3.2243083027951442 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark21(-92.6769832796834,-81.98738576375354 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark21(-92.67698328089888,26.690059926693774 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark21(-93.36766519138467,35.11121250918292 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark21(-9.368969024316613,-93.80271861452054 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark21(-9.387585938729885,-47.87074153796567 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark21(-9.406347195696242,-15.676466083935154 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark21(94.19960121307764,0.08507432604833554 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark21(-9.424793222873053,-0.18639918129616007 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark21(-9.428684210769411,51.616166776109466 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark21(-94.3110173543084,-5.902547074718836 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark21(-94.59553418802895,-2.680132019018097 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark21(94.79403943418026,55.25389744042596 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark21(94.98538644075632,-33.37731738483272 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark21(-95.03798538419454,91.12853505673408 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark21(9.521748587139895,-0.22896283007452212 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark21(-95.47158545570176,89.06477169689288 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark21(9.551118088340417,-0.167407094256627 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark21(-957.6113637172514,-40.76122262856245 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark21(-96.62932634438683,-2.043971552503309E-11 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark21(9.68668601653256,-0.20808718926984732 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark21(-97.09347347187109,-35.50213353854761 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark21(9.719572385872667,-87.91829225792651 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark21(-97.30237392048753,73.0108492572472 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark21(97.42713633919024,-37.795284580227275 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark21(97.53358951267711,-47.51106429245484 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark21(97.56311831978493,-83.81889714725708 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark21(97.66293237636839,180.11459268062566 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark21(97.7117296279371,27.345500936171476 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark21(-97.96804835189018,28.901129595751343 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark21(98.04473190181878,-153.31680766737966 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark21(-98.12346602963089,-94.59752762578984 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark21(-98.3657367032207,-28.250817706853894 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark21(98.49821723050303,-10.635215935875692 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark21(9.858743422667729,50.740565566211394 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark21(-98.73083275988179,-98.92952936910935 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark21(9.879664196044374,-66.3387064491913 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark21(98.96437762539368,-80.67065020274589 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark21(-98.98984304996685,-27.077713252770835 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark21(-98.99672973387285,-27.235420562076257 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark21(-99.064826976928,-0.01585624660870799 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark21(-99.08650871564953,8.403412425046326 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark21(-99.28058964998611,18.574772341939752 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark21(-99.32788166055026,-18.87596057793546 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark21(-99.36352429682745,-13.492580847551892 ) ;
  }
}
