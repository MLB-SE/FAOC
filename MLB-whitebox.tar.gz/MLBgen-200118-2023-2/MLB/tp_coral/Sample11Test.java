import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(-1.0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(1.0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(-1.0000000000000002,-0.5095229386917517,-55.0750570777563,1.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark11(-1.0000000000000018,-0.868303695379907,-24.304399375802085,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark11(-1.0000000000000018,-1.5490050276065805,0.0,-0.06255294278535835 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark11(-1.0000000000000027,-0.6254073215734199,-39.73527941121527,71.03130044868011 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark11(-1.0000000000000036,-0.3437236605179862,-36.27597114494879,0.47003497094795765 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark11(-1.000000000000007,-0.2706249246057273,-73.6619300035635,-73.28993083221027 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark11(-1.000000000000007,-0.3625036466315903,-30.111740023368707,-42.481779038642756 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark11(-1.000000000000007,-1.2503077458634906,-97.62354990222444,-0.0437540975638705 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark11(-1.000000000000007,-1.267977016328275,-7.674343513036658,0.06255753653008145 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark11(-1.0000000000000142,-0.7556909351985662,0.0,-1.000615409424634 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark11(-1.0000000000000822,-1.5698744166358887,-1.5707963267948966,1.8465957235571472E-127 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.0010238776542122836,-1.5707963267948966,59.369025514558224 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.002188671689433319,-100.0,1.0000026732403813 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.005347790220550763,-96.79526704934518,1.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.00838729580529868,-15.23142823826893,35.05961912788252 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.011955268614878622,-100.0,-0.5180450436403401 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.012295320643358573,-1.5707963267948966,-49.190817181591854 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.027456506347172727,-73.67394625042718,-0.06255276353599916 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.02962183116039178,-66.6897432504809,1.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.04984539412664893,-0.40863976045640066,0.9999999998829445 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.05789878339111935,0.0,1.000253376427765 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.060036315544709645,-79.50743068830923,6.938893903907228E-18 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.06010578106540554,-0.07053215906247932,80.11340175669096 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.07784831969848305,-88.25096322454874,1.0542197943230523E-81 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.0828775911739473,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.08582373966508972,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.10679812663110523,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.11760181512515537,-28.735610310354815,1.0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.1275682733238214,-53.83458250791737,-0.8545008540998622 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.1402226147355056,-100.0,36.69930674499703 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.14463008363082253,-37.86989988832192,-1.0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.14545494851229362,-1.5707963267948966,0.4335031185687104 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.16711613686272717,-110.52122789272768,-0.028533793347367234 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.18198073391659683,-1.5707963267948966,7.998188687472597E-15 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.18779010829877904,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.19838428083247095,-23.983595146902932,0.4331754060254016 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.20330691247214874,-86.09894372659758,-0.06255499714530303 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.20994942449495768,-0.7130701167834026,-0.05200856983055274 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.24523097798859242,-1.5707963267948948,-0.9347896171654924 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.26341674757508554,0.0,1.0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.2636102206052563,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.269303980705754,-100.0,-1.0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.2711818946521752,-47.04983737558501,1.0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.27631385647674683,-63.657692197009354,-0.010167483415045364 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3428590203361064,-72.86766197877101,9.110143229295595 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.38976898754712974,-11.645529626087214,-100.0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4004513894833606,0.0,1.0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4013398297630766,-20.98939495797406,-0.9999999999999964 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4039625352470818,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,0.4694332070740031,75.86112860842408,-53.609122092015426 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4810405632319288,-100.0,-100.0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.48647615754671664,-67.84616985617448,-1.0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.487651161726699,-65.64170113959203,1.0000000047795268 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.49137596208277995,-77.3218313288013,-0.3625605583697956 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5149065887300706,-11.058668338840336,-5.250107630564765 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5263407741859965,-65.70897372946791,-1.0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5288093370219,0.0,-1.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5425799491434512,-19.85136849604229,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5494053185963179,-54.31247367858638,1.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5646616721290574,-63.24473558250406,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.569434897390006,-73.44791343458338,-0.6643035379462239 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5938501074949031,-100.0,-28.86115541886317 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.606392366542356,-99.07946296700408,38.62452305125838 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6073648419086362,0.0,-0.7444286675728934 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6259882487546796,-1.514164665935901,-1.0000000271617742 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6485440559566481,-0.22302298606660742,42.065018892997486 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7242508394067987,-43.40359619795229,8.881784197001252E-16 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7283029216600596,-2.7356756126406765,-0.178561050029995 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.744041791304164,-39.603083023876785,-0.8309909748013571 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7646673731245218,-66.30369282917948,79.17364750594845 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7883199450748707,-29.915188651240523,-1.0000000804304738 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7966417790205369,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8273805156094276,-44.51898997912588,-86.31032294017716 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8521009274941184,-14.257572094112927,-0.6430891143759894 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8574875972272487,-100.0,100.0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8641617653643503,-38.21252762474927,-1.0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8760440691143576,-0.09104205158161706,-0.06256003904317087 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8965830472921048,-28.28264007316139,-25.058553368989948 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9198417394409022,-7.151072857487264,0.872359318509754 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9420506094917996,-0.24619412826041076,1.0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9795130316758978,-10.679484455063779,-0.04016187912867086 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9830787835623406,-18.19276492115335,0.9730514291083898 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9921095477268587,-100.0,-1.0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0052231481355092E-16,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0063457299211913,-75.05986943897116,-1.0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.019544703114338,-15.53193511171714,4.647348893159901 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0211945934090996,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0270845322393423,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.054149209866155,-84.23915415854,0.8591930416416809 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0733464280050915,-1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0898290783347893,-26.805084451357516,-43.61906949140859 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0924366200314009,-82.84454323942512,0.6786164282645792 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1099244093893805,-46.564706647425695,1.0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1313563199024126,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.132860074955289,-6.325222456675843,100.0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1397476581763077,-53.108783406024315,-1.0000000000183218 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.140575998909281,0.0,-1.0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.166908581071787,0.0,0.9905676126472621 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1729339415428648,-45.16720082370224,0.0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2002376854883845,-42.742470332138005,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2078605165863294,-59.9492712216755,-1.0656100492701297 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2162220617368493,-0.8008299072773375,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2197770428646035,-38.57859894476789,-0.13493844944386602 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.232956720707293,-84.4259524655087,-1.0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark11(-100.01236642809835,0.48664941860019956,-1.5707963267948966,-41.25280890343468 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.273551094362124,-1.5707963267948912,2.710505431213761E-20 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.275043514438453,-41.79523834565689,0.0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2808535052628507,-38.86613604415065,0.05732849497860913 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2894544912053905,-33.99722329570812,-1.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2945265625368156,-94.83276201011455,1.9291160237805676 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3820822718794562E-14,-36.08606299022409,0.0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3877787807814457E-17,-77.0345950540785,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3927105577944918,6.440698729148171,2.216099626939914 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3949905859183023,-100.0,1.0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3950844798558364,0.0,-12.523346512728553 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.399228570466031,-27.68421299686404,0.0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4105212163718848,-43.710720122129025,0.5709560217894563 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4129269626876217,-73.48105046821615,0.015680315430660147 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,14.467488433691457,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,14.478008170726667,-1.5707963267948972,100.0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.461766091255339,-19.156983628202877,0.979254328013719 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4629581008494577,-98.0129465757827,-0.6203830999091868 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,14.779713975105203,80.30223660507139,-96.19427579287347 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4795997914279098,0.0,-69.46143899711458 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.482361335601944,-4.195382081702125,1.0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4835617957186036,-1.5707963267949125,2.0590230357872116E-84 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4839807380317276,-13.209957626078463,-0.010368273690590346 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.517856820530599,-10.679259758880292,1.0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5209695175690476,-39.13281573056544,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.528527790312133,-8.673118001764486,66.22175328554117 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.54068306191636,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5559375783425553,-20.99633664195195,-0.6132683979603661 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5573940300768585,-1.5707963267948983,0.9999999999999998 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5588005942696546,-1.5707963267948966,1.0017568856577355 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5623756475133235,0.0,-1.0000021305961249 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5630531838984005,-13.42898458398292,1.0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5657938585592505E-14,-1.5707963267948966,0.010521109332607586 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.568850442042597,-54.39455835812246,-0.026701825680583213 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948024,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948468,-100.0,-0.019168570623784964 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948593,-0.29625634063732387,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948735,-66.34542917536797,0.0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948797,1.5707963267948966,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948841,-48.70506681233261,0.4955136670329847 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-100.0,-63.504205696822495 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-4.36536736379864,-1.0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-47.911212873199055,1.0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-66.11792129887019,45.91752611976762 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-95.00143539704102,-1.0000000000000016 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-35.35887937886437,-100.0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-3.552713678800501E-15,-1.0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-4.264745120052995,-22.915861661413473 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-66.11597536174835,-1.9087365094411224E-4 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-79.0197814607385,-30.721703427929963 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-9.817000933659433,-1.0067045445077667 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948957,-1.0042502534012945,2.559866604375968E-66 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948957,-11.044934116651177,-0.2037358682951443 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948957,-17.327284915532438,-1.0000001164884549 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948957,-45.24115415609912,-1.0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948961,-36.515501926012064,1.0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948961,-47.32855771217066,-37.25008927246047 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948963,-77.21610499726121,1.0587911840678754E-22 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948963,-9.583312708733445,87.14385983507043 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.7763568394002505E-15,-19.096163335717492,-1.0094081363619474 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.7763568394002505E-15,-82.4823924506278,100.0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark11(-10.001950052339415,-0.11272797586984784,-22.028178314376987,-1.0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.9721522630525295E-31,-21.666122806195823,-8.470329472543003E-22 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-2.220446049250313E-16,-0.6806781588993497,-23.0918467080001 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-2.220446049250313E-16,-26.36225151701963,-0.00732712300657622 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-2.220446049250313E-16,-3.7906145669359455,0.06255252568197991 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-3.552713678800501E-15,-27.340273291327776,-1.0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-3.6266276824217087E-4,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-5.551115123125783E-17,-0.30096245981070624,2.1389771117372764 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-6.542872818807451E-16,-88.17868374565236,6.938893903907228E-18 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-7.194532790039453E-14,-1.5707963267948972,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-7.766081013082794E-15,-24.628755843759887,-0.9999999999999982 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark11(-10.049154757665633,-0.7741658391407498,-67.43339363939164,-176.58434910901371 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark11(-1.008648801200934,-1.2060172286560373,-42.865989595815996,-21.605871650075684 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark11(-100.92357267681935,2.4433262282603265,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark11(-101.65191916285349,-1.3325900455188762,-62.48515820874025,2160.6378097759684 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark11(-1.0185004580158221,-0.3905769453654371,-79.48815688528217,0.23981637117051058 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark11(-10.19762998156379,-0.5924219370636692,-67.72966820747627,-0.8359205728606266 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark11(-102.13898342252519,-1.5707963267948948,-11.320188148057488,-2008.0921860448746 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark11(-10.29668214983177,-1.205242073970936,-61.988713249731674,86.91789243472232 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark11(-104.0045922045822,-1.4344341341115106,-1.5707963267948966,0.048507881460574165 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark11(-104.06589367771096,-1.5407881197441782,-95.7722523854436,1.0542251530351479 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark11(-104.20587020939874,-1.0515065554762515,-119.17360045987103,2062.427086302722 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark11(-104.20837911011584,-0.16686949024987968,-40.20132332483683,0.656262215912804 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark11(-104.42581897999575,-1.4030745403754308,-1.2003457591852253,2241.7783602822533 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark11(-10.446406331643983,-0.4284579760676776,-3.3641463471830555,25.174794071536304 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark11(-10.466268976555845,-0.020404364954194846,-21.295693327752005,0.16623667826565303 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark11(-10.530574177834293,-0.673359862439044,-50.08124113308295,0.0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark11(-10.56329458858109,-1.5707963267948948,-9.375359093012134,0.06255376896984362 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark11(-10.565837914477044,-1.5707963267948912,-75.17947844402435,0.27103549394506576 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark11(-10.729341825804255,-1.570796326794877,0,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark11(-10.777509831686544,-0.2336124334304306,-100.0,1.0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark11(-108.0565700235331,-1.1094328525902881,-61.931561614042664,-0.017970118760849307 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark11(-10.80906597122447,-1.7763568394002505E-15,83.95571056450044,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark11(-10.859810681563516,-0.1424565663249684,-1.5707963267949034,1.0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark11(-1.0871262240101416,-1.5707963267948912,-72.72453906770049,4.656953594399148E-15 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark11(-108.71662175263543,-0.019321441900822703,-20.223489567690972,1.0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark11(-10.935238377004818,-1.4368151443532011,-81.40041142858803,0.988995863685405 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark11(-10.961779398173007,-1.2885584545252158,-30.250020425207758,-0.015868312005777374 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark11(-10.969539489198777,-1.08613318662335,-65.28483982771087,-27.556899739233074 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark11(-10.9798148076641,-0.38865487974260265,-1.5707963267948966,-0.2723587481806843 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark11(-10.992308935920805,-1.4578854639777896,-0.7337914802553732,1.0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark11(-110.10034151603304,-1.0522100916228387,-1.5707963267948966,0.1686421533750746 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark11(-11.026841394641279,-0.39349877669504596,0.0,-1.080111452422221 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark11(-11.02831229461536,-0.937817342948352,-1.5707963267948966,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark11(-1.1040234232566488,-1.7763568394002505E-15,-73.36780072544862,-1.0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark11(-11.090252729842296,-0.0684203194550605,-0.15478069690130664,0.0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark11(-11.115160108102893,-0.8743868343081388,-1.5707963267948966,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark11(-111.39640984685532,-0.8150051425869203,-92.92761256881661,-1.0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark11(-11.183530354861645,-0.7459924282744937,-34.67079590792604,0.03093976629421153 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark11(-11.22647597511911,-2.2969262398023074E-8,-4.712731687372858,0.03427077372897536 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark11(-11.236927676835968,-1.5707963267948948,-75.14011715153292,6.870045576625511 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark11(-11.242225541346883,-1.5707963267948815,-38.98637060076475,-100.0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark11(-11.250511195257618,-1.5404083291951665,-74.95238301732574,-1.0000000000000009 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark11(-11.254943951439206,-0.0988358151873836,0.6125090267667469,-0.17827130021889726 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark11(-11.262242619902139,-0.4415011203512398,-44.642427410748994,-1.0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark11(-11.287230587251798,-3.923989748814035E-18,-1.5707963267948966,8.782544372375018 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark11(-1.132850423115287,-0.25090865316704525,-69.00361492576252,0.06043824705218822 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark11(-113.42960445296818,-1.5707963267948963,-4.442136917426936,0.4896587959984197 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark11(-11.41398355466172,-1.2237726027472031,-52.94233797182362,-1.0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark11(-11.458843848912506,-0.06398701805423257,-62.407550887982175,0.366157903246324 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark11(-114.6273302801083,-1.463601079969966,-1.5707963267948966,-1985.2550941409213 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark11(-11.484593047719812,-0.5768666404347049,-88.38928163673775,-6.626568535516682 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark11(-11.485020739956141,-0.2419381656938675,-0.5607777839430154,77.67572851366705 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark11(-1.1487560013896916,-1.5707963267948963,-39.995187947106295,0.8038489650476994 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark11(-11.524401501438973,-0.5951584004558548,-194.04816314188258,-38.30074553956771 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark11(-1.161438513515257,-8.881784197001252E-16,-1.1188486599421574,-1.0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark11(-1.163816977554568,-1.5707963267948948,1.1875333702009345,-71.87376252564124 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark11(-11.645301697714697,-7.81007386264472E-4,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark11(-11.646708699248308,-1.5707963267948961,-0.4479320210860455,-0.036993364297244875 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark11(-11.672405426708588,-0.06294958500696664,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark11(-116.85163458596426,-0.11763446187738216,-68.05344573148547,25.668262416177253 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark11(-1.1750232184690006,-0.9355768894273675,-38.40429984854262,0.638287340214748 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark11(-118.207453467336,-1.1013981376330566,-65.70511926739863,-98.80877626885642 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark11(-11.823730235162316,3.9627419872119076,-1.5707963267948966,15.058133766350917 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark11(-11.85739872816188,-0.4642641609163176,-34.16479866286176,1.0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark11(-118.65600986751481,-0.004120824317928418,-38.853239641582135,1.0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark11(-1.186775785973642,-0.19120989047222192,-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark11(-11.890989066577156,-1.5637039387491543,-18.023130541626408,1.0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark11(-11.896610176512741,-1.434376450491099,-35.22329186189239,-73.6669308606854 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark11(-11.898256568842797,-1.3221959307730895,-32.80149031631885,1.0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark11(-1.1901470534492713,-3.552713678800501E-15,-20.688460997913516,1.0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark11(-1.1912335677167964,6.524730160629297,15.36336103403152,6.938893903907228E-18 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark11(-119.40686611461058,-1.537554423460306,-122.49231341583945,-0.9999999684087176 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark11(-12.004315881482245,-1.4895248695779126,-1.1667862879246491,0.3621093427701615 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark11(-12.033045543109418,-1.3399156156932204,-37.553014905827574,-0.030087424643422178 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark11(-12.061850933673718,-1.029877375886355,-6.472000316388039,1.0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark11(-121.41208829869748,-0.020264973313349977,-30.152144697576404,-1.0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark11(-12.144959569839646,-1.1476749020117958,-33.727596704386784,-54.47966844078247 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark11(-12.180086873894197,-1.2542514380550702,-12.024317178811657,0.3603261728599465 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark11(-1.2182318111161194,-0.08660024254752974,-41.449609922119855,0.9999999999999982 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark11(-1.218439480816574,-0.28522707572065875,-71.40702360209045,0.01030153365784072 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark11(-12.215597587981472,-0.4782758461424441,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark11(-12.34088145909871,-1.5700007568825698,-40.28538694545814,2.220446049250313E-16 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark11(-123.48771255590852,-1.5663155338175825,-36.466299447732474,-0.3189423918962402 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark11(-12.356995580937026,-0.19731600584361875,-26.218626846882728,1.0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark11(-12.43600005672192,-0.455518951724303,-86.70299260999923,-1.0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark11(-125.22004986494304,-0.9162191034683511,0.0,2199.460781040609 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark11(-12.528282110486566,-0.3287452531636603,-77.34696771599229,37.63911033149924 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark11(-12.61039835220446,-1.0694164678160163,-1.1214050927313612,-1.0004404905693507 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark11(-12.618382787183094,-0.70302127904257,-4.592862236517632,18.01126457712259 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark11(-1.266102600524178,-0.0014214497142192872,-45.315660809537114,0.0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark11(-1.2673750310762566,-0.20574083358550865,-31.922063217715394,0.0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark11(-12.681427896461912,-0.26183077030115065,-6.39793794823602,-1.0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark11(-12.761904489411132,-1.5707963267948963,-15.899915239131609,36.86229283525194 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark11(-12.81541501426845,-0.22029979512890077,-68.24993190264276,-1.0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark11(-12.856136722557437,-0.640919238007664,-23.866579154775778,0.9916029917793168 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark11(-12.883910413634908,-1.5707963267948912,-87.11266386282679,63.06273220991578 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark11(-12.883939323430337,-0.44828442099345506,-29.855392518289122,-4.377738116977881 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark11(-12.902430703202064,-0.3344384623158163,-7.998635391099574,2225.336595926303 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark11(-12.975155950074198,-1.5707963267948912,-47.545048470993635,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark11(-12.97726064765876,-2.220446049250313E-16,-20.27079097592741,8.043319601703452 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark11(-13.034105646407204,-1.5707963267948963,62.15264880809451,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark11(-13.047427236431789,-0.5429974920151588,-66.19101287970463,-1.0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark11(-13.095808016716672,-4.022378893607361E-5,-45.30683539317321,0.17261916056988688 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark11(-13.11119726008051,-0.021358952114616025,-0.5442276620671745,-1.0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark11(-1.313186569069902,-0.9745046896718415,-22.634627502680154,19.872961445077955 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark11(-13.183365598648194,-0.916604134298936,-0.9269993900714155,0.15020117774034825 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark11(-132.06674773458485,-1.169665370423981,-38.97632032041598,-0.8120640968777479 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark11(-13.287438074943964,-1.2803910356410548,-9.551781719026891,1.0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark11(-13.359297312219805,-1.3729646196090253,-83.10198421689587,-1.0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark11(-13.36974949922556,-1.3041873308795289,-37.03274098231811,56.219732602557144 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark11(-13.592280716493576,-0.5959685214697764,-9.704927207775384,28.89823498333037 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark11(-1.376015108036647,-1.5707963267947633,-89.48839523996969,0.12641178609248316 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark11(-13.76259248778473,-1.4210854715202004E-14,-31.933588011243202,-34.973766611563974 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark11(-13.871114256736542,-1.227667700832538,0.0,-0.655995420574667 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark11(-13.87252479062966,-0.0012781322588969503,-96.8065654691811,1.0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark11(-13.900157712457778,-3.552713678800501E-15,-1.1655255277446683,-28.55543943464362 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark11(-139.56326425307668,-1.34223846064957,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark11(-13.981023417356464,-1.0632106363975469,-88.58065381718774,0.9248839120921182 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark11(-14.063144378895919,-0.23685125162193202,-1.5707963267948966,-0.7299727531244429 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark11(-14.068718880265251,-0.7578970686897781,-1.5707963267948961,1.0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark11(-14.073113998054493,-0.07579502758997075,-53.820658658380665,-72.9469535316575 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark11(-14.079037573195706,-1.5086116088356119,-1.5707963267948966,-2125.3109444319807 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark11(-14.094124774739235,-0.0306276657209467,-39.922746052391574,-0.06618738590921969 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark11(-141.00331112965802,-1.2457837155346634,-62.311194465389775,0.9383540173345502 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark11(-1.4154321750080117,-0.5490296884553563,-52.78972058650077,50.86981010508852 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark11(-14.24513755658123,-0.029691372432491182,0.0,-2185.250779993521 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark11(-1.4252815124345921,-1.4483990774306357,-12.140782023828336,-1.0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark11(-14.258736640236421,-1.46038123255796,-8.597238859671311,-65.93713770406997 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark11(-14.266450118881226,-1.4015366847947386,0.0,47.6596785685787 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark11(-14.284757800729377,-0.8922278160730599,-33.4712755033773,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark11(-14.285594178420308,-0.06170505134737067,-32.095867834933934,-100.0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark11(-14.289916804105992,-0.3355319857461868,-56.536099161403854,22.50245499790722 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark11(-14.369632258144215,-1.008785043174269,-99.2407131857581,0.5574733412423775 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark11(-14.405121246650157,-1.56164547943483,-0.9305741143011184,51.857286704475975 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark11(-14.41894348767098,-1.5239745219297351,-21.797185965041457,-1.0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark11(-14.446128210836775,-1.0436064003091161,0.0,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark11(-14.458454148679627,-1.396056142626577,-3.231582892431618,60.10678807698973 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark11(-14.47694645810632,-0.25333307792707904,-97.88024651039404,0.07848871881300434 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark11(-1.4487970026735155,-0.20916675110177074,-65.7151737431715,1.0000000000000004 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark11(-14.503924490283445,-1.3955558830933488,-50.77242425584165,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark11(-14.505894929217456,-1.1902086586781273,-74.46398181913668,0.5179176305052238 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark11(-14.54336032440311,-1.5707963267948957,-0.007171359852149745,0.0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark11(-14.563361136194104,-1.5707963267948948,-66.1440590618873,0.7855343350667086 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark11(-148.08979563410304,-1.5660998807114408,-101.96460307616489,-2085.3374634404136 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark11(-14.927579886184645,-1.2787779226395881,-1.5707963267948966,-7.0928705175280555 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark11(-14.950982457772463,-0.7635621885605319,-37.83375412200807,1.0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark11(-149.88791874288222,-0.9385280086033134,-27.80972596215601,-1.38714061893684 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark11(-15.017819732678324,-0.9346809104366863,-0.2777020740931131,-1.0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark11(-15.029404615268671,-0.03481660665189268,-10.741953931765607,1.000006913010696 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark11(-15.087700824024441,-0.19142743406719723,0.0,25.502864341114616 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark11(-15.092375504988258,-0.3040341931613456,-4.168483148005549,0.9683605954621355 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark11(-15.116286737285261,-0.03585140923079324,-15.47693041015468,-1.0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark11(-151.600397183364,-1.341987954232124,-87.73989341299642,-0.07313305621988775 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark11(-151.7928421490047,-0.3523412339308578,-4.814573102909961,-24.192969059896257 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark11(-15.228162642599523,-1.0352889019416995,-64.74756644613711,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark11(-152.6171279983365,-0.02836156124748022,100.0,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark11(-153.35280595832637,14.436246278528571,126.72783865744803,7.474077576021742 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark11(-153.79136911025003,-1.5358366577316427,-21.870884938854942,-13.889223827729197 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark11(-15.422443713297206,-0.012541210119552807,-95.4174612252713,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark11(-15.46527598007112,-1.202753739875106,0.11048240112793518,7.703719777548943E-34 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark11(-15.496851831829634,-1.5707963267948948,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark11(-1.5532523142519938,-1.5707963267948961,76.41092225903577,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark11(-1.5663125081003506,-0.6588198599634463,-136.19544539282353,-4.6501726766330006E-5 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark11(-15.679763921949462,-1.5707963267948961,-52.776407009887585,0.6396002226530131 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark11(-15.851820336364568,-0.28236282231889076,-5.708176803380027,-18.021363197624318 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark11(-15.927031649574985,-0.11273481227924265,-35.55336753871214,0.9745738862781348 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark11(-16.00202558940324,-0.749506903543871,-100.0,-0.3621646545456102 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark11(-16.009753750260984,-0.10029449849772315,-13.895162528196963,-65.89751460926776 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark11(-1.6027686684752354,-1.7763568394002505E-15,-16.409901584808402,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark11(-16.033440311495003,-0.07594969916133851,41.02672886815003,20.666088134874048 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark11(-16.1865395790347,-1.5707963267948912,-119.66906436043423,-60.051572648106166 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark11(-1.619206894506405,-1.570796326794896,-30.068933041083955,-0.06255257877320569 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark11(-16.206354134132127,-0.04580836583213142,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark11(-1.6206750233892584,-1.4789911279847427,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark11(-16.223150429732986,-1.538666650382875,-86.76597287903418,0.9448158298491692 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark11(-162.6296808763429,-0.1683370822582333,-74.40958913632447,1.0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark11(-16.264453650478337,-0.4171054390598492,-28.04163363117774,-79.33663372044084 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark11(-16.271079267892418,-1.2291048427601994,-1.5707963267948966,42.71644328449861 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark11(-16.2871244854566,-1.5707963267948948,-12.458827713798339,0.026547422140526276 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark11(-16.368184519109228,-0.9360799625633556,-14.461415322791911,-1.0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark11(-16.389791390330828,-0.8575826450350028,-50.074134950745496,-41.615721500653 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark11(-16.398323133090287,-1.5707963267948948,-62.68050715185402,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark11(-16.519713294604884,-1.5707963267948912,-100.0,100.0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark11(-1.652713309772355,-1.513725909591788,-66.51225077806424,0.9618873440493243 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark11(-16.548797655164286,-0.5337630575068595,-26.903185056042343,0.9371101918207898 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark11(-16.567252796472957,-1.278912445055801,-67.66787851405297,0.06255266633441796 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark11(-16.65203853451511,-0.45831340868615156,-47.107044305995146,-63.79447658903621 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark11(-16.68623951249914,-0.1745572438072392,-53.838340296729875,3.2626522339992623E-55 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark11(-16.703480839100514,-0.09066016190438587,-81.93540551967276,1.0021398921682954 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark11(-167.04195970250433,-0.5267757294926669,-100.0,1.0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark11(-1.674287768539832,-1.3374354269843187E-4,-58.3463633357792,-0.3823595011797679 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark11(-16.831349929636723,-1.078041146935418,-75.41471788475546,-0.6618808354741967 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark11(-16.918486118074853,-1.5707963267948912,-96.14470807669433,1.0000000000000009 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark11(-16.989748737187412,-0.6636545411136603,-13.536578577802906,-14.055346630377944 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark11(-17.048190435911703,-0.7035794989603592,-125.52714372947031,-6.004443506437056 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark11(-1.706001417206984,-0.011372760033078471,-38.97549105658223,-7.52316384526264E-37 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark11(-17.102902837577652,-1.1481187414374943,-33.14410252106994,-1.0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark11(-17.140026756560474,-0.2420394648550186,-6.963880103879547,-21.38229735085571 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark11(-1.7192460445984539,-1.121583804564776,-41.60563670327781,1.0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark11(-17.219202290585606,-0.466398861022507,-1.8981104350976659,29.932863441024036 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark11(-17.278844694477613,-1.0253427012591914,-3.1647809642125577,0.059589798460073506 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark11(-17.303581070879314,-0.006894386606543151,-43.93400078343163,1.0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark11(-17.327037204992408,-0.009225567895077447,-153.41299925522563,1.0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark11(-17.329568439888344,14.430202758463416,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark11(-17.355603279421416,-1.5707963267948912,-14.73851439710279,1.0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark11(-174.1785550280726,-0.5078073496274639,0.0,-18.426574463171065 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark11(-17.43119130386044,-0.22006347222856593,-19.38774442335064,0.05609684675213559 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark11(-174.5342636199226,-0.9526218788677383,-93.17048773749424,-1.0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark11(-17.509011310092,-0.8673138484784727,-4.73821623293413,-1.000000131434648 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark11(-17.515823060843125,-0.4740180473864749,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark11(-1.7565730317578385,-0.8983974250905595,-63.895638235266624,-0.6866489008415833 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark11(-17.574460783008348,-0.7576583299375697,0.0,0.664786528939106 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark11(-17.574909692513906,-1.076365498780505,-0.6557830180067699,0.5604659848409179 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark11(-17.5885279585138,-1.4105991380467071,-36.69504137547846,-0.3500607835152978 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark11(-17.607863590880374,14.436408932164525,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark11(-17.616688416737418,-0.6263111503638593,-1.5707963267948966,1999.2305814672006 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark11(-17.63424487038303,-1.5201929212714307,-27.820588103356215,-1.0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark11(-17.716546679875353,-1.4862849994229188,-2.465190328815662E-32,-3.4278815856352914E-16 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark11(-17.757357852693577,-2.209530621315172E-12,-1.5707963267948966,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark11(-17.871383417706912,-0.22570435513605774,0.0,2055.255503504971 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark11(-17.903024586487135,-1.1984792602934173,-1.5707963267948966,60.23517677305985 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark11(-17.943161380421763,-0.179163990638716,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark11(-18.22923687602744,-0.18793223381102273,-71.59426233798703,-1.6242827758820155E-114 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark11(-18.281969442883042,3.9006122470178073,-1.5707963267948966,1.1926226754889104 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark11(-18.463370955908175,-1.5707963267948948,-79.29363555704325,0.0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark11(-18.529741665672248,-0.4915465725754067,-2.3415665335643787,-0.9686642768524371 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark11(-1.8531565487200936,-0.026663196737438,-29.258355418989005,-1.0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark11(-18.612035300152858,-0.5370506061873535,100.0,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark11(-18.733393563393292,-1.1433302534794743,-37.35225581644485,-95.11129010455561 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark11(-18.775651639412537,-0.00915286483575822,-100.0,3.469446951953614E-18 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark11(-18.87895250054983,-1.5449660413974493,0.0,-37.360813029661955 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark11(-18.884674830506135,-1.5601420903059124,-30.752837166165037,0.9636524084327285 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark11(-18.978620664696724,-1.5707963267948948,-11.719187904056316,-1.0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark11(-19.03323566244374,-1.4515868054705479,-80.27754610656694,0.05794221035595512 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark11(-19.143359060800023,-0.999966137694063,-83.89624459362757,-78.44980252932463 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark11(-19.197160685450715,-0.6127687145655213,-19.28481009022058,-37.901148211820676 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark11(-19.211482404195515,-1.4526332021260597,-67.45682490207572,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark11(-19.221525124076692,-1.4194362351297445,-62.518329645881735,-0.3820870303780285 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark11(-19.261721938446584,-0.9265428128402817,-39.612314485977535,-0.02303803850803765 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark11(-1.9286376227863231,-1.4623260388252934,-1.5707963267949907,-1.0000396744283728 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark11(-19.33825156105217,-0.7123263347087392,-1.5707963267948961,-56.50029262222391 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark11(-19.342562592040167,-0.05915334344154022,-38.95450054700922,-67.98592798300079 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark11(-19.37991009248629,-0.0021167794561527953,-62.23308983579919,117.66273302200668 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark11(-19.44015203278301,-1.4243742461619915,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark11(-19.495414240575997,-1.3958623709872322,-61.24918562803996,-0.019479776490555295 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark11(-19.499296836282426,-1.3789236846047999,-0.8732298333143191,0.170596496816799 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark11(-19.601428087576824,-1.0393249640535829,-1.5707963267948966,75.14850834535181 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark11(-19.674082228528146,-0.8425427387957505,-72.67983067948282,-0.815996526147468 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark11(-19.68799654642776,-1.0152502872667537,2.1146516508991545E-16,-0.9993847273072003 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark11(-19.812216932609832,-0.009034024177465029,-84.5398428697439,-0.0507751416436677 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark11(-19.814677449988586,-0.09820414258753463,-67.24428588285997,0.0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark11(-19.86743918601312,-0.5030753061651232,-1.1592821887400393,78.70490668762716 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark11(-19.915397393623316,-0.025539783772977807,-9.953234353902797,0.4320422438698418 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark11(-19.922754573442987,-2.220446049250313E-16,-88.20540007753178,64.32513450308153 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark11(-1.9978868671744863,-1.5707963267948948,-1.5707963267949694,67.58249442370209 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark11(-19.980386684842372,-0.8934245446634437,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark11(-20.01546606473637,-1.04245033857275,-0.07634998536208526,-1.0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark11(-20.030079413419315,-0.609105317252185,-75.30456830919941,8.673617379884035E-19 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark11(-20.14584532307353,-0.7156807180352855,-72.47976183934144,-1.0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark11(-20.164750167622515,-0.18754187803636424,-73.04282271862313,-0.933146705329855 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark11(-20.175110247708812,-0.032370728861847636,15.411177522889844,99.40129087121792 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark11(-20.2048004042348,-1.336409885311734,-25.463986180329332,-1.0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark11(-20.240753192065483,-1.5707963267948963,0.0,-28.091461865084987 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark11(-20.26806282130653,-1.5707963267948912,-40.710633603510246,-0.869843941810995 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark11(-2.027586303333151,-0.7514064042082679,-1.4040289399334553,-1.0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark11(-20.33419352102352,-0.09199071309534386,-21.13482473594253,-0.722124790330176 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark11(-20.360174832117305,-5.551115123125783E-17,-0.41095363655887557,-0.44390724995056524 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark11(-20.400012155561992,-0.5466227603527454,-82.28779942845836,-43.52239971945423 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark11(-20.40977809964833,-0.9521566314418078,-45.09400614515782,-34.318712280798586 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark11(-2.04311688529881,-1.5707963267948852,0.0,1.0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark11(-20.445341378543443,-0.417114631110726,0.0,0.06261866913670033 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark11(-20.484569973541,-0.17676543096097924,-0.3397486584073848,1.0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark11(-20.489195118359543,-0.986541490203023,-46.12487625321626,-59.23224699840649 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark11(-20.492871406760216,-1.5707963267948948,-37.9662565035184,86.3498451773417 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark11(-20.531702310540865,-1.3234893236667986,-18.19292890279351,-78.04626790965663 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark11(-20.549338264644856,-1.4410569129768087,-31.497574773075428,9.860761315262648E-32 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark11(-20.59512164017486,-1.376030407535718,-14.0511247590745,60.345084622434314 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark11(-20.711585105565327,-2.220446049250313E-16,-1.5707963267949054,-0.017080817201114887 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark11(-20.719047661308796,-0.053337094445929156,-38.86140615272244,1.0000000000000009 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark11(-20.759113807123306,-0.691862856903382,-81.29120659109441,-100.0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark11(-20.76412794312388,-0.10586978960942166,-1.5707963267948983,-71.78359537595087 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark11(-20.78335855417958,-1.2034679946762954,-44.3822160401217,-0.2442287809191509 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark11(-20.810090975715838,-0.6689335616580975,0.0,-0.32855200760158587 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark11(-20.96822965582033,-0.825485660317169,-49.845995608348225,-47.6941887166973 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark11(-21.004747163033997,-0.41419179504009024,-15.312417784322951,0.0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark11(-21.02384183437311,-1.5707963267948963,0.0,-1.0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark11(-2.108527292047071,-1.3361748241662177,-81.04295801004767,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark11(-21.251848146931337,-1.3785019229523943,0.0,-1.0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark11(-21.36135121649818,-0.144294525732377,-85.75205771277743,0.8539680351877911 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark11(-2.1385307526395003,-1.3009518516562193,-79.00052076901588,-37.95112475220919 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark11(-21.466733966482778,-1.5707963267948961,-1.5707963267948966,-0.13525132837152865 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark11(-21.477962093971527,-0.8926193658715793,-9.593826315724096,16.34029916367123 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark11(-21.503978654730858,14.429363707459665,0.0,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark11(-21.511588432442593,-0.14274816192854511,-55.93438176137153,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark11(-21.53300164472338,-0.20711750945844165,-1.5707963267948966,-0.17200461026094604 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark11(-2.1558659706503125,-1.5707771803330046,-37.45598040795429,0.0077695084137114345 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark11(-2.1617437139720925,-2.220446049250313E-16,-31.59380921139289,1.0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark11(-21.649063072523077,-1.1403171463845965,-10.267787696534825,86.3250707921265 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark11(-21.668414073291203,-0.12843968328874508,-8.743998601122698,-1.0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark11(-21.672272223561343,-1.5707963267948948,-72.15125579072644,1.0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark11(-21.792109604674167,-1.5211675257169686,0.0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark11(-21.937402950942996,0,0,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark11(-2.1939746707046135,-0.18095739488110177,-61.339007231072515,-57.72566151009113 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark11(-22.082937229205903,-6.242643138467708E-15,-1.5707963267948966,-0.9999999999999973 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark11(-22.094892808969504,-0.25886792600996933,-8.1661018177723,-0.48225326017399883 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark11(-22.09775951052359,-1.069298576828674,-90.18266294528271,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark11(-22.156067376212548,-0.8389247729493209,-44.336948902095074,-21.58876697333045 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark11(-22.184995327237516,-0.04839848376052182,-37.00721130746893,1.0000003449810773 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark11(-22.296715205831276,-0.779535720252257,-52.43154580809713,-51.4764912412549 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark11(-22.39909882295224,-35.6187224246971,0,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark11(-22.504164580433923,-0.3860422892741307,-17.410611393383533,0.9999999999999999 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark11(-22.610707076856905,-1.1102230246251565E-16,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark11(-22.666156810707648,-1.5035416497415168,0.0,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark11(-2.272855683360575,0.11519983723829641,-1.5707963267948912,-16.176391463973232 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark11(-22.76333841435196,-0.25603361986875917,4.440892098500626E-16,0.7764088820159758 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark11(-2.2842079066986094,-1.4081170617570369,-43.415786042183214,-1.0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark11(-22.90463473599185,-0.7300209156022959,0,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark11(-22.996097796553233,-0.021151719829998552,-7.80743892100213,6.938893903907228E-18 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark11(-23.06237509326965,-0.8438837467736345,-26.027033240227794,-1.0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark11(-23.128213387999143,-1.5318639318399327,-39.028245427871,2.6469779601696886E-23 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark11(-23.26399492075429,-0.16083479530564126,-43.889429537117394,2.135929750813858 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark11(-23.33187136634156,-0.39581576739379287,-1.5707963267948983,-2171.705826651796 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark11(-23.483244546074694,-0.0933915097387823,-1.5707963267948966,-0.9666008669847326 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark11(-23.498673996591847,-0.7920335463537787,-47.88528921702204,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark11(-2.3520307185462226,-1.558362431119397,-16.674747020527747,1.0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark11(-23.532934325451112,-0.9524377853167196,0.0,0.12820356809334144 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark11(-23.75372475975237,-1.3519903498524855,-44.025688248066196,0.885249618898226 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark11(-23.905093632703608,-0.3872640317588369,-0.8502901558717711,1.0101680596545874 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark11(-24.00065526003327,-0.36926768811194766,0.0,-1.0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark11(-24.02138691079901,-0.1461498917240784,-61.89670874010045,-1.0000000000000002 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark11(-24.02831684975812,-1.32717120745032,-45.685235641741784,-0.9999999999999991 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark11(-2.404648208481376,-1.1292639426192324,-37.241903937564445,-39.70961669731979 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark11(-24.111199153495424,-1.1949919012237147,-46.31440375112935,0.0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark11(-24.13883215220764,-0.5784377588452423,-97.6779550490507,-37.51621670981715 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark11(-2.416703762790825,-0.04425746608100113,-100.0,25.865935384837883 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark11(-24.17009292646499,-1.2618966640454092,-1.558464758096351,1.0000033329005071 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark11(-24.2585702026366,-1.0786501932523491,-1.5707963267948966,-71.68161698765466 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark11(-24.311961643899533,-0.0619333551802157,-1.5707963267948966,14.8039743091812 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark11(-24.442564937585246,-0.12540978648045403,-66.51245471720816,-0.025787479844549988 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark11(-2.447861482271801,-1.5707963267948943,-68.27582299515913,0.9904786703904379 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark11(-24.541073591587157,-1.012354429483902,-1.333556887799988,23.18232437661216 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark11(-24.624863990850017,-0.6681644332900314,-34.3316564114562,-25.05609755573786 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark11(-24.64608980362122,-0.2117790333832561,14.439404363150096,2.1755330053059616 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark11(-2.473730092393153,-0.34664707850724485,-10.139577119966656,0.8306921707806927 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark11(-2.477260461353327,-1.570786761924844,-73.4145386041632,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark11(-24.829959511430168,-1.4096915959116885,0.0,-1.0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark11(-24.897331315955796,-0.44513005431768704,-79.16721652553802,-88.92503396317599 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark11(-24.93764525544108,-0.1496678326888663,-45.38663077361256,-1.0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark11(-25.001260740053592,-1.200735596350128,-10.631244077116513,-1.0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark11(-25.080006010295936,-1.4195998072654297,-100.0,-0.9999999999999671 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark11(-2.5098346178550814,-1.4332341366808334,-1.5707963267948983,-0.14259247174703754 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark11(-25.12718034208334,-0.17894252938546584,-93.46339900467562,1.0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark11(-25.229695517866706,-1.0790820156762448,-19.649261594180416,45.09320997992703 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark11(-25.23940075563093,-0.8170818614804416,1.5707963267948957,-0.03493850997219333 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark11(-25.26921003325736,-0.5510734388403793,-46.98246365639335,-1.0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark11(-2.529297857747828,-0.6336461874432843,-94.34054161940637,61.53536584363973 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark11(-25.304472973016097,-0.1352820192962898,-88.45273349287201,-0.6303523413411252 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark11(-25.327958965047205,-1.570796326794893,-1.5707963267948966,-0.4898811412515096 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark11(-25.333210938589954,-1.5707963267948912,-67.40196839669127,1.0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark11(-25.346515864528055,-0.34935510636622946,0.0,-0.01378050241745335 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark11(-25.37332899417476,-0.12455832380996609,-25.594228505710277,1.0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark11(-2.541819974969299,-0.9450296572293483,-77.5068480723798,-0.9628199181330614 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark11(-2.5422966137297918,-0.04571992379411549,0.09637307863252627,-1.6472184286297693E-83 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark11(-25.43741159291793,-0.252935264551553,-66.30513364019477,-0.9999999999999998 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark11(-2.549123056472297,-0.2842157851725766,-37.37187740498467,-2194.3872609170803 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark11(-25.50337922084813,-1.5707963267948912,-52.38706385302265,-77.0910599887367 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark11(-25.503387892686483,-0.4639884807742338,-163.37034443073145,50.131340011014274 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark11(-25.54774188430312,-0.6049760997894988,-7.258147006483553,-1.0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark11(-25.622221104627066,-0.10045009118256906,48.24950791106322,0.0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark11(-25.655886508916144,2.4308087928512054,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark11(-25.674153555149182,-1.2511012719614882,0.0,1.0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark11(-25.725662421171734,-1.371488478254257,-109.43395477740891,0.15932369399464053 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark11(-25.747928603463713,-1.203856636343174,-42.73784181525594,0.9706989722622907 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark11(-25.779888922499385,-1.4243770717144582,0.0,52.85384920068178 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark11(-25.794607463066853,-0.1723288175244616,-8.757230872055374,-1.0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark11(-25.876823276444235,-0.5626421036548592,-90.87819938142424,-1.0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark11(-26.00500433588211,-0.8548807092367952,-1.5707963267948966,70.65500688970684 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark11(-26.079628723205406,-0.4328233659082557,-79.96224986297084,1.3766909419461312E-16 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark11(-26.092936678807817,-0.43450479568237155,-8.998523384638318,-0.34850514217219875 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark11(-26.100126224822528,-1.5707963267948948,-13.193196384224933,1.0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark11(-26.15738453482453,-1.5707963267948963,-70.94037494638604,0.017200491603928437 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark11(-26.18749382677375,-3.0871923396049487E-18,-12.234983365265734,-1.0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark11(-26.226069848658618,-0.3043073702670784,-47.42829575678588,-6.497131103528062E-114 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark11(-26.30682231403251,-1.2907054288972213,-66.70079014834855,1.6134184957671578 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark11(-26.345127649135037,-1.7763568394002505E-15,0.0,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark11(-2.6408812036023077,-0.14768750457979002,-9.443071115362052,0.39511364273329197 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark11(-26.5244943527865,-0.11536181408673656,-17.356142287320317,1.0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark11(-26.552274694168265,-8.881784197001252E-16,-81.33299398356397,-44.68307835835612 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark11(-26.668187205902694,-1.5707963267948961,-1.5707963267948963,-80.18422835112493 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark11(-26.669694592763307,-0.4197319070740382,0.0,-0.6760095999992162 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark11(-26.681502969660265,-1.2812227075653277,-1.5707963267948966,-0.03608362644879742 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark11(-26.72750353627195,-1.4343140569455373,-9.574893395941523,0.4824690754958202 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark11(-26.751330979491087,-1.5499315699906242,-93.63440185634084,-1.0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark11(-26.76358613836294,-0.109291152296953,0.0,0.023301703256329853 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark11(-26.79811815420983,-0.48835555523381513,-100.0,-34.60266477865198 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark11(-26.898865112146808,-1.5707963267948912,-47.52634254771148,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark11(-27.02979004550881,-0.823965009384709,0.0,-8.190443999789405 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark11(-27.074175953503655,-0.8988094748084619,-34.680264625214505,1.0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark11(-27.079248260490115,-0.12936222896451882,-0.3172702561454982,0.019560681056983553 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark11(-27.104918451063334,-1.5707963267948948,-38.71190399607205,0.2989759750882688 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark11(-27.16883414733611,-0.4304740322332596,-75.59560152347558,1.0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark11(-27.16907064606311,-0.14739613729559775,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark11(-2.723182600510729,-0.016717101784536937,-22.90184746691682,-0.3529105639690403 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark11(-2.724794257281065,-1.5707963267948912,-60.25675208747619,39.81517607027541 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark11(-27.26477313322496,-0.052419357664461104,-8.773502669435201,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark11(-27.282846746322665,-1.016043539933591,-31.442641234155232,-1.0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark11(-27.314272558908428,-0.015531026542115071,-61.858066794377535,-25.09101378968684 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark11(-27.371059916419696,-0.06711487164250941,-82.18166443589014,1.0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark11(-27.542200415195207,-0.2374643923147754,-26.130133951266888,-0.9999999999999998 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark11(-27.587448663768626,-1.56784575982119,-8.532720733417804,32.31020755394291 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark11(-27.61702189466207,-0.03351772205560155,-78.53774940126613,62.231540571791726 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark11(-27.86274778600416,-0.0931707613849905,-1.5544236173856756,-0.8545257770639216 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark11(-27.87075317120394,-0.42663429457435775,-1.5707963267949054,1.0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark11(-27.888260499577324,-1.5707963267948912,-27.744601745176283,1.0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark11(-27.95859164178581,-1.5092348468378995,-70.41830537785182,-39.41556910577873 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark11(-28.019376464040427,-1.3282932850462335,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark11(-28.047960455856938,-0.22142103679201322,0.0,-0.9896770862721631 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark11(-28.096102385861485,-1.489799647023276,0.0,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark11(-2.8149583949853394,-0.1911023112804419,-79.33847759653965,1.0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark11(-28.269513759434524,-7.091066990668847E-15,-1.5707963267948948,-19.4351673662226 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark11(-28.285568785947966,-0.7473757549358705,-100.0,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark11(-28.32051476721658,-1.1173477945499728,-27.097897183430817,-42.37781408027266 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark11(-28.334853118319675,-3.552713678800501E-15,-60.11225765562781,-67.53110644858148 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark11(-28.368266420408332,-1.03471211120611,-20.420557260867938,-1.0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark11(-2.839692556708769,-1.5707963267948912,-5.819212095056841,4.269509493569217 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark11(-28.404956194877514,-1.5707963267948957,-95.94638274452151,46.647739294822145 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark11(-28.44339339067976,-7.105427357601002E-15,-100.0,13.632967342221683 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark11(-28.459442254834318,-1.2536164290507634,0.0,35.61020433296683 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark11(-28.516856717039865,-0.792677644913016,-1.7763568394002505E-15,31.658470480428186 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark11(-28.537865326241075,-0.6302880379922158,-13.567408150442123,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark11(-28.671881777255138,-1.3664126865891675,0.0,-34.27594613600695 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark11(-28.683267109006458,-0.0725153276396577,-21.81438150619826,1.0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark11(-2.8727297013187325,-1.5707963267948961,-0.7239660321509479,-1.0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark11(-28.782706378439123,-0.09723633972118927,-32.8057015234982,0.5133743862073705 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark11(-2.881410011771448,-1.103990914288392,-69.35185520592064,0.36210583831331444 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark11(-28.895288271906885,-0.008597806425277355,-11.04968560634805,1.0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark11(-28.913448909013674,-0.9802305935106661,-1.5707963267949054,-23.938299464236838 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark11(-28.91884845939137,-1.3756131751189002,-31.14590421431633,1.0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark11(-28.973352065996224,-0.24752581974216525,-1.5707963267945821,95.52938298884365 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark11(-29.087734387046194,-1.5707963267948912,-61.385222620472305,8.678273081516135 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark11(-2.909437766058476,-1.1326888732473788,-19.605138463650945,31.05625100568574 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark11(-29.117183686366914,-1.4556420753283066,-158.11148810435833,54.584374602067555 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark11(-29.247429773895604,-1.0410321693602247,-36.40909414356211,0.006923456655619248 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark11(-2.9271701199901403,-1.092199564848653,-10.757908928316894,91.73204637933313 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark11(-29.331669754790546,-1.55935764235365,-45.159154354930344,-0.020475349977553847 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark11(-29.334991785675864,-0.4028022926073969,-89.16393962080687,70.88779005575262 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark11(-29.408165241348044,-0.0278892889817155,-30.192123330537605,-1.0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark11(-29.435764398639222,-1.1566005012091347,-79.1033142322928,3.0983952336093134E-17 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark11(-29.521687257004004,-1.1366635532775742,-40.62055189441635,1.0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark11(-29.527339710073313,-1.2566707833105166,-0.9734002761321503,70.10951284314103 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark11(-29.527807838243177,-0.19952953791766342,0.0,-44.69288589014002 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark11(-29.60575153011639,-0.17794223814121557,-1.5707963267948966,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark11(-2.9615469880541325,-1.5707963267948841,-97.9461025620134,0.7436621370212468 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark11(-29.639597289268913,-0.19478002389713264,-4.5628886587136535,5.421010862427522E-20 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark11(-2.9677030293841162,-0.2438252292596279,-32.80360415599692,-0.0119991093648074 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark11(-29.70809297512781,-0.6973580847809906,-6.56326195423641,1.0000014148774614 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark11(-29.75956405155866,-1.5707963267948963,-63.18481884582406,-0.06255443720425657 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark11(-2.9799214827442846,-1.5674325817066728,-13.31717962959216,-0.8651053487024265 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark11(-2.989902301401738,-0.02861426780776411,-14.69769444828489,-1.0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark11(-29.908364463101144,-1.5707963267948912,-31.976125828939434,1.0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark11(-29.90844609334642,-1.5707963267948963,-4.581032402545858,-1.0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark11(-29.912704212292823,-0.1423160487877515,-73.39077945508254,-1.0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark11(-2.9963854685105265,-1.5707963267948948,-53.79508149019829,0.6082873282537093 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark11(-30.197453920755905,-0.9543844578330658,-32.87162371514067,42.580419793192334 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark11(-3.020371088638612,-1.324522238933729,-77.03078736076316,35.04863541684071 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark11(-30.237648552260392,-1.399889132245468,-51.1484294717281,-0.9691827071508214 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark11(-30.254939798823884,-0.5729448197985434,-11.48476151422203,1.0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark11(-30.30641973804156,-0.10037184026114537,-2.4381748540184276,1.0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark11(-30.364665193435528,-1.5508452167287923,-33.48584235178147,1.0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark11(-30.413243948830463,-1.3830578789705519,-1.5707963267948966,-0.2794338839934174 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark11(-30.452593732496823,-2.186241664270144E-16,-14.207171115314353,-0.024416247979373806 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark11(-30.463441934771947,-0.7492593075651099,-91.82595155945957,49.478347239348594 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark11(-3.065180974647552,-0.04839166940707207,-1.5707963267948926,0.9999999999999998 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark11(-30.711322124608362,-1.0802142005530513,-37.88013783056624,-81.42086194922187 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark11(-30.717850427668132,14.429280419180067,-1.5707963267948966,0.8779493529296727 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark11(-30.80612907861926,-1.5707963267948957,-74.67965339940332,1.0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark11(-30.844625877371286,-0.4258635964548596,-30.904553101010297,-1.0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark11(-30.868003576313388,-0.6149671285576797,-97.14553958598816,-66.70531703612454 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark11(-31.01798588037834,-0.3581707847269362,-9.255910508459209,-1.0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark11(-31.023984045413314,65.95920351327575,37.38156856134373,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark11(-31.026995068436136,-0.4228997732233629,100.0,0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark11(-31.06095988843855,-0.009121813850596761,-0.8700263101796443,-1.0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark11(-31.069216713009293,-1.7481762484008659E-16,-68.46675061442338,-1.0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark11(-31.12990850904407,-0.348230534585612,-0.5000720001915228,0.0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark11(-3.1158480567166293,-0.21271638274672355,-66.67523519044077,32.90103018482378 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark11(-31.205175654146167,-1.1674456534334072,-44.420457472863845,-0.9301037766827975 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark11(-31.233312062307988,-0.005364331952865092,-100.0,9.273015376718553E-69 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark11(-31.314645887700806,-1.2125337435583647,-1.5707963267948966,-64.21806017536977 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark11(-31.32457293703549,-1.7992529215848348E-16,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark11(-3.142737314424874,-0.8913732246467841,0.0,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark11(-31.438465820696962,-1.128445419489238,-100.0,100.0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark11(-31.506242490341773,-0.947548448602999,-31.930089922014005,-0.9771136748561766 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark11(-31.57686841481133,-1.5707963267948841,-35.48773978721516,38.60274355682932 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark11(-31.580200527580516,-0.12469833174517478,-26.209229308817232,-0.024508360221781326 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark11(-31.74809509291947,-0.7172378883451342,-0.7248383690843592,-86.06517420859205 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark11(-31.793555351156968,-1.547866352922311,-45.51985773388009,0.38844183762374307 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark11(-31.855854025562355,-1.0978303670696534,-1.5707963267948966,-57.50280042610497 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark11(-31.963113843974487,-0.2522709227175057,-27.16501493049565,65.73112685243721 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark11(-31.965907779088656,-0.031539264704467246,-38.74037100484135,-0.05764274299933174 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark11(-3.198585374310155,-1.5707963267948912,-94.01228318734873,-0.9999999999999999 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark11(-32.00042968906965,-1.5252907681565397,0.0,-52.36930825240194 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark11(-32.014392208642036,-0.31009040160602597,-73.3359385854378,-92.50232471451075 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark11(-3.203881007836112,-1.1812316361470705,1.438601894930736,-33.76666566149568 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark11(-32.06234605816701,-1.5707963267948948,-42.54984509421285,32.52356282041861 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark11(-3.2088000563709613,-1.3683836911792286,3.4887398273924274E-16,-25.387496836707783 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark11(-32.18810983979163,-0.35657376993627565,-72.73255229514535,-2182.723360389168 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark11(-32.333672009575224,-0.20207390944092918,-0.31424139481767294,-0.9002066035769523 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark11(-32.41480051997862,-0.024645376537594833,-40.12733272400864,-0.027182339348387832 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark11(32.437237644154976,-97.2664095060803,55.30687942789709,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark11(-32.519247830480595,-0.5853802387369313,0.8456733458630286,-2334.1104933096913 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark11(-32.53344806078219,-1.177960570742994,0.0,62.32180412714091 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark11(-32.578175195407425,-2.220446049250313E-16,-68.99447805750201,0.002559265139923106 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark11(-32.58698445757559,-1.1895825461581548,-58.27850037043328,-0.9495853649614286 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark11(-32.62533317694552,-0.6196723455660668,-39.42854733583769,-1.0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark11(-32.659940825896456,-0.7111960791387837,-27.291398497958113,-49.62162987951333 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark11(-32.72754462581383,-0.7732078981658533,0.06239264481001957,-0.9850748030196533 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark11(-3.274449031412189,-36.07548779649121,0,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark11(-32.799375279871214,-1.5572189843052715,-0.22404586793712689,1.0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark11(-32.90003351678722,-1.5707960464849355,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark11(-32.94897761990266,-4.440892098500626E-16,1.5707963267948972,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark11(-32.95427308955109,-1.552613638240346,-16.924791384529314,-0.7727765322760325 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark11(-33.10599835885002,-1.5707963267948963,-4.216552864306947,-47.91549058242162 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark11(-3.3212873466091635,-0.8214725522855675,0.0,1.0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark11(-33.21301472587559,-1.5707963267948948,-1.5707963267948966,0.993878002529172 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark11(-33.22934271279713,-0.2096693758041094,-42.26572294129619,-1.0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark11(-33.24924349008664,-1.2216233856075118,-0.8512978927348847,0.014248338125559229 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark11(-33.255245072120886,-0.5409513496045167,14.901216776347837,-13.93525947801659 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark11(-3.3326755384745708,-0.8095046992701292,-99.87660011270194,36.32378370082134 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark11(-33.346797123119494,-3.552713678800501E-15,-1.5707963267949019,11.330766150165502 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark11(-33.450144489069885,0,0,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark11(-33.45339728319952,-0.5735182743270836,-90.80499589250101,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark11(-33.548528920925484,-1.1727132284248258,-42.31818084292918,-0.8011968122844266 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark11(-33.602978791241426,-1.203883712608391,-100.0,0.0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark11(-33.78960078832333,-0.4176190104734874,1.3091661388008404,40.39064505744747 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark11(-33.93309051797436,-0.2931018601033739,-18.840674068036215,-1.0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark11(-34.03426524838153,-1.0864980444734562,-37.74248652529937,1.0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark11(-34.06208748080734,-0.2531309001553312,-21.221816093606876,-1.0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark11(-34.068090996191856,-1.412908237731501,-89.6476017974017,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark11(-34.087732300516734,-0.5179763636224295,-1.5707963267948966,-0.006808868235356376 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark11(-34.1015258890416,-1.5668697638268194,-0.7460478270201624,0.0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark11(-34.11291700744072,-0.026596415095242798,-1.5707963267949019,1.0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark11(-34.14292755983005,-2.6628848720364984E-15,-26.75458000474989,3.592142924552667E-17 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark11(-34.2034164171005,-0.2119642583681984,-26.883027599403494,0.059831436601791466 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark11(-34.22583811109699,-1.5707963267948912,-1.5707963267948966,0.9999999999999998 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark11(-3.4270031813339736,-0.27727008612732573,-24.40271136174336,-0.4741633413012384 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark11(-34.45844640376579,-1.5707963267948912,-18.678743602517585,-86.54703702540125 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark11(-34.47218227851408,-0.748252979289612,-0.5187524128896173,27.898572095610298 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark11(-34.527811104987094,-1.2927242162587802,-1.5707963267948966,1.000003201905004 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark11(-3.4530870856367044,-1.5669432731625954,-1.4446908407131471,-0.021330817775679356 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark11(-34.543871987012906,-0.3932002100367191,-19.40184541067147,66.09965218058376 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark11(-34.59337037994301,-1.082791968951497,-100.0,22.61430862745167 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark11(-34.67293320511932,-1.5707963267948963,-27.252237459104123,1.2553351208423784 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark11(-34.67460466362253,-1.1637691283780107,-44.32472444005334,-1.0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark11(-34.686129249488005,-0.3886168064272647,-36.224701032538285,-69.36230262823962 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark11(-34.792944801320424,-0.043642807852942715,-89.81171070083818,5.293955920339377E-23 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark11(-34.90932073601019,-0.4429804714831042,3.1126223070859615,11.378525615488611 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark11(-34.91618188456665,-1.5707963267948961,-1.5707963267948963,0.34951723092127196 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark11(-34.93526657867358,-0.020384692191637365,14.429766120109193,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark11(-34.984371751609736,-0.5213590356142692,-72.71331228821899,17.898042612219193 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark11(-35.03125204546713,-8.391186286270274E-15,-98.82944602525168,-1.0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark11(-35.04793042473847,-0.6564236109477988,-89.72138000953298,-0.27122090190004045 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark11(-35.19583221960973,-1.5707963267948948,-25.97663499577682,-1.0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark11(-35.228050821319684,-0.6316310892849764,-37.95629304171337,1.0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark11(-35.2392282960544,-0.8220842183165784,-1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark11(-3.5338419620406345,-0.49853043720393697,-2.3008535786692477,0.06255267989512302 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark11(-35.403512371607015,-0.0879778845944697,-1.5707963267948966,0.9333944330725049 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark11(-35.44370512994579,-0.5031563025689539,-73.62449260665917,-0.3137627578240343 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark11(-35.48768557627896,-0.146340026891271,-21.67663587452678,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark11(-35.50154737364864,-1.5707963267948948,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark11(-3.555170796102999,-1.2474075623699399,-82.66431645576861,36.19983556868331 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark11(-35.55517678013809,-1.2815118388858024,-3.21759985108838,-0.9999999999999973 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark11(-35.588724913563745,-0.5847102531545196,-41.88089283925394,25.20378109356084 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark11(-3.565009815571522,-0.4497174197886189,-14.814936898951082,92.46690316299438 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark11(-35.6916502413127,-0.43890998326136976,-1.5707963267948983,-0.4573715670682803 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark11(-35.72605540686704,-1.964013633210209E-5,-70.89748158494596,0.016946688647196895 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark11(-35.78114745848812,-1.4536188852125145,0.16792664628265308,0.0012753039691135448 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark11(-35.94702461465725,-0.8258167306805557,-157.49198951812406,0.10791020927565675 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark11(-35.97299342977273,-0.945010919160712,-61.35202132336269,0.9999999999999978 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark11(-36.00110596864975,-0.9345231046214515,-56.10501199320124,69.77694366362292 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark11(-36.01539106726966,-0.7346589009054538,-42.26228575916592,-30.471394126611614 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark11(-36.14134468892425,-1.5707963267948943,-8.933731354473801,-1.61677232145973E-6 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark11(-36.17536837247006,-1.4030603002012054,-0.1129023691336137,-0.8564795162421064 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark11(-36.403068059865696,-1.5707963267948912,-27.244867799097335,4.867863935487549 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark11(-36.42464307462359,-0.9641381031889877,-1.5707963267948966,-0.6409656223294036 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark11(-36.51067077421483,-0.3988519339454131,-50.15157434641406,-0.9999999999999982 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark11(-36.52685906795291,-1.570773730351132,-38.86438373130744,1.0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark11(-36.52972939970023,-1.4295789641602452,-95.3547797811611,-96.9491190224572 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark11(-36.548902387068935,-1.5707963267948912,-67.41751064284135,-0.499857032102621 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark11(-36.62012470483616,-0.8309950473184143,-78.58459983497947,1.0000000000000036 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark11(-3.667431028714601,-1.3305364659849657,-1.2053438552100169E-13,0.004201250639920107 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark11(-36.77764709038316,-0.1420407036037608,-1.5707963267948966,2083.441036573845 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark11(-36.835075112913266,-0.3578851056219852,-79.75313291235686,0.6551159420542194 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark11(-36.907475677490496,-0.8979368167656792,-7.003401028846511,1.0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark11(-36.924112355389354,-1.5705231871203287,-0.332057632799002,64.34668646599431 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark11(-36.94477119041867,-0.537132977640012,0.0,-89.2514611425738 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark11(-36.95925540208454,-1.570796326794895,-50.146834973993506,-5.59072453130014E-17 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark11(-37.04295428686554,-0.2562564476789982,-0.3337607809124953,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark11(-37.06374389618519,-1.1102230246251565E-16,-1.5707963267948966,-86.90634356862193 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark11(-37.080552631677435,-1.5707963267948912,-45.196786687026076,53.304597238603094 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark11(-37.16207496037528,-1.0195511741928662,-31.482579784419116,1.0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark11(-37.189805700717315,-1.3861785413372059,-59.116991776620424,-0.7774396208082806 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark11(-37.27128532481819,-0.22674556223771358,14.838483863613817,-2.1895288505075267E-47 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark11(-37.308078959162465,-0.1677611904564581,0.0,-0.8859062710631318 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark11(-37.32034647103663,-0.7883613125199099,-4.724273768005464,-0.8019554756005747 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark11(-37.33721647462734,-0.45980653121522663,-65.98392663812204,1.0000000000000004 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark11(-37.47471642509159,-0.6261878948679231,-88.8121648034287,-70.17690992698203 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark11(-37.47638344703558,-0.6688192550539542,0.0,-1.0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark11(-37.57302952368271,-1.5707963267948912,-24.5478348016687,-1.0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark11(-37.586107876689184,-1.1278976090800883,-4.564089797236676,-0.03744840977822898 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark11(-37.59055765841882,-0.9322000359054163,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark11(-37.74371181224113,-1.5707963267948957,0.0,-1.0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark11(-37.74426136965831,-0.5803602982409907,-1.5707963267948966,7.936732057917996E-17 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark11(-37.78618666818339,-0.592456502748389,-57.89694967513654,-51.057231472835426 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark11(-37.90523455993315,-0.5233998739701671,-1.7515659932676328,0.0285961472030112 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark11(-37.918069530548166,-0.20325279724083242,-59.68961811687435,-0.985185364537234 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark11(-38.02755825307079,-1.5707963267948912,-27.58089827926383,-48.277257100326615 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark11(-3.805498417751309,-1.2077219964687969,-0.9264239237509493,-0.37292107794963547 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark11(-38.11233104421966,-0.33030346141681655,-39.1049788025671,-0.10069386026783034 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark11(-38.135516395568914,-1.5707963267948948,-37.792223986031104,-0.33188683909110883 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark11(-38.231999113716434,-0.7881283539283479,-32.8830180064892,38.83331666801571 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark11(-38.280311577728064,-0.8801148442888954,-58.39212201548685,32.12982436719065 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark11(-38.2863807483855,-0.19564259168315346,-1.5707963267948966,0.9999999999999964 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark11(-38.30648288151171,-7.105427357601002E-15,-1.5707963267948966,0.99999999999895 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark11(-38.34232938476415,-1.1161096317368386,-2.116118971544907,-1.0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark11(-38.419189692604355,-0.9448576048554276,-40.691730522216034,-1.0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark11(-3.84285099270384,-1.4894314091080814,-23.90166704019823,1.0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark11(-38.42881790986591,-3.6139460187578685E-15,-74.39488825055668,0.9875823228677412 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark11(-38.46409370869628,-2609.08328572096,0,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark11(-38.537486253704344,-0.28191946387695793,-58.48975477828796,-0.06257929952277431 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark11(-3.855066359757287,-0.3288593684606164,0.0,-8.271806125530277E-25 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark11(-38.57656952828623,-0.07704649086505,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark11(-38.61566843911081,-1.5456700439774973,-1.339611883774021,5.551115123125783E-17 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark11(-38.675283787605906,-1.5707963267948948,-67.85856184709652,1.0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark11(-38.68948924142558,-0.04874132843043366,-80.48583470114284,-1.0072389682036416 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark11(-38.731612896601696,-1.5707963267948957,-84.42671729709943,85.93556874000643 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark11(-38.797157026820756,-4.440892098500626E-16,-41.18358625457197,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark11(-38.80934677189695,-1.5526475672618985,-0.7850512385771858,-59.859606556940136 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark11(-38.87971418444067,-1.5707963267948957,-1.3454246174360174,1.0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark11(-38.958385258225704,-0.19592231745604138,0.0,-1.0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark11(-38.990989900012764,-0.006645417274338265,-14.069873129203916,-0.9931352888940048 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark11(-38.99206191160863,-0.4219193094943412,0.0,-0.769907918844125 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark11(-39.03416097407729,-1.3192246361115907,0.0,3.552713678800501E-15 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark11(-39.04137382964822,-1.1949128046316086,-1.5707963267948966,-27.670960675675143 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark11(-39.130619656973956,-1.5586398344126309,-73.5082990348572,0.05711959816053419 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark11(-39.1339432550698,-9.798016230829893E-4,-1.5707963267948966,0.9999999999999996 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark11(-39.144371578933416,-0.9150070170801988,-31.83422984763394,1.0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark11(-39.182169883709605,-0.11511286817130574,-99.95313185434303,-1.0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark11(39.18643773806795,0,0,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark11(-39.23120626928498,-5.551115123125783E-17,-73.90021871757247,-1.0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark11(-39.28784311348926,-0.7816861030878758,-0.3169300044862673,-90.7002710081908 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark11(-39.3781472177598,-1.5707963267948912,-1.5707963267948966,1.232595164407831E-32 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark11(-39.794373150252696,-1.5707963267948963,-34.82329255474871,1.0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark11(-39.801461641049364,-2.9125675052414692,0,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark11(-3.986134657327163,-1.5707963267948948,-7.034604408293305,-0.9999999999999964 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark11(-39.87282725361176,-0.05589092701104527,0.0,-1.0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark11(-40.09339142205863,-0.20716133341030296,-45.08854496895153,47.53821490546296 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark11(-40.10981848464523,-1.466590878835774,-44.140746584281544,-0.43754708957800625 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark11(-40.11865837042373,-1.5707963267948912,-51.2458147855639,-0.039669789156330904 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark11(-40.16379938412117,-1.556464976432499,-1.5707963267948966,-0.05300804263002407 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark11(-40.20111702275574,-0.6047844026798589,-84.59789263370448,1.0000001436732162 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark11(-40.20600660961766,-0.20329161568435383,-15.124634072408425,53.045916756936066 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark11(-4.026589415679455,-0.5300117105597435,-18.804864117052965,0.9999999999999996 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark11(-40.29843700166527,-1.2344512642037357,-0.5362714102222249,2.2028102883875684 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark11(-40.35329193944151,-1.5707963267948912,-80.6027086401267,-0.003909326614660702 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark11(-40.40757597471929,-0.2460958349969422,-74.99664564434102,91.25140217940967 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark11(-4.041540785502707,-1.5707963267948875,0.0,-0.7664730760488936 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark11(-40.44229991752855,-1.5668651949716548,-44.59531912257682,-0.770384304297366 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark11(-40.54259493238351,-0.08850628371851976,-76.60061722703685,6.900894741287411E-4 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark11(-40.596008926503416,-0.904732596092457,-1.5707963267948968,-1.0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark11(-40.739663900337625,-1.5707963267948957,-53.944892615816194,0.9298189128465809 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark11(-40.76675564623273,-0.12108041077197032,-23.06193095119466,-1.0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark11(-40.82802402255501,-1.4407710214631053,-53.96203487401992,0.06262765372997486 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark11(-40.841570647558434,-1.4168350004506722,0.0,0.8497364359218311 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark11(-40.849469795254365,-0.1501252116589219,0.0,-0.9999999999999999 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark11(-40.93143085424323,-1.5707963267948948,-1.5707963267948966,-1.3766192270804065 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark11(-40.96578837671971,-0.21110936013776427,-67.46391818198225,-23.867593576394434 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark11(-40.96932932882886,-1.0980730947476611,1.5707963267948841,0.0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark11(-41.10380206875892,-1.4397082867550726,0.0,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark11(-4.111523737238343,-0.707170769249993,-9.8419811525432,-69.81065008515274 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark11(-41.22356504099092,-0.13827869761729938,0.0,32.516730066010815 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark11(-4.127151707091187,-1.3395756904189027,0.0,0.8192113045248135 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark11(-41.29162368886402,-1.130859921640699,-57.473366128821624,1.0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark11(-41.30308951401012,-7.105427357601002E-15,-9.629299264656673,0.36673724387224915 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark11(-41.3244674477144,-1.570792330854759,-5.891494988861993,-0.6439491141580288 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark11(-4.133163641024277,-0.7808423926252173,-67.34309173693548,0.0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark11(-41.341217307219594,-0.22524725271629853,-1.4733959046351388,-0.9313711227303046 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark11(-41.442452520740154,-0.005502518925169547,-22.762029624340123,-0.721441457882328 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark11(-41.54123335732817,-0.8210635096875546,-34.112461217689535,59.05958047230624 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark11(-41.82757529837242,-0.39559820702128995,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark11(-41.964682826886566,-0.9940688942903666,-0.039495807902160784,0.049313920059596034 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark11(-41.980640930250985,-0.8196002835615559,-90.26355754417185,1.0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark11(-42.005558289141845,-0.07441462102535557,-1.5707963267948966,-68.7094992779663 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark11(-42.04916502139206,-0.49791861625130096,-32.459969898744134,-11.799797225606905 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark11(-42.0724567658187,-1.5142630088215883,-44.30780538983261,-1.1966066273419947E-7 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark11(-42.08486550096334,-1.1306199823821257,-39.780738458841,0.41933139579056733 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark11(-42.16341877232456,-0.3999529470624419,-15.522279354549923,1.0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark11(-42.265423673661275,-0.005569980718834696,-43.69815286896423,-0.9792384412504691 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark11(-42.28778592606818,-0.3709105148084666,-1.5707963267948966,-0.01579029566032085 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark11(-42.332889713788965,-1.1219508594266787,-79.37151950198941,-1.0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark11(-42.42990173953559,-3.552713678800501E-15,-100.0,51.13574450446247 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark11(-42.45645435504989,-1.3335591739931287,-0.8645954611685692,-1.0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark11(-4.2504900687478395,-0.12931997308473792,-1.3597827718525546,-0.02085724207812939 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark11(-42.50898901729188,-1.1209555389943238,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark11(-42.64166152171432,-0.2874377832404509,-16.20056529302983,-2.1175823681357508E-22 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark11(-42.77459341923341,-0.6905482745253735,-58.9356390270904,-1.0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark11(-42.80601212648894,-1.28172451145009,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark11(-42.8418349972866,-1.438218071107966,-0.8540555548574225,-0.9054026358600107 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark11(-42.8830898181002,-1.5447381186283369,-40.1022870257837,0.046286029688920316 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark11(-4.293920647570573,0,0,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark11(-42.944228577940294,-0.9144741205978102,-1.5707963267948966,-13.161684146610174 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark11(-42.953349238474594,-0.841046885501534,-66.23730927680609,51.2781060488779 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark11(-42.95532593731439,-4.440892098500626E-16,-1.5707963267948983,0.5820351516431013 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark11(-43.01220390305663,-0.20290917773071104,-60.455823990095894,1.0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark11(-43.01328883611732,-0.8652417241928703,-81.92622378908885,0.30773486634004577 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark11(-43.017988715553095,-0.14724746576862607,-2.0468032529323033,-0.11144869485558456 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark11(-43.02921529703824,-0.916964618962373,0.0,17.219794445815893 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark11(-43.030964554548405,-0.5376390478132043,0.0,-0.2492253106906137 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark11(-43.07687251872321,-1.5667419269810026,-1.1102230246251565E-16,0.010113727870856657 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark11(-43.091895919901305,-0.3495132733300874,-100.0,56.40238094290987 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark11(-43.11969002054455,-1.1617020786318242,-1.34298206107073,12.906960577699833 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark11(-43.171126217419385,-2.220446049250313E-16,-72.03073982158332,-24.989551778415603 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark11(-43.192294010349116,-0.03339452475754001,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark11(-43.22741752385809,-1.0337265454124884,-1.5613572491196506,1.0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark11(-4.3362700927945514,-0.6322888163246461,-35.07987175841346,-37.20449701943705 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark11(-43.38740688836297,-0.5861231415347328,-11.948243354534213,15.77088558796629 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark11(-43.41074961830023,-0.6301154495245728,-62.50773264990126,-1.0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark11(-43.4767085744018,-0.5947136160351021,-45.38471690623005,-95.3860507707148 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark11(-43.51086996513132,-1.1134994769466866,-1.5707963267949054,-11.625414201776533 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark11(-4.362952930536979,-0.31328795346082333,-0.16572523427324742,0.7454619007097599 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark11(-4.366201500699301,-0.09662182745596581,-0.007565394346816165,-0.5687258106173889 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark11(-43.665984749143206,-0.6302188749420633,-1.256381435210337,-2.6101217871994098E-54 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark11(-43.69899560348174,-0.1120949783631584,-11.795272200249887,-1.0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark11(-43.83946720742033,-0.15891851822062808,-32.758956503764495,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark11(-43.84739887969968,-0.5308028523224215,-95.19253151464628,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark11(-43.84999307058593,-1.5707963267948963,-1.5392957654366808,1.0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark11(-43.85020552824668,-1.5707963267948961,-70.40940081818795,0.0890323199365548 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark11(-43.91095000782268,-1.4654152984547861,0.04624993557718377,0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark11(-43.94114316189257,-1.303368977491364,-1.5707963267948966,53.342294917004004 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark11(-43.99041855334847,-0.11301764590837715,-0.21664983115376127,-2070.0612501898527 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark11(-44.08211286715297,-1.570796326794893,-1.2121050173345214,-0.7109306452511315 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark11(-44.1532837466892,-1.417474969619688,0.0,48.92949068219605 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark11(-44.17746440566794,-0.653163348318925,-73.74568276705764,2052.8767222902757 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark11(-4.420754727612538,-0.025388678797952393,-48.72925039035776,0.9898815591858392 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark11(-44.20970279365348,-0.11084588215946208,49.630536028171946,0.0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark11(-44.23432370382534,-0.035165032911836855,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark11(-44.247519250882405,-0.41076460420890365,-10.595767585146959,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark11(-4.428922496560332,-1.329276185998913,-38.17997816477076,26.059848918848584 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark11(-4.432099639527917,-1.4078785218982142,-45.79595509912078,0.0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark11(-44.44822895534587,-0.017574131829743062,-72.70771494393632,-0.94173797750542 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark11(-44.48511356843857,-1.0545917736613095,-68.13710960405862,1.0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark11(-44.5338376913969,-0.599567793862749,-14.317796938760779,0.6801382306756244 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark11(-44.57320175496292,-0.6041315081356474,-14.326907544380326,-0.8942165659505399 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark11(-44.64628318601358,-0.8263819990085949,-100.0,-2265.4332840753655 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark11(-44.6656400429304,-0.761885859290145,-88.7697094756908,0.6208981523690768 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark11(-4.467805370414894,-0.5537052037230312,-108.98482195217701,0.480198107200702 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark11(-44.688215256637186,-1.3049019093726812,-73.09832725781739,1.0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark11(-44.731637557833594,-0.05732174880658114,-22.166235473773128,-0.9461762976165335 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark11(-44.98489122647193,-1.4571779462011094,-1.5707963267948966,-0.9504171840318267 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark11(-4.498946168494758,-0.0011453052785586754,-1.2535541129533854,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark11(-45.06223582007603,-1.5707963267948948,-24.793158943924524,2249.9958930166304 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark11(-45.14374932775893,-0.2897064181462916,0.0,1.0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark11(-45.14776628151905,-1.1628067758800285,-0.1856299641483362,-93.41409135620593 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark11(-45.18727992411085,-1.2418632686053703,-1.5707963267948557,-1.0060604157817994 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark11(-45.30628770691399,-1.5707963267948912,-134.5154460565351,-55.82077987527334 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark11(-45.31571100906253,-1.4465622504713278,-53.66908390222514,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark11(-45.322107273945385,-0.5851929641748328,-137.210786615582,0.008381362755443045 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark11(-45.4869205195753,-0.5396522011472452,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark11(-45.596967823310685,-0.21427716065257002,-12.298315963107683,-0.47459843852152256 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark11(-45.60216443091915,-1.5707963267948948,-90.54436930644732,-1.0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark11(-45.60677375750172,-1.5463359859451105,-0.9058831334330826,1.0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark11(-45.670621020148545,-1.1591882468068664,-50.1209076547116,54.75996512776248 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark11(-45.68017247621347,-0.2100890993047129,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark11(-45.693968830411414,-1.395323958005479,-37.89713523845964,1.0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark11(-45.783263436662985,-0.5709981513556692,-85.53920920465684,-0.7140040649842188 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark11(-45.91561344399093,-1.133970951301657,-12.407115535674974,1.0000325035411173 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark11(-45.931733043021204,-0.15890552602068056,-58.4479644294274,-1.0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark11(-46.002909285225776,-0.34354004481611095,-14.455417450076482,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark11(-46.008027719417406,-0.12461299093759637,-67.39710127549742,-1.0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark11(-46.011585564628454,-0.6948409608822188,0.0,0.694806358705975 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark11(-46.021998465486746,-0.6373649583755437,-157.47686992810353,-0.8361682028196276 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark11(-4.619490832836959,-1.5707963267948912,-1.57079632679511,-1.0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark11(-4.622683536669308,-0.6623315201738365,-87.05169865461448,-1.0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark11(-4.635476765931259,-47.86121785446282,-15.06777863760378,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark11(-46.413497342265686,-1.560732361336841,-1.4260579414044243,-46.88286484916154 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark11(-46.42071807101652,-1.2857363983144565,2.6559646203388665,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark11(-46.47746628190479,-1.144361310207458,-49.67110716158598,-1.0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark11(-46.53109535586579,-2.220446049250313E-16,-45.08342784732678,89.16669477635224 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark11(-46.66313041796226,-1.55797884504264,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark11(-4.675179531536571,-1.0955731444403298,0.0,-57.957008687267454 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark11(-46.753427796070014,-1.087201007187275,-2.98735761463473,118.66613732584733 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark11(-46.76423679954607,-0.15139029082050165,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark11(-46.909324887564665,-1.5707963267948954,-4.521658952788304,-1.0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark11(-46.952411115493064,-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark11(-46.96033001078061,-0.8610672110423201,-1.2801011948137315,34.1379490379625 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark11(-47.060611097755384,-0.06436084983777701,0.7614762375354047,-0.9974136975338044 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark11(-47.103875044035426,-0.21466359075824967,-89.1632048858091,0.09920173227871762 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark11(-47.34311415821402,-1.5707963267948948,-41.902784011886496,-0.7749968750164146 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark11(-47.501254811508254,-1.5707963267948912,-45.50396920861481,55.499073336151895 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark11(-47.53438833265776,-0.34816653736325254,-7.105427357601002E-15,-1.0000000000000018 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark11(-47.633653384961306,-0.20299130804911658,1.0561559925279402,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark11(-47.73000341644765,-1.4063349580465898,-20.498046502728062,-1.0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark11(-4.779925540051025,-1.543897999156204,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark11(-47.80017206969263,-0.015505065219939773,-37.293613983544816,70.63039990642756 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark11(-47.80684106429187,-1.5707963267948912,-48.79978655291159,-90.91499970195053 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark11(-47.814622818675794,-0.032501453278706884,-33.36794100016809,0.0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark11(-47.858588605321614,-0.11141845012765084,15.017410568192844,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark11(-47.86474788627902,-0.21028988650806557,-3.4760838480002576,1.0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark11(-47.89586870338705,-0.6179682704726939,-88.19250035830731,0.10258115085174246 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark11(-47.981995909456074,-1.3399288197184247,-37.8558987032838,-127.72186558508517 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark11(-48.071126458333126,-0.17570263942283826,-73.80388891178941,18.61188326340013 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark11(-48.12179489184235,-1.0837307623852585E-14,-1.6879757086920808,-1.3177747429038154E-82 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark11(-48.12529943466129,-0.10061771425132675,-18.393881002300624,1.0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark11(-48.15288394862802,-0.8997653973781254,-5.51490173028931,-1.0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark11(-48.252197935483515,-0.7158641145577285,-77.8151196817534,18.924763439727613 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark11(-48.31748906212876,-0.7767874693623169,-43.790918094911135,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark11(-48.323469857947785,-0.8666365613282991,-1.5707963267948966,0.8303090012912581 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark11(-4.83342474689249,-1.5707963267948912,-84.36665985799068,0.9999999999999929 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark11(-48.41431765782077,-1.3061897333796324,-1.5707963267948912,0.0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark11(-48.431326266296274,-0.3117061180124707,-23.50580164930915,1.0000000000000033 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark11(-48.44854985415402,-5.551115123125783E-17,-56.15668698553696,0.9999999999999929 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark11(-48.45409840061285,-0.01237377682145722,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark11(-48.53138260388778,-0.02522923257750625,-1.3877787807814457E-17,-1.0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark11(-48.6101172923035,-1.5707963267948963,-67.49333687072192,0.9999999999999997 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark11(-48.67688415374613,-0.34296538913165975,-1.649311530334657,-1.0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark11(-48.75035520505806,-0.44294384659654007,-68.04974667208667,1.0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark11(-48.81154819183163,-1.5707963267948912,-50.447430678167684,72.9093022276768 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark11(-4.888424535272787,-0.6663865788681136,-73.62873350280849,-47.18915494380968 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark11(-48.89316281813959,6.453580994113918,-1.5707963267948912,100.0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark11(-48.9183112253752,-0.9480990557319442,-45.72662033983751,0.0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark11(-48.957729017539165,-0.5457397814347429,-58.69766714929805,1.0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark11(-49.04243067846956,-0.6004375632050661,-4.633319650472731,-100.0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark11(-49.1427036050829,-1.5707963267948912,-58.935954510542985,-0.36217914642616317 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark11(-49.159603520296955,-1.5707963267945395,-95.51783432871623,-2005.2792197901447 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark11(-49.16065904373994,-0.0370838644645346,-45.38927375025273,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark11(-49.198461228803474,-0.23111584937400625,0.0,-0.9656118180497386 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark11(-49.264545514771434,-1.5707963267948948,-43.83165052443061,-62.04805948965551 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark11(-49.30763418340711,-0.0036459468012438614,-51.34928959717793,1.0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark11(-49.31619145718644,-1.9715980078863476E-4,-8.328340119167521,0.8485672148023651 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark11(-4.932488094352138,-0.9216402437358151,-53.16650994137926,-0.4938610003150081 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark11(-49.45515201622503,-0.17858551103820175,0.0,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark11(-49.49400489892804,-1.5671583234097481,-1.5707963267948966,-1.0010415694227501 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark11(-49.758038326788615,-0.3242265404200086,0.0,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark11(-49.82235020273687,-1.3674670960795186,-48.48069508300432,-0.044810237419481896 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark11(-49.87221796290046,-1.5707963267947407,-6.670785188348145E-16,0.062552914051056 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark11(-49.92627823355282,-0.5111944313411128,-89.37290463635912,-67.61941528248298 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark11(-50.002657702220446,-0.107313458672331,-99.2777286474576,7.571555180847852 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark11(-50.11399509473837,-1.7763568394002505E-15,-82.07252768020004,-0.46270976057303237 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark11(-50.12849494875944,-0.015078111361582344,0.0,-0.030532617320267227 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark11(-5.012972469644024,-0.6919226268881147,-24.642151846001976,0.9999999999999964 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark11(-50.13821822139492,-2691.869092424642,0,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark11(-5.014191659970412,-1.377404586654885,-3.776166708421008,0.204633247814332 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark11(-50.18901480079404,-1.4657907122455183,-34.65223001736906,-1.000000151811283 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark11(-5.026391368304972,-4.440892098500626E-16,-20.374834573487433,0.633396507035088 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark11(-50.36373382002691,-5.551115123125783E-17,14.432093645520197,81.68480450168983 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark11(-50.42918926396462,-0.24797336347289747,0.0,-0.1291624071401067 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark11(-50.58545213806911,-0.13586020739844026,-53.665009183065166,-22.07312922254809 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark11(-50.596966116232686,-4.440892098500626E-16,-68.06416393987308,1.0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark11(-50.69397453118194,-1.0114668940206049,-31.686298915712104,1.0000175609735995 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark11(-50.70918369012646,-0.3092123133243634,-2.1437720621204583,55.80544241173608 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark11(-50.73249521220896,-1.5707963267948948,-44.25764257135773,-65.57961767500261 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark11(50.777419322828564,84.70541324125901,-89.34098968131703,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark11(-50.81198864892889,-0.5068716223453433,-52.989001908176164,1.0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark11(-5.102021177224404,-0.46788191131952317,-91.7145012200218,0.026882538471696457 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark11(-5.108057900709226,-1.4063976374051208,-75.35765361920134,-64.79441450519379 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark11(-51.224357572418064,-1.323879683768264,-0.008652740900216609,-0.7461416787119534 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark11(-5.124009241548837,-1.5544590543602612,-2.4138384849748475,-1.000090878866939 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark11(-51.321059466080456,-1.1972584881127921,-2.1623502547860483,0.9711911957377917 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark11(-51.331138463960826,-0.998389958718461,-1.5707963267948983,0.04903658032229535 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark11(-5.1368469635998935,-1.2607378816452783,-8.281204329021236,-1.0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark11(-51.37847281615592,-1.570796326794893,-29.23777486910862,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark11(-51.42352857442405,-0.07508643603084475,-1.5707963267948966,-51.9744702608266 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark11(-51.511450937218505,-1.2467804800723103,0.0,1.0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark11(-51.53059363891043,-0.38726252565172103,-38.009420502743616,-1.0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark11(-51.559920525769456,-1.570796326794893,1.5363811796484261,-34.38043558901087 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark11(-51.59793808503138,-1.5707963267948961,-53.844894524767454,-0.008204872563944088 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark11(-51.80240190434512,-1.2083112776980123,-1.5707963267948966,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark11(-51.841137076509746,-0.9144380539877837,-1.1684969551596238,-1.0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark11(-51.84723164461252,-0.5463227586456805,-38.8532425764719,1.0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark11(-51.88806814499877,-1.5707963267948912,-64.21541792662016,-57.134172667078744 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark11(-5.207136216523582,-0.1804229269693056,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark11(-52.177076819176065,-1.4637343501616813,-1.5707963267948557,1.0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark11(-52.3957313850369,-1.5707963267948943,0.0,-1.0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark11(-52.51786503747229,-1.5707963267948961,-1.5707963267948966,-0.061047725253464996 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark11(-5.253548942931298,-0.5701955411251256,-0.16874939587118448,0.05908921167180914 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark11(-52.53973142976005,-1.472584965534013,-71.96790828133203,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark11(-52.55275301901165,-5.682369441382072E-15,8.628717528800884E-4,-0.9999999999999999 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark11(-52.669295141200244,-1.4663429497250409,-82.41300631795501,28.558372396592432 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark11(-52.808425598670546,-1.0241918757896293,-65.71641974154261,77.65180550598281 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark11(-52.82472883103463,-1.3456304915520008,-41.52711312582179,-36.052526551134974 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark11(-52.848233125467374,-0.9701701657321566,-1.5707963267948966,-0.8986758289476775 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark11(-5.29368812180184,-1.5707963267948963,-89.25609373208223,2302.8099115853797 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark11(-53.027964116742055,-1.1258159716664011,-52.60239138695444,-0.06256802470675484 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark11(-53.03250486857632,-1.4042509633295308,-33.580249263485214,0.45690157889123006 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark11(-53.0328847776176,-7.105427357601002E-15,-122.56688445726498,68.55939254883171 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark11(-53.13956335503534,-1.5707963267948912,-45.975117972359136,-21.070675382569632 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark11(-5.330293079361127,-1.0325249063278479,-46.85572453955524,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark11(-53.3119730209801,-0.09824806117416533,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark11(-53.36154769703453,-1.2638748464581717,-50.73871625814468,-12.634276873668512 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark11(-53.48988496117737,-0.8436214742606664,0.0,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark11(-53.6222315529811,-0.12091785117223708,-31.966613809995735,68.67511043795766 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark11(-53.821206739139626,-1.5703216820696815,-1.5543689043353568,-0.8948899356606917 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark11(-53.83752353556605,-6.959220167144485E-16,0.0,14.467908042608713 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark11(-53.89548244507268,-0.35276185707271945,-13.898388442142007,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark11(-54.197724563928475,-0.33928834432160065,0.0,-0.3620932831762398 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark11(-54.53324004443555,-1.5587125507366788,-10.018714067284634,0.9013907127393325 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark11(-5.453920065600182,-0.9059304933162199,-98.27678463655758,8.673617379884035E-19 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark11(-5.463792002038259,-1.5553668384249408,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark11(-54.83571450118086,-1.5707963267948912,-76.18888508487902,0.9999999999999982 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark11(-54.842806147487956,-1.1530385072489138,-21.727203066126037,82.02221232757341 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark11(-54.86789054717267,-0.21210083616067388,0.0,-91.87414387228849 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark11(-5.486986747066499,-1.5707963267948912,-0.41312274692724404,-1.0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark11(-55.02280539713483,-1.5707963267948957,-54.45100609993606,-38.45797050488123 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark11(-55.10439964655497,-0.8059542162161735,-65.4057102202355,1.0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark11(-55.13681250166939,-0.42835688513388903,0.0,0.02491565255142114 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark11(-55.14575048427133,-0.1880478688160755,-3.1199566059854007,-2149.228275086154 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark11(-55.194767317002366,-0.3879323625268627,-85.09634516090101,58.94917709034402 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark11(-55.194842892311634,-0.197471974500524,-1.5707963267948966,-26.57033441045052 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark11(-55.215632386362486,-0.4396773217208169,-18.449085635652956,0.042363493823378146 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark11(-55.2593230625926,-1.7763568394002505E-15,-67.12929143181859,-4.923219666105007E-4 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark11(-55.28425810119077,-1.4210854715202004E-14,-128.01206636433113,54.95428103317866 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark11(-55.31246385106085,-0.5369157936238271,-95.5430837195505,1.0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark11(-55.53031318358097,-0.12666883617887928,-1.5707963267948966,6.578854278633345 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark11(-55.54276845071654,-0.02000915544190216,-64.295136540536,1.0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark11(-55.56177398515292,-0.12355451278434423,-93.81099105736662,-1.0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark11(-55.79320444201314,-1.0000174906425912,7.027411494737728E-15,46.74647516538502 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark11(-55.82936377561059,-0.9584267414978261,0.0,1.3132850472660533 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark11(-55.965533761914486,-0.2631645570684143,-34.570995890471494,-2343.0401185291503 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark11(-55.97349152295895,-1.4257665232363859,-25.117063798777295,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark11(-56.079795865912516,-7.105427357601002E-15,-58.50375490099127,-1.0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark11(-5.608391508933309,-0.47365533566646434,-15.363827859349904,-99.74457834978006 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark11(-56.27682010595262,-2.220446049250313E-16,-88.13417340623646,88.68153724661957 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark11(-56.290216662184875,-0.010600442936671714,-7.673762064890486,0.0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark11(-56.36781071039192,-1.229580800486957,-53.662803119671835,1.3195561908191378E-4 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark11(-56.407283577699474,-0.6034863915574391,-1.570796326794896,65.26578158257811 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark11(-56.44758785859325,-0.23902369151435932,-83.37988288843124,0.054162049953115195 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark11(-56.46484596907375,-1.1096194247890616,-1.5707963267948966,-88.90209835673255 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark11(-56.59148951893285,-1.0474325607600448,0.0,72.25593365714177 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark11(-56.66554652627839,-1.4893443010902214,0.8958035073846204,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark11(-56.67874313166965,-0.41329257553061105,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark11(-56.67882768493138,-0.8489062260960083,-96.15498065989236,0.009445064948029824 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark11(-56.80578862995206,-1.5499176220413944,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark11(-56.92953115339697,-3.469446951953614E-18,-11.48643360484859,-0.5630730048039245 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark11(-5.693119723173211,-1.2889183104257427,15.408967502843439,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark11(-56.9937182228334,-0.8158425437271795,-100.0,-0.04580337212721938 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark11(-5.701494745416461,-0.9832408228938185,-53.78860917349854,-1.0000317613344158 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark11(-57.09633062605441,-0.08380162292969726,-12.821427775900174,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark11(-57.16260042943633,-0.32958951418285576,-1.2250310333057497,39.8730350929696 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark11(-57.216114632836664,-0.05964461348102905,-39.50661303472043,2153.344470389804 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark11(-57.26213769085845,-0.028756262946444622,-136.28197913935787,-1.0000036578868208 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark11(-57.30147147671134,-0.18453481280124384,-1.4034854987037365E-16,65.95813615766156 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark11(-57.32310620596999,-0.4087854638445778,-1.5707963267948961,0.9054277021610427 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark11(-57.33539587215379,-1.1237595463669257,-11.555988740843373,1.0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark11(-57.53552593013418,-1.1130100459043624,0.0,1.0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark11(-57.570842862678006,-0.3626338887103637,-53.85500669978645,-1.0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark11(-57.57644325694148,-1.5707963267948948,-70.77925069558414,1.0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark11(-57.584951455487584,-0.5504574833234375,0.0,-71.42261400027061 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark11(-57.6141060017662,-1.5413245958461417,-19.074366504830472,-2306.832411828484 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark11(-57.694873002652216,-1.537724632776887,-0.006839098224248757,-0.8031560756250615 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark11(-57.69645768919064,-0.9175255955563744,-67.08860633913439,1.0121988427188076 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark11(-5.771850029321925,-0.58881954948616,0.0,-1.0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark11(-57.72996400490045,-0.45832469713061685,-83.65122887590371,-0.9663410497036153 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark11(-57.746263275141615,-0.46775053666818067,-0.4209308420803779,-0.3961535153243424 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark11(-57.76076795345062,-0.524683286034513,-94.05247341510086,10.503236780101407 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark11(-57.83990013316102,-0.805165596319963,-128.89989048926265,-2255.8008100395896 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark11(-57.872597685480166,-0.7448137015087206,-35.729442609586656,-20.446605063451486 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark11(-5.787752744880763,-1.2035735061283293,-72.26840828855877,0.8401922189606226 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark11(-57.927305870462355,-0.15365970278629185,0.0,-0.17224824492882518 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark11(-57.995391819081014,-0.0018594159220239714,-59.192923532494405,-1.0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark11(-58.00445670505816,14.429255834355573,-20.390887776434543,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark11(-58.14637457795843,-1.1129609927628024,-42.953070932183856,-1.0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark11(-58.189399510276814,-0.6645377253896608,-1.5707963267948983,0.5135863659105762 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark11(-58.19447255868425,-0.9711094996877443,-44.82782546756678,71.62180305369452 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark11(-58.33189256630223,-1.546946521726722,-33.10407127466193,-82.54038487417841 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark11(-5.837134510895709,-1.5642596838327683,-54.41570544022076,-1.0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark11(-5.8596213407600075,-1.0071850413457766,-5.777587203289158,-0.7407558689125183 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark11(-58.62800414341148,-0.8184654789070498,-59.482994704504,1.0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark11(-58.73565928168132,-1.5707963267948963,14.513094236595123,0.0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark11(-58.75487970089922,-0.2577040409465167,-57.06769991992661,1.000066338186067 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark11(-58.785185065190404,-0.07269884105923041,-0.2108611304604264,-37.12095365151799 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark11(-58.81461151316709,-1.2109431979642014,-47.50153767580769,50.061358020978815 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark11(-58.88760860082077,-0.04157061795459055,0.0,10.412384185375064 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark11(-59.208783603068674,-0.11429382402972633,-100.0,-1.1704190886730496E-97 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark11(-59.23587565943246,-1.3573384796596444,-24.816106426246343,-0.9999999999999991 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark11(-59.312306888499364,-0.4482657701851096,-53.66777873012152,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark11(-5.934413008238522,-7.105427357601002E-15,0.35799701740361867,-0.988752824867037 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark11(-59.348811639015814,-0.0386948362936982,-39.122322490013616,0.2858954719129221 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark11(-59.41021337549418,-1.4847180329847274,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark11(-59.44585460672123,-1.5522339699005934,0.0,-1.0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark11(-59.45253344255369,-0.6201456972573887,-1.2171383809299616,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark11(-59.545305321367216,-0.5871145903832122,0.0,0.20486638078323383 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark11(-5.954644022397134,-1.4335148202509842,-42.096505025720404,84.70925278309709 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark11(-59.575554781792746,-0.2780705363322227,-6.227016287703805,1.0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark11(-59.612278696548344,-0.2866929057020684,-1.5707963267949197,0.838674431528244 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark11(-59.711488587330145,-1.5063711938632436,-4.96465087292313,0.0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark11(-59.71362333830561,-0.5847190706417447,-22.497710675541413,-33.55814186188353 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark11(-59.77025417365746,-0.2685256526426021,-1.5020711171381436,1.0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark11(-59.83869839954973,-0.7393255265843671,-1.418980461149802,1.0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark11(-59.84447734852078,-3.552713678800501E-15,-84.11006655976708,100.0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark11(-59.984890843209,-0.7479076972833194,-15.361846830148705,0.9999999999999999 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark11(-6.00088499180809,-0.26590917327693125,-1.5707963267948966,-1.000000071891915 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark11(-60.0147703466687,-1.1513230223081616,-14.859795646062793,28.868803608218197 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark11(-60.036805124487074,-7.105427357601002E-15,-53.73258590838317,74.59546045512393 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark11(-60.04791954369715,-1.3565277483158988,-15.067536992744238,33.84759328601231 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark11(-60.08034971836699,-0.9713742877887479,-31.795799502193844,0.011870581609907727 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark11(-6.009329288349847,-1.4838574274918654,-31.78780621378492,-1.0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark11(-60.096536516826056,-1.5594139274453083,-24.74989658976297,1.0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark11(-60.09916631590433,-1.4816814014018909,-19.39979174665445,1.0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark11(-60.142345042824395,-1.2814340169293308,-26.15153563377148,-2190.4072860802507 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark11(-60.14696613606432,-0.03471776088006499,2.74495159311426,100.0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark11(-60.214242556998926,-0.9516584920021331,0.25039998067051245,-0.9999999999999966 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark11(-6.040620922925404,-0.3502165115403528,0.0,-37.53652569414911 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark11(-60.42409036090122,-0.45713840225677704,-64.28991478616712,1.0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark11(-60.44949612548061,-0.67059695803079,-84.39889014141234,-41.76965666747592 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark11(-60.53838426962557,-0.5037301269617319,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark11(-60.54811556854782,-1.5205804177064504,-47.78150302087951,-1.0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark11(-60.576581218254866,-1.5707963267948912,-90.29033056505831,-2338.2622004691443 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark11(-6.065669301700694,-0.8717851596713442,-15.644307610595064,0.19794172213671324 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark11(-60.7071617357596,-1.5707963267948912,-68.72400640884561,0.0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark11(-60.73480413021626,-1.5707963267948912,0.0,1.0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark11(-60.763668006964025,-86.15391580287024,-72.12360735513099,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark11(-60.9291287707432,-0.35072033220389986,-28.317058588358698,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark11(-60.967801693438616,-1.5707963267948948,-0.28367232485230043,1254.1999716431274 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark11(-60.979950750112785,-0.09826715216335136,-39.02440097117725,64.7986651992056 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark11(-60.98947606745681,-0.2491676566615345,51.32536459988054,43.322930408222405 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark11(-61.014695858897454,-1.5697526174923782,-44.64314106280618,-0.7003496379820046 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark11(-61.048379305789034,-0.06851546457915964,-31.76240565153011,-0.6443239535860235 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark11(-6.109865005185654,-0.36179777218652837,-1.2758741957850372,-1.0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark11(-61.13332730291292,-0.4911186477597198,-4.554550701842405,-0.8437617393626757 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark11(-61.15818157490794,-0.6620335998878463,-95.63726655683473,-0.9357461382652928 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark11(-61.23674010936699,-0.9399938432778632,-1.1949334751753184,29.683774331912957 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark11(-61.24270791915641,-0.6174522764760969,-75.22643413237942,1.3363823550460978E-51 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark11(-61.247015967166696,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark11(-61.29504819767391,-1.4556215756621782,-44.52496633866363,-1.0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark11(-61.2995732330309,-1.5707963267948948,-100.0,-1.0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark11(-61.300866584196214,-0.028621258705646108,15.60235602785474,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark11(-61.31876229988268,-0.38106999676883646,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark11(-6.133814444236702,-0.88722894664864,-42.70079230026526,0.017797984597037228 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark11(-61.3480494283826,-0.5350460424322198,-78.49500750812896,1.0000066206820433 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark11(-61.377830484153314,-0.6798239237073631,-100.0,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark11(-6.143487157812703,-0.20680415982424888,-1.5707963267948966,1.0000033507096562 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark11(-61.46832710584128,-1.5665091264056807,0.0,0.6586913507082932 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark11(-61.47062417362605,-0.87938146862137,-77.42614742445043,-1.0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark11(-61.4770191149705,-66.62540259349547,0,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark11(-61.53861423852625,-1.1018208711411692,-9.910056252233375,1.0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark11(-61.5551975254103,-1.120483500669796,-40.06640227902039,1.0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark11(-6.158041348532279,-1.2006987851642184,-2.6823235807021732,58.59886817400164 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark11(-61.614734525368576,-0.24316659877676194,-45.79302800032228,-10.160559094535907 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark11(-61.62584812235577,-1.5707963267948961,0.0,0.0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark11(-61.64123028254751,-1.5707963267948948,-75.9302409699608,-66.78702029663559 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark11(-61.6637013322131,-0.7651637309053279,-31.01105926492577,-0.7641513442319994 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark11(-61.69167089956146,-1.4545204898914654,-140.00558111835565,-24.95913016227486 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark11(-6.178471077439397,-1.5551471533323467,-76.7806023951231,-1.0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark11(-61.81637761191238,-4.440892098500626E-16,-74.50092904547397,1.0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark11(-61.843469163329736,-0.010950616819538461,-1.5707963267948966,12.714245828777555 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark11(-6.193713236292027,-0.16366297267902963,-45.09959925302466,-0.017363719721669224 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark11(-61.937211214101296,-0.6394882644103013,-84.26246631006542,-1.0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark11(-61.961419075334206,-1.0327636367688362,-21.529904928900336,-0.9999999999999964 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark11(-61.99219899325869,-0.515932092756529,-43.130216018306754,-0.6390064427753118 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark11(-62.008710001475634,-0.4772188395053282,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark11(-62.0985102462876,-0.08831576008741604,-59.30244746114046,-63.57528966358501 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark11(-62.1252914087551,-1.4229931979781707,-53.67626738400509,39.54296153728433 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark11(-62.15567248700207,-1.3518343550227216,0.0,0.17052242849986415 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark11(-62.262092015985544,-0.11698973828727188,-1.5707963267948966,0.6403950261013678 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark11(-62.30095420803269,-1.5707963267948912,-78.72357028220345,77.09922820694854 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark11(-62.319838078240636,-1.0413853556443542,-17.070327691382303,0.9910906292223085 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark11(-62.32529661809704,-0.21897857451750724,-135.45219096385003,76.81735934318002 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark11(-62.38880899212059,0.0,0,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark11(-62.50107965939386,-0.5430558490765662,-7.713308809922054,-2.3182538441796384E-69 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark11(-62.561070701996414,-0.10985889447512065,-7.194545566365828,7.105427357601002E-15 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark11(-62.57341394389446,-1.238267242631902,-1.5707963267948966,1.0000000000000036 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark11(-6.26376474870065,-0.9535960591611196,-54.52012228691723,1.0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark11(-62.652305716428636,-0.4325071610064756,-7.328018583206974E-4,-91.88621141137466 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark11(-62.693791517769895,6.430735666864309,15.91614973113451,6.706180572749731E-7 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark11(-62.69832707622491,-0.5349077846301404,-1.5707963267949765,0.9676448492599331 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark11(-62.76685757054445,-1.5707963267948957,-100.0,84.1464227596851 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark11(-62.80034155398843,-1.4390499549312155,0.0,1.0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark11(-62.81704554213976,-0.23790256681048394,-53.71563939678204,-53.514963331227406 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark11(-62.95524063202038,-0.492076824256372,14.429379705520404,1.0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark11(-62.956463570108355,-3.552713678800501E-15,-82.93310405241907,65.10269629659695 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark11(-62.997758699315526,-1.5707963267948957,-87.59750465325163,9.581643283805944 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark11(-6.301369983288806,-0.6655620017112791,-37.7336057187382,1.000791944852903 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark11(-63.02926709853362,-0.824584913891967,-179.327754611832,1.0000729027360016 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark11(-63.25937572678927,-1.0109528718990812,-28.57922914657837,-0.7714124214658602 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark11(-63.31353533072812,-0.03269973833160187,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark11(-63.3555243378436,-0.16809322546629035,-56.24149818407849,-13.442395173255875 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark11(-63.375413614775276,-1.0938460156369274,-45.246638043452705,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark11(-63.38064262249604,-0.653223107186921,-27.299670212337187,-78.57107564892567 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark11(-63.400096595420656,-0.0484182583402485,-51.17921404388801,-1.0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark11(-6.341882042387796,-0.8303228559372647,-37.48486882686459,-33.268319002080545 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark11(-63.45574954954267,41.84077355105978,28.616797715651302,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark11(-63.54969763198444,-0.6079197602995634,-50.04721114943552,-0.5373402325201646 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark11(-63.71337323193503,-1.5707963266237126,-94.20115642898969,-1.0000002375797026 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark11(-63.76694422145708,-0.028083683510686658,-646.4567224366929,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark11(-63.925403437352976,-0.03054864731646678,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark11(-63.98953770713574,-1.5707963267948912,-100.0,20.293673829411134 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark11(-64.03654882357756,-1.1719529828605175,0.0,0.9392254714248774 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark11(-64.03897930731475,-1.5701068322985654,-1.5678265436705754,-0.05603207627703519 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark11(-64.05048532539007,-1.185582853516296,-69.90627702355692,2255.8388879813874 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark11(-64.09382410846406,-1.3547460300068415,-3.1917799838396803,-31.421190667896568 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark11(-64.09952757302264,-1.5656442242518236,-49.517851255080956,-0.16119102183874914 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark11(-6.416269171672763,-0.3497547951569955,-90.72785420510836,0.0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark11(-64.19452770523972,-1.5653706956210216,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark11(-6.4236171170796155,-0.25477775044016937,-33.56931694683706,0.9486616570568174 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark11(-64.2382260354811,-1.544292112144284,-1.2226722167633626,93.5066514021803 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark11(-64.30456856097595,-0.7352103751400105,-1.4291922921950024,-0.8478008903404176 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark11(-64.34601531453015,-1.5707963267948948,0.03326324141363103,-1.0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark11(-64.4133227843297,-1.037085926034078,-43.7968612923821,77.4038415966669 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark11(-64.4337680090711,-0.48522347103199626,0.0,0.33773315436730533 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark11(-64.65766364154747,-1.5707963267948963,-39.80733089493264,2291.181311723722 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark11(-64.67744155258256,-1.4610049064976167,-10.918108078328515,2134.174482949734 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark11(-64.72910477258527,-3.552713678800501E-15,-88.52392739500962,1.0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark11(-64.77425382896637,-0.24769473550394847,-1.5707963267948912,-15.672560704693108 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark11(-6.500979931890033,-1.5707963267948957,-8.256371112898993,-6.3108872417680944E-30 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark11(-65.25065048341656,-1.5707963267948954,0.0,100.0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark11(-65.26997402146476,-1.1182883722303423,-97.66411739596965,-0.018864704028261764 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark11(-65.27270649292534,-0.7635124528788714,-97.36037354813207,-2236.831994739007 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark11(-6.5318749604899615,-1.5118954602664085,-73.66832812982796,-0.9999999999999998 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark11(-65.34420197026037,-0.5476179312107909,-1.5707963267948983,-0.8484860909206835 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark11(-65.43837535189897,-1.5707963267948948,-26.03062133875555,5.293955920339377E-23 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark11(-65.4915754699752,-1.5707963267948948,-91.71074709562173,0.3740521685567515 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark11(-65.64644568457882,-0.40886076958608175,-41.237731824647206,-0.9847775951837134 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark11(-65.66721519310208,-0.01619863994041675,-96.63786130002725,0.9713257345902764 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark11(-65.80677232770796,-0.7946002274374222,-54.482481583879064,0.5538598203614871 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark11(-65.83352512022213,-0.6316341145932448,-49.042137219549055,-29.384817325152184 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark11(-65.89405886147523,-1.2257622834359212,0.0,24.045939279281598 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark11(-65.89772244219536,-1.0516338118907103,-3.4700207043435967,1.0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark11(-66.07932028206409,-0.010353717957250819,-3.4110458734756435,-75.57539583098922 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark11(-6.619358214664988,-1.5293373459735191,-31.516132906520973,-1.0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark11(-66.21095428718257,-0.1895343438868326,-32.58142626894188,0.007993695961539427 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark11(-66.31605148988956,-1.7763568394002505E-15,-33.608597657423125,0.9438308599775662 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark11(-66.41244103542248,-0.1736754990806956,-54.81050889663372,0.006145768709518773 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark11(-6.64318279770535,-1.1532033789623903,-8.866889957326325,-1.0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark11(-66.51025991017298,-0.03851387003068862,-46.677518197992114,-0.6004863140935537 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark11(-66.54192849063003,-1.3690772344368625,-32.97162381778264,6.515645333753521 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark11(-66.56407481797889,-1.5707963267948937,-1.5707963267948948,1.0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark11(-66.61358333747575,-1.1969047582800092,0.0,-1.0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark11(-66.66450698462101,-6.421661615514751E-4,-1.5707963267948961,0.7840888226789292 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark11(-66.74535277845567,-0.4916221953744073,-55.2026471417865,2266.0155390022123 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark11(-66.87709083248525,-0.008868475748400773,0.0,0.80449549296665 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark11(-66.99497909971817,-0.3111143720841263,-76.02847025867734,0.13973707560175258 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark11(-67.14286496882855,-2.1504848197119204E-14,-1.5707963267948966,-90.54875866528653 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark11(-67.18231225071185,-0.005116837716805266,-38.8220914642933,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark11(-67.27013899301016,-0.2666320678457965,-17.169175455857527,-0.7345562412767048 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark11(-67.38213049156187,-1.5707963267948866,-57.421819704371494,-0.6829882288658591 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark11(-67.4699451796382,-0.5110478706164798,-44.39417811182174,-69.34597869846904 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark11(-67.70391422083314,-0.024594460191210032,-24.574866753201622,-1.0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark11(-67.73038011362075,-1.5707963267948948,-95.45954140804058,-0.7256686587217271 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark11(-6.775175610092432,-1.2307354885059434,-90.49847278189573,10.264884031680026 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark11(-6.784802260710535,-1.5707963267948963,-0.5375111892028316,7.928926082032945 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark11(-67.86121671878901,-0.44083920219257067,-0.09591047797083246,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark11(-67.88438451977822,-0.27396857622215126,-31.8258434453689,1.0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark11(-6.793855392984947,-0.41798563719206755,-5.48274996535204,-4.0607069397050388E-115 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark11(-67.96405627311273,-1.5628333540455193,-1.5707963267948966,0.7005112485879892 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark11(-67.97950974134363,-0.021550091819972614,-85.99256524011103,0.0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark11(-67.98953042135065,-0.20253415432805766,-1.5707963267948963,68.31030697943982 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark11(-68.00572123600944,-1.201473748524652,-19.062696071269357,0.0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark11(-6.811246976828526,-0.9849137795628348,-43.58469426273868,-0.3762034866068855 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark11(-68.12531874138352,-1.5707963267948883,-44.516952603880554,0.5226897829619954 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark11(-68.13602848062885,-0.05999596871077295,-121.45056887276958,0.11891088381778075 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark11(-68.26007491856834,-1.5707963267948941,-1.116965148904086,0.03385031563599439 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark11(-68.36202486312729,-0.8168796423870854,-63.17937516090086,-1.0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark11(-68.40775762988149,-0.9026546172634748,-6.260639318539987,-2117.100718565883 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark11(-68.4613532865487,-0.06861926875010489,-1.5707963267948966,90.45308806973573 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark11(-68.6910142160252,-0.3206076649165921,-2.0537606311149297,0.28300363018937813 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark11(-68.7775036919693,-0.22736748617202943,-31.68393444435973,-1.0000000044052797 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark11(-68.92243596207169,-1.4516961968221214,-10.938944840984053,71.63996881353088 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark11(-68.96748044324374,-0.3492096703629963,-59.85535728635499,1.034986437330959 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark11(-68.98616675920519,-1.5707963267948912,-38.96329870677771,-0.43841715001712167 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark11(-69.07987992452092,-1.5707963267948912,-39.37257824274186,0.9999999999999991 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark11(-69.14960590009251,-1.5707963267948886,-53.668290515218246,0.08192595013538595 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark11(-69.16426476419636,-0.9455704404053419,-0.4819698842469512,-23.06885660686881 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark11(-6.916545040896142,-0.6463321203358858,-44.70775617157321,1.0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark11(-69.18947008924084,-0.4747323070768843,-16.458111978059705,34.318403633815024 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark11(-6.92601814175273,-1.328745756663897,-37.74269486519739,29.532898560076646 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark11(-69.31932533167651,-1.4974245742713426,-0.5895245132989658,1.0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark11(-69.44809145846429,-1.5620237642909227,-1.2418310408375715,-1.0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark11(-69.54584409377792,-0.1775938872500168,-73.5336459165345,-4.5522099189454387E-159 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark11(-69.63648696060467,-0.5930929176264547,-2.3751516464130984,0.04960790711982212 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark11(-69.65377103986596,-1.5707963267948963,0.0,-1.0380266313426583 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark11(-69.73576218871978,-0.204331235242035,-129.9080649075788,-1.0000690435351804 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark11(-69.83618629579568,-1.5707963267948948,-85.99864428549671,-1.0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark11(-69.8610205864869,-1.1233289089046958,-91.9853785410691,-2258.751494871822 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark11(-69.87186378472907,-0.6343129448151892,-44.852481697729004,0.6892947594662782 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark11(-69.92739073058075,0,0,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark11(-70.01290977099012,-0.08912014061155729,-38.805022857601344,1.0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark11(-70.06064305289978,-0.14966820280075377,21.765165702126772,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark11(-7.013591591324236,-0.1094376879701458,0.0,9.860761315262648E-32 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark11(-70.143923949677,-4.627014874444456E-15,-61.832573510253034,1.0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark11(-7.024333079826431,-0.038045938641993654,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark11(-70.41172133203327,-0.35777309884829633,-32.719267297169765,-39.464364116010955 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark11(-70.44514095904651,-1.5704199958918328,-29.800007981451714,-0.9119284260800828 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark11(-70.45498615599038,-1.5707963267948912,-24.253049430316253,0.0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark11(-70.45911525368473,-0.04178592022058514,16.420149607771208,0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark11(-7.051065235386673,-0.42840765072662146,0.0,1.0000000000000036 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark11(-7.054194862214189,-0.2981743626272717,-2.8418185239589917,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark11(-7.064415349749005,-0.8862195885986449,0.6316280063771101,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark11(-70.91919286109743,-0.9983557974562971,0.8566133848665107,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark11(-71.05405281498818,-0.4597359106223766,0.0,-33.31315544130999 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark11(-71.09565393531444,-1.3979874354672182,0.0,1.2618242090889732E-7 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark11(-71.19222293720726,-1.1102996386929398,-18.158476720146297,-1.0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark11(-71.30176792317927,-1.457682164756425,0.0,-0.032425921920492096 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark11(-71.36275493906291,-1.5503181404848707,-80.67800905028602,-0.8769916564034176 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark11(-71.47862495977333,-1.5707963267948963,0.28930640271726205,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark11(-71.53022298289244,-1.1740323763335994,-67.09543447520605,-91.54183488725454 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark11(-71.59665901184823,-1.3226206031492866,-37.6921176430173,1.0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark11(-71.73232544619567,-0.9272339554083151,-100.0,0.013379442366832861 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark11(-71.80881754179016,-0.054307344506038024,0.0,1.0000000263962368 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark11(-71.83011857806582,-0.721851507969275,-88.94461946715427,0.9999999999999993 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark11(-71.83895117659313,-0.3639596222684247,-49.718921661894456,1.0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark11(-7.186082484118856,-0.33198422349841106,-1.5707963267948966,38.260318967969454 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark11(-7.188723960723806,-0.008389907040361416,-86.87074334230458,0.9936393862070153 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark11(-71.90351210443315,-0.4189212829403437,-56.32660667642615,6.06184855055541E-7 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark11(-71.93443816324772,-0.26507880698707714,-36.29344669028037,-10.609825887019468 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark11(-7.1966802813384,-1.9645687249685674E-4,0.0,1.0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark11(-72.0305139968109,-1.1867670725928234,-9.981988480322343,-0.697433275759056 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark11(-72.06358557699835,-1.0112573480916993,0.0,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark11(-7.2071526800744055,-2.220446049250313E-16,-4.297819539193101,0.9805016563394281 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark11(-72.09072990592284,-1.495643440790953,-83.67870884311898,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark11(-72.14297964201126,-0.16078192852983172,-6.68934697241329,0.2208392628917073 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark11(-7.214488064857605,-1.2147872364771501,-127.39690787873111,-0.38645674430025473 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark11(-72.14808418878675,-1.5707963267948957,-69.274087329642,0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark11(-72.19017031044194,-1.5432248233467596,-42.55842124314413,35.16789438904294 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark11(-72.29400308226585,-4.5217531743422303E-4,-80.93428151193096,0.08424867199916523 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark11(-7.236504570926483,-9.768330323323619E-17,0,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark11(-72.39960289845973,-1.559769640600635,-0.09671108192370681,-25.289040172804008 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark11(-72.48476381756204,-1.0708378609922435,59.46369226086773,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark11(-72.51280653144461,-0.09250329389786847,-73.60970301027025,0.8651382746042181 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark11(-72.6823792683677,-1.1346212168230991,-52.41601324976861,-0.058767580361232225 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark11(-72.90301309972766,-0.08575996155958786,0.0,-0.9880247575853858 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark11(-72.92010009025321,-0.9128638248118593,-38.85221054948293,0.714057801312255 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark11(-72.9916753228942,-1.0336439802036996,-41.85964522370147,0.05840220100213536 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark11(-73.03898227471505,-0.7018864001006877,-1.5707963267948966,22.08898582249431 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark11(-73.11352029972518,-4.440892098500626E-16,-22.83051524763873,37.66759678136222 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark11(-73.11953552925365,-1.4764238244913686E-17,-1.5707963267948966,-0.997440708641461 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark11(-73.23846204086155,-55.40743110541897,0,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark11(-73.3336272098058,-0.13223420203429026,-1.5707963267948966,-1.4210854715202004E-14 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark11(-73.45207016484959,-0.3061596136976652,-29.945660520119624,-36.61360532144781 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark11(-73.5077418682864,-0.07461529022544179,-1.5707963267948966,-8.835246873492643 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark11(-73.57332495325576,-0.10645876203083533,-1.5707963267948966,-2001.4526782347227 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark11(-73.60276646884223,-1.488203162052045,0.0,-1.0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark11(-73.64181556935401,-0.697168511373877,-60.1970996041113,-1.0000000000000924 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark11(-73.68156535500603,-0.4826157233081101,-1.5707963267948968,0.8152148560331927 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark11(-7.370971016071323,-0.6027278336652347,-94.38237138454231,-8.021783040746858 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark11(-73.76633786906828,-0.6488593402912386,-1.5707963267948202,0.544799865739019 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark11(-7.37949326739414,-1.5707963267948961,-0.011625255970791698,-31.61654729704553 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark11(-73.89273137122056,-0.6763543391856306,-1.4488179374679595,99.75649682553717 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark11(-74.07302666255123,-0.03557901491060585,-73.32612297743565,-28.44926036463316 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark11(-74.19915199279728,-0.8423865395542474,-32.66772741924298,96.09612665353573 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark11(-74.24115248996361,-8.881784197001252E-16,-10.951831383620586,1.0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark11(-7.434827467964682,-1.1334068499293721,-43.94764831273952,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark11(-74.53202759799879,-0.5136608107371151,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark11(-74.53703267507626,-0.35210193828397585,-1.4746458054447409,-55.77449967436454 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark11(-74.53894403856722,-0.6766912212430967,0.0,0.5425207591330078 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark11(-7.457165706792278,-0.9612028233777455,-31.5581999510623,64.27628462041397 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark11(-74.61003952650984,-1.4408008606358687,-34.27990730067632,0.9059825806509613 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark11(-74.63063801219042,-0.23838933533035167,-87.8055025732295,1.0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark11(-74.64946415469308,-1.5707963267948948,0.0,-100.0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark11(-74.65760041985021,-0.9073458952500337,-74.28451288587529,-53.59477881984986 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark11(-74.66868445010648,-0.4457998546523545,-1.5707963267948966,-60.231755418981564 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark11(-74.6901833501822,-1.5707963267948912,-52.59100341986613,25.195491950385517 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark11(-7.472426811486236,-0.6503529714101761,-83.86207908667488,0.0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark11(-74.89292719917772,-1.5665466253574771,-71.07131347482876,-56.87345474892412 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark11(-74.90686280817219,-1.1436362841069274,-26.01677827958229,-100.0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark11(-74.93106965641542,-1.450915963432533,-39.031270783194486,1.0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark11(-75.01891329079298,-0.6853927538508482,-10.589728817355795,-54.029288403936484 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark11(-75.18350504425766,-0.3902236137990408,-1.5707963267948966,-93.48098514555666 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark11(-75.29454267598081,-3.552713678800501E-15,-15.354124800288783,-1.0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark11(-75.3810944130321,-0.3296263574879595,-90.21984040783043,-0.06252563519625849 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark11(-75.42546123906946,-0.24355287042942317,-0.654226337053676,0.9626016598817253 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark11(-75.49169169038696,-0.637113979688565,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark11(-7.562325520614728,-1.4748123996432128,-15.6920803685924,0.005714869302333114 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark11(-7.562381082917416,-1.5707963267948912,-95.92971299958447,-62.02356285094175 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark11(-75.67853764378278,-0.856409152650869,-18.135900150204098,0.5812935310102212 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark11(-75.6813654571761,-1.4759987494588138,-1.1726399542915724,32.61590201309259 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark11(-75.68882867566835,-1.5707963267948963,-27.94551619923375,-2018.4972355081331 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark11(-75.76634692984237,-0.8557288203323302,-43.58080612679627,0.0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark11(-75.8400059566973,-1.4565941481321367,0.0,1.0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark11(-75.90588354306558,-1.5639235524024107,-66.85951278353006,53.640627321862574 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark11(-76.00797933528315,-1.5594306344716753,-1.5707963267948966,-1.00000044663808 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark11(-76.1326037900448,-0.24481896369560513,0.0,-0.0519508535682901 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark11(-76.18752460815497,-7.09076453468872E-15,-1.0496841169646365,22.80404789040015 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark11(-7.623790216578,-0.9766475471214234,-93.06298004175619,-0.0625743020706344 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark11(-76.25742312086682,-0.8811092254752799,-0.8555925508319542,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark11(-76.28770308255295,-0.5190518903037145,0.0,1.0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark11(-7.634533836699191,-1.391476015786372,-100.0,0.30174681719042296 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark11(-7.637713059320423,-1.4074660172870221,-88.15973417929341,0.046787129673191145 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark11(-76.47646686625454,-0.238657307632765,2272.519573501509,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark11(-76.53283924638238,-0.672730367993779,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark11(-76.67580726779285,-0.5201729573366058,-62.021266699152484,-0.18293762636376765 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark11(-76.69373542844099,90.86576709447462,-53.31444275424069,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark11(-76.79734824891737,-0.009466485303677996,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark11(-76.81410025319386,-1.5435317818594818,-0.4228710434983848,0.0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark11(-76.8798214428598,-1.5707963267948948,-30.074895300546117,25.457505828532664 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark11(-76.99272645437097,-0.9746499424937995,-54.19839815023699,0.22116576271089627 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark11(-76.99352792979751,-1.5707963267948877,-0.11870524539805793,-1.0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark11(-77.00720842675621,-1.4878463188340576,-75.65920391334501,0.9690457469580781 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark11(-77.16267166459936,-1.3459751458674052,-48.44032252827386,0.8268697281017465 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark11(-77.17487972190816,-1.3392742166522946,-88.51576439675107,0.4689312829594203 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark11(-77.2128474167694,-0.9934619150232162,-31.568510952563095,0.0625581305071183 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark11(-77.31611099047294,-1.5707963267948948,-67.26745420123393,-50.6513614696064 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark11(77.42812640917091,0,0,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark11(-77.53548817877336,-1.5707963267948912,-89.7279586832757,0.19920175479840263 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark11(-77.68408585947805,-0.8969945525805052,-21.822886973632396,42.68799646641054 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark11(-77.73555663324098,-0.3390804099157574,-1.5707963267948912,46.4300281110175 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark11(-77.7424472137993,-0.5193854423122486,-79.01669143314342,-74.86007468924036 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark11(-77.90682870412138,-1.2873281048503475,-164.89023659216127,-0.9999998582246652 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark11(-77.91340542991622,-0.6393387194394791,0.0,-0.390686348251748 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark11(-77.96075168009072,-0.5156281393570299,-88.12447788261092,22.528281064561632 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark11(-78.099987921448,-1.4990280057817424,0.0,1.0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark11(-78.12568678223177,-5.551115123125783E-17,0.22261274597055392,-0.04088893699922325 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark11(-78.23791603121748,-1.5179831035379867,-10.676814191922688,42.349697053904976 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark11(-78.3378844081968,-0.8380796946886439,-1.5707963267948648,-74.75107709215769 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark11(-78.39406293088264,-0.29592534341861243,-77.37167942092667,-1.0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark11(-78.41571217255071,-1.1878869391199782,-1.2496581619738067,-28.5279768425311 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark11(-78.43134790226392,-1.2960207136134794,-44.785575192075726,-1.0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark11(-7.844560903757162,-0.7071384437901429,-24.453080255726107,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark11(-78.62312608774607,-0.1420130041939558,-90.99669195376788,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark11(-78.73240075804289,-1.0361963911795562,-72.57350252004179,-0.9999999999999996 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark11(-78.9011321283168,-0.5618915495169261,-7.281360920542273,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark11(-78.94541266601156,-0.176684531103831,0.0,79.66813680252211 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark11(-79.01623086694484,-1.5707963267948912,-68.10448474249614,-20.24621899721217 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark11(-79.05256734180585,-0.4420959336234116,0.0,-100.0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark11(-79.05895422159473,-0.7697362571031093,-98.07148572319578,0.9830268424531523 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark11(-79.07255334396672,-0.6898876814506227,-1.5707963267948983,-75.00792272573737 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark11(-79.07337594509997,-79.12701541837885,0,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark11(-79.16150712026486,-0.9626849515118059,-32.178341812662666,1.0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark11(-7.916741641373704,-0.2216851506997014,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark11(-79.2798928587352,6.799841981142667,-1.5707963267948966,-1.007057388779789 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark11(-79.52657126026608,-1.4348239340169375,-18.469152140939368,0.8256544894343809 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark11(-79.55833438728278,-0.057619540562947234,-53.02503200675963,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark11(-79.67232197770821,-32.15018665707544,-94.28155049986972,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark11(-79.77824437017622,-0.415476164914808,0.0,1.0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark11(-79.79589083381555,-1.5464037294755437,-59.04981474569043,-0.8074098384324911 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark11(-79.814315212531,-1.5541426930714304,0.0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark11(-79.8208113912191,-0.16581054631194792,-3.409512820727741,-0.23544763023198612 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark11(-79.82143988176597,-0.0873983403367814,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark11(-79.82847465233907,-1.1860886209593424,-99.31073446031237,1.0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark11(79.83473150195758,0,0,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark11(-79.90677653602988,-0.4461733523622556,-1.2212761752168328,-75.80899013752897 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark11(-80.04338888560285,-0.4871044184490936,-17.278759594743864,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark11(-80.04735423033152,-4.440892098500626E-16,-70.54537996483181,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark11(-80.1009467779476,-0.5812637793379812,0.0,46.92868229872029 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark11(-80.13864392914775,-1.5707963267948948,-10.668936954092104,1.0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark11(-80.14854889644737,-1.5707963267948961,0.0,4.4888255467692094E-190 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark11(-80.17603824897087,-0.7435124606226039,-1.5315191836814497,-0.9326318840532998 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark11(-80.23233714462164,-1.3742691174805866,-1.3938602108523601,1.0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark11(-80.2813969037799,-1.5707963267948957,-2.0562462322089443,1.0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark11(-80.45930506406951,-0.7544529083482718,0.0,43.29703314342322 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark11(-80.47482700880863,-0.0921788748441319,-34.7955500707707,-1.0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark11(-80.55945397704777,-0.8469561424460629,0.0,0.01998526409103682 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark11(-8.06276718503696,-1.5707963267948912,-4.7051859672502445,68.46819355548149 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark11(-80.65685703596554,-1.5707963267948948,-97.16341797420986,1.0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark11(-80.72884864620629,-0.02884094188684758,-122.55915437314171,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark11(-80.74797555564432,-1.4905326724087191,-163.41898328182248,-0.5725338479824886 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark11(-80.75004415751097,-1.5284883790438653,-9.037344721373316,0.2307452587302491 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark11(-80.948655348377,-1.282801320341823,-56.5296605571403,1.0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark11(-81.0227709344748,-1.2619435251350726,-17.14438012101921,-2.192953296739201E-16 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark11(-81.12602744346142,-1.5707963267947962,-32.938647598164536,-0.06255715015750409 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark11(-81.14893972146203,-1.2682188357203505,-40.41072553240927,72.13165459713966 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark11(-81.15987212922008,-1.3940928659692036,-37.18961931836444,1.0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark11(-81.23910758211788,-0.7277128944518427,-72.75495417659083,-100.0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark11(-81.24477615967697,-0.4553521873922657,-67.32216021294907,2.2140949192472713E-8 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark11(-81.36514063010819,-0.15610571550470187,-1.0515622744733424,87.87368900791898 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark11(-81.38422129449839,-1.5070130335085963,-1.4233719470382535,-37.051653822335865 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark11(-81.42563447967215,-0.38812189463204394,-13.135949159150341,-1.0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark11(-8.15815833310499,-0.49780691259689114,0.0,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark11(-8.16918603004012,-0.6751831903637646,-14.157998031873518,-0.3621367216886327 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark11(-81.75452792196333,-0.2825923035404787,-1.5707963267948966,-76.3458898298178 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark11(-81.93037480770437,-1.4107215790197751,-4.559185742843614,1.0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark11(-81.96656001044082,-0.30104484946132526,-1.5707963267948966,86.50954320247541 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark11(-81.97915521157522,-1.5707963267948912,-77.15255882507752,61.50002869575525 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark11(-8.216248729702299,-0.3245889305320714,-1.5707963267948983,591.3482401075856 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark11(-82.24438652536735,-0.8451176850926205,0.0,-1.0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark11(-82.26787112281018,-1.2061908569721078,-1.020004093094101,-37.1414062852005 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark11(-82.35659413668269,-1.5707963267948912,-49.81973337707998,19.998642536633948 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark11(-82.3769914025951,-1.5707963267948957,-14.070212814527487,56.09060048832386 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark11(-82.41119153126681,-0.2501955200111702,-1.5707963267948966,-0.030880334878531812 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark11(-82.54401787492797,-0.08495096008605688,-1.5707963267948966,-0.06255720710504276 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark11(-8.254966300147231,-0.14994666312288585,-100.0,1.0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark11(-8.261033104061994,-1.2060024466235344,-88.1230338854154,0.8166974508977773 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark11(-82.62893895789342,-1.5707963267948912,-75.03624975159057,12.47675849806788 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark11(-82.70554501085545,-0.9829349687244462,-19.41430243820507,0.9999999999999982 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark11(-8.274941918642874,-4.440892098500626E-16,-45.53917043541275,0.36443743816689583 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark11(-82.76719409627361,-0.9202971115385168,-99.74583852255235,0.843538956999879 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark11(-82.78656469511594,-1.4801539107792565,0.0,0.9999999999999996 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark11(-82.78985355320626,-0.035510674535049885,-91.02287361322821,2116.491306365514 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark11(-82.79153442060355,-0.48884651532948514,0.0,1.0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark11(-82.96129346481816,-1.517314030898194,0.0,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark11(-82.97279041362964,-1.475357402390884,-52.71137760137184,1.0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark11(-83.06955427851248,-0.28991967995308343,-22.031406672600596,0.32201878794054994 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark11(-83.08774756392005,-1.328485168604045,-15.697342708091046,0.7770052698507444 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark11(-83.21998168146953,-1.223994219982449,-56.77720617146576,-1.0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark11(-83.26216730269915,-1.5707963267948948,2495.37103172458,0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark11(-83.27716729433368,-1.2596544172242452,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark11(-83.30650541126639,-1.4534689422076086,-129.78168047114175,-1.0012115219679802 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark11(-8.37799990820669,-1.44016285034748,-19.964483937068344,18.97558359597741 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark11(-83.78591671642685,-0.9392662957019454,-1.5707963267948966,-2.308244654446434E-128 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark11(-83.82105297232616,-0.8876002077096246,-22.298463110468955,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark11(-83.84026839687205,-0.327826769175482,-1.5707963267948966,45.36992755900127 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark11(-83.87359038453155,-0.12909681498095874,-0.08903197544333163,0.638795977151595 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark11(-83.87833389237494,-0.9536584696299654,-72.64065101353114,-41.049726590209715 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark11(-83.96764213649027,-1.7763568394002505E-15,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark11(-83.98473693087445,-0.4312481565835659,-87.59609720681773,1.0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark11(-84.2238041584266,-0.11471758231902252,-45.32380911270491,-0.8614848847189489 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark11(-84.30519540027498,-0.3167689857839643,-107.53940549504071,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark11(-84.37439323023256,-1.5707963267948961,-55.63613879310776,0.11351832885802038 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark11(-84.38888143681402,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark11(-8.473457135717169,-0.714973996556495,-97.12432324336717,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark11(-84.76343854330324,-0.7901599103422352,-93.09511506994815,-1.0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark11(-84.84862188798027,-0.0337335496134421,-100.0,-0.9672534544859553 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark11(-8.485119690855242,-94.24453157911242,0,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark11(-84.88864367758346,-1.5555094838931953,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark11(-84.89004462262292,-1.5707963267948806,-9.838099580878276E-4,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark11(-84.99225236943886,-1.764169059625761E-15,-88.46613410865541,-0.8485371069818215 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark11(-85.24025182227639,-1.5707963267948948,-5.319026156531464,-35.755268221426604 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark11(-85.28880972517987,-1.0400754048227503,-43.215512787959184,-1.0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark11(-85.36943223256972,-1.5695596892029968,-1.3654318815439996,1.0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark11(-8.545104890179388,-0.5081282224471089,-6.786837414094971,-4.795795236928244 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark11(-85.55394598922427,-0.04811913363678855,-1.5707963267948966,0.012361792639355912 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark11(-85.65667633719684,-1.5388184079487948,0.2662077585022505,-2202.3685049752403 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark11(-85.75894552139253,-4.440892098500626E-16,-1.5707963267948966,47.16266358805143 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark11(-8.581964201704569,-1.3484684114292198,1.435699602076934,-0.016200573845883304 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark11(-85.92879967375096,-1.2505646396776342,-58.59299244698692,1.0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark11(-85.9397826569044,-0.8987130559734902,1.0629617443582489,-0.5433157966732713 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark11(-86.06946242132544,-0.3181179782610888,-44.99469511927629,0.12316689588071394 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark11(-86.10887076338973,-1.5707963267948948,-67.44685479751995,38.63424487106769 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark11(-86.13972382712664,-0.7176798068492529,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark11(-86.15085284255835,-1.3824886717769498,-6.68081583312312,-21.539204981785048 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark11(-86.2507795701919,-1.5066828088043778,-2430.866239965369,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark11(-86.26021623674094,-0.047443864222213805,-1665.8135361361271,0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark11(-86.30423495599118,-0.09692373874235116,-61.289201494393744,0.008836522175048711 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark11(-86.46881440280158,-1.0111482578625366,-7.6648291872403576,-0.46624279150947423 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark11(-86.59396735100998,6.458090517049929,-1.5707963267948966,-0.48013902359549365 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark11(-86.59475426977822,-0.8742278265252139,-76.43185183785006,1.0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark11(-86.62650345846782,-1.5707963267948912,-33.51545230748596,-1.000068093236956 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark11(-86.78505306523904,-0.8184933556184406,-66.37681200552011,-0.8946503712488876 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark11(-86.796024971694,-1.5707963267948948,-0.11752295730355355,84.15823321948358 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark11(-86.95681212786512,-1.5707963267948912,-1.7628661176789575,0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark11(-87.18349329063419,-0.03738400650295051,-17.3265643886901,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark11(-87.3685822939274,-1.4606682297489684,-35.437892401987085,1.0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark11(-87.4720175570483,-1.5530820089671966,0.0,-1.0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark11(-8.750689366078854,-0.7793069696391979,-101.04428145821886,-1.0178595642197426 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark11(-87.53168406740934,-1.5649609720640507,-63.321320452741645,-1.6484210889813888E-4 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark11(-87.53678840818958,-1.0329005413172045,-17.20305230125207,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark11(-87.59943399566404,-1.0417123482952386,-1.2297737403749383,0.7047810751565127 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark11(-87.63120450167973,-0.7710680398393026,-35.54062891153842,0.012320282993117687 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark11(-87.870172874772,-4.440892098500626E-16,-62.135092425789345,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark11(-87.92219665093444,-1.4610952514800877,-1.5545689258362245,1.0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark11(-8.796039478285401,-0.8756708357244835,-11.00611349144756,57.12113023927628 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark11(-87.98003737931084,-1.5707963267948948,-75.21506577940796,-1.0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark11(-88.01363397105966,-1.5684947595602827,-1.5012598683594536,-1.0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark11(-88.0538647311274,-2.220446049250313E-16,-13.551351701886283,33.63148353194896 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark11(-88.05553435679742,-1.0337177981269798,-1.4527932349880766,-1.0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark11(-88.09711844134202,-1.5707963267948903,-1.5707963267948966,0.9999999999999981 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark11(-88.10433269953054,-0.9315780521356821,-100.0,-100.0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark11(-8.820826334038752,-0.49701861982054873,-9.050671083133125,-0.03432864235647712 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark11(-8.824514198211347,-0.8607035005580218,-8.608487041914454,-22.113004761120603 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark11(-88.25892056092391,-0.4618564003610558,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark11(-88.34493304415318,-1.5242212845058027,0.0,1.0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark11(-88.36824216244243,-0.21608426905796368,-71.76599157718968,-0.9780777053545083 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark11(-88.57116791377108,-1.5707963267948948,-0.8441604271791426,61.195930205283396 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark11(-88.57737095096202,-0.27619772061103065,0.0,0.0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark11(-88.73956499297256,-0.18974461304944773,-1.5707963267948983,77.80013577959102 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark11(-88.7867273102068,-0.3716487823379382,0.0,0.5614747946002545 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark11(-88.91889427109238,-1.5707963267948912,-40.26342774157501,1.0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark11(-88.9966549455461,-0.48019527177008214,-83.1634524494336,-0.575248462029297 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark11(-88.99791060750512,-1.4912517849525,1.7763568394002505E-15,-0.8352307774207774 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark11(-89.05462046622233,-0.6220257460800904,2.1684043449710089E-19,-0.7993243819588456 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark11(-89.13422917569129,-1.5707963267948948,-123.62411526494638,-57.85940675269978 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark11(-8.916075774752972,-0.909040845009983,-77.9777392513087,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark11(-89.23178383630237,-0.5639619032503476,-11.26803413896355,1.0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark11(-8.938021850162103,-0.6452322868825102,-83.03348186302067,57.36278902262347 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark11(-89.38964308520698,-0.008360283440791674,-88.53270589399708,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark11(-89.40485241190554,-0.6165175637446161,-27.19247319381725,-0.05315410749872751 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark11(-89.64560752478215,-1.5256441610381428,-15.160693548988277,-96.9115275094286 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark11(-89.70947405333374,-1.1738398139627741,-59.67984303377625,-0.05076283874198145 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark11(-89.70954107728002,-0.8063371878423169,-75.57647602506407,-18.39127338911642 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark11(-89.73820640853809,-0.7182776163719122,-22.17583067930913,-55.703001257818954 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark11(-89.82878207815409,-0.2821485447385552,-88.47167533215168,1919.2399893532015 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark11(-89.86257272904508,-1.5707963267948957,0.0,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark11(-89.97631422469314,-0.5471998640759969,-0.19403800752785116,-2143.714513516014 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark11(-89.99602470313839,-0.5996007232806306,-19.356187470964443,-52.24232295000854 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark11(-90.04461671394684,-8.49057234646859E-7,-4.523540134570615,0.11115806060628157 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark11(-90.05910724678164,-0.46258469574385686,-76.70979557810689,-1.0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark11(-90.05994543872734,-0.2458546299659341,-54.00886763292815,2339.2510883439973 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark11(-90.07173089587222,-1.5707963267948961,-0.11129733572144362,0.5235785389363231 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark11(-9.018460823020412,-1.471327974833477,0.0,-0.04124135420197958 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark11(-90.19595486052904,-1.5074476389994134,-38.908289390248015,0.0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark11(-90.24184677037262,-0.5119380175949702,-0.6129849671536629,2061.3560276444723 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark11(-9.029088749568128,-1.463643037136737,-1.5707963267948966,19.155078676042542 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark11(-90.30918429612802,-1.5567700474918267,-1.5707963267948966,13.420030723604611 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark11(-90.37961303630186,-1.1003634233460817,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark11(-90.37987949232107,-0.6454918182659479,-38.984689185345786,1.0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark11(-90.43886213203595,-0.2071529748077774,-94.33166165077724,-25.732077069374725 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark11(-90.56271996305216,-0.5635644461175662,0.0,59.66806370164606 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark11(-9.060484726783812,-0.1237077457632305,-185.3817835837372,-0.19186937974917906 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark11(-90.67563016427667,-0.07379791255308779,-0.0014618773534493385,12.426842880220107 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark11(-90.75447095615066,-1.031299249264643,-28.032688320094376,1.0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark11(-90.92054364608813,-0.5541921758751975,-39.61127242939446,-22.69314560852241 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark11(-90.99779512916294,-1.5707963267948912,-71.62613633402562,1.0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark11(-91.0248348250462,-1.0072725539554264,0.0,-2.0303534698525194E-115 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark11(-91.10970073554893,-1.2608646249979572,-77.35266304145145,-69.59021780164474 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark11(-9.114363788445665,-0.21469889642906725,-85.4516100840209,56.03671747578768 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark11(-91.2398199819759,-1.459384616907443,-1.9639454409086738,4.440892098500626E-16 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark11(-9.133054381098404,-2.560757343662681E-17,-0.8931091402944429,-1.0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark11(-91.35200992938607,-0.5412875042564309,-64.13902533839142,1.0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark11(-91.41148433938575,-97.16664160595899,0,0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark11(-91.52868524931526,-0.9106665668765963,14.456712548179638,86.18421398117819 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark11(-91.6088961407414,-1.5707963267948912,-53.2087981347972,-9.992491679981441 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark11(-91.64102799142543,-0.021880538043134175,-45.20433101681281,-90.02045754699859 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark11(-91.69687109952957,-0.9572037007192777,-13.393561745689993,-0.2401840219311695 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark11(-91.70218142481826,-0.026194831704251256,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark11(-91.70536820973551,-1.4597338648977747,-4.966531283876051,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark11(-91.78530793915016,-0.18774320512247744,-2.7755575615628914E-17,-1.0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark11(-91.78844325728457,-0.045313219532111926,-69.25021578953539,1.0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark11(-91.86177217319111,-0.38369596795731437,-7.09303974848963,-99.767034135372 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark11(-91.87329316200683,-1.3158942017468815,-65.40459669637235,100.0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark11(-91.8976086428574,-1.2806120130614238,-1.5707963267948966,0.06262923654175609 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark11(-91.92896664651332,-0.8010095936466048,-79.31773298086532,-0.6845601378226167 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark11(-9.193601421008005,-0.0035264491745493763,-4.503315120185333,0.029543344399207472 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark11(-92.07826948512155,-2.220446049250313E-16,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark11(-92.22551843814037,-1.5707963267948961,-0.1644662300109596,1.0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark11(-92.25717510416979,-1.5707963267948957,-1.1468653330979524,0.9999999999999964 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark11(-92.26111566896753,-0.8384472104457927,-46.57711578995594,4.139713429925337 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark11(-92.44561779072478,-1.5604140313658026,-1.570796326794897,-19.231271127999673 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark11(-92.45922894499972,-1.0585050891957775,-98.49294187588228,1.0000000240677953 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark11(-92.63484806966427,-1.2750545933806627,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark11(-92.65063770326944,-1.382638821309939,0.5706531217280106,-100.0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark11(-92.75114752290322,-0.527251201746162,-94.46310304777627,-1.0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark11(-92.9739960706117,-1.1473723346219156,-37.802126975813636,-0.04692081436975193 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark11(-93.00409261441847,-1.4562953264059608,-11.605173440110907,-0.6785409625964105 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark11(-9.314894425405303,-0.7266846497978654,-9.682658061587107,-0.9999999999999964 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark11(-93.15014495068468,-0.4141760277277037,-88.35712136552701,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark11(-93.19479630716748,-0.26619181051093577,-0.3344110518872788,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark11(-93.25281609871554,-0.19204085224570283,-0.24164244903836618,-0.025571868711207056 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark11(-93.33849867396655,0.036616500680354186,46.30564722853522,99.8971425106433 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark11(-93.4016229326343,-0.13822805149381046,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark11(-93.44741699238186,-1.5494431004053468,-57.08588621394366,-0.9422738531780196 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark11(-9.34481315722622,-1.1903033818687945,-62.641218792995446,-0.6565576410581677 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark11(-93.507361808312,-1.1668543478522135,-11.102038361665718,0.9999999999999999 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark11(-93.51704797879714,-0.16250028088911805,-13.97679946813733,-1.0000006061473083 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark11(-93.69656895362782,-0.09616779125853148,-100.0,0.030101299041537244 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark11(-93.7523404053655,-0.7551601519946878,-20.843906012165682,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark11(-93.92181752876617,-0.09248008931361458,-1.5707963267948966,-60.78881585285813 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark11(-93.98862541010315,-0.08418601575253593,-54.138930423735836,0.06227594963002923 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark11(-94.01406102871923,-0.4194926795402183,-0.8488105516515473,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark11(-9.406547439628378,-0.05877041079908568,-5.718116959900779,-94.49088696554632 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark11(-94.21563466057141,-0.1234607131714152,-38.795495842031336,0.5830521906904877 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark11(-94.27054594657987,-0.829969937212101,-44.768799568972184,0.0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark11(-94.55967870206185,-1.260619695421234,0.0,0.0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark11(-94.6278608927459,-0.9707078079369533,-55.06870315593715,-54.85495580628046 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark11(-94.78520995750662,-0.10959381016734948,-38.79760319984858,-1.0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark11(-94.78657502952389,-1.5705590772590974,-82.76033931262917,-1.0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark11(-94.93052030202834,-0.26065088500320943,-4.410625953950008,0.2292285363417914 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark11(-94.97296641370932,-0.19920659265349627,-71.50474133619156,0.9880188666945886 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark11(-94.98515532350129,-1.1963406215288135,-59.90621800260778,-1.0000007020043846 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark11(-94.98644009535806,-1.2844468358603631,6.997324521641407,31.678039630721564 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark11(-95.09208282454695,-1.3975361050613428,-37.42796638683221,-0.19442517847739949 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark11(-9.516896498784604,-0.4089735601617015,0.0,0.0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark11(-95.22958462357391,-0.5952790613034178,-53.77269866068265,-0.9999999999999998 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark11(-95.30904528388449,-0.6626675159986775,-41.66916186524385,2167.78742721682 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark11(-95.41822093953603,-1.5608189050977561,-100.0,1.0000058632506155 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark11(-95.51678675872215,-7.105427357601002E-15,-15.070503017817856,-0.9999999999999989 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark11(-95.56537858084133,-1.5707963267948948,-72.03010687406456,-0.6782095191859197 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark11(-95.60521865694967,-0.43514836002603263,0.0,-2181.0557875663562 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark11(-95.6719408772031,-0.8421242532105899,-0.6340175052710265,-0.9878615450028438 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark11(-95.68167787382302,-1.531039210288357,-15.949981827040311,16.166558609069142 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark11(-95.69115593646036,-0.28809409149419174,-2401.728690051739,0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark11(-95.79491469530343,-0.28990888188504016,0.04044989770961155,-0.0470845612612536 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark11(-95.82649200904699,-3.552713678800501E-15,-66.27608383893042,-1.0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark11(-95.83174609251765,-0.3574891789197565,-68.97237911425277,1.0384064787000369 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark11(-95.83981011100843,-0.836113879141315,-100.0,-0.2919566746895351 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark11(-95.86899352844573,-0.5998655705747367,-43.38515490829543,1.0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark11(-96.00964713854768,-1.4983046218078548,-85.64651160631277,-99.30020904469822 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark11(-96.0388585747454,-1.5707963267948948,-14.273484745127575,-0.8077981774641214 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark11(-96.10990927260063,-0.5321002146453735,-11.529352272574684,100.0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark11(-96.12371602979115,-1.5678265409856222,-1.1102230246251565E-16,48.718603804609245 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark11(-96.28880110227955,-0.0013868420558715844,-40.02465338506846,0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark11(-96.36149246572101,-0.4367626986371004,-51.86280092274066,4.810672273126479E-9 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark11(-96.37687970035148,-1.2814602637453585,-30.938279860263645,0.2955287681187906 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark11(-96.3958066918566,-0.9947352443516001,-0.04006078645946121,0.49013951330646205 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark11(-96.62537337740147,-1.1958935148131609,-45.127405692004686,-90.31193362725519 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark11(-96.63297343318867,-0.21951085504080245,-96.48748164706326,1.0000000000000009 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark11(-96.71943916092077,-0.1442215177502288,-1.1102230246251565E-16,-1.9424514403413555E-51 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark11(-96.78474390533052,-0.10842738965869492,-50.97753495159054,29.058179091635367 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark11(-96.8749583928304,-1.3238505769409823,-5.4931848380455985,-0.06704151561210381 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark11(-9.688397750480933,-1.5255125897868484,-1.5707963267948963,-0.43714623833686217 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark11(-9.692508818503775,-1.1515786295208557,-52.695020268276124,1.0 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark11(-96.9823500513324,-0.8695810084367093,-28.795331384200512,1.0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark11(-97.04200375609211,-1.0421867138415761,-19.367813363912575,-76.75860803153793 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark11(-97.17911572648268,-1.2337416636316332,-0.9356122420653167,0.06762796789204774 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark11(-97.18120789739253,-1.2092852217762928,-56.08190501929704,7.105427357601002E-15 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark11(-97.23954028583995,-0.3682559746552042,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark11(-97.24309321935556,-0.43069587028968875,1.2887068531964256,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark11(-97.24619992106875,-0.9243879711358673,-47.96834364581966,1.0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark11(-97.25487034296323,-0.7863820785367187,-50.12300040951716,0.773392826849153 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark11(-97.45758295988304,-0.4203624398246339,-1.5707963267948966,0.053411299545697705 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark11(-97.48941007979366,0.41327640956142087,64.12428721031743,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark11(-97.56872785557738,-0.47801029129669814,0.0,47.78456040687814 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark11(-97.63181834542861,-0.28125946996715157,-65.92423791514177,0.9234509516243414 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark11(-97.65381731511695,-1.4367447940465348,-80.702532186218,-0.6503268047922026 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark11(-9.766589292763316,-1.42024427722596,-23.58421997542303,-0.955505426729543 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark11(-97.73218345792385,-1.5707963267948912,-1.4799130522610788,1.0000000000000036 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark11(-97.7460953538597,-1.5528981190458133,0.0,-0.01220938683962635 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark11(-97.92414904934432,-1.0963424891260327,-44.98405761366384,-0.03733335178378128 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark11(-97.94973135325645,-0.35472462637322016,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark11(-97.99911172295182,-0.41441742351705096,-45.92586875028228,-38.836408267915324 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark11(-98.01780226011589,-0.14936507824455547,-1.5707963267948966,-0.9999999999999993 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark11(-98.21980727755843,-1.4647549986100838,-1.0646459660214909,1.0000040538354624 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark11(-98.23694679396031,-1.3291974939716595,-9.98364869598632,-1.8804256116405925E-15 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark11(-98.32584845830183,-0.13687840867877402,-72.03255581773445,6.747729946272668E-6 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark11(-9.835595602532194,-0.2198843323820583,1.3507849087148818,-62.81604792317425 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark11(-98.36042574803318,-0.6092878673577502,-15.619204209537372,-85.22751288872534 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark11(-98.45854646830648,-1.125487757930983,-81.56972148210365,-1.0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark11(-98.47800305711274,-0.035395831805631675,-100.0,0.06255257961922973 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark11(-98.48162394056497,-0.31738039604979806,0.0,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark11(-98.58902423815069,-0.001015803917118776,-26.574056986534714,1.8033161362862765E-130 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark11(-98.60110014304772,-1.252125604660968,-32.6113784761195,1712.5581368031612 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark11(-98.68743655338503,-0.08570736771642307,-61.502906206858384,0.9999999999999982 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark11(-98.73436301899895,6.443563184032379,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark11(-98.90622980708939,9.848346487223452,0,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark11(-98.92687363694435,-0.356421367689209,-0.30344355554114444,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark11(-98.94433358416039,-0.8939797280001778,-100.0,-65.90987710948461 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark11(-98.9710541863308,-0.00583221992435945,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark11(-98.99677591504826,0.5379504824135845,-1.5707963267948957,1.0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark11(-99.10919387437033,-1.5707963267948877,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark11(-99.15930790041523,-0.11092108084996134,-1.2430449487404965E-16,0.8296255838324158 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark11(-9.916610153675864,-0.8637242362238664,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark11(-99.22681326858438,-0.39721053188423633,-39.04642532656435,0.7415226844744183 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark11(-99.25649221310573,-0.9022802577478046,-1.5707963267949054,0.126910891382501 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark11(-99.4364312494787,-0.0011299883286386033,-22.78580329711851,1.0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark11(-99.45798045404935,-0.027785638201236196,-66.98216916987539,-1.0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark11(-99.4634800230286,-0.48515369624431415,-100.0,-100.0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark11(-99.57753927131152,-1.0629124695242516,-0.13836743672311436,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark11(-99.62242569750808,-0.3695134796509594,-78.45879682205248,12.562726613616162 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark11(-99.65751412830676,-1.5707963267948963,0.0,89.91345218518654 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark11(-99.7853031695998,-1.3566061829065639,-92.92680524866581,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark11(-99.85186775220953,-1.011750196208943,-1.5707963267948966,0.9435058928693252 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark11(-99.85403361432394,-2.7755575615628914E-17,-0.1353459973619116,-0.9855453945780658 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark11(-99.86798327913039,-1.5670736653906785,0.0,-37.24202777868254 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark11(-99.90574824371353,-0.11847873827228539,-19.41476620135133,0.8113525161271746 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark11(-99.91223069094026,-1.5707963267948912,-44.11641897153933,1.0158783329454397 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark11(-99.92360409446563,-1.1040569611684354,-86.86635741827317,0.4135574859175425 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark11(-99.93519917446302,-1.2687196268030687,0.0,0.03508381138016681 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark11(-99.99082789071973,-1.1602856436475488,-62.61456697488121,0.0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark11(-99.99308174062412,-1.5575262231707665,-1.5707963267948966,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark11(-99.99488444594483,-0.8927690177312172,-23.730159094351276,0.9687339730422238 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark11(-99.99627367488618,-0.044717592058758804,-2.041737460015864,-1.005355446867585 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark11(-99.9970988055019,-1.1764214729549414,-49.06975964247404,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark11(-99.99975552451622,-1.5707963267948957,-39.01047988493341,-1.0000000000000013 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark11(-99.99994634672579,-1.301166972293899,-89.38105221776405,-1.0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark11(-99.99999927609612,-0.47786726730385937,1.3020728826913412E-6,5.293955920339377E-23 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark11(-99.99999999999974,-1.570796326794894,-70.6874309888065,0.04806375939807765 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark11(-99.99999999999996,-0.5557786207034748,-66.99120948853272,1.0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark11(-99.99999999999999,-0.04612151184596423,-1.5707963267948966,0.0 ) ;
  }
}
