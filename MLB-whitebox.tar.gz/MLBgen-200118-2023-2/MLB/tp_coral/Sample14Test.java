import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(0,-0.28855044537041863,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(0,-1.3877787807814457E-17,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(0,14.485311257077,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark14(0,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark14(0,16.091610306802863,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark14(0,-16.102345423841328,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark14(0,-1.6335973309092822,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark14(0,-2702.067352754861,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark14(0,-2718.42208431695,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark14(0,-28.810145985799878,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark14(0,-4.930380657631324E-32,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark14(0,-57.66904075216448,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark14(0,-64.14689760460557,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark14(0,-79.40539362077948,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark14(0,84.02823379501666,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark14(0,-85.79903863798583,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark14(0,88.52651406253972,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark14(0,-96.36102610155908,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark14(0.9999999999999998,-1.143532853460803,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000002,-0.06814806938350321,-71.78354512375216,0.14213882433220704 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000018,-1.5491408152929258,-0.3374507427554338,0.06256692958928328 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000036,-1.5214313772597317,0.0,-1.3303196698961243E-6 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark14(-1.000000000000007,-0.5591221792380807,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark14(-1.000000000000007,-0.6328966214519123,0.0,-0.04608251741827593 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000142,-0.3560675555519792,-100.0,1.0000000114181475 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000142,-0.8684437308036805,-100.0,50.99736600490934 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000142,-1.2072552153721081,-59.87245779067216,0.06255624039501505 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000142,-7.105427357601002E-15,-79.6277797691704,-100.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.004959073780300681,-1.4546274679080258,1.0000013357067208 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.007158247225020629,-53.92317913324493,0.02194376701740222 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.007545916393905519,-0.937379937922409,-1.0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,0.009288672969566847,0.0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.015699218848467256,-4.66292594298122,-1.0000000000000036 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.023378885070452292,0.0,0.9047237286156296 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.04715764356331931,-16.972883637957096,0.36251642081493973 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.0578645884373401,-65.04799980347835,-1.0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.07512978893648528,-87.80532695039035,-0.03694332809915734 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.07717960466578366,-61.196122144071055,8.352389719038111E-53 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.09742520295089256,-25.514524818197096,-0.8691192394357655 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.09883002831864857,-100.0,-1.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.12499141782814638,-1.563980964647546,0.06733180702636829 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.129674764649783,-20.79888728457998,-0.061776811271462506 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.15002330385395624,-62.24886673607008,1.0000000000000004 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.1541030495707194,-100.0,0.9621244939882888 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.16598099926605414,-67.37159825307907,1.0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.1840518608828209,-1.5707963267948966,1.0000000000000002 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.19522161326707313,-59.57436106994651,0.0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.2133613185215441,-95.73847460071259,1.874471404454341E-16 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.21640459777561252,-8.851319057944961,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.22945385758443504,0.0,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.23098942505286038,-1.5707963267948966,-0.985946786465947 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.23919211082626646,-73.78395194597955,-73.4480384239214 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.26996812832430805,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.2733606791918637,-14.215249598293283,76.23187346928168 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.33608373199711566,-30.484198574929508,-1.0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3361309428896743,-1.5707963267948983,0.7950213347754436 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.33752213326594305,-15.423791389535353,-0.9999999999999929 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3447092690564475,-5.966652198652505,-0.01524524347257128 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.36314537631032745,-60.61786226223358,1.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.37070506193237796,-84.34286901967107,2.8866853410600135E-4 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3810963787613806,-111.97226662161978,1.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.38329901317807114,-44.69664724799849,0.13748775812246006 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3907476397091869,-66.747333318399,-0.3850176101284353 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4187763680940273,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.42218006830376714,-70.85960002229032,-0.010832397424873408 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4248505386061417,-54.41809563749685,-1.0003256134102838 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4716355276199889,-52.035126069101395,0.31664452270172366 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5235863014380929,-66.07922060072724,-16.609344940865583 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5341479771963726,-44.166386781624304,-0.015788736577091872 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5691632450325279,-67.07593863539219,1.0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5814666078691326,-1.5707963267948966,-1.00302610387842 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6190922279840423,-93.34880689892316,-1.0390145871138163 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6204666501253744,-1.5707963267948966,-4.286823992256333 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6413050207753962,-0.5134432865113869,1.0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.649752434252574,-46.27990441018085,-6.528020731882176 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6601159109009981,-0.766902506189956,-0.010414179118384697 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6604013535199289,-1.5707963267948875,0.9999999999999998 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6737594928597098,-78.84620905350121,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6801662071856397,-1.5707963267948966,35.83857315863434 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6873335623006251,-1.5707963267948966,-0.9470965683793701 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6902864528714069,-88.29680997576263,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7073923426466195,-40.06224543555774,8.673617379884035E-19 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7266400853248285,-32.374762651369856,-0.9999999999999991 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7717291413115402,-84.36178521196678,10.436249775384717 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7968412419581946,-45.50680465299164,1.0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7990423940164697,-100.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8241858999264977,-1.5154927735087051,5.421010862427522E-20 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8556117582635352,0.0,0.0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8588164759841822,-1.406073594497708,1.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8621979032430628,-66.08610325038993,-1.0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8670674899520866,-42.966831108085636,7.832972755233726E-15 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9341374318839482,-8.28460461531646,-51.3596503009791 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9448451421010216,-77.43396771391082,-0.033198227686016143 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9474378970199546,-95.8115340833517,-0.27891178745515244 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9530516299035687,-96.2687864428992,-1.0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.954293077373094,-0.8614831632411324,-0.050884410082678196 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9799015685462269,-35.87545585922112,82.38637073792336 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9805528410072958,-1.5707963267948974,0.033930404509642145 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9900681495218568,-94.28771843672534,-67.07969004647968 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.015949338188253,0.0,-0.8819887294638402 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0303901567156828,-45.0035303991049,0.1626490722448466 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0388699311956169,-31.930027562319523,-0.06475365730401965 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0448037319495451,-39.25015153329625,-27.25106599587852 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0486051804923664,-32.39987392286494,-0.06255362569789215 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0714422576768814,-93.3386350684094,-0.6532319536770146 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0929018142441727,-26.91469712463845,0.4358987086505952 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1090682892892398,-42.92070031042874,48.02236045970565 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1166813157067885,-7.355874371937458,-3.4211388289180104E-49 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1393101354097321,-27.63743961187987,-1.0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1539058948385439,-1.5707963267948966,-1.0000646875534263 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1594936932517574,-0.09405359820936925,-0.34767841203553584 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1950800436793143,-1.0162508235653718,2.0303534698525194E-115 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1951885765577241,-78.47233464512095,13.771512862986683 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2207241167364573,0,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.223742865518256,-78.58308060907197,0.011064028103104279 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2302621544297696,-72.34811459802887,-1.0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.266031118742838,-1.5707963267949019,5.207347310528621 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.308329319436217,-32.74343269836237,0.0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3297211850298665,-1.5707963267948966,-41.95892643795223 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3339615452360576,-1.5707963267948966,-17.54066908843154 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.340275160372253,-89.37753443181096,-1.0000000000000004 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3419365896167659,-94.27414985489743,14.271750060385799 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3530008911240123,-53.86822708791529,-0.05210622343237514 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3592921080553582,-31.738363415726614,-0.8785500912074354 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3656758711299959,-1.5707963267948983,82.0616645654832 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.382923030227,-10.766429693086575,65.61501183241471 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3874367051249323,-88.36763061034661,0.04228208757758704 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3902594159087713,-6.721511540282651E-4,-8.78169786428207 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3933564348319507,-2.6236083752580157,1.000000000000135 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.411056767253845,-20.48338988281138,-0.5951882499426404 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4204185257769684,-25.89256520092438,0.9548066159210898 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.426639275087291,-67.1840890661679,24.73364939331647 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4309257663416213,-10.77473837243356,1.0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4339344661275573,-8.260412734027442,0.0625525625678494 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4808540789753957,6.43150691820835,0.0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4854690890573468,-97.98594348466744,-1.0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4978407538637923,-3.1548250066955887,1.0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5034808761594007,-10.850226813134341,-0.9732361499182003 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.507133521743114,-0.9826662969535807,31.494623479483266 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5133505523665516,-67.06424984563097,2.618194064541157 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.517424068631868,-36.34840992539227,11.448938141486655 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.531344972136682,-52.087332806725556,-0.04651866043108743 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5379509056975849,0.0,-1.0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5486569249693096,-92.66870085536897,1.0000008222021897 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5497669831506746,-28.072591366386508,0.04054054647528427 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5594942159966103,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5618791913750911,-96.35430302622996,1.0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5630553038953638,-20.31095891502335,1.0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5675429463074777,-7.474516207038034,-1.0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.570576547156831,-1.7221399138257385,0.0625525863820464 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5706590137557284,-6.694138824889613,-0.5292635746257431 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707613216479308,-3.713259074670028,6.776263578034403E-21 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267944924,-73.61130691442816,-11.192686544894784 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948668,-49.75377560574414,0.9999999999999996 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948764,-74.01735340901331,0.006145570791730184 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948841,-8.843381248222682,-1.0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948877,-100.0,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948897,0.0,-1.0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948906,0.0,-1.0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,0.0,-1.0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-34.46544733504335,-1.0000011420451793 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-41.72144473503461,-100.0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-49.53294878173533,-35.885529416878796 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-66.00699944710567,-35.101969775451806 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-67.89913502822398,-1.0000001826330995 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.57079632679489,-25.16471357097261,0.9471910516545294 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,-0.5379452208714065,-100.0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,-1.5707963267948966,-0.45916351570289393 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,-9.96664334928849,1.0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark14(100.0,-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948961,-100.0,0.8636795955459138 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948961,-1.5332850707362637,-1.0000000213498164 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948961,-7.34644065317877,-0.0039298795613215975 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948961,-96.14922841353427,-2.1124484651199916E-8 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.570796326794896,-78.62784663803669,-4.333103110428259E-16 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-2.220446049250313E-16,-63.931223620023125,-1.000015450181926 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-3.0546438657368817E-13,-100.0,-0.8831801231031591 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-4.440892098500626E-16,-10.993825047855594,-1.0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-5.551115123125783E-17,-1.5707963267948966,1.0000000857192135 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-6.773193553721004E-14,-1.5707963267948966,13.540372771580428 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-8.881784197001252E-16,-25.732620724063786,1.0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark14(-10.020248028835029,-1.5707963267948948,-7.966749002782661,2.6662107088087375 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark14(-100.32317434094125,-0.15895446621585022,-49.41166758847506,-0.06256797325028843 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark14(-100.43402719135896,-1.5494432739563855,-45.191163351727056,-2149.4199645939966 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark14(-100.52905105549151,-0.5099575575371205,-132.89160860652902,0.9998723807545006 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark14(1.0,-0.7578230980061972,0,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark14(-1.0123214207389688,-0.7363078392431319,0.0,-91.65402053459832 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark14(-1.0,-1.3139983207238253,0,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark14(-101.99263506452894,-1.1332352603603562,-53.18591534762243,0.4738531642432271 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark14(-10.204147094024538,-0.5241855398343824,-37.822882818942816,0.11521978239179587 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark14(-10.211079159324896,-0.7782901772084836,-100.0,2326.137199498858 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark14(-10.242482522183462,-0.35527832327625863,-1.5707963267948966,13.347725027094516 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark14(-10.256269659926673,-0.4097289280709202,-1.5707963267948983,15.431228325917573 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark14(-1.0374658393541734,-0.7317705399296524,-72.3910898074769,-0.9999999999999996 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark14(-104.65970514250472,-1.3354280818493651,-44.44434457884381,-0.06395970220229685 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark14(-10.486980167083093,-0.00830888598966189,-6.945578284143852,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark14(-10.587059582612511,-0.2782214586007109,-89.71854914424603,11.154470287572309 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark14(-10.59460491009969,-1.5707963267948948,-33.0862324397888,0.818439954432711 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark14(-10.654876934783678,-0.008189597988422774,-45.52107554407511,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark14(-10.67807150444034,-0.07839123272958681,-88.34645961809055,-1.0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark14(-1.0834005003318627,-1.5085674023595046,-20.419504616937957,-0.8355572319135673 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark14(-1.085369299396172,-0.9704960474764041,-4.426146185670078,-73.68511900536146 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark14(-108.59204282407381,-0.505019629272105,-95.3706316811972,2273.758324926762 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark14(-10.910671815965339,-1.2248639407295379,-11.748551301126113,-0.3006149689590887 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark14(-1.0913318260188039,-1.0010867038242472,-31.29589376654779,43.23915063479536 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark14(-109.5894475637835,-0.2554945071677821,-53.908079305306984,-94.4525429216553 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark14(-10.981730631614742,-0.7169280240430812,-93.81543533335486,-0.9999999999999998 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark14(-1.1006578400077518,-1.0298001139367083,-24.220520415652658,0.0387050340519032 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark14(-110.07053203643764,-1.307568467458403,-164.68997430969858,-1.0000079386906124 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark14(-11.085638842462526,-1.9968806036668216E-18,-100.0,0.06255253177666899 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark14(-11.13064943075279,-1.3868175265753633,-39.4784706690384,-0.43134391068952005 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark14(-111.65835714029976,-0.3792774799237151,-36.52447963062373,3.2035087283242305 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark14(-1.1193003187260853,-1.5707963267948963,-51.98795255827448,44.46221892322353 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark14(-11.256124081497907,-0.9982319508228241,0.0,-37.26999298103643 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark14(-11.310630785062475,-1.2907015869315677,-24.795927230942723,-1.0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark14(-1.131465178490015,-0.45109439621852226,-44.01571669461817,-0.6496226832721119 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark14(-11.31645344878092,-0.9168431876539636,-38.921714591344305,1.0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark14(-11.394520292137504,-1.5707963267948948,-1.5707963267948983,32.53523020376659 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark14(-11.419176933203062,-1.5707963267948948,-85.48601892189427,-47.9763508168114 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark14(-11.421672613335334,-1.430927668408347,-34.598571692415106,0.0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark14(-114.89425817398904,-1.3946663172265077,-10.76164817139179,-0.9999999999999862 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark14(-11.501283865436427,-1.5707963267948912,-1.3284413405413744,-1.0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark14(-11.50923241882219,-1.5707963267948912,-73.77573465160707,-2174.575018177506 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark14(-11.521058296576982,-1.363017917552397,-17.50310212634259,-1.0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark14(-11.574026264223223,-1.445171708537327,-51.290883825008805,-1.0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark14(-116.02800066417703,-0.18373880566915163,-1.4202484099726806,2104.3389900301136 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark14(-11.630423070417558,-1.4982486580971277,-38.76845212684093,-0.28181009244930766 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark14(-117.06673844703612,-0.6015570748915279,-3.4854069704776194,-2284.0429546972405 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark14(-11.710481181587932,-0.03219993912078288,0.0,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark14(-11.769225288553542,-0.3242195173990874,-42.693858450196075,2311.4004459502517 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark14(-11.826028423874927,-1.2947991502039489,-65.15834143949192,-79.89453159304618 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark14(-11.957968135098959,-0.41137737009310454,-88.72001100812666,-1.0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark14(-120.34737260958389,-0.010411127981839116,-92.06516215868268,-70.64699042089391 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark14(-1.2131995083902325,-1.5707963267948948,-58.26201511910562,-100.0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark14(-122.3178525428844,-1.5162329558282872,0.0,-38.43648904834935 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark14(-122.40050694706224,-0.5956053593533386,-0.41746525477587426,-2028.463586041653 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark14(-12.288558944033085,-1.5504545943604917,0.0,-1.0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark14(-12.319488285954577,-0.8269879559188986,-33.47987297509777,-1.0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark14(-1.2322535565929336,-1.1852754733836117,-88.26350953398219,-0.9665315072251996 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark14(-12.342773295015618,-0.0217652653840547,-88.84202418459456,12.314264548342125 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark14(-12.445113738201671,-0.5545310728561494,-1.264704361904473,-0.06255784882780084 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark14(-124.45845278387111,-0.8401438693107508,-38.92009109370409,2034.7281259481447 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark14(-12.493057484392287,-0.4429026662837714,-162.64255683663978,0.36645297611970745 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark14(-12.50873261147241,-0.5661722299080223,-24.073388049511713,-0.36906499662875514 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark14(-12.522640672982595,-1.4067321531649863,-0.43338917918063297,-42.22381844550522 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark14(-12.52725851867428,-0.6114136622322754,-4.476995933179725,-82.5612278704138 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark14(-12.576051071937414,-1.5194890978962805,-7.105427357601002E-15,2257.34460986529 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark14(-12.925695671735525,-1.3459605133059243,-55.107970373519954,19.6413828707285 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark14(-12.94078526601209,-7.118265644939059E-15,-45.36852460683142,0.01092159798175607 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark14(-12.951117181609371,-1.5707963267948963,-78.9548121682501,0.07815083283377788 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark14(-12.975147316893677,-1.5707963267948963,-15.278956558760255,2.4079081553714653E-6 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark14(-130.4734692158801,-1.5707963267948912,-3.243331125812162,-9.70308363763715 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark14(-130.51437732112615,-1.490792223304041,-100.99971048871576,-1.0852010471662055E-5 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark14(-130.52020129625367,-1.2910627461139441,-3.2036287732047555,0.0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark14(-1.3060102176841564,-0.8880107946620506,-0.7514107310497558,-1.0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark14(-1.3148931727441335,-0.8487662105344447,-60.519779123612125,1.0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark14(-13.20658183578702,-0.7654997369904155,0.0,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark14(-1.3207441051502826,-1.4684125228758305,-15.059895445172915,1.0000000000000036 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark14(-133.00563357774138,-1.555121147104731,-136.50641607767184,-0.7683702020915211 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark14(-13.321488077940046,-0.24410282066884825,-3.2091088466289293,0.9812994730600444 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark14(-13.32305098703666,-1.5707963267948963,-1.5707963267948968,-1.0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark14(-13.328370452537818,-0.27645005927857014,-51.397826497022024,0.9995542387344427 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark14(-13.362747244531146,-0.9107967507703557,-96.97896300056948,0.5542183686359934 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark14(-1.3379200174010863,-0.5870850663950349,-88.30447873603123,1.0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark14(-1.350285460868447,-1.3448296454895197,-61.67682291343604,1.0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark14(-13.562486150782219,-0.5175562548588513,-1.5707963267948966,-0.8934158323328664 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark14(-13.581176756649072,-1.1026752204147368,-21.074649557217413,1.0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark14(-137.65179671311824,-0.8615829526824541,-68.4831372286738,1.0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark14(-13.785783935032182,-0.1442643475217007,-0.30710837737883734,-1.0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark14(-13.945239479330349,-1.5707963267948926,0.0,2.8853058180580424E-129 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark14(-13.992412884882807,-1.1109127291011325,1.5707963282185882,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark14(-1.4028905131712124,-1.5707963267948963,14.442338402529252,0.0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark14(-14.06132097370028,-1.5707963267948948,0.0,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark14(-14.083043196818583,-0.16503649349588748,-8.26289458473486,1.0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark14(-14.096261555271596,-1.5707963267948948,-24.40031447035615,0.0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark14(-14.163830786867024,-1.0281653780300766,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark14(-14.209282005467657,-0.43288441361073327,-28.833659394646073,0.05348758124873934 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark14(-14.342286051729133,-0.030809965051631638,-64.01335951145326,14.443065526959785 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark14(-14.382737809912683,-0.05274388007880759,-67.37631489442538,37.92237903288134 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark14(-14.416820913541617,-0.5945993203532329,-71.52343856823516,-20.86341430483089 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark14(-14.467851714097321,-0.9508893706085928,-10.68563502336437,88.77884616105521 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark14(-14.711539968883644,-0.20601357671479303,-72.67346647757354,-0.8150742527223581 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark14(-14.866927870664554,-0.13051720805011602,0.0,2.710505431213761E-20 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark14(-14.881976320784819,-0.8634263658216045,-13.992690784457878,1.0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark14(-14.965345679971975,-1.16668872370748,-59.00647817928001,-0.17277490472856982 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark14(-14.96963592469654,-0.826281177873194,-50.22470124820019,-1.0000000647283964 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark14(-14.971294986038535,-0.00618116094334023,-1.5707963267948983,-0.0625525585778744 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark14(-149.8938851527238,-1.07961533636787,0.0,-73.73665000564694 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark14(-1.5002635189968245,-1.5707963267948912,-10.465547168635585,0.2606177063496308 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark14(-1.5020448574383687,-0.877111592790112,-77.77986710740335,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark14(-15.032810584943899,-1.3135265474422044,-52.29437698707483,-1.0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark14(-15.056317619477404,-0.44752756648582426,-67.1262663824629,27.998690449490024 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark14(-15.10104730046756,-0.02337140147470211,-0.5618199247334279,-58.625787968049224 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark14(-151.65267336460678,-0.3251932248185305,-1.5707963267948966,87.1451312441564 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark14(-15.172262715423384,-1.5296675652654625,-37.74958858904203,1.0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark14(-151.86436936879437,-1.1157792990031647,-1.5707963267948966,-2189.747323368739 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark14(-15.37142837045433,-0.6092685306938123,-69.62611696654956,0.7817627138019972 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark14(-15.485741994744828,-1.3600984557622298,0.0,-0.5771175119801646 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark14(-15.51548681914375,-1.0159158695064772,-30.867876417232253,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark14(-15.583321080041571,-0.7924550687830765,-22.980349166421647,-90.9830212537563 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark14(-15.603742444852696,-4.440892098500626E-16,-1.1102230246251565E-16,-93.96052920084692 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark14(-1.5615900908445326,-0.642987046806115,-60.8675686667578,0.182044748235052 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark14(-156.29723371050875,-1.5580937744845036,-33.93564608483106,2094.118027062963 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark14(-156.3088774744146,-0.6215065924158694,-59.94333641141401,67.84461759252261 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark14(-15.686987710194032,-1.153610612731131,-9.825235726291808,-1.0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark14(-157.09121516572563,-1.5107000755273623,-46.628309232189594,-1.0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark14(-15.726980934648111,-0.4262438418045911,-38.59519051859634,-37.88709874722353 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark14(-15.766714778423383,-1.3996423235731852,-60.03281284900424,0.9503495309938587 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark14(-15.898159805841969,-1.5707963267948957,-51.68744255712474,1.0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark14(-1.5902689424120169,-1.5707963267948963,-66.50773720319495,-45.98159375227655 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark14(-15.93903573390619,-0.498212472997575,-0.557723417085267,0.9585543942649528 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark14(-15.964116579211387,-0.06795324185797896,-44.71843677827502,-27.49954751937695 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark14(-15.974908546961199,-0.9309270091670112,-131.5622035891215,0.055244668310625855 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark14(-15.99256894239533,-0.06753719496158665,14.431960825775775,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark14(-16.107504704309285,-1.570796326794896,-50.59370551798718,1.0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark14(-16.119779014235796,-0.2922739774921155,-9.050850094364776,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark14(-16.241881382620285,-0.5338667650703786,-46.415667204823954,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark14(-16.308704670171892,-0.6851415827032195,-84.76808561738089,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark14(-16.329330382221627,-0.3543802909514824,-191.10936077595363,-0.5566547571340017 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark14(-16.389054248576045,-1.5707963267948912,-28.35276100869821,98.78309588728047 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark14(-16.522398179399776,-0.04715493508688384,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark14(-165.32715769751428,-0.10662152436371741,-0.623371903388735,-85.11504621978966 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark14(-165.47581917218025,-1.3309999516404947,-317.80133782153507,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark14(-16.593026313226265,-1.0081171548127845,-42.40480205540855,0.8505808157753165 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark14(-16.669087390875966,-7.105427357601002E-15,-55.36504550135985,0.0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark14(-16.738637988749396,-1.5707963267948963,-20.567685476778053,-47.630170473533305 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark14(-16.832919577303887,-0.4566210410989786,-58.34026513537902,-1.0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark14(-16.865570752647358,-1.25241002674856,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark14(-16.965788764933748,-1.5230954975902478,-4.355843298722917,1.0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark14(-1.6975308375079468,-1.5587437233633905,0.0,5.967879125153702E-17 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark14(-17.10949074188686,-0.5853503377208256,-86.92373353181037,-25.261096695531876 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark14(-17.259743094217104,-1.3413265389141853,-6.076066137796403,-0.7486440190668848 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark14(-17.281123071566828,-7.25101595064698E-15,-61.81345031786628,1.0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark14(-17.286393734407262,-0.5968611171191469,-37.92757178077341,91.43140134355417 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark14(-17.32119616491187,-0.5554597568925834,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark14(-17.390553153589643,-0.5264490335036105,-86.97480963302414,-0.5631092082589184 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark14(-1.7448887127508925,-0.1574176908502558,-31.05529949216934,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark14(-174.68024819797745,-1.5323808101270426,-77.49849889731543,0.3750011254151775 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark14(-175.55607253088485,-1.5707963267948593,-19.32442155485485,2259.122268283488 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark14(-17.709450052614194,-1.570796326794893,-81.34993305011061,1.0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark14(-17.7191018596092,-0.041551422116109626,-53.678056224170696,31.348754114238616 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark14(-177.55565413295565,-1.3347248296752399,-80.25950227856201,34.533991631491546 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark14(-17.941458557810172,-1.5707963267948961,-43.677689983652975,0.26640964297031533 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark14(-17.957346154032383,-0.36125396596051285,-45.727779710128615,0.0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark14(-17.974864274715944,-1.3476757621382642,-100.0,32.49171899539412 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark14(-18.007270221546268,-0.5049806025244566,-1.5707963267948966,8.673617379884035E-19 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark14(-18.01166599409767,-0.38154213836537565,-9.45761263581545,0.9892462474353927 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark14(-180.37795677042632,-0.28631169104436316,0.0,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark14(-18.06012262129996,-1.5707963267948948,-59.5185826322757,-0.7846129876234702 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark14(-18.140200770747256,-0.03725022912981571,-55.509538677088564,-0.9417006379955215 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark14(-18.174442027769643,-1.120872258177719,-39.52559954020304,1.0000000000000329 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark14(-181.80654256506853,-0.023011777101490053,-32.54646114479854,118.36787598162039 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark14(-18.208108085014857,-0.7978023926305802,-67.9278041931746,8.881784197001252E-16 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark14(-18.242725734005436,-1.1197799292306625E-15,-72.70263638121006,-0.9999999999999928 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark14(-18.298437757480542,-1.5707963267948912,-92.26568126268153,62.65207566415265 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark14(-18.35196351531512,-1.5707963267948912,-15.560577805083895,1.0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark14(-183.69570880244504,-1.421047525749896,-31.737156836454236,0.0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark14(-18.389745212750253,-0.6794971215447703,-37.88349951732074,1.0238190612160314 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark14(-1.8473925858930955,-0.007039630385485875,0.0,-0.03459970593688622 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark14(-18.48292601803938,-0.033166955150322,-66.17786321227001,-0.40738479535635536 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark14(-1.8536182935894274,-1.5707963267948952,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark14(-18.58169593118724,-1.0173627462948254,-31.635371238503048,-0.08954072174225836 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark14(-18.586707327734672,-0.4914155576386191,-67.03243665911589,-0.8767172752816401 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark14(-18.598613533576625,-0.3670972982888058,-69.15053352651732,60.98131860057828 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark14(18.6028107699522,-52.221447025935475,0,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark14(-18.61243318095607,-1.5636236330300004,-100.0,-4.58206912711534E-4 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark14(-18.686081043546803,-0.3340771034380925,-98.02932867473461,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark14(-18.75452966673926,-0.11509190053326956,-18.18806479765162,0.05431167089840054 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark14(-18.763510423445876,-3.469446951953614E-18,-29.94854329756442,0.04513960191265784 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark14(-18.792319149073656,-1.550241129314012,0.0,-1.0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark14(-18.820758728339296,-1.5707963267948963,-1.5670292845107177,0.321563574510664 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark14(-18.855072400132798,-1.26793245371408,-1.5707963267948966,2.902310456169861 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark14(-18.901982971877946,-0.0139954866482155,-56.17715373271073,1.0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark14(-18.903769377401492,-0.8535709425006615,-4.678612495927793,43.35611635748319 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark14(-18.93229654754537,-0.5921185739829209,-63.649816798406974,0.5432111006510035 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark14(-18.94163574928566,-9.305503660208539E-16,-1.5707963267948966,0.052846974995528484 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark14(-18.985617916972913,-0.3322101175588563,-24.487212951692726,-1.0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark14(-18.988806395789577,-1.5707963267948963,-39.68074983208779,-1.0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark14(-19.00761866614498,-0.4422698647902959,-8.15436670813663,-1.0000000000000002 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark14(-19.105222928681485,-1.3374793176571327,-41.55841776833717,-4.138953807690804 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark14(-19.139877205953628,-1.0070331347700407,-26.374019185521774,-1.3234889800848443E-23 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark14(-19.19812122499706,-0.14755277718803853,-92.48215290596106,-0.9203818317817697 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark14(-19.239336341792363,-0.4030808445712251,-56.68967692681228,0.0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark14(-19.26289297305108,-0.7525727682740859,-102.02771048591484,-0.03578113353138079 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark14(-19.378459711919223,-1.0732973164465711,-85.76430283850642,-1.0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark14(-19.383793271967207,-0.9518897579310173,-1.5707963267948966,-0.03642948936373888 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark14(-19.45549989796018,-1.5707963267948895,0,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark14(-19.52240730143538,-0.01086595487507042,-0.013672767680991712,-31.300067668902997 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark14(-19.530742817456705,-0.27337583342632055,2.7755575615628914E-17,-1904.9551247153902 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark14(-19.557083346020335,-1.5707963267940386,-73.80135636627531,57.62566792896135 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark14(-19.57106650135615,-0.7742882824737105,-37.518918707572674,-0.041221501232587845 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark14(-19.722224612715124,-0.9241456700908316,-17.400764167247807,0.9999999999999998 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark14(-19.791744203213426,-0.7419252235363549,-67.10024572260295,-0.8054476844495309 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark14(-19.88400316167352,-0.878941081686409,-1.5707963267948983,-4.7758976230330035 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark14(-1.989168732434564,-1.0599759316133177,-20.343658029625416,1.3903253818259491 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark14(-20.064551891133096,-0.049427281174007076,-0.09973335575377087,42.51555519482372 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark14(-20.120707641145138,-0.5642375301423992,-37.741973756518014,100.0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark14(-20.166787054242548,-0.16763625300816898,-14.86029058544485,-5.103447714491935 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark14(-20.18742010598696,-1.2415875940633754,-8.440420529422445,-78.84071791291885 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark14(-20.20625163148553,-0.8473747551266113,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark14(-20.221849800343218,-1.5707963267948948,-26.150645373200014,1.0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark14(-20.240679071012107,-0.03963512190438751,-0.035969029636709636,1.0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark14(-2.0256984857512066,-2.1424962380302607E-4,-56.02610747058805,0.9055679643783509 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark14(-20.301833722956783,-0.8965235356483137,-5.21288172428569,-1.0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark14(-2.0309764878265653,-7.105427357601002E-15,-34.269179079322655,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark14(-2.0383919996564424,-0.27231027971456073,-14.465516210329996,-1.0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark14(-20.441309032338822,-0.6362051998187708,-41.83760589803774,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark14(-20.455855931542718,-0.7307337403429465,-60.14577769675058,85.29707334309461 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark14(-20.47082776625868,-1.3936236453609752,-31.970009146053528,84.94864524504845 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark14(-20.519375176101963,-1.7085482419197952E-15,-28.754610819159858,0.05046758462240396 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark14(-20.529684720814632,-0.040714813188628796,0.0,-0.9999999999999996 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark14(-20.53828168132579,-1.5707963267948912,-95.54565699342226,0.41901074865581533 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark14(-2.055609267621069,-1.387296893108132,-36.52999177501153,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark14(-20.558421232310078,-0.6419918582249764,-74.70601470960322,88.36990270064763 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark14(-2.059252010441554,-1.197722536938869,-72.32838817027896,-24.04098027376294 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark14(-20.600020048472487,-1.203000386114411,-71.84127885223546,-35.862899211859656 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark14(-20.664123689893266,-1.471979877334412,-9.589719603682617,1.5777218104420236E-30 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark14(-20.794604083170668,-0.7118404073936156,-80.03808469579768,-1.0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark14(-20.8269137553472,-1.3146182937063315,-1.5707963267948983,-46.49223442763361 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark14(-20.8340787604222,-1.029825356799364,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark14(-20.835879270168487,-0.13309398042832754,-73.49454426169825,1.0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark14(-20.901764789135832,-1.5553509099887557,-100.0,-44.90326627822364 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark14(-20.9703110853282,-1.5333470360693628,0.0,-0.0625526000790714 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark14(-21.026009020939853,-1.0646890808322953,-4.3750749307583945,72.18901850678209 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark14(-21.03847683797935,-1.0773479948206823,-21.11151395413073,-4.1359030627651384E-25 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark14(-21.06977537953126,-0.1921830363304462,-1.5707963267948966,0.892979922090643 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark14(-21.073979485485903,-1.5067082554674345,-15.557363178825014,1.0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark14(-21.179523590112446,-0.7959846712735157,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark14(-21.28612479714126,-1.1952401179328276,-20.36316494774561,-1.0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark14(-21.451489073291896,-0.3553117369140022,0.0,0.11983521756214621 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark14(-2.1479080107866046,-0.8945955703492464,-0.22751626420199544,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark14(-2.152575762513078,-0.3888212827367683,-52.04258773432309,-0.362095042012485 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark14(-21.58142590919768,-0.14430701682878758,-2.743667430174621,1.0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark14(-21.6421252824327,-1.5707963267948948,-123.62753232338287,-51.97461997391628 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark14(-21.659404264953828,-0.15590651867289723,0,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark14(-21.65958007560937,-1.1668087951610162,0.0,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark14(-21.955867900473216,-0.6992474598274867,-100.77484714067162,-21.43213864338665 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark14(-21.96110842004158,-1.3762812517144027,-4.321265252121776,0.03464860307931658 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark14(-21.961307498986756,-0.27431171814032873,0.0,0.999999999999988 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark14(-22.065647161397877,-0.7784244848243179,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark14(-22.096778455172007,-1.2183345348572003,-0.2744046031639352,-0.04524573547805523 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark14(-22.26874402923364,-0.3345705103178142,-1.5707963267948983,32.77029889418988 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark14(-222.90445950980666,-0.8305258475205051,-68.64405494251343,2234.4282153564013 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark14(-22.317000872467375,-0.07921171967844909,-1.5707963267948983,0.9245873814433043 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark14(-22.359484391906314,-0.33302202911795487,-35.04640217634925,38.70275393017613 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark14(-22.40432563937349,-0.7112894929791438,-64.50831124280982,-20.871321070030074 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark14(-22.566503858286673,-1.566573124576111,-86.30975226601059,1.0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark14(-2.2576926533711656,-1.526308198756806,-45.38737205654137,-2.3206567879773417 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark14(-22.67287881606908,-1.379043555677508,-10.96275833678854,-55.36514214118585 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark14(-22.71651800279794,-1.5161972179493355,-65.01477439359098,-0.009057416622069048 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark14(-22.75117196647263,-1.562158808353896,-40.04462538317459,76.19373650123723 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark14(-22.767243527276534,-1.2434875217059744,-1.797744564687818,1.0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark14(-2.278993893531109,-0.3369160327784616,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark14(-22.808327209775406,-0.021107104321629242,-45.71740264274896,1.0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark14(-22.8152365562528,-0.6816121564167161,0.0,1.0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark14(-22.818779316056915,-1.515984786675705,-90.50133915907817,0.009235900003532914 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark14(-22.824457283384902,-1.5067033705639252,-100.0,-8.686534134163434E-6 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark14(-22.909543914903807,-1.5707963267948912,-9.791682595914011,93.80479785511119 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark14(-22.92408707453045,-1.4105583166281543,-42.0339869800457,-1.0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark14(-2.293858138830931,-1.4709031889443904,-1.5707963267948966,0.4070246705050978 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark14(-23.067424239405387,-1.0260980509581472,-1.5707963267948966,0.9999999999999964 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark14(-23.074505567661074,-8.881784197001252E-16,-21.60607203773435,0.6277411116131343 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark14(-23.116376853458533,-0.05034695688967483,-67.77200387702956,-0.5087086552572089 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark14(-23.140820459901928,-3.552713678800501E-15,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark14(-23.172139985072278,-1.5700503362314928,-1.5707963267948961,-0.03508923045564527 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark14(-23.21561050032418,-1.5707963267948948,-8.446806160578035,-0.39151296592584073 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark14(-23.219197552268117,-0.537427519764976,-28.110750382779994,2151.9823105599908 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark14(-23.314102284966275,-1.5707963267948948,-70.68058361361113,7.227245172558909 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark14(-23.35040030540089,-1.132059985272164,-78.14691205681493,-25.379992251419093 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark14(-23.367773889046106,-1.5707963267948957,-46.29163067818835,0.9999999999999991 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark14(-23.418293113055604,-0.8662178130881887,-33.599751616215954,-0.050197338816205896 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark14(-23.51088864402802,-1.5289091268900226,-33.72574108780747,-1.0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark14(-23.761411686310165,-0.09128873111421848,-58.52705074398785,1.0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark14(-23.790190725321345,-0.748542186588349,-53.87240103379887,0.2009011455163915 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark14(-23.80452899135497,-1.7763568394002505E-15,-59.06009903347218,65.01324553880869 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark14(-23.831613039437286,-0.09020210577202903,-66.54165681482233,1.0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark14(-23.84394409210971,-0.6570207849307781,-15.955931230748623,1.0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark14(-23.846106732007584,-0.8373293399506867,-61.64046504344536,1.0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark14(-23.884556615371448,-1.4798876585741103,-0.728303157631361,1.0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark14(-23.88739134353864,-0.3690836910123041,-38.81682864420595,0.5714841090197669 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark14(-23.937659239693055,-1.193911174426631,-0.8083203785276905,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark14(-23.960049765702653,-1.1732378658007363,-3.552713678800501E-15,72.11934946519827 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark14(24.14248929988867,-0.9929901584207887,0,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark14(-24.23442249988679,-0.9962474749331126,-0.6707543220031247,1.0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark14(-24.238689937628024,-1.4302142586778759,-1.5707963267948966,52.027497440090734 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark14(-24.252471773293518,-0.6314709567135341,-0.26430929203318065,-13.321004736401555 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark14(-24.279616294501064,-1.2480065206543411,-1.5707963267948968,-59.11075520103463 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark14(-24.297749282546082,-1.5707963267948963,-95.30354908436529,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark14(-24.302658581100044,-0.7512542591572456,-100.0,-1.0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark14(-2.432768765230975,-0.6627876086354229,-1.6782602332673662,16.099178626623555 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark14(-24.330716030620156,-1.3058685579140565,0,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark14(-24.36995926433198,-1.012583448408222,-0.15717179451453045,-60.12532641149626 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark14(-24.395819096245667,-1.5076589608716366,0.0,0.6478162801327593 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark14(-244.1448316078205,-1.2048082568998337,-29.675133069633677,-2155.8933332858824 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark14(-24.52302819696599,-0.6610162624651127,0.0,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark14(-24.597104054078656,-0.04923039319882977,-1.5707963267948966,2165.039207814721 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark14(-24.607374417914926,-1.5542465540064665,-36.15654470049952,-62.35111247230822 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark14(-24.725402511586715,-0.27209157621921426,-1.5707963267948966,-0.8314734332604667 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark14(-24.826837046738646,-0.9170082106837754,-112.82619549998915,10.015458165429294 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark14(-24.861563734692933,-0.5582709715338141,-67.34272846084973,28.665465637689252 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark14(-24.896234017202318,-1.393092145662619,-60.62855616957232,0.7570774239827445 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark14(-24.9025976478412,-1.3155491545209466,-39.27930805014945,0.06007048530669917 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark14(-2.498292826010396,-1.3503158496778853,-32.02960686173762,0.010017253624950236 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark14(-25.02048263838749,-1.5707963267948948,-23.86593721288115,50.59636972709214 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark14(-25.063886925490586,-0.5188184517589853,-1.3261373361344388,0.9578176554570774 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark14(-25.09291282906928,-1.5697837798529992,-100.0,0.03213034522693595 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark14(-25.111310875074846,-0.7733732374503219,-40.383972981815575,1.0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark14(-251.99342006056574,-1.5707963267948681,-74.89411942097684,-2200.863524248063 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark14(-25.21272925991618,-0.02401496928539765,-11.661383460142787,-1.0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark14(-25.23664732789934,-1.4540724438888726,-34.97176821306586,1.0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark14(-25.249819321208626,-1.0011674169871618,-32.604440361550644,66.25713300435083 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark14(-25.268712982734005,-0.0018324898504437131,-9.529045001350614,-1.0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark14(-25.343427658131674,-4.440892098500626E-16,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark14(-25.370988642768438,-0.6599508795681586,-82.97821440959585,-77.42768226984087 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark14(-25.384670336861454,-0.11816198119618154,-0.2965594973723077,0.0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark14(-25.435374125401733,-1.5661400032877346,-1.5707963267948966,0.9502501661323143 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark14(-25.565572422241594,-0.870767912144359,-80.28983937416639,-0.012741904707431667 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark14(-25.585582660611145,-0.010945862722390245,1.5707963267949054,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark14(-25.58781036932384,-1.5707963267948961,-53.32371819955563,0.0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark14(-25.594672760035003,-1.5282642181196113,-42.642101705833866,0.857297480240856 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark14(-25.724171502356587,-0.1701773770651993,0.0,-62.740976611491746 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark14(-25.758425423268424,-0.0031564118074361228,-1.3389666594223812,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark14(-25.76762728328466,-0.06099993110960654,-11.067348391623831,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark14(-2.580465976764943,-0.7332755645801979,-27.282448763583684,-9.084479411017377 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark14(-2.599767014967415,-0.10282325201752877,-68.41102860805886,2.9411014175509685E-4 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark14(-26.01819603943835,-1.5707963267948912,-94.2247145272387,1.0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark14(-26.045898096552612,-0.2390657221641799,-10.735935609421063,1.0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark14(-2.605365671428639,-0.3631710082673729,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark14(-26.304540395056033,-1.2632072014207107,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark14(-26.419198853056052,-0.931293809976939,-47.90243315644068,-0.04512710998173869 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark14(-26.44817736058185,-8.881784197001252E-16,-46.79322350035603,-83.5711702917297 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark14(-2.6474142146799737,-1.5707963267948948,-67.14868294785538,87.77853857951249 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark14(-26.51398193572396,-1.7763568394002505E-15,-10.64191761232766,-1.0000000000000018 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark14(-26.563365798467657,-1.1356038837633626,-1.2617531344308326,73.25117158392547 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark14(-26.594363118981274,-2.3208077443567692E-14,-53.66894309890793,-1.0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark14(-26.60785890755308,-0.7614598391470692,-1.5707963267948966,14.113619036430919 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark14(-26.70512203572121,-1.570796326794838,-1.5707963267949054,0.03814695791788836 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark14(-26.79326507547396,-1.5707963267948948,-43.52823073177989,53.325164310749216 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark14(-26.817320737281726,-0.5714847616211354,-59.78951986692975,-0.26217310001401595 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark14(-2.6890772177112527,-0.5631930714682483,-33.273663980548235,68.95048469333763 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark14(-27.05353803983498,-0.11836467890350737,-22.04680138527494,-26.36985675255454 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark14(-2.707038457590527,-0.931705179455636,-29.619593448871548,-0.9999999999999982 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark14(-27.106084531424887,-0.2429816041303918,-28.28800784594346,1.0000010353903117 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark14(-27.149466232554666,-0.1375402250072122,-80.8868231303874,0.33538293821129095 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark14(-27.194830631434186,-0.896530715586465,-1.5707963267948966,14.397361642974744 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark14(-27.297509965739046,-1.570796115413604,-9.560738370360484,0.9999999999999062 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark14(-27.333619669995226,-0.5905092974750782,-40.440791619790765,-0.13515423251142522 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark14(-27.372772223007452,-1.5707963267948963,-1.7763568394002505E-15,-1.0171778952306567 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark14(-27.421575859012123,-0.02886081803841532,-10.790086081793554,0.029974379839641185 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark14(-27.559692185369705,-0.8435337662901484,-1.5707963267948974,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark14(-27.72395360024862,-0.9185614222967795,-7.395155196207469,-0.49846600953430764 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark14(-27.74294531732812,-0.03196300496076665,-55.18358127587663,-1.0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark14(-27.889979574815193,-0.1864745725260848,-96.27918802290438,0.36208933694919687 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark14(-2.813602620858681,-0.3571745239182896,-0.9406542033762009,-1.0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark14(-2.815890359832644,-1.4761589695459423,-0.5986269553300754,-0.5498726122861751 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark14(-28.189883084106242,-1.134055733936064,-67.4070089209579,0.06255274295895857 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark14(-28.32470553882363,-0.7620475113664953,-100.0,0.35634264586476916 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark14(-28.3345563196167,-0.471952718757592,-71.88516013669692,1.734723475976807E-18 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark14(-28.388495218376896,-0.03249603360466385,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark14(-28.521282569615344,-1.5707963267948912,-84.09174975100433,-0.7186005617904581 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark14(-28.58003259639031,-4.440892098500626E-16,-1.002184382216152,-0.03893410949568249 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark14(-28.634680761224118,-1.570362600156138,0.0,0.8226824158362842 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark14(-28.654897593576425,-0.61913091017516,-0.3745657867506842,1.0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark14(-28.66086439004835,-1.570796326794894,-20.395298216102418,31.51983129222613 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark14(-28.73322648927894,-0.16681201449166697,-4.5597320133790475,0.5745009522161882 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark14(-28.74082362202896,-1.5707963267948948,0.0,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark14(-28.81157013225343,-1.5707963267948963,-4.38518476670221,1.0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark14(-28.820936579943645,-1.3983226043504697,-1.5778316079756372,16.23380634512253 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark14(-28.889369444912596,-4.672384477305729E-16,-32.78262652991048,-0.049792633744412125 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark14(-28.914634196759252,-0.50341572037843,-45.48648250557546,-2.4677579418653533E-178 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark14(-29.0176902158009,-0.5151491101059613,-52.063268282049876,84.6378793298579 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark14(-29.249705007506975,-1.4431102928960229,-8.498610415485032,-47.56845602120574 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark14(-29.272185331277264,-0.18994602439834019,-100.0,-0.9999999999999929 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark14(-29.60086219201072,-1.3408893777559214,-59.27220330793847,34.26471022703795 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark14(-29.69324475429959,-0.7614593409746009,-5.916477248115672,-88.03610456487647 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark14(-29.693347480818453,-0.9716901301216021,-40.83611333917881,-0.4906023045253747 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark14(-2.9702857154758737,-1.5707545430245264,-11.824715247513767,-0.9145307200728685 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark14(-29.811991766527125,-1.338078592822934,-88.21401878525779,-1.0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark14(-29.83908453655239,-0.37290585314514635,-1.5707963267948966,-0.6043514535630669 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark14(-2.985184650972684,-0.26701016328085814,-121.97676932039131,-0.8314542189113929 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark14(-29.99532033778475,-0.8927805691824844,-77.3854236975077,0.046654916643300307 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark14(-30.048688142641794,-1.5707963267948961,-0.5526441577402244,0.9790275896387699 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark14(-30.056698038358086,-1.5707963267948912,0.0,0.7364684945520412 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark14(-3.022970482679092,-0.13377113534258425,-1.325348541455016,-14.793520160455268 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark14(-3.035305156039034,-0.8130306116063255,-1.5707963267948963,2315.917120463801 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark14(-30.53045822670563,-1.5454117046424705,-45.67652258435036,1.0001797066828715 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark14(-30.53289205880573,-1.5257283194131979,-74.10160946207756,-33.04321123930116 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark14(-30.536160073102323,-0.8798387338921221,-1.5707963267948966,-62.23458036607834 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark14(-30.5837715639423,-0.8133738354320037,-100.0,-0.9677084047516777 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark14(-30.633811443103465,-1.5662489877591752,-86.85730811350388,0.9726928799342156 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark14(-30.67335995207744,-1.5707963267948948,-13.466531534071835,-1.0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark14(-30.675023084221237,-8.881784197001252E-16,0.0,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark14(-30.701763080354397,-0.8879954057866657,-33.39478673891702,-38.62389286730417 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark14(-30.784101940650572,-1.2141792774888953,-130.9233653966311,-38.010218971052076 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark14(-30.85759263728282,-1.5570790461366746,-67.88330599507395,1.0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark14(-3.0859490404758265,-0.6138837049026891,-2.064578701937741,-10.78580942919005 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark14(-30.87662650411612,-2.220446049250313E-16,-90.01700199500038,0.3126258509603335 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark14(-30.894676681492406,-1.5624086054349087,-73.3655025201843,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark14(-30.940148486441338,-1.283759554055432,-11.647152627886069,1.0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark14(-30.951145502976345,-0.9831079760595712,-170.20450641960838,-0.4057387042913514 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark14(-30.963958625419824,-0.5100795523847701,-43.42532750481783,-36.97818963363819 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark14(-30.964520241951014,-0.5253439258218354,-100.0,0.05877126311859629 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark14(-30.984454150050137,-0.5249180953941075,0.0,-0.9930018692026532 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark14(-30.996029929609985,-1.1171549796097469,-0.754506245608149,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark14(-3.1099625267710875,-1.1434267795585014,0.0,-7.418412301374843E-68 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark14(-3.11421424995979,-0.006631928470933192,-0.535270940128349,1.0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark14(-31.167530281629112,-1.5707963267948912,-86.9610913741499,1.0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark14(-31.176219768983174,-1.5707963267948912,-37.794329839672685,65.98542795942936 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark14(-3.129113639799603,-0.6041801278581812,-33.34358664770559,-1.0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark14(-31.316386633371188,-1.3158435577306034,-56.062534913751236,1.0000118885669649 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark14(-31.320908051602274,-0.8439633834209979,-56.80139872960204,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark14(-31.405675458191446,-0.1685449154759464,-16.582517108681948,-0.7983638286518332 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark14(-31.488564067844578,-0.004100574091293649,-14.09883794288231,0.003808989048142336 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark14(-31.559149145024435,-0.08485152374059557,-58.02702635493601,3.5795561108905325E-15 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark14(-31.577074850501432,-1.7763568394002505E-15,-11.405777720477644,-2183.555195409292 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark14(-31.68072246496301,-0.23962742208686905,-71.68816393269378,-0.4635152811926946 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark14(-31.711819955715256,-0.7469011193878542,-14.11964030420525,4.118046071574423E-84 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark14(-31.723342706193183,-1.0929345201602296,-17.922185727491772,-1.0000247965500406 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark14(-31.83739559072788,-0.7514352655157523,-27.805187680982677,-0.9165094345102371 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark14(-31.892560201746633,-0.9079625037372008,0.0,0.0025802049663868343 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark14(-31.907864265242726,-0.004540764224480031,-10.485081558013622,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark14(-31.94003828225252,-0.23591625730636778,-67.21170183787271,-1.0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark14(-31.95715571383209,-1.349288113401564,-15.536605080889831,1.0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark14(-32.00835234167612,-1.5707963267948912,-95.66658996873933,95.05966671897448 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark14(-32.03069469417928,-1.5707963267948963,-67.98784180754313,-0.7985074215781691 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark14(-32.03330730175678,-0.768205251336255,0,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark14(-32.29143052730359,-1.5707963267948906,0,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark14(-32.324476474365056,-0.17283796458961853,-84.84364827292825,0.7472857175496743 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark14(-3.232469609463964,-0.7299775509191743,-84.85768325299522,-0.8412337621486976 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark14(-32.33226978829781,-1.4883893349473505,-42.92339998546986,-0.9797212806251726 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark14(-32.412876784529075,-1.5707963267948961,-37.52711468412781,-3.7099708052200227E-16 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark14(-32.41853025082213,-1.5707963267948912,-45.503715614992934,29.65207889524551 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark14(-32.43615060558187,-0.863108439301458,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark14(-3.246476905782705,-1.5707963267948948,-4.440892098500626E-16,23.79050965479302 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark14(-3.2478254110581055,-1.5707963267948912,-29.602296342783582,1.0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark14(-32.82650360208005,-0.04073358095479307,-45.47198013802393,-1.0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark14(-32.834837900018925,-1.3700931684397353,-82.06072617190284,1.0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark14(32.8512328128098,99.20624924809294,-40.9681747361869,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark14(-32.94917860076356,-1.4191154051299046,-4.291612173801694,-1.0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark14(33.11274792153847,46.77320970229556,-57.252275390961806,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark14(-33.11588410036445,-1.5707963267946496,-7.972167957018513,0.0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark14(-33.147816155561316,-0.5942202278722203,-25.951725336867845,-1.0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark14(-33.17254770769367,-1.435814729034547,-59.20359784782704,-0.743333470924819 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark14(-33.19165335983812,-1.3563278575597475,0.0,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark14(-33.24667803557962,-0.03727115577522295,-0.8093340640538161,0.9557323611836068 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark14(-33.253330406846146,-0.5335295550231728,-40.050669908977284,5.01001636753378 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark14(-33.29083845615834,-1.548578884599132,-100.0,-0.9954610947412089 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark14(-33.30090038697298,-1.4683179631681018,-43.7142138026606,1.0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark14(-33.315552384344095,-1.4826430960641404,-40.80091943124418,0.15657916179759124 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark14(-33.35050919282912,-1.5707963267948963,-41.46047273911294,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark14(-33.37296303830351,-1.161221174685722,-0.7281506078965694,-1.0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark14(-33.389682281599164,-0.8931201177123697,-1.5707963267948966,-0.6731124908479487 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark14(-33.43155568035181,-8.881784197001252E-16,-6.462047133978752,-1.0342945033875064 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark14(-33.535653931659596,-1.38593842501877,-1.5708102947622085,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark14(-33.55526453124617,-0.048327557156419676,-71.83912246586566,-2190.619584682619 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark14(-33.571568632852824,-1.4831151320770581,-67.17025706266989,0.060072852857544656 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark14(-33.63054312191974,-0.19221442913106374,-37.681175590723136,-6.588873714519077E-83 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark14(-33.66600414138536,-0.500942358621542,-67.46339835410684,0.0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark14(-33.69051088894118,-3.7152589690672566E-16,0.0,-0.9999999999999991 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark14(-33.852438517269206,-1.2352849273808684,-25.323058025179662,-21.69670685478873 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark14(-3.394960175401309,-1.4910332551247194,-36.343404850425244,1.0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark14(-34.08197138287139,-1.4811366613877766,-0.4930778470537623,-41.59031138917299 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark14(-34.14140064726445,-1.5707963267948912,-85.58915861852839,100.0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark14(-34.20958101622907,-0.42529337579655324,-0.4673161144215027,-1.0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark14(-34.25115305421723,-1.567192113553205,-83.37866468012844,0.010781443828950483 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark14(-34.290550678236514,-1.0659939211559042,-69.79374247692216,0.0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark14(-34.362644255730146,-0.41605511594890143,-29.018613099545323,-1.0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark14(-34.36490600994528,-1.5707963267948963,-1.0737291895967869,31.387468956381973 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark14(-3.4439093202133972,-0.9675450242364817,-32.76216293156945,1.0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark14(-34.476580921800576,-1.0639196402723654,0.0,-1.0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark14(-34.54541429286349,-0.006132491213947346,-100.0,1.0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark14(-34.565097539199776,-0.9290124331204531,-4.210978211100439,-0.9999999999999999 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark14(-34.60004796776222,-1.5706397300533719,-1.5707963267948966,-0.28602593095987905 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark14(-34.6093579168235,-0.7569699372982152,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark14(-34.74046225641206,-1.0256020021126062,-57.37543720960323,-64.2402412768225 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark14(-34.740724915299936,-0.46173989966872897,-89.9779759153652,-1.0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark14(-34.78986891753239,-1.5707963267948961,-51.935498435675186,0.28516107019058023 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark14(-34.8878052160329,-0.07814676455009995,-10.60467013167694,-37.04974582733884 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark14(-34.90901278149178,-1.1923959419313843,-17.638658941953146,-1.0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark14(-35.10364200555506,-0.8411396131945061,-58.486399930191,23.94897853955021 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark14(-35.14156067166705,-0.09326621970999714,-4.278807771465109,0.06329884108342204 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark14(-35.26551584755882,-1.0270963713448422,-85.15013306228182,-0.9744722959600295 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark14(-3.5269516683989792,-1.3046018252064755,-63.36145271406897,-1.0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark14(-35.32585737948382,-1.5599596624428074,-6.082953716358652,-0.06307111078422706 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark14(-35.33846470921465,-0.04486793540079759,-46.0935711382082,0.6962363898065697 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark14(-35.358305548750785,-0.12655138938898522,-7.756888683541391,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark14(-35.36533005627295,-0.3469612159351716,-57.381396000433845,-84.26323761023924 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark14(-35.558056585326106,-1.5707963267948912,-27.84234040614993,-1.0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark14(-35.558217381575865,-1.5707963267948841,-27.93692309409259,74.99722464472299 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark14(-35.61442069020721,-1.3386678651308261,-11.647342535223244,61.52525470680686 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark14(-35.63702220377315,-1.7763568394002505E-15,-0.3218341920598084,4.440892098500626E-16 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark14(-35.68143173251101,-1.1147692866898822,-1.5707963267948966,-65.67130427015346 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark14(-35.769984948133896,-0.6510930098763485,-9.631437574576552,1.0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark14(-35.83673419864167,-0.29368945639724514,0.0,0.05309034010929452 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark14(-35.88137654768914,-1.5438329166529574,-50.08742151860286,1.0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark14(-35.98979100381978,-0.15756822904457124,-39.095719948179074,-18.946203432828934 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark14(-3.5992183811668697,-1.2522122904790085,-78.74336385190279,-86.1446737091262 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark14(-36.02549289130047,-0.7302520442588907,-27.42824634910249,1.0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark14(-36.060193211774916,-1.2419538028157766,-179.3616806019991,0.8147527669952104 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark14(-36.06188868844844,-0.422409853321651,-1.5707963267948966,-0.0560695605178561 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark14(-3.61198609006291,-1.5707963267948954,-1.5707963267948966,41.40049409578103 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark14(-36.18937522036386,-0.5479518179925361,-22.786152982797077,1.0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark14(-36.37574242342452,-0.004441100110563479,-0.343904199767419,-0.13972606227362744 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark14(-36.38351587466056,-0.502760693864319,-1.5707963267948966,0.7212328256313604 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark14(-36.43678640247233,-1.1030103287702382,0.0,69.62122880055756 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark14(-36.44122280226322,-1.1769555513977963,-83.14090418912518,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark14(-36.45480803289218,-0.8364472936205938,-28.44439270235013,0.637594006476173 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark14(-3.655691695401231,-0.18570721821509475,-169.7927226193607,-29.74934539632197 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark14(-36.63838298621832,-0.28183546295194556,-1.2361587680361412,-1.0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark14(-36.65759367740104,-0.006765125596477628,-65.60332742398523,-1.0000002942331607 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark14(-36.685578448256344,-1.333021689361694,-76.40694305226677,0.5696941130680226 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark14(-36.79764145632869,-0.12284177368496178,-15.430375103993066,0.9944497857983083 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark14(-36.88062063669477,-0.06322462343952241,-45.332927200287955,-1.0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark14(-36.916505328536594,-1.2029669218400478,-1.433209591749163,-1.0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark14(-36.953956913563616,-1.5707963267948948,-63.06452221550302,-33.4204038740985 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark14(-36.982792481191055,-1.335653091802024,-32.91437265643739,0.04952885295439788 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark14(-36.98431464528656,-0.8890206852646585,-0.23530179606012275,-23.30971657319866 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark14(-37.046646229784926,-0.7459350577342477,0.0,-1.0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark14(-37.08482015966062,-1.5707963267948912,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark14(-37.13800511024002,-0.48802664727722656,-1.5707963267948948,-0.7277465092886282 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark14(37.157329443462345,69.58959500812134,-40.5232106516179,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark14(-37.17021201527452,-0.6419005308139805,-68.05290165519018,-6.138581931166842 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark14(-37.178242209540414,-0.8025545661702722,0.0,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark14(-37.23263309901641,-1.5707963267948912,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark14(-37.24388317021328,-0.9912517590758105,-19.165655541760493,-94.92340548683438 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark14(-3.725303838556337,-1.1463324026298098,-37.77080957394806,-1.0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark14(-37.28751424114322,-1.424116588650635,-72.68574775044252,-2013.0998305496792 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark14(-37.34892667515398,-1.1277680856019288,6.5099183857664515,-100.0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark14(-37.41479435050808,-0.9932382565335871,-51.3738800153305,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark14(-37.418209696874754,-0.9682952274999987,-74.27974814334743,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark14(-37.44047539346238,-0.39326837487783384,-53.67983562142852,1.0000000049033286 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark14(-37.48809619320528,-0.021493940341175508,-1.7763568394002505E-15,1.0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark14(-37.50487085476637,-1.4804155638629592,-37.34579087084232,-15.614687758831469 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark14(-37.63435955578745,-1.4075091239594457,-58.62812813814825,1.0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark14(-37.654399468441,-0.4591008274713768,-1.5707963267948966,-0.9162016819632242 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark14(-37.73718540958417,-0.7684949428954638,-54.08112786951105,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark14(-37.77107792294402,-1.161470834314676,-1.5707963267948966,-75.10368330550997 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark14(-37.94124092246708,14.726882269171043,-18.81916234547288,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark14(-37.98397169511396,-0.7943513113600325,-20.032814559530763,0.16694633389815916 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark14(-38.01169898683827,-1.044227839809821,-48.3916189301546,0.9829242641522049 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark14(-38.03520747839517,-0.9767793345118676,-33.23313786987042,0.9349743187658555 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark14(-38.0504054481925,-0.44359841622628426,-0.3512840604931142,-1.0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark14(-3.807227546857418,-1.178371558292285,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark14(-38.17141247082041,-0.3377085408806872,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark14(-38.186571958324215,-0.00419443477712967,-4.554173592613466,-0.05424179644193776 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark14(-38.357554129034746,-0.8286037750505052,-45.12473349606531,-0.1225629984101193 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark14(-3.8405478673134326,-1.1983837416496135,4.631601382568533,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark14(-38.41912027432969,-2.220446049250313E-16,-88.36155420137115,88.20476688687228 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark14(-38.42915808883184,-0.35304615275660606,-63.32335342406004,-49.60672033252197 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark14(-38.43493808024952,-1.4630593755447834,-6.389569266061514,-2101.2140184534023 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark14(-38.47442494207221,-0.7426698862836184,-67.9659229443855,-27.56575412638184 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark14(-38.56022131014651,-7.105427357601002E-15,-60.77163667221729,-1.0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark14(-38.60752028615335,-1.5575412394369224,-72.68684198985632,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark14(-38.67179188194064,-1.25158259137298,-1.5707963267948983,28.725214656584704 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark14(-38.6740475044579,-0.6849186848847175,-100.0,0.0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark14(-38.686548173407836,-1.1756321490139,-95.78405978256272,0.3624550546736451 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark14(-38.73042590301527,-1.5707963267948948,-7.6486821004690375,1.0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark14(-38.75223840410189,-0.18992967231738067,-147.7023440124199,-0.1473367896630755 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark14(-38.80417447717354,-0.512976203990462,-99.31311339284204,-2142.3642159658366 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark14(-38.850080035760904,-1.3092174137134347,-3.5695485586070594E-17,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark14(-38.91682918598155,-0.035743352139732565,-73.99498805870408,0.06255275007948193 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark14(-38.920477689042656,-0.16828796293003037,-15.335087457175291,1.0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark14(-38.94320630163352,-0.8784526417089449,1.4765795643474173E-15,-0.5125849571055066 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark14(-38.95997488766923,-0.45310384879290666,-73.39665503799867,1.0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark14(-38.965832222146915,-0.22969716962717257,-32.63114186750542,0.0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark14(-39.0393594486991,-1.5707963267948946,-19.368271458703575,0.8999425822309752 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark14(-39.104435562289474,-0.26273607256965215,-51.80177408624581,0.5058420699547309 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark14(-39.11344766268996,-1.5707963267948912,-36.18993674984712,-28.53669710330813 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark14(-39.13642749917392,-0.6685991556568979,-0.25228283198494617,-0.48278255846462037 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark14(-39.19503341837483,-0.5072817791387303,0.0,0.0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark14(-39.28593002420389,-0.06972285636112316,-62.38494066517811,0.0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark14(-39.34920451216591,-0.5826404176782298,-1.5707963267948966,-0.02515827673091664 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark14(-39.466993800792565,-0.4730277974592941,-55.00428939046492,-0.8979216878084125 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark14(-39.47859806639745,-1.5707963267948948,-67.51917966161639,-0.04199544703229863 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark14(-39.51200325659116,-1.088012267109363,-122.86468276926492,0.039135062909926244 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark14(-39.52145619856129,-1.0666627567447655,-7.536071962637376,-1.0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark14(-39.56426486518265,-7.105427357601002E-15,-44.055498494196435,-99.886060751924 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark14(-39.66597625342007,-3.552713678800501E-15,-1.5707963267948966,-26.945289328066163 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark14(-39.75630949275464,-1.5707963267948948,0.0,-2.3855246165043695 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark14(-39.76598302217904,-1.5707963267948912,-63.96523928445881,-76.90366311484564 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark14(-39.79092563565687,-0.4340394775543779,-0.09215498284886126,-32.36579455070121 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark14(-39.84404658009359,-0.012748272514790049,-1.5707963267948966,7.016644421671785 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark14(-39.95870704263283,-1.5707963267948957,-24.77891556759956,-1.0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark14(-4.003175487877042,-0.26776017942274316,-74.83766794968665,1.000041120789709 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark14(-40.10252344636087,-0.9111805894472185,-44.05078387535113,0.9102864062003421 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark14(-40.11401871834374,-0.0944643815029309,0.0,-68.28484198064758 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark14(-40.185679211156945,-1.0590468261760264,0.0,-0.04054607570875329 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark14(-40.19009142840355,-0.7179542110170635,-34.48644334586704,1.0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark14(-40.24757067933695,-1.3485456477657949,-100.0,1.0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark14(-40.29411593158419,-0.3194512614920555,-77.54994262665309,-1.0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark14(-40.324163109537295,-0.05981103139942376,-0.022076834342154482,-1.0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark14(-40.49812211344119,-0.08323721872492623,-98.30352405141491,-0.36212177447334304 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark14(-40.58188515859643,-0.9090269103190037,-49.02021010298475,1.0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark14(-40.58963112561072,-1.3157855664680653,-100.0,-1.0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark14(-40.675771410590386,-1.569528886823099,-14.806059320047686,0.8626960158190277 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark14(-40.722082229303766,-0.1080788296834595,-1.5707963267948966,0.024427118344341033 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark14(-40.722921015317745,-1.5707963267948963,-86.88423405764541,2.0992380133168336E-18 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark14(-40.7810210751891,-0.10971392561807228,-20.753864148927907,1.0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark14(-40.87631444856987,-1.5707963267948895,-62.26754357338095,-58.14524107446641 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark14(-40.885962743750646,-7.105427357601002E-15,-47.429335792236294,93.82707219419711 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark14(-40.95569034440058,-1.3481490745341809,-65.65367590439358,-59.42508072026066 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark14(-4.096153451678386,-0.027332966721654577,-11.796281648518569,-23.76192855376255 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark14(-41.02774798355631,-1.4626657742886482,-10.293627872896383,0.32608804598631524 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark14(-41.07209820148765,-0.8778521256618478,-162.37307137867256,0.9998879997745633 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark14(-41.11846914886243,-1.3343863873536606,-6.44629456726626,1.0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark14(-41.21262264033148,-1.4985720212322675,-99.63118663901253,-0.5193487039579963 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark14(-41.281326208820175,-0.20315566158491283,-7.105427357601002E-15,1.0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark14(-41.30234857094801,-0.9951922181195281,-33.023672093684745,-0.005231018770634144 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark14(-41.304012183230384,-0.7141509624586022,-87.10543524504368,-0.9999999999999998 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark14(-41.31172391866079,-0.7159337898829643,-76.42527304548224,-1.0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark14(-41.34868941138872,-0.032431993431171355,-100.0,-47.422252261773394 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark14(-4.141000109890712,-1.2332695147515313,-1.5707963267948912,31.609889237577164 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark14(-41.478736665877605,-1.1586220904337305,-96.25867973324475,-0.9999999999999998 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark14(-41.49056679032774,-1.570796326794888,-0.8172239675005504,0.0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark14(-41.50270630410097,-0.010576468772319807,-68.21830906488404,2.710505431213761E-20 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark14(-41.520812609081,-1.5707963267948912,-0.9815026828486864,0.9999999999999996 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark14(-41.66819793724747,-0.6655018435391485,-1.5707963267948966,-0.06255256311871318 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark14(-41.98803905105621,-0.10543183481355652,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark14(-42.209637135754186,-1.1546218773226156,-4.262570539183439,-63.08888001795269 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark14(-42.39883527636308,-0.8610793218887418,-52.55905117752122,-54.41860882051732 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark14(-42.46650698959194,-0.9297129532279738,-13.243028382315426,-1.0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark14(-4.249652665528842,-1.5707963267948912,-0.0780559481825227,0.4753881859632436 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark14(-42.51827170610609,-0.6276329875680204,-8.570919257512287,-0.37166266310001317 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark14(-42.56114365714867,-0.8710608279566188,-56.89655879891108,1.0000000178725974 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark14(-42.60389470912262,-1.5707963267948948,-88.75718962488257,-0.18734290929406416 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark14(-42.616961640676195,-1.370257453068281,-39.1215497409633,50.374720186788096 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark14(-42.643806346525665,-0.29730440754491255,-83.84553417627973,0.11650425661878683 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark14(-42.693710974249726,-1.570796326794896,-1.5707963267948966,0.022991256261908437 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark14(-42.74915128073189,14.762374062766796,17.600100156608192,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark14(-42.82834100454849,-0.46356623953447795,-67.06398080387181,-1.0377426136684547 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark14(-42.88807079934923,-0.49730259700890844,-42.203625731279544,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark14(-42.90674744555683,-0.7834432785610181,-44.484537698134076,1.0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark14(-4.304071633179515,-0.960667363901981,-37.79913174467937,1.000434487371888 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark14(-43.05584515455288,-1.5688767698472825,-3.2231883521460816,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark14(-43.083198129185114,-1.1102230246251565E-16,-1.1579679921617356,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark14(-43.118858353865235,-0.3367874655114351,-79.55598567574728,-0.0626030832427531 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark14(-4.326343398855382,-0.9213365892234952,-1.5707963267948983,-60.99525728161904 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark14(-43.33589835488513,-1.063691699350408,-1.5707963267948966,-0.03929893138219798 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark14(-43.34765475425641,-1.5496299605665662,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark14(-43.367681083693874,-1.0638017720667519,-100.0,64.49820018417424 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark14(-43.40924749934668,-1.1549313093388571,-59.05868616266889,-9.1438991302582E-100 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark14(-43.415339587421435,-0.7048364681982235,-93.71697023573155,-61.12092099139569 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark14(-43.42918333433107,-0.8383927735099257,-29.369607100716706,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark14(-43.44011277646685,-0.7869394418505647,-4.3368086899420177E-19,0.8875354264080821 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark14(-43.60126882810995,-0.10444975919823354,-14.929043642251784,-1.0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark14(-43.66658830779795,-1.412631953633264,-4.543463576767615,-1.0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark14(-43.67076617861897,-1.1665795231290236E-302,0,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark14(-43.711975072731526,-1.2986767575744425,-31.958794581813677,-0.3191661594588042 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark14(-43.793559201718125,-1.496386361641991,-31.49302627311468,0.9999999999999997 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark14(-43.81425123996667,-1.0694809876941436,-32.842708265959004,-1.0319021770260657 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark14(-44.02445284411742,-1.570796326794893,-57.61116145004729,-0.3021997870716725 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark14(-44.065260488418026,-0.7845830430948941,-45.844257583692226,-1.0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark14(-44.067598473048456,-7.105427357601002E-15,-25.793551954212496,1.0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark14(-44.083308241006556,-1.1864233165858495,0.0,-88.36772530309946 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark14(-44.09493429529802,-1.0033953747305167,-0.4636686683421885,0.1510039929123112 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark14(-44.17233786639559,-1.4963996855519686,-42.1073118432141,0.9999999999999929 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark14(-44.19322466298201,-0.3989462868679965,-49.85978245610053,-3.9551621997202524E-5 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark14(-44.25472425633081,-1.5528674057569802,0.0,0.9993364159109711 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark14(-44.29685480358414,-0.1521304616725203,-60.00595965042776,0.999999999999997 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark14(-44.2969656609434,-0.0036360194473271127,-15.231463522580007,-0.36820206799746247 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark14(-4.429785722250049,-1.4415101498756007,-78.32581432001028,-2.3984573935371652E-4 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark14(-44.31486491578916,-0.05336079473707887,-19.364125483436936,29.687128083687753 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark14(-44.38992340159127,-0.32921324032266436,-89.7795909955055,-1.0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark14(-44.476151908731644,-1.0987486462147162,0.0,-0.9999999999999991 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark14(-4.458796659233304,-1.5707963267948948,-43.14545538869914,-0.3578194624480733 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark14(-44.63672554572533,-1.2729590458994267,-38.19035914343498,86.0189449095025 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark14(-44.663591376424066,-1.5707963267948912,-85.71369888955269,-0.07929433951318586 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark14(-44.66438178991749,-1.3299399238799219,-58.05027301434559,1.1658930808696222 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark14(-44.73831690724876,-0.17631564931010713,-100.0,0.9999999999999996 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark14(-44.84400132677201,-0.946033040584776,-84.56578572375307,-0.916703864008803 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark14(-44.890161698242494,-0.7031671851168024,-10.510696295241118,1.0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark14(-44.89262690610989,-0.24362508423524787,-73.37595055003027,1.0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark14(-44.903714093220685,-0.023860175285006495,-68.24376918394174,0.4745802610273291 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark14(-44.91866928573058,-0.07838453612830087,-1.5707963267949054,-42.88188659692191 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark14(-44.92535962352178,-1.570796326794209,-60.38595597333145,98.15234527178788 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark14(-4.4999648457871615,-0.9602800488795209,-4.956033922166601E-4,40.78443239997667 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark14(-45.16919235492798,-0.650308780172685,-32.9855167107556,1.0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark14(-45.288298936505456,-0.6727287362775893,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark14(-45.336639050936206,-0.4960534005928665,-1.9877674812786086,1.0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark14(-45.351286257461396,-0.07937085793437375,-5.748054098910031,-1.0000049288017399 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark14(-45.36266651028617,-0.9866747779848725,-100.0,-1.5557532065946216 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark14(-45.42230414392587,-0.1923739418861217,-65.9142967420861,17.155664681896088 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark14(-45.43865905790683,-3.8416476963684595E-16,-1.5707963267948966,0.89016592583132 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark14(-45.44752261933456,-1.2029165676168878,-16.049840724973734,0.5656458194432563 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark14(-45.49472103329465,-0.6221291083765721,-1.5707963267948983,-1.3520917157830237 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark14(-45.53999216058009,-1.5707963267948912,-100.0,-1.0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark14(-45.54696067615741,-0.28793619961122147,-46.683060889034465,0.9966360095968088 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark14(-45.6002218265355,-0.256161454787605,-100.0,-17.510631479096798 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark14(-4.562789101134695,-0.37296891700982227,-100.0,0.6279203352161729 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark14(-45.68583581571006,-1.0258060877071538,-100.0,1.0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark14(-45.723144729998836,-0.5909869798203602,-1.5707963267948983,0.7305363559762459 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark14(-45.776182339679465,-1.5178302759125926,-26.631024584439558,-85.94944360754273 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark14(-45.98579485813039,-1.4486725084956806,-1.4642857092552253,46.010887573324865 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark14(-4.598714845676952,-0.06850665389773702,-38.92882282867578,-2252.9346632225147 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark14(-4.607858657747194,-3.552713678800501E-15,-94.50716473902246,1.0000376889974252 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark14(-46.14947152192264,-0.013457357643032119,-31.56291780976865,-67.9777987823402 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark14(-46.18499608713567,-0.25444732125185876,-55.1242698544001,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark14(-46.24533958941924,-1.3426352460500084,-85.09000304324047,0.9887059087153477 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark14(-46.27348149121716,-0.6939079335308158,-0.18696426580465195,0.0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark14(-46.333230874749226,-0.6981475547918099,-44.32826766030253,-21.330231853784746 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark14(-46.380916139615245,-1.5707963267948948,-42.99904244875267,-12.215485938991733 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark14(-46.45185013788709,-1.5257675508228623,-1.5707963267948966,-1.000041128417106 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark14(-46.46208405908183,-1.4239298951034597E-6,-0.052745371844395705,-0.4831397114494569 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark14(-46.46741005916055,-1.5707963267948897,-1.5707963267948966,14.194916956585828 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark14(-4.650554705593564,-0.547016196075262,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark14(-46.54451376897233,-0.0028228259022724522,-122.98024804109657,-0.9429280351888654 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark14(-46.5453238739656,-1.4977848779374785,-1.5707963267948966,0.999999999999999 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark14(-46.567404502802965,-4.440892098500626E-16,-32.530074315242885,0.5097903458457154 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark14(-4.6649359003820905,-1.5707963267948948,-100.0,-93.83446251143093 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark14(-46.781456648277626,-0.17276598710554336,-27.091573440831247,-2186.614114388388 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark14(-46.78372894667957,-1.1711577422504438,-84.66737932451807,1.0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark14(-46.84390457142634,-1.5707963267948912,-88.11408193786272,0.8530451017479899 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark14(-46.87937008778036,-0.5651530772334729,-68.51941211519774,-1.0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark14(-46.98600316603867,-0.2915637312579163,-47.96261977758674,-26.4490777551758 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark14(-46.988644317978945,-0.28144020090115784,-18.686043366866414,1.0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark14(-4.701864114282376,-2.220446049250313E-16,-80.33964248831624,-7.684467316001331E-8 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark14(-47.06387864965396,-1.4366026208520726,-37.448365199906924,10.172628766446394 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark14(-4.707831457560929,-0.5517400295629915,-0.8346120120316289,-1.0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark14(-47.0918104924631,-0.9886463279239335,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark14(-4.725526575814129,-0.20453422507025085,-60.03974509632597,1.0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark14(-4.727162603733122,-1.1679447878119744,-71.46222800713694,0.8448804114513837 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark14(-47.27590873919714,-1.5707963267948912,-2.714933624631259,-36.96464032426603 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark14(-4.729787491866972,-1.420466285991872,-81.98086477474216,0.9999999999999982 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark14(-4.7350689751154045,-0.5263219641969021,-3.9404118189610493,-1.0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark14(-47.36492555703496,-1.5707963267948948,-53.81943044607947,1.0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark14(-47.372266291761946,-1.2877700614723029,-71.72791940565492,-0.6524066943696596 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark14(-4.773356386279543,-1.5707963267948963,0.0,-1.791032736190319 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark14(-47.82747603270709,-2.220446049250313E-16,-95.39067232643558,0.9999999999999996 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark14(-47.848738196441154,-1.5707963267948912,-45.05116929267447,62.994305231254145 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark14(-4.793076914295146,-0.5556418389188973,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark14(-47.97367814490998,-0.5894884038795418,-135.54609218109533,0.0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark14(-48.004204952985674,-1.5707963267948912,-43.54305525879818,-1.0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark14(-48.12802033027644,-0.6351968779743682,-73.28128284756957,-100.0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark14(-4.817999592314235,-0.6384348654355976,-95.54050467729083,8.470329472543003E-22 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark14(-4.820262583748679,-0.6439502319263603,-6.425749108457735,-0.05427392304522623 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark14(-48.23856008554515,-1.523396716821337,-72.45220753353479,-1.0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark14(-4.829524586825457,-0.7016086257840595,-21.564086565725276,-0.8396509122195075 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark14(-48.34253077687534,-1.1346513357649044,-0.850951494567504,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark14(-4.851053597287464,-0.07171985948720473,-1.5707963267948966,0.8136139281516808 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark14(-48.55377043339834,-0.37600719578861685,-15.309949490560443,-111.23173889767008 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark14(-48.614653363827394,-1.5203468589816866,-42.85222538422267,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark14(-4.876887123393115,-0.29930793931765265,-39.02742679561097,-1.0000467750195214 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark14(-48.822843048898214,-1.1684831677320069,-78.49299278738444,63.49926477130259 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark14(-48.87206872517128,-0.9838093088172164,-68.98456565745897,0.2978515260287654 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark14(-4.90041113021455,-1.4210854715202004E-14,-84.24589918037776,2336.136845036656 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark14(-49.05848582581838,-0.8381669031480392,-4.115521620553573,-18.338836823602808 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark14(-49.10677655098783,-1.570796326794877,-34.21413589688346,-0.9999999999999992 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark14(-49.1388743796868,-0.27220548840585934,-0.030936533057693616,-0.10486838936818887 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark14(-49.16573151946531,-3.552713678800501E-15,0.0,-61.47611927534419 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark14(-49.18350982567764,-0.20566256125550708,-28.200798782334726,45.7825881452182 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark14(-49.30323501762073,-4.440892098500626E-16,-68.50036733315528,53.72833006684467 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark14(-49.32626940909432,-1.5707963267948948,-88.52010858746046,-93.52485044794076 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark14(-4.949154037252443,-0.35360372119237576,-86.59475869809884,0.9999999999999996 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark14(-49.50532913794234,-4.0330553911584194E-16,-39.05471020654667,-1.0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark14(-49.528567557688696,-1.3291660854000862,-76.85779560693703,0.9999999999999999 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark14(-49.533276576729264,-1.1539790540949006,-1.2567850017520439,0.682385834269901 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark14(-49.65197802872905,-0.16284218959136812,-12.50936173284029,1.0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark14(-49.697529225292655,-0.7819252609658549,-15.461508217927966,-0.8849645287186503 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark14(-49.704326908072716,-1.3674011946558315,-1.5707963267948966,1.0496681418073576E-140 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark14(-49.741775901354025,-1.3233506173995253,-60.66706264185642,-1.0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark14(-49.79586656343804,-1.7763568394002505E-15,-32.29878679880447,-1.0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark14(-49.80498541506816,-0.9645420590093656,-38.58154338497223,1823.757688366061 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark14(-49.80795255052826,-0.8819553305898363,-44.186386834451355,1.0000082979657159 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark14(-49.81526016658507,-1.5707963267948961,4.3368086899420177E-19,0.0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark14(-49.88626031412534,-1.502207534070432,-10.590937187070763,-1.0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark14(-4.9891187382041755,-1.491220883744188,0.0,5.551115123125783E-17 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark14(-49.96337673935957,-1.0148597101601766,-179.56281758876588,1.0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark14(-50.07306875732263,-0.15993759595099255,-63.67164296621699,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark14(-50.17462950857605,-0.5763879961174609,-66.27771423866767,-84.74105401893081 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark14(-50.18555878262537,-1.3995267460625558,-73.6141075971809,0.15938857301424536 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark14(-50.20461108067969,-0.012966866022484105,0.0,-1.0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark14(-50.24490943922245,-0.324953566685663,-164.10263017807006,-0.02014536774576159 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark14(-50.3110667870584,-0.4676578042292614,0.0,-55.86086280188848 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark14(-50.44720168115817,-1.300044453860411,-42.70994661058957,34.915151795067175 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark14(-50.650505334302316,-1.1285312210905618,-31.67568856557415,-56.619459443816055 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark14(-50.71689802818271,-0.691240572544958,-34.80993725247484,-1.0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark14(-50.72064179908498,-1.1722339844878755,-0.09428639412014751,2.220446049250313E-16 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark14(-50.811518769273924,-1.41802267435442,-1.8939535901878628,1.0618371352980547 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark14(-50.83601893989091,-0.4387632977959072,-43.27365345492616,1.0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark14(-50.97630258503277,-8.673617379884035E-19,0,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark14(-51.044542498883594,-1.270503955363624,-54.92168637685427,-0.7641581000921751 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark14(-51.07679038788507,-1.5707963267948795,-32.0986429648766,0.0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark14(-51.09641581463776,-1.1534632852815472,-68.89181955913864,-0.8706037500409929 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark14(-51.25007910363164,-0.8140454401937376,-2.0813943956704293,-1.0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark14(-51.25448107126298,-0.009393568507883874,-8.783998016254884,-66.00412883030856 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark14(-51.274795717066205,-0.2206111750768909,-61.94470727323798,-29.122409859796157 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark14(-51.32926000603815,-1.0169550115389667,-32.92931027490274,2.0880974297595278E-53 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark14(-51.42089628371725,-0.7904914188195953,-7.34954686377179,1.0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark14(-51.46275996007775,-1.482282798511714,-37.75338009824115,-58.952639916937514 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark14(-51.55764601791088,-0.7811819245727349,-53.82162801850504,-0.66674883112508 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark14(-51.68683903948725,-0.8871426791647513,-1.5707963267948966,6.776263578034403E-21 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark14(-51.69085919082269,-1.1351099927706794,-0.7735172951654636,1.0098044063486455 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark14(-51.715926287932604,-1.5707963267948963,-0.07713925720127855,-2072.921465257932 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark14(-51.78864824413744,-1.5707963267948963,-52.56067431112947,0.0011287471955217232 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark14(-51.95980584345993,-1.5288959132750446,-1.5596935082611854,-1.0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark14(-51.98047398836591,-2.721512850059412E-16,-1.5233179255393903,-1.0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark14(-52.05401569349367,-8.881784197001252E-16,0,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark14(52.114347644436094,-1.1663471555978104,0,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark14(-52.14100833655035,-0.38734653015304676,-24.78072344342834,-1.0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark14(-52.155410035306886,-0.07433071116848566,0.0,92.68066526582346 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark14(-52.167398744536335,-0.8018636911391399,-4.810046828647344,-0.7188468730653739 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark14(-52.199349051343916,-0.22226097519534704,-73.25654346488035,-0.007505175446518408 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark14(-5.228078771233797,-0.04400988625556575,-80.6234764667439,-0.6460054291813466 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark14(-52.30416260971803,-1.5707963267948948,0.0,-32.246000768383915 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark14(-52.35751469270992,-0.59670909636168,-10.731072846393936,-1.0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark14(-5.238950407501351,-0.6324672418280592,-2.135977055254614,0.14222165299060308 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark14(-5.2424574825793115,-1.5707963267948961,-0.8172321486754069,5.798059776044074 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark14(-52.44190511136647,-0.03757336684105566,-89.34528421027278,14.304559268907411 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark14(-52.45854193572751,-1.5707963267944176,-31.642687073130823,-1.0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark14(-52.59786732610644,-0.4603590632200305,-71.33803692283014,29.585378431451744 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark14(-52.61064875066945,-0.26331417084323894,-57.987150317845945,0.6137720066412511 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark14(-52.66346165043792,-1.5707963267944507,-1.5707963267948966,1.0274552124937013 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark14(-52.80492610569671,-1.5192552212360413,-24.673537374904107,0.2025651465916758 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark14(-52.82512199596773,-1.5372866891970633,-38.27798456252711,-0.7732089546019978 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark14(-52.84289912569165,-1.2796741508792846,-39.11053656806503,-0.8945259916536135 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark14(-53.01634353043008,-0.04218415113351215,-100.8412844633724,-1.009582676053685 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark14(-5.310070870370765,-1.5707963267948912,0,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark14(-53.15399299909519,-0.04368198411324178,0.0,-0.008122487991306689 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark14(-53.17966230674804,-1.5707963267948948,-9.83160115919938,-0.3285488648458448 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark14(-53.19716559659106,-1.5707963267948912,-100.0,-0.3620893395016321 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark14(-53.2090779713307,-0.3740181759233286,0.0,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark14(-53.21706708571026,-1.4927748989973133,-100.0,-1.0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark14(-5.332903375020472,-1.3016930975689855,-68.6166047596902,0.15325455640469277 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark14(-53.3687373493981,-0.648251434299496,-66.96935907918817,1.0000000000000036 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark14(-53.37267774790353,-1.1997952475711866,-2.094320922254333,1.6016664761464807E-145 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark14(-53.46978757952831,-1.0474560970036126,-5.715536235002695,-1.2037062152420224E-35 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark14(-53.49535489690771,-1.3350099226189975,-31.771530269819493,0.9999999999999982 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark14(-53.559729344203724,-0.16865899063575213,-25.031729645968223,-1.0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark14(-53.591882314437875,-1.4526945938234093,-4.157373757490262,-0.3857676981936873 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark14(-53.622788594540516,-0.07531533293008438,-50.024935861415976,0.1681147199880757 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark14(-53.85704851815014,-0.37709015156303294,-14.640127222862489,-1.0003233911229843 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark14(-54.0295742071292,-1.118467273590329,-9.328455378685614,0.6386060743635356 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark14(-54.22053012954166,-7.849272070732041E-5,-44.74999322128701,0.8274487788451893 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark14(-54.27333015801015,-0.5651152862373634,-94.82579608172482,66.41735846729115 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark14(-54.27626092581328,-1.0567558353770092,-12.043906008548781,-29.145168892632782 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark14(-54.289338465923805,-1.5707963267948957,-32.179086344434,0.01277865676341186 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark14(-54.36434408817922,-1.0501113782630007,0.0,0.05430513039697482 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark14(-5.439857008748831,-0.5086628202433348,-146.71699394350813,0.18160504854599785 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark14(-54.61488148752957,-0.7326769594147762,-44.22975567591284,1.0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark14(-54.67342324600513,-0.4863093508463099,-88.95989678467758,0.9999999999999999 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark14(-54.77071963258173,-1.5707963267948961,0,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark14(-54.77806314053598,-1.5707963267948912,-7.894454668062287,-35.22840987568033 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark14(-54.88671926773138,-0.47011021322162866,0.0,-80.88589280908968 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark14(-55.00991695082028,-0.5696885783066494,-80.36644790034137,1.000024237915162 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark14(-5.505943312919811,-1.53333386943087,-97.77149018645632,-42.8756085933064 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark14(-55.078764218083016,-2.220446049250313E-16,-68.48306898351582,0.06159845378897357 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark14(-55.11531570698227,-1.4535260159078163,-0.035657080417118285,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark14(-5.518100608932863,-1.570796326794893,0.0,-1.0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark14(-55.26156816480144,-1.0978995273669403,0.0,-0.9024546100305211 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark14(-55.3802968426715,-1.5707963267948912,-36.26730861378071,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark14(-55.4177987367341,-1.4744009167174608,-48.878691112852856,0.14509859567288846 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark14(-55.465780359471765,-1.5707963267948912,-66.03274522024225,68.52323994603684 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark14(-55.471420114321376,-0.5246116641367715,-55.195100128244164,14.262275445717037 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark14(-55.64058318000232,-0.9704422958440375,-49.252602680193995,1.0000000000000004 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark14(-55.65554829892332,-0.6953098588625578,0.0,2197.772214042163 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark14(-55.77382818129308,-0.6180371305287282,0.0,-0.9726266092656324 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark14(-5.5811794003419735,-0.7575615312137671,-1.151894755403677,0.37683177818753544 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark14(-55.81286352910191,-0.8559059493165146,-37.326143783437836,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark14(-55.862183315009936,-1.570796326794889,-15.037883427338821,-0.042329565763798746 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark14(-55.88117509141891,-1.4888127701413736,-44.00836957819456,-100.0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark14(-56.00435651837586,-1.5707963267948963,-1.4078200467224096,0.9542231889797081 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark14(-56.047197704079906,-1.1088802792525416,-0.715381177790568,-0.5110577659801238 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark14(-56.07253675670488,-1.3876142977147015,-40.24642251622132,0.4952780127725337 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark14(-56.13841860134442,-0.803163658175565,-23.691721888213088,-0.30069283480757747 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark14(-56.22668282313552,-0.11518471359099408,-67.96865536261393,0.17539500405648967 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark14(-56.306485680834975,-0.01790292681734133,-68.09108856744344,0.9484822485295602 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark14(-56.38196872323435,-0.1393180996201167,0.0,-0.9999999999999998 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark14(-56.46222588648646,-1.5124352160557173,-65.25884378380982,0.0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark14(-56.51429342650277,-0.5452074452113939,-52.73322674835053,2.4858355989166503 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark14(-56.55315305715948,-0.14973152230807774,-32.794111693241945,1.0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark14(-56.60236428641772,-0.05686075976607176,-86.29297805466646,-0.46039885259477425 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark14(-56.793458879859415,-1.5707963267948841,-20.040603922098153,4.440892098500626E-16 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark14(-56.899376484367146,-0.5938191895219118,-11.479400981559333,-7.907507646286904 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark14(-56.93110710812015,-1.3868631193218166,-57.14796784998356,-0.006189460927408863 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark14(-56.987589690296325,-1.2852626257757473,-75.25315534927468,0.9967101551109484 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark14(-57.22879821215643,-1.5707963267948912,-50.8102364686146,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark14(-57.24329641933356,-0.880546630434224,-84.12602367212557,1.9059608547324898 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark14(-57.25870980925579,-1.3772375297462847,-65.52376073188317,-1.0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark14(-57.274179979500374,-0.5310630771716975,-66.14170306914646,-56.95230759566414 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark14(-57.280778935260116,-1.071350075112862,-97.14523760826812,-0.9446206867592082 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark14(-5.733901346937948,-1.403540453971594,-23.744140409627384,-49.32987623585381 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark14(-57.382956189434196,-0.5162801177591829,-6.84898094102871,99.12950467908938 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark14(-5.7469286536092605,-0.8936621205956066,-71.67017414499612,-0.013797644335352157 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark14(-57.48526926228956,-0.4074063423790231,-53.22436061903224,-82.29219160581187 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark14(-57.604443601131095,-1.2859416581027867,-187.07248950884662,0.999091855468987 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark14(-57.6516391443008,-1.0868525934108142,0.0,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark14(-57.83758512604143,-1.4909147584523796,0,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark14(-58.042071183409156,-0.8010312712865089,-70.03783948692661,3.7415159546362595 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark14(-58.0517160233812,-0.5786013687414053,-25.672728226775906,-0.6310155086569917 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark14(-58.05367772795434,-1.568471985891696,-17.139907861471812,1.0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark14(-58.05756704016279,-1.1025425939378177,-39.6036843899378,0.0027989406664197386 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark14(-58.09569028711379,-0.9875337944991829,-1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark14(-58.102407669498554,-0.19973749254124798,-1.5707963267948983,0.9360232627639054 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark14(-58.11278669541053,-1.5707963267948912,-37.84193328756733,13.954727650811634 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark14(-58.11607036209678,-0.6567252988552327,-55.111506960764885,-0.7734833027259743 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark14(-58.17255399915111,-0.46728683311231123,-38.57095092985764,0.6978564449251886 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark14(-58.22899255564251,-1.5707963267948948,-73.19973537819709,1.0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark14(-58.25303773761759,-0.7758155543825612,-73.08599795851309,-1.0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark14(-58.31876986789614,-0.5473092801457555,-59.14505971683484,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark14(-58.33878878747437,-0.19220007421661067,-54.236711944166714,0.038334276018332135 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark14(-58.35149664317614,-0.3604741980329038,-51.76030709854438,57.49635170303799 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark14(-58.40546984969388,-1.555033519537487,-57.61345437049182,-1.0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark14(-58.481692262101255,-0.030025039899026745,-41.96388688674908,-1.0000008421010582 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark14(-58.493038862077064,-1.5707963267948923,-4.9311787753203475,22.87204341361379 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark14(-58.49987144110873,-0.7932889178539285,-60.64540955220037,-0.07068216509140324 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark14(-58.5149361664989,-1.7763568394002505E-15,-1.5707963267948966,-0.7060283788917855 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark14(-58.6444331170383,-0.6046831407812505,-9.573125923439816,-1.0000000000000009 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark14(-58.64799667033953,-1.2146542647181446,-31.804716647153924,0.5070571815701341 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark14(-58.64988076968184,-0.3576823910926247,0.0,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark14(-58.67295311733022,-1.0142621567620034,-85.64149738379061,-1.0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark14(-58.679180967081244,-1.5183588931995229,-0.5611127630197396,1.734723475976807E-18 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark14(-58.70987662772102,-0.021620973060510158,-26.175696245451853,0.020807565088653047 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark14(-58.71135091599017,-0.9473996061210183,-79.53664133115613,-70.51153486852682 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark14(-58.73469309469586,-1.5707963267948957,-73.69188558253677,-0.016600796408271584 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark14(-58.75295890527597,-1.1194959768799742,-10.66305271012384,-45.59243662761343 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark14(-5.878978150922887,-0.24568368612281088,-1.5707963267948966,1.4982932103090733E-15 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark14(-58.84678883226931,-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark14(-58.89550781637437,-0.05823284487944892,-12.552842919495786,-1.0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark14(-58.983592685956694,-0.27635583639951095,-77.66641756948475,-0.25835072648503976 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark14(-59.10544868615369,-0.2953430437985958,-7.975219954081396,-13.431303399454578 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark14(-59.12439696080405,-1.5650453201292724,-0.012163801213945084,-6.62850243160072 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark14(-59.19955333386031,-0.04895145019277151,-3.4369724063552667,-1.0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark14(-59.412152255533584,-0.3166044156314891,-18.798158023798507,-62.39833701589737 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark14(-59.568767919096146,-1.521610925625689,-1.5707963267948966,0.06206975533405498 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark14(-5.957411318548919,-0.7585745956146064,-0.48791421483360864,1.0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark14(-59.60155036306341,-0.3754123489972425,-174.4982603267621,-1.00000000000398 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark14(-59.676001342302584,-1.3270402857310102,-77.37923770628734,0.04973663123077754 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark14(-5.980396225891342,-0.4320952256135191,-60.068903218912574,37.66054404269161 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark14(-59.85472481114599,-0.11990618651027218,-1.5707963267948966,-77.20562745779132 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark14(-59.98048434041682,-1.5707963267948912,-67.83981800581444,1.0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark14(-60.02145865384336,-1.3332925705174041,-36.617040050465874,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark14(-60.077710216125105,-1.1224052601650585,-39.10043700897414,8.470329472543003E-22 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark14(-60.251337033367136,-1.1173411158353637,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark14(-60.3317520557396,-0.09476807055976247,-31.65223160914927,20.90000474646368 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark14(-60.39474838909711,-1.0724306990637975,-89.5448629729621,-1.0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark14(-60.47451066989431,-1.5707963267948912,-24.557384691645524,-35.3398811376008 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark14(-60.55542642560424,-1.33877448075663,-1.5707963267948966,0.6996138247526756 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark14(-6.055821449675956,-7.105427357601002E-15,-10.990115750181044,1.0531977349041601 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark14(-60.559456425444736,-1.5707963267948912,-11.220492747112019,-47.8603099943524 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark14(-6.073022876939652,-0.9620826345396511,-10.864939111360108,-1.0000000000000002 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark14(-60.7327020293913,-0.11894630876482631,-1.5707963267949019,1.0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark14(-60.745979364301995,-1.450893616782465,-41.50749357586016,-1.0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark14(-60.89655793550011,-0.7596580378208634,-76.17401193342116,1.0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark14(-60.93826051440667,-1.4468206028670252,-1.5707963267948963,-82.27418656804471 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark14(-60.96958069006644,88.51723975880827,0,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark14(-60.99727079511413,-1.0647777003804293,0.0,-0.08985961397215725 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark14(-61.027347736159136,-1.5707963267948912,-52.50673271050483,35.521739204810885 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark14(-61.03995070945092,-0.8845577048562924,-73.51577196760955,0.6208018736510645 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark14(-61.09736667163223,-0.5408468415054732,-46.55729956282861,35.2256462621899 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark14(-61.16599829480351,-0.4148976277113997,0.0,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark14(-61.19689231388632,-1.1513738862391278,-70.84630076816669,98.88660172807553 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark14(-61.25110973608304,-0.0803466616994939,-17.739370508528662,-1.0062530953510913 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark14(-61.2983840633684,-1.5707963267948961,-95.80824738946399,1.0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark14(-61.40175495168217,-1.5289824963879814,-43.35252786886056,0.045527763943349904 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark14(-61.45426441006851,-0.07926735941149321,-11.971049347726796,-80.16767808897677 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark14(-61.45959168834922,-0.029436357887789845,-49.42192313485445,0.37634264859090605 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark14(-61.47332657471533,-0.9567223393863209,-85.25309782762318,65.87761366866617 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark14(-61.77640038057536,-1.2485697983907353,-97.24283784241558,1.0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark14(-61.83210951864679,-2.6433732671339532E-14,0.0,-1.0343091155815458E-18 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark14(-62.0522208205347,-0.5350146236910451,-1.5707963267948966,-0.9241355172923231 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark14(-62.252123109537166,-1.5707963267948948,-90.38432241465954,1.0000000000000002 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark14(-62.281064149040795,-1.2811176765673078,-44.101912539519276,0.9270424000554738 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark14(-62.29091163589986,-1.477266967895877,-1.1258045386872995,-0.7886335865064393 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark14(62.33582765868019,-5.192569428006948,85.34822619843024,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark14(-62.420776748651924,-0.671229608196673,0.0,-0.6597260923164107 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark14(-62.4236758403212,-1.5707963267948912,-13.999298091613355,-57.80089126290626 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark14(-62.4829830993838,-0.5066322037807874,-31.74601750584423,-80.31651810944982 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark14(-62.7948184052786,-1.4744876618510219,0,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark14(-62.82022479840106,-1.4353062134116925,-32.89936600182722,-4.703065894908832 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark14(-62.984126672054344,-0.7648965042291826,-73.38342238102318,57.303959983788644 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark14(-63.064074013433526,-1.5707963267947775,-52.53381897239762,-2270.890995549001 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark14(-63.118583355745955,-0.7893807038784892,-81.57495874334175,1.0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark14(-63.271134826041695,-1.5707963267948828,-100.0,20.30106882282231 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark14(-63.42158422004813,-0.12147478337456707,0.0,0.6312563083075748 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark14(-63.49268493421545,-1.1583892481311526,0,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark14(-63.50068223516574,-0.7475661820741881,-37.68645423341825,0.8185683323493436 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark14(-63.59083932538796,-0.9337276900624971,-74.6117043695973,1.0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark14(-63.60155632832453,-7.105427357601002E-15,-12.812755551882844,-0.1384783441772104 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark14(-63.60696865404306,-1.4995186418573527,-0.02658230407835295,-0.15718526106250796 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark14(-63.61098326479266,-1.1266952652622262,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark14(-6.3790279553673175,-0.0658846349409976,-92.54415703967389,0.9228191574159164 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark14(-6.387287273715671,-1.5707963267948815,-33.890961440881696,1.0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark14(-63.89374657585717,-0.23735358932307316,-3.3895431429604486,-77.67715623420273 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark14(-63.92869023574322,-0.830715691658181,0.0,-0.5728720200382851 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark14(-63.93177016646352,-1.376699455728367,-32.06478453818376,-85.1088855723483 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark14(-63.977505929500765,-0.946484535640332,-61.988593120213494,85.66907729537024 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark14(-64.0027248914152,-1.5707963267948948,-100.0,-0.0011820661314425607 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark14(-64.22800223516766,-0.3846793336298292,-1.928093224749761E-6,-0.9621101844406403 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark14(-64.28185694429904,-8.881784197001252E-16,-15.909417470669402,-1.0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark14(-64.33951132901235,-1.5707963267948948,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark14(-64.37321985659318,-1.5707963267948912,-49.57219784675908,1.4552683589392448 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark14(-64.38547896485511,-0.37790992814638,-10.436194103804382,1.0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark14(-64.39725069011197,-0.16957265931242205,-58.84930666894268,0.0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark14(-64.48871287852161,-1.547428091014717,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark14(-64.50214451736902,-1.2332917536674453,-60.242543800288246,-1.0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark14(-64.58209994096623,-0.2246242464581903,-4.7991878203549305,0.0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark14(-64.62426540557213,-1.4603543682286755,-3.202158866396105,0.2954565985890705 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark14(-64.75222486709103,-0.22159006447537077,-31.43147197038038,-107.29224585319903 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark14(-64.91622751777956,-0.8056763756510008,-55.788473474835584,72.03689262240334 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark14(-64.99556772111148,-0.35076402395911854,0.0,-83.63348826756095 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark14(-65.04514384960004,-1.396946010057922,-44.10712329526446,1.0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark14(-65.0501933238194,-0.05375132047482714,-37.631192713050304,2095.7018715795207 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark14(-65.13265244080428,-0.19758155271944997,0.0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark14(-65.14885329952233,-0.5214927293622198,-1.5707963267948966,-0.9999999999999998 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark14(-6.545835030193797,-0.5453083562788511,-84.44852946677827,1.0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark14(-65.48764487598048,-1.1608611033771146,-1.2139599222930177,-74.65107538053553 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark14(-65.56234663197594,-0.46306291517754516,-41.29796755669722,-0.36323343319611057 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark14(-65.58303113769261,-0.687970629759933,-96.7373867958479,-34.78546584983832 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark14(-65.60347621392054,-1.1129542313127045,-53.600193496764206,24.546389036514732 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark14(-65.65172640178825,-1.1193482257270921,-14.117361846999618,42.060317206463246 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark14(-65.94768464876046,-0.1648453118138018,-92.2765414230118,-1.0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark14(-66.07990324767079,-1.0280339423070213,-0.307503336291268,-0.9999999999999998 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark14(-66.09891830579298,-0.5743365431942835,-16.39299826383474,-0.010959740532380344 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark14(-66.33652101253395,-1.5695529369340986,-96.98787975883492,16.96293601703747 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark14(-6.633700153973091,-0.6191883713500879,0.0,-100.0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark14(-66.36507903910694,-4.440892098500626E-16,0.0,-2268.8958096654774 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark14(-66.50615378404869,-0.7134521287729747,-1.5707963267948966,55.608724668230046 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark14(66.53208214241496,-31.184230175922465,-79.45936426292573,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark14(-6.6574884699439,-1.151574757666097,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark14(-66.62518788033799,-1.5707963267948912,-158.32876734870388,1.0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark14(-66.8116990320156,-0.05421797435923504,-1.3695664328545376,1.0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark14(-66.88880581061031,-1.1220474840070362,-1.5707963267948966,-4.906115254045336 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark14(-66.99237176873324,-0.9138495361474848,-27.254747187842582,1.5022252859511352E-17 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark14(-67.04076720592948,-0.02448350346229433,-25.433151663080427,-43.0961841216066 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark14(-67.06893019896165,-1.3255564782335754,-127.63768173707577,0.013136917131717496 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark14(-6.708818655132596,-0.28312755007883034,-43.80930496055102,0.0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark14(-67.12958929803185,-1.0966402492843175,-17.722971934807568,64.27963940284533 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark14(-67.14643311498358,-1.329605168342752,-0.0032910457979539944,15.83386614382505 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark14(-67.17365370370621,-1.0999669262409526,-94.81642874865118,-0.8468319406498779 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark14(-67.1817698182301,-0.6618945653139789,-46.543725054203435,0.7362790000967276 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark14(-67.28090963841981,-0.7590955324920762,0.0,-0.756730396648204 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark14(-67.28834828100197,-0.90781073364877,-27.344720605010885,0.433924910524746 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark14(-67.300142022537,-1.5707963267948917,-1.5707963267948966,-1.8582457439067693E-17 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark14(-67.3307682136712,-0.35118594518856366,-35.819229002821075,1.0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark14(-67.37813677366242,-1.5707963267948963,-100.0,16.721983668666503 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark14(-6.7396852743118245,-1.5707963267948957,-39.228525877036404,-1.0000000000000036 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark14(-67.43179735376496,-0.002471442099600565,-21.690040020013477,1.0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark14(-67.43189762351862,-8.881784197001252E-16,-0.5983615293398085,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark14(-67.43462799511049,-67.86718495459796,30.018516876299117,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark14(-67.4466730345984,-1.5114104271933204,-32.69511717206559,8.673617379884035E-19 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark14(-6.749979677418295,-0.43953821277242233,-2.1418149232527885E-14,0.0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark14(-67.50598390595657,-1.5201412830912409,-66.43490590840264,-0.016167013407376543 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark14(-67.52598818106306,-0.29831163425070883,-28.086767856839153,1.0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark14(-67.52774436425469,-0.5592758864827871,-92.14072223949162,61.44330863032253 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark14(-67.55877695909416,-1.5387330120654117,0.0,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark14(-67.58246648172283,-0.2405389633804072,-45.22386687643153,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark14(-67.66911689922442,-1.4718607666950938,-83.35136052225607,1.0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark14(-6.774063512634531,-1.5707963267948963,-7.241712295957797,0.02943938146542588 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark14(-67.77827624517,-1.2485302691117024,-38.507397262109876,-56.077808483728894 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark14(-67.95185851831326,-1.4330232691291729,-0.807713860720149,-7.705350767729667 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark14(-67.97640456231093,-1.3295003259417522,-7.787576717353019,-1.0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark14(-6.799676587446951,-0.2356549866418276,0.0,-1.0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark14(-68.01509237149124,-1.3138350956056921,-1.5707963267948966,-12.391863819565074 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark14(-68.18498395691886,-1.4597993619944847,0.0,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark14(-68.2319071636042,-1.367700219480823,-36.166772949269046,0.78923522313631 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark14(-68.28745610661531,-0.18381869326087807,0.0,0.36704467620154013 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark14(-68.29126262903227,-0.833499283711858,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark14(-68.46157150211391,-0.026379881315515108,-0.001908513015944635,1.0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark14(-68.57766368368658,-0.3584200989581494,-53.29617593336262,-0.046527147462848736 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark14(-68.68544317927648,-0.2662279800304697,-69.35819248164833,1.0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark14(-68.72258139806642,-0.8499915794143328,-41.68256148900278,-90.77650391598075 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark14(-68.72260095295827,-1.9779893111375655E-5,-79.74054976109308,0.0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark14(-68.77180458166966,-0.33728085344572967,-97.46439694646081,-17.322502085242252 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark14(-68.79028692433931,-1.5707963267948948,-99.26563135463724,-16.21540923322533 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark14(-68.81405412211873,-1.5707963267948957,-71.99568496218886,-1.0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark14(-68.96520261684226,-0.005934014704608981,-1.7763568394002505E-15,-0.04097397053806301 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark14(-69.00745693526774,-0.3907233895172624,-32.48809811065671,-6.815552236334828E-5 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark14(-69.13174756475692,-1.4806234769709958,-70.98179783456558,0.014210315831497967 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark14(-69.19633794019657,-0.5578866875346087,-53.91874870903746,-0.9999999999999996 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark14(-6.920720698542379,-1.1083268793313357,-1.5707963267948966,-2.3025374293477605E-15 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark14(-69.21932363400893,-1.5707963267948948,-69.2479808519498,0.00654086168885501 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark14(-69.25254441164347,-0.5270276597345713,-56.24708826841114,0.8396015568820842 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark14(-69.2840228074954,-0.14079413771044938,-15.084172787426791,-1.0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark14(-69.2854604465503,-0.6175320711383847,-3.21750649210378,23.642647704251132 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark14(-69.31621792249393,-0.9510166567932675,-3.7472749918011137,15.040021840110668 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark14(-6.9462877501014475,-1.4401860745474317,-64.22518341352722,-0.022094694344133324 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark14(-69.47315327456809,-1.5707963267948957,-28.574728196786012,0.5455470024561466 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark14(-69.55479075718424,-1.0055424936752217,-3.3764714870822417,-0.7286117889895021 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark14(-69.59711692398905,-0.16871489111120283,-9.398398358086865,0.04236237394610587 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark14(-69.60396815467853,-0.75154362480342,-163.47932221673958,58.1843582536828 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark14(-69.65434598329318,-1.560547794005359,-60.99662955649389,4.670473621322737E-8 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark14(-6.9723715312758685,-1.1348028988533974,0.0,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark14(-69.94792226550364,-0.006323730956000814,-76.50668811751049,-1.0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark14(-69.97625553288589,-1.5707963267948912,-42.78175272179227,13.79350631303042 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark14(-70.09637215613466,-8.881784197001252E-16,-11.750018708687406,1.0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark14(-70.2176182015233,-0.8292693727444451,-46.54438627086285,0.0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark14(-70.29239275058171,-1.5707963267948957,-2592.0733216774324,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark14(-70.39957710529454,-0.04316123454330523,-21.22789490911228,-56.13829162927531 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark14(-7.0401981517168135,-1.0874875234648331,-1.5707963267948966,71.76970495670311 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark14(-7.044373591919662,-0.7205662594854699,-36.63534642602396,-0.010251194292451499 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark14(-7.057315740500812,-1.5707963267948948,-1.4803218499953736,2.537093877546077E-16 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark14(-7.05782555524395,-0.05349668177278838,-1.910223734269987,-1.0001520611382244 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark14(-70.74288298582186,-0.13196308677265214,-37.911361423834336,1.0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark14(-70.85836435676785,-1.5707963267948948,-53.18790146906611,2257.5869320727465 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark14(-71.0112180738679,-0.12773090571292217,-71.79944744214586,34.35633313952259 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark14(-71.01233621696083,-0.6933241438268576,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark14(-7.1019980376420655,-1.0324149029050735,-59.46213062448462,-4.699142863100647 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark14(-71.04980750800628,-0.7074551347973935,-0.6843719471955803,-0.05917172871238696 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark14(-71.06061363206408,-1.3238813334575519,-1.5707963267948966,0.9993665310001233 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark14(-71.09203580785137,-0.002036038290454338,-47.18784757894983,-0.004006463316538825 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark14(-7.109208855583771,-0.18416049956326166,-88.15258612165421,0.9169823241250382 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark14(-71.20048879303437,-1.5707963267948961,-0.3288783806245972,-1.0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark14(-71.23151520297715,-1.5572395008381459,-1.5707963267948966,-82.66520990183935 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark14(-71.41790500854738,-1.5707963267948961,-59.30643616230522,34.54493273597038 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark14(-71.43932586539835,-0.374571238848118,-1.5707963267948983,0.9688215559794475 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark14(-71.44596948332006,-0.5923068839011277,-1.5707963267949054,-1.0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark14(-71.44810725604155,-1.4821774173379945,-66.07493902157267,-0.046873442213021685 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark14(-71.4646113273139,-1.5707963267948961,-1.5707963267948981,59.781772942401616 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark14(-7.150264806975002,-0.0665849417452371,-91.78043228092487,-82.87449286364267 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark14(-71.59072932258725,-1.3289112584429874,-88.31168435857823,-0.626648849666959 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark14(-71.76901819897645,-1.3649793505452692,-46.44084458734918,34.137008491592724 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark14(-71.77566874681116,-1.5639369932409768E-16,0.0,-100.0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark14(-71.80389865592878,-1.3337230677984822,-99.62046007706915,24.262627177219702 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark14(-72.06639817304593,-1.570795825501757,-26.34844423254421,-0.09557744936730209 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark14(-72.09531191565084,-1.564907044728825,-74.88180909157482,-0.0659195382086375 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark14(-72.12329306962653,-0.5090313953641399,-63.21353417645932,1.0170917697618607 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark14(-72.17759204733227,-1.479328067508888,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark14(-72.20739902190381,-1.5707963267947633,-69.11302458796396,0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark14(-72.21934775375435,-0.024544903102534134,-45.480616446215585,-1.0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark14(-72.24747345834872,-8.881784197001252E-16,-1.5707963267948974,-1.6154288303623352 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark14(-72.2706546666813,-0.8592033600785173,-38.78329765081406,-0.17754145880462602 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark14(-72.472448448143,-1.5237155452451354,-55.07669497946321,-0.9999999999999929 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark14(-72.59020977303089,-1.228809394787639,-40.64055539783786,-0.3044249418201872 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark14(-72.59447553641947,-0.03785815270706203,-1.5707963267948966,0.1520996843452167 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark14(72.61782292586497,-68.98824436136996,-94.32599613587251,0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark14(-72.6920748365768,-0.3943633714975386,0.0,-0.044940063316436046 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark14(-72.99055405313149,-1.5707963267948797,-1.5707963267948966,-1.0000000000000098 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark14(-73.05188390105761,-0.017266475381853663,-192.92232967170003,-0.36359762354966785 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark14(-73.16595765582399,-0.3184268955180323,-22.43054455200031,0.007951100450124898 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark14(-73.22850255706481,-0.5876370486893379,-65.03644583940657,-5.241526802901874 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark14(-7.325375270385862,-1.4550461384862388,-70.36813099411181,-53.70436945236601 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark14(-7.325516440973317,-0.8769005013457948,-1.5707963267948966,-0.9999999999999991 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark14(-73.28426230325988,-0.6086792697301986,0.0,46.42363228538314 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark14(-73.33391176026626,-1.5200458580310858,-64.29858491514648,1.0940123211520216 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark14(-73.41504871455336,-0.5373654299557321,0.0,-0.5299124208364056 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark14(-73.48548513329864,-0.13797201223635813,-1.5707963267948966,67.98193124187621 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark14(-73.49333120688586,-1.5707963267948912,-70.8862884102331,-1.0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark14(-73.50988164555405,-1.2425445848004486,-1.5707963267948966,-0.8869387387723138 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark14(-73.57297555785146,-1.7763568394002505E-15,-77.35167681306359,-47.215641158685315 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark14(-7.357847124736974,-0.6074910796138637,-0.6071049817899641,1.0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark14(-73.63716480844532,-0.07568825163862569,-37.749896893564866,-24.69659291067032 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark14(-73.69220646996288,-0.3764417038305332,-101.96080571701656,0.0625956774334162 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark14(-7.371376943620525,-1.0167286672680766,-8.453130552330872,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark14(-73.77811796391234,-0.8711620799870907,-86.88977909397707,-11.253922706655452 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark14(-7.388918406710957,-1.148375498757364,-17.621020005030427,0.9032937316031375 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark14(-73.94677631581604,-7.105427357601002E-15,-89.30438367128697,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark14(-74.1445966501221,-1.5707963267948963,-43.90532814776129,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark14(-74.34071620397322,-0.14441339658067484,-0.42442909582341315,0.0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark14(-74.34760395230859,-0.6634278098529118,-1.5707963267948966,0.9234150374086363 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark14(-7.437891991552883,-0.2378716005068764,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark14(-74.43013916379478,-0.43467704498041937,-77.94009525399079,-1.0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark14(-74.44483907727648,-0.7363850210781311,-49.22571435285369,1.0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark14(-74.56801995479836,-0.6743314391826587,-0.47634771657822306,0.4424180973966405 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark14(-74.66024504076866,-8.881784197001252E-16,-62.74507617829756,0.0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark14(-74.66317833666386,-1.2367656656521127,-98.24327459194149,1.0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark14(-74.79152608672786,-1.5707963267948948,-48.45821696182713,-6.39975379281816 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark14(-74.7938372087117,-1.3531556615330103,-1.5707963267948966,-2074.7818230052267 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark14(-74.89634320364226,-1.2057853709923974,-105.41979783585248,0.030698807282648014 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark14(-74.95290061471727,-1.5707963267948954,-44.43170595395698,-26.45713133430398 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark14(-75.13875976745817,-1.5707963267948957,-68.6746190798035,-0.0037661704213304698 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark14(-7.535487297649695,-0.3873888444348663,-68.54067910363082,-91.95964177617601 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark14(-75.4552464687143,-0.26935082129707766,-1.5707963267949054,-1.000000000000007 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark14(-75.47015965293679,-0.24373941773498586,-67.6670925310052,61.35357757645701 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark14(-75.55151335534521,-0.8061382120026779,-1.1666064448524285E-14,-2182.129488973588 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark14(-75.59929665521216,0.47891580717286375,-87.17453553232873,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark14(-75.60099965120469,-0.047053547311577404,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark14(-75.65118964108032,-0.6124699580698554,-18.634014126789182,1.0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark14(-75.69057240603505,-1.018700885375388,-61.177590463953635,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark14(-75.771512489433,-0.7307259825696014,-0.3595508096032547,57.07554239010531 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark14(-7.5788369118417975,-1.0982669816303974,-64.10379444189098,0.06255253174896756 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark14(-75.80560567958459,-1.5707963267948948,-1.5707963267948966,3.4819910165337316 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark14(-75.83810753459082,-1.0302123082172907,-26.56394343664897,72.48304497199564 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark14(-75.92733024072406,-0.563472758047634,-49.6050597486682,-1.0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark14(-76.02844534773179,-4.440892098500626E-16,-61.82238632124833,-27.271141665588946 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark14(-76.13155283735786,-1.330916713989739,-45.26370309894799,-1.0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark14(-7.614243411429718,-0.27578482934664134,-80.30516296908104,-0.7920077104177067 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark14(-76.22525102217088,-1.3390726234768895,-33.1890733544448,0.9999999999999996 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark14(-76.47537968881444,-0.8175661830544539,-1.0603687216653137,73.97907832415954 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark14(-76.52310114060055,-1.5213911554120614,-23.869677934456938,-0.7242936487075724 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark14(-76.52752823823892,-7.105427357601002E-15,-54.474337490510926,60.14320660006763 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark14(-76.52812122111902,-0.07524116615090867,-44.25947765789471,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark14(-76.53428544593959,-0.6148367550211458,-63.694719462691076,41.397721763306 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark14(-76.60785210034881,-0.8142301908590575,-74.30782062244566,1.0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark14(-76.62866224907847,-1.5132626466411216,-75.48836535922175,-0.05745390765895812 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark14(-76.64988066517864,-0.05157732247459301,0.0,-100.0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark14(-76.91571390894903,-8.881784197001252E-16,-10.125380710988054,1.0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark14(-77.01356984206485,-0.8012253481676345,-0.39174990356834183,-48.531164262074455 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark14(-7.701489586284904,-0.2952285603661678,-0.6316273219976285,1.0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark14(-7.712221080441597,-0.5581286689936282,-31.806092591622274,0.9999999999999996 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark14(-77.16781255339589,-0.18527528991374342,0.0,0.02864938445593357 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark14(-77.21511018949413,-0.8995112278499933,-69.22874311829085,1.0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark14(-77.23417632017782,-1.3674510926466614,-14.603988508432337,-2097.316106287142 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark14(-77.26042667750761,-0.10787966101103809,-0.43794359069810934,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark14(-77.47511007994866,-0.208449590200124,-15.417300804988447,-1.0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark14(-77.52470058466892,-0.19085535005372917,-2.0226083530666443,1.0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark14(-77.7469978966746,-1.4379046853552062,-21.22894623103658,0.955804566971363 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark14(-77.78855284629162,-1.0463812456224442,0.0,-78.2695792435637 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark14(-77.87221651412214,-1.5707963267948948,-33.46776126649362,0.3678918446756061 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark14(-77.96408675881487,-1.003390715909111,-2.890787659422752E-16,-3.8838708877026335E-6 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark14(-78.05283830014444,-8.881784197001252E-16,-3.1925338397210083,-37.788362747389776 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark14(-78.08782536921599,-0.7991408764754032,-60.625638876509846,-0.39709720333045784 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark14(-7.814694293517079,-1.433716408069854,-62.53457370195579,-0.34088139676682694 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark14(-78.37080062575673,-0.9451613466821872,0.0,-1.0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark14(-78.38045633704601,-0.3696025754806843,-14.041201228543159,-1.0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark14(-78.46482069098937,-0.7155434147902793,-90.53757574434695,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark14(-78.48818756907174,-0.010206264997703966,-21.110185957224445,-31.624668453043057 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark14(-78.59336439679578,-0.08781717838228423,-31.9847190144311,1.0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark14(-78.70233399239798,-0.6765583476086325,-0.6094865038478203,-0.1239281620751096 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark14(-78.7509398605675,-1.570796326794877,-9.389500590007042,1.0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark14(-78.80996137274688,-0.03730587532538227,-67.00398481109293,0.6674246651472733 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark14(-78.92818247134312,-0.27502379252220654,-0.14087470907878147,0.12053167004429488 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark14(-79.00144094493444,-0.6284853061578399,-9.877257942113356,0.8221359108919061 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark14(-79.00387378283637,-0.6025048564686006,-33.10302373342717,19.22851741615609 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark14(-79.12614660458243,-0.3145032397932583,-67.39108492715485,2019.1558441413445 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark14(-79.15271920503233,-8.881784197001252E-16,-67.32226038893006,0.7810988065010197 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark14(-79.17835014118599,-0.14924861041659881,-2.182491418366876,-0.7082076533950201 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark14(-79.2142345307448,-0.14595812751186815,-0.9624460686245313,-1.0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark14(-79.22820804821575,-0.9287266677976659,-1.9027940567868524,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark14(-79.37114572623398,-1.0662215761003715,-74.76762265340778,27.85027395613206 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark14(-79.45159871989402,-0.1926533671737141,-1.4540077861877807,0.48918418151153176 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark14(-79.561573133607,-0.32803681562448084,-100.0,-12.915462701546645 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark14(-79.57568270921696,-1.5707963267948957,-30.57383533773401,-0.7962410452641552 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark14(-79.58963284953731,-0.9631177906155377,-30.046430664919246,51.89958968163748 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark14(-79.59763186660223,-1.297333461343199,-66.43919309816084,-1.0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark14(-79.6247938616849,-0.19254707951130406,-18.473059131615628,-7.049575092486289 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark14(-79.63220227632657,-1.2358318850956194,-40.63824776175886,0.0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark14(-79.70638632022316,-1.294916741167003,-66.86394157272976,0.0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark14(-79.86232565518273,-0.6290956585790326,-89.76631662292229,0.36352619575848566 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark14(-79.94094744109769,-1.5707963267948948,-97.68463587099467,0.0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark14(-79.94364591169615,-1.5697126231458907,-1.4559575761373402,3.6586417427431996 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark14(-80.18686439041846,-0.5618051053096307,-1.5707963267949197,-1.0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark14(-80.26677046257876,-0.616152635583032,-23.853206322522084,-0.2814525528394768 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark14(-8.049698111931393,-0.5334273538019397,-4.531998183992442,1.0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark14(-80.65010723512196,-0.8566810983914346,0.0,0.24369121243517627 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark14(-80.6556678500856,-4.440892098500626E-16,-0.24054864035586898,-1.0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark14(-80.68453922450061,-0.6706567944417463,-95.5733719737828,1.0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark14(-80.97650018829654,-0.7505604785745758,-61.9377311903446,-60.060116543891404 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark14(-81.08244844443699,-3.552713678800501E-15,-75.15626116469582,1.0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark14(-81.15943253793247,-1.570796326794896,-34.250386380188694,-0.06898450037019721 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark14(-81.18479451573168,-0.7451667694159857,-4.694353199757031,-6.363087921123382E-8 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark14(-81.29637465861167,-0.6709388942068149,-69.08589191997879,-12.697417325610862 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark14(-81.3652998765663,-1.5707963267948912,-59.03356912876423,-51.0442851181675 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark14(-81.57999934806152,-1.5707963267948948,-68.99011192342816,-20.62100904181295 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark14(-81.65367358042221,-1.1127309065759616,-1.5707963267948966,0.89459949957458 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark14(-81.80436699668486,-1.5707963267948948,-66.41989204937613,21.974359136097974 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark14(-8.186985276425318,-1.2146145029487612,-37.093228632350915,-45.90488262281966 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark14(-81.88373764692322,-1.5670442861448868,-1.185944407573377,-61.39587547126669 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark14(-81.89072010240119,-0.42006985513887,-61.77693245112703,42.239534666312125 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark14(-81.97345493275083,-1.5707963267948912,-74.77938127160478,0.0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark14(-81.99852598097834,-0.8589221434540392,-13.197781311757154,-0.9999999999999998 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark14(-82.0968905156895,-1.2985018591288426,-1.5613851249112916,72.4048652044443 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark14(-82.16053352416701,-0.10750210747238853,-0.8118428812897505,33.17241646480008 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark14(-82.16356382394623,-0.5439538464449996,-53.925072020789,-1.0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark14(-8.21900705422159,-0.03429947208301275,-73.54204736970244,-1.0000000000000007 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark14(-8.226473239041761,-0.013951389604660604,-80.7498099637848,6.5586903265860315 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark14(-82.32690712733663,-1.1575648837214731,-42.06462258513353,1.0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark14(-82.3674743597035,-0.11017155866330577,-52.87321957942246,-1.0092283710173289 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark14(-82.41423747454381,-0.6486631105568388,-46.24734215980132,1.0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark14(-82.43474984535025,-8.881784197001252E-16,-1.3899663436455552,44.178602417026546 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark14(-82.66478713033004,-0.9351177701388387,-24.672115301079184,1.0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark14(-82.89561544421488,-0.015187943348325123,-1.090061528775922,-46.56523978618473 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark14(-82.89950061265002,-1.5707963267948912,-25.457828355897718,1.0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark14(-83.05590138541551,-1.4210854715202004E-14,-81.82320888962586,60.59551956590735 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark14(-83.07297715319325,-0.054117572834854855,-72.98983567925757,54.730562335661745 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark14(-83.07698098162977,-0.04733597240206677,-52.186172931331235,90.59545578784117 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark14(-83.14160644395683,-1.3303887641677083,0.0,-1.0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark14(-83.17532021975524,-0.7033410404708237,-45.22767025929838,-0.9743920160788032 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark14(-83.33536290710532,-0.3859603788492274,-1.5676129706893873,-96.54492373944505 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark14(-8.370948163604794,-1.5707963267944933,-16.55006460471691,4.97003000029204 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark14(-83.71592430713577,-1.2235755311695156,-84.9521501577245,0.30153976296911034 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark14(-83.7408143787062,-1.1103384193370307,-1.5707963267948966,0.3395181509107755 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark14(-8.378006182140265,-0.30280180205574236,-74.18552854742215,78.58705810896197 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark14(-83.81652832800255,-0.9611973626740541,-58.471849639848,1.734723475976807E-18 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark14(-83.87139715863157,-1.5707963267948948,-16.86690431603044,-1.0000000000000036 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark14(-83.91597747926662,-0.0032963564624700647,-1.5707963267948966,-67.79449621468748 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark14(-83.96227142402357,-1.2489056378790462,-60.50357772644525,1.0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark14(-83.96873110425328,-0.5960032986994667,0.0,-1.0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark14(-84.02366280960794,-1.2942906369620886,-66.37504463190788,2.996272867003007E-95 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark14(-84.11718005136443,-0.1748882841563666,-57.48279964492884,70.31833709240814 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark14(-8.417475388451178,-1.5707963267948961,0.0,-1.0000003158143114 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark14(-84.2782953137872,-0.5618226235816995,0.0,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark14(-8.433593105696389,-8.338234592633568E-12,-33.67357247756267,1.0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark14(-84.47518789463346,-1.1855958898549637,-1.5707963267948966,-0.3632561705184099 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark14(-84.55230571966128,-6.329047053858139E-4,-3.4340005015613033E-4,1.0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark14(-84.56383501679926,-0.4969407055994788,0.0,2270.2646988355864 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark14(-84.59167171422862,-0.566705185929538,-41.817761643938795,2167.4785350784805 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark14(-84.61810100193,-0.1483031922432345,-30.914197157272262,0.014569128796632556 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark14(-84.71998695627876,-1.482178220376864,-1.5707963267948966,0.03668253572197301 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark14(-84.75000496334462,-1.5707963267948912,-66.31792149180089,76.68055385805926 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark14(-84.80389812471152,-1.5316804726912863,-43.783319543078996,3.3569413406500042E-6 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark14(-84.85575128820196,-0.08285667113454012,-45.954564152970136,-0.4246259690857883 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark14(-84.88201208848825,-0.3743704757093429,-40.076823199285656,-42.18576364058539 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark14(-84.93701967800928,-3.396014454923683E-16,-53.37815146551179,1.0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark14(-85.03728959106228,-1.471193838814421,-26.46739146645342,1.0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark14(-85.1628825112605,-0.2970688877172825,0.0,-1.0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark14(-8.519113277683665,-1.0921641485778175,-70.53432858860576,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark14(-8.519785679135854,-0.6868233996515781,-28.43000892491214,-1.0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark14(-85.23154208045464,-1.0831500044938216,-10.837763874061352,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark14(-85.36638835603594,-1.549092065115829,-18.786367681753383,0.9999999999999948 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark14(-85.6376894921435,-0.22259051957885934,-50.42046758001656,-0.6663692049224563 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark14(-85.72665412967048,-1.5707963265095894,0,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark14(-85.99542159486367,-1.0489227723082342,-40.451796179902175,1.0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark14(-8.605530249694713,-0.6225123354915904,-26.443626849841024,0.475317691450163 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark14(-8.611912147734884,-0.3115360806786054,-74.0124237154779,0.25690644842056776 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark14(-86.16549296284376,-4.440892098500626E-16,-0.025045603416621168,-80.30503506402297 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark14(-86.22016574180485,-1.5707963267948906,-39.217878458793535,42.88911337680436 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark14(-86.23013994859826,-0.3546108244993838,-18.614487728921404,-1.0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark14(-86.26901952335903,-0.029319258724072483,-1.5707963267948963,2.224183258750841 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark14(-86.31749249634939,-1.3556120144582542,-9.809502132270731,0.0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark14(-86.35031585060425,-1.0640258813164063,-88.10577568538528,71.30434946815919 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark14(-86.39313096088243,-1.0272289595740893,-66.10881363225408,-0.45181074686759803 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark14(-86.43743389753038,-0.2941886424170215,-1.4059476609999069,-0.7166650951958998 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark14(-86.58325609408351,-0.14319365455153843,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark14(-86.71644601275754,-0.46358898234947343,-1.4148221074841132,-1.0264457590632183 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark14(-86.79593566786738,-0.2108928250286019,-67.19065679922225,30.734732133353223 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark14(-86.92926594953956,-0.671930725741773,-36.62296881809822,40.095621340910185 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark14(-86.94243577093297,-1.2588881456887897,-8.523249692201404,-1.0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark14(-86.99951766416245,-2.0378492201307993E-16,-1.570796326794893,100.0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark14(-87.10187836142065,-0.44223570297121473,0.0,76.77010914872125 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark14(-87.42714653537035,-1.527610177902638,-44.33172474628257,0.9065520476281556 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark14(-87.44754333032029,-0.83391292958985,7.495197705044064,23.527898762066407 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark14(-8.755930309322796,-1.570796326794891,-0.7922032840366077,0.7056264899849771 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark14(-87.59531191657739,-0.551157275923317,-32.766185730524484,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark14(-8.766498051340795,-0.43396096263926154,0,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark14(-87.6987388036095,-1.0537219905129278,-81.5545992354266,2.6355494858076308E-82 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark14(87.7513466934497,96.43916164364296,-58.13684313663086,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark14(-87.76280380255855,-0.75130900013413,-1.5707963267948966,-10.845623455808024 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark14(-87.8669711286534,-1.0725146776664332,-45.773674700587776,-1.3679130462428696E-5 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark14(-87.927559635842,-1.1665570194320907,-44.33619853385073,1.0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark14(-88.03789904990195,-1.5209154505559004,-66.46878724350104,-1.0000000000005127 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark14(-88.1431289414468,-0.39609155530959267,-1.5707963267948966,-58.76030710686649 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark14(-88.5069543143568,-1.5707963267948912,-94.27360604881194,-25.563379559265755 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark14(-88.59607973537804,-1.2215494802033278,-0.7117476923378661,1.0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark14(-8.860992017635374,-0.4133637968347539,-83.2699353699283,-0.951980254256366 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark14(-88.63332190241677,-0.005641803512131759,-0.010050907919109144,89.53027715742674 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark14(-88.6686862571284,-1.0658182522652049,0.0,-15.731646681887867 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark14(-88.67356232175598,-0.9984797551671546,0.0,0.023847307447967734 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark14(-88.67815938044619,-1.5707963267948948,-1.5707963267948966,-78.90618873714827 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark14(-88.68582301602378,-0.04600516429664266,0.0,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark14(-88.72530652673706,-0.6178659223639116,-1.5707963267948983,0.6625935288233304 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark14(-88.98684138329807,-1.5707963267948912,-43.152461077230335,1.0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark14(-89.15257385539918,-1.4273003595448586,-9.70566521060193,2267.8392150590075 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark14(-89.2409127260156,-1.570796326794888,-8.511726584616897,-3.944304526105059E-31 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark14(-8.927310684951514,-0.19387687318108554,-3.1499555775370567,0.4977336158746062 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark14(-89.55341528932962,-1.5565366907925644,-5.551115123125783E-17,0.6450576488100722 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark14(-89.555174294242,-0.002161607475988118,0,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark14(-89.59516818338288,-1.071406702992098,-23.562108635788796,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark14(-89.6439302569375,-0.9789730204066895,-96.88123848515397,27.852895190823062 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark14(-89.73151704655375,-0.9182717361869874,-1.5707963267948966,-2.2323972485981933E-103 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark14(-89.73599032142869,-0.35670762268912903,-14.4417538353999,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark14(-8.9971742968213,-0.9219931475711717,-53.81063619397255,1.0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark14(-90.18592679222795,-0.05393603200010322,-94.3569519843263,0.328152213999345 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark14(-90.33471030423468,-0.8528057128643179,-17.905382122350716,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark14(-90.55320518434617,-0.8859188026220827,-32.427960430474585,-42.919318301809305 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark14(-90.61397764697942,-1.570796326794818,-62.31370905601639,1.0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark14(-90.65906202497588,-1.5707963267948948,-4.597941667593119,-4.118046071574423E-84 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark14(-9.07411427113216,-0.952066725647649,-66.15271322301292,-1.0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark14(-90.85348799316529,-0.5855212123108706,-119.95671973268527,-10.599292492896708 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark14(-91.03020600275755,-0.3133872144720877,-79.11436142058643,-28.817224468783365 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark14(-9.103281591546864,-1.0749769308818995,-1.5707963267948966,0.6237138621701357 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark14(-91.04307173752176,-0.15186312930693063,-44.649369726338485,-1.0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark14(-91.05989148150566,-1.5707963267948881,-86.7041063834941,-0.03968455899643699 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark14(-91.08762722936312,-0.6764588590135051,-14.273727466198,0.01230827414914945 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark14(-91.20772868734672,-1.4036071016736444,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark14(-91.31377210525042,-1.3735241872192105,-24.80274692388818,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark14(-91.43621873331196,-0.7922639947470904,-1.209449066262821,1.0000000000000018 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark14(-91.58133348762166,-0.24284674860833017,-26.749039534157973,0.22109894644006722 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark14(-91.67251144108982,-1.5333972312295145,-85.9965054524263,-0.9999999999999991 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark14(-91.71338891158774,-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark14(-91.84008555240908,-1.1656632997539091,-79.81160325507541,84.00940939413127 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark14(-91.93409591105066,-0.14394762855294108,-89.65500564542633,16.377844361764495 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark14(-91.94931298663253,-0.9281460348144592,-15.664196407119285,-1.0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark14(-91.96731389906583,-0.10168892499094909,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark14(-92.12096593533275,-1.511468793833526,-0.02696901139955943,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark14(-9.216955303143031,-0.22168482725518857,-44.52414778035592,-0.7650743668749636 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark14(-92.20392789392727,-0.14264629571027854,-1.5697027790407125,-0.9999994694692377 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark14(-92.21542432345387,-1.5679403407062589,-60.970675466582755,1.0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark14(-92.26148412995006,-0.7070990504637639,-11.406480954602344,-1.0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark14(-92.47045563684865,-0.19708871320968357,-32.34559609421102,55.89444391846331 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark14(-92.69646960093903,-1.5707963267948877,-42.635226997460016,1.0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark14(-92.78081866904772,-0.1819951578029568,-74.58668126864009,1.3234889800848443E-23 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark14(-92.81280319491343,-1.3657146150224353,-28.115578220932377,-24.0845162917492 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark14(-92.86024577495849,-1.2740198916990866,-23.940923072843034,1.0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark14(-92.86603874854866,-1.5707963267948948,-31.712611094830812,0.0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark14(-92.90496838688684,-1.5268409824469944,-100.0,0.9676234964882151 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark14(-92.9087960293929,-0.21231387379981284,-10.821623075206592,7.64059524718076E-6 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark14(-92.91833218045403,-0.26656485493786375,-58.50264457396045,-0.02623635989462908 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark14(-92.96382667162452,-1.5707963267948963,-3.556647124955518,1.0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark14(-92.97113221012546,-3.552713678800501E-15,-80.41877418002902,-86.12760737495779 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark14(-9.307614053437396,-0.09873634001200626,-1.1953875954306188,0.47494360595554863 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark14(-93.16428181368832,-1.434262246478505,-121.20415424426253,-34.461160459480595 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark14(-93.34048169014379,-1.5707963267948912,-18.48626614332396,45.87283891868671 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark14(-93.34321820917611,-0.7266822215102158,-5.705205844259712,1.0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark14(-93.3471793849266,-1.5376534011640768,-77.12019414354772,19.246819176475526 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark14(-9.340318156511682,-1.5707963267948948,-44.01468598572259,-0.4027835999082754 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark14(-93.44810130609918,-0.9230108228143653,-62.883971031860234,0.21849729972732124 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark14(-93.48523069945342,-1.5469191747217554,-28.2097068415367,3.80005801222702E-4 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark14(-93.71446233069818,-0.06385852568827328,-32.803361823168984,0.03693844849968077 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark14(-93.71700320318024,-0.9275406403372983,-98.26303176906431,1.0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark14(-93.91670624943454,-0.9847216066188929,-1.5707963267948966,-0.2864188726513035 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark14(-94.03647498633647,-6.387195076355563E-4,-37.799897847105214,-0.9042778072037339 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark14(-94.07497773689222,-1.5707963267948912,0.0,-1.0000113169244316 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark14(-9.419375323397011,-0.13871348662886532,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark14(-94.22888926510805,-0.09743479115748371,-18.675467855351783,-0.962437648901363 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark14(-9.428697539448137,-0.38110860776041733,-1.2306243825028047,-24.63108772944779 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark14(-94.29952015906457,-1.5707963267948912,-1.5707963267949,-19.025000965661803 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark14(-94.37815312026494,-0.2922631931272309,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark14(-94.41490339874719,-0.12562607319228852,-63.517936815546804,-1.0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark14(-94.47146535118048,-0.09038464096723647,-1.11174342475233,0.0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark14(-94.48320754811112,-1.5656322699714758,-1.5707963267948966,0.06256841148824581 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark14(-94.51621499781417,-3.552713678800501E-15,-48.59391292424018,2349.7015469514163 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark14(-9.460638126839768,-0.00344926729643147,-91.85333580408108,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark14(-9.484343886530795,-0.3005291186333482,-45.22295261087268,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark14(-94.9308940032568,-1.1487320705748485,-32.69404656739321,1.0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark14(-94.99062964644064,-1.4160939373873362,-82.81809931509716,0.9264987164163109 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark14(-95.05266841897662,-1.4923906980934556,-7.459883147454249,-0.6997561640191812 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark14(-95.06232697790622,-0.36722438439349303,-2327.9011431549725,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark14(-9.512907421598157,-0.05395869354125371,-10.076989880901321,5.1187722477944675 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark14(-95.14552723181171,-0.46132037880920507,-45.78083437026683,0.35650739739177784 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark14(-95.14849783835868,-0.6310454630376248,-43.499348940704216,-2144.1223421528443 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark14(-95.50199846609777,-1.2601210441262771,-10.043232129312246,8.673617379884035E-19 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark14(-95.522527492135,-3.552713678800501E-15,-32.94375157987537,5.407190392783307 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark14(-95.60065421544587,-0.8036748195432198,-73.34710566330129,31.146145765530097 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark14(-95.61785248316748,-9.148002801849895E-5,0.0,-0.8284013562094404 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark14(-95.6574043737355,-1.0742406116359975,-64.90691079588473,71.9138577605635 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark14(-95.76019154962584,-1.5105022665490935,-100.0,1.0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark14(-95.8883923185055,-1.0798119269578426,-52.01335034155066,-0.40781405676774696 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark14(-95.91015159099986,-0.6314467063465252,0.0,0.0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark14(-95.95246983890682,-1.5707963267946887,-45.40268300531879,0.0315034531761423 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark14(-95.95842750726938,-0.031130203345193567,-1.5707963267948966,-0.08567803579252994 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark14(-95.97345766915241,-0.9197624932195582,-72.7389397356177,1.0000000061990366 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark14(-95.9909797046194,-0.4969303690901553,0.0,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark14(-96.05744204724624,-0.011338326870368818,-29.764966231453972,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark14(-9.621260385763511,-1.4628504126635786,-0.5464084585035562,-6.077163357286271E-64 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark14(-96.36815016090304,-0.7974613626395853,-32.65252271461727,0.05578914499169581 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark14(-96.39166807859357,-1.5707963267948963,-1.486313767866571,-1.0301085296143223E-16 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark14(-9.64040609749002,-1.1961364469634939,-39.8004738741303,-0.06255720682074219 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark14(-96.55143755242996,-0.03607200739159587,-1.5707963267949019,1.0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark14(-96.66348179027995,-1.508069630771454,-89.88373017323013,-0.6923488699193316 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark14(-9.670718238495354,-0.7672882914824051,-23.990400954208127,21.017131503478033 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark14(-96.74444731560399,-1.5707963267948912,-3.0058595672820303,-1.0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark14(-96.77027845763342,-1.2815128647203515,-7.616129589681009,-98.59798598454361 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark14(-96.79422684282794,-0.7731150088247318,-1.5707963267948966,-1.4620849204026902E-11 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark14(-96.84129805941042,-4.440892098500626E-16,-44.10707258209365,-98.01747952521784 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark14(-96.97956282654606,-1.5707963267948948,-36.01507177190937,-1.0000000000000049 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark14(-97.0698470187966,-0.04461232485611734,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark14(-97.23182867591512,-1.3889173885072656,-0.2007510294421735,68.02809916793571 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark14(-97.39530536570109,-0.00671905968584996,-80.7601935800023,76.68957462023229 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark14(-97.58615032496215,-0.890018519115491,-8.924746488204196,1.0000000002557454 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark14(-97.60172538720529,-0.9749361207021081,-88.16068610806221,84.12080395202916 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark14(-9.766302363223375,-1.4584472045239079,-100.0,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark14(-9.767639317563802,-1.5707963267948557,-100.0,0.06243997062540879 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark14(-97.70730638498353,-1.0083598638582019,-33.5011717219694,-0.986262011581439 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark14(-97.93151343689678,-1.357504005455944,-97.31629672783582,-100.0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark14(-98.13583801405734,-0.7513538597369802,-131.2872739462253,0.35196344823057535 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark14(-98.15379422844089,-0.8376501194350108,-28.98099215788233,44.38579313861787 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark14(-98.17600474357266,-1.4550691704939371,-36.90017406450956,-0.7619426173287138 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark14(-98.3531421307532,-0.7185496311416293,-76.88200757850281,-2190.590056138881 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark14(-98.37083520013732,-1.1566571349918213,-1.5707963267948966,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark14(-98.38117404712314,-0.8058884136715929,0.0,-0.027949321448031972 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark14(-98.40718424399954,-0.0988616044694462,-88.47495490418578,1.0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark14(-98.41141723378914,-1.5707963267948963,-74.47128228090124,38.92624776227968 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark14(-98.54344253070073,-0.2657578805112862,-0.01891735809916245,0.9999999999999996 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark14(-98.63002309183022,-0.37564174235332065,-59.490494275980396,-1.0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark14(-98.76385203215256,-1.570796326794895,0.0,-1.0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark14(-9.880279733383798,-1.569664556339227,-26.600895123090453,-1.0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark14(-98.89093756293151,-0.5424998982792648,-46.75344303464249,1.0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark14(-98.89822210841166,-1.2958349522132608,-1.5707963267948966,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark14(-99.00991141837748,-1.3466968159299322,0.0,-83.53301209330547 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark14(-9.905547004940345,-0.013812886822560683,-34.631886191297276,-0.03794914427188184 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark14(-99.10110977202231,-0.05186294252678206,-35.56844489502147,-13.176076969929078 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark14(-99.20677988392359,-1.4136236468903498,-0.18296048523256436,-0.20365338118356213 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark14(-99.2180174086462,-0.4923952638396829,-1.4749644277471532,1.0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark14(-99.28674163092415,-1.2304760441732263,-96.64494459787758,-0.9999999999999999 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark14(-99.32513562478526,-0.5769517633301424,-66.30991264819693,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark14(-99.3730399383581,-1.3654918138532666,-66.51043940661725,0.01880203524959069 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark14(-99.4136116029797,-1.1888737457934107,-157.15294072845188,0.03415292196453623 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark14(-9.94914768258152,-0.18145179711899326,-63.25374320262859,-34.15494084321338 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark14(-99.49394719177059,-1.5529362367815185,-1.5568695295334969,-1.0000000000000002 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark14(-9.954187686166234,-0.8999436377057874,-20.218580281404282,-1.0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark14(-99.54662401728106,-1.0854745461221371,-80.78184322002903,-81.3051578287664 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark14(-99.63115938203029,-1.556050366204243,-0.4389135864067173,1.0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark14(-9.967902016547846,-1.5057222489126931,-48.54035416199181,-1.0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark14(-99.72546505427256,-1.5707963267948963,-37.427999802673796,32.71246693825992 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark14(-99.7512771740062,-0.3718124580590616,-53.81985947606152,-0.06255617097106911 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark14(-99.8102470076829,-0.04611648162638726,-0.8592227670270818,-1.0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark14(-99.84931182271235,-0.7392061835462584,-96.99647708347212,-1.0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark14(-99.85938665345934,-0.013810572218127131,0.0,-1.0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark14(-9.987918138224948,-1.0921708391461529,-83.01614560856069,1.0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark14(-99.92398895148013,-0.007241245319370235,-72.49315575624843,0.9545119065076179 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark14(-99.93447359138058,-0.9847667552481784,14.432649048861961,-100.0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark14(-99.94949194522125,-1.5707963267948912,-24.40883881298471,-1.0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark14(-99.97327131981748,-0.19523407188345465,0.0,-1.0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark14(-99.99999999732391,-0.5360913267863043,-64.3523279669889,1.0339757656912846E-25 ) ;
  }
}
