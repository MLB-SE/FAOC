import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(0.002386364514927814,8.399312020010929E-7 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(-0.003363267630721874,1.0193673304055628E-4 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(0.006921228340209756,7.0874956377927835E-6 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(0.06266597500069714,0.004616710958848556 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(-1.007033090822455E-4,2.085246228615061E-5 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(-1.0517866146198402E-8,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(11.21871882334715,27.80672689859147 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(12.973317021199865,37.02668297880014 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(-1.6406595228110111E-9,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark49(21.6813240174462,96.58061696364223 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark49(2.208230325424741E-37,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark49(2.3611307497146643,5.280961873191996 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark49(2.515721734663162E-16,1.5860962816635535E-8 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark49(2.582833209234005,5.24222826333154 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark49(27.73723949938922,84.59079139822961 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark49(-28.04049931171457,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark49(3.1586171318257925,74.97515410769137 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark49(3.9384808527323877E-14,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark49(46.33853464158736,90.5840644587575 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark49(53.42049358747457,19.454496970291515 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark49(5.7079646951313187E-5,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark49(58.78602621065073,59.178607431644544 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark49(-64.75525621346021,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark49(-6.92269246071761E-40,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark49(77.77881515177128,98.33626435410102 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark49(-84.27094602421073,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark49(8.888891774584977,63.69770426607499 ) ;
  }
}
