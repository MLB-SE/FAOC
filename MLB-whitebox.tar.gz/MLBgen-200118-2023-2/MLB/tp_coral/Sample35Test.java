import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(0.45801840127406024,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,0.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-1.2241365517234666 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,3.552713678800501E-15 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-40.19140624999999 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,41.91649937927693 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,65.2640427287795 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.009031108759 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.1043749812015 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.1666738137803 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.4306963999305 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.4700963649198 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.737396890312 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.7521739647443 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-711.058768318973 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-713.1437097143712 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-715.5037397555852 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-723.8687507224936 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-725.6273355993127 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-732.9192710342513 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-734.3010799942457 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-737.256143315202 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-741.553984658741 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-745.3997296722107 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-745.48333830666 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-746.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-746.000000004852 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-749.1914063770043 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark35(-10.0807173341571,79.68504713016381 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark35(-10.10193245029636,-39.81828556479425 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark35(-10.129561620690808,-711.8108012267733 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark35(-10.162331717442171,-709.2541138174699 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark35(-10.464969142191539,-709.8863741333647 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark35(-10.484281752789053,-709.7513978158199 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark35(-10.48960424092445,76.038821987011 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark35(-105.2421331646916,-748.7999693929061 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark35(-105.94816674413315,-709.5674542573173 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark35(-106.20528369582749,-709.9466773999723 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark35(-10.632366463617672,-746.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark35(-10.750653814000017,0.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark35(-10.774652177399616,-746.0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark35(-10.952087835721585,-746.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark35(-10.991845015055208,83.95077516615112 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark35(-10.992429189410872,13.418666147978987 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark35(-10.99612072318907,68.54926534881075 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark35(-11.09838894044293,-69.39973424086811 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark35(-111.33050065284654,-709.7889694151877 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark35(-11.134044951518728,-709.5742854450085 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark35(-111.52769502009713,83.40905935018529 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark35(-111.53026847494672,-745.9993318890153 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark35(-111.54838688031708,-709.9997341236748 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark35(-111.55797847770532,82.0848574712187 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark35(-11.498429356604618,-709.736221548309 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark35(-116.8925482808599,0.0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark35(-11.794221906556785,81.91272336108503 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark35(-118.18370184816303,-746.0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark35(-11.821964077872423,-709.6482202746854 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark35(-11.875865375548727,-746.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark35(-118.9323256482132,-1.0683606584992823E-14 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark35(-11.96552693808453,-709.7033132334049 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark35(-12.0757416528199,-719.8567855304158 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark35(-12.213645394340958,-746.0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark35(-12.244989024533396,-35.21304203787696 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark35(-124.08918054428759,-709.9155607213775 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark35(-124.26131914291662,-709.8705735182086 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark35(-12.4670104946575,-709.2609536199143 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark35(12.566370614359181,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark35(-13.318384568002742,-6.580867062410817 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark35(-136.65555812378028,-746.0000020294815 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark35(-13.755927044572246,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark35(-14.137166941154069,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark35(-141.84099825783497,-712.117160954202 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark35(-142.3747488271441,-745.999999230544 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark35(-142.49512749210493,-709.5299303228528 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark35(-142.94001515487614,-746.0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark35(-14.373577653001817,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark35(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark35(-15.750284710832062,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark35(-15.767434279381476,-711.0535397724068 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark35(-15.781834362538078,19.468581774405408 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark35(-15.872863258868335,21.327090960540815 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark35(-15.910174384937687,-40.191406249999105 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark35(-15.989903821779365,-43.69948859475428 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark35(-16.009059579321146,-746.0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark35(-16.058313932466135,0.0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark35(-16.061207136225807,-749.7582617957814 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark35(-16.10686887005926,-746.0000087499706 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark35(-16.13431095145461,-746.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark35(-16.147510105735876,-709.4313626041355 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark35(-161.69459316709876,-746.0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark35(-16.188449738716145,0.0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark35(-16.442778721280632,-746.0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark35(-16.476900674008974,-84.3462843816427 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark35(-16.589354830832704,0.0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark35(-167.9890620325595,-723.2360388810155 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark35(-16.80528629857048,-31.973319641413994 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark35(-169.24486654128677,757.3774866109144 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark35(-16.924844447587418,-725.1511041123454 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark35(-16.937010256278306,0.0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark35(-17.13512366061498,-746.0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark35(-17.19568534100617,-40.19140625 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark35(-17.256425488936703,-725.7034567731719 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark35(-17.282488867252983,0.0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark35(-17.458786576027904,-719.1164055809215 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark35(-17.463035904884066,-779.0727193342661 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark35(-17.497028316127,-95.05999640510963 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark35(-17.56426957228254,-746.0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark35(-18.03414357413314,-40.19140625 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark35(-18.17668143233469,72.24860938988954 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark35(-181.78773155140925,-746.1914062803027 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark35(-18.27163485639973,-714.2965473127024 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark35(-18.59262038121075,736.6138481156704 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark35(-187.60531611009014,-709.7456691773389 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark35(-194.44261420031745,-745.8775137505278 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark35(-20.839762540601114,-77.72484472798561 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark35(-218.344418696999,-745.9998558536074 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark35(21.926550243254468,-60.64951379649002 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark35(-21.962913681753122,75.9792888217855 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark35(-22.117563220911023,0.0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark35(-22.16816844523497,-709.8325203803686 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark35(-22.382776739993133,-100.0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark35(22.395334880570445,12.766225344335112 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark35(-22.418236332795203,-746.0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark35(-22.441924729270823,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark35(-22.474785813426834,-709.8356044180047 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark35(-22.682470023217533,-40.19140625 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark35(-22.890174895402332,-740.3418691972184 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark35(-23.041451766234573,-733.5662110735348 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark35(-23.253045102032097,-748.1914147319628 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark35(-23.363778108237625,-709.176039637446 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark35(-23.491341657784375,-746.0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark35(-23.51123386289474,-709.3181176959018 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark35(-23.566223802939362,-709.7604363701353 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark35(-23.615325378122193,-22.712175604514 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark35(-23.6298691896288,0.0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark35(-23.756705474611948,-709.652011984115 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark35(-23.8234693454733,-709.043551275754 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark35(-24.120095860146918,-14.462262817563712 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark35(-24.14859128157609,-713.6371946181534 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark35(-24.168710451227042,39.62483265178821 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark35(2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark35(-24.70811633538122,-14.876537933318687 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark35(-24.826374846516103,35.13207749124135 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark35(25.13274125852067,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark35(-2626.7169244950314,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark35(-2717.0845511967814,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark35(-28.274333897209303,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark35(-28.35150577010681,0.0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark35(-28.364708837383333,0.0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark35(-28.417539101819017,-725.9084161750004 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark35(-28.459128704101573,-722.8739407417287 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark35(-28.49299855976753,-745.7701905080912 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark35(-28.516038977086822,-709.6759826526702 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark35(-28.688514756817256,-746.0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark35(-28.887300087308006,-719.2238944983475 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark35(-29.166691678525268,0.0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark35(-29.180904233170963,0.0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark35(-293.7351844882919,135.3692033818781 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark35(-29.502550935622992,-40.191406249998494 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark35(-29.668669648876982,13.334536124074752 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark35(-29.799392429461747,-709.1309062064432 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark35(-29.807095877510726,-709.3166121012039 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark35(-29.841400936593956,-710.0813517423135 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark35(-29.841400936593963,0.0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark35(-29.841844943496387,0.0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark35(-29.845914530150026,-742.0760694385099 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark35(-29.8477600497419,-747.2091385308111 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark35(-30.231946269355433,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark35(-30.273490318031634,-34.41386858288877 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark35(-30.343716313784782,-49.89754435996674 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark35(-30.567030576817643,48.88257069029507 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark35(-30.590605434306422,0.0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark35(-30.855255021750082,69.22436425622499 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark35(-30.958854289304,-88.2068538039714 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark35(-31.074572106642037,-746.0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark35(-31.081817363430233,32.10846316316167 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark35(-31.088825913774485,0.0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark35(31.348605021777445,-22.78189933424619 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark35(-31.4159265358973,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark35(-3.1486806085737986,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark35(-3.148692011666872,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark35(-3.197754323922177,-726.318261317574 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark35(-3.2346857651127294,-709.3366925857351 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark35(-32.494791070008944,-75.1467475683079 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark35(-3.3294141461176707,-43.49333888155633 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark35(-33.93101951790227,83.96866622635619 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark35(-3.410159707898771,-732.2708834476954 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark35(-3.4413805070423678,-714.5171782132676 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark35(-34.66103714312717,-709.6224013812113 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark35(-34.728324899389975,-41.91192780329778 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark35(-34.783501661803754,18.40335759061236 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark35(-34.791813219862775,92.62675915653571 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark35(-34.85925309228574,-746.0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark35(-34.88092865549363,-53.25312085683489 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark35(-34.903167029976956,42.540378799950645 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark35(-34.944478010653455,-741.0553070106655 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark35(-35.028164119080515,0.0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark35(-35.047155830954495,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark35(-35.04934373405149,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark35(-35.11478751589017,-55.3412306613664 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark35(-35.18820020330455,-746.0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark35(-35.44020650240725,752.3477554190353 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark35(-35.45344461340396,-710.0129364626767 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark35(-35.538624594342565,-727.2361423857626 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark35(-35.59098921542967,-744.2892505650926 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark35(-35.70307352448536,-746.0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark35(-35.82198256386291,-1.494140625 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark35(-35.860530956402,-746.0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark35(-35.878696847175874,-12.65925057864925 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark35(-35.94826311909974,84.8500649508814 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark35(-3.6021069679894424,-749.8015073613736 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark35(-36.124586243773535,-9.167850345136754 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark35(-36.12525420032858,0.0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark35(-36.12581454348176,-709.933018961789 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark35(-36.12884044204159,-44.63043688066284 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark35(-36.13204478879176,-40.78672616382243 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark35(-36.13204478879177,-717.6073563858988 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark35(-36.202650902501766,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark35(-36.56574124051435,-746.0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark35(-36.79428759504078,55.98073572578727 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark35(-36.79797574739094,0.0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark35(-37.21713197334786,39.606688027124875 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark35(-3.721734663361161,77.79107278056011 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark35(-37.48078860493391,-746.0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark35(-37.604109074814595,-68.29940796568587 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark35(-3.778789172857728,-746.0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark35(-37.85671342452224,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark35(-3.9052710335900684,-747.1914062501976 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark35(-39.394652433090016,72.01144660825776 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark35(-40.85296209368734,-717.6584209122834 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark35(-41.054089319508115,733.2285630324674 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark35(-41.16411124044639,-38.23658290273644 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark35(-41.18033627267478,0.0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark35(-4.120631333506623,-742.4382807596407 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark35(-41.23227963541878,-709.172028279834 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark35(-41.285653841408674,0.0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark35(-41.35007749351453,-745.2675742728552 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark35(-41.408988401251335,-1.9224857217161428 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark35(-41.43419185049084,-709.9512658274664 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark35(-4.147278380451482,-73.56165068149696 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark35(-4.1503573415220725,-731.683532256763 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark35(-41.53960726311623,0.0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark35(-41.596433493766206,-709.7435443434127 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark35(-41.65005130202859,-746.0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark35(-41.80358575275738,35.725729703122965 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark35(-41.83297460444032,0.0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark35(-41.840260163116106,69.86645973734232 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark35(-41.9975263850598,-100.0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark35(-42.15764237749602,53.42791087610394 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark35(-42.2089721194635,-746.0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark35(-42.28111497934597,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark35(-42.39599514048409,716.9312007532302 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark35(-42.406042050155605,-745.9999994608058 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark35(-42.542304963535294,-746.0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark35(-42.549830058730585,50.1504095786963 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark35(-42.55968486943513,-746.0000000191633 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark35(-42.579473537056145,-746.0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark35(-42.648701481713026,-746.0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark35(-42.67164730756983,0.0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark35(-42.67495941809907,-40.19140625 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark35(-42.69116359474261,-746.0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark35(-42.697060154643715,-746.0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark35(-42.70230330188882,-746.0000130196502 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark35(-42.747850581505595,-746.0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark35(-42.79338709890679,85.2399931752582 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark35(-42.80296598424763,65.36876136844907 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark35(-42.83539513481632,43.43100530304572 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark35(-42.912559844149236,33.00556263450986 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark35(-42.920177176203424,-40.19140624999776 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark35(-42.94568910083581,89.21496507191063 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark35(-42.96733505567496,64.39390015076816 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark35(-4.3133882153625365,752.8888318141555 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark35(-4.31478567092087,-746.0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark35(-4.316588506212398,-746.0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark35(-43.37138299342396,0.0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark35(-43.68401191747986,714.1843685957826 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark35(-43.734308336626675,0.0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark35(-4.483890245115418,-746.0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark35(-4.489032164420482,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark35(-45.06944593830049,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark35(-45.06998577262089,-66.7547676371702 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark35(-4.508879171859974,-746.0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark35(-4.5127502972074325,-724.2987136180782 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark35(-46.22965859052248,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark35(-4.710109893644065,-710.225765484581 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark35(-47.14117894474039,-746.0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark35(-47.1508544338878,-721.7115745748124 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark35(-47.31892617504619,-746.0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark35(-47.4249005311689,-711.229316148253 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark35(-47.49116357576768,-746.1914366163325 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark35(-47.641153544087715,-12.97195711082226 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark35(-47.74222282420495,68.31018359103726 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark35(-47.753825835996,0.0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark35(-47.784711152938385,718.6954938235041 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark35(-47.87100746085373,-723.9304033085313 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark35(-47.90927697292742,0.0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark35(-48.11099735612918,732.2799610352008 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark35(-48.13032177913963,0.0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark35(-48.150309764046014,-40.19140625 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark35(-48.21550018191783,-746.0000744197062 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark35(-48.221860791820134,-91.090435399905 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark35(-48.35388837967132,-709.9996407076621 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark35(-48.44955246816516,-39.01744869144844 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark35(-48.480546062052774,-730.0454932463851 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark35(-48.547459019784235,-87.3890136519649 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark35(-48.643854773955255,25.966097374922704 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark35(-48.69150209311792,-100.0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark35(-48.69232307964987,100.0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark35(-48.69841540315086,100.0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark35(-48.73314224801336,0.0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark35(-48.7680332559801,-745.9999983393599 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark35(-48.806160818888564,78.28312900118077 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark35(-49.14090343139614,-725.9806590654454 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark35(-49.26123905707447,-40.160565168773914 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark35(-4.933721894577744,-44.27294010693083 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark35(-49.34581551747922,0.0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark35(-49.437301946227684,0.0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark35(-49.47813787520709,0.0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark35(-49.57035124140481,-746.0000000843709 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark35(-49.630461051724104,54.99482960293014 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark35(-49.72958191826824,-54.677099580401254 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark35(-49.743316510689084,12.338365113269077 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark35(-49.77628002869696,764.8176508369385 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark35(-49.864111305904444,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark35(-49.89109529661051,-746.0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark35(-49.931874045247035,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark35(-49.96529939740598,-747.1914063286076 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark35(-50.02344293964454,73.58841824549204 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark35(-50.02755396691618,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark35(-50.132719862544356,0.0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark35(-50.7932527529503,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark35(-52.35546126245656,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark35(-52.61625642479777,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark35(-53.518613095397406,0.0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark35(-53.52649773194773,-746.0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark35(-53.54159955836024,724.8646335031755 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark35(-53.63317426207745,0.0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark35(-53.63941648729582,-709.9106550820171 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark35(-53.714968211295734,-746.0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark35(-53.81189442179828,-746.0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark35(-53.85860263248061,-85.31674372003266 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark35(-53.92992739082809,0.0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark35(-54.046454826849,-709.9980041434538 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark35(54.07057455823676,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark35(-54.07789842212374,-709.8263902666234 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark35(-54.14954954167983,29.218468745372576 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark35(-54.20875876395312,0.0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark35(-54.24735715097091,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark35(-54.36995083388223,-38.527337231964 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark35(-54.381125772223015,-746.0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark35(-54.41173275950627,-49.41112449154636 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark35(-54.476148095973365,-47.790281836770745 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark35(-54.507006192236716,0.0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark35(-54.513413969617915,0.0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark35(-54.58392618620371,-709.9899698240805 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark35(-54.67248574198176,-726.5818047478485 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark35(-54.68774557931957,95.3842668941349 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark35(-54.692545432856434,0.0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark35(-54.949921838540284,-709.4015409070148 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark35(-54.97902400192728,-745.9999999951654 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark35(-54.980501278460196,-747.7927091452697 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark35(-55.00863771075322,-746.0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark35(-55.01813924578501,95.52713386508611 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark35(-55.043365168791496,-750.5577903324648 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark35(-55.07698943073655,-746.0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark35(-55.1627847639248,-746.0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark35(-55.22276760837833,718.0262744727834 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark35(-55.269719674647305,93.00928860565813 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark35(-55.28104929033836,-746.0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark35(-55.30532254702636,-751.8531208324645 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark35(-55.313421664413355,75.33385858125277 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark35(-55.3258867858476,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark35(-55.32682245002522,-746.0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark35(-55.42637302170106,741.771490722663 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark35(-55.447739386084024,97.9583897308524 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark35(-55.498115245628085,-746.0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark35(-55.525851539098504,-746.0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark35(-55.710639138335495,-751.2017477067213 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark35(-55.72122760371836,-100.0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark35(-55.9906632993002,-746.0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark35(-55.99760409703447,-746.0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark35(-56.03312544799084,-746.0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark35(-56.09892052932165,100.0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark35(-56.10921427880642,3.2652333335361092 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark35(-56.15924289297371,-746.0000026034635 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark35(-56.25011772116319,100.0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark35(-56.25423999792967,67.75993705017248 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark35(-5.629485637140986,-708.7750562191101 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark35(-56.36427895334894,-746.0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark35(-56.4196865538553,47.53940944331558 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark35(-56.56473141891203,12.649251648582307 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark35(-58.75576216366245,-45.46354037694418 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark35(-5.917015655371102,-746.0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark35(-59.32304838779383,-39.554009898812346 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark35(-5.957432415954017,32.7969410840677 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark35(-59.652861041240214,27.86383867222102 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark35(-59.80956682783041,-709.1402944609308 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark35(-60.040043675249464,74.5934005518371 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark35(-60.14619227947091,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark35(-60.190592422959725,-741.408408837512 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark35(-60.22273366292736,5.302666177533098 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark35(-60.30078396204601,-732.520331716629 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark35(-60.34948541596553,-746.0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark35(-60.354279155025516,-69.55068864750854 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark35(-60.41982521763308,-709.6045626033986 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark35(-60.51981678593814,-71.92918309989702 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark35(-60.5626479927704,-46.246767665496314 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark35(-60.596587314693906,0.0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark35(-60.6072872914535,-51.643525609965835 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark35(-60.64466949929581,58.772719238583704 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark35(-60.81070910171273,-746.0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark35(-61.00930184030406,61.160947542553856 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark35(-61.07444866242932,-727.1241355364514 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark35(-61.13228222894268,-1.3725366041955755 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark35(-61.24695338617967,-709.8220529438966 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark35(-61.248351494013065,0.0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark35(-61.25732747249138,-713.5444449583273 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark35(-61.257327472491944,-709.552577755616 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark35(-61.2573577830891,-746.0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark35(-61.26079446769098,-745.9999999999998 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark35(-61.42382700953177,-709.9097825895966 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark35(-6.145402622469831,0.0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark35(-61.65391555379424,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark35(-62.28482742344866,0.0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark35(-62.43891022044381,1.9970175190422594 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark35(6.28318530764525,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark35(6.283185313034588,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark35(-63.11081204809981,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark35(-63.28351388658684,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark35(-65.89554902896131,9.44897466311869 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark35(-66.32139827471767,-746.0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark35(-66.35514305622308,-746.0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark35(-66.37933186493042,0.0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark35(-66.4559447656847,-727.7661449663126 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark35(-66.49333129168915,-709.1327404551009 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark35(66.5144928176625,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark35(-66.60765316436434,-709.6474988342648 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark35(-66.70608899466882,-746.0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark35(-66.73117001156001,-731.1789810211127 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark35(-66.76994082506698,-709.3725547882276 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark35(-66.80872436334198,-709.0784706625473 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark35(-66.85178240331383,0.0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark35(-66.85486804553102,-709.5901882662753 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark35(-66.8903115620177,82.67555306868029 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark35(-66.92993558277931,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark35(-67.02628280255087,-93.80037655988302 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark35(-67.14935857074049,-48.70075305255295 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark35(-67.20715201626788,-709.5073626065268 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark35(-67.22947401493565,-55.21942522200156 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark35(-67.35905346507762,-746.0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark35(-67.48833635591622,-746.0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark35(-67.49420304334684,-709.0188598609046 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark35(-67.5005027685241,-747.1914066345083 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark35(-67.5266967598088,0.0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark35(-67.5418831960971,-709.5256236421819 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark35(-67.57357249226506,-709.1900877585723 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark35(-67.9559068020213,82.9455778601666 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark35(-68.11814652634432,-720.0253822653173 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark35(-68.2572186656798,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark35(-68.25969260162282,0.0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark35(-68.33397950226698,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark35(-68.36966677715937,-21.846561712631257 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark35(-68.52220821932941,76.47375825594935 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark35(-68.57263219318459,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark35(-68.74357181780071,-40.19140625 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark35(-68.77425821796933,4.7534884216401565 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark35(-68.99292038269243,-723.2641224819739 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark35(69.50936061687608,13.02804854872332 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark35(-70.72717563849767,14.78580731953869 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark35(-71.17835843829998,88.152193854801 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark35(-72.25673569434436,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark35(-72.26644063202232,-709.0793483942618 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark35(-72.38051662060718,89.31673875263647 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark35(-72.54628071063863,-73.49055555295348 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark35(-72.66302289971813,37.52081795933461 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark35(-72.8177196620833,-69.85020318387481 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark35(-72.92625663779984,0.0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark35(-72.97990467817482,-709.6256701248857 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark35(-73.11243849412845,-709.4669197583121 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark35(-73.1367675858224,2.8257612719246907 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark35(-73.20087467327174,-745.9999969205318 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark35(-73.24504887624686,-736.7213783080739 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark35(-73.41601991639344,-746.0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark35(-73.60517129556249,-709.9469633803055 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark35(-73.63453656960328,56.87857911044486 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark35(-73.64775961521974,-709.9001560636166 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark35(-73.72232498230717,-709.8779182984009 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark35(-73.77104589178137,740.481901526796 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark35(-73.80063641196601,-746.0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark35(-73.82495961720964,-787.2574689786462 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark35(-74.05204883538774,-723.9937619138135 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark35(-74.13193335098933,-1.494140625 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark35(-74.20763773517912,-746.0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark35(-74.36827845088838,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark35(-74.46413630094833,53.7104122167278 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark35(-74.49247018270171,34.68014214519397 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark35(-74.75555366752758,-709.9887454839529 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark35(-74.76452364239515,75.1873853107233 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark35(-75.03330153942605,-746.0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark35(77.16068537335076,-40.2445354655421 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark35(-77.42558064513518,39.08400625746077 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark35(7.853981633974483,0.0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark35(7.853981633974486,-66.43454839034506 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark35(7.8539816339930635,15.468101975024204 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark35(-78.68287546429347,0.27572045127737965 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark35(-78.74381490358397,0.0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark35(-78.80188006635476,0.0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark35(-78.93708588247617,-55.37161369233785 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark35(-78.93793006932194,-745.5547483853113 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark35(-78.96554628852006,-18.78198741906172 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark35(-79.13686154692613,-709.820679133456 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark35(-79.19675946699829,-746.0000000002916 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark35(-79.32627965726549,-721.839186988571 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark35(-79.34922659721879,5.0639648717332815 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark35(-79.41839228456735,0.0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark35(-79.56242583084213,0.0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark35(-79.69702374209282,35.2552087291721 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark35(-79.74997181904284,0.0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark35(-79.78182940454329,-25.211815126853423 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark35(-79.80191217528207,-709.1614228025071 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark35(-79.81113547748106,14.339353448207135 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark35(-79.90673488585982,-40.19138170063997 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark35(-80.0856707714167,0.0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark35(-80.11066585902577,0.0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark35(-80.11091261842988,-746.0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark35(-80.11149538164658,-757.4349638535906 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark35(-80.15462518891347,-747.19140777594 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark35(-80.21890319989589,-746.0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark35(-80.3513154525435,27.51833134663522 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark35(-80.58407737177916,-746.0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark35(-80.61843126992636,-3.7212514096235196 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark35(-80.77178878561577,-33.763474741675964 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark35(-81.01603104383273,-709.2868857253798 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark35(-81.20261924592884,731.9973757201304 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark35(-81.35515700088216,79.65214018670767 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark35(-81.50730087651593,-746.0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark35(-81.66141823391659,0.0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark35(-81.84386109431546,34.396154648201104 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark35(-82.48134253185827,-59.62467764375838 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark35(-83.36527888301134,-50.05084098700656 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark35(-84.83370927048097,-710.3059545969876 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark35(-84.87945389816419,57.54754047222127 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark35(-84.984856965741,71.79885040623651 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark35(-85.4001342663465,-733.9002647366717 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark35(-85.4723024671795,36.35904743284871 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark35(-85.55495337143542,-725.8660687974758 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark35(-85.67730334378636,-771.325043717953 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark35(-85.77701801817832,-746.0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark35(-85.84922648861533,-713.5726129859426 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark35(-85.99051647303315,7.762615549928853 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark35(-86.00857132531972,-31.091165906148618 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark35(-86.00960437838619,-709.988742791811 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark35(86.12699861567754,-72.32681651693973 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark35(-86.25165285815287,-769.3098634477332 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark35(-86.31953872759944,-1.2185338011460356 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark35(-86.39006870121018,-3.0304665421775763 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark35(-86.39116813308932,-803.2076345090444 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark35(-86.39545026577541,-709.39458396366 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark35(-86.44547602628887,-743.7949659611787 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark35(-86.45392435197866,-712.9362916461337 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark35(-86.45920353700907,-709.644575264805 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark35(-86.6174761321959,-745.8392396203303 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark35(-86.64288720270889,713.6959095602513 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark35(-86.7056075873326,-746.0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark35(-86.7625427942076,-709.370546282869 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark35(-87.07898871631016,-746.0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark35(-87.19548185056945,-746.0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark35(-87.23918401718602,0.0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark35(-87.2682727541343,-6.026150700075021 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark35(-87.47051686657316,42.909814006226526 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark35(-87.73743047204417,-715.4851018305093 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark35(-87.8153787966347,0.0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark35(-88.52160753745856,20.121297627447248 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark35(-89.30626088991471,82.61944824088997 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark35(-89.56650590465627,16.533933356852074 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark35(-89.76646487505766,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark35(-89.86474805735682,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark35(-91.10618695503533,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark35(-91.3989781646006,-67.75688190594558 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark35(-91.44615855122706,-726.7728705390351 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark35(-91.51611107416421,-722.377520354367 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark35(-91.52606713416746,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark35(-91.56707085163755,34.79655795335901 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark35(-91.97164875839358,0.0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark35(-92.35629985962473,-746.0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark35(-92.38508038685565,-745.1944004507966 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark35(-92.47492786447499,-709.3114258201218 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark35(-92.58637693055705,-709.906149847708 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark35(-92.61174379583399,-746.0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark35(-92.63372542862753,-1.4941406249999998 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark35(-92.63996896428091,-746.0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark35(-92.67469653759103,-62.865737356856854 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark35(-92.68071255340796,53.26386279455781 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark35(-92.68071255340797,-709.4265840573133 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark35(-92.94791316381783,-95.35348848817782 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark35(-93.08569527027409,3.552713678800501E-15 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark35(-93.14685627871484,-3.894089528029099 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark35(-93.38588822142601,-7.390499074864238 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark35(-93.3971740784753,-746.0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark35(-93.46074658451691,-744.1572133847324 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark35(-93.91282549342053,0.0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark35(-9.396788839458424,40.50889731878172 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark35(9.424777960766686,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark35(-94.24778026291224,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark35(-9.481519451203098,-743.3939179401087 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark35(-9.564265588232601,-81.67460438354057 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark35(-9.583380012161697,-746.0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark35(-9.621963157051212,-709.5149731229284 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark35(-9.683064357035601,-745.9998105704558 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark35(-97.40225907340682,-746.0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark35(-9.745871495807052,-727.1276314555623 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark35(-97.62085764376937,-709.9291920892412 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark35(-97.64334598918056,-746.0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark35(-97.72217448804363,-709.8662141310872 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark35(-97.79227795727358,-746.0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark35(-97.81969768568301,-727.030860237225 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark35(-97.84256524920086,0.0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark35(-97.84557752401062,-27.005200872598436 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark35(-97.90348716541118,-77.90975758531704 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark35(-97.95064139695444,5.736709527998187 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark35(-98.04102601830344,-709.9698600797898 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark35(-98.09129036342017,-709.7103383786965 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark35(-98.11868242254445,-47.95996173816342 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark35(-98.12263523631768,-709.5035697192139 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark35(-98.15981798241805,10.155743583355274 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark35(-98.19085147098995,-746.0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark35(-98.19514116300772,-709.5182682986954 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark35(-98.1974380835409,-40.19140625 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark35(-98.23181367380549,-88.91324295232369 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark35(-98.39944708467105,40.28641837232868 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark35(-9.843584319387631,-746.0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark35(-98.52654885392877,-709.0659263936446 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark35(-98.55864074051807,96.92393188265268 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark35(9.865567874979718,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark35(-98.8908060764505,-46.85566345755993 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark35(-98.89197678767896,-718.9932826024044 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark35(-98.9023336797356,-709.9929303328325 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark35(-98.94642575120601,-76.79178682173335 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark35(-98.95643931556943,0.0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark35(-98.9575387474397,-791.5685701789007 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark35(-98.95804622439643,-736.7312043403226 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark35(-9.90969523442216,-4.357042391465853 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark35(-99.1017606189778,-709.9974462917778 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark35(-99.25883634196731,-746.0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark35(-99.48320718921687,-750.6416562704501 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark35(-99.51219670356777,-746.0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark35(-99.51464898794444,-746.0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark35(-99.60095443782322,-746.0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark35(-99.67623379858227,-716.5801140971242 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark35(-99.84167649471918,-100.0 ) ;
  }
}
