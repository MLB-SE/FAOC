import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(0.0010020378612693233,-0.5699782071035472 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(-0.0032506261542861736,92.85969921317488 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(-0.006464602631766944,48.398994152614435 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark01(-0.0069539542799815154,34.58728458780081 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark01(0.010364217297467409,-37.55500624372564 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark01(-0.014945675173460366,-1.5707963267948966 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark01(0.022210221731937898,-0.21114835938879692 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark01(-0.025895264858586287,38.0835129217965 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark01(0.02735211424645956,-0.4630229915969258 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark01(0.02822500494788119,0.23814109090721747 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark01(0.03689914998566168,0.44186738815290394 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark01(0.03776726345581795,54.97787363529438 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark01(0.0471421909627896,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark01(0.04850433821492117,16.186461161442843 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark01(0.04970325709425836,1.4795414263508183E-4 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark01(-0.05065073783366403,-0.4365509431061386 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark01(-0.06295916109820854,28.48065003888853 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark01(-0.065702001666187,1.5707963267948966 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark01(0.06639719824842594,-49.53748088044111 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark01(-0.07591723284610574,1.5707963267836937 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark01(-0.08242208426998232,13.807661975147568 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark01(-0.09236016156390292,-32.86053125440389 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark01(-0.0926982073041066,0.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark01(0.0948139790215663,0.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark01(-0.09571666038983806,100.0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark01(-0.1052328513180429,0.0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark01(-0.11806624283081829,-79.9421328571065 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark01(-0.12325833004390033,-1.2510230022490703 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark01(0.13305068895678174,0.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark01(-0.1413946617285069,0.49578862627800163 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark01(-0.1497592379656183,-90.86890831808836 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark01(0.15609785113620944,-18.634763891315288 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark01(0.17312336228343383,36.52804538772337 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark01(-0.17846347886833433,-0.5418888285978195 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark01(-0.18178447092711308,-1.5707963267948966 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark01(-0.1828805689145856,0.0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark01(-0.1832484047955694,-23.496515411687625 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark01(0.1854808299889843,-100.0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark01(0.19833818406985415,1.5707963267948966 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark01(0.2121078719857355,-41.22040508698095 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark01(0.2209164315095151,62.15712382935763 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark01(0.2220557109602816,0.0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark01(-0.24832589712883646,-67.66551867621843 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark01(0.2648683405241883,-94.2477796076938 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark01(-0.27017071558542227,0.0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark01(0.27287514286305253,-1.5707963267948966 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark01(0.2737371108058086,-72.31495506854687 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark01(0.28546829516682976,111.97755236411436 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark01(0.2924689691262117,-15.37424828610429 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark01(-0.3207077570760254,-87.44910389714248 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark01(0.3209066953121562,69.98890157150218 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark01(0.34231612278798407,1.0132404816184153 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark01(0.34802106136447764,-4.161196140448705 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark01(-0.3527933538103642,0.8479327624405425 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark01(0.35344042244598484,1.7685403124069836 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark01(-0.35799155170487185,-58.78652022874182 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark01(-0.39171671432037103,13.007953938230944 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark01(-0.3946119843861453,35.19562939627036 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark01(-0.39970451257477413,-0.6807415204957357 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark01(0.40206054918750234,31.828184534286624 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark01(-0.40476255673314654,-67.46962014499277 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark01(-0.407151919286195,-100.89285181235465 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark01(0.40725560737553224,91.65255372231283 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark01(0.4077835943582586,-0.9230078606063785 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark01(0.4154692729427491,89.94216302607848 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark01(0.4180397518363508,-76.4993386815191 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark01(-0.4187131492298249,88.97776429687715 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark01(-0.4202139759135689,-6.886233085038569 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark01(-0.4313909246264619,1.6243140052326658E-13 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark01(-0.43966528879440103,30.405960277448713 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark01(0.4471340124602379,-1.5707963267948963 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark01(-0.45304484582681925,77.16792920779771 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark01(-0.4655602289850771,20.341246182379308 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark01(0.506997594457788,0.0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark01(0.5142065792284853,-136.5175573985244 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark01(-0.5218353972447214,-50.57149808288859 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark01(-0.5380453606925215,-99.02084073017828 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark01(0.541834022955823,-0.9682324719322084 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark01(-0.5645754678600088,-23.56194490192345 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark01(0.5662776791357638,-1.5707963267948966 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark01(0.5746054685843142,-68.98169309315168 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark01(-0.5820012429055481,16.395385166761216 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark01(0.588150887597496,-76.13265953910066 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark01(-0.5895751474802582,1.5707963267949054 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark01(-0.5933394571756216,-2431.8636694774477 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark01(0.6058960275936158,0.8789101652772531 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark01(0.6080149852755898,-51.36623088455154 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark01(-0.6168487791714149,1.570796295223428 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark01(-0.6275881178020162,72.62180888892067 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark01(0.6346396647140295,100.0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark01(0.6420341502262721,61.872822070984284 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark01(0.651607512461279,-2583.530427274673 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark01(0.6516457727161705,1.1943394788508124 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark01(0.6519431378750423,-38.865725045153766 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark01(0.658534497733628,-14.04847907320395 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark01(0.6874909464564691,70.31177231410858 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark01(-0.687638483366837,0.0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark01(0.6974327730380411,67.91009717726928 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark01(-0.719066794969093,2585.0310622437432 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark01(0.7434694396448265,38.894622955379475 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark01(0.7479144324250769,23.13171483561071 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark01(0.763377287742653,-42.72525794453985 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark01(-0.7698097268562114,60.783348461287886 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark01(-0.7947858914694721,-0.5298827737270103 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark01(-0.7989104909229103,1.5707963267948968 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark01(0.8099013486246553,0.0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark01(0.8183699228188596,-61.261057380888 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark01(0.8359643718948,-34.09263883806852 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark01(0.864838010897734,-1.5707963267948966 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark01(-0.8920322847946016,0.0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark01(0.8945989707452335,-1.5707963267948974 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark01(-0.9067151753949405,65.07170311384357 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark01(0.9163962368984273,-0.10958189070835733 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark01(0.9400277269705568,-1.3605926424924044 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark01(0.9426633036152358,45.361041070062946 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark01(-0.9470305295762347,-32.98672286269283 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark01(0.9907001813427172,44.34344959044759 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark01(0.9987058119475227,100.0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,0.0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,0.0016461100312562052 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,0.2303983859199364 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,0.5706726847791984 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,0.9920263825526878 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-100.0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,100.0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,1.0545324951720396 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-11.482417898520389 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-1.2418305928196531 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-15.009543974188597 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,1.5707963267948966 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-1.5707963267948968 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,1.5707963267948968 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,2523.3061785465075 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,2605.9918318845957 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,39.10512611466858 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,58.01472086630574 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,6.429214110252485 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-7.210645429187174 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,80.11061266653974 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,83.03262098513335 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-96.957420869971 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark01(1.0017556080525907,1.5707963267948974 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark01(-100.49687092298412,-0.3028639669143801 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark01(-100.53209482778725,3.2229363838252336E-4 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark01(100.57097590308122,-157.43525867908616 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark01(100.60003118785727,0.3736850551691503 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark01(-100.7369308981651,-4.510468906555177 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark01(10.074878074648183,-0.570645167597872 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark01(-100.96658889941538,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark01(1.0110868428599675,1.5707963267948968 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark01(-10.11930034167453,93.48054149062315 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark01(-101.94763276331584,-37.74203667861119 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark01(-102.10065565561197,13.253295500960931 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark01(10.23518752019612,-9.465179017805113 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark01(10.284506801331588,-0.08826998996805424 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark01(10.295703443456603,35.56688342628664 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark01(1.0366379743576317,1.5707963267948966 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark01(-10.386267352680562,-71.87973019942481 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark01(-10.394319925653694,-82.76714506004652 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark01(-1.0411885187304225E-17,1.5707963267948968 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark01(-104.21287803922243,-4.712388980389026 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark01(-10.422595061509556,4.872786281593928 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark01(-10.42477796076938,-1.5707963267948966 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark01(-10.461929514998587,-1.497652928187558 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark01(-105.24276626434346,39.30115817022025 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark01(-105.24598373589424,-1.5707963267949037 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark01(-10.579494713324403,1.5707963267948966 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark01(-105.91260373715622,-1.5683605315732159 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark01(-1.062911517493745,0.0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark01(-10.633206555671308,36.19330093929111 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark01(-106.81437341794854,-54.97787143782137 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark01(1.0737981895901352,-10.99736085984996 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark01(-1.0748308610196657,0.0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark01(107.48909147941117,123.93638974135209 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark01(1.0756782517573682,-64.29016241136303 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark01(-10.776164254685227,145.58850270794605 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark01(-10.79600795720149,0.0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark01(-10.81246295073526,-95.73699908907149 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark01(1.0820901083771656E-16,0.0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark01(-1.0842021724855044E-19,-0.0011628563566229372 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark01(-10.873954812669794,-44.84571234878136 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark01(-10.89432860106902,100.0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark01(-109.00164523934076,40.532481857834995 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark01(1.0929011681064318,1.570796326794899 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark01(-10.992944446925359,1.5707963267948966 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark01(-109.950529881833,2.6249004475599875E-6 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark01(-109.95137868645205,-2.4920811740060386E-10 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark01(-10.998204128202543,1.5707963267948983 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark01(-1.1040770462834475,0.0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark01(-1.1051525649564997,1.5707963267948966 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark01(-11.125618834949787,4.743641051661404 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark01(-111.5247465012618,14.138143503700757 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark01(-111.53788193223832,124.0927556499465 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark01(-111.55905266563946,71.35895143836618 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark01(-1.1198928674305322,1.5707963267948966 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark01(-112.27706872116075,-44.061637193906314 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark01(-11.255171646430014,-0.037116353661546905 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark01(-11.259473032792599,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark01(-11.267056361617762,88.65267601445825 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark01(-112.74758682072687,51.11899754298644 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark01(-11.277810125952538,99.97609264400728 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark01(-112.93080960318362,11.982332110785599 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark01(-112.99687852342949,2488.443212372568 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark01(-113.02520131310891,1.5707963267949054 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark01(-1.1343233782705686,1.516547842759423 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark01(-1.1420426749248578,32.08762872091049 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark01(114.24520730861485,-89.54191762679048 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark01(-114.64118023626537,-45.15194141167014 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark01(114.66813185423962,-120.95283857522423 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark01(-114.86369520398361,-31.570374515626142 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark01(-11.499879223926428,22.361989885386095 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark01(-1.151445611306166,-61.26105674500097 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark01(-116.03455209158207,-62.79003920879103 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark01(116.1544965980222,-31.829554695433405 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark01(-11.641753284800373,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark01(-11.644838534379076,-1.5707963267948966 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark01(-116.7484329336172,89.59033800657657 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark01(1.1687602268420374,-34.90142398242364 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark01(-117.42701428882133,73.89983449863391 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark01(-117.63503388212037,125.34266566404304 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark01(-118.2748317932909,-4.8373889854300405 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark01(-11.871453861622504,149.5935743575415 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark01(1.1884495310138493E-8,22.887847936160103 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark01(-11.931550226840402,-9.868277940089342 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark01(-119.34818292516024,21.924510276072926 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark01(1.1958724880702885,0.4936228725154577 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark01(1.1961051973788184,1.9729452251521717 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark01(-12.023401402805934,-33.74235165468548 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark01(-1.203023630424202,-14.46560017302182 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark01(-120.87795687728989,9.793199293488739 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark01(120.94902714550192,48.69468528556785 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark01(-12.102974257170782,1.5707963267948972 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark01(-12.122446064909525,1.5707963267948966 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark01(1.215129531497007,-46.361974725580566 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark01(-121.69284863105433,-92.79439117745652 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark01(1.2208930086414607,0.0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark01(1.224575644150994E-9,-74.54920204353944 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark01(12.245795716531148,-28.856581549123433 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark01(-122.51630656190503,-94.24777960764237 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark01(-122.59322580895102,-70.70382256626391 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark01(122.63423676663244,-1.5707963267948966 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark01(-1.2344794783707158,-73.63571554078575 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark01(-1.2383122905325372,-0.2967797541771065 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark01(-12.400323085129914,72.47860694729516 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark01(-124.09136834484922,142.94246388940635 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark01(1.2483997442622468,2.0497750353513595 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark01(-125.13489413641335,-63.94569357149311 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark01(-12.520014191583803,44.4254952124424 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark01(-1.2523445829310883E-11,-92.67697275922593 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark01(-125.66370791128665,-92.67698328003678 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark01(-12.566373049353738,75.39677337485972 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark01(-12.56637351643989,-31.415787101743803 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark01(-12.566378246955058,56.54866776462859 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark01(125.66747218183313,0.07511239442505789 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark01(-12.568323739359219,-50.265588836942946 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark01(12.568477326252033,0.0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark01(-12.573859513981049,32.9068976125412 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark01(-12.597620614359174,-1.5707963267948966 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark01(12.598557613749131,-62.92844278045344 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark01(12.642161086044368,-142.94393737580933 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark01(-12.659046933222442,-1.5707963267948966 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark01(1.266048123826382,-4.755253481086914 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark01(12.678681879365968,1.5707963267948966 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark01(-12.717450597786126,2597.273835805843 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark01(12.743004965519305,24.456310995747415 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark01(-12.756351671756121,74.20178234905777 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark01(127.9058293889481,-8.906592423261884 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark01(-12.795214970112648,-16.603115538686733 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark01(12.79938777295449,-100.0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark01(-12.834861358271866,-1.5707963267948983 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark01(-12.839203071410935,4.440892098500626E-16 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark01(-1.2863810330636771,99.80854210468328 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark01(12.873733588651795,1.5707963267948966 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark01(128.80468464178412,0.0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark01(12.884153767171746,0.0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark01(1.2892936214369897,4.94566311631047 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark01(-129.51967505380094,-1.4104263663421797 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark01(12.956578415584403,0.0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark01(12.967318962687585,-94.24778267700624 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark01(-1.2977619562095057,-93.65662373460877 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark01(12.97856629850267,-77.19421915755831 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark01(-13.033950730476064,0.0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark01(-130.37605217264633,136.6592692551452 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark01(13.057083962826523,45.16551804880794 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark01(-13.19786832390721,-0.5517351801550695 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark01(132.28374278583823,-70.20184668127112 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark01(1.328138472600898,-1.175657231043136 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark01(133.5163348012442,-136.65928043115593 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark01(13.354188168246028,42.7069656030366 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark01(13.358385969952462,70.39345717331491 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark01(133.68915665050415,0.288122878377692 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark01(133.77306408826132,-93.37941182392177 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark01(-1.3379851497981008,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark01(13.38711132726256,4.979428939189366 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark01(133.92632487890387,-73.84171988134656 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark01(-13.398911551717902,45.11586069175275 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark01(-13.41243937363052,-1.5707963267948966 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark01(13.452341994805522,52.79321935374739 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark01(-13.462481826232846,-0.018238286355006635 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark01(-1.349437622348404,40.77344941777207 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark01(-135.0837111049698,-14.137197461548269 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark01(-1.3630544903110961E-6,-144.51255166479368 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark01(-13.661387690629894,-71.49087481564578 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark01(13.66141451422223,0.0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark01(13.67507890616842,1.5707963267948968 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark01(13.68248369028198,-4.837388980385565 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark01(-1.370864179963669,-23.628526412598614 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark01(-1.3741395752415997,53.19471586258675 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark01(-13.768309164692647,-1.5707963267948974 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark01(13.778880647618704,-0.26748363440037687 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark01(-1.3821264321868116,-7.074357129716881 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark01(1.3877787807814457E-17,-1.8152798525819818 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark01(-1.3877787807814457E-17,94.24888911088256 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark01(-13.959422775837693,-94.98067040664785 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark01(-139.64663387653837,-50.204935745227395 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark01(13.984761572541158,136.26399399106316 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark01(1.4033829120672323,0.5704277011789954 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark01(-1.4036844200435183,-68.94376421374584 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark01(-14.09364095603516,45.02160437506359 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark01(1.4096866742002827,-1.519918797548163 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark01(-140.97508552057988,0.0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark01(1.412985681378059,-83.23977982238597 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark01(14.134552669949908,-1.5707963267948966 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark01(-141.36856751584287,37.699111842620916 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark01(-141.37132964474284,-0.0027475860087645687 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark01(-141.371388202022,25.13274122746959 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark01(-141.37148794484492,174.35839215488048 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark01(-141.37166588983115,113.09731933172017 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark01(14.13979678179299,-1.5707963267948966 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark01(14.161965913604362,74.95958852585159 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark01(1.4278696579580124,1.4614821428352163 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark01(-1.4284531402154415,0.0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark01(-1.43415886053387,8.769746515153187 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark01(-1.43966757850081,1.5707963267948983 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark01(-144.5152268556226,-6.204965835528703 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark01(14.473903939917315,44.11969402117186 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark01(14.508948326170232,-45.16225523804958 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark01(-1.4509948450620556,-2461.84745044759 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark01(14.56104530259175,-73.80435960228112 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark01(145.64412776807677,86.79140251602644 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark01(1.4568474825909479,0.0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark01(-14.587481934983714,0.0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark01(146.08400913186367,4.712386403982604 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark01(-146.17311349180991,-16.821459650632896 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark01(-146.5045080574405,142.95405742069286 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark01(14.653956834667056,-42.33168911349179 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark01(146.85212325775413,6.762833874081793 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark01(147.15202181782337,-74.37204406156422 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark01(147.3127904137904,-63.67338409798435 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark01(147.37362224538714,-31.364880463007538 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark01(-147.49371669836694,73.82742735936014 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark01(14.750545492222532,-1.5707963267948966 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark01(14.765891960989137,-42.72013355162971 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark01(-1.4780739107725371E-6,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark01(-148.72104115782193,-93.29363460666492 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark01(-1.4880415825522959E-7,18.846982752678986 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark01(-149.22565104551026,-193.2079447448835 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark01(-149.22896252467294,-54.977871437818045 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark01(-1.4952175644276724,-1.6412376174373635 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark01(1.4974781842374472,25.373739883817407 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark01(15.006329791525813,-1.208380871229261 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark01(-1.5078540256481636,-1.5707963267948966 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark01(-15.08615555404785,-16.50560679204831 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark01(15.088152643586113,45.17906992679242 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark01(-1.5209512083298387,-1.5707999987932195 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark01(-1.5247104770779316,20.100154573001163 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark01(-1.5254404436956293,-1.3169185859144372 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark01(1.5296056028809817,-1.5707963267948966 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark01(1.5306543966051016,-45.10422933295999 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark01(1.531135360592403,2566.9524738582477 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark01(-1.5344585252836946,-10.729107665473762 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark01(15.382932402479696,0.0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark01(153.89519365489164,-57.95128419723861 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark01(1.5429543222880433,0.0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark01(15.4316995501503,-95.64569294409011 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark01(-154.32708905242632,-5.382013102551673 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark01(1.5486564388912112,0.0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark01(-155.0437692244351,-76.0944616210188 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark01(1.5554887334191014,-0.43743518755938837 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark01(1.5611754575055519,-1.5707963267948966 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark01(-1.5620347841342477,-63.579510678234264 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark01(15.6249040640718,3.708086080876288 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark01(15.64047796750635,62.93480921703343 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark01(15.654723068716685,36.128535804212255 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark01(1.5681664861560134,-1.5707963267948966 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark01(1.5681664861560607,1.5707963267948966 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark01(1.5681664861593614,1.5707963267949054 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark01(1.5681689495447133,-92.67698327436398 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark01(1.5682168832882655,1.5707963267949197 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark01(1.5682256976632627,14.137167096551641 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark01(-1.5684582562078329,-0.045739290553723215 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark01(1.5684989764505877,-89.53539145448886 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark01(1.568544068787935,-10.995573356714102 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark01(1.5686561111412476,73.82742617971829 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark01(1.5686964946416746,76.96902127918668 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark01(-1.5704483479521307,-17.079509285132943 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark01(1.5706775224437584,-36.12831200591551 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark01(1.5707139057641544,1.5707963267948966 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark01(1.5707469207806213,17.2787565372879 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707955748425366,-83.26116803728794 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark01(-15.707960781180702,50.26689723282696 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark01(-15.707963210163518,100.53325881521891 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963263570035,4.696838630507264 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267444884,37.22602181356247 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267927347,-88.42971689043435 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267938538,1.5707963267948966 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267945821,-49.67057982750161 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267947385,-85.15360957900653 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948186,0.0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark01(-1.570796326794838,1.5707963267948966 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark01(1.57079632679487,-26.70354052082736 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948877,0.4774674923164806 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948877,-21.398484009970204 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948877,4.712385458185582 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948901,0.0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948901,32.91521501025789 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,-1.5708001414921624 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948912,-30.640902755403772 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948912,32.52258345454304 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,4.4407815776971375 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,-94.25510266970718 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,95.62713840203389 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark01(-1.570796326794893,45.15533768949831 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,0.006314009889513217 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-100.0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,100.0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,12.516104286102347 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,-1.5707963267948966 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,1.5707963267948966 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-1.5707963267948974 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,18.166038489304896 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-2600.9856485629457 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-2.6868879300360824 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,33.068146517413474 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,43.134452018083806 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,43.29675414460538 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,45.410014529338035 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,60.352994599851854 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-60.63768536112654 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,72.69399520232042 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,-85.19828895577828 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark01(-1.570796326794895,0.0026298406382425786 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948957,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948957,-14.640134362430189 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948957,-1.5707963267948966 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948957,-1.5707963267948966 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948957,1.570818241236257 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948957,2561.768633844889 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948957,-26.071330984253933 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948957,-45.181872352593054 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948957,61.26105322276148 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948957,-91.99759065335206 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948961,1.5707963267948966 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,1.688713027240262 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,-48.281437918403945 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,-67.54423982985955 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948963,-8.977283559851012 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.002528893938145976 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.002579767009983352 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.0026290053588882757 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.014470811073108436 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.0276390900442619 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.048021300691353304 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.1393916628755228 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.19750123420706173 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.24733326510337067 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.35283293778040936 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.431332291892006 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.4376502227007215 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.4679039336052596 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.5227619732733093 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.52641362904726 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.5671518359490918 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.5707880081838425 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.5707950420703739 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-100.53096491486775 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,10.159684169257453 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.023336005306666E-15 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-107.99122182390371 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-10.960825345740465 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,10.995574287371934 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-10.995574287564274 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,11.011199287564278 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,12.408699297855733 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,124.15541028652501 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-12.461059826480634 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,12.463829283475825 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,12.56637061435968 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.2928508728932886 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,133.5176954283912 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,135.4863969272272 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-135.50187021654367 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,136.22897974817994 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,136.52451035175395 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-14.059177714567625 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,14.429203845578648 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-14.42929573234889 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-14.429403665747344 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,146.08503495442542 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-14.661750711525684 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5609748812306818 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5609812469120243 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.570796326794893 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5707963267948952 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267948957 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.570796326794896 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.570796326794897 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948972 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948977 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948977 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.570796326794898 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5707963267949054 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267949197 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267949294 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.570796326796767 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.570796326829018 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707964460041868 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-17.278759594743857 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,17.281978618838085 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.7758966638278304 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-17.9491468662344 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,18.483323813911618 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-19.782396224209336 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,20.115407267137847 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,20.732605915269858 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,20.754714877573686 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,21.040684584335942 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-2.118914367351939 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,21.593289762957994 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-21.991148575128552 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,22.281482506455514 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,22.77481685061044 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,2.281151845592781 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-23.442903626043716 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-23.56929965624031 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-23.585493517857987 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,2512.1121275837895 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-25.13274122872546 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-25.17436292586895 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-2520.6179511241085 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-2525.3860984711155 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-25.698866872478447 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-2609.328118716441 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-26.12353422973041 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,2622.3339854001647 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,2624.9796565994934 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,2631.068203200304 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-2640.568652922405 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,26.703537555513236 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-2.6785924974977298 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-28.556949704803912 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-28.91873073749026 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,29.122515924899936 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-29.845148855240392 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,29.918198423694697 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-3.0540472241473253 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,31.415926535896403 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-31.415926535900358 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,31.415926535901868 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,31.41592653591423 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,31.64404573763281 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,31.68442388122537 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,31.781768521962533 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,32.51426003987726 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-32.64437632952514 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-32.98672286269282 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,33.44025495607603 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-3.4903692130275793E-4 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,3.5011812167026673E-16 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-3.5388822985475343 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,35.39960551280055 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,3.552713678800501E-15 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-36.128315521578564 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,36.12832136998969 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,36.12832314567716 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,3.6457549845861905 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-36.75869696783132 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-37.50689196123933 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-37.582304187403054 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,37.699111843077034 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-38.332538360464696 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-39.26990816987241 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,3.931537393980325E-16 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,40.71572231387148 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,42.34007123078131 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-42.411500823462404 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-42.411500823477 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,42.63304900797782 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,43.783412757368154 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-43.982297150366364 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-44.38084528619208 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-44.4640549155841 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,45.136190102566516 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,45.15002275069768 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-45.387923464625125 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,45.553093477051995 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,45.553093477052 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,45.55309538440063 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,46.069349022697935 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-46.380302129748245 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-46.62299425217955 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,4.7123858324922185 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-47.71563500950103 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,48.69468260840231 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,48.694686130641784 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,50.26548245743844 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-50.91359275688503 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,51.50655529356723 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-52.04678743885471 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-53.3009312903924 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-53.48406202716774 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,53.80181236235053 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-54.27473468841932 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-54.97786792424706 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,55.10635592276747 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,5.542042893594668 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,5.57348148134831 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-56.54547128802943 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,56.54866776461322 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-56.548667764620866 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,57.24108899403037 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,58.71767114462327 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,58.74621750776146 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,59.51033640767018 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,59.61571255650095 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,60.0448165051439 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,61.26105366648176 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-62.83185307179391 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,63.46372266300636 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-6.43042661141303 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,64.40264939859074 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,64.63277709897285 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-64.66347049607049 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-64.87981055739571 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-6.533355583678122E-5 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-66.21919450015979 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,67.17676972167754 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,67.54423852994107 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,67.54424205218054 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,67.89754687209312 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,67.9366835921117 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-68.13290636577993 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,70.10735221683633 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-70.52310753015071 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,71.21256464399242 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,71.98666333850244 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-7.216740108103899 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-72.25425822843219 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,72.42561805101838 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-72.61711391555743 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,73.36710749949432 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-73.82742388074477 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-73.84305235936014 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,75.39822368614801 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-75.3982236861511 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,76.32909607046258 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-77.82687828011814 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-7.854012151552609 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,80.1106279253288 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,80.21430736035185 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-8.0514038303446E-15 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-80.76291192733134 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-81.68140899333426 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-82.46104306005675 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-83.2522053201295 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-83.2522091348268 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,83.25220913506531 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,85.30879809357756 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-86.39379445147982 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-88.1758276705195 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,8.881784197001252E-16 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-89.53539062730908 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-90.00409182646098 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-91.73995765164665 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-91.78198961800739 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,92.33823157616249 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-92.67698328089885 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,92.67698328089888 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-94.47759639526053 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-9.481939082520089 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,94.85428443746349 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-95.48038409012264 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,95.81857593448868 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-95.8185775665556 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-95.81869800642585 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-9.662282618993665 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-9.85995479060077 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-99.96973361085372 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948968,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948968,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark01(1.570796326794897,42.51495561104913 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948974,75.82791412515974 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,0.17485552187639042 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-0.3993629699282796 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,0.5024136764350634 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,10.70717756853528 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-10.995572959487655 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-136.65927690891652 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-136.65928042935212 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,1.5707963267948966 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-17.010370751553324 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-19.441007386900996 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,20.003335611169874 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-54.42209059317757 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-6.429830329282731 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-6.506354408467047 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,77.30790447358888 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-77.5359022470353 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949019,0.0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949019,-11.522171349004093 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949019,-4.712449274344454 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949019,87.84629128102156 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949054,-0.12163473332360263 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949054,100.0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949054,15.213810885629663 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949054,-1.5707963267948966 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949054,1.5707963269287433 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949054,-21.991148575128552 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949054,-48.6946861306418 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949054,53.84212239225158 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949108,-1.5707963268012277 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949125,-80.11061144284274 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949157,95.81857720961332 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949197,-0.9075956723770986 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949197,-100.0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949197,1.5707963267948966 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949197,-2649.917007609957 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949197,98.96016573378226 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267952323,-53.94467291385647 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963268003602,-39.06852479679954 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963268092626,-92.67697975865941 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963268755138,61.26105322276148 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark01(1.5707964276497302,67.54423852994356 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark01(-157.079779120174,-105.24335389307376 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark01(1.5708019338890928,67.54423857191031 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark01(1.5710984879918222,-1.5707963267948966 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark01(157.1182634560627,7.12045672974033 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark01(1.5713736240162304,-14.137170123695673 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark01(-15.717332292068349,-31.55840771813824 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark01(1.5729282925004202,-67.545817844483 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark01(1.5729660930124079,-14.137168056397114 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark01(1.5730111226297576,-67.54424103674833 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark01(-15.731292187965735,1.1351183037608958 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark01(1.573254017113279,1.5707967688749673 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark01(1.5734261674344432,1.5707963267948948 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark01(-15.74725772907025,0.0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark01(-15.773310230540611,-0.387028804219702 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark01(-1.5775387308015354,-42.86047114293044 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark01(-157.84606532948172,-50.00217156282908 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark01(-15.806520525187082,-43.460049016054214 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark01(15.819811639507705,-1.5707963267948966 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark01(-15.821848721479281,-1.5707963267948966 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark01(158.6477991419176,1.5707963267948974 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark01(-15.88325739691416,0.49999955056750395 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark01(-15.906414344330024,0.48019406713283985 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark01(-159.2666720156843,55.479506211209696 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark01(15.93772659351582,-42.462459382202724 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark01(-15.961979630080577,44.53279482229394 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark01(-16.005524118148614,1.5707963267948966 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark01(-160.21993980581632,14.13716713980684 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark01(1.6058087575029123,-14.429209002535018 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark01(-1.6072945753045388E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark01(-16.11943710035935,0.0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark01(-16.17689206137974,-19.519965701597556 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark01(-1.6297454082381013,-16.732809573874817 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark01(-16.306458667767913,-1.9582431699656544 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark01(-16.33814343145402,66.08785359621848 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark01(1.6343786427138154,-44.00925478090541 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark01(-163.99984884074422,1.5707963267949623 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark01(-16.430890992245168,46.41489759335886 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark01(-164.3808366163642,88.2482298979721 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark01(-1.6614962466131544,1.5707963267948966 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark01(-166.16309680073553,47.216312444425625 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark01(-166.50637735045447,23.476671673800826 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark01(-16.663571855305367,-0.5688436632367547 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark01(1.6744782089337906,-1.5707963267948966 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark01(168.04799716860782,14.43003155510037 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark01(1.684551813507901,-41.55213900392762 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark01(-16.910168621267985,26.328691375296415 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark01(-1.6947507057963693,2547.47061913743 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark01(-16.949007475760435,-4.837388980384708 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark01(-169.65131488204395,-1.0532263429374953E-10 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark01(-1.7015217280345933,-28.142437402620473 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark01(-17.050959322114622,-83.67317076881824 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark01(-17.115954410310486,54.942844411568245 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark01(171.93106736364382,-0.023869726314714512 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark01(-17.194684688457173,0.0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark01(-17.1965979349023,0.0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark01(-1.7243900372762597,1.5707963267949676 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark01(-17.24469110035581,-1.570796326794897 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark01(-17.276129754104975,-1.5707963267948966 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark01(-172.78561681562533,-1.5707963267948966 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark01(-172.78591533348853,-75.39822368684224 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark01(-17.279727421030522,4.712385950244474 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark01(-17.28117887299264,-73.82742682268174 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark01(-17.32797976594459,93.47665237881066 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark01(-1.734723475976807E-18,-1.5707963267948977 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark01(-1.734723475976807E-18,-42.41174496385523 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark01(-17.40174918254609,1.5707963267948966 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark01(-174.06094475188468,65.02258691099507 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark01(-174.12355414254858,0.0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark01(-174.37821722173166,70.53928737911528 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark01(-17.550996832649446,-62.94536527544115 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark01(-175.93114403170654,-6.224395584693039 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark01(1.7763568394002505E-15,-1.5707963267948952 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark01(-1.7763568394002505E-15,-15.707963267948966 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark01(-1.7763568394002505E-15,-3.1191794033799045 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark01(1.7763568394002505E-15,59.4836455381662 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark01(-1.7763568394002505E-15,92.6769840944539 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark01(-17.86432594543534,13.715213495136013 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark01(1.7880225906966383,1.5707963267948966 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark01(-179.10535559217305,0.003192797188485813 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark01(-17.983042114659394,5.212388980384693 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark01(-1.7996943775383585,-0.9156636280784214 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark01(1.802159257088899E-7,-44.4061136427001 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark01(-18.02576259145009,16.73683094673155 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark01(-180.48243569985388,32.85478406151583 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark01(-180.64122571608004,-4.7123889803845325 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark01(1.820507603762616E-5,31.514514960791814 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark01(-18.22481058591943,0.1248215694833773 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark01(183.25075734880284,0.1466049951799141 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark01(-185.3479373278084,6.204543739831325 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark01(-18.608844853339427,-5.458528326628922 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark01(-18.620144566634323,-49.37197126274392 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark01(-186.93204890631054,-61.26105674500009 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark01(-18.700740895129343,-78.61188466205971 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark01(-18.821243766077146,54.27697690911472 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark01(-188.42278446844978,-74.72316442420954 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark01(-18.84955781130212,0.0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark01(-18.849559443768033,-2.022464855266069E-8 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark01(-18.849559443775313,-75.3982235672649 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark01(-18.84961066116973,4.712374163134418 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark01(18.849730325080678,43.96345602913313 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark01(-18.849800142854715,10.995557843119355 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark01(-18.852501599050388,-50.265482459148515 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark01(-18.949656963687573,-83.97671198559047 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark01(18.965334309322188,37.67985486327217 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark01(-18.965430444482166,-1.5707963267948963 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark01(-19.09333691090916,-30.511399045144245 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark01(19.101829999382318,-67.33697393010144 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark01(-1.9104550918233656,34.921851825470014 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark01(1.9108692871845818,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark01(-19.121117209848173,84.48810328772984 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark01(-19.139391953416492,18.898527068074472 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark01(19.145132767852388,-1.5707963267948966 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark01(-192.0048516785722,32.55844966529747 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark01(-19.248428340049713,49.02282695725497 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark01(-19.29663329908578,1.5707963267948966 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark01(19.313765761009094,-1.5707963267948966 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark01(19.40087442703711,71.64508287948368 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark01(-19.44341255373463,-44.62047778923287 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark01(-194.7789886760432,1.20719068159156E-14 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark01(-19.517863893720577,100.0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark01(19.522405334130212,-96.35067247552539 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark01(-19.61235064336025,70.10115916454984 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark01(1.9619102418220677,100.0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark01(-19.680818299864058,-1.5707963267948966 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark01(-19.71047196365899,-9.485308199041526 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark01(19.748139628222148,-30.890399597230523 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark01(-19.755209345082278,0.002977936763669148 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark01(19.7630875814668,1.3609254229573462 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark01(-19.769526949637623,-6.660673924655485 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark01(19.84955592153876,-1.5707963267948966 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark01(20.017744062922436,6.151564787067144 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark01(20.042697159578424,23.710441812319075 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark01(-20.048225507048564,0.0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark01(2.0085587320986633,0.0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark01(20.217124371762132,0.0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark01(-20.217515012282746,-95.2856353278309 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark01(-2.0246020127352855,1.5707963267948966 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark01(20.297199054352944,-89.9709835737441 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark01(-20.335910929956444,-83.02164421246006 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark01(20.37143024405315,-1.5707963267948983 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark01(20.420361300465235,4.712388980210502 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark01(20.420941255532377,-23.561941571724756 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark01(20.42196430004221,-48.69468394724468 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark01(20.422982088971853,1.5707963267948983 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark01(20.44689723172307,98.96051796440527 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark01(20.502840935711774,1.5707963267948912 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark01(-20.573425434260017,2.2938082288872698E-7 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark01(-20.616046265394928,-46.67692128256229 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark01(20.636007272870696,1.5707963267948968 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark01(-20.688509263753474,-44.11582356252785 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark01(2.070796326795079,70.09683996293151 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark01(20.71318258480217,1.5707963267948972 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark01(-2.0737539396133823E-19,92.67698328007799 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark01(-20.781729038117188,1.5707963267948966 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark01(20.791399546314764,-54.09625287333117 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark01(20.811286654969095,-1.0030271033134994 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark01(20.8548625323576,-72.67422931995816 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark01(20.864265591642944,67.61068910119997 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark01(-20.89370466254475,0.0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark01(2.0906305218722565,56.87898991370062 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark01(-20.918273884759373,16.567178042058714 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark01(20.927719804285985,100.0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark01(20.928683460502686,55.70216964832275 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark01(-209.2971454716632,14.728607442361024 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark01(-20.976235694350535,-45.42520987353735 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark01(-21.1295549019381,0.0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark01(-2.1175823681357508E-22,-4.712374806016853 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark01(21.328068358949423,-2.9219892303469942E-5 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark01(21.34703286258693,-53.76312108301482 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark01(-213.62830046417585,1.5707963267948957 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark01(-21.430351699713594,0.0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark01(-21.441543532330556,1.5707963267948966 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark01(21.51897474200209,-87.1670579322876 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark01(215.19677152023473,-4.712387958385606 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark01(-21.551523077207662,-47.483432216840725 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark01(2.1568410012784796,73.37102117231653 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark01(21.58029059107636,-63.50569473597284 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark01(-21.609805440944804,67.59412165254764 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark01(21.61586212196356,0.0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark01(-21.64906280287216,26.222454157837692 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark01(21.676491083816572,-36.44475594660195 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark01(-2.1684043449710089E-19,31.872795506240664 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark01(21.6948959285142,23.740591998481506 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark01(-21.710137521730587,73.15247192557993 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark01(21.750002218713348,59.4705226877287 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark01(2.1800786546087925,1.5707963267948968 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark01(-21.857867607804028,-89.53545166476225 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark01(2.1898878438242093,-1.5707963267948966 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark01(21.902952720521483,0.42286166952537807 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark01(-21.925852054048917,100.0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark01(21.942235370969478,0.0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark01(21.94462324841838,0.0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark01(-21.949402389518696,-0.7885803452966416 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark01(21.951731816770646,0.2816683391550194 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark01(21.98050423392693,-44.02580215535151 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark01(21.985589996708747,-0.10550214577153737 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark01(-21.991145052889067,0.0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark01(-21.99114505288907,-81.68140899314537 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark01(-21.991148574324466,-36.1283115819755 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark01(-21.99114857512855,-1.5707963267948966 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark01(-21.991148577148948,0.0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark01(2.199816913299074,84.5853979840082 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark01(-22.04439942855676,0.0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark01(-22.16114518086157,-6.7517725313154955 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark01(-22.168640360132088,57.80204837223744 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark01(-2.220446049250313E-16,-0.2327464919254112 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark01(-2.220446049250313E-16,-12.563740773720383 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark01(2.220446049250313E-16,14.429207447770878 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark01(-22.24902757270619,-0.0022471464705014765 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark01(-22.31640969798312,95.8622918749943 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark01(22.33637586403083,44.55247973689879 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark01(-22.38562663421488,48.94135035537133 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark01(22.417479334883705,-31.62106035678012 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark01(-22.442173895491365,9.102061040661667 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark01(-22.61738431714638,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark01(-22.751789436910812,64.34065783576547 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark01(-22.91316346547498,-1.5707963267948966 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark01(-22.964134565117277,38.2058606374969 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark01(2.304639298408043,0.0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark01(-23.069688926932642,-243.7342742714348 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark01(-2.308928329519191,1.2470102922022521E-6 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark01(-23.430894004652302,-97.21929725142424 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark01(23.45276532388239,15.087238728666335 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark01(-23.561944901926886,23.561941379684004 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark01(-237.18764534655296,42.411500744704576 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark01(-23.8134624946793,50.58649866373207 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark01(-23.861795188847722,20.569510932448168 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark01(-23.893244511776135,-18.003153000264888 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark01(-23.89751249301048,1.5707963267951026 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark01(-24.050761359940225,1.5707963267948966 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark01(241.55104086444078,1.5707963289891755 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark01(-241.89943463340023,61.26105674498307 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark01(-245.04425749788345,-64.40313792567238 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark01(2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark01(2.465190328815662E-32,0.0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark01(-2.465190328815662E-32,-1.5707963267948977 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark01(-2.465190328815662E-32,-20.420352248333657 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark01(-24.72950206026958,-0.4863661825706143 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark01(-24.756943908836867,-0.8853925210218371 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark01(-2.4799054408916277,0.0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark01(2.4822181303011632,0.0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark01(-24.847660179067717,0.0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark01(-24.92567494178846,7.405515531378387 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark01(-2.498066190328827E-16,-0.0026298406387982053 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark01(-24.985974103263644,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark01(-24.994145109504885,0.5488686860694637 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark01(-25.00859441604952,-3.2038674992907517 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark01(-25.132741228718363,-1.5707963267948966 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark01(-25.13274123764436,-1.5707963267948966 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark01(-25.136647478718352,1.5707963267948966 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark01(25.143221466540712,88.48879542771238 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark01(252.8981708358638,-45.55504747554264 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark01(25.289994738639137,0.3007852634024687 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark01(25.29385345563978,-136.19430235574907 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark01(-25.310986720878503,-41.498378701726345 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark01(25.35204023603905,2562.8484126891685 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark01(25.404262121027152,10.621201768580676 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark01(2.543003790783278E-11,89.09188518635825 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark01(-25.431813681710643,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark01(25.454462246701468,80.12813344518372 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark01(-2.5480567357805752E-6,-31.414554995660506 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark01(25.548162974441084,2691.4433613986203 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark01(-25.555843873672764,-51.85087748012902 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark01(25.604956150124046,0.5707898793585363 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark01(25.6368596997047,-71.85111417187167 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark01(25.68788950766065,0.0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark01(-25.691347799640837,-73.82742741058681 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark01(-25.71701572481824,-13.55903685069417 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark01(25.745463468929792,86.83265312943738 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark01(-25.916911711239536,-60.98594778898318 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark01(25.98251221601595,-82.70367055020344 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark01(-25.986607163749525,-75.73178959193069 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark01(2.602142063654758,0.0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark01(26.028138505325927,71.11531929308106 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark01(26.07862116442608,37.475784334517684 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark01(-26.119778578776902,9.367351558671345 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark01(-26.130485908900965,0.0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark01(2617.107051599285,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark01(-26.199938045414747,1.5707963267948972 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark01(-2626.247082833946,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark01(26.27732473080031,-30.223564556388254 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark01(26.28989073444459,-0.01548517151395295 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark01(26.32853521366809,-76.65559082796224 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark01(-26.36505887798593,10.995693139517623 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark01(26.441230538085442,1.5707963267948966 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark01(26.450277862596494,81.79665876846329 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark01(-26.472635116227508,23.589603434082317 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark01(-26.48814118127764,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark01(26.573187135705997,4.720915036644624 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark01(2.6594020792984736,1.5707963267948983 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark01(-26.685459485762426,4.440892098500626E-16 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark01(26.703778001586297,4.712388477280194 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark01(26.704256148502566,1.570799573194524 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark01(26.705986492470245,61.261056281234 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark01(26.70612227145839,1.5707963267948966 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark01(26.70616739614877,-1.5707963267949054 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark01(26.706537324483687,0.0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark01(26.71518798984051,0.0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark01(-26.71962828974638,21.70383030545191 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark01(-26.74428143905709,1.5707963267948966 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark01(-2.678439622111142,1.5707963267948948 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark01(-26.79490539315978,83.0975987094592 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark01(-26.796612935379045,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark01(-26.805666389790368,149.56505226741228 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark01(-26.844959597680905,-42.96546978958952 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark01(26.893329582660833,-32.48762706096345 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark01(26.9269934122442,15.800733189974798 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark01(26.936399994087857,-1.5707963267948966 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark01(26.94228002936312,-21.569102529158712 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark01(26.973168747796546,93.22622371302089 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark01(-26.9752723361822,1.5707963267948966 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark01(26.97689131006105,-4.837388980384903 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark01(-26.97939926982531,-34.62167217200162 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark01(-27.028918561475912,7.888609052210118E-31 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark01(-27.05191552348434,-92.6769832808989 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark01(-27.07082169578368,67.04469164741323 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark01(27.08518503974244,-60.70406562455324 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark01(-2.710505431213761E-20,-10.995574286372788 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark01(-2.710505431213761E-20,1.5707963267948977 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark01(27.11809985209453,10.98581915035696 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark01(27.145989542668623,-1.373905340289511 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark01(-2.7204139707927055,-65.94054612573434 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark01(2725.7702892187876,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark01(-2.7284305521541747,-2458.546006143331 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark01(-27.319881334393443,8.231703703118413 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark01(-27.354500284057785,16.080738411945983 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark01(27.50754526391161,-68.74130071687814 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark01(-2758.4249691687255,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark01(-27.584821740547643,0.0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark01(-27.625585633805287,-82.43569563577017 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark01(-27.717520173197357,100.0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark01(27.721832375859456,1.5707963267948966 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark01(-27.753635497590906,-30.47882963680631 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark01(-2.7755575615628914E-17,0.0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark01(-2.7755575615628914E-17,0.0026298406388588587 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark01(-2.7755575615628914E-17,-17.278759594743864 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark01(-27.76031139860966,-30.653171831309194 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark01(27.76683022221296,98.01334661970392 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark01(27.767814310419745,98.96845343198673 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark01(-27.769264888495798,44.09205181088717 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark01(27.78330274233306,1.5707963267948963 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark01(-27.786608869151692,-0.06236578728235493 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark01(-27.788469007461046,2.2246847424616237E-16 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark01(27.802450431207838,-1.5707963267948966 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark01(-27.805603238956987,1.0770522737814177 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark01(-27.812547751255394,-1.5707963267948966 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark01(27.83558681330623,-67.8151949177377 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark01(-27.859110637288225,0.4323815052399179 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark01(27.926879100954864,16.134447968016897 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark01(-27.93244896697456,-26.894833315172747 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark01(-279.60129956058523,76.9709731381069 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark01(27.98581876407372,-144.55542238440813 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark01(-28.06626506683921,97.71885544551847 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark01(-28.067457938550177,90.44358020243594 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark01(28.097293288290754,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark01(-28.105279136767926,0.0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark01(-28.107026529116,1.5707963267948972 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark01(28.235787852867333,0.0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark01(-28.247971149569544,0.02010733887149061 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark01(28.26695832363238,69.21734293884762 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark01(-28.26954683338284,-188.3422813254104 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark01(-28.274330364770737,-7.543551540169176E-5 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark01(-28.274330535604076,0.0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark01(-28.274331054219456,-0.0011539868391793218 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark01(-28.27433173404336,87.96622768224378 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333739119722,-113.09476019919876 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark01(-28.27433381720518,-6.203660102062518 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333842889853,37.70131125124126 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333874454225,-100.54268147745272 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333880191413,-80.11061212605328 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333881604726,-5.212388807075172 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333881638753,1.5707963267948966 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333882117862,-67.54424205218054 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark01(-28.27433388230759,67.54424011900831 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark01(2.829531671642684,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark01(-28.339359086789102,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark01(-28.34437885460092,4.586448505014189 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark01(-28.353337007350028,-1.5707963267949054 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark01(-28.461717337197506,-100.0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark01(-28.680601551881015,7.205142819677541 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark01(-28.74314709695721,-0.2509852539699265 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark01(28.872854891055965,10.388889886895257 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark01(-28.917438274020398,-52.053554244705566 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark01(-29.011960170170184,2600.5338653907947 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark01(-29.100488003358837,0.6737882694217774 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark01(-2.9104914420695422,-66.26291051636359 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark01(-29.142743961425666,6.2671330786377375 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark01(-2.9386403602447757,77.61125377416852 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark01(-29.49855972735234,0.0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark01(-29.505560229474057,136.30327978734337 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark01(29.51360976510591,-35.68782416655961 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark01(2.954369220154149,-15.084318767798393 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark01(-29.618220190643484,5.334398642543476 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark01(-29.652560272067603,-16.20662687309988 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark01(-29.68229822369347,4.725617470238894 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark01(2.98052991499749,1.5707963267948966 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark01(-29.841663036372616,100.6261907176691 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark01(-29.842723108289288,-67.54424148582379 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark01(-29.844144746929782,-61.261056491444684 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark01(-29.84498606642582,67.54423854387689 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark01(-29.845441689022636,64.40265286465912 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark01(-29.846133117744678,1.5707963267948966 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark01(-29.846457965326945,-1.5707963267948966 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark01(-29.847760049741957,-1.5707963267948966 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark01(-29.894415638261364,37.58855869580364 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark01(30.00422605555272,32.3305358637833 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark01(-30.009853561334822,-0.05658584615720803 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark01(-30.08077543089054,85.34599859097983 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark01(3.0233999202508346,-138.72060909979015 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark01(-30.26246099916831,78.50322882364708 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark01(3.033386084744066,37.91423143277336 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark01(-30.397844959649206,-20.108175831206182 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark01(-30.97125756366536,0.0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark01(-30.987777852158274,0.0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark01(-31.063268665722724,-36.841977727865014 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark01(-31.10191357950049,36.17051103585027 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark01(-31.18540310780167,-100.0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark01(-31.290406498261248,0.0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark01(-31.35733025279464,-71.74152381805115 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark01(-3.141589131353455,43.982297022681124 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark01(-3.141589135152727,6.111915181126409E-5 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415895247408057,43.98315994347806 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415896377988934,-31.415358984062387 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark01(3.141592653589476,0.0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415926535897842,1.5707963267948966 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark01(-31.415926535897928,0.0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark01(-3.1420809348397936,0.0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark01(-31.44717655215614,-14.137166964490074 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark01(31.49083601143377,27.060361692560903 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark01(3.157217653698696,-1.5707963267948966 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark01(31.58464342202937,29.82729447522756 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark01(3.1595526333027237,-2619.8015385098074 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark01(31.60607092455777,-1.5707963277601789 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark01(-31.669898676068556,-40.44200428757685 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark01(31.67031378363839,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark01(31.685244519183897,-79.20404607218012 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark01(31.694701399185192,-77.91460349520358 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark01(31.807062424033603,0.0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark01(-31.814324377815282,-42.7824638887484 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark01(-3.1854027926899278,-99.11517898561215 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark01(-31.890444267471413,1.5707963267948966 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark01(-31.904279160467347,1.5707963267948966 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark01(31.9705551399966,1.3586205285649372E-16 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark01(-31.989278854405196,-1.3329648715839553 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark01(32.02240412142758,0.38685614425790354 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark01(32.046023451965496,-99.38347463476043 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark01(-32.049253146566414,32.655472117475995 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark01(-32.06771815126467,0.3177510689012163 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark01(-32.08006259875556,-1.5707963267948966 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark01(32.195456085183736,36.546479224196105 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark01(32.20618840144488,72.700635799243 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark01(-32.23411067499286,0.0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark01(-32.23476374928222,16.770610935232426 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark01(-32.263439958639474,-78.94669386278376 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark01(32.304498216561086,80.03177431027444 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark01(32.31010781535048,-1.5707963267948968 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark01(-32.346535292418494,-16.634734096420644 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark01(32.36463676150901,-1.5707963267948966 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark01(-3.24480742256344,49.781059422950804 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark01(-32.46087636371241,45.206911294476264 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark01(-3.2471565399893976,-151.25963682376087 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark01(32.48332419802627,0.0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark01(32.48689638866253,41.82628713478405 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark01(32.55717092439389,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark01(32.64406219271595,100.0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark01(32.64624997418787,0.0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark01(-32.656651587877874,74.13330142202358 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark01(-32.67471798742743,-53.92682291786943 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark01(32.71015788212972,99.00364873389142 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark01(32.809888638359155,-48.798701641061314 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark01(-32.86112937317023,0.0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark01(32.8834122453421,-54.77677415592894 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark01(-32.93868285272222,81.11607909634108 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark01(32.95224624678261,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark01(32.98451149375986,1.5707963267948966 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark01(32.986633357080756,1.5707963267948974 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark01(32.986677303328676,-89.53545166586258 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark01(33.20470208240977,-95.65835640277461 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark01(33.27977864506698,-38.7942733205467 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark01(33.28063574823445,53.53359954262888 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark01(33.310913717205466,-11.180614401278973 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark01(33.38571011802949,58.26924860419871 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark01(33.49309386902772,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark01(-3.3499846305290593,-4.2787155297544 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark01(-33.56546510428257,1.5707963267948966 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark01(-33.59823290220503,46.89041232425879 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark01(33.67673441353539,1.5707963267948968 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark01(33.82304333126418,-0.031123221528698224 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark01(33.845622193008495,66.0187045976673 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark01(33.88531327433518,-1.3104423343876397 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark01(-3.390731271788019,87.1988369092215 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark01(-33.97342482370728,0.0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark01(34.08262252435313,84.17507185892134 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark01(-34.33992482309982,10.555105244070091 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark01(-3.447163230025888E-6,-3.636825167873184E-4 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark01(-34.557515955839804,62.831123322277676 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark01(-34.61058636584897,-93.92061539936466 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark01(34.64191115703585,0.0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark01(-34.65109512666232,-7.205054498753974E-4 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark01(-34.66440009339567,-89.75850810106576 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark01(-3.469446951953614E-18,-1.5707963267948966 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark01(-3.469446951953614E-18,25.130176758887313 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark01(-3.469446951953614E-18,-43.98490429852247 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark01(-3.473129505991295,-2.6694497023889276 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark01(-34.73509299157318,-49.06072769411065 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark01(-34.75616989615702,62.288029486715565 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark01(-34.81120630484041,-136.36099213425445 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark01(-34.96054184024751,0.0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark01(-34.969707289407566,1.5707963267948968 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark01(34.99142908325919,-44.31739709778712 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark01(-34.99937422438302,12.979122654734098 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark01(35.0011792284663,-40.02584271913516 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark01(35.12444689314766,-1.5707963267948966 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark01(-3.519586023838185E-6,-81.68140899333463 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark01(-3.5222394875986665E-6,0.0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark01(-35.242392792373316,-1.5707963267948966 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark01(3.525029108734003,-2617.8014940653366 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark01(-35.35311167944666,0.4842571142365576 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark01(35.3908308557798,-51.78170824179978 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark01(-35.40179046424599,32.573271368567134 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark01(-35.4087156634107,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark01(-3.5416690809506584,39.0132969120404 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark01(-35.4895987618181,57.632207650309965 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark01(-35.50172571504944,-1.5707963267948966 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark01(3.552713678800501E-15,101.46438349897124 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark01(-35.56604571409778,100.0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark01(35.65068388865541,13.625325505381696 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark01(-35.681300219441795,-10.988537637636524 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark01(-3.5760388424266694,2637.8509304370787 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark01(-35.761066000008285,1.5707963267948966 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark01(-36.125685675643695,1.5707963267948966 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark01(-36.128152646755666,130.37609512319176 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark01(-36.12831551628221,73.82742383712065 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark01(-36.30073562722127,19.41466515651291 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark01(-36.33946935424037,59.12519133092252 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark01(-36.39809311486817,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark01(-36.424216158193914,-17.32223302989371 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark01(3.6943648345360813,-1.5707963267948966 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark01(-37.158751492708376,-49.90250188255918 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark01(-3.7478239455323887,-14.907904527834106 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark01(-37.69911403001514,-87.96620370118126 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark01(-37.699600124327524,0.0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark01(37.70511867836775,-43.574827612894005 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark01(37.75938173718065,0.34885017476069546 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark01(37.772636705259146,1.5707963267948912 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark01(-37.79095460581971,-1.5707963267948966 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark01(37.79826119615814,-10.44767590282072 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark01(-37.81490130815478,-54.88423348783593 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark01(37.81686565567543,-1.5707963267948966 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark01(-37.83135666457114,1.5707963267948983 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark01(-37.886947445669826,40.78197081143239 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark01(-37.91236786055538,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark01(-37.91670223669708,24.792501991717472 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark01(37.9377546404313,-1.5707963267948966 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark01(37.99112323886044,-17.56003081380655 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark01(-38.0886433002658,-67.54424205655155 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark01(38.11466911546063,0.34971377280390925 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark01(-38.2107342607189,1.5707963267948966 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark01(-38.281688788178904,92.95532346406026 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark01(-3.846358620947427,1.5707963267948966 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark01(38.52166205650458,1.2290768366269926 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark01(38.61024630035022,19.808847790765498 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark01(38.62742201360464,66.94920187783319 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark01(38.648694532376965,-45.01317345098841 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark01(-38.71200983649372,-45.21028340924172 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark01(-38.72061555042766,3.2652072446514455 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark01(38.737245325168345,0.0011884907957880387 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark01(38.74050284903476,-50.451437800569366 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark01(-38.78142939223316,-7.136964158445726E-4 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark01(-38.861118292259825,16.946069339364897 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark01(-38.87602037809581,159.8020971066049 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark01(38.89200871449352,76.96902001294994 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark01(-38.928475796364765,0.03870146422051641 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark01(-38.93501870892162,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark01(-38.942483969016976,-0.06934175476192603 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark01(39.01014280500111,1.5707963267948966 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark01(-39.02303137198291,-48.444241704453376 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark01(-39.06592646016238,-2668.590828535558 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark01(-39.06621721481568,-1.5707963267949 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark01(39.084801732773535,-38.75909384807267 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark01(-39.124067554732235,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark01(39.136346268501285,2679.3522736059645 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark01(39.13676441790039,-1.4845548156569374E-10 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark01(39.156698415554956,33.26745032671033 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark01(39.226797816875035,-13.721651306951756 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark01(-39.24568358080783,-133.57983173839384 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark01(-39.25780290247365,-1.5707963267948912 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark01(39.259339585919975,-44.342661520070294 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark01(39.267278329234145,1.5707963267948983 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark01(39.50875867225212,0.0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark01(-39.56375177858067,-67.57393585775806 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark01(3.97125754509866,101.7712679873389 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark01(39.719218830912865,1.5707963267948963 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark01(-39.802568838928764,-49.465800855729555 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark01(-3.9834353453788065,-19.74269727886237 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark01(-39.84489585534878,-37.112932729787104 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark01(-39.86458108181559,9.42477796076938 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark01(40.02013339455402,0.0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark01(40.07619557862253,-80.80685049166792 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark01(-4.018391198917115,-13.674379318405542 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark01(40.43968491498734,44.19619863051204 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark01(4.0484363457598675,-59.177603817062774 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark01(-40.51751956836097,-70.92863800839555 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark01(40.56717775355644,55.309264108985474 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark01(-40.75927355420873,-8.600719921301586 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark01(40.79029420009235,0.7577832438594632 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark01(40.79245301468612,-92.75331753647524 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark01(-40.84070097486686,-1.3905741633016819E-5 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark01(-40.8407009777995,-56.54860665247976 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark01(-40.8407013913506,-8.889301562527828E-4 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark01(-40.84070334746072,10.995574270448978 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark01(-40.84070399268048,0.002432620704267389 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark01(-40.84070449612973,-100.5369507861549 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark01(-40.840704496666625,-138.2285120538715 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark01(40.8407080189068,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark01(-40.84189433151021,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark01(40.84461074729173,-0.019206193282678002 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark01(-40.88245364001306,-44.30431589388274 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark01(-40.919220599831284,44.0636379411879 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark01(-40.968212800617536,-145.02195632918136 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark01(-40.980350217113745,22.12611267347235 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark01(40.99678107006116,-1.5707963267948968 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark01(41.04674544465382,-59.22918524956586 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark01(-4.12070853244569,-16.34398327427072 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark01(-4.120729328805169,0.47821676421689424 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark01(-41.40873148518577,1.5707963267948968 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark01(-4.141592653589794,-32.25586309108406 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark01(-41.455021778332004,59.69594895656033 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark01(41.47456215884097,-0.1866186743252537 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark01(41.49574150787856,-1.5707963267948983 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark01(41.53329678442827,-5.621843390425511 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark01(-41.556274507952985,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark01(-41.558541993293204,1.2214936791779618 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark01(-41.58348473035757,70.40416026151014 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark01(-41.61435882213287,-89.98926477070574 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark01(-41.780376414463845,0.06098752567993821 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark01(-41.7978123549259,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark01(-41.80779668547172,0.3604774150397946 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark01(41.89723174804578,-1.5707962719799367 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark01(-4.19190904691051,79.99570882059359 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark01(-41.991938244475776,12.03212693302305 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark01(42.244994444497166,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark01(-42.25483226630558,19.075749886289046 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark01(-42.296375718337856,86.40041607418658 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark01(-42.3782353695659,0.0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark01(-42.381412079169614,-0.29334890699274496 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark01(-42.40497282424128,-1.5707783842889476 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark01(-42.40983229595785,-1.5707963267948966 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark01(-42.410738817519146,29.84512699590588 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark01(-42.410918496450556,-67.54424186401616 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark01(-42.411230774929535,-17.278758181183488 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark01(-42.411388617574445,-4.712389040018552 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark01(-42.52747200630474,67.54179935634357 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark01(-42.59790406316137,45.075034042699016 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark01(-42.6405847177369,0.0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark01(-42.65560722752481,0.0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark01(-42.68909967466279,97.49412961903124 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark01(-42.69641849696866,0.0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark01(-42.74274269726932,0.0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark01(-42.744076710397664,0.4452043732529292 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark01(-42.770722795611356,-11.120574306715183 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark01(-42.77535745880437,53.71299569082351 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark01(-42.78784537651634,26.66794067676389 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark01(4.285698786818699,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark01(-42.90530588238105,73.64271767274181 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark01(-42.923526702954646,-6.435878981661085 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark01(-42.925985025515054,1.5707963267948966 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark01(-42.939970864024914,0.02066690557941679 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark01(-42.97272112696853,98.96016858807849 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark01(-42.976763897888475,121.83882671774302 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark01(-42.979624864732706,1.41305482197834 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark01(-42.98229715018299,0.5707540892554591 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark01(-43.20159338292364,71.12281684371482 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark01(-43.22996332601616,-46.66323330520128 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark01(-4.3240447377466635,-80.18514420372689 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark01(-43.555627593007394,86.37090062028633 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark01(-4.367786187423064,-46.492158197601505 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark01(-43.94654318291183,-76.59393541580668 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark01(-43.98230053723936,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark01(-43.982304779651656,-25.132741209095563 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark01(-43.98237210770925,81.681378486889 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark01(-44.007658726374274,-93.07030551038507 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark01(-44.008844772372605,-2566.8407482076404 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark01(-44.17367414698274,1.5707963267948966 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark01(-44.17489221055364,59.42308987803383 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark01(-44.209582280075054,44.15031789518849 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark01(44.27249097250481,46.6873930697989 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark01(-44.28221761506546,1.5707963267948968 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark01(44.35313233701217,-16.044857491966134 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark01(44.36517912973653,-11.013863771501732 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark01(44.37121409690775,-81.64747127728572 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark01(44.39842724574211,6.356229593932952 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark01(4.440892098500626E-16,-20.03352048654139 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark01(-4.440892098500626E-16,-56.42944166043021 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark01(44.4127680219473,-2466.251147349279 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark01(44.4990240643239,0.24348041769909 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark01(-44.61439080120966,1.5707963267948966 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark01(44.64225494757281,97.02214098113717 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark01(44.741331247038445,-1.5707963267948966 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark01(-44.76560608739214,-1.5707963267948966 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark01(-44.883535135029476,57.06056439477662 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark01(-44.89783535492888,-44.277459917995216 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark01(44.906630373327545,7.684069857506249 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark01(44.98556854452686,88.17900395177472 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark01(-45.023815522167276,-18.57732194347254 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark01(-45.1377062198242,0.0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark01(-45.17622509302173,0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark01(-4.518700081818958,-108.82363352055708 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark01(-45.19529323628927,-1.5707963267948966 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark01(-45.19596213381629,26.924930151672143 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark01(45.23889470366328,-23.85780186189335 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark01(-45.259034296471356,0.15610266665058703 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark01(45.26915302489834,-2.3377148683270189E-4 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark01(45.27784501905185,1.5707963267948966 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark01(45.35576280760111,-64.15232379177597 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark01(45.38149278545879,-1.5707963267948912 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark01(-45.38426566890794,34.71769267153124 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark01(45.54205447350898,-4.7126333090689 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark01(-4.5546309326360275,-64.44766136032506 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark01(45.55046363641388,-1.5707963267948983 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark01(45.55201960996124,-36.12831329226907 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark01(-45.57025209135721,3.4882368204872165 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark01(-45.717387060842626,-45.14493798822886 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark01(45.72559019335472,-69.30566457746991 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark01(-45.80792153831479,-0.2433765577090795 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark01(45.91472916402799,41.53526252277203 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark01(-4.60590433282721,-18.266419675460384 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark01(46.299671890058335,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark01(46.31037449172225,4.989204199310361 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark01(-46.37685506121591,-35.861781568824625 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark01(46.44736422954995,-91.13734554304015 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark01(-46.520325423782324,10.510748138588454 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark01(46.555629108056564,-0.1801395240961548 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark01(-4.65697250995384,-1.569263600760474 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark01(46.83372516343766,-25.97023668919536 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark01(46.939700490863,82.21260970535089 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark01(-46.998662886426224,42.082555951579124 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark01(47.109648278372326,-0.21079950107287815 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark01(-4.712157201580017,1.5707963267948966 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark01(-47.12328196111111,-86.39379797371825 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark01(-47.123886273645965,-0.008901339681386285 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark01(-47.12388628163981,5.293955920339377E-23 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark01(-47.123886647567886,69.11420705861755 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark01(-47.1238881708557,-45.553093615865116 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark01(47.12389025779039,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark01(-47.1246046849048,0.037885637596353314 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark01(-4.712668299876476,76.96902348891962 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark01(-47.19875776949512,-0.3892292837303152 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark01(-47.214219166862485,-100.95897540451806 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark01(-47.39391600629322,-1.5707963267948968 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark01(-47.48120422512034,0.0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark01(-47.5007713489656,-88.79876845467936 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark01(-47.744184083677666,46.1147798464514 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark01(-47.86005185484174,136.31765494862526 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark01(-47.89673963442376,-1.264193473253283 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark01(-47.95780359698425,-17.541194608108704 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark01(-48.161078216514504,-1.1187623442135113 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark01(-48.16627177272025,-99.42324633052746 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark01(48.18610450905513,-1.5707963267948966 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark01(-48.21102881671142,1.5707963267948983 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark01(-48.2369205669476,20.317211791752353 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark01(-4.825631648621408,-1.5707963267948966 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark01(48.32975314577285,-83.84910760545836 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark01(-48.38844409338812,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark01(48.44245457567602,-0.2774797776889689 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark01(-48.4518278992615,-4.77327196166226 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark01(-48.47799806681935,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark01(48.48212796563311,-101.69168092246761 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark01(-48.51687403177336,91.01084011977196 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark01(-48.667020686785364,0.0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark01(-48.69211085600742,-1.5707964701273258 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark01(-48.69467578136235,-20.420352487570387 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark01(-48.69553781790693,29.845127070461626 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark01(-48.69731597128071,1.5707963267948966 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark01(-48.701846218890324,-0.06314910056794559 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark01(-48.780913286583406,77.2141228561201 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark01(-48.841217102147525,-2625.768147596533 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark01(-4.91006138228072,45.14824260591462 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark01(-4.930380657631324E-32,-50.3291452545777 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark01(-49.58518569838468,-1.5707963267948968 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark01(-49.68430114831468,-97.9053488758709 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark01(-49.76791348298911,1.5707963267948966 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark01(-49.78803101860606,44.42694434240075 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark01(-49.78857614907499,-31.65074089741428 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark01(-49.83680197360174,100.0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark01(49.83992514751202,-48.54021044463976 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark01(-49.87740190392354,62.58845173502456 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark01(-49.91840019812794,11.64078506164445 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark01(-49.92171580844382,67.55642016177822 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark01(-49.92606227624375,46.51838827618076 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark01(-49.94102896998962,61.69548376102765 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark01(-49.95390952151256,2498.7624824516583 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark01(-49.97005831759671,1.5707963267948912 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark01(-49.98535052237081,0.0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark01(-50.047948836751004,11.735251691258558 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark01(-5.008315705940802,-31.74911721128997 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark01(-50.12626319318699,26.154934855979292 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark01(-50.14829052776749,0.49231026865981653 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark01(-50.185016608929445,0.0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark01(-50.20017912291368,3.4813399313406563 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark01(-50.205628441587336,95.71993076203401 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark01(-50.26548245743668,0.0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark01(-50.26548597967618,4.149283943952426E-11 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark01(-50.26548627221093,0.0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark01(-50.26560452775317,6.223994368835362 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark01(-50.31697874510144,-46.570613019579945 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark01(50.317433848785726,-2664.879571100402 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark01(-50.34773517902276,-38.76858435735925 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark01(-50.37242953206524,-45.42944827252002 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark01(50.43754966496607,13.16024196936291 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark01(50.437924554502516,-1.5707963267948966 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark01(-50.44740085234159,-56.00527834610529 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark01(50.6360648559793,1.5707963267948966 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark01(-50.679686011035145,-59.04673904801736 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark01(50.70926185724274,39.22464035594047 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark01(-50.75356040977209,-1.5707963267948966 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark01(50.89248135921008,84.72763613769868 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark01(50.904924649963675,9.94838657541182 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark01(50.931453561782405,-2560.0880148055503 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark01(-5.095476158627122,-53.572938091905996 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark01(51.01448537311281,45.208671019628476 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark01(51.03215975509408,15.903000038354321 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark01(51.099730305644044,-3.630247607510817 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark01(-51.10555454479183,0.0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark01(-51.14146758216935,1.5707963267948966 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark01(-51.16552248944177,-0.6997611628108583 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark01(-51.16620936592457,0.0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark01(51.2247175863753,0.0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark01(-51.2247524055845,1.5707963267948966 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark01(-51.28758922800178,0.13534837903283403 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark01(-51.301746369772225,-8.767958357162543 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark01(51.34564719692804,116.28121756599677 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark01(51.388954606766134,1.5707963267948966 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark01(51.396181875712074,95.14999865052854 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark01(51.42236866720147,0.0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark01(51.48176945469859,-14.279626269112555 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark01(51.564905025405636,-51.3576195510693 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark01(-51.5685043802121,5.393033935432911 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark01(51.59533556022795,100.0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark01(51.60142837611431,-0.3276967349290565 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark01(-51.61061370428995,64.83242787819499 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark01(51.63931355931328,-55.99739296915294 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark01(-51.66074613649162,0.0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark01(-51.7216681794916,-50.23876934243718 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark01(51.83364894359268,1.5707963267948966 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark01(51.83627878363535,-67.54423853024934 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark01(51.836278784229926,-142.92954145907123 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark01(51.83890862487155,-61.26105674500097 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark01(-5.193150396783224,0.0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark01(-52.02745201819039,-1.5707963267948966 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark01(52.09190045662194,7.105427357601002E-15 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark01(52.11639948869315,-0.15033150678344906 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark01(52.21082569531579,0.0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark01(-52.2973114283358,-50.617973136281805 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark01(-52.426435693485814,-0.2650753755181987 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark01(52.53058715425024,0.0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark01(-52.582630794763396,1.5707963267948966 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark01(52.64095505964298,-66.69508621925058 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark01(-52.7035171693937,4.712395283727974 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark01(52.749773373267956,-1.5707963267948966 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark01(52.76209544715357,-99.0425837910969 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark01(-52.84446734410973,63.141784106997335 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark01(52.99663409328514,60.36587574939486 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark01(-53.056510041562866,92.16241447084494 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark01(53.07966623505544,-42.41150111656651 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark01(-53.0940965697362,4.044762408821697 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark01(-53.20462201055265,43.539902021910194 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark01(-53.407075111026344,-10.995572590359943 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark01(-53.407075111028306,0.0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark01(53.40707602840707,-0.0022557749449879636 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark01(-53.46209938287659,-62.39643145844923 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark01(-53.49852919724294,-1.1542845149887254E-4 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark01(-53.50963384520524,31.87238103447314 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark01(53.52307205976874,-88.70001561867053 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark01(-53.6317043530671,67.78770424920836 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark01(53.638428977648026,-64.40929590362599 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark01(-53.78650727213634,-1.5707963267948966 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark01(-5.381350949531097,-1.5707963267948966 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark01(-53.94286334945111,74.4660013735768 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark01(-53.97196559736741,-2546.4438502574053 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark01(-5.421010862427522E-20,75.4008535267939 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark01(-54.44910353087511,35.563169170583436 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark01(-54.47425648767492,57.03640367521422 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark01(-54.49444863529773,30.197003051220236 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark01(54.5045019037027,24.16230852753442 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark01(-54.60626281215376,67.0520995447761 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark01(-54.61088947848275,-60.35442086984422 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark01(-54.6786840064829,-45.361027915336564 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark01(54.68483739141146,-13.794632707420192 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark01(54.698605929591366,-68.61965713868938 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark01(-54.812319739163144,0.11590881117038743 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark01(-54.84041735792782,-2631.170641784396 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark01(-54.84171158868461,-1.5615420560565785 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark01(-54.9754009562224,-48.694685720390545 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark01(-54.975972007991324,-14.137168612992998 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark01(-54.97787155765589,67.54423852994402 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark01(-54.97849142597624,29.84512806117998 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark01(-54.979931520305314,1.5707963267948966 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark01(-54.98050127844705,1.5707963267949316 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark01(-54.980501278459926,1.5707963267948974 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark01(-55.13155975551543,42.25576944039932 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark01(-55.17565685048676,0.0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark01(5.519025001834635,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark01(-55.19752618797167,1.5707963267948966 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark01(-55.229503194159854,1.5707963267948974 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark01(-55.22964533580297,0.0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark01(-55.234673303772084,1.5707963267948966 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark01(-55.24310118263696,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark01(-55.3221098845146,83.5965762516791 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark01(-55.342232141351744,45.42435232508871 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark01(-55.37014593633576,0.0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark01(-55.436574709980675,16.742078380665262 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark01(-55.502107106456755,0.4752262672616598 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark01(-55.5049809698233,7.888609052210118E-31 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark01(5.551115123125783E-17,-14.429203711100591 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark01(-5.551115123125783E-17,-53.47229164716893 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark01(-55.63133865781372,-1.2333790643585363 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark01(-55.642147339325064,67.93418425367784 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark01(-55.84989140202975,-96.28274160437095 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark01(-55.94105204220337,-1.5707963267948966 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark01(-55.98698765878667,-1.2041590770473163E-8 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark01(-56.036913325643646,143.75368516783118 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark01(-56.04328770968455,16.54372962915069 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark01(-56.06297210555212,91.32173595064265 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark01(-56.06685607724014,0.5486076133948191 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark01(-56.103104849217786,34.075692835979616 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark01(-56.109627012543335,18.913180760547057 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark01(-56.16468391831994,1.5707963267948966 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark01(-56.16854846964478,-14.429208722270367 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark01(-56.402822030910556,17.713718641788347 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark01(-56.410547939372776,100.0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark01(-56.51322504407388,53.895517218721004 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark01(-56.52228030168807,7.99882327291797 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark01(-56.52517142999528,0.0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark01(-56.54873671581589,-31.416173858116878 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark01(-56.54878137567471,-5.212352874948181 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark01(56.702531568458056,93.3152581759955 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark01(-56.74768417555963,1.3682844466031132 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark01(56.74851461041726,80.54704216602073 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark01(56.78087963593234,17.441198763248238 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark01(56.79846443930002,0.7185013884095424 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark01(56.855235124527894,136.85223747337355 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark01(56.85721207126903,-36.623377763134776 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark01(56.921906317456816,1.5707963267948966 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark01(-56.97426570319806,0.0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark01(-56.98735056240438,6.793131455140957 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark01(56.99117697895835,1.5707963267948966 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark01(57.03834246967443,65.85480324011289 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark01(-57.086243904777284,-86.45724233739074 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark01(-57.232431757040025,30.924005116910934 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark01(57.23585375395561,98.41999846205957 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark01(57.4510577356903,0.0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark01(-57.4972779578349,-1.5707963267948968 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark01(57.51743533683689,84.6462715114482 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark01(-57.58850660483728,16.697372699359217 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark01(-57.65703543225166,-24.289364559619347 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark01(-5.784878215582296,35.75005094277407 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark01(57.92154431221056,99.2099047798431 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark01(57.94796788405685,-1.5707963267948948 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark01(-58.11052059113433,27.09141948916256 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark01(58.117106212159655,10.995573602740762 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark01(58.118014195916686,-1.5707963267949054 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark01(58.11945433241757,10.995571006940159 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark01(-58.15532324032174,-73.53249716979062 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark01(-58.25764119900543,0.09272365791981302 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark01(58.30604865926884,11.921559210511191 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark01(-58.372962421220755,49.507066994646635 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark01(-5.8408228169969485,1.3676123645569191 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark01(-58.43720539130955,-80.63068377602087 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark01(58.438236545817944,3.1415926535897936 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark01(-58.45473147228055,0.0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark01(-58.49849310118964,-0.07047895924138425 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark01(58.54437669642516,2651.8225031959573 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark01(-5.863370278286052,-158.31279262595922 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark01(-58.67805198619498,0.0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark01(58.70519708813279,-69.55457307686446 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark01(-58.88464028434517,1.5707963267948974 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark01(-5.911833511472656E-12,-54.977864134879155 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark01(59.153975204468196,-31.305022673545736 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark01(-59.16837924049221,-0.23996612420470137 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark01(-59.19323173030024,-10.778636487599485 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark01(59.21566848538779,1.5707963267948963 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark01(59.3687398285377,-62.01427557240264 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark01(59.406239446836736,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark01(-59.41482096313065,1.3934999695075554E-15 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark01(-59.56142257132242,51.305598289029064 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark01(-59.63228542426454,0.0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark01(59.65458633963911,7.389568901878022 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark01(-59.690256895966584,0.0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark01(-59.69026041820557,6.2240035778612395 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark01(-59.69026041820606,1.5707963267969933 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark01(-59.70445611950419,45.94976911683551 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark01(-59.75250752945266,2510.951928011229 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark01(-59.87963610440812,85.7144530370148 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark01(-59.97523122942826,-15.811970084547312 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark01(-59.99447940921418,-73.35555356463502 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark01(-59.99508643119124,-0.3296197698028651 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark01(-60.05415217348884,1.5707963267948966 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark01(-60.099287109550524,1.5707963267948912 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark01(-60.17849798909074,-67.49453749177677 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark01(-60.22862715657671,2621.5329208925345 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark01(-60.292441550413315,42.85993904458368 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark01(-60.30761436832653,0.8537851600481741 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark01(-60.41333003613034,29.57673432202814 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark01(-60.45996301650695,68.56922032308466 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark01(-60.55458597823377,1.5707963267948966 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark01(-60.605474738606645,71.01406956111812 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark01(-60.80967740926243,0.0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark01(-60.87551953875494,-50.90284493079034 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark01(-60.89861720822067,3.096883552484428 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark01(-60.90105157115588,81.35740208648843 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark01(-61.006165858341774,-18.48504544295291 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark01(-61.26250906057365,-10.995571976002562 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark01(61.3735124579336,-54.25729488274076 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark01(-6.147753532383746,-19.31739858461954 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark01(-61.570917764106945,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark01(-6.162975822039155E-33,1.5707963267948966 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark01(-6.162975822039155E-33,1.5717728892948968 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark01(-61.633933831244704,1.4570221243374351E-15 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark01(-61.6395862419745,-66.15774906146007 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark01(-61.89721614776058,17.475645716396983 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark01(-61.90156566723082,5.339955374509245 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark01(-62.09016510810187,-69.28941835279414 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark01(-62.098835149740395,1.246333790840553 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark01(-62.30633610445051,-61.39429636784808 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark01(-6.235238116680321,87.26164133033896 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark01(-62.63251741676192,88.02971815408404 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark01(-62.75421397629573,0.0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark01(-62.765333548924644,62.30509127390661 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark01(-62.79621898868128,-2693.8900659337105 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark01(6.283185254286978,163.36286860288976 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark01(-62.83185307050343,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark01(-6.283185563074991,-1.5132941132915145E-4 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark01(-6.28318657179378,-6.203781256333175 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark01(-6.2831879456037685,163.3641232085419 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark01(-6.2831888294024125,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark01(-62.831994288898336,0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark01(-62.83209721242087,-6.224383634945502 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark01(6.283231644470042,-43.99225930502145 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark01(-6.283246346403491,31.415783113133173 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark01(-6.2833074359476715,-4.712364054722533 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark01(62.83350367411958,-66.94963332148193 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark01(-6.284161885883089,-25.132739329595704 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark01(6.287091560290577,69.15092735211306 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark01(-62.87211069581816,1.5707963267948966 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark01(62.89435307179587,0.0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark01(-62.89435307180772,169.64614351761418 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark01(6.293215861006585,6.141421777123828 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark01(62.9388868018814,-1.3493152105583448 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark01(62.96040808284642,-61.92593878143658 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark01(62.97434279678632,-0.5394488436250314 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark01(62.98594993093988,2571.7455344130162 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark01(6.299048371825986,-0.14765670035532186 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark01(63.06471421480347,-61.85785001458779 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark01(63.070084209923905,-83.67168239381365 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark01(63.10203573890701,14.429203674304247 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark01(-63.13999384889295,2676.606678322232 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark01(63.174946867259024,-9.680238200931697 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark01(63.17576993610376,-41.91320930626383 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark01(-63.271300172993335,-7.031314970451234 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark01(63.28212147291501,-7.803392754967504 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark01(-63.29624192898084,57.50621962677658 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark01(63.298025150375025,13.66740762751013 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark01(-63.34437466837868,0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark01(63.36032655865486,1.5707963267948983 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark01(-63.43873744656544,73.26602209465376 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark01(63.439180184397316,-73.71377388953553 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark01(-63.45317575778917,82.37845135833913 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark01(6.3456853548809065,31.702583250861558 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark01(63.49701238516198,-2.637739754440996 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark01(6.350235548673321,85.7780722132722 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark01(63.50259801792344,-95.43047606695818 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark01(63.51635108024638,39.348672876617684 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark01(63.541168108814695,-106.89798095673802 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark01(63.65060911144902,-37.872175254163224 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark01(6.367352898746744,31.873646393164353 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark01(6.3683472278227,-59.81432530885622 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark01(63.69094475842431,-172.74614828147432 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark01(-63.755006130800204,65.87737326588424 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark01(-6.387834357586925,2630.2748414977536 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark01(63.89475695836907,-56.65077021322811 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark01(63.899394729591194,44.39845891578162 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark01(63.96388583763872,33.126511665844866 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark01(-64.02419705641219,0.0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark01(64.11658430784551,1.5707963267948966 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark01(-64.1171042396391,11.001439804404638 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark01(64.15408731516726,72.30555081903066 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark01(6.423362268453884,5.74821079060565 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark01(64.26476429172762,0.0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark01(64.2714924098432,-29.84513020910304 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark01(6.43165323617643,0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark01(-64.3942776801936,62.12599659675752 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark01(64.40013160277255,29.84512991800648 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark01(64.40254823064227,14.137170455786059 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark01(-64.43796469880895,15.658792599230779 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark01(-64.48295694079087,-43.759247462568005 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark01(-64.49711018515663,-1.5707963267948966 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark01(64.53982686611346,-6.476015930579024 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark01(64.67836675978083,-1.5707963267948968 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark01(64.77817083035104,-24.92467105363866 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark01(-64.91580825461213,-104.29264406636185 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark01(6.491685760104332,0.0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark01(-64.91700333327366,74.46333513045931 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark01(64.93366893350805,0.0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark01(64.94317897899228,0.0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark01(64.97032264050344,-2509.1184622630253 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark01(64.97146170979684,71.15424036146112 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark01(-64.97279547815727,-7.661381500822869 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark01(-65.03793695136486,40.592358838957125 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark01(-6.513700610402955E-8,125.66529077191697 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark01(-65.22177444067438,2628.9007880786894 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark01(65.23669272339478,26.472767834198287 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark01(-65.255738242934,88.06095785020091 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark01(-65.28262128321848,-1.5707963267948974 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark01(6.530366367835811,0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark01(6.533185307179588,31.970540883476612 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark01(6.533185307179588,-45.47218340479001 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark01(6.533185307179589,100.0 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark01(6.533185307231511,62.741322321655666 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark01(-65.36374250031683,0.5563345557353375 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark01(-6.540015462014686,-52.502738284533976 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark01(65.41074013333039,-61.74641291249201 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark01(65.41843688216537,-37.69911184307752 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark01(65.52158248796476,-74.26408155607753 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark01(65.58524255117035,-4.692162891069643 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark01(65.59983566680881,78.71374490368342 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark01(-65.6663567046582,0.0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark01(65.79038748506501,1.5707963267948966 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark01(65.81461506096112,-10.980405529542914 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark01(-65.89915975202737,0.3153791194129667 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark01(-65.97344569381285,-6.222896366641655 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark01(-65.97344572525603,-80.11061236753937 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark01(-65.97344572538523,-67.54424201824783 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark01(-65.97344572538564,1.5707963267948966 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark01(65.97344596380424,-1.5707963267948966 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark01(-66.04365409801052,88.16149259915692 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark01(-66.14334148722158,-11.510815559929767 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark01(-66.1515389731162,2.512584003164464 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark01(-66.18318964748852,-5.070357891543594 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark01(66.22109617747961,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark01(-66.30796382364157,0.0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark01(-66.32533340006191,-34.66743324313498 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark01(-66.39155407369486,-59.35463029850332 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark01(66.42461097392338,-94.30514667183773 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark01(66.43410789739286,-0.1535529535704051 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark01(-66.45940948409441,4.440892098500626E-16 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark01(66.45990029825529,-1.5707963267948972 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark01(-66.59803677771325,-1.5707963267948966 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark01(-66.72974205907254,0.0 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark01(-66.778044993788,1.5707963267948974 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark01(-66.78336684778577,0.0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark01(6.6852368871318895,-61.91546877295217 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark01(-66.85337435082889,-1.5707963267948966 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark01(-66.87734827176368,-7.850597791781535 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark01(66.9211563581571,48.3427910956203 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark01(-66.9686109292327,58.64099529754088 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark01(6.701757807713378,-35.01429585954119 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark01(-67.03491158594079,7.419101545102504 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark01(-67.14465272885728,17.90350934400952 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark01(-67.22991884637833,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark01(-67.30358373935451,25.249482566995013 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark01(-67.3051556065873,-36.12831551628262 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark01(-67.38983745487683,-42.87053326737898 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark01(-67.4514356600925,75.40524600798918 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark01(-67.54161221154229,-1.5707963267948983 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark01(-67.54161221154236,1.5707963267948983 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark01(-67.54278747650892,70.68583713446712 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark01(-67.54422887633265,-158.65055107820172 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark01(-67.54424389636407,-45.55310110647474 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark01(-67.6656271191381,-0.017659967196475387 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark01(-6.776263578034403E-21,75.39566771025318 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark01(6.778314517633895,80.66315701183848 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark01(67.9037265594099,-46.54508185630624 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark01(-67.97562911031534,98.08921409181889 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark01(-67.97906370569734,-73.72546951321677 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark01(-67.98140736854754,34.090667093474735 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark01(6.804168391272029,44.46061197071046 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark01(68.18352566400947,70.9787244238849 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark01(-68.24758089513057,-1.5707963267948966 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark01(-68.34342546912045,-0.5209422196452206 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark01(-6.83483404406779,148.34312073336173 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark01(-68.52872400408638,84.85091812831573 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark01(-68.60331788575529,31.389028087689695 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark01(-69.11503837897543,0.0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark01(-69.1150392188029,-14.137166970488508 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark01(-69.11503988812969,0.0019809536296287694 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark01(-69.11504186041468,6.282932156113931 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark01(-69.1150419002372,2.5993139204513473E-5 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark01(-69.1150994141317,-1.5707963267948966 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark01(69.11699150397546,0.0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark01(-69.11801267020029,-188.49492668862146 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark01(69.1238527375723,37.831991950933514 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark01(-69.29796890939497,-23.361370958768315 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark01(-69.35592722702857,0.0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark01(-69.38889134426299,-1.5707963267948966 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark01(6.940044273692717,-11.395519153946784 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark01(69.46026487125852,-85.50872677551277 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark01(69.46182419463466,-108.2591369485719 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark01(69.46852127746523,-0.01993449463486014 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark01(69.52037121816477,-1.4301697676571172 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark01(69.52754662627143,-1.5707963267948968 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark01(6.953657676925971,-69.95630507025098 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark01(-69.61401056811965,-14.43091454877775 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark01(69.63865852712507,-51.50212231649003 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark01(69.63913517224165,1.2108890009810533 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark01(69.67597006505736,-1.5707963267948966 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark01(6.97617293119604,-46.178422937930264 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark01(-69.78883751483767,-1.5707963267948974 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark01(-6.982787057407208,3.8801076411393873E-4 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark01(69.86457544243736,0.0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark01(70.07488844718912,-51.458821028275125 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark01(-70.08523982658669,-1.5707963267948968 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark01(-7.011820751688193E-18,29.845130209102933 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark01(-7.01409706717729,-1.1102230246251568E-16 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark01(70.15982046137353,-93.6912073990647 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark01(70.18569268780746,-7.33131253651724E-6 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark01(-70.23335246451563,-1.4329572362239134 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark01(-70.26197611220324,135.17054969059103 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark01(70.28090489833332,0.0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark01(-70.28206120065015,63.24889686689278 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark01(-70.32083190381992,26.496183100859156 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark01(70.3745185509631,-77.42767829314015 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark01(70.38573039871287,-168.75501409592957 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark01(70.45868544128341,1.5707963267948983 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark01(-70.4812993673076,0.0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark01(70.48221520355673,-19.6722807230898 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark01(7.050359515001479,55.28875105056053 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark01(70.68320486513142,-1.5707963267948966 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark01(70.6854973418628,67.5442385951455 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark01(-70.68827078042824,-1.5707963267948966 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark01(-70.78363404772962,-1.5707963267948966 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark01(70.80989533841247,62.87031654403765 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark01(-71.04197228135483,-87.4969600399339 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark01(7.105427357601002E-15,23.586211745184592 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark01(71.10447929610461,43.02256284619378 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark01(71.25043875577032,-55.11262273869315 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark01(-71.26018753568566,-1.5707963267948972 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark01(-71.29294482335644,44.18157029866632 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark01(71.30278533377319,-1.5707963267948983 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark01(-7.13365678760773,2.720391194196805 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark01(71.3597243395254,9.816394442049955 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark01(71.40075092451553,0.0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark01(71.44111001925167,-55.523499111613695 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark01(71.53713405174028,32.638749237579155 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark01(71.6803889504285,-85.23398955875207 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark01(7.190927470187745,0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark01(72.01239415168087,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark01(-7.208768992962561,-0.47341779439390924 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark01(72.10465309519225,2.0679515313825692E-25 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark01(-72.18425890149848,-96.03918960937166 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark01(-72.20077658004661,-50.01932866457241 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark01(72.22136369334397,-0.2663444158387104 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark01(-72.22519842603234,60.55857368777734 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark01(-72.2566310322734,17.27875957380241 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark01(-72.2566310325629,-1.5707963267948966 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark01(-72.29581370606263,81.96223460871643 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark01(-72.30560905217479,-25.271608911042968 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark01(-72.31678178608212,1.5707963267948966 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark01(-7.235051812345276,-32.99588516639962 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark01(72.39388400900269,-80.03201687400288 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark01(-7.252688441226326,-49.60825559246847 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark01(-72.53571709423171,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark01(-72.5855943922997,81.61876284941164 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark01(-72.73340749902944,-45.45603367160741 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark01(-72.80533376622036,-214.90018744467923 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark01(-7.28077252220298,0.2547758661090332 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark01(-72.84521762594282,57.38978792800753 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark01(-72.85674390781755,67.54464025363455 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark01(-72.86877508239708,-40.71115673384828 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark01(-72.9537653454129,-96.2805596630137 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark01(-7.2983144288911745,49.60033937054956 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark01(-73.01783018804709,50.03203095578249 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark01(-73.33563638993685,42.411714948157034 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark01(73.34076940253291,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark01(-73.40282478474703,1.5707963267948968 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark01(-73.44686565987696,-1.5707963267948966 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark01(-73.46892181576048,0.0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark01(-73.59070792224914,-2606.3124682051466 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark01(-73.82787178895201,48.69468271808786 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark01(-73.83053276011606,70.89673913370224 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark01(-74.00186133943532,0.0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark01(7.403654066639118,-5.861390755445257 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark01(-74.11637629486825,-45.12697326828548 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark01(-74.15348547285332,45.500381674405034 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark01(7.429986503841548,1.5497005467577907 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark01(7.443090422196147,-70.68583473264592 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark01(7.449952347623749,54.05140771609257 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark01(-74.70384343241791,64.98129141813189 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark01(-7.512714570902929,-1.239299170946964 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark01(7.524058253340527,41.27618190486234 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark01(-75.39822411534062,-25.132563422446086 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark01(-75.3982242754539,-31.41832418373528 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark01(-75.398225166469,81.67941245609408 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark01(75.40212993615505,0.0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark01(-75.44580789832854,1.5707963267948972 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark01(-75.456761679268,-27.19857995482755 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark01(75.4936771535595,-50.705624098577545 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark01(-75.50147270906868,0.0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark01(75.58345462561174,29.686447658616892 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark01(75.59858498371926,0.8924700341358047 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark01(-75.64400434413538,-24.45754779055879 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark01(75.66802431434216,-49.51808548794144 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark01(75.73769343606318,-1.5707963267948948 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark01(75.76507206305413,-0.3968356553570406 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark01(-7.576602361079537,72.10700425563218 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark01(75.77185332850343,-0.2670917093499715 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark01(-75.82370447483393,-1.5707963273821202 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark01(75.85443228530389,50.55996487403684 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark01(-75.876649564072,64.9621805202689 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark01(-75.88812748392712,-60.27471603908644 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark01(75.92447347426352,-1.5707963267948912 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark01(-75.96317384874378,68.71066977728586 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark01(-76.03508149733618,-190.9702639581029 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark01(-76.07212899140342,-33.11381302853269 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark01(-76.07957796795162,-100.0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark01(-76.15904319039194,-10.62439398646185 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark01(76.16926535314782,21.792544727722657 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark01(76.18354713110895,-13.839860321873767 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark01(-76.1877164459146,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark01(-76.18799474667021,53.71904909829082 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark01(-76.45315402269094,0.0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark01(-76.50127163633712,46.698197827384774 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark01(-76.50182895404492,135.3599911042228 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark01(-76.5024785305265,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark01(-76.60819643017847,-77.10631793925546 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark01(-7.662728773111821,53.00586608102148 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark01(76.67170472543835,-1.5343065648163159 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark01(76.76943422515097,0.0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark01(-76.77930013736037,75.19572147560595 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark01(76.78232521240929,1.5707963267948972 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark01(7.683012814849235,-1.5707963267948957 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark01(-76.84699619963386,92.77001675017607 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark01(-76.86020627090758,1.5707963267948968 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark01(-76.90197578795096,0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark01(76.9674935159695,-4.712386660643265 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark01(76.96889473762597,95.81857778684193 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark01(76.96902001294737,-105.24328575375468 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark01(76.96914041373202,10.995570775536176 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark01(76.96949003678098,-45.553133291972024 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark01(76.97078274144445,-51.8362807097081 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark01(76.9716498535888,-1.5707963267948966 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark01(76.99650486452396,-0.12398069335053208 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark01(77.01002383192207,2639.394065965016 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark01(77.01065452806496,78.0104074033093 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark01(-7.703719777548943E-34,-45.55310133637262 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark01(-7.703719777548943E-34,51.83627878771803 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark01(-77.03912918552274,0.5706769342127914 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark01(77.09454379297749,1.5707963267948966 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark01(-77.13648788212356,-67.54424205218055 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark01(-77.14573310834163,1.5707963267949054 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark01(-77.21485922309961,2499.9908149069997 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark01(-77.38978234949784,-1.8409946782713007 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark01(-77.44923534850476,-1.5707963267948966 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark01(-77.47976666356304,98.64120943169226 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark01(77.50725821766457,1.4603101514711818 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark01(77.50993824947435,-0.03420232137651851 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark01(77.51072347568739,1.5707963267949054 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark01(77.52765026426323,94.74671407637379 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark01(77.53946746575328,-47.84460060759326 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark01(77.60599090230087,0.4980490412896404 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark01(-77.61687156675009,-1.5707963267948966 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark01(77.66109049127387,64.17049612070134 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark01(7.772849982739873,-124.09290980944783 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark01(7.775009301114964,61.26105674271366 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark01(7.776464028487844,133.5186867364915 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark01(-77.86274399955946,0.0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark01(7.788724212298215,1.5707963267948966 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark01(77.93474701042001,-45.945451305654146 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark01(7.793561688306892,73.82742735055761 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark01(7.793959944684431,-139.80093703678173 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark01(-77.94472182107877,0.018510966112994406 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark01(7.794539408639654,89.5356347679365 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark01(7.794586833124662,48.69468551189782 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark01(7.794982244232354,-36.12831550661016 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark01(7.7950534331049415,-73.82742735701848 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark01(78.09853226868131,107.28430699298909 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark01(-78.10441279023362,-1.5707963332671497 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark01(78.1206374639454,-98.03305002683163 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark01(-78.12600232473832,0.0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark01(78.15177883886577,-76.84602470879568 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark01(78.16421088290474,0.0 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark01(78.21336421755768,-0.020004723369676403 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark01(-78.22926714170906,-57.957695816607256 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark01(78.24450682089889,95.44098632442301 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark01(78.25149713022202,1.5373241325651836 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark01(-78.26579118009005,-44.085415641415665 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark01(-78.33297953134871,-6.429283972712757 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark01(-78.35102322798008,-0.014413757545920608 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark01(78.35409409589268,95.77339571400552 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark01(78.37191482499586,0.570792336599737 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark01(78.41389949563265,-1.1132143088419393 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark01(-78.42892058737415,-65.20956557675605 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark01(78.43930747027002,-1.5707963267948972 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark01(-78.47503232069145,4.164947292182834 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark01(78.48995122522601,5.753614940962661E-4 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark01(7.851351793336235,-1.5707963267948983 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark01(7.851351793338899,1.5707963267949054 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark01(78.52143082500088,-36.18657626719467 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark01(7.853567258433799,-23.561942301807935 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark01(7.853979366014825,-89.53545166246546 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981350735037,12.566010699631244 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981583093181,6.2031245844695055 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981589528404,-56.54854402771878 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981603242882,89.53545166250491 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981623360731,-6.223719619405771 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981633533398,-131.95579853557044 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark01(7.853981633974483,-100.0 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark01(7.853981633974497,0.0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark01(78.53981729376966,6.2254005336236125 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark01(7.8542327970558805,37.53109830743304 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark01(-78.55544133974483,0.0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark01(78.55752923530804,-98.07095263932 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark01(7.856611474610046,-1.5707963267949054 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark01(7.856611474613339,1.5707963267948966 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark01(-78.66973844819083,-1.1876159696986925 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark01(-78.72109712814404,-74.80433022446653 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark01(-7.904344433671028,20.426983269849174 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark01(79.23928761019582,33.479769619343415 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark01(-79.25112621626144,-6.429323671013472 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark01(-79.39644100356709,-66.97242028494858 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark01(-79.4346170187234,-52.065684216143126 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark01(-79.49337909377287,63.346025861430746 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark01(-79.50737210856363,0.0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark01(-79.6593505711345,-70.68026453234381 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark01(-79.80271832150731,-86.48875442026763 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark01(79.86282833147598,89.15129582084728 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark01(79.89785209055887,0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark01(-79.90143693621023,1.4510292408600173E-15 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark01(-79.93542638566215,46.54082026102802 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark01(-79.94521675226572,-31.609637315015128 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark01(-79.99595291203525,-80.02275183545149 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark01(-80.00543420892754,70.73988335273957 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark01(-80.01482194248084,0.0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark01(-80.06442027173387,-75.94685428188387 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark01(-80.10989419855883,-1.5707963267948966 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark01(-80.1105266358774,-1.5707998432161938 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark01(-80.11090329292946,4.712388954587322 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark01(-80.1132425071786,1.5707963267948966 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark01(-80.17319452533853,1.5707963267948968 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark01(-8.025496588973226,158.25221253088793 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark01(-80.46231840381596,-76.90776839013924 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark01(-80.50782626869926,-16.197762274223336 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark01(-80.6023143804254,-11.928027706209619 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark01(-8.071729485939919,75.7491604418139 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark01(-80.86724807804349,74.37926655591022 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark01(-80.96537611065324,-45.48410731679617 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark01(-8.106397423739837,-37.54412829178795 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark01(8.107770147130026,0.4250499349476571 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark01(-8.112714701763763E-11,67.54423953365497 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark01(8.113560874431027,-41.1153274374959 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark01(-8.127101745340193,-0.5605733561083462 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark01(8.136069598957201,-14.09763336716659 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark01(-8.149464753829534,0.9623381531974762 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark01(-81.52530245717693,-31.98104213939718 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark01(-81.57649229962794,82.14315588310846 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark01(-8.161029480408807,0.0 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark01(-8.165783309906237,77.58884968982117 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark01(-81.68143951092559,1.5707963267948966 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark01(-81.68143966204813,-119.38044233782682 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark01(81.68178962141356,0.02776619461927363 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark01(81.68445586780142,0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark01(81.68534427429574,14.429203673504773 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark01(-81.68922149333463,23.56194103382712 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark01(-81.69142764205792,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark01(81.7270463289474,-86.77315258725275 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark01(81.73493420369061,-0.7316607711844556 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark01(81.75806004700131,32.59305905686293 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark01(-81.7742466076545,17.70637405769915 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark01(-81.81946700228164,-38.544476696575956 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark01(-81.86604805299532,-49.20955907424249 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark01(-81.88109145213855,65.35403888710212 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark01(81.90149414285882,-74.72479399999129 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark01(81.90896979810637,-93.71876380867047 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark01(81.91524363033585,0.0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark01(81.96038383175934,117.05108162374253 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark01(-81.9668560554348,0.0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark01(81.97228855404796,-0.7767362867790747 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark01(81.98189441598066,61.49922352719147 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark01(-82.0091095592724,1.5707963267948968 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark01(8.204579555184909,17.073234091849578 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark01(-8.206274651724152,-1.5707963267948966 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark01(-82.11615319620853,0.0 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark01(8.213889819338076,8.152233725805526E-16 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark01(-8.216276081489347,6.813920033149401 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark01(82.20231593987072,-94.23669911542409 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark01(-82.25432280434364,0.0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark01(8.225943436022835,-0.16785607685573362 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark01(-8.226799570741703,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark01(-82.29325552448377,42.28854599296977 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark01(-8.233207057247986,-3.218294238057312 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark01(82.33280454410368,-1.5707963267948983 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark01(82.35466574845424,-1.1848191586920052 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark01(82.39475160381932,0.044386422721722614 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark01(-82.4542066364129,-74.781094198817 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark01(-8.246547231980504,0.0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark01(-82.49796870572128,0.9677091571267915 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark01(82.54468530886655,-73.54754322348722 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark01(-8.254825685192657,17.038629757617343 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark01(8.262598686389792,66.04639761051936 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark01(82.64937780210786,-1.5707963267948966 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark01(-82.77115087287754,-69.01184958105229 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark01(82.78184653763381,-77.5965058107387 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark01(-82.7843875368059,2649.610199705757 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark01(82.81408604731914,-40.1946237478402 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark01(82.8285075742441,-25.751287943499406 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark01(82.8544641284355,61.35317477653163 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark01(-82.89798131006063,44.85490938609033 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark01(-8.301633831634426,57.69835827062396 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark01(83.06806347711216,0.0 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark01(8.307383414702288,1.5707963267948966 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark01(83.09193004660736,45.01925381466076 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark01(8.31572929055345,0.0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark01(-8.319696594682675,-31.064717407772875 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark01(-83.2008812373323,74.21289672931488 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark01(8.322480848964663,0.35042849898811623 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark01(83.2506404126791,1.5707963267948966 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark01(83.25213280472933,98.96016815913592 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark01(83.25323801882749,61.261053781337374 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark01(83.25371280896717,1.570796326795032 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark01(83.2540930671617,-1.5707963267948966 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark01(83.25422132267822,39.4010088993822 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark01(83.25463893275706,-1.5707963267949054 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark01(83.25483516076841,1.5707963267948966 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark01(-83.27791827195765,-36.432668288768234 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark01(83.35238659988515,-88.33436900892107 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark01(83.3955909887061,-1.5707963267948968 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark01(-83.40647260960388,-57.38208280453478 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark01(83.41360919996131,-67.0148085165244 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark01(83.43193415103455,-61.585990944599395 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark01(83.44522530926591,-2.974279291733879 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark01(83.47362453035433,-8.380912915531695 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark01(-83.47810599277656,2616.0119751964767 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark01(8.352147103513751,3.407109107311678 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark01(83.55119981864154,-0.23357613814809586 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark01(83.56912768038299,23.571736462529323 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark01(8.367745986720648,-48.82414675323519 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark01(-83.7535936877422,0.6772514054373728 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark01(-83.76037843579378,19.35074843994332 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark01(83.79293350397751,0.0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark01(83.94849992710269,-1.5707963267948966 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark01(83.95268834382702,-89.19348854105291 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark01(83.9823025269475,1.5707963267948963 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark01(84.18578570715181,1.5707963267948968 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark01(84.25064098060955,-15.235055982239706 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark01(-84.26429423119086,1.5707963267948966 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark01(84.33428383516524,-1.5707963267948966 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark01(-84.34445033792028,-1.5707963267948983 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark01(84.38061369575581,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark01(-84.38122087223105,-7.452653104868062 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark01(84.3891270462515,-77.02463707096999 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark01(-84.42872456941551,96.24098502671777 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark01(84.43774431899432,-59.63912387455295 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark01(84.44234558083065,-2197.285526095425 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark01(-84.44907396637504,0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark01(-84.45623714939705,53.85593450563218 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark01(84.46009776989614,0.043040126341944714 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark01(-84.46802130269823,39.152528425662425 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark01(84.49611203727511,110.4764871436191 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark01(84.51870488874624,-20.9355917211455 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark01(84.5387310657078,0.0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark01(84.55024947141929,80.92983798682026 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark01(84.56675856109842,0.010217126215178523 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark01(-84.56922452844734,0.0 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark01(84.59334206839708,-86.66339770261585 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark01(-84.60132936892548,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark01(84.61144320177202,63.49181407969421 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark01(-84.6161757843279,-2604.9738626878807 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark01(84.63458151042794,53.99706366950633 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark01(84.68623858369064,2598.5170328962704 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark01(84.6954859349093,0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark01(-8.470329472543003E-22,6.280555466540768 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark01(84.72380222068014,0.5065330875389643 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark01(84.76133216625522,13.254425192955981 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark01(84.78078123441122,44.273874068969405 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark01(84.78631291816922,-0.2718111101787134 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark01(84.8141946160863,0.5819739556411463 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark01(-84.82296263064421,-95.81869907783177 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark01(-84.82299812534679,1.890918440650995E-18 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark01(-84.8229991645694,-0.0014178385822586573 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark01(-84.82300164691871,80.11061110097911 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark01(84.82300164691964,0.0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark01(84.8230016469244,0.0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark01(-8.487484829312606,0 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark01(-85.20587665530643,-1.506681056791729 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark01(-85.27131301548347,-74.42974721102411 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark01(-85.29339027492438,15.297791062559412 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark01(-85.36584080872207,30.597142675823704 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark01(85.36825562312552,46.470865095056325 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark01(-85.47059105156954,1.5707963267948966 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark01(-85.47242523684018,1.3302673192887413 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark01(-85.59983126568918,0.0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark01(-85.67408410633743,1.737385868162001E-4 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark01(85.81900670737258,0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark01(-86.07413100369838,0.570788023707456 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark01(8.617562291383123,62.972540772873856 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark01(-86.19413682697827,-1.5707963267948968 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark01(-86.39367399612385,54.977867926318325 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark01(-86.70433614290889,-90.89817751834694 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark01(-8.671139397920154,-0.16773200663288612 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark01(-8.673617379884035E-19,0.001177569048750783 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark01(-8.673617379884035E-19,-43.98492699089598 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark01(-8.673617379884035E-19,4.7123889802391945 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark01(8.673617379884035E-19,-77.32598228731601 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark01(-86.7415286878414,-73.83582885609424 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark01(-87.09798993599347,-35.532293458061986 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark01(-8.739862502828743,1.5707963267948966 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark01(8.774297637718746,-2693.6110885384533 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark01(-87.9458213647174,60.202768698563574 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark01(-87.96459430051446,1.5707963267948966 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark01(-87.96459477702857,0.002974153512950022 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark01(-87.96459772890216,-4.093556361112121E-4 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark01(-87.96460955930353,10.995574262792273 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark01(-87.98022725594734,89.53563477200036 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark01(-87.99357012984883,54.977871437690716 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark01(-88.03940276369158,0.0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark01(-88.14987908506507,42.440959178347185 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark01(-88.17691342098476,10.520796563347188 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark01(-88.24097929190941,1.5707963267948963 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark01(-88.28047332126236,-1.5707963267948966 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark01(88.28399953383295,1.5707963267948968 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark01(-88.319499024581,28.39697866474998 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark01(88.32427327833022,-95.39675221750863 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark01(88.32945063320481,4.948021221683149 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark01(88.42656749640386,59.59046379313276 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark01(-88.43088578712003,-14.42971093152343 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark01(88.4353754763155,-79.98736072835628 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark01(-88.45051822852788,1.5707963267948966 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark01(-88.54140675843516,0.0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark01(-88.54192915877088,-69.5344502928998 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark01(-88.54584678648291,-100.0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark01(88.57330988310542,89.13629911992192 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark01(88.64162302079875,100.88418727259389 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark01(88.71238983427548,-32.66101883676257 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark01(-88.7303189412672,-67.87091034334301 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark01(88.7380859744497,1.5709742457581566 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark01(88.75957147782304,0.022944531367990795 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark01(-88.77241145257047,85.4405740597661 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark01(-88.79661225835535,8.222000435079906 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark01(-8.8811724624682,0 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark01(-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark01(-8.881784197001252E-16,0.0 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark01(8.881784197001252E-16,2519.0526786590112 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark01(8.881784197001252E-16,-98.21454606603297 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark01(88.8339508403615,0.0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark01(88.9866082277773,-32.62353171265592 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark01(89.05746877036658,-131.71103261269297 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark01(89.15387268393053,0 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark01(89.22085113032519,-17.327840045465802 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark01(-89.22235689779922,-0.02103835791008265 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark01(-89.24564536831686,0.0 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark01(-89.34772707498925,6.566990961686784 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark01(89.36688627965214,98.40438588840078 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark01(-89.43714220312143,-3.9028320226529627 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark01(89.4892662198188,-0.21328749125544327 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark01(89.53276078667021,1.5707963267948966 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark01(89.53539062730981,4.712388097459943 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark01(-89.56507019193792,89.41207976536857 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark01(89.59315683000766,-1.5691306569745587 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark01(-89.65211480706574,0.004426094840184919 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark01(8.966855798380863,31.331770790980272 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark01(-89.67610260909784,1.6347614555628383 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark01(-89.67693815116962,0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark01(-89.68791251258865,-76.42382495770957 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark01(-89.69543471870044,-177.58212949735517 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark01(-89.73500324947355,-1.5707963267948966 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark01(89.73893724921925,1.783878570270403 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark01(89.76017155531129,1.5707963267948966 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark01(89.76149894211275,26.94888233808375 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark01(-8.976340358638282,-50.4044242342113 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark01(89.79882186961015,39.64535572162862 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark01(-89.80630013208561,-0.24275424411287455 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark01(-89.86731112515517,-2525.715616947836 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark01(-89.88892625887061,-52.84589155059112 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark01(-89.90227722218073,93.49775472517055 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark01(89.92528489518831,-1.5707963267948983 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark01(-89.93587474123481,0.0 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark01(-89.95518923264287,-0.07446164825156286 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark01(-89.95584477590376,-9.85811005629185 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark01(-89.9571808518931,-43.38037607604919 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark01(89.9741085301876,38.82494153144853 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark01(-89.99407976040033,-64.52948907558783 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark01(-90.04352784414186,-77.86273733507225 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark01(90.1231752093345,4.746262978489966 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark01(-90.19645270960703,0.0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark01(-90.24637739712438,71.44531143048863 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark01(90.56187237498165,-1.5707963267948966 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark01(-90.58280989313675,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark01(-90.61859608051026,-1.5707963267948966 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark01(90.6293313868624,-63.38833452975537 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark01(90.65919181493217,-87.77710708620212 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark01(90.66363825078923,-17.94388919604483 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark01(90.66506363419299,13.040670562665198 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark01(-90.68301956516808,24.690014340876274 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark01(-90.6917263559087,0.0 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark01(90.71620946458239,-1.5707963267948966 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark01(-90.7191916765327,0.0 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark01(90.7425003948071,-26.145716533420817 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark01(-90.74477824768883,14.207859389828231 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark01(90.74908723967147,100.0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark01(90.85441661260336,-7.55438562618707 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark01(90.86215772821478,-9.692011105254425 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark01(90.89121126064865,-32.93053389446563 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark01(90.89649636853501,-1.3298167332889397 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark01(90.9152176347362,17.278772217060823 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark01(-90.92882070740201,1.5707963267948968 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark01(90.93826834853772,0 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark01(90.94733898727972,-31.98607807021996 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark01(90.95946776940067,61.62409382476292 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark01(-91.00569236115261,0 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark01(91.0077240489,55.607946768531846 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark01(-91.01354460882631,-7.186936750754015 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark01(91.01383167053952,-0.5656932719673972 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark01(91.04844454194236,1.5707963267948968 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark01(-91.09393595993514,32.54733991149388 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark01(-91.10598792813025,-31.415926535902916 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618216729091,-4.712388980384689 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618343186452,25.132741228718512 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark01(-91.1061834884644,-81.68138098519775 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618417425327,0.0011942338370167422 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark01(-91.1061841746314,-62.83268566807105 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618693757795,6.224585606106428 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618695410362,10.995571387293742 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618695410399,-1.5707963267948966 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618695410399,1.5707963267948966 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark01(-91.12051291988766,14.429224736204631 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark01(-91.12296037273616,-0.18341556828561123 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark01(-91.21238685639305,-1.5707963267948966 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark01(-91.40856521169738,-23.56848279686883 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark01(-91.41184570698839,67.83613017360341 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark01(-91.63142820546786,60.817777610393904 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark01(-91.67794262894002,1.5707963267948968 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark01(-91.75246211550525,0.39755563059955873 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark01(-9.176466140965715,0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark01(-91.82164918789194,95.46736654581325 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark01(91.96464343732003,0 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark01(-92.0246268065311,64.8584954748585 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark01(9.228984558888214,107.3238543717554 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark01(9.243022257726906,-76.37314348220785 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark01(-92.51810436701714,-99.66253257518125 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark01(-92.56028257635747,-1.5707963267948966 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark01(-92.64681891529172,0.0 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark01(-92.67457484533774,1.5707963267950902 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark01(-92.67507471173279,-61.26105509078563 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark01(-92.92841949475732,1.6826889113463568 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark01(-93.12620488899192,80.11352351600203 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark01(-93.3821813017319,0.0 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark01(-93.56409878434533,-17.163542946026 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark01(9.362938193687114,-4.998375264647592 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark01(-93.84399443246795,0.0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark01(-93.96532832861514,1.570796326794893 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark01(-93.96558072022717,40.91577849207155 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark01(-94.08692837241937,86.66892851459752 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark01(-94.12317818573486,36.16256412660252 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark01(-94.1684729650919,0.4007303755954791 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark01(-9.424774438658353,0.0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark01(-9.424774584788976,-31.416443363356084 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark01(-94.24778133400703,31.41779743756505 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark01(-94.27902962081768,-124.09251397335093 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark01(-9.429007229416392,44.52783474792647 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark01(-9.431921506734666,-44.10190880375549 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark01(94.38244602109444,46.08648626417588 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark01(94.39830359539653,0.0 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark01(94.43975891096974,-0.07033458730959563 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark01(94.45591362887843,55.23237482854718 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark01(94.47345202515785,-2684.5625059588083 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark01(-94.4792978242685,-93.3652836105248 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark01(94.48648298761381,0 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark01(94.52350191296784,0.0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark01(-94.5822319371695,0.3720025616379995 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark01(-94.72413966732141,0.0 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark01(94.77037989979249,-26.645903978162888 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark01(-94.78047465146615,-2590.2954249297104 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark01(94.78475164020446,-45.12381389778917 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark01(94.84129310446596,-89.78435423594388 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark01(94.90598099975362,67.09992922267506 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark01(-95.011464148629,22.181671940339122 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark01(-95.10214074588166,-0.04166502043648061 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark01(95.10388900809468,185.36158721910223 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark01(95.18040131248566,-29.33211734701206 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark01(95.2205221710033,0.0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark01(-95.2474403968859,-14.429203912879444 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark01(95.29743993297282,-70.97539986663779 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark01(95.31125081554516,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark01(95.33514352414556,-29.845130209496205 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark01(-95.34953744332734,80.22077645794671 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark01(9.56589626354614,-97.10085023329407 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark01(-95.73627695008545,91.39463327782519 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark01(-95.7825235448923,-2608.690870729258 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark01(95.78622484116742,49.083829985631446 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark01(95.81594609384977,-1.5707963267948966 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark01(95.81857566558372,23.561941597093725 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark01(95.89770889086958,-57.811248377235124 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark01(96.20811026302414,1.5707963267948966 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark01(96.39750260664808,-1.570796326794897 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark01(96.67274670774054,-8.300841417790954 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark01(96.84915175481596,5.219524045293474 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark01(-96.85298602676913,0.26176746521333083 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark01(-96.91129935610974,5.665820728451378 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark01(96.93789333494607,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark01(-9.699149191329411,-83.11544414485056 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark01(-97.01259448169955,1.5707963267949054 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark01(97.02546809636715,1.5707963267948983 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark01(97.06613102967512,-84.60991268053456 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark01(-97.11393083996222,0 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark01(97.11937690257705,2611.511513481539 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark01(-9.72209759996862,-78.91979571295579 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark01(-9.724769005815226,0.0 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark01(-9.732804817093289E-18,1.5707963267948966 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark01(-97.35407305565813,-48.19292937712321 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark01(97.35543243367493,89.99176299062012 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark01(-97.3745987923016,56.50949677443336 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark01(-97.38342717566229,-2647.226861725695 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark01(-97.3893687616953,18.849555921538105 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark01(-97.3893704714044,-25.134578288322167 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark01(-97.38937216237271,73.82742735552526 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark01(97.38937561403326,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark01(-97.43888058365609,-88.12237446461468 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark01(-97.67535084261183,1.5707963267948966 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark01(-97.69759250522512,-169.69787428275873 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark01(-97.7054026594882,61.96065540805199 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark01(97.75393614955567,15.392351118963049 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark01(-97.85627112338642,81.4135167244509 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark01(-97.86116530610605,64.28428898831964 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark01(-97.96762298545767,0 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark01(-9.816226006063701,0.9039987562671996 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark01(-98.16270489051549,16.68512897827254 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark01(-98.19068072960647,-42.909660297687594 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark01(-98.319304157489,13.56020131573275 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark01(-98.33138332553682,-17.952832079330996 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark01(-98.36622271132006,98.05333444351223 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark01(-98.38936841768954,-14.429217900463541 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark01(98.59509967141582,-0.4995574390480007 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark01(-9.860761315262648E-32,0 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark01(-9.860761315262648E-32,-69.11284536885474 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark01(98.71030367728315,-72.01803719308013 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark01(-98.71177166385773,-86.42449447894559 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark01(-98.83231593948982,0.0 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark01(-98.94884641019001,-61.841587143422515 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark01(-98.95764139581655,1.5707963267948966 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark01(99.19808258491315,22.617191671959418 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark01(-9.943896653061355,-2591.2955256571195 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark01(-99.49715424077012,36.14810980805672 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark01(-99.52379962229051,1.5707963267948983 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark01(-99.5251597788983,0.0 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark01(-99.69558111149507,-129.58347649586867 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark01(-99.99944424165331,-5.2281019271226885 ) ;
  }
}
