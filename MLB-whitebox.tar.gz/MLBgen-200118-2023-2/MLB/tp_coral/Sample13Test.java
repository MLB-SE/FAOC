import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
//    0.6119134142969274;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(0,-0.5088562496695204,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(0,-11.337094709640567,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark13(0,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark13(0,-25.761669174298476,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark13(0,-2624.7195295271226,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark13(0,-2722.396639576343,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark13(0,34.65294777197002,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark13(0,37.93485211278863,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark13(0,-4.930380657631324E-32,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark13(0,4.930380657631324E-32,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark13(0,4.950490169931612,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark13(0,-64.50525308832174,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark13(0,-68.53543474225413,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark13(0,-74.88311961555456,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark13(0,-82.65124309153967,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark13(0,-82.85136070902017,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark13(0,-8.881784197001252E-16,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark13(0,-97.80771003994684,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark13(-0.9999999999999996,-0.4711814545192211,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark13(-1.000000000000001,-3.552713678800501E-15,-72.3800424924048,36.81212151719268 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000036,-1.4394790840248353,-77.71964938040561,0.36208941792017385 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000036,-2.1143041114278673E-4,-98.46337410614687,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000142,-0.43913578266108955,-64.50982793179443,0.36214389001874886 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000142,7.786449452035595,-20.553873285647217,458.8604882836444 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark13(-100.00000003551023,-1.4725139591813994,-67.08587338598662,1.0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.003341220412382162,-70.50760644438554,-0.7831698660205195 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.0064392428726329776,-53.737887285243346,-0.5477708621412756 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.010779740034786893,-47.38208459693895,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.011405818530420029,-26.969352665269653,-0.3719898615186036 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.01414909759030522,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,0.017300118530010233,-33.439862844843454,0.05217200246774145 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.022937867326837908,-34.15160696771136,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.023884661747827333,-0.42336832582026435,0.9110881990206623 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.02591051611543188,-88.13692647450242,1.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.03337961503222364,-67.33537391458604,0.04697582658012773 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.051005896867204026,-100.0,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.054497333202985755,-62.90188424873327,0.0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.056186778513318644,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.05653054886752494,-9.982441110443702,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.05866332038151023,-1.570796326794905,38.99761482858574 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.058925675553922696,-11.799485922747936,-2.1669367072728603E-14 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.06258960798626197,-65.87505813790406,5.784332560102145E-9 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.07181566221791136,-53.7245788762389,1.0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.08230484811696234,-0.5450606572273392,-1.0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.08562273976769116,-100.0,1.0000023239874858 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.0861631058722434,-0.4971377736683793,1.0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,0.09073653989343734,-0.03781231380595669,0.0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.13713878160472803,-88.37407142286804,22.7607672424168 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.14355037068470444,-37.78091715845997,0.8654719507536106 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.14441946137002115,-0.07577668058390685,72.00225634894858 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.14637462035975535,-1.5707963267948983,-2.7060057288269768 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.1467055044947907,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.15822398019615716,-1.5707963267948966,1.000000146137479 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.15996226167766336,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.16211636463543366,-40.596928068306184,0.10233966853803131 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.16433467919965938,-87.03071528357573,-0.018867598470129116 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.16782147812149262,-70.79855208845663,1.0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.18942347217687835,-44.15023742047506,0.9270504623537361 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.19027896873986677,-1.5707963267948966,8.623338411080548E-10 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.19544808597350322,-85.80578548205786,-0.45302016730568095 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.2026906846842681,-1.5707963267948966,-49.04749144770042 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.20623275289140963,-7.870622388791742,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.20985281717262702,-31.462354662709686,1.0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.2101210013021202,-1.5707963267948966,-45.67888547096232 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.22472540767178018,-35.37870658851395,0.036959119520740616 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.22709702634466933,-15.069174237202134,-6.95515096589922 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.23013871982796685,-1689.017738584108,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.2365518267184724,-1094.4121104648768,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.2454356928807202,-0.6688741670898933,-1.0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.2529850691186226,-73.54587053304544,-0.9643879253890502 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.2685940388719247,-1.5707963267948966,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.27639597719863623,-1.5707963267948966,-0.1019683068861037 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.2780386949382275,-94.59398472239027,1.2732259040758334E-4 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.29490354129351637,-84.45752237085105,-98.33689819123886 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.30851306240862164,-99.8102338929043,-1.0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.31685391942993013,-1.456257248316916,-0.3620894038431041 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.34812569368005486,-89.20412968357952,0.0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.3669315462529138,-1.570796326794891,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.3694619788850679,-0.888958118424661,60.95284534708151 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.36980412088922965,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.37041660922032876,-17.57891630195709,-0.8881204884832585 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.3707542545419741,-2.220446049250313E-16,0.0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.38555446545294636,-37.5157788405292,-0.5829002784392932 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.4131573347118316,-123.5241697476154,-1.0008699506534682 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.43547700680004237,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.4421456053789822,-52.58099218033471,36.82088682985693 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.44705002647133024,0,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.485888653256383,-91.79710289002566,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5157473309242496,-31.964761052220567,64.78288638171114 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.517862762993478,-1.5707963267948966,83.29715511996977 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5383482526305234,0.0,-1.0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.54187281079806,-67.4676033516021,-100.0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5516783386164656,-95.77398124113945,-1.0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5528463952018123,-4.142652354757959,0.7314312438550515 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5583900458909739,-52.82889259983317,0.0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5598769703021065,-24.384436639654467,0.996806162949782 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5837827758406715,-1.5707963267948966,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5929459446545486,-39.80802508086494,31.14380426454811 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.6110892090229675,-4.379053103426287,1.0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.6131128539241002,-31.923522343128884,0.3975290677348735 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.6238535381299526,-58.31642435536774,0.06255253629112961 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark13(100.0,-0.6279804702540711,0,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.647242200188014,-49.95024444913552,-79.66786188987614 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.6857994756987067,-31.8983656372466,-0.9999999999999929 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.69089882563792,-31.75140157605831,-0.9816220092760897 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7098107189427816,-1.5707963267948923,-0.09299285418265368 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7192879077026337,-22.022784508492347,73.4938060733518 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7259895736828899,-89.26452297189921,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7269483912912431,-45.17322344948943,-1.0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7272590218801063,-0.006854135078208739,100.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7421591024864428,-19.304664498600957,-0.974872950403168 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7425732864859784,-17.53090477488432,-1.0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7560729697618704,-88.74145600131125,-0.02324894137037037 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7807314105981971,-0.5062696953615752,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.8075984745997762,-67.47738107381936,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.8328283170196039,-57.12402885928099,-0.9999999999999998 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.8410384839623088,-14.165596275938896,-78.70140938351946 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.8439939513926984,-4.870716212719772,-1.0077349964680268E-6 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.8623184587562077,-78.15354190601397,-1.0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.8782620464223516,-6.313982667158735,-41.863434650923324 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.8929821141542152,-34.42071485164769,-1.0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.8991095688813188,-70.98997324252566,-0.041141929226229446 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.905741287050706,-91.56611065862137,0.24546490373706886 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9147589658554619,-53.896941763780234,1.0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9172784538302352,-21.854039852967652,-0.25790498785117677 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9344214417346532,-41.318447551769424,-1.0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9625533428994899,0.0,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9911426515439681,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.0009099574986728,-95.70605706112556,66.4718507465039 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.001586163733725,-1.5707963267948983,0.3620978209986942 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.008955065873323,-1.5707963267948983,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.028522518018491,-22.936034714626416,-1.0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.0461545762697118,-1.3507989722343166,-1.0000938027438349 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.060463100063855,-55.929024143824876,0.04864181598830848 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.0824412889279798,-84.22451125010726,-1.0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1102230246251565E-16,-1.5707957792708234,-2.1175823681357508E-22 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1102230246251565E-16,-1.5707963267948966,5.852095443365248E-98 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1102230246251565E-16,-64.37250910821264,0.0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1109714400791404,-45.96204908544017,1.0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1579584754561068,-67.20812872908984,57.796457180590146 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.164070888067501,-6.424438045895756,-1.0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1644906276546898,-4.1775859863959255,-1.3234889800848443E-23 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1754376516890566,-1.5707963267948966,-4.7477838728798994E-66 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1887178654951498,-100.0,0.47302056312708984 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.191769777728319,-1.5707963267948983,-0.407207827660919 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.2130018138674312,-23.63185744571916,1.0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.2273664435566898,-0.005769604453786569,1.0428364021766987 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.244377670613361,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.2763543044441175,-1.9566301101541228,1.0052940016442662 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.2818862504888504,-31.525660082311347,48.83343332756812 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.283133840602929,-17.524818930841548,-41.05376710206321 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.287248197538844,-90.21177571351387,-1.0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.2878201731974456E-15,-4.454012145338383,87.08141170327463 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.310252921336565,-81.68399947821054,68.88646010068315 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3171858572773871,-93.0909700508069,-49.97350633348209 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3455608492860671,-18.258972589030947,1.0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3643810431096126,-31.925964486504355,-0.8727120767926081 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3837145970452813,-39.13833959696398,1.0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.387485735298982,-25.746111521696513,1.0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3887461501801543,-90.62219931000186,1.0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3890405726223496,0.0,27.440413452604957 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4074324689836022,-33.84285655804004,-1.000000001856262 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4236409945608008,-42.015556493754076,1.0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,14.429209505161857,-45.07493756922113,1.0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,14.42927009647579,-95.48392901652929,-100.0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,14.430990023777248,-1.5707963267949019,1.734723475976807E-18 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,14.451085126054586,-72.4074323536163,-26.09131506762053 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4470685364073872,-100.0,-0.7956976378344824 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4517918921955522,-58.69125774989194,-1.000003302752994 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4663714712895926,-26.39956311622842,-0.05807342687823571 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4764782918813815,-47.02272205903286,1.0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4860206242964138,-101.96193186027352,0.209429031440044 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4950584534331661,-10.955796495968755,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5143623870996805,-76.04077563225519,-0.7020655173616801 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5226680653206968,-64.52704577193519,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5338722573852424,-100.0,0.9999999999999297 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5453579635168349,-9.85536557928581,-1.000173543033241 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5534527648254364,-60.94299895564497,1.0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5544593641713036,-35.41763025845794,-0.005839439144540937 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5572405391545134,-44.31525229860605,0.6166505940428795 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.561637366421113,-73.90012645237195,0.8547625981840641 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5674653183933467,-93.48521480244588,6.938893903907228E-18 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5701158426653121,-88.47092880086575,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.570395572567695,-1.5705954633723702,0.902021143387875 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267945324,1.5707963268010001,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948806,-88.49825622939052,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948877,-78.39556214148521,-37.84025689912436 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948901,-99.52097583864106,-1.0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,-17.656503547511917,25.12008317902446 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,-23.462299641357696,1.0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,-30.19279274069511,-42.474289214277505 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,-32.79739526036887,-1.0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,-42.38069492261995,-1.0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,-44.428767578524834,-1.0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,-94.78034712298602,74.88785165968652 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948917,-47.564579811556065,0.28108125199805967 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.570796326794892,-0.07047435740600211,-0.3621280556840791 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948926,-44.29697155252232,-1.2994262207056124E-113 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948941,-1.5707963267948966,0.36208927646584294 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,0.0,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-0.405173005371422,32.0152936398704 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-100.0,62.48674061597896 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-1.4497993087225014,-1.0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-1.5707963267948966,0.27630473401804917 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-46.41119920225104,-46.992631786565006 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948957,-10.936463512562938,1.0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948961,-0.263767230881887,-1.0003255613648054 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948961,-53.7123140845899,-0.009863982097046883 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948961,-74.14167069604308,6.179583597564427 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948961,-77.21844100050718,-0.3803076683644573 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948961,-95.63573903111151,1.0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948963,-100.0,-0.06267130110683064 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948963,-1.5147372681698978,-85.85759798088789 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948963,-1.5707963267948983,1.0000006305156728 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948963,-48.87478401928561,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948963,-52.0580128095978,-0.5775004608799243 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948963,-71.1521042050899,0.296134991824898 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948963,-8.907397293232478,0.49890477634025354 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.7080994820512675E-13,-1.5707963267948966,-87.74636998016106 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,2.429707484935603,-1.5707963267948628,-91.34858467254546 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,3.385225298859868,-1.2317213917359444,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-3.552713678800501E-15,-3.0824499780894676,0.0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-3.552713678800501E-15,-74.97881819253791,-12.939245758582715 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-4.440892098500626E-16,-10.98339666982875,-0.2740156849957349 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-5.9989938727379605E-15,-0.2899043171735063,-1.0302213415246048E-8 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,6.435927492248408,-8.593551885921695,100.0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-7.105427357601002E-15,-62.45188902918206,0.8708998794061271 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark13(-10.009375636387936,-1.5707963267948948,-57.8209132471125,-0.9999999999999964 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-9.649777383795462E-16,-1.5707963267948966,94.68939710242825 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark13(-1.00124087486975,-1.5675132519292578,-1.5707963267948966,0.43533378075595636 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark13(-10.012725091273046,-1.4732352734655592,-129.01441133115534,0.049412946543090544 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark13(-100.55879485357104,-1.3445068985391346,-44.147055662389704,-2069.344027244119 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark13(-100.60879312809405,-0.16611406280048913,-1.5707963267948966,0.10143680110394371 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark13(-100.83964501905733,-0.6038721859165871,-88.26242023636168,-0.027708680382133366 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark13(-100.90545569117924,14.430793535007432,-0.34512965481148505,0.8471878488998801 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark13(-1.0,-1.0128716524806611,0,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark13(-10.12574363729627,-0.2860804726938764,-90.64361953831282,-76.8362978577258 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark13(-10.133400873182069,-0.6896563094845859,-22.514379032715055,2288.239044091688 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark13(1.0,-1.4857402283189436,0,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark13(-101.59703968943144,-0.6333908097488079,-71.14815962176924,2143.290366636611 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark13(-10.215699733970624,-0.8932966134702087,-66.05339238330218,16.40704071249133 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark13(-102.27529489088204,-1.2621044000339665,-75.31191480777709,2137.462516910688 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark13(-102.67902322579499,14.43486931784848,-1.5707963267948966,-0.06038774204637265 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark13(-102.73109211181018,2.4317843436906634,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark13(-102.76178886126367,-0.24251886697451178,-46.52424969197247,2131.464994955339 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark13(-1.0283506406035092,-0.4483534766615539,-1.61391478982749,72.60635901954466 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark13(-102.97682679501118,-1.4741216737614442,-12.118736489655376,0.3580433029603398 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark13(-10.312672909515072,-1.5707963267948912,-25.625777453880858,4.11933262137137 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark13(-1.0319672267288007,-1.5369505943924446,-22.185531150769087,0.9730705051603025 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark13(-10.350635040051182,14.429571455567448,-1.5707963267948966,1.5434725260710005 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark13(-10.416384041232348,-0.5811851416329429,-77.56587164276223,0.8871200102238603 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark13(-104.26946130277828,-1.4025488311216363,-68.93024788302831,0.07922553606657934 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark13(-10.429334071568883,-1.2917111095654095,-92.32340052979104,-0.6637806201489167 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark13(-10.451172223470756,-7.888609052210118E-31,-31.818963904473456,0.005526380443780843 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark13(-104.59433881603977,-0.012112007046410855,-100.0,1.0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark13(-104.84521437834985,-7.105427357601002E-15,-66.9869985177622,-0.04230204691488737 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark13(-10.484568316786145,-0.36025018302529244,-43.12620300043609,-1.0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark13(-1.0494134383166238,-1.179353021936453,-1.5138501397304938,-56.23210405381594 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark13(-10.51780133206949,-0.44431655112805774,-69.0863431860104,-1.0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark13(-10.5951681409486,-1.5707963267948912,-43.10619210208168,-48.9074910610838 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark13(-10.641602137786528,-1.4019508292801575,-61.542264840207075,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark13(-10.659429208697311,-1.241047720001049,-34.86209377079334,0.1432273767307155 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark13(-10.685826674261818,-1.5707963267948912,-95.68247311796594,0.3059858221279086 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark13(-10.691016504997084,-0.3480220050698439,-3.2200075781413657,-4.0607069397050388E-115 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark13(-10.762444200230831,-0.009629118409101967,-28.30398702995764,-95.8392203262077 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark13(-10.767047985597317,-1.5707963267948912,-87.69865340100651,-0.019483474062676698 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark13(-107.74472232985646,-0.16850494554052953,-57.32524712802923,63.5025983147693 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark13(-10.788542130585629,-0.8982241772432964,-58.38382956186815,-0.820463073565089 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark13(-10.804399765130867,-1.5707963267948948,0.0,-0.8923599956283035 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark13(-10.811916675859406,-1.217032407543472,-67.54972589869634,1.0000000149965822 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark13(-10.929907994623722,-0.4693111206676406,-32.587040767027254,1.0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark13(-10.984373204776233,-1.570796326794893,0.0,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark13(-11.015006234246293,-1.5363317988379508,-1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark13(-11.113679630833587,-1.5707963267948912,-83.7453888915606,56.799450304343736 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark13(-11.1254501583185,-1.51819457509799,-47.62768722938937,-88.37922186551678 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark13(-11.17912829278189,-0.6191281770887469,-32.61865729238819,1.0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark13(-1.1196486833466217,-0.8178051522490293,-60.3494131571408,1.0000472675137069 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark13(-1.120299374404482,-0.3263719805071892,0,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark13(-11.229889925697128,-1.5230718869011668,-0.45726414373687624,0.5907626070834466 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark13(-11.243134299985513,-0.01539947509765727,-54.37795446484642,-1.000002575998962 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark13(-1.1272345042561107,-1.5707963267948948,-39.039805025417394,-0.06172417710291275 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark13(-112.7935717391672,-1.0431109428296814,-25.79114870587209,1.0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark13(-1.1307840548337185,-0.5320836555522244,-58.70763433021187,-1.0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark13(-11.411780661226576,-0.0617807788934176,0.3963802090729679,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark13(-11.432676710895505,14.429229951488885,-1.5707963267948966,0.059729709278816046 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark13(-11.55450591725453,-1.5707963267947196,-1.5707963267949048,1.0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark13(-115.57170735435867,-1.5332957819470252,-129.9044368012544,7.806581064818642E-4 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark13(-11.57824569269076,-0.307474903709792,-31.521719257463268,1.0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark13(-116.31728442176079,14.43664267558782,-1.5435522903892345,1.0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark13(-116.56115879247561,-0.5443224176621055,-119.78552032757331,-1.0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark13(-11.683911580807887,-0.8735604123359169,-52.90542620916752,0.7086689434589108 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark13(-117.51228299461872,-1.3395854710088648,-9.643974186130805,1.0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark13(-117.75755477148893,-0.6094266464539082,-59.34534705215789,-1957.6125358271975 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark13(-11.80949755808804,-1.2764221031305508E-14,-79.89779639173094,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark13(-1.183606660540505,-0.403771779676801,0.0,-0.2767107113311198 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark13(-11.855427998649922,6.429287386420438,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark13(-11.887739701980369,-1.1102230246251565E-16,-1.5707963267948957,89.76927840606811 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark13(-11.919815582392228,-0.8078655746578649,-35.377282762129234,-1.0000049279778644 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark13(-11.939960993623558,-0.795789983136789,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark13(-11.946697794243068,-0.1821856527918797,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark13(-119.67920278183831,-1.5488142488337193,-100.0,1.0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark13(-11.970109898471378,-1.3686158374428032,-186.7537623212707,-1.0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark13(-11.976423225399802,-1.7763568394002505E-15,0.0,-0.15138158626138543 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark13(-12.039526920363008,-1.5707963267948912,-4.429549642004487,-0.06258751665358972 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark13(-12.05172858018311,-0.8703219860393931,-24.664173400004515,-0.00839928150440572 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark13(-12.067791051713158,-1.5513082948190406,-75.13359093939712,1.0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark13(-1.2068644791594143,-0.041574446311859053,-19.382992407082735,-70.92333843977464 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark13(-12.211997904353403,-0.34479595224802867,-4.4540524585779195,-0.806206043673717 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark13(-12.228480383861267,-1.5707963267948912,-30.7113656461091,11.13847060423981 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark13(-122.36663222478808,-0.2456641916062523,-100.0,1.0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark13(-122.52927013681312,-1.5707963267948948,-1.5707963267948983,2178.6612357769955 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark13(-1.2258010269850814,-0.7672385886412092,-31.95404075177197,2225.715114209204 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark13(-12.270886197432253,-1.2657550020551747,-57.28520487517578,-0.6059766293490307 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark13(-12.27563092717878,-1.0826978110320837,-11.877693079493156,-0.01708416539992096 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark13(-12.287592342064082,-0.36605410182119297,-100.0,1.0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark13(-123.01600007674824,-0.9431088790104383,-52.55740664841889,-6.136419701670073E-4 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark13(-1.2312721042108166,-0.6442823674648261,-13.560426243103436,-57.38321435267778 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark13(-12.342451569170649,-0.03381794667410343,-12.881755290437349,0.08281663444682419 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark13(-12.352434131795697,-0.21781065602874028,-0.6249387223382729,88.00963774414677 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark13(-12.384417802740728,-0.2681708624553689,-32.93737246848714,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark13(-12.492273281106996,-0.23602679284339378,-26.07764430377709,-1.0000000000000142 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark13(-12.517197841156104,-0.3764163361990427,-26.69557886769202,1.0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark13(-12.598432771838196,-0.9256975360601242,-8.842440607745203,-0.0625628276489376 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark13(-1.2605758738240276,-1.5495131180945725,-27.776692141768034,0.9999999999999996 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark13(-1.2629193843144142,-1.5707963267948948,-4.361714185279752,-100.0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark13(-127.19054301865158,-0.8558704504132006,-106.06434896790232,-0.4172329643823671 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark13(-127.22632559051686,-0.33337775890777266,-59.03703186852858,-2219.276042873996 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark13(-12.762796804743353,-1.5100763001278494,-74.60750982308879,-28.50691791162062 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark13(-127.65638830148715,-1.5707963267948912,-25.459135971795916,0.3620892860635087 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark13(-12.88891347107981,-0.38971318637970104,-36.19597726061961,-1.0000000433014626 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark13(-12.894532675941653,-1.1937648948536994,-1.5707963267948966,-26.352884041118713 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark13(-1.292687575916318,-1.0305619025869752,0.0,-0.031670389803356236 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark13(-12.929074433927967,-0.27739154432593716,-5.942278602803253,0.0042312162377449725 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark13(-12.978539572860257,-1.5388551007769862,-0.9139369382774589,8.436209058132846 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark13(-13.002828528266427,-0.8597060015312676,-2.149424722835455,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark13(-13.026873682847688,-0.8182061157107857,-75.83731779152899,0.9810835702763488 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark13(-13.068068607405365,-1.4631289573494164,-83.7434224248621,92.25508413873158 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark13(-130.76289730523138,-0.19085988506923002,0.0,-79.84163739152315 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark13(-13.08107284061338,-0.7377739244947248,-1.5707963267948961,1929.1282170948048 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark13(-131.3773331502695,-0.8374170600182715,-163.86897005109267,1.0000967779474657 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark13(-13.143074780971016,-0.4629773195350656,-1.5707963267948963,5.874334353505901 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark13(-13.170526811057648,-0.8164968950532544,-0.03256738450366143,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark13(-13.22930733027843,-0.5236374280114688,-45.40905881521808,-0.6322570345893204 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark13(-13.230453337306953,-0.6162679787267521,-45.54042111999489,0.11765304949554212 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark13(-133.37061370313253,-0.7335378487998847,3.552713678800501E-15,-82.80292617509531 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark13(-13.408134514690431,-1.5707963267948912,-95.47121800153704,100.0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark13(-13.469455934245712,-0.8276690972515847,-1.467906650648708,-0.010327841576863145 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark13(-13.530411693943721,-1.445539921110742,-88.42314631161301,0.04265457641523881 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark13(-13.536737429783646,-1.3113926197456767,-9.761137384854536,0.9611691987437914 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark13(-1.3581353489089059,-0.39778821423767496,-59.23560321941332,-89.40357264725047 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark13(-13.67927911206562,-0.5701668854512336,-32.760202950310855,100.0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark13(-13.683256623521117,-1.1384247866012878,-16.610608542352136,63.07866317958293 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark13(-13.691749406019255,-1.0659843999235994,-81.49668725480782,-0.9865510579637862 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark13(-13.706785392277581,-3.552713678800501E-15,-31.020140883306233,93.19852475372059 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark13(-13.727393692646814,-0.9098880142389945,-1.5707963267948966,-0.3620927767732067 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark13(-13.737994176019457,-0.4902078797536453,-39.21083662924634,71.3453504801607 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark13(-13.79398817667071,-0.12491613223863848,-50.1494423641506,0.0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark13(-138.22633659843257,-1.038203116170763,-52.30531555032576,-57.51351594036356 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark13(-1.3826005084343846,-1.5707963267948912,-46.17245712435761,5.421010862427522E-20 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark13(-138.80370254649114,-1.2010311574478432,-67.92352241401852,2113.3184711324348 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark13(-140.25554740454493,2.821573141933683,-18.891366377688108,389.88290139020796 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark13(-140.9940594692273,-0.001425907184530062,-21.125743989099036,72.54361536645757 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark13(-14.103756554687616,-0.8488878234691546,-45.406659716359925,1.0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark13(-14.14932842425614,-1.2859188262638865,-0.5202099027244563,-1.0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark13(-141.50894093750028,-1.2310947593762522,-10.553840901075674,-2.4157388662839527E-15 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark13(-14.189923268956292,-1.507135614502206,-82.94564452374388,-0.9276509406314659 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark13(-14.22326365400177,-1.5707963267948957,-44.05915873849031,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark13(-142.4207969989127,-1.3775747328024486,-164.39356721837484,-0.06263467906677965 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark13(-1.4323249020653916,-1.1102230246251565E-16,-1.5707963267948912,49.624190389471025 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark13(-1.434318106302985,-1.4132811992116205,-43.24369905836009,-1.0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark13(-143.54886240108496,-1.0285664062935584,-38.874038169091094,1.0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark13(-14.42481498572765,-1.1102230246251565E-16,-28.48877820359479,0.0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark13(-14.658474693833321,-1.0852879960030577,-35.192173921836044,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark13(-14.805214166199814,-7.105427357601002E-15,-66.33149422230562,0.8805378155202728 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark13(-14.839871001042379,-1.4094363543147783,-100.77486710220198,71.04250078939044 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark13(-148.44651707329407,-1.5707963267948912,-43.44006804573568,2431.8455011804213 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark13(-14.852520779075382,-0.16781125171669523,-32.59951231437927,-0.05427731559110078 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark13(-14.881719061611609,-0.18025997092769264,-0.4869705817401925,5.551115123125783E-17 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark13(-149.03922519010948,-0.8319180976190574,-55.52402749018022,-1.0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark13(-1.492881524816994,-0.5705519816958871,-38.89421587162371,-86.54251829177531 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark13(-150.36364781845714,-0.33504248876548515,-33.87695880679635,0.6444222599504483 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark13(-1.5038460525554664,-1.5707963267948961,-1.2304422070147325,6.3174603311753045E-176 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark13(-15.056699210101442,-1.5699675494075809,-24.81456257363321,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark13(-150.68074136656514,-0.3244870859895883,-61.365854032484826,-1.0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark13(-15.127391451435315,-1.3707983682039675,-38.92687953218492,-1.0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark13(-15.149463024269508,-1.5707963267948941,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark13(-1.5174505342808668,-0.5572486351006635,-0.19644554943398562,-11.761658524899339 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark13(-15.188524946808922,-1.5707963267948912,-22.833182078392817,1.0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark13(-15.280854746303248,-1.5707963267948912,-13.736575272727128,1.0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark13(-15.314015616942271,-4.312252929384845E-17,-1.5707963267948966,44.75019430723924 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark13(-1.5364585932181,-1.1088051101054397,-33.399296212723215,-79.15744500782739 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark13(-1.5374687248725585,-1.5681318541562579,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark13(-15.427612011233398,-0.3045895222198983,-0.5333319848682567,0.9011775851368229 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark13(-15.46449590580103,-1.1288399131572164,-31.624127271583454,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark13(-15.510266936811433,-52.619796582660314,9.231662866838079,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark13(-15.544312459731135,-1.3954284739479887,-66.8692502749506,6.776263578034403E-21 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark13(-15.548248643242099,-1.1617775744630967,-60.797399516086166,0.04905566530979996 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark13(-15.560819757322534,-0.0949575720813382,-1.5453337088415604,-0.06144052729059646 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark13(-15.561904768279298,-5.38112856978393E-17,-18.490779172580815,-1.0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark13(-15.6214610825669,-2.220446049250313E-16,-1.5707963267948966,0.11909972717181112 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark13(-15.627085040212023,-0.09780573106039753,-75.8059165019593,-48.43938452501286 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark13(-1.5684279886333863,-0.6830601678324549,-80.31717826328233,0.9999999999999999 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark13(-1.5745378087518072,-1.570513145001356,-45.18951323548144,0.21160982269737316 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark13(-157.9063076149753,-1.057441377883201,-102.0904901833787,-92.46035000469539 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark13(-15.881966862191884,-1.4039452802324899,-1.9090685513095422,0.3683957679162909 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark13(-15.884628733177365,-0.4256745098670219,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark13(-15.926254064615632,-0.05948249233971725,-71.68729306836761,-0.3621068346172655 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark13(-15.926807561801553,-3.552713678800501E-15,-31.56852133217285,0.46442599624579195 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark13(-15.929306104354318,-1.4998857088953181,-53.95143173141983,-0.46896599685589013 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark13(-15.962677260651375,-1.0649880161446532,-41.185096754778655,-66.96333697836552 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark13(-15.96360567146587,-1.280292494382398,-31.222570065034773,-1.0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark13(-159.73590689361032,-0.33786920522115027,-163.6624944545314,-0.9999997082546713 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark13(-15.989054524814293,-1.40913831978293,-0.0030986153426748597,-0.05059860366401758 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark13(-16.058287229765867,-0.3015218427283303,-100.0,9.273015376718553E-69 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark13(-1.6089893304479261,-0.2499416158157879,-90.360091816287,-0.9999999999999982 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark13(-16.09734390867836,-0.14573783989326827,-80.2792121933044,80.0685293678084 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark13(-1.6102076732010882,-1.477713831590185,-42.4739056484565,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark13(-16.117430890926016,-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark13(-16.137669090173176,-0.8264529265877307,-41.64862335321727,-39.39967064999941 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark13(-161.39540273326043,-1.3492469027408802,-192.09425680244965,0.9999999969115957 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark13(-16.152184052122305,-1.2798431707375726,-14.534832622485512,-1.0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark13(-16.280873591707238,-0.33798860029433775,-0.25817459624616723,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark13(-16.282485592627182,1.2785706893584174,-25.179562315474453,-40.81796399255319 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark13(-16.33129669452091,-1.5707963267948877,-42.008746606573496,100.0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark13(-16.355122092122116,-1.1622667352259628,-7.831056133343665,1.000148152441638 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark13(-16.36737074697404,-1.2135745082472837,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark13(-16.368794453740534,-1.1460101572171002,-4.393611113709518,-65.72287699522407 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark13(-1.6416059238916074,-0.053179485768160006,-6.4729443035461705,1.0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark13(-16.442392343795156,-0.4601361981322034,-0.04239693731590751,1.0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark13(-1.6461424130949611,-0.38510017280130787,-91.59346138635553,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark13(-16.4643805246249,-0.5886148009159677,-31.174925470207466,-0.9999999999999991 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark13(-165.89763720231872,-0.5401635131760907,-79.50613313199236,-1.0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark13(-16.59495875610953,-1.0294062933565116,-11.177066496191257,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark13(-16.617619864300707,-0.9166859376016703,-98.02043935104456,0.19461895037060184 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark13(-16.63965593354991,-0.0016457858160345582,-4.618118035947587,0.7204529929261412 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark13(-16.658167844954164,-1.3275314784868828,-95.77596641671879,0.014125179586493059 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark13(-16.694941939675907,-0.7835323968970576,-26.919904418247455,-0.9354529694224666 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark13(-167.34540028574537,-0.004105730597405488,-38.936273795046695,1449.1301519605831 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark13(-16.74812281011706,-0.5423159323128891,-10.661917715096394,-1825.5463944721591 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark13(-167.77995145252225,-0.6954726408208813,-159.86576315268377,0.022247788040457094 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark13(-16.812558278938354,14.437783612171224,0.0,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark13(-16.859429597205235,-1.5707963267948022,-13.753706645966645,-1.0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark13(-16.90942081252669,-0.44157076555775454,-31.10657426203754,1.0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark13(-16.914051177079433,0.060951319581658114,-71.2648604862585,864.2753238760289 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark13(-1.6977424480525505,-0.16778747135801753,-52.28073049523414,51.87821251488316 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark13(-1.7089832580949036,-0.04861384902172082,-65.17179715129237,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark13(-17.19046777313858,-0.6060898983250436,-86.33377373605975,-1.0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark13(-17.200319503897557,-0.5450760133933934,-66.4464047534984,37.895677370811455 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark13(-17.343636241849175,-0.11042928763133467,-46.584896726160174,-98.07283888418645 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark13(-1.736787769177187,-1.289761458309708,-15.48825518723049,-0.056059243555299926 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark13(-173.90131246731943,-0.0703885808033501,-10.824489214662824,0.06257978951654732 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark13(-17.52446761151558,-0.744359230262964,-46.92729776869653,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark13(-1.7559052641949426,-0.7239939070798016,-88.32154502836346,100.0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark13(-17.562572750321237,-0.24957380752929634,0.0,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark13(-17.61029555489388,-0.3918251669786681,-96.58047020714686,10.267847886806123 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark13(-176.45734753462034,-0.4279180277050363,-0.8696180595802421,88.91988249250184 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark13(-17.66031665066996,-2.220446049250313E-16,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark13(-17.6993887998738,-0.6185526185808706,-51.34872278352382,40.87657180932362 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark13(-17.714833310442867,-0.30631058749186413,-32.74102442118836,1.0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark13(-17.742418280911963,-1.5424611922143998,-34.188958391837694,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark13(-17.746102224116967,93.94551953657492,-77.26561603092586,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark13(-17.797727962354216,-0.3292084563416662,-88.17832076997246,-4.873114283261998 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark13(-17.825415128836838,-1.5707963267948912,-66.44400716660988,1.0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark13(-17.8323176295214,-1.5707963267948948,-93.04947799924443,0.9635606759391493 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark13(-17.8424962238225,1.1493499766689552,-3.364052271868691,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark13(-17.961240617482346,-0.06330486884491905,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark13(-17.994304626316058,-0.30233152534595314,-44.27417066746705,0.004984156606641643 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark13(-18.001700328338533,-6.699141371896725E-4,-77.5118006769203,-0.24498856521617696 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark13(-18.03025571907097,-0.842756836787089,-79.11318380102828,-0.018313019509881196 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark13(-18.039913799264866,-1.5707963267948926,-33.389711718641976,3.944304526105059E-31 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark13(-18.156646921887187,-1.5690956853038718,-92.94720757594709,-1.000003414747036 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark13(-18.24491600146602,-1.5581895024884433,-1.5707963267948966,-0.05480429377663956 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark13(-18.292091907638408,-0.18468438084992825,-1.5707963267948966,0.06257267650679402 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark13(-18.30893903482895,-8.881784197001252E-16,-18.47632904484489,40.72188324527929 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark13(-18.555272958868045,-0.05822621951784428,-62.761211239734884,3.552713678800501E-15 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark13(-18.58179535823203,-1.5707963267948912,-100.0,-0.4751314550213088 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark13(-18.645518480536552,-1.5258154476904031,-60.875350651763576,9.273015376718553E-69 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark13(-18.712947800357043,-0.14453973142448273,-51.712677259344936,5.30346597517628 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark13(-18.731190976163745,14.434312138424971,-28.90752264370957,86.28773627680744 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark13(-18.73329432286211,-1.5707963267948961,-12.537886444963714,0.04830969064280971 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark13(-18.741726794513372,-1.5707963267948948,-72.8311536055311,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark13(-18.76730786892105,-0.46254425407651345,0.0,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark13(-18.803803012018896,-0.012183443850265187,-32.80914949218239,-0.0382933544440211 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark13(-18.819883726811106,-0.27860739776889876,-84.02877220130986,1.0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark13(-188.96725381174738,-0.6117324139595859,-87.78333748076182,-88.88791717459907 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark13(-18.962439632044074,-2.220446049250313E-16,4.930380657631324E-32,-0.06259181324490959 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark13(-19.080400553227083,-0.4043269678594219,0.0,-1.0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark13(-19.278361813627907,-0.7639342193175613,-33.29863560495754,-78.88972978533306 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark13(-19.331914754251542,-3.3366636340288213E-15,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark13(-19.39544910213123,-0.002920857574111675,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark13(-19.422482985606777,-1.5707963267948912,-95.44439619834024,-0.9938212437104994 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark13(-19.451969243951243,-1.0888172411917028,-78.68532046484452,-0.05485596364439407 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark13(-194.5579698594738,14.429207574651166,-28.68438071103509,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark13(-19.518671396083775,-0.44687583714187085,-2.485754065889786,0.9999999999999991 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark13(-1.9545108157246887,-0.0077831988868064484,-79.09151021256953,1.0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark13(-19.552433478558658,2.545089175186639,-0.3848746488343362,21.005524373287003 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark13(-1.9593271809467812,-1.570631566773796,-59.27678305465796,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark13(-19.608719162629942,-1.4520496947252326,-100.0,0.18200563881128995 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark13(-19.614957217454506,-0.4264782225360554,-1.5565407112452339,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark13(-19.63354322296002,-0.9461196054318748,-142.5615296161107,-0.23185885375222948 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark13(-19.641333993055795,-0.13431967638873804,0.0,-1.0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark13(-19.67280278496385,-0.8608748321393307,-1.5707963267948983,-0.31587013787508056 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark13(-19.723248753209475,6.9037240794935295,-130.3256173735721,-1517.464782570576 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark13(-1.9723323196751839,-0.9717265044090047,-1.5707963267948966,1.000000066654941 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark13(-1.9760058162366372,-1.234266813118305,-64.91599665531052,-76.78218044996737 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark13(-19.765014550209102,-1.3135837032382665,-31.769327153573542,-1.0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark13(-19.864648199182845,-1.3783405433589242,-29.949414919871984,-67.63625689979666 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark13(-19.933453928078777,-0.6355766861610375,0.0,-1.0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark13(-20.06065633308431,-1.2639822999616817,-4.5104436851897844,-75.954526874464 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark13(-20.071012116959054,-0.7131230724026479,-34.53719985000765,1.0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark13(-2.00878379587229,-0.5401441550248993,-1.5707963267949037,-44.35219364804996 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark13(-20.120271573886754,-0.07822364702609795,-1.5707963267948966,5.403227209783267E-225 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark13(-20.132408545957745,-1.7763568394002505E-15,-2.5050600729302914,0.170325852631791 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark13(-20.153326299677012,-1.0365593485583142,-37.263545586964106,-1.0240593117094505 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark13(-20.167382031499187,-0.5312259098679868,-48.84745346830209,-1.0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark13(-20.194890210229616,-0.06411070960495904,-4.4386431921289216,-0.7036459517526534 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark13(-20.272930852019257,-1.363565458631123,-43.24919794097071,-0.9604919606965467 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark13(-20.277263742733552,-1.3005379897086655,-32.5835863499871,-0.6630459305229539 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark13(-20.29089393814973,-0.007541018952692701,-1.5707963267948966,-0.5703520163461263 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark13(-20.29154121510308,-1.5707963267948912,-57.40886199319202,-82.55876863795774 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark13(-20.343719267814944,-1.5707963267948948,-45.776537495147316,0.11868940902903402 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark13(-20.35561902391605,-0.06327397436095133,-12.386477791846232,-46.56898261298499 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark13(-20.369707670515282,-1.0682981049870204,-48.068460820439306,-1.0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark13(-2.0395283843190875,-0.3479109308291425,50.958827203636346,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark13(-20.396300589459162,-0.22217926380384892,-50.141510560627374,-33.80295562458375 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark13(-20.40852867269946,-1.5707963267948948,-85.72258009501317,47.48502323104901 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark13(-20.425666625611605,-1.3011981072089611,-1.2117842542327608,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark13(-20.4734704252119,-1.267360496885783,-10.534183539660026,-0.019902605581747362 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark13(-20.508639939023578,-0.39942605150762983,-37.83795634048132,-1.0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark13(-2.055193552433021,-1.1102230246251565E-16,-1.830593187543943,0.9999999999999999 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark13(-20.591780247083705,-0.10203032987893952,-66.99586310428057,0.0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark13(-20.61951848865469,-0.403435487801352,-35.83955040673982,-1.0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark13(-20.660891568856066,-0.3308368273823274,-13.703953724231244,-0.9996268956505715 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark13(-2.0983610980528327,1.855850000259928,-1.5707963267948968,-100.0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark13(-21.07385725412243,-0.7419071802892006,-1.940840929187182,1.0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark13(-21.134756393091372,-1.5707963267948961,-11.574128822644068,-1.0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark13(-21.19673182766483,-0.8585433156507255,-4.502779207205995,40.63498291276137 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark13(-21.249356472657063,-0.6840666992473825,-64.40158453808586,-0.9886126481596852 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark13(-2.1287828094978796,-1.4364047418471577,-31.497114715601736,31.837538628974485 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark13(-21.32900861957083,-0.229068898568515,-49.23503720555242,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark13(-21.330719372548142,-0.3767397514856935,-95.31132735071243,-99.79161671872005 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark13(-21.35611942095212,-0.08961719006959568,-44.38731327968435,1.0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark13(-21.435859469646655,-1.5658725440602035,0.0,-0.9999999999999996 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark13(-21.491901168476925,-0.6736420946345503,-19.065007267621326,0.2132979780688089 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark13(-21.498906647585642,-1.5707963267948957,-4.045833057559813,0.5658602947146534 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark13(-21.534160624915934,-1.541997473543397,-71.65714507286155,-1.0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark13(-21.605161256538523,-1.5512150405771852,-48.8084136586347,-1.0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark13(-21.611901847917633,-0.06462916548420594,-77.57121882497859,-0.017594659273684123 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark13(-21.657280864562946,14.432048238660236,-56.86432574790743,79.44411196740116 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark13(-21.66395418039086,-1.5521958447847268,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark13(-2.168357373639827,-0.31214963831439807,-39.79714277277945,22.401108939251973 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark13(-21.689949257254472,-1.3041732904487584,-135.59091475650757,-1.0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark13(-21.885868383661776,-1.5594095434067776,-38.83401466344829,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark13(-21.981376884409315,-1.5707963267948957,-2485.7473599897307,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark13(-22.001527214806032,-1.5642147208350003,-95.8775175072149,-1.0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark13(-22.0068737215067,-0.472897820384249,-4.244985401027236,1.0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark13(-2.2034449579962567,-0.060603370962491604,-28.110126000817434,-61.47875709830928 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark13(-22.113158635618674,-0.5248652585040642,-67.52253781144913,-23.109427161693375 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark13(-22.18468280052298,-0.6617234981939788,-75.67540369296731,-1.0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark13(-22.25749113359036,-0.6159140715554583,-1.5707963267948957,-1.0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark13(-22.292280649843818,-0.2569663028995698,-41.27546059178445,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark13(-22.32945585503208,-0.014731638505619876,-47.999973264864344,-1.0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark13(-22.3375592365794,-1.5319625678012645,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark13(-22.376694825932354,-1.4367437893649246,-71.623802434207,-2.5988524414112248E-113 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark13(-22.403068911259652,-1.3663159357382328,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark13(-22.42991701316727,-1.4997281520684642,0.0,-0.028586832624733105 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark13(-22.453958018525668,-0.01612411550052062,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark13(-22.481742451715824,-0.015166403676550862,-9.505883443303446,-0.5448012558984578 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark13(-22.48488154385646,-0.5421797014812824,-1.5707963267948966,32.25394872500763 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark13(-2.253111998461597,-0.08013319687805802,0.0,-1.0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark13(-22.643841676048666,-0.5176251920977966,-131.880816341255,0.9994835882276029 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark13(-2.2733663211514785,-0.006202771621345982,-15.723972007833225,0.0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark13(-22.74588794030224,-1.5707963267948846,-88.4316815912893,-1.0124300124423322 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark13(-22.768049859697186,-1.286336640829457,-88.2526162878108,14.501019584774724 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark13(-22.803056377530957,-0.22044482885940786,-43.024457828401964,53.57766969904899 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark13(-2.2883913585366877,-0.4485658895857024,-0.2125206427180495,100.0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark13(-22.99399183361222,-0.6968153095872135,0.0,-1.0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark13(-23.008337145967605,-1.5366823578390787,-20.092951049375856,-0.0626624565989368 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark13(-23.049757205014203,-1.5707963267948912,-46.543683390476794,83.91626589815462 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark13(-23.114264178141976,-2.220446049250313E-16,0,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark13(-23.13477633746576,-0.00335180495627145,-0.4753535381732995,0.8647814114620704 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark13(-23.13751569068218,-0.08432590642320205,-15.288795507708025,0.6895104263952598 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark13(-23.280582999376346,-1.5007373748730677,-1.5707963267948968,-2232.4930362313526 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark13(-23.322622499174514,-1.2990769131958282,-45.244507273701686,98.3498799876084 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark13(-23.348469958966593,-0.7965621889168031,-23.57367895704745,0.9190769562671441 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark13(-2.337818063357959,-0.25146769294055493,-15.380864645322688,0.01508720674169152 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark13(-2.338253878616655,-7.105427357601002E-15,-37.659032322286464,0.07279629482903249 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark13(-23.402054129334196,-0.07670617173285196,-44.115274892762415,72.38918812558717 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark13(-23.41250506628814,-0.3521729617652307,-69.04710644048004,-0.04622896515306067 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark13(-2.3421385968408543,-1.4364239219584878,-22.251048306097516,0.5081274173264174 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark13(-23.51576672555222,-0.8436526961860861,-1.5707963267948966,-54.56479851777724 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark13(-23.548125631170663,-1.2676430815996467,-53.765661130071216,-34.184653732874544 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark13(-23.588621226295572,-0.4234046743900466,-78.17532533467934,-0.33483722804992877 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark13(-2.3596154938193425,-0.7115622300806743,-77.45738955199732,-0.06255535188191362 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark13(-23.601863962156926,-0.4672344756934055,-2.859504015750448,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark13(-23.626817208313756,-0.14864199824193497,-13.284267435591389,-0.7167505088621411 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark13(-23.63332141880312,-1.5707963267948957,-13.984711064885879,-51.51157503686727 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark13(-23.656843860071348,-1.5707963267948961,-98.57037526516248,11.378961233333044 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark13(-23.682377653236088,-0.19926520651407031,0,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark13(-23.711652728559017,-1.3340185134422584,-73.41158897341755,-24.02925511894152 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark13(-23.712317698014463,-0.5281527585819106,-1.358788771068177,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark13(-23.80161118664924,-1.5707963267948961,-73.67769489913154,0.11871409017952805 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark13(-23.812485641195003,-1.5528575971110112,-9.984337767446885,0.06177239289175776 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark13(-23.845149390185338,-0.564817750134408,-65.85379792725067,1.0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark13(-23.856565861705832,-0.1997753540727274,-33.98227498299207,10.659287232128719 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark13(-23.88628817722997,-0.23134758204227346,-135.54203539427905,-13.293795218788375 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark13(-23.914820467299595,-1.5210936445546486,-31.59506670829616,1.000000037640355 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark13(-23.97226553466116,-1.169449482365124,-69.46419978022746,0.13550227329972664 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark13(-23.98525843486308,-1.5586793724329993,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark13(-24.01912291667935,7.506845873622955,-94.37021074904128,100.0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark13(-2.4062966713731875,-0.17481163025937008,-57.95304768678443,-1.0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark13(-24.067541213033117,-0.12138087239641226,-45.32090435524036,1.0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark13(-24.07637189713211,-0.2263116067328634,-73.48826850144607,-62.319143205399484 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark13(-24.090404228462546,-0.1894335787675263,-9.794276714346474,1980.3975090466315 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark13(-24.20652319476276,-1.2670408375667548,-0.6814578167566658,-0.22915419302840812 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark13(-24.26722006552083,-0.6694458151666982,-61.57346650609873,-2106.834371230357 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark13(-24.270281902081564,-1.2354106044337878,-45.08451057350655,-86.24347545442284 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark13(-24.295944307834915,-0.5392768683821743,-17.501504326559008,0.0023352616382255713 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark13(-24.307842393893132,-0.6133662323406497,-2.605913349217999,1.0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark13(-24.394007560786605,-0.9230488300874948,-1.1257846287068527,-1.0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark13(-2.4445524681466395,-0.2519245077271235,-53.31546707449964,20.99750919026995 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark13(-24.480720499106315,-0.8814315446375403,-66.35340418236973,-1.0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark13(-24.63767604682387,-0.4925339929982681,-1.5707963267948912,0.0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark13(-24.64092060880847,-1.5707963267948912,-86.99734170874969,37.24487580911406 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark13(-24.71234687803903,-1.1383865049731878,-17.182708785990997,-2248.574639893652 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark13(-24.777550020170487,-0.8368995020238597,-1.074509696924284,0.046962837397192744 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark13(-24.784361701052262,-1.5707963267948948,-4.643775177539158,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark13(-2.4790308296342154,-0.12118869171881186,-1.5707963267949054,69.2877344793666 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark13(-25.02537699607231,14.429989448423377,-3.2330080822091247,2.127124245072509E-15 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark13(-25.06323851548961,0.1476972970176068,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark13(-25.071772071996293,-0.501271746580339,-1.307684833961635,56.19974619050358 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark13(-25.109627371125995,-0.012302482648632151,-1.5707963267948992,-1.0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark13(-25.170036804411183,-1.5439143102858193,-18.369527836451866,0.8411830641509324 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark13(-25.205762166165968,-0.9526886589437134,-69.10233672228841,-1.0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark13(-25.392567407989915,-0.013343200580573922,-21.549279480470148,47.62846793969126 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark13(-25.416562214122525,-1.4763947319263284,-19.734988107631967,-2162.0999896858743 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark13(-25.439895952031428,-2.220446049250313E-16,-45.49759299081035,4.6421789750039775E-6 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark13(-25.534587309413368,-0.6695594149254124,-39.570889494589764,0.9823919384818872 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark13(-25.58179468707364,-0.6917546861515689,-98.12527221648249,9.584402393776813 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark13(-25.60222576782267,-3.4606436904672568E-15,-16.532177883035892,-1.0000000000000004 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark13(-25.610696535609947,-0.7934505317149458,-77.19135852505147,1.0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark13(-25.660442692464823,-0.5180747139704658,-1.5707963267948983,-0.9298107973788293 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark13(-25.736945035368045,-1.2744165765036772,-1.5707963267948966,-54.74590240717744 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark13(-2.5800117998059164,-1.5707963267948941,0,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark13(-25.82208286454749,-1.0741241265826371,-94.30271266571818,6.152044626493906E-15 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark13(-25.93900776072141,-0.5530152735712719,-60.26133656716294,-93.57725993546217 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark13(-25.98852684497165,-1.452911759530069,-95.34298509354585,-1.0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark13(-26.049951183285543,-8.881784197001252E-16,-52.17980927753343,1.0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark13(-26.069378650042722,-1.157237416510261,-95.37584278912313,1.000000204873129 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark13(-2.612396239373183,-0.24298209913689706,-1.5707963267948966,75.61309459862426 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark13(-26.12479163915417,-1.5448328642816365,-92.56096618230994,1.0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark13(-26.293251696567893,-0.5043258668640633,-44.525119574074566,-100.0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark13(-26.379689168082194,-1.5707963267948948,-65.50192473030671,-52.19863880614235 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark13(-26.456455559100785,-0.6781262144783549,-1.5707963267948966,-1.0000000000001164 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark13(-26.482890143004465,-1.0985365055630174,-6.464775434910555,2.158023920719911 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark13(-26.490132207555096,-0.22475751746103234,-3.411492621675194,0.9004357827195367 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark13(-26.61345402932594,-0.5023538652114911,-98.43744125997091,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark13(-26.630261432358783,-1.5707963267948912,-53.74192057314907,-95.07357204550348 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark13(-26.777880439390923,-1.5707963267948948,-80.60897807240565,-0.01713006649925647 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark13(-26.888125796629996,-0.9347900125760192,-9.493118198044698,-0.9993016621091093 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark13(-27.086471904292598,-0.3884255943478076,-1.089426434785345,-8.419899706133634 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark13(-27.18697351463885,-0.6446239735213182,-78.85493628913113,18.691536050580225 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark13(-27.249043439097747,-0.3792084187327077,-83.82781173435077,-93.06988612808924 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark13(-27.2497131180684,-1.196197479004065,-23.805834895277425,0.0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark13(-27.26968547962802,-0.23609539868039375,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark13(-27.27269198719084,-0.0218027311093712,-19.389070587950165,-0.9377558267038257 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark13(-27.312039240627712,-0.050145574972267265,-20.612859429290253,-1.0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark13(-27.317708981738775,-1.126897971338692,-33.67349424212213,3.2944368572595385E-83 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark13(-2.7322897513609803,-1.2507751092457289,-1.5707963267948972,-0.14101443566327165 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark13(-27.355741427541485,-0.8850879489858501,-100.0,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark13(-27.44360742577712,6.854445457716268,-10.746779856357392,30.545653980784873 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark13(-27.52119373371501,-1.3387705210188803,-29.694945345127397,-68.79648000769846 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark13(-27.555457531855463,-1.44334331193143,-71.18959762838418,-1.0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark13(-27.689739049703988,-0.022459680581815484,-1.5707963267948966,2268.610201872342 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark13(-27.769239254056494,-0.4956719964665517,-1.5707963267948966,-56.71055472263349 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark13(-27.78499047273356,-0.003433177062412183,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark13(-27.833663385346334,-2.905534854462022E-7,-3.123455231500095,-0.4510611485986525 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark13(-27.932741742413025,-0.20383584994735013,1.7294294635264496,75.11430799718194 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark13(-27.99598975962358,-1.1424609575766214,-55.49434137647891,52.02173781236263 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark13(-2.8104800595688744,-0.7318961300329031,-45.50504304337507,88.50726267151963 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark13(-28.134769749527138,-8.992372905924427,0,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark13(-28.202888878935063,-0.24511455415263467,-1.5707963267948983,0.019094298936489142 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark13(-28.228585029475425,-0.39364373824592624,-67.13615290322846,0.0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark13(-28.24133158497079,-0.22732042892571627,-74.49338744656195,-0.9545113437800886 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark13(-28.26121866559771,-0.002797775617967291,0.0,-1.0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark13(-28.27003082787576,-0.27100906131804514,-44.29194918905318,-54.94250617581785 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark13(-28.281006324705942,-1.3379114748537546,-86.88340429998075,27.159721623528668 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark13(-2.8286168002677794,-0.39336881440805294,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark13(-28.35906761231888,-0.020865124846395355,-6.74667497520484,1.0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark13(-28.507647706885944,-0.780481553943475,-0.01055156911056757,-6.143858550027401 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark13(-2.8532077560343723,-3.552713678800501E-15,-40.84766160220181,-88.04011767485889 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark13(-2.85978982762778,-0.33001079119773835,-41.28710395203426,0.15583298936861156 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark13(-28.623949358256382,-0.48070867388605026,-72.74776022929187,-0.8997228085411122 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark13(-28.681361008290512,-1.429736878029207,-1.5707963267948966,-61.52947401334862 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark13(-28.713949061935082,-0.9402738727416603,-80.02088872923542,-1.0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark13(-28.781522563090967,-2.220446049250313E-16,-10.845673230187293,-0.8524082325495723 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark13(-28.870529313782004,-1.5481904298814821,-1.5707963267948961,1.0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark13(-28.882338094004773,-3.552713678800501E-15,-0.12000050346593828,25.32000141726934 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark13(-29.086002963777723,-0.7337558293987696,0.0,-9.878076815455898 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark13(-29.114333735307923,-0.12411478271836268,-89.2708507354383,1.0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark13(-29.151862283620318,-0.08117524782622651,-1.2733851897600845,30.46085312835333 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark13(-29.178282818408352,-1.5707075185220054,-66.19849818427751,0.9830640231993002 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark13(-29.240508612833914,-1.5424758860782983,-112.62284575155857,7.493061360848548 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark13(-29.35761997578139,-0.053013192486650186,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark13(-2.946110235371,-1.3318059097731814,0.0,-184.56329672209623 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark13(-29.603391591622543,-1.512698698203657,-1.5451756315158431,92.14638285479987 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark13(-29.73129890603775,-0.8998974226375873,-64.44128455542584,-9.54847466954493 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark13(-29.847513194449334,-1.2210365129846668,-68.39299411570113,1.0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark13(-29.8837489813083,-0.7472646377999778,-42.479931707771506,-1.0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark13(-29.974921251458397,-1.1727641952719288,-163.77205469869727,-84.64370017940452 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark13(-29.99612292316141,-0.8900753565913249,-37.870285252756965,-1.0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark13(-30.013540176804216,-0.7576394893978313,-72.643941630265,-0.5751609557029327 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark13(-30.03458048240574,-1.4454250143821659,-13.784590060044348,0.0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark13(-30.130804975433993,-0.07051920709894603,-1.3557715821671377,0.0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark13(-30.17233776337141,-1.5707963267948948,-86.702518885943,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark13(-30.181348000674564,-1.5481692841281414,-53.04103062270689,1.0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark13(-30.252028566246754,-1.5707963267948963,-1.5707963267948966,-0.06257034015508664 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark13(-30.260345550668347,-1.1153780677925091,-121.84528973862977,11.39293128182986 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark13(-30.262951701905696,-0.05666215793196981,-10.7084087206579,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark13(-30.309634585366155,-0.7489739505622204,-25.663839153821684,-57.674098802241744 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark13(-30.338909246148095,-1.4236550729633852,-89.53535735924021,-1.0000059899948799 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark13(-30.372410402609873,-1.353559211899914,-86.56888348932705,0.9594523413034166 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark13(-30.55011499681305,-1.217256283044127,-58.99542412800273,-1.0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark13(-30.55205781468547,-1.557894277354805,-66.02980608740819,0.0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark13(-30.55512944225933,-0.010564824994462485,-0.023198049413121206,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark13(-30.55755511678903,-3.734213272928906E-15,-31.208982187306827,1.0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark13(-30.78458184519169,-0.3187639546670881,-45.79077666265935,-54.242429250900635 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark13(-3.079231788556312,-1.4246125053087744,-1.5707963267948957,-21.596071341909763 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark13(-30.927936159051917,-0.8298949467726114,-66.84574597535078,1.0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark13(-30.97588827290137,-1.551721801608069,-1.5707963267948963,-52.00610505051234 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark13(-3.1008937761516497,-0.4548521158128318,-1.5707963267948966,-11.730680806566617 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark13(-31.074668076509198,-0.7220212021526233,-24.610217933364993,-20.713446464789342 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark13(-31.07747998526831,-1.313948431699913,-14.551313840511167,1.0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark13(-31.169786062300666,-1.5707963267948948,-62.43094180565833,-0.22740750781160646 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark13(-31.17304279209612,-1.1226785033373978,-72.60889753947212,-0.5507899737804063 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark13(-31.181103801182836,0.3813687749582598,-1.609171250433211,0.3498636851301652 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark13(-31.1904160424994,-0.8942883314061602,-27.737621859251824,0.0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark13(-31.24748664773084,-0.4227582973846894,-88.51699175838819,20.02861694428377 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark13(-31.27364846700361,-1.5707963267948912,-66.04945409208781,1.0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark13(-31.30867565946815,-1.5605821227635033,-72.71627264337646,0.5783194316576343 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark13(-31.43662072139304,-1.1220644504301507,-51.13700915649921,1.0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark13(-31.445845028443156,-1.5212393132629884,-77.141208025771,-1.0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark13(-31.45495385533792,-0.4831408835356066,-100.95094601134514,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark13(-31.554858936724713,-0.20277432219218874,0.0,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark13(-3.1600873065124304,-0.5235472242945169,-1.5707963267948966,-55.587598489136376 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark13(-31.781570796404623,-1.019556677345376,-2.220446049250313E-16,27.475793974080965 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark13(-31.816665736518296,-1.4843942197891349,-31.85304517288884,-12.835067455264834 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark13(-31.93885016588524,-0.41743029901762896,-1.5707963267948628,7.105427357601002E-15 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark13(-31.987053171298513,-0.6940562984306275,-59.57645073801299,-1.0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark13(-31.995258198048887,-1.5707963267948912,-99.39340957923267,46.97291682438063 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark13(-32.006649423848245,-0.8929304454212854,-74.45756532199964,-2046.45357749117 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark13(-32.00743554858143,-1.5707963267948948,-0.036891308318573596,1.0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark13(-32.02127304246473,-0.027360090557251304,-36.525852782475134,50.002906667773715 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark13(-32.13191328000886,-0.4621194820627351,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark13(-32.15777882151653,-0.20253674320641785,-44.94085250845201,-0.9999999999999982 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark13(-32.20401344178927,-1.3465967857573455,-34.45124807421076,-0.002055825817885104 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark13(-32.299122435837695,-1.1754266559235291,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark13(-32.323997525502335,-0.4245855710347257,-24.136210415648552,1.0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark13(-32.32562147655089,-1.4513104026884227,-61.787363885908945,-54.23123256069005 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark13(-32.33190953686709,-0.22923297781988644,-100.0,34.08390851906691 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark13(-32.34154237293447,-0.21672519869756912,-72.64730563996501,1.0000000000000036 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark13(-32.477812093455775,-0.5819512592011451,-7.347248262575,-0.027597879016977887 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark13(-32.57417352951863,-7.105427357601002E-15,-0.918686188411593,0.9717531763941002 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark13(-32.613325075384324,-1.4117491549802756,-0.4645063548670434,1.0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark13(-32.61409858039684,-1.5180974042295077,-54.89092131798357,-5.4044404166373425 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark13(-32.66658111463818,-0.7976450527660855,-58.2308447033781,2113.816487529854 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark13(-32.68643627505213,-0.022878074649180416,-0.04817717422129308,3.4230234870108447 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark13(-32.70320077239265,-1.5707963267948963,-46.11162903262593,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark13(-32.782937503049965,-1.3758291207214057,-39.460144192915344,0.3740351587351128 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark13(-32.82167461068269,-1.5294479852346154,-58.041505565426874,1.0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark13(-32.89508028540641,-3.552713678800501E-15,-32.92910086018533,0.2673358354508044 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark13(-32.937060975470374,-1.0643288956721375,-8.966333122169388,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark13(-32.95117506809859,-0.7441273530221792,-1.5707963267948983,-32.78481974259755 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark13(-32.960932414391564,-1.3258848366216944,-1.5707963267948957,0.995079973025448 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark13(-33.041742873700684,-0.2283005930015816,-32.70957854741429,-0.4762365135859723 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark13(-3.3125220795889447,-0.14759247911769743,0.0,-0.03056199845103265 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark13(-33.13786180440863,-1.5707963267948963,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark13(-3.31948690535215,-1.0808513391225745,-68.67140548379929,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark13(-33.225927443647194,-1.5424705542282329,-15.792792307251581,100.0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark13(-33.281269383356516,-1.3306500213472516,-75.37101439090782,0.6271082219144501 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark13(-33.39818830476082,-1.537448403525007,-64.98612034418923,-0.1897916845820875 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark13(-3.34050500869167,-0.07400796880144812,-1.5707963267948966,-0.03423354645550444 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark13(-33.520356017561674,-0.6761075105903153,-34.348325385163534,-2224.295438764158 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark13(-3.362765434653568,-0.002463382678101501,-1.5707963267948966,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark13(-33.64743088650377,-0.07610234114946193,-66.29147632351743,0.4800467323611972 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark13(-33.76994042684068,-0.5245798218859743,-4.249315397852005,0.04271122478284001 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark13(-33.79606806733869,-0.06726570000066145,-1.5707963267948966,-0.035463121208711756 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark13(-33.94417364166051,-0.3982079030631809,-82.16509674939101,0.9999999999999991 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark13(-34.029932698175976,-1.5707963267948912,-0.0011134384306966587,-1.0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark13(-34.073746690787644,-0.026237304255723806,-0.26234808030604606,-0.6003692912422316 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark13(-34.1270569788802,-1.5707963267948912,-1.423655936607724,-0.5132712987075685 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark13(-34.268818136345615,-3.552713678800501E-15,-50.28204216520455,56.53895557829123 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark13(-34.3312822727427,-0.4256282797941045,-32.6383252819392,-50.55754578582128 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark13(-34.37865833359429,-0.29195486354796374,-67.85419811908311,0.0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark13(-34.48579654000748,-1.0852723445130381,-3.4681834693082862,-1.0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark13(-34.65732173074082,-1.5707963267948912,-36.83494394550507,-0.5636499081940929 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark13(-34.81089537460558,-0.4679060059721313,-26.365753730250006,1.0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark13(-34.816194866598465,-1.355213716082232,0.0,-1.0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark13(-34.84938960158229,-0.6852017503002159,-86.79662656447263,-1.0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark13(-34.855258161457655,-0.7173871023797935,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark13(-34.870071050003475,-0.7092988482883462,-4.594021428395624,-0.9999999999999996 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark13(-34.97150479016849,-1.2282249073699099,-73.72528390673645,0.7259714156982282 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark13(-35.01577762150117,-1.54264371337304,-100.0,1.0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark13(-35.053699958549416,-0.6436329297605958,0.0,-0.039902585173853033 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark13(-35.11369361396122,-1.387751105563997,-1.5707963267948983,-0.46552859366762356 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark13(-35.15758202920162,-0.14351478282784438,0.0,-52.23647934050766 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark13(-35.26724781754367,-0.4616145628638092,0.0,-1.0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark13(-35.37738558978303,-0.17517991290375856,-77.7322896262345,88.61893483876858 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark13(-35.50769943541043,-1.4812523397027293,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark13(-35.56112254412639,-0.06350942057743131,-3.295971862238787,0.07256159118210626 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark13(-35.587484832136816,-0.09476715363395272,-74.55461002069235,90.46671477882077 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark13(-35.664288254244894,-1.3109943622432305,-0.013953029993100637,0.9744062470953545 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark13(-35.73402412705748,-1.3759664002821868,-69.25207833943335,-1.0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark13(-35.75658985510948,-0.5407403354123361,-0.013481181954998311,-1.0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark13(-35.87510344008851,-1.5279098639286566,-80.04798759209642,0.04524019536567474 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark13(-35.90443223286222,-1.2693609335463771,-59.296138221743334,-0.23901482590643353 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark13(-36.117091348232286,-0.5391838085824703,-13.741336749065955,-1.0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark13(-36.142955555031115,-0.8362271345299653,-96.06676441066331,56.38903334401125 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark13(-36.2074853521936,-0.29676373874012446,0.0,-2061.6461797741877 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark13(-36.40064710192726,-0.9613918087692301,0.0,-1.0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark13(-36.50068328588639,-0.10073593829858174,-2.242928299661944,-1.0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark13(-36.50097051516713,-0.49565821800153836,-2.9257288212223784,1.0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark13(-36.5172348813829,-0.1742198704963927,0.0,-1.0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark13(-36.541056333926406,-1.5551280281543325,-2.9288300075815266,1.0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark13(-36.56435564473551,3.031966829733237,-0.3049121827128367,75.94503412091719 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark13(-36.75228662037275,-0.5488640927727575,-71.31952987254542,-0.0227627371118312 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark13(-36.78676704559592,-0.034884157694488285,-158.31630092447486,-1.0963226764218739 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark13(-36.880892283230445,-0.5269899162010319,-1.5707963267948966,-29.113740165825014 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark13(-36.911138510724065,-1.0175762476949615,0.0,-0.9948582297289118 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark13(-36.93118023754093,-0.5389494470415874,-42.832078288858064,-0.5860461582449696 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark13(-37.07612348936501,-0.1512537266986982,-0.7859501814284511,1.0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark13(-3.7100905546218828,-0.17387098958968406,-1.2163081467809584,48.12640665999959 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark13(-37.157746397529245,-0.360417886467415,-65.25790035693923,1.0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark13(-3.7177663153814207,-1.0395642303631623,-37.336079510000594,-0.9018629028675814 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark13(-37.29186372080861,-1.570796326794893,-56.50084905279212,0.2812605477534902 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark13(-3.734041096551513,-1.488737489548883,-67.25890466454607,0.6198197938961261 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark13(-3.7388424182881006,-0.562869749101563,-1.5707963267948966,0.0524112144299439 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark13(-37.42895312007661,-1.5707963267948912,-32.43909372242032,0.7875314439674597 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark13(-37.43281766512517,-0.25302678257068156,-44.930433802483066,91.27905173842711 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark13(-37.4948364363927,-1.5707963267948963,-99.17473038483348,0.06264981145312414 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark13(-37.74587551874573,-1.5707963267948963,-92.39204364561162,-0.5131654085236725 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark13(-37.75895902108289,-0.48855883373872827,-94.25093702017482,0.06258779402497792 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark13(-38.092406948452165,-1.5707963267948888,-1.5728842363288325,0.06263211806750488 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark13(-38.12470292387157,-1.4175759022108632,-74.68964341798863,0.051970919380323444 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark13(-38.22077037879102,-1.564007121426311,-60.247735725028434,-4.680166511245405 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark13(-38.24206581631357,-0.7730868860981435,-25.700116503285614,-0.9575006548304508 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark13(-38.249753855324855,-1.3998938252907753,-70.40152520666437,20.13683191762296 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark13(-38.26435813822127,-0.8134877549244274,-32.96458245886865,-0.0415736621210981 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark13(-38.343230409309605,-6.123233995736765E-17,-1.5707963267948961,-2.5662313430787123E-16 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark13(-38.431962433863106,-6.127624823634878E-4,-28.427148472592407,4.440892098500626E-16 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark13(-38.4997864172376,-0.2939973774959006,-50.93782849119994,0.35862827357573723 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark13(-38.52424491091178,-1.2737889600880536,-94.7539057238326,-87.29523327279836 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark13(-38.61768940837509,-1.5707963267948957,0.0,-6.680958415059004 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark13(-38.72750733355499,-0.6901550053959793,-53.93218436017577,-8.330693417835505 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark13(-38.75767650844941,-1.4963059282216826,-1.5707963267948966,30.01824817548983 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark13(-38.762779933712395,-0.8051204739535378,-91.53644051916399,-0.729925255779392 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark13(-38.81234357107258,-1.5707963267948912,-1.2324167168423728,-41.23014869126656 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark13(-38.83302956695687,-0.6399514084905582,-44.574624205008014,0.2034482815733334 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark13(-38.880610474972514,-1.0651505530107768,-164.9251279880831,-0.916344640595801 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark13(-38.925137032083214,-0.03682437812731544,-0.9680547161154323,-1.0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark13(-38.993270327853686,-0.33852701716781075,-77.95555276786781,0.45509851425767334 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark13(-39.173039904084234,-1.5707963267948912,-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark13(-39.24487341232931,-1.5545533881699765E-16,-96.71393272809414,-0.3083300041540562 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark13(-39.30228024552721,-0.5488716940719174,-1.5707963267948983,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark13(-3.9336303138413102,-1.3417124712225577,-44.110083982023575,0.9174951803734472 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark13(-39.42147346654946,-0.48178598657915117,-15.407181366564798,-0.3727324619249791 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark13(-3.947147217585209,3.4473219869538148,-1.5773195018089645,5.551115123125783E-17 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark13(-39.54475745917123,-1.5707963267948912,-32.82285330909639,97.0881664918544 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark13(-39.56714392497425,2.651248368210943,-19.38370124764881,2.795336208866221E-5 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark13(-39.56871588752657,-1.5707963267948957,-0.24561176000887977,-1.0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark13(-39.583751365002,-1.5519250795144066,-4.267428227160181,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark13(-39.63540674028213,-1.5707963267948912,-66.17631913315299,0.6591574235884823 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark13(-39.6541554287218,-0.006887502196603938,0.0,-0.757982615152428 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark13(-39.69445964119027,-0.09142313193373747,-32.816972756333016,-1.0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark13(-39.77095953578247,-1.5707963267948963,-39.03869431953461,-1.0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark13(-39.91968277406026,-0.6857657112797961,-87.79065653607903,-70.75795472801587 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark13(-40.02901681825141,-0.6083691826580946,-99.97136230115397,-0.8768834308725761 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark13(-40.10015752727332,-1.4378893197553433,-59.88015896490597,1.0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark13(-40.12395042247047,-1.5389469163319638,-74.79060227643554,-1.0000004108140221 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark13(-40.156168847530935,-1.5061474820618674,-100.0,-41.36804007239415 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark13(-40.23977121962099,6.444995199739901,-12.213814639015505,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark13(-40.25412556910186,-1.5707963267948963,-0.6639811873103051,1.9695467337197223E-17 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark13(-40.34421832294588,-1.5707963267948948,-1.5707963267948948,86.10388721103743 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark13(-40.35124754234638,-1.5498509475407107,-72.31956956194863,-0.0064032555203724015 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark13(-40.3588506102047,-0.07621803555817172,-72.660570939855,0.0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark13(-40.44204800719638,-1.5707963267948948,0.0,-37.9394301605084 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark13(-4.047713437924619,-1.395691304156918,-15.950223377201409,0.571432313971556 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark13(-4.049885261202647,-1.5707963267948963,-97.57297679759476,-32.951994897656036 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark13(-40.50557216756295,-1.5707963267948912,-69.3622117434623,18.077439940764478 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark13(-40.54205844995957,-1.1761115713405959,-19.2644465066073,-33.17956498839123 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark13(-40.632507760198536,-1.5707963267948948,-48.85888060138419,36.68300500080162 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark13(-40.744775705720706,-1.4601631697744082,-16.27039634496162,1.0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark13(-40.77363393313962,-0.5528383633632027,-44.36635979125734,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark13(-40.81775072434711,-1.1243681869161953E-6,-74.20624557207653,-0.11567251972512262 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark13(-40.900303750334935,-0.03679421743856577,-5.055050158019895,0.5264763001012556 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark13(-40.92364410341951,-0.17011917373801952,-26.2835254545845,100.0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark13(-40.93194135309209,-7.892980206673828E-4,-28.524834058997246,-0.06256609188284872 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark13(-40.947375760985885,-1.5707963267948948,-4.848449321388715,-1.0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark13(-40.96453160662189,-0.046098509345921634,-71.13756479931655,-49.76502599008023 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark13(-40.965581344264315,-0.6685939297602616,-21.08377316976089,-26.050524429329315 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark13(-41.08879855546243,-0.20603070739528384,-10.77089836855383,15.044207873123355 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark13(-41.12712039539616,6.429327218683423,-90.88543898946993,1.0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark13(-41.24998282914157,-1.557215373819831,-1.5707963267948966,-0.03942981767253634 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark13(-4.127475226858575,-0.35153025326562776,-38.81634152410306,-1752.7796928280138 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark13(-41.33968220027435,-0.07013562494732195,-1.5707963267948966,-0.786558132748052 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark13(-41.583617838521,-0.41277799698336537,-100.0,14.761018697112377 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark13(-4.162071441800934,-0.7841821141128386,0.0,-1.0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark13(-41.64616453507135,-0.6480217216586016,-1.5707963267948966,34.99335156441125 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark13(-41.648430691749944,-0.1676275881906204,-0.6484826831299841,0.061326807244525876 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark13(-41.672528178747704,-0.4993827948262606,-1.5574016064667187,0.41553385786912467 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark13(-41.73676162477907,14.429630911202636,-83.41486951183417,1.0000000000000002 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark13(-41.87064147291322,-1.5707963267948961,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark13(-42.06361645479272,0.9085193178934989,-10.913707136303524,0.0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark13(-42.286217014553735,-0.01950206179140064,-94.29032824275005,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark13(42.33295145623231,-63.65769072110685,0,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark13(-4.240443527505846,-1.503442609987311,-0.330919704423263,0.9598718362351628 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark13(-42.40502856903825,-1.570796326794877,0,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark13(-42.437356489223106,-1.5437872442887453,-52.7215324703186,1.0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark13(-42.64536229270946,-1.5116683844512104,-0.21882039682607868,-18.915301666265563 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark13(-42.68151557833677,-0.0031339852747171272,-89.58366945367851,0.4750943426360392 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark13(-42.69236909057216,-0.480331931701793,0.0,-26.420200823930703 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark13(-42.76004095336009,-1.5707963267948948,0,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark13(-42.876252522865585,-0.7046279815299028,-1.4998822186083363,0.6124984360050547 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark13(-42.902680044130946,-0.009800855214157517,-34.145316685872814,-1.0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark13(-42.9092086038996,-1.2661611871767808,-38.81592376344505,55.7978413251806 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark13(-42.948839156711415,-1.5277394582379593,-14.185845206131345,-67.33218520417003 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark13(-4.3079410880579445,-0.30522675613239714,-14.959452159414766,85.5761278554275 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark13(-43.11136576709793,-0.841215490737079,-26.535471846881393,77.46955586498436 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark13(-43.17896291632064,-0.499898824881274,-32.64070688400429,1467.9335037745 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark13(-43.227838930002314,-1.5707963267948948,-21.116802629905138,25.91676124214746 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark13(-43.299204945033075,-1.4942221087643734,-73.72313674012416,-1.4281797950547457 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark13(-43.31129667733017,-0.8710422465046577,-67.55567102334078,-0.9742722693969732 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark13(-43.389655932558824,-1.5707963267948912,-3.147654514278078,14.752541756709064 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark13(-43.444572646363035,-0.1748019063716697,-0.18913507376188488,-76.91925355280469 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark13(-4.354693147310828,-1.5707963267948948,-46.438729970253256,-15.91793527127868 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark13(-43.56067134581908,-0.10144380903262129,-26.938237619729136,0.0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark13(-43.573756443449675,-0.0017693428148792558,-17.376559415969453,0.04361582942051011 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark13(-43.57720879334631,-1.269795921461414,-75.5297200018054,0.9201229796297181 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark13(-43.68108627953626,-1.4401221611089854,-44.20565768709015,-69.44492010143921 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark13(-43.72703497782413,-0.005437412267854869,-43.448551915580566,1.0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark13(-43.74153553867616,-1.1102230246251565E-16,-1.5707963267948966,-59.51826176837699 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark13(-43.8398345471561,-0.4288222618096711,-67.62546580743654,28.121046993446214 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark13(-43.84936178425975,-4.5197831305592034E-4,-1.564297019285092,0.9550383495224236 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark13(-43.94184468142978,6.429212496104538,-1.5707963267948966,-62.31329668079162 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark13(-43.943513894375194,-0.07856409927026481,-79.30074362851536,-1.0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark13(-43.969887629295926,-1.5178719658812798,-9.636474333207422,0.0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark13(-43.98001265047076,-0.23497042438073112,-72.4213313738262,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark13(-43.98205019339679,-0.46553648335517234,-19.44300021810851,0.0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark13(-44.15013574017397,-0.2127865297063866,-1.5707963267948961,1.0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark13(-44.157407264649734,-0.6895949645427748,-87.7398049510262,-0.008717731254872876 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark13(-44.177349896676105,-0.00940215794100376,-24.04299156291117,-1.5321604953416375 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark13(-44.242807268246004,-0.03245771866878938,-87.46140438255398,-0.0448567157676444 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark13(-44.279869996333545,14.43029055585324,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark13(-44.29121172397212,-1.5707963267948912,-48.00037115873606,1.0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark13(-44.43899302951577,-1.570796326794895,-49.053333759845124,-0.9999999999999984 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark13(-44.47889565132269,-5.368118912623869E-16,-0.13148061701512148,3.4211388289180104E-49 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark13(-44.51486173957971,-0.23238635550745051,-0.5089988037602522,-62.95807542193796 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark13(-44.693826289239276,-0.025140671816272147,-10.621480451295138,71.01018524339227 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark13(-44.79771531283743,-0.3713941850083238,-53.77749997876783,18.50021233821846 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark13(-44.89274944063973,-1.5311046728754896,-61.90093569212999,1.0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark13(-44.899204792469234,-0.05158058552179389,-1.5425888966675159,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark13(-45.09946837194307,-1.1810463630468393,-0.9915187879687731,0.0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark13(-45.130922212860476,-1.5707963267948963,-55.718427717465524,-0.9999999999999964 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark13(-45.176688234201926,-0.3913489609339109,-0.17077067750194708,-59.62047156128567 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark13(-45.26416065869534,-1.4465679851800175,-21.12582217423447,0.1652619524459471 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark13(-45.31168044454723,-1.5707963267948912,-50.06494668552548,-1.0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark13(-45.34603442786888,-0.5022715184877999,-1.4855242679580347,1.0000000000000036 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark13(-45.417590641843006,-0.673142621528166,-0.9006979469923152,-48.6707928401507 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark13(-45.48859373394592,-0.0023698508510894565,-56.519774290133945,-80.3539166825072 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark13(-45.549945949701076,-1.5707963267948912,-21.441549222080837,59.918433935297884 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark13(-4.557175625272741,14.444050739666089,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark13(-4.557228725804748,-0.31444402190200693,-31.762452921961117,-9.723461371658034E-63 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark13(-45.618343906971695,-1.3680623319760723,-64.92964432366895,-10.209850013155213 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark13(-45.65322087456883,-1.7763568394002505E-15,-74.00174294695788,5.585775945545745 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark13(-45.811943011027616,-0.42378125793534593,-87.615766737844,0.6542746202719663 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark13(-45.96231666813599,-1.5707963267948961,-85.74976183104673,0.3467015163499436 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark13(-45.985767551017595,-1.0057336380025792,-38.893546847198735,75.12339653457391 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark13(-45.998846886377784,-1.1320572851134558,-23.737782215099326,-1.0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark13(-46.026330654769374,-0.3142513861672106,0,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark13(-46.027912805719296,-1.4217350288692785,0.0,-14.48123604474354 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark13(-46.13104879196741,-0.4559177804421397,-84.53358450096103,-0.8860959832463439 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark13(-46.15667921117794,-0.2449445050419421,-1.5707963267948966,0.6759539880605383 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark13(-46.16259833518351,-1.570796326794893,-16.05666003373832,-2.3182538441796384E-69 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark13(-46.23505769976466,-1.5614390467187937,-74.39859821855741,-0.9633550729144175 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark13(-46.269222124001864,-0.015854428703454007,0.0,-59.76097175841344 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark13(-46.56359223423258,-0.0755846827216687,-0.5613437980784604,839.3851935036477 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark13(-46.571133824408804,-1.0481834237061356,-1.5707963267948966,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark13(-46.582865725077,-1.5707963267948912,-73.89336272695388,1.0341878449124926 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark13(-46.71805363974996,-4.6210067235739946E-15,-1.5707963267948957,-24.665446183379682 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark13(-46.809841941848894,-1.440921213377341,-94.33478924409755,0.0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark13(-46.88472622237802,-0.16147905685110264,-74.47027883173692,-0.022066919272418523 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark13(-47.13564630055575,-1.3267028738355797,-86.32767924433624,-1.0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark13(-47.1922244328128,-0.6624086810239668,-24.38154621831343,1.0000000000000004 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark13(-47.22091589164241,-0.7455232896463868,-3.0470915669389127,36.37135241589786 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark13(-47.222023246923584,-0.11488636441699729,-12.787050380493703,-1.0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark13(-47.24895032310717,-0.065075268435699,-60.75840715976501,6.150820313165044 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark13(-47.31814122813648,-0.03405236626954222,-65.98389357506157,1.0478656689076078 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark13(-47.32810118441758,-1.4952980996956104,-31.76127129922182,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark13(-47.425189829731174,-0.09907334296762599,-71.50977597522709,1.0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark13(-4.758315245413115,-0.8997904966287463,-1.5707963267948974,1.0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark13(-47.58983388699569,-0.5155000611740435,-66.17862085006526,-2119.8039181403396 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark13(-47.724947581025276,-1.0003942849413816,-124.00229444702933,-24.697315519337963 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark13(-47.749141880716614,-1.4022654385848072,-93.89132890560157,-77.83311066114686 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark13(-47.75444379039952,-1.4785719889793683,-80.37102324895547,26.415730587507237 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark13(-47.77868470652913,-0.41820963671323014,-100.0,-74.13057421940664 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark13(-4.778972503846333,-0.20260727424946068,0.0,-9.4039548065783E-38 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark13(-47.79439361426031,-0.9921341356579516,-66.71760293503183,-32.95358617797989 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark13(-47.88624599036101,-1.542545117393463,-22.550705166345846,100.0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark13(-4.796222752201526,-0.060363861406358285,-40.00946970117802,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark13(-48.10886049722024,-1.4437848838701557,-27.623772069701307,-3.4175047685512552E-6 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark13(48.17623073718758,-1.7763568394002505E-15,0,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark13(-48.46942749574684,-1.447866183428136,-2.2248847304612642,-1.0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark13(-48.47207208797936,-0.41179225635795547,-76.07156627156351,-0.013002566770345766 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark13(-48.47357842783593,-1.5707963267948963,-65.16411198979544,-1.0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark13(-48.52608160753645,-1.0475201132122858,0.0,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark13(-48.57063488831261,-0.2761778296745858,-66.70960904577595,-1.0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark13(-48.590257112252644,-0.8167956000114405,-55.3287848361913,-57.08426189643296 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark13(-48.591984488971335,-1.5707963267948937,-1.5707963267948966,8.548422075457808 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark13(-4.867878957792256,-0.11098462520022334,-97.66346287681569,-63.2791592484995 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark13(-48.73853503154986,-0.5571822210105788,-85.59330853641025,98.24470152103984 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark13(-4.878669107333749,-7.105427357601002E-15,-78.91577800985885,-59.22218580273095 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark13(-48.81878656806838,-0.7522440862299771,-67.51912324302565,-1.0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark13(-48.837388656144896,-1.4876344079919936,-44.346180239914275,-0.9992741262092467 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark13(-48.849750099747936,-0.11634026960142663,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark13(-48.866829959235936,-0.18032953629884463,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark13(-48.90223204142674,-0.19039387618394354,-62.97735261525505,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark13(-48.912097143166456,-0.6925647717638507,-53.76088516369741,0.0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark13(-48.93500550609884,-8.881784197001252E-16,0,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark13(-48.99655648723731,-1.450069478075832,-88.30342832266155,-72.20252525097015 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark13(-49.00903348530673,-1.5081165888470094,-95.97694730859845,-6.6174449004242214E-24 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark13(-49.06548053760099,-1.5707963267948912,-1.9592649855520818,-0.06951686844446942 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark13(-49.07089851956001,-1.3848331901900923,-17.70570115696684,0.025867995899116716 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark13(-49.07880506728036,-1.229850097808324,-1.4672916933478282,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark13(-4.910181400531512,-0.9687137262204505,-6.153314992204875,1.000000000000005 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark13(-49.125081646906295,-0.510671319681289,-54.713322746454686,-60.75935482190679 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark13(-49.346909220309314,-1.422032449744107,-1.5707963267948963,12.87431290629877 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark13(-49.597334571789645,-1.1281321568042064,-31.805630202414758,-1.0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark13(-49.6698003734501,-0.2152200129786715,-0.04417514528748783,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark13(-49.74042110836019,-1.5707963267948948,-24.702101643342488,56.15832801853412 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark13(-49.93261899771168,-1.5707963267948963,-1.5707963267948966,-38.34465464295111 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark13(-49.98917836777635,-0.3810381518744417,-34.17559796461012,1.0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark13(-49.995281404564025,-0.9434127986293027,-73.52974836500192,76.41993016833922 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark13(-50.17096514944263,-0.9257347163739515,-2.9771765108962596,-35.4625379147917 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark13(-50.19353019061854,-4.440892098500626E-16,-83.34870979142269,1.0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark13(-50.21886897335371,-0.18135682973012024,-69.14531628426305,35.53089309862548 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark13(-50.30296906745279,-1.283636341351059,-85.09715262676373,1.0612768386966795 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark13(-50.35120194802842,-0.4108128861317011,0.0,0.0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark13(-50.42136708704561,-0.3104396230829112,-84.3887238557037,-0.256672676243317 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark13(-50.43555595326849,-0.5957490993826875,-75.56925232148379,1.0380667076664372 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark13(-50.478379803518564,-1.1496317560355036,0.0,-1.0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark13(-50.50445426474422,-1.5580679545100526,-0.9721249802215791,-0.777772738820189 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark13(-50.91004699780031,-1.1000157324413777,0.0,-0.9710666497588452 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark13(-50.9704181798176,-1.570796326563552,0,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark13(-51.01431935613244,-0.94561762492453,-27.750426293051124,1.0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark13(-51.098974048350215,-1.4846642996491823,-228.61324195359964,-1.0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark13(-51.11072152612078,-1.4370388863564518,-13.20650883865315,-91.10448284436517 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark13(-51.255254694171214,-1.2391062497858296,-1.280174871710873,54.81757143413044 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark13(-51.372626398706466,-0.13481626925182166,-41.486660725818744,0.0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark13(-51.45498329444814,-1.2201124686281444,-60.059692465893306,1.0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark13(-51.48052694905033,-1.5707963267948948,-44.42829358443906,-45.23160101511018 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark13(-51.804316902864734,-0.6258877208156062,-14.270147346264306,-1.0000000199635053 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark13(-5.188057961785258,-0.7762565122821041,-2.5020531484341976E-13,-1.0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark13(-51.973242903363115,-1.3311748398307461,-14.12470280518984,1.0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark13(-52.12515434479564,-0.3728385305197881,0.0,-21.856520695397947 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark13(-52.154948530144864,-0.013919820225940183,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark13(-52.15923495588135,-0.66551812617584,-57.944418331862614,0.9827622570634754 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark13(-52.23802911730428,-0.3216946876837242,-1.5707963267948966,-11.18200230445195 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark13(-5.229127949977137,-0.5581283357107614,-38.90116218537046,0.0141738557711199 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark13(-52.291611882310505,-0.961550133064204,-71.56555446699903,-0.878266175444744 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark13(-52.29956328186862,-0.9615093847044063,-58.24101542440916,-4.616489308892868E-128 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark13(-52.336824243980594,-1.1102230246251565E-16,-1.5707963267948983,974.6418583421569 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark13(-52.37697273244197,-0.5851743286337582,0.0,-0.9463096350189937 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark13(-52.39971347744005,-0.07985345730288884,-1.5707963267948966,31.36317523474143 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark13(-5.242549383699128,-0.7413585314147686,-93.11850518628655,1.0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark13(-52.43436629456854,-0.42028068681232433,-44.95276938071183,-0.264854829248657 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark13(-52.50102559430941,-0.31240004317880476,-34.96342239959687,25.979212098112804 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark13(-52.511127247456,-1.491416254496406,-46.676300585113516,-58.43035251912243 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark13(-5.254411566513717,-0.9040985562340874,6.327599802601707E-16,-1.0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark13(-52.558388551313755,-0.18833015969119385,-59.89773769137912,0.9470423980668489 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark13(-5.257774633893234,-0.023385114942700243,-32.68212716355066,0.710137428370998 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark13(-52.76389935515715,-0.30246472989279044,-63.41614610212183,2185.0829673111734 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark13(-52.845568713520336,-0.45999297279764206,-9.395207852778498,1.0000001923738975 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark13(-52.9009329368422,-1.2703434427824285,-40.37341419976738,-1.0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark13(-52.9298915869907,-0.2993065194413118,0.0,-0.9702959810629423 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark13(-52.989436202687365,-1.5707963267948963,-0.0795160334313156,1.000000000636543 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark13(-53.02811559548161,-1.3174584404032883,75.47265863739472,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark13(-5.304398467185827,-1.1636749856997834,6.4514637407057736,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark13(-53.42595590338558,-1.382876221304553,-69.66281536492708,-17.7776870583958 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark13(-53.456362147893664,-5.551115123125783E-17,-28.211341853380272,-0.36208983008138357 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark13(-53.46742743419134,-1.0614692685887976,-42.63739172872579,-1.0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark13(-53.48019449001833,-1.1174362417193926,-15.213962963441176,63.38838438111975 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark13(-53.48586489865139,-8.881784197001252E-16,0,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark13(-5.364396671976467,-1.570796326794893,-38.195947796006536,0.8435477194508807 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark13(-53.68525394052373,-8.881784197001252E-16,-37.527270813737765,-52.74769262424288 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark13(-53.787393762567625,-0.5205570681130914,-40.60585998066444,1.000130591240452 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark13(-5.380148984889857,-0.47824820175874516,79.68326233033335,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark13(-53.91851492388645,-1.074035186686735,-55.54025099266592,-0.03881095024710657 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark13(-53.92830839208872,-0.040739428289699536,-33.10105819416742,0.061977237868462765 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark13(-53.965195281294555,-0.8095266452772047,-103.65491217603125,-0.04699032806487613 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark13(-53.96684950061223,-1.250519181274851,-12.380421749672294,0.9999999999999964 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark13(-54.219177607958244,-1.5707963267948948,-69.63356165954536,-44.52150989890796 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark13(-54.22434714513295,-1.5707963267948912,-83.37624195732832,-92.73201294208437 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark13(-54.30559545355506,-0.6061821169678079,-17.917476681316973,0.05060534490119227 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark13(-54.3176363696621,14.497264431723707,-32.56267172390868,0.5394011630977926 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark13(-54.366341142028034,-1.5707963267948961,-9.70313004541642,42.97623588961795 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark13(-54.415296485164674,-7.105427357601002E-15,-61.89004918028367,-48.87947088646225 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark13(-54.47076174875285,-0.17884552366331324,-48.96692584244303,1.0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark13(-54.57985967375815,-1.5707963267948963,-23.68435782887859,-1.0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark13(-5.4665326026608625,-0.8838611482003158,-54.982293357571564,92.34800447510675 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark13(-54.71452895013371,-0.9446875131729875,5.551115123125783E-17,-1.0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark13(-54.72799888664073,-0.15005184989634146,-3.552713678800501E-15,77.35321775702374 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark13(-54.76646477608419,0.6465993698785615,-71.81573523245467,71.89659126332947 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark13(-54.81874308257867,-1.5707963267948948,-16.408206756966532,70.56797813480676 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark13(-54.90896261024479,-0.1276261624919662,-8.195771727568431,100.0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark13(-5.494299163613932,-1.5707963267948948,-45.22345476022146,86.32599510313987 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark13(-54.95777082806352,-0.056443883862136085,-24.01038497958702,-1.0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark13(-55.00384803149504,-0.3111435507775188,-4.53100453489788,12.98450049190133 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark13(-55.016267055851614,-1.5707963267948912,-10.438725543696535,18.656397121902273 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark13(-55.04146366898286,-0.8747917361030513,-10.664804584713877,1.0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark13(-55.16523857639599,-0.39845278202285983,-1.5707963267948966,-2.6942215565187326 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark13(-55.19104368623079,-1.1102230246251565E-16,-45.43040365784155,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark13(-5.522412437237501,-1.570796326794894,-18.554962180315954,-1.0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark13(-55.23531630349674,-0.5858356776860489,0.0,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark13(-55.38442475374929,-0.49737244180113027,-68.69669528339941,-0.9696990197157569 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark13(-55.418060167519016,-1.061009221600383,-71.80737974428183,-1.0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark13(-55.511340766147846,-1.488235937576984,-35.91012820273223,-54.52857253732397 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark13(-55.51882782321758,-1.3051958903481922,-35.043085659145994,-1.0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark13(-5.56098457510479,0.17897690070081498,-1.5707963267948966,-8.858218645214741E-4 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark13(-55.681479118497485,-1.2933504938189226,-1.5707963267948966,54.35983570020316 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark13(-5.574190856280211,-0.9668479526706548,0.0,-0.054703749327048135 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark13(-55.751640296273926,-0.3819063414682766,-71.48027052183143,50.7508950140994 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark13(-55.8193279487596,-0.2698988697388245,-1.7763568394002505E-15,-22.883912640778124 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark13(-55.84503242412004,-0.7333963217507393,-77.07225786437941,0.6857301545702548 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark13(-55.854985315496464,-1.5707962601751633,-31.66831593900112,-1.0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark13(-55.9221467259144,-1.0449929947500982,-0.04203526626185295,-55.45494165565573 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark13(-55.9587830778935,-0.7123702507965244,-33.01005619097651,45.94944360655711 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark13(-56.002539550994534,-0.2586171665416034,-44.47045609340085,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark13(-5.600558526541393,-3.552713678800501E-15,-64.44748600673442,11.221713024817035 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark13(-56.08179221862355,-1.2829352332737203,-33.46160145107263,1.0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark13(-56.18849076520074,-1.5707963267747118,-84.12228129978413,-77.5694392216559 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark13(-56.40795768541902,-0.4055697947602429,-31.613367059249782,52.603436888621516 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark13(-56.41457426648503,-1.2360657604255987,-1.5707963267948966,-0.9999999999999926 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark13(-56.47780476126339,-1.5707963267948963,-1.5707963267948948,0.40509481623195637 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark13(-5.650612100510707,-1.5209181515956984,-88.99989946842271,0.0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark13(-56.66159972116033,-0.3148025268631791,-0.06510536338290596,-0.5100606399793355 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark13(-56.69452959380645,-1.3841650452083574,-1.5707963267948963,-2120.1252926975653 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark13(-5.6735654657630645,-0.17622118883856858,-38.379300207608615,-0.4269903316957989 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark13(-56.82800761165939,-0.05847572970569769,-44.20859994678261,1.0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark13(-56.83444023058215,-0.3732115107432228,-49.936661024366416,-1.0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark13(-56.84418010100535,-2.123058581900726E-15,-1.5707963267948966,-10.301242566389424 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark13(-56.914790779615885,-0.4658430749173017,-76.1055433170585,-2223.352421878801 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark13(-56.91762111160714,-7.084413186742161E-4,-70.50092723986948,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark13(-56.94243082631945,-1.5590961661266847,-9.669513562377503,1.0000000521627253 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark13(-56.98389696103443,-4.7134463585918915E-4,-18.25043117776191,100.0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark13(-57.05770814848602,-2.220446049250313E-16,-10.79196764100763,-0.8857217550424334 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark13(-57.088077725761224,-1.2334842810791065,-38.47190163670197,-1.0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark13(-57.40436415164787,-0.06281760893208527,-1.2504899857814618,-1.0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark13(-5.746347534940912,-1.4817066311575822,-1.2592728551502228,-0.05487087189239043 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark13(-57.49015233903995,-0.13710012816024886,-75.30204421039028,-50.046437710973436 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark13(-57.55511290034405,-1.5707963267948912,-32.770462188637666,1.0114326364288444 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark13(-57.559216784068695,-1.5110216329738746,-1.5707963267948966,0.8806941858405162 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark13(-57.59428397813848,-0.23411329700882688,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark13(-57.62020666885629,-0.012073677326087296,-45.386863619571,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark13(-57.6214546857456,-0.9129350273328739,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark13(-57.63743825647683,-1.2529515485593694,-66.67291137455146,-0.7494927939249572 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark13(-57.71973540106889,-0.7305164654846192,-45.374469518257456,-0.2423430808873576 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark13(-57.753969234021056,-1.5291123451929236,-1.5707963267948957,-1.0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark13(-57.860037913541674,-0.05389486835809538,-84.52657720852886,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark13(-57.97221407931519,14.460412544555155,-1.571503741316593,0.3328433144302693 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark13(-58.00383006195107,-0.6019805797293829,-40.8132502705875,39.72871141965832 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark13(-58.00773549801375,-1.5707963267948963,-41.264625203567924,-1.0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark13(-58.042756291939284,-0.4038033864895265,-152.99023226125036,0.013941855949740053 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark13(-58.04421934913211,-0.3205529523417023,-67.01474078955528,1.0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark13(-58.05816059974298,-1.5707963267948912,-52.211546606757594,0.24032730636115618 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark13(-58.10283973555448,-1.5707963267948963,-97.09601680547385,0.9999999999999982 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark13(-58.129027832977535,-1.140329845918249,-32.362972954222016,1.0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark13(-58.233705996694084,-1.2772428270801246,-100.0,-21.295047610164048 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark13(-58.239426929133195,-0.019394649686900634,-53.71131720473345,-57.59595977409199 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark13(-58.35556781125236,-1.5707963267948912,0.0,-1.0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark13(-5.861678493694015,-1.553584401080988,-0.641026517158917,0.9999820165654075 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark13(-58.6812537289612,-0.01605892165686868,-9.241236425682217,0.6393430041346173 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark13(-58.92419077985634,-0.7644760586375937,-13.37423004076776,0.036438955219734406 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark13(-58.96572268213142,-1.0897508521109074,-38.94822700153242,1.0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark13(-58.971086970204965,-0.08881669361110778,-0.18262929252616739,96.0067054554265 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark13(-5.901522444352343,-0.32476105593347687,-1.5707963267948966,60.66240581378567 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark13(-59.02488676137876,-1.1433455590222874,-8.581232865609588,1.0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark13(-59.098698930562094,-1.3765938314797126,-78.27017950149708,1.0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark13(-59.10490066869813,-1.1851907539006918,-37.82261679307384,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark13(-59.11106492716136,-0.005299876643401473,-100.0,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark13(-59.404860803167615,-0.5591810501655439,-49.63826443252397,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark13(-59.43111528421571,-0.7986671756209464,-46.434591219482854,0.21710660198291976 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark13(-59.44014337931287,-0.6382308604382678,-9.613665381449636,0.5350118763057142 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark13(-5.9456303979791585,-1.2588796259560766,-88.4202088865072,1.0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark13(-59.45641320254531,-1.321977350683043,-1.5707963267948966,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark13(-59.4627748394492,-0.17435580699904962,-20.56550041004938,-0.34697881218900684 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark13(-59.52763567870891,-1.5707963267948963,-74.33584630752166,-40.95099278950354 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark13(-59.58000825416616,-0.1739223648531889,-11.02646645960965,1.000001890089327 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark13(-59.591960832577605,-2.220446049250313E-16,-1.5707963267948966,-0.4880751628493677 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark13(-59.59719022406287,-1.4950708921492692,-86.22942613084356,1.0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark13(-59.670266733731374,-1.2572207334290786,-8.063420796587636,-1.0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark13(59.696796399233364,-95.69026231803868,-28.41831752944313,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark13(-59.71391433519929,-0.5336878319599354,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark13(-59.73515639908098,-1.5707963267948948,-57.264735893726154,65.02298440830481 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark13(-59.74327283718941,-0.033838363992061755,-57.951032551468394,1.0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark13(-59.80913409493974,-1.0176608355347077,-80.60561442428194,-18.09141096208818 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark13(-59.87362804790065,-1.5549466135155148,-1.5707963267948966,0.1393491232213126 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark13(-60.00683525250941,-0.06395416722862844,-77.06119300965511,100.0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark13(-60.108375733677434,-1.2116249067163631,-56.32611503625636,-0.9058230284599467 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark13(-60.12181291069213,-1.5707963267948961,0,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark13(-60.15720745081654,-0.773037073132443,-68.01179305753053,-0.19996595927011152 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark13(-60.31835943536568,-0.09517650792714666,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark13(-60.465641962653024,-1.0647030112172018,-29.356153217765243,1.0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark13(-60.47584619216289,-1.1362449184673,-34.35884986097363,1.0000000000000009 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark13(-60.50070919220688,-1.0854912731463222,-21.330264373687086,-0.011546412953841567 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark13(-60.523409777861865,-0.4361001959852109,-1.5707963267948966,-34.10879482715958 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark13(-60.597210480050606,-0.9553637815736049,-73.63621412132017,0.4445352901011387 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark13(-6.061216741789814,-1.3727009762149793,-88.48178536515233,1.0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark13(-60.654920816516416,14.429212078922603,0.0,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark13(-60.65641143455569,-0.04017270162996067,-54.72325126654882,1.0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark13(-60.737231503571564,-0.1442992423940993,-1.5707963267948966,0.6561711067698021 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark13(-60.75661896703708,-1.5707963267948912,-42.489888212787854,-64.50502491826671 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark13(-60.86779908904941,-0.5245623796240722,-1.5707963267948961,-0.29742641404320114 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark13(-60.89427104777983,-0.41189178279125294,-65.97821370873753,5.565287650774762 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark13(-60.96699970295234,-1.5705754150262652,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark13(-60.982111023367594,-0.3486481603788807,-30.873309688197864,1.0000000000000009 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark13(-61.00384328514575,-1.3426815305643771,-44.393107768874884,-1.0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark13(-61.04725896435685,-0.47069327535398237,-42.458623292201914,-1.0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark13(-6.107374713581819,-1.2930980822956424,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark13(-61.33130264881756,-0.3140259687388145,-1.5707963267948966,94.26902876299678 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark13(-6.139024426235454,-1.570717817401766,-78.392903963959,0.004655476151392224 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark13(-6.155067022385497,-1.568219586508386,-49.975965261886216,-2.265696199348454E-8 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark13(-61.82875302249139,-4.3510638852523904E-4,0.0,-1.0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark13(-61.9596658288998,-0.6933812036400884,-0.1717073891956688,-1.0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark13(-62.00927368735286,-1.5707963267948912,-45.197704981919905,-81.05705152822375 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark13(-62.162829274030926,-0.4919234010294922,-72.51867953153518,9.748221732896668E-17 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark13(-62.183848416091976,-2.220446049250313E-16,-86.90171973325077,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark13(-62.244308977359985,-0.9345558472602176,-60.92747387111801,1.0000002555113963 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark13(-62.39469422695989,-1.5707963267948912,-41.52262530183399,-64.25056692022342 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark13(-62.43524166603125,-0.2842074303158313,-8.134109248134706,1.0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark13(-62.46035699006744,-1.5707963267948957,-32.852700672622,1.0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark13(-62.48218075250014,-8.881784197001252E-16,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark13(-62.5111680889732,-1.5707963267948963,-1.5507991571228295,-0.43945022796037486 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark13(-62.528296265808635,-0.1350561828019906,-1.5707963267948963,0.24490282763833626 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark13(-62.723406483761785,-0.8289844829338109,-62.309057773857866,-43.67092125705192 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark13(-62.73228997648921,-1.5271669042654867,-78.57860805283359,85.19955502613087 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark13(-62.76773522199184,-0.04367743266556473,0.0,-0.28425294227665 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark13(-62.77728294114762,-0.6519511484749607,-83.5386210670377,1.0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark13(-62.79279631869084,-1.5013681205123977,-12.331826879185154,0.0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark13(-62.859240259548,-0.9253340141459222,-54.531229702695136,-0.04153022695418179 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark13(-62.92498077577709,-1.1124277913558469E-16,-51.76098325099892,4.436477727714875 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark13(-62.93566037568696,-1.3092806912566797,-123.68343075761516,4.420461986804629 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark13(-63.01563636944463,-1.5707963267948912,-32.27733113310819,-39.6585204962812 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark13(-63.01587487357349,-0.8323590542087782,-2.901347633578736,0.8771573210684189 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark13(-63.14363937906078,-0.38482090564048654,-52.868907577310395,0.833629333808386 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark13(-63.14580843939484,-0.350348597413356,0.0,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark13(-63.15264611522961,-0.06484764042654373,-100.0,-8.197039302027449 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark13(-63.167511368868226,-0.25857403237901383,-76.1648612246848,-1.0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark13(-63.28776949062592,-0.17360041471365695,-81.36383890352278,-41.737924003461124 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark13(-63.29387153523107,-0.00459123751457588,91.95774092185724,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark13(-63.35281137257927,-0.7820262413651817,-136.46710684041312,-37.89241730079256 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark13(-6.342057892025259,-0.16645764650698291,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark13(-63.49799206853086,-1.5707963267948541,-39.62028578770243,7.724146132832402 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark13(-63.49903199525982,-1.5538965583744038,-25.00538385906899,0.0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark13(-63.53745752605124,-0.14620907236891026,-74.98913330906618,0.4407088716757296 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark13(-6.356127203672482,-1.5707963267948963,-0.9537241035524212,2101.738419168351 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark13(-63.58462455375573,-1.5707963267948912,-44.406341815477354,-28.34626525843447 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark13(-63.69484775909932,-0.41876919566726656,-73.71994191546611,-0.42162149732258447 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark13(-63.71979088479984,-8.881784197001252E-16,-74.9741706429974,-0.7088038074967424 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark13(-63.791521790321326,-0.37033313096154963,-82.86634152062756,-61.871351741084574 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark13(-63.92620675466199,-0.7584146276098263,-66.0907477922404,-7.441929191576946 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark13(-63.95460047832368,-0.5378520965305602,-1.2977847654225756,1.0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark13(-63.956046700914136,-1.5707963267948963,-95.72270040840452,0.3695250884102146 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark13(-63.98982970347434,-8.881784197001252E-16,-83.22458155674198,1.0000000000000002 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark13(-6.400918151965463,-0.654475336632288,-1.5707963267948966,-0.6088357927954354 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark13(-6.402842202385115,-0.5387625103338963,-1.5707963267948966,56.36402806619164 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark13(-64.11455462252431,-1.5707963267948957,-5.471638674343637,-1.0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark13(-64.12922490787147,-1.537580573544739,-74.106563204958,-29.019085340177696 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark13(-6.417187261904083,-1.5707963267948841,-1.5707963267948941,-57.0561218822513 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark13(-64.1922691661712,-1.3367023800199096,-166.62638161030216,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark13(-64.20203679787537,-0.41968785977815837,-0.1822729960631704,-0.33313580404969967 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark13(-64.248554310018,-1.0794310526351776,-158.08560853139073,-0.4832737509306102 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark13(-64.2628649728187,-0.17416397895026653,-46.713369469999265,1.0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark13(-64.31495383319992,-0.707896482426388,0.0,-0.8850518375206885 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark13(-64.47626162086593,-3.552713678800501E-15,-15.010457608844035,82.91429607680004 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark13(-64.66221633040483,-1.3419880971781746,-30.258403694219368,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark13(-64.6638407204063,-1.3906089911766815,-67.6186358509571,-0.8137799827359231 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark13(-64.716659882747,-1.5707963267948877,-72.76052266537157,-2.6240270716857026 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark13(-64.75611172623685,-0.5794117354743835,-20.525320937680966,0.0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark13(-64.76751110585322,-1.1016543256769609,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark13(-64.77006815493806,-0.002872536638932575,-56.99660831993669,2.6469779601696886E-23 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark13(-64.81806816553623,-1.5707963267948912,-1.5707963267949028,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark13(-64.91527875121245,-0.7414225530855889,-92.82123001732596,0.31362898617933155 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark13(-64.930650231426,-0.2811223175717683,-48.37428977106094,36.16454473355901 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark13(-64.98145061512973,-0.0036477437405844915,-1.5707963267948968,1385.8551095528578 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark13(-65.0809390159204,-0.3066361330988503,-80.80391888598258,-76.56407029173549 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark13(-65.23955184305247,-1.4439163901478622,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark13(-6.526913302322484,-0.016612360672731762,-64.70449806250593,0.9999999999999996 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark13(-65.28970393341551,-1.559331958334442,-76.284486481297,1.0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark13(-65.36228273179306,-1.4426137894458564,-1.5707963267948966,-0.9955301391435937 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark13(-65.42098671334469,-1.2178183132514704,-27.762972502253945,1.0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark13(-65.53665119651535,-0.6068632173231672,-68.44747478763814,0.042497346132935016 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark13(-65.54838254839922,-1.2562872213781462,-1.5707963267948974,0.7185058966895785 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark13(-65.60093037841546,-2.220446049250313E-16,-1.6630227089629552,0.7694586225642482 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark13(-65.71827378909182,-0.2664972913435046,-38.62099325784749,0.7443409168173509 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark13(-65.80447389866579,-0.6254470594728394,-1.5707963267948983,0.010483249129303873 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark13(-65.82669313414661,-0.2814219426101854,-9.080399811578877,-85.31675626131097 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark13(-6.589831765304882,-1.3999168951315313,-0.013628732621006874,9.69214491068732 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark13(-65.90371076404492,-0.275890209137345,-13.936538638805185,-85.3596807864531 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark13(-6.6064517247860906,-0.09576615909514974,0.0,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark13(-66.08688403002039,-1.430218560342062,-98.89932451308808,-62.916353253241255 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark13(-66.10164044057456,-0.5260458594850626,-12.187760539752105,2175.3892049402457 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark13(-66.11491404258709,-0.6150235006600813,-33.78619908139888,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark13(-66.29122999488708,-1.5707963267948912,-8.563422301074759,-1.0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark13(-66.49119699105246,-0.46876997176591856,-1.5707963267948966,0.9680185452136961 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark13(-66.5061064110217,-0.07319123239855496,-83.81747009060972,-0.5114277164836675 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark13(-66.51689724391629,-0.01759438846776716,-38.39867289644614,-50.73129363300198 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark13(-66.52510861204205,-1.5707963267948948,-13.078700589573016,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark13(-66.57473680087773,14.43161126023044,-0.22807198090692699,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark13(-66.6342981361962,-0.22699880144255147,-38.75489053844538,47.69096423805129 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark13(-66.9515293749051,-0.299103018456218,-43.01457848658404,0.0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark13(-67.07461672256747,-0.42799456275839837,-32.533535069174235,78.107637387236 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark13(-67.0807243693547,6.4309227453330005,-1.3858212555794414,8.673617379884035E-19 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark13(-67.10408128730099,-0.39557394424831216,-88.1234209516167,-0.641426867878069 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark13(-67.1299284742871,-0.01457681365903511,-9.823841553840499,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark13(-67.14972312273933,-1.43834777362476E-4,-73.0538295485097,-0.81822615028808 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark13(-67.19990727692989,-0.6088350544257899,-123.67761994616615,-1.0000041542487892 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark13(-67.24148102838132,-1.4854667894906157,-129.87633204442199,1.000100768233202 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark13(-67.34265489248028,-1.086324598566442,-75.81212545965099,-1.0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark13(-67.44087245085977,-1.2869634459478156,-135.36479096443404,0.05867338574056824 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark13(-67.46404142673636,-1.5707963267948912,-15.043409008351695,0.696485154586624 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark13(-67.49603309363826,-0.41342694881887476,-74.86427879725657,-1.0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark13(-67.51072588053076,-1.5707963267948912,-78.49998712959703,-0.4729147842864987 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark13(-67.55782537135548,-0.2474619684726258,-45.63395895156348,-1.0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark13(-67.629919255875,-1.4346803359821563,0.0,-53.27254954953846 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark13(-67.63848319380239,-1.5707963267948912,-2.8862089871167975,-27.619970968658798 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark13(-67.70814818302426,-2.220446049250313E-16,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark13(-67.7158739246888,-3.552713678800501E-15,-1.5707963267948983,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark13(-67.74621227840886,-0.6383329251365355,-67.82029095060497,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark13(-6.787654123146257,-1.370446260268601,-16.995953281614053,0.0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark13(-67.93165839028434,-1.443855090825788,-1.5707963267948966,-17.321836957005196 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark13(-68.03553318103037,-0.22970963142017045,-99.79798155808426,0.8180008812943211 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark13(-6.818605180453849,-1.5707963267948912,-23.611831429869582,-0.8494184341550074 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark13(-68.26656073606468,-7.105427357601002E-15,-57.46857714107225,1.0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark13(-68.2767038315327,-0.15769106077841305,-83.27939161791592,0.17312426114568402 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark13(-68.49088978706637,-0.7885642610759014,-43.11885040012875,1.0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark13(-68.51632320980607,-1.4693376751340248,-88.60618776825683,-1.0000001911765521 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark13(-68.54378404278285,-1.5707963267948883,-37.92442306273609,0.05210563694166071 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark13(-68.54572001497631,-0.872156777685329,-51.535498824262405,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark13(-68.58695406402452,-1.5707963267948692,-61.79842935119588,1.0000000000000009 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark13(-68.6280584704697,-1.2458124877048837,-29.65191595761523,-1.0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark13(-68.6284399265652,-0.0820063300509171,-95.71065994859298,-1.0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark13(-68.64409788486333,-0.10499280079358933,-45.38238399525203,14.113911957130897 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark13(-6.885833014537859,-0.9317290885264313,-94.685060907773,-16.889667607594326 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark13(-68.98293606564104,-0.5234340329301937,-139.80492611640332,-2.7302232332129805E-4 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark13(-6.900136750538282,-0.3184997999322133,-1.1730392007747306,-0.9999999999999996 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark13(-69.01428286540842,-3.552713678800501E-15,-68.16792607396974,0.0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark13(-69.08256810865129,1.0503499911973158,-1.5707963267948966,-29.307877580203993 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark13(-69.08401263459702,-0.025661789253855538,-52.58401485810167,-1.0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark13(-69.23670232355954,-0.8668840824151215,-13.689835953322866,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark13(-6.925056184950762,-3.8800971433676436E-4,-78.44813559527093,0.554388206062957 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark13(-69.2579434539862,-8.881784197001252E-16,-81.86891932500379,0.1817541217841656 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark13(-69.28373458990441,-1.5269234125814608,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark13(-69.31498810973861,-0.657051026614012,-77.16301154957677,-1.0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark13(-69.34767814738645,4.930380657631324E-32,0,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark13(-69.35162535255697,-1.7763568394002505E-15,-66.26667567058337,1.0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark13(-69.49910190298006,-1.1531424919819626,-45.35112983932195,0.8210376639635713 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark13(-69.5346874174591,-1.5707963267948963,0.0,-1.0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark13(-69.60764691431984,-1.5707963267948961,-3.4091073716722017E-14,20.42505058267048 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark13(-69.61061120464427,-1.3878803459650575,-0.15743304000230762,-0.9101008166945179 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark13(-69.8280635474355,-0.7463279230671915,-92.66312936534497,1.0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark13(-69.83306262764546,-1.5620727136582224,-66.13444517901297,1.0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark13(-69.86911049319626,-1.3677523413831576,-26.587265788002398,46.7209777420328 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark13(-69.91827837476626,0.1684141650472876,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark13(-7.0006275641689015,-1.5707963267948912,-1.5707963267948983,-11.156271817021715 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark13(-70.01016970803086,-0.19932308134054638,-54.701423721259054,-0.0017639800580439517 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark13(-70.02144453265788,-0.6641194572113625,-0.5303592694763934,1.0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark13(-70.03222285487465,-1.5116735807272583,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark13(-70.0901768366775,-0.7030811031999573,0.0,-1.000000033616694 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark13(-70.10694082096087,-1.0308354737603123,-1.5707963267949019,1.0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark13(-70.20018027731712,-1.5707963267948912,-99.8110104527361,-1.049314241312228 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark13(-70.20121239963498,-1.1362294912344968,-67.82750214087883,-6.406665904585923E-145 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark13(-70.25383172078384,69.52489854959003,8.519187230794586,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark13(-70.36809733438596,-8.881784197001252E-16,0.0,-2192.5805617604374 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark13(-70.39850933667435,-1.7763568394002505E-15,-92.55025517687507,-0.010705067882109221 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark13(-70.40897945054252,-1.5335348540125802,-23.511338542857,0.9825178587041361 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark13(-70.58529668587936,-1.5707963267948948,-46.56990320539408,10.327247975703273 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark13(-70.60047186859441,-1.5372910972567253,-85.75188792385225,1.0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark13(-70.61444434573829,-0.25435818572892177,-71.21559132261552,1.0053509441156183 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark13(-70.6810529812174,-1.1747209935125618,-15.3015855670696,62.826712715739355 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark13(-7.071165520896145,-1.2683218535078131,-114.60876483171795,-43.799853240130204 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark13(-70.72459339624281,-1.2117136951463738,-45.81170550050824,-2300.9588901705542 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark13(-70.75290612934864,-0.20058829908671783,-1.5707963267948957,-0.9863522343115666 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark13(-70.80895150852513,-0.5829106354855527,-99.30603948891053,-64.70771025425236 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark13(70.8292835469947,-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark13(-70.93503391539241,-1.0228724606903086,-31.735623153237547,-0.21549865453302153 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark13(-7.094645993256558,-0.45392848071135283,-1.5707963267948966,-0.8690126136270255 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark13(-70.96724619921461,-1.570784322720719,-93.36832597929673,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark13(-70.96883548622783,-0.6132032424137814,0.0,-0.42445045170805906 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark13(-70.98465566252119,-0.0896625249048999,-30.52676282147597,36.58868786294211 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark13(-7.10167615671206,-0.7737807139865112,-54.04762895696673,-1.0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark13(-71.10833004268159,-0.3875822083870915,-38.231533565328576,0.0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark13(-71.14182492612618,-1.3939584392309357,-53.939204310331135,-5.7731324599836995 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark13(-71.14924634736188,-0.32308968275603434,-27.506360480084197,-1.0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark13(-71.1516341395193,-1.5707963267948948,-65.95621779614588,31.300984101442967 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark13(-71.21856257142981,-0.09385101527202445,-5.878345827404985,-1.0000101308263478 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark13(-71.2465767646179,-1.1133439417596875,-3.679572717389007,0.0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark13(-71.25315814655977,-0.28663469326915003,-1.3924032615342332,0.0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark13(-71.27373732440782,-1.569142395117169,-0.5837424901438167,0.5977730396845672 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark13(-71.48561052900364,-0.2958964307386367,-71.06617174583815,0.030454163462031503 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark13(-71.50685117558652,-0.27507118129606656,-71.1400358973466,55.27582085368684 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark13(-71.6207662935176,-1.5707963267948963,-86.5294528179672,1.0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark13(-71.79187286769383,-4.440892098500626E-16,-5.985015154963946,-0.4374948209202939 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark13(-71.80122013908768,14.42935267177571,-39.01236076942946,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark13(-71.83492372712078,-0.19089979133323862,-59.92056483248325,-58.58679502027293 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark13(-71.90729093371267,7.195087119181186,-91.51042048063499,-100.0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark13(-71.98053374151249,-1.5707963267948963,-46.24156841228579,-0.36112543380846507 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark13(-72.05127919454857,-0.5359981221461756,-100.0,1.0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark13(-72.10487178485371,-0.5584576707187985,-57.28242079908789,-0.25547219718831204 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark13(-72.18340807429499,15.929707314034204,41.601246043793594,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark13(-7.228485376843451,-1.066954874852493,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark13(-72.38012826996852,-0.158377356624138,-72.89958974723258,-0.4610897221502395 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark13(-72.40560534083367,-0.5633653511687046,-60.79139538446207,0.0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark13(-72.51069314226311,-0.1374132548314293,-1.5707963267948966,-47.1729744795337 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark13(-72.56267886944137,17.3082484504734,56.53319251767411,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark13(-72.73598878382823,-1.5707963267948912,-28.515898023780323,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark13(-72.74981692254016,-0.6925157665223926,-95.73966601647103,0.8424625402110205 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark13(-72.85871725666546,-1.3618417283301265,-40.198781984056666,0.8414161390746784 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark13(-72.9481174228801,-1.2975277433147712,-1.2818363803860249,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark13(-72.98020066479884,-1.5707963267948963,-100.0,-0.4003978843905654 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark13(-73.08270745195125,-0.017185254211870782,-0.4037000446832163,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark13(-73.11248563182468,-0.8243852939640144,-4.504366625581216,72.4958731435938 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark13(-73.1615498914296,-1.185089373873116,-1.5707963267948948,-0.7934193404968486 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark13(-73.29863995861754,-1.2081034939221442,-77.69072240004726,-3.872622349912639 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark13(-73.35427506404837,-1.4412708492061297,-21.067113529454588,5.177058593673017 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark13(-73.35709899849199,-0.3648966997168657,0.0,-0.9351443538080095 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark13(-73.4192560105667,-1.7763568394002505E-15,-14.622514888120813,-0.798204070700272 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark13(-73.53527608556345,-0.5852502906523633,-31.654129663921694,1.0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark13(-73.54238394256781,-0.7704846766223967,-7.086459737364372,-1.0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark13(-73.83855936814247,-0.017728382428030355,-1.4886478208307687,1.0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark13(-73.8894791980494,-0.8139706065815253,-1.055992780662982,-4.2168791772922093E-81 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark13(-74.00601998986089,-0.35901568304541476,-0.049373618763467055,1.0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark13(-74.01790344738656,-1.5707963267948961,-11.11898095994664,0.4724046557752102 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark13(-74.20827204259285,-0.11983148516649213,-6.4864331880002455,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark13(-7.421245447776123,-0.04250122295117628,-94.34731451439724,1.0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark13(-74.285264590488,-0.06187010682683894,-54.26757324522642,0.5293942817602728 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark13(-74.34144879778816,-1.2733441986040996,-119.3456288959829,-82.1956741172628 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark13(-74.37805685345283,-1.0106197345307146,-29.96809739723959,-0.05442626193430053 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark13(-7.443156002735748,-1.0520307074585578,-98.10251339810125,58.89159571676254 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark13(-7.449338772630476,-0.9854542518569644,-66.39810830420404,-2241.497303500344 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark13(-74.5024521393137,-0.7041354666685141,-67.0719834255315,-1.0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark13(-7.459570161516532,-1.260406898416873,-37.0355080254433,1.0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark13(-7.462736509772636,-0.42294222371122203,-1.5707963267948983,-2162.7731501035946 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark13(-74.69331769685004,-1.5707963267944496,-0.19511270107262496,-55.43145198836912 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark13(-74.81354222788896,-1.5707963267948963,-0.6894063436289464,-0.4721119641906877 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark13(-74.81704579907179,-0.9232631115295341,-46.01825911356412,-63.76725851524676 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark13(-74.89490548210263,-1.5707963267948957,-56.95061008229596,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark13(-74.93954170092759,6.581605295775032,-1.6649899601787297,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark13(-74.94546169597764,-0.41365276068782464,-53.845027074022845,0.05486685507258274 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark13(-74.96378661121297,-0.8837897813328794,-153.4916304868741,-0.996687969738076 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark13(-7.49828342126068,-1.0374834490416107,-66.42137902397869,0.0965989962307191 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark13(-75.02540476553851,-0.05479057738309123,-58.50361253619346,28.836646030103992 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark13(-75.05496213992116,-0.048899327136399544,-0.07933146960824093,0.013535824328397502 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark13(-75.21728840605088,-2.0522684006491881E-289,0,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark13(-75.25200952142168,-1.3974752842837728,-95.99305580441909,-54.74401080553828 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark13(-75.38591893243226,-0.025326027672905482,-72.7613786986517,-0.531394280215838 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark13(-7.539042864049218,-0.31584888744451156,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark13(-75.46468188172548,-1.5707963267948895,-6.74446755858456,1.0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark13(-7.548361803043278,-0.7775507435823776,-6.923027295498272,-1.0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark13(-7.551277759056717,-0.8651202897273035,-5.640254689337294,1.0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark13(-7.562079639974004,-1.3796861305084194,-0.8204847195724599,1.0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark13(-75.71944765594387,-0.422263056373156,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark13(-75.73331405640623,-0.09618567119621474,-0.08028669285800373,5.449123235937336 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark13(-7.582711759716661,-0.4966934435520911,-50.93915739498231,0.7368611828676614 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark13(-75.84761916063523,-1.1102230246251565E-16,-1.197847852207881,37.378329393036324 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark13(-7.5860065766792815,-1.5707963267948943,-20.310482684900176,16.566179389431284 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark13(-76.01147243571398,-0.9872135468374748,-51.45435181714794,-1.0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark13(-76.01303120063208,-9.536404008414186E-15,-32.652366008504956,1.8726705418768793E-96 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark13(-7.604489593248601,-1.551345074405745,-46.88794432035193,0.0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark13(-7.605678834046522,-1.4726733396644163,-98.87535715619246,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark13(-76.28110230501252,-0.21864487116638576,-4.364413634577673,0.6901481959187472 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark13(-76.31027953149628,-1.5707963267948912,-1.5707963267948966,42.25997174647284 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark13(-7.639425216620102,-0.2898991357073657,-59.8945694929687,0.016837211031070914 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark13(-76.40959969798428,-0.8191913909583255,-1.5707963267948966,-0.05181581573783686 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark13(-76.55822679226694,-1.552255517613343,-56.81779660132455,-8.433758354584419E-81 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark13(-76.62435590757507,-1.5707963267948957,-1.5707963267948912,0.0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark13(-76.71500815318802,-1.570796326794893,-0.07400811027471615,-0.7881407218242296 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark13(-76.8225356514685,-1.5707963267948963,-1.5707963267948974,83.05316753363114 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark13(-76.86154819176505,-0.06561683144167793,-66.03651947740275,-3.487832454367029E-7 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark13(-76.87317057939178,-0.053977819052332295,-73.77516437813001,-0.9258294411755293 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark13(-77.30613463616214,-1.4322949456976521,-10.334179070239795,-0.9593156493360459 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark13(-77.33685519273922,-0.02405316828965187,-52.67011248121449,-0.8395663461515872 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark13(-77.35407779061858,-1.5684766126078573,-1.5707963267948974,-2089.6346435355786 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark13(-77.39907582867912,-1.5707963267946923,-6.865533570809831,65.08684225454621 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark13(-7.752631956780567,6.430035674191548,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark13(-77.56384742543077,-1.3793953258004272,-46.71745338519677,0.9999999999999996 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark13(-77.68373104792687,-1.1611052299159859,-2557.939085534001,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark13(-77.8981447565061,-0.06856253998116121,-26.20904037589647,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark13(-77.95672373800704,-1.5667250241620763,-12.069308584770425,76.46353278953049 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark13(-7.796342432346748,-1.3528082517565174,0.0,-0.8187017798126113 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark13(-7.798069250798186,-1.5707963267948912,-80.09883026782494,1.0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark13(-78.1081594569968,-0.32051250102875367,-90.43005791281522,-11.072247265986704 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark13(-78.20207239824526,14.467540624398815,-13.928318214192426,100.0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark13(-78.25295812183113,-1.7763568394002505E-15,-0.2243056275218105,0.3624237635373589 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark13(-78.26420639705013,-0.7410447597555695,-55.90311251928117,-1.0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark13(-78.27348795006267,-1.5707963267948961,-87.11167408936203,-2291.865042202586 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark13(-78.34211201262889,-0.8816863211715037,-56.330580749225405,0.5010178331543997 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark13(-78.40641686891979,-0.01106397653506841,-21.29949684651225,7.224835585940016 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark13(-78.46144712654295,-0.047349851127411524,-1.5707963267948966,-0.36954197433855995 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark13(-78.50413373968993,-0.6116352518039597,-40.7350936512958,1.0000004093530237 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark13(-78.69841732012607,-0.7838912517876997,-88.44077367222341,-12.587139206605201 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark13(78.7431239992471,-1.552082972963298,0,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark13(-7.884372756916784,-0.47336115597311984,-1.5707963267948966,-0.6603122038712157 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark13(-78.90519395440415,-0.5062750893114343,-46.75470429878066,-11.73121256588128 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark13(-7.893394577462482,-0.15736600099137554,-62.25367366550364,-1.0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark13(-7.893553684910206,-1.5707963267948912,-73.71492954057393,1.0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark13(-78.99896892362511,-5.551115123125783E-17,0.0,-0.3851991620440065 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark13(-79.05218733543973,-1.4439871182152246,-56.916047123582004,0.4991018898585633 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark13(-79.05843337689748,-0.07807984109337125,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark13(-79.06799455118505,-1.3536914985017996,-55.903527342494925,-76.15099722204036 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark13(-79.11082276277486,-0.9617095975570167,-1.5707963267948966,0.646014874604288 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark13(-79.13757499417629,-0.8986868206929444,-100.0,1.0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark13(-7.938211427758162,-0.6324318778594785,-0.0305078061002233,1.0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark13(-79.39246915736882,-1.2492225528519114,-98.16111844973065,0.014688803031172051 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark13(-79.39653504769223,-0.341880015993706,-61.25051393201628,-0.9984806497459435 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark13(-79.41666003143328,-1.267481810886081,-0.8587034397805996,1.0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark13(-79.43523128505598,-1.3098078693575022,-0.9009528204588548,-1927.9792710843255 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark13(-79.49924424601431,-1.2796045344742217,-123.74024974328965,17.67095548336954 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark13(-79.57880451922078,-1.4829565875636541,-29.837230314584126,1.0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark13(-79.5807466105838,-1.5707963267948963,-48.11296425069103,2216.9960522786805 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark13(-79.62242396524896,-0.39848999209929525,-69.90194600139003,-0.3774368313901253 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark13(-79.62292595195706,-0.19334916433185856,-47.006932623327984,0.05444414157804572 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark13(-79.67267862360657,-5.8522187076137655E-5,-21.181844421027925,-0.3054752532191366 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark13(-7.970700013402848,-1.3255391927026352,-30.805826115619382,93.88614762744407 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark13(-7.991526756870655,-1.5707963267948912,-22.160845846524353,-1.0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark13(-80.04444284064954,-0.8251114075635715,-30.901175674485003,-1.0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark13(-80.08278188019653,-1.203063766993343,-56.098022938036564,0.030714534012765426 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark13(-80.1056514605871,-0.014432160486958081,-49.37633743568435,-1.0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark13(-80.1795378503483,-0.8468232443573471,-62.78211496520984,14.437332854847668 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark13(-80.26342467204434,-1.5707963267948963,-38.06219960255334,-2.4134359749014406E-16 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark13(-80.27469953015493,-0.1222250637256936,-7.208318681776904,2144.0330714409 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark13(-80.28875433495286,-0.30216517257279296,-1.977462411660646,-0.7189106151747122 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark13(-80.2989386309557,-0.5198558424915413,-1.250840476849469,83.06234243867738 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark13(-80.54274341136231,-0.041733275936762126,0.0,-1.0067168250396408 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark13(-8.079212815705738,-0.43153582370205457,-3.1193037641002803,-1.0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark13(-81.05263652143809,-1.5518868111588229,-1.5707963267948966,0.821941071626524 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark13(-8.108271948340771,-8.881784197001252E-16,-74.90941475576346,-0.6581272553794677 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark13(-81.16564934591742,-0.39911671290421236,-40.585774314464544,-1.0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark13(-81.29383747993609,94.41972741421739,2.9554565125959016,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark13(-81.30104744971229,-1.5619573806786193,-0.5719382460264668,-0.5829061277615318 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark13(-81.34084581307566,-1.0186288311580234,0.0,-13.746934063107084 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark13(-81.3560540107291,-1.3934080246800908,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark13(-81.3760765893101,-8.881784197001252E-16,-12.155347923449654,-50.38271061972625 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark13(-81.37872712611843,-0.6532900355143617,-0.907598289052085,-1.0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark13(-81.38950206012724,-2.220446049250313E-16,-34.9027438864794,1.0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark13(-81.44823832081876,-0.35039826696370024,-8.836099509335313,1.0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark13(-81.47587951668649,-0.5450532206296145,-67.26059596941361,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark13(-81.49665397857282,-0.7892770437305434,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark13(-81.52089390288027,-0.0980390503648074,-98.28380536172993,-0.910882218626898 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark13(-81.64387467544195,-0.5210693173161717,-0.3693536673947051,1.1470519543096809 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark13(-81.71637036782144,-1.5707963267948948,-50.22377956991632,-1.0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark13(-8.175263513597292,-0.04532223441691341,0.0,-100.0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark13(-81.77044854499998,-0.5482838669901027,-65.69790015758319,-0.013667459384208325 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark13(-81.78077301423032,-0.015085910741106096,-68.8941897415597,-0.06255333904111564 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark13(-81.79541651556887,-1.5707963267948957,8.881784197001252E-16,-0.019336435617139363 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark13(-81.83754802660847,-2.220446049250313E-16,-44.503917302708984,-0.9999999999999999 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark13(-81.84008846370808,-1.0525204291786339,-18.460998563023043,0.36208928129228796 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark13(-81.9538157320325,-1.5707963267948948,-3.552713678800501E-15,94.13938376497704 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark13(-81.96736668829064,-1.0505037933601993,0.0,-6.923079031780905E-18 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark13(-81.99878203361915,-0.22822579856560798,0.0,-6.2217388506689275 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark13(-82.3175057314458,-0.11476460142437239,-7.875239913509418,71.26172401570881 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark13(-82.32435389035142,-1.570796326794893,0.0,-14.473802061418278 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark13(-82.41200657188061,-1.5707963267948273,-111.72074022480149,85.14005207455173 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark13(-82.44381024603345,-1.7763568394002505E-15,-37.09810173358969,9.104425887190914 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark13(-82.45773481981688,-0.8881134536760995,-100.0,-1.0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark13(-82.4708552934215,-1.517459371638695,-45.35937105804528,0.0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark13(-82.4741712219196,-0.09110066598286715,-0.3771275414174653,40.895495381410626 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark13(-82.64649883325987,-1.5707963267948912,0,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark13(-82.65268419383483,-0.128076755448141,-1.0603784351196485E-15,2105.3618454502785 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark13(-8.282029595297926,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark13(-82.86032658114631,-1.5707963267948961,-1.5707963267948974,0.0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark13(-82.91019019853806,-0.13582823226104168,-66.0843512610817,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark13(-82.92388044990793,-3.552713678800501E-15,-72.64750205935886,-48.052487223099824 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark13(-82.93423412614445,14.459869619643392,-1.5198046224430128,0.0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark13(-8.296114454477967,-0.33331017136415325,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark13(-8.297615021109014,-0.5548104455514166,-1.5707963267948963,9.99639032548638 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark13(-83.10821813100227,-1.2812729883666887,-1.5707963267948966,-0.764055973359496 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark13(-83.13715134488002,-1.5707963267948948,-1.5707963267949054,0.014708889121790747 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark13(-8.315065641009618,-1.064221661665381,-66.7733944317716,0.06255489614235629 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark13(-83.2552985380228,-0.04655814112439316,-46.37379801347994,0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark13(-83.49932747683451,-1.000541497781498,-73.00818411803303,-2.245561881283246 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark13(-83.52438235041916,-1.525433826665995,-92.56174734503239,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark13(-83.7063097146701,-1.5707963267948912,-2.6302314100729163,89.51664173104581 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark13(-83.75135214792238,-0.5247042660648453,-33.18296161659053,34.00751317251181 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark13(-83.83860728964314,-1.399704759014773,-8.257733318560607,0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark13(-83.92493430715089,-0.38495565764388573,-39.808946212324244,-71.63076561218273 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark13(-83.93558437673148,-1.0453706286922966,-31.730061520132562,59.75169882473094 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark13(-84.02696093911494,-1.5707963267948912,-164.60218209958435,-100.0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark13(-84.05452166742685,-1.5707963267948912,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark13(-8.409331362649269,-0.00170104894122121,-47.61995476036822,-0.34592765256114777 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark13(-84.33984036414314,-1.059080915204108E-18,-1.5707963267948966,-0.9999999999999968 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark13(-8.437138995609496,-1.345064149775206,-23.880591423368045,1.0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark13(-84.5323175789484,-1.5313575992806576,-0.23398909811923907,-0.06255252564087486 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark13(-84.5883524626229,-0.9430536339760751,-56.446374285332766,-2302.5084785471495 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark13(-84.80399936894636,-0.1554101375694919,-14.430229367460647,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark13(-84.81085590722235,-0.3431132966073146,-89.37568071367973,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark13(-84.84575870674925,-0.871556641696686,-21.728441179194277,-0.8015761373779875 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark13(-84.93183414882965,6.4295803045211715,-8.961571701269602,-53.396392715944685 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark13(-84.98539112012864,-1.2740611877484098,-1.5707963267948983,-1.0000008126913078 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark13(-84.99130920791768,-1.3407893105319673,-18.107951939652875,-59.257367354374836 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark13(-85.03912521256797,-0.7696601626307876,-36.32542816977321,0.6133793540791084 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark13(-8.512420926182045,-1.2843637561124097,-73.7942069040009,72.67425056928141 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark13(-85.30254203845017,-0.3751813493556142,-42.223853597388015,-50.84586569752288 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark13(-85.31773525999442,-0.2628449341921595,-51.634412623783945,1.0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark13(-85.38069101919771,-1.5707963267948948,-52.269835918161945,-8.4834392317062 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark13(-85.51731941506037,-0.6086092832913491,-59.43519568199379,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark13(-85.52660254483055,-0.47458729445375525,-4.82147716724748,-1.0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark13(-85.53916497761313,-1.563842606183266,-8.15459306723233,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark13(-85.69731178861767,-4.474449746700561E-15,-1.5707963267948966,66.1141496810542 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark13(-85.7027357762371,-0.01216062493667458,-34.94055657062259,38.87512030779024 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark13(-85.7098844026445,-0.0030835052006722603,-151.85103002765516,0.17729995286216563 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark13(-85.99135954169618,-0.9475200610085426,-40.598843573095486,-89.38842443467973 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark13(-8.605207760323855,-1.5707963267948912,-0.17957332596421732,1.0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark13(-86.10773225947631,-1.3750722938944477,-35.59797370840883,28.1779993858855 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark13(-86.21636762674214,-0.028529446625920052,-86.01081432875964,0.0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark13(-86.28946529017688,-3.628144969535189E-16,-50.79673800180766,-1.0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark13(-86.33901090777317,-1.5707963267948963,0.0,-29.598529157745894 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark13(-86.44802755178056,-0.5074683907640605,-36.279113154494254,86.90543718858365 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark13(-86.50804336806456,-1.5707963267948912,-13.40597386937685,-4.276998133132494 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark13(-86.59612268285038,-0.33382991913532145,-8.610380812902662,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark13(-8.65982223694582,-0.22741643357645103,-25.176646652501578,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark13(-86.6210055442904,-0.047603924919568164,-73.34941411252824,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark13(-86.69232615633071,-0.24216565644359955,-9.711981477295708,0.0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark13(-8.669844599214034,-0.7519806530389307,-1.5707963267948983,0.9587777540321466 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark13(-86.71815248988742,-0.5372885385884478,-29.63662024022149,31.669089501679707 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark13(-86.99084602368615,-0.15169935019103162,-1.7763568394002505E-15,43.17512146026752 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark13(-8.708575672505418,-0.11118386961359106,-68.28201500321403,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark13(-87.28327353595768,-0.9643292559082332,-99.83517551717841,-0.06083005155517421 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark13(-87.3106416677702,-1.5707963267948963,-10.916120707845014,1.0000059091627893 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark13(-87.36490909636103,-1.5643348145916753,-2.458865605104029,0.9702145314910394 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark13(-87.4003352121023,-0.7002761549264038,-73.90410780982175,23.70469417936792 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark13(-87.41850281482695,-0.9146263880456473,-20.762473071498064,44.051961091745085 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark13(-87.56591257816872,-0.8003758417935553,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark13(-87.61514543671605,-1.5707963267948957,-6.270040783011922,44.15007302491645 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark13(-87.62063369124238,-0.0306991324494017,-90.95288811861522,-1.0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark13(-87.66981329519845,-0.21129140158447524,-12.928387952362026,0.0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark13(-87.79603057278759,-0.344735755686044,-71.4631866022773,0.0728101095722134 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark13(-87.86278867683362,-1.4367757630707043,-36.51975472960378,67.98255552253897 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark13(-87.9178685262444,-1.2411430092657054,-72.55158958211585,-63.82123208664596 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark13(-88.07845160089273,-0.38769732234271714,-1.5707963267948948,86.17383021445036 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark13(-88.26117390540841,-0.10350649559739546,-0.12982287145173665,1.0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark13(-88.39700620098475,-1.2494082300611768,0.0,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark13(-88.40166396267854,-1.5707963267948957,-64.85460074442919,1.0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark13(-8.841071161253291,-1.5707963267948954,-19.45071634312105,-1.0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark13(-8.877166983576558,6.440124606666132,-88.1512303051705,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark13(-88.90378518771203,-1.5707957837968796,-54.067099591795035,-0.890862636516524 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark13(-89.00357691658989,-1.5707963267948912,-45.69852602236839,0.41446234655393965 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark13(-89.00791938890899,-1.0471975511965987,-74.08474961882357,1.0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark13(-89.01523819323903,-1.5707963267948912,-5.912776385694144,40.907954624405846 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark13(-89.13913120936435,-0.2066277522992707,-31.111182996619817,-0.2594058241494126 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark13(-89.19894374894388,-7.105427357601002E-15,-124.2862808016013,-23.74514809959753 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark13(-89.23452905118864,-0.4400910132296474,-101.37249817949878,144.00600360045362 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark13(-89.33565280733488,-1.108326127736409,-64.50132452364704,6.371602147261598 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark13(-8.934237377509005,-0.7251285483749014,-59.1545647705007,-0.030271215367548385 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark13(-89.39521674197663,-1.570796326794894,-42.546385066643914,0.3208756289839221 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark13(-89.42528722474637,1.6797728498701472,14.439544560590228,-45.59364841219379 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark13(-89.47389997169816,-1.5707963267948948,-90.89595817257381,-1.0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark13(-89.48798330180712,-1.5707963267948912,-36.57649514544622,19.08551985260067 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark13(-8.951149908910743,-1.068702669064182,-0.0316012283441323,0.06550502520585078 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark13(-89.53007949924535,-1.1128958496456818,-14.738759790600412,0.03691096217321074 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark13(-89.58956462329179,-1.5170314734582675,-1.5707963267948966,82.65544826251579 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark13(-89.78854079040379,-0.2579809973563341,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark13(-89.796502080421,-1.5707963267948912,-25.84171476590504,-0.7952078987158444 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark13(-89.9215664121199,-0.01785601866252029,-0.48474809633345006,5.421010862427522E-20 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark13(-89.95422240701528,-0.042940716858689276,-9.933177376026933,2039.0667800409583 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark13(-89.96234641021556,-1.0542139413984124,-31.701516746893603,0.0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark13(-89.98575515833602,-1.5592464618965494,-31.54326954303221,-1.0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark13(-90.0409631952794,-0.13794554959122252,-100.0,-0.3180993940244574 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark13(-90.07699244907532,-1.5707963267948923,0.0,-26.882961456564594 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark13(-90.1992640622842,-1.5707963267948912,-25.473642845397457,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark13(-90.38797349894774,-0.044238712654342316,-0.8977022672098814,1437.0693758337466 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark13(-90.43671459218034,-1.4853850759440634,-0.01732456061992054,-1.0132144984604048 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark13(-90.44354291338446,-0.011701768372298941,0,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark13(-90.47659423817,-0.08162625491029653,-20.452342558555856,0.1045379945377802 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark13(-90.53860212548042,-1.3205896007905413,-88.50799728667161,-74.54214089518862 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark13(-90.57420409318597,-0.744643175601324,0.0,0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark13(-90.5821551044483,-1.5025750163413034,-84.61269224211979,1.0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark13(-90.67353139417048,-1.0470461086901968,-51.88645376701758,33.38047828501989 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark13(-90.67480309063205,-1.4822768041491974,-30.933494881008173,0.9620368616518415 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark13(-90.92082502168068,-0.13522378023129936,0.0,-0.5603708200274999 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark13(-90.92591427012692,-1.5707963267948957,-1.1864506533965722,66.9591121732281 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark13(-91.19726716591244,-0.03753123984576398,-0.8990573413808053,0.45239941323624794 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark13(-91.21047166615969,-1.5707963267948912,-96.51354501208576,-0.05591633692934754 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark13(-91.23186727365562,-0.1692246243288262,-0.42313111046713914,1.0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark13(-91.23258453944189,-0.046192815098136664,0.0,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark13(-91.34219968774664,-0.7395225131518928,-1.5707963267948966,-0.04597238896166406 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark13(-91.34971114133945,-1.068803104106152,-34.58969946245415,-1.0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark13(-91.3866803503027,0.00869865490699244,-44.09884690342931,1.0000000000000004 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark13(-91.45232190654676,-1.5707963267948963,-1.0872373870703878,-0.9999999999999964 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark13(-91.52046935578414,-1.08804265001312,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark13(-9.153864725587495,-0.403909562066088,-25.68966889849078,-45.09567244943784 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark13(-91.53894990419523,-0.3363837657378168,-42.62229306565961,-1.0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark13(-9.155236711802559,-0.6100909427480922,-95.54680736922438,-1.0000011165223772 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark13(-91.71033263375973,-0.5519100253582394,-97.7804634496919,-2308.7288518161217 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark13(-91.7463987534395,-0.12912876977013454,-9.239499646318093,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark13(-91.8536985650698,-0.7071746399158749,-0.6738727393463405,-35.433659162023275 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark13(-9.187225297579175,-1.437374335769312,-68.68698006161407,92.0277036562066 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark13(-91.89885826968096,-0.8660365883869456,-1.5707963267948966,-0.024448489537329626 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark13(-91.912741641584,-0.6194014207403928,-1.5707963267948966,0.4623676206657319 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark13(-92.00451913773182,-0.7354562651574477,-67.09494662573351,1.0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark13(-92.2262497099073,-1.2270865555060109,-66.14953921819557,-57.58656542167469 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark13(-92.24505735627581,-0.004367071351707181,-8.745241390392492,-1.0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark13(-9.228261702858587,-1.5635580643269442,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark13(-92.30217188083834,-1.5707963267948948,-11.234380683787904,0.06255758002687489 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark13(-92.37487341051735,-0.15849614784906407,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark13(-92.37556274285993,-1.5707963267948948,-44.14807701688139,1.0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark13(-9.244296382514522,-0.05198311322725779,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark13(-92.57268456367412,-1.5707963267948948,-1.5707963267948966,1.9024540102744355E-19 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark13(-92.58101925790479,-0.670404507409567,-5.551115123125783E-17,-0.9287516497641906 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark13(-92.71478598186249,-0.2271621982840486,-1.5707963267948983,0.3546134314481222 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark13(-92.72434163049448,-0.022075935003036656,-100.0,-0.06511708619127701 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark13(-92.82730936898224,-0.32167096324299654,-9.848944171389636,-1.0559388873773927 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark13(-92.96516262490805,-0.5091465399908464,0.0,-60.300867661826516 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark13(-93.00486468407158,-0.14270087532855202,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark13(-9.327410644483983,-1.3990295498554741,-55.89629381139477,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark13(-93.32627475139164,-1.5707963267948957,-24.758557123052107,1.0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark13(-9.367664670871818,-1.5707963267948948,-73.46951073438525,20.420019333666065 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark13(-9.371630702880745,-0.5302124047984482,-76.53839981425008,0.9592205067785011 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark13(-93.72753291924946,-1.256473578860946,-68.73691148979987,-1.0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark13(-93.78821341585709,6.429308218168182,-1.5707963267949019,0.0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark13(-93.79561904722044,-1.2908360986066252,-18.540572374431818,0.9712675007070078 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark13(-93.84507852979345,-0.8826122766606879,-47.4236778256607,0.7699133193910218 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark13(-9.393522525549884,-0.5002753932223655,-36.18693256747097,0.9530767947044029 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark13(-94.1415027607287,-1.5707963267948948,-53.745434842108295,0.9999999999999999 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark13(-94.20827340416797,-0.7214467174455876,-6.213108341352111,44.3250313018882 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark13(-94.23360313482917,-4.208569700553767E-4,-31.103940599227343,-1.0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark13(-94.30232667702514,-1.1972171229517605,-89.31934373668327,88.99648561686001 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark13(-94.30266222043585,-0.6020018516287882,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark13(-9.440141738083641,-0.4370146102368803,-1.5707963267948912,86.36756141461521 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark13(-94.42638890735353,-0.06704768634091723,-1.5707963267948983,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark13(-9.463957485405723,-0.4321439210973873,-1.5707963267948966,0.4569221897831453 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark13(-94.91035702658846,-0.05717727310330719,-1.5707963267948966,-12.905275697857249 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark13(-95.07073406807116,-1.1081262088703667,-7.105427357601002E-15,-24.144961994646025 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark13(-95.157574979841,-1.3720454737000978,-65.89378767317227,3.2626522339992623E-55 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark13(-9.5223818120601,-1.1726240743079455,-1.5707963267948966,0.8704836015748622 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark13(-95.31268715171888,-0.18351491368314043,-1.5707963267948966,0.9999999999999998 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark13(-95.33283599396395,-0.3634398625262487,-88.44640656577354,-0.8930588422545243 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark13(-95.40262806863299,-3.552713678800501E-15,-33.96888980816031,65.39521643191318 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark13(-95.43295543078534,-0.9645520933527483,-31.27167043953895,-1.0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark13(-95.48394617691594,-0.5964578098272861,-12.60013768731693,-1.0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark13(-95.62886867454814,-0.8612351997416114,-39.22570452067522,-64.85449458652212 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark13(-95.63337523509198,-0.026821295812856534,-83.19919184172261,-1.0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark13(-95.64757354336372,-0.655832789379474,-43.78614220063504,-44.39079095906702 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark13(-95.67541866391386,-1.066677837358234,-99.98243984852462,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark13(-95.6767791332454,-0.937122079660967,-34.042039753549844,37.288624174050504 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark13(-95.75563349638888,-1.3881490525915436,-1.5707963267948966,-1.0000000458597236 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark13(-9.585164167614991,-1.5499543603359747,0.0,0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark13(-95.92667951098231,-1.2552121549210644,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark13(-95.97368809677147,0.77997648580647,100.0,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark13(-96.0135480719886,-0.01679695319595046,-0.08961281644439163,-0.01680050529900612 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark13(-96.0922172993955,-1.1805816633337685,-4.926933602060104,-63.871282524241856 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark13(-96.0954805217379,-1.5661441902280013,-6.75107818802223,0.11309731416125235 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark13(-9.619106258716862,-0.6648510875597742,-13.953383516452737,50.507234893467796 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark13(-96.24896419009647,-0.27735607756912295,-0.5104439380683454,72.8748734213303 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark13(-9.627057141373152,-0.275425712971463,-43.995533160849455,-0.40509263697219733 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark13(-96.42127511716448,-0.27771741151882967,-31.763494573355644,-50.373165297666475 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark13(-96.50178965703188,-0.7458507321067356,-1.5707963267948966,-0.8125671686383605 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark13(-96.57856132803461,-1.5501943271614693,-40.941894196587704,-0.044713507382697984 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark13(-96.60322089317161,-1.2792932530949104,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark13(-96.67179343802387,-0.06527714173515786,-1.5707963267948966,23.866077533080848 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark13(-9.67119747908588,2.668176725257575,-1.5707963267948912,100.0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark13(-96.73524660074817,-1.400560963535699,-12.102608626334874,0.9972801637297535 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark13(-96.8948069780253,-0.976374023970485,-25.049927322213023,0.8507576665242902 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark13(-97.0479951286951,-0.48699687436497746,-75.60354732168754,-0.918089177381061 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark13(-97.06103552151087,-0.16822170186692964,-72.74829359296847,-12.581635446032095 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark13(-97.09664725817925,-1.4861436728750075,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark13(-97.10607034019029,-1.5707963267948961,-54.20621116742529,0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark13(-97.1204969298464,-0.3342594083009871,-27.45295817725837,-78.55827203282871 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark13(-97.1266103041169,3.988564153999675,-77.57024702959666,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark13(-97.15837697234488,-1.5301047871311912,-72.60495582086094,-56.67897934852044 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark13(-97.21969128064488,-0.5312554484722212,-22.11112047992543,-0.13303962668331715 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark13(-97.3005717744036,-0.8039199262631623,-1.5707963267948983,-0.33200555893599537 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark13(-97.45655737799099,-1.5620935306420582,-88.94388303127148,1.0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark13(-97.46212245099295,-0.2669427417771901,-6.418700315609253,0.06255270630254363 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark13(-97.51971585981238,-1.5707963267948963,-32.46330439308262,0.0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark13(-9.764091977585792,-0.9978435228826888,-1.5707963267948948,1.0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark13(-98.01564003152029,-1.5705904404579307,-0.14085555760542512,-1.0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark13(-98.036404481307,-0.04220871301160989,-1.5707963267948966,-16.63751898703764 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark13(-98.08854459124615,1.2843327596464247,-38.71775846354781,14.034602265384066 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark13(-98.14054773424408,-1.447140234494082,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark13(-98.15247179124792,-0.7532423041951675,-62.60056138982432,0.9999999999999982 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark13(-98.16563825383022,0.26077044912424696,-111.4622910491647,0.0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark13(-98.30592902275347,-1.4612832682020036,0.0,-1.0000000000000009 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark13(-98.37663871123583,-0.6917386242870949,-1.447056101477925,-74.46088040979264 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark13(-9.85601339982252,-1.5311692593868926,-0.34238468390042603,1.0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark13(-98.83081883564118,-0.11715286261654967,-93.49572103789497,97.98326143983789 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark13(-98.87819298472193,-0.20838940360835068,-58.62618616017316,-0.4959028487489755 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark13(-9.896442143940362,-0.1832733490501539,-11.469756604565553,-0.19759128378979451 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark13(-9.90640167251162,-1.5707963267948808,-81.42597181377526,0.0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark13(-99.23086319655087,-3.552713678800501E-15,-1.5707963267948966,-0.5428638521351039 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark13(-99.29279478918393,-0.4714778989881978,-30.179037505338258,37.238139822883454 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark13(-99.39759737573956,-1.5707963267948912,-71.86322603176308,91.16511291786452 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark13(-9.941208220084611,-0.24992257936716,-0.11046368865667433,-0.040806175131738176 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark13(-99.4183411563522,-0.3733318224809501,-111.31627305751688,-0.8695038127571877 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark13(-99.41918449587794,-1.5450529805501343,-61.34150874396689,1.0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark13(-99.44449814030972,-1.1191563840579493,-3.7415776250315957,21.644479367146488 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark13(-99.54410425016914,-0.46598360367265457,-45.40251893925755,-1.0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark13(-99.64812913694901,-0.3745969037096839,-36.64734677349699,1.0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark13(-99.648671896267,0.5389203078171122,2.5848249568505337,2.1574762091590344E-17 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark13(-99.66232897442156,-1.5434305054386694,-9.682268424221707,0.9905216336497805 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark13(-99.70971389583792,-7.105427357601002E-15,-46.87072578609718,-0.015647446909661633 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark13(-9.973186445612242,-0.2566178190858164,-94.33687855275544,-0.04842178485533377 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark13(-99.78318103635623,-0.7530220747636437,0.0,-0.044190045481743295 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark13(-99.88537517743615,-0.0718581593106078,-1.4139739113731296,0.8066928975612755 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark13(-99.96520794269694,-6.749573520663365E-6,-1.5697345197940271,-1.0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark13(-99.97938149938376,-1.018926842022448,-4.406797667333103,1.2994262207056124E-113 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark13(-99.98322552687803,-0.056870980421588085,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark13(-9.998371034073937,-1.4596439763623763,-0.3196641841561798,-25.52045584901913 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark13(-99.9914154411216,-1.5707963267948954,-50.15385863348453,-7.515897762939077E-9 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark13(-99.99378420969215,-0.13804208881626298,-88.38326411340375,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark13(-99.99974167996064,-0.6512602646029252,-4.8610924157548965,5.421010862427522E-20 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark13(-99.99999981379479,-0.43498173980102695,-1.5707963267948966,5.293955920339377E-23 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark13(-99.99999999999993,-3.0582146787939403E-30,-1.5707963267948966,-3.693751300414441E-14 ) ;
  }

  @Test
  public void test1823() {
//    	UnSolved;
  }
}
