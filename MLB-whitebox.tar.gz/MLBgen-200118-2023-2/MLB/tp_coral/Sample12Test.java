import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(-0.9367132335772936,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(-1.0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000018,-100.0,1.1102230246251565E-16,71.68148371115034 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,0.9999999999999996,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0000000000000036,80.02496026022023,-0.06255255621475679 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,-1.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,1.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.01976394686108837,0.06258928214828059 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.02128632186531565,0.7204915810257964 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.022964256521486925,-10.632541171836078 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,2442.777180781897 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,3.552713678800501E-15 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.03958885493390095,1.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.04376703750908227,-6.16470308884394 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.04603734423654851,-0.6815326712258059 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.04753379620731436,0.8322335385427896 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,-97.9793260237309 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.21766336825226143,-1.0003333728091741 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.403799090566777,8.881784197001252E-16 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.4450622039841766,1.0000000000000002 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.49723558413754076,-100.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.5734543023041756,56.779308645471986 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.8693451221654058,-1.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.8924778949844887,1.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.9999999999999982,-38.97165171265396 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-100.0,-0.06521253298994611 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-100.0,-1.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,100.0,-1.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-100.0,1.0000000435053897 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,0.02350259986734861 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,0.7670418236011759 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,1.0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,1.0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,1.000000000000987 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.1102230246251565E-16,0.9940023412215011 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.1102230246251565E-16,-1.0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.1102230246251565E-16,-100.0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-2514.3178717663995,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-3.240954335511761,-1.000001618795203 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-8.20036876689068E-15,1.0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.021687576466265,1.0,-19.067877033428125 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-10.30335837699828,-0.003943357532599778,1.0597655220992095 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0679770074957275,4.440892098500626E-16,-2.3478164648151356 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-10.758992896623052,1.0,1.0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.090422888161773,0.02122706414895456,0.05135905846058354 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-11.306409336759131,-0.7841377061885393,-1.0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-11.726468314619318,0.0,-1.0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-12.335776724071174,-1.0,0.9763122737958255 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-12.543498247158222,-0.3623421351731453,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-13.530950830797916,-0.9967506153970448,0.0625552374637306 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-14.450944962895562,-0.9999999999999998,-1.0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-16.701840913043238,-13.845038146951726,-1.0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-17.009364802074135,0.9999999999999991,1.0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-17.614320989817983,-1.0,1.0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-18.555075131703262,0.006353098771304411,-1.0000013320027161 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-20.362771761053995,1.0,-0.005310973353929133 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-20.667474148727866,-0.8199205656426432,0.3626801428814955 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-20.679981943999397,-0.6257359650523623,2.1840452084008195E-16 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-20.892659439816686,0.6068836237729018,-0.9712811755690107 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-23.333813020606772,0.0,-78.40006017295784 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-23.354940713772848,-1.0,0.0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-23.432021205042293,-0.6221226378781788,1.0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-2.495125318130995,-1.0,-49.29157359718263 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-25.19917847978792,100.0,-1.0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-25.28321292160321,0.0,34.18509240917734 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-26.41275637274845,3.4679796421181714E-5,0.6192014567567647 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-26.5704756891459,-0.003335809776550902,1.0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-29.691654184542475,-0.9857677124443719,-0.9913344496430414 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-29.935569014757206,-1.0,7.213264545145106E-130 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-30.479406813866444,1.0,0.02119754527360629 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-30.52432336458444,0.8029120586793783,6.776263578034403E-21 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-32.080794585616125,-52.98517507760754,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-32.70868696825784,0.052510762091845416,1.0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-33.11361472710164,-1.0,0.9997442228638992 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-34.85082893924077,1.0,-1.0000000000000042 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-35.934700206372526,1.0,-1.0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-37.05179486807195,3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-38.64801379492939,-0.01919257603896896,-0.9581492433515563 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-38.82761724570345,4.440892098500626E-16,-0.9999999999999982 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-39.596054115241685,1.0,0.9999999999999991 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-40.33110222996676,-0.9296372130920914,-1.0000001371301492 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-4.076467225426118,0.8029864383049554,1.0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-41.89068410292716,1.0,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-42.62680244331602,1.0,-86.56848046155011 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-43.15361502400167,0.05280729789085914,-0.3028951862441521 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-44.053845749624514,0.0,-0.009981633265264103 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-46.579359190253975,-1.0,-1.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-47.206981339426534,0.6822523870027737,-1.0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-48.51306230497791,-8.823248799672955,-0.6079189701762324 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-49.08555342800864,0.05584403587784465,-1.0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-49.42232241626252,1.0,1.0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-50.70806370666019,1.0,0.0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-52.4813797219403,-0.9940699879546459,-1.0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-52.57888213706769,-31.648608646933685,-0.6364690893901954 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-53.11371287560989,1.0,1.0000005438789434 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-55.53301911887423,-0.025291565958139306,0.02807756303072831 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-58.18295110892362,0.04061566975900477,1.0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-63.353536137132515,0.018638466536576775,-96.21376868892263 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-63.357961030477426,0.8813937376431159,0.021237333337363634 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-64.99733444818601,-1.0,-0.607632114306015 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-65.01821780827942,-1.0,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-66.25578306149306,-22.274451765057385,8.673617379884035E-19 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-67.33498536047446,-0.02055246725789761,-1.0000000020629942 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-69.17710619471163,-82.47461316403863,-1.0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-69.81924038365378,0.983162480865169,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-72.28067516888625,-1.1102230246251565E-16,-1.0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-72.37179867318012,0.061507567892522985,0.9978438515827978 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-74.57328551272637,-0.849786442340891,0.557642601634539 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-7.673612999773694,0.0,-0.01742278157932367 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-78.33293302235653,-1.0,4.208711092806702E-17 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-78.33846071114168,1.0,-0.0633254843128862 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-79.57064604613583,0.0,-1.0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-79.71205786345747,1.0,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-82.04546885690084,-1.0,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-82.35286948174019,0.049520222607161976,-100.0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-8.249970092195682,1.0,1.0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-82.63253991986825,1.0,-7.456210757922571 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-83.55097171139887,1.0,-1.0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark12(-1.0008362778695126,-100.0,-0.9995890872057366,0.3624299777342427 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-88.23034367618561,1.0,0.003952873964807591 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-88.56159163278245,-1.0,83.81194240268617 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-88.69828998879814,-1.0,-0.039352163118453465 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-91.62349754414754,0.0,-73.71777749884545 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-9.27282399827913,-0.029354399100045524,-100.0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-93.88464590795905,1.0,-1.0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-94.58443937603786,-8.881784197001252E-16,-1.0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-95.04325950326657,0.0,1.0000012274030026 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-97.26676597105819,1.0,100.0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-97.94430387488242,-0.9168254263410475,-1.0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-98.97972956466943,0.0,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-99.9919594277983,0.9800813276412502,-1.0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark12(-100.20470050670329,-110.66347353616842,-0.02039226299945878,-2293.024421087409 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark12(-1.0022376164713862,-28.92766681599273,100.0,-1.0000059447949516 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark12(-1.0030332709821674,-36.183794105219945,-0.727433153761816,-0.9993438307132196 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark12(-1.0032288326036005,-100.0,-0.34817062875056215,43.960864635671186 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark12(-1.0038857837456314,-91.27526516977977,0.6395792377307841,0.0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark12(-10.119679804667236,-7.697315279825769,0.0,-21.883703067673977 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark12(-101.53781991995642,-110.9126094530441,5.551115123125783E-17,2265.6590367143185 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark12(-101.75052858568087,-100.0,-1.0,0.1272836672693176 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark12(-1.0182993161753597,-14.801773994004124,1.3877787807814457E-17,0.21227998733610431 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark12(-101.87048946759344,-69.28381533193458,0.0,-1261.3581871260058 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark12(-102.87454266773192,-23.03232289708567,0.002824705802228184,0.02937050182172751 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark12(-10.348515360321258,-26.56205724328629,-0.05513493221232499,0.9999928849543724 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark12(-10.381005558211044,-75.26499103513754,0.0,-1.0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark12(-10.434515174277887,-10.752613974039823,-0.03884065487527412,2.1989469451917965E-4 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark12(-10.470859669571169,-36.83459927607058,0.04791885725181011,-0.9812628002502409 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark12(-104.88458135693806,-66.11492520083443,0.026525148181300136,-0.9999999999999964 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark12(-10.491860645343142,-64.02919547328429,0.8089151713846288,-79.9951980456994 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark12(-10.564455596029648,-63.35144245919055,0.0,2340.3481842477377 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark12(-10.63643415463647,-6.062789780893868,0.9999999999999996,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark12(-1.0715487251935394,-10.436956665103608,-0.48341751328006116,-82.32299601031829 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark12(-107.19176445486707,-85.47837371022933,0.49254628328931815,0.0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark12(-107.2693952727613,-65.29367676298477,-0.05069697162184586,0.6635503461477334 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark12(-10.826747894430076,-93.23279971808238,0.0,-0.427226769476448 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark12(-1.0829226231310893,-66.54757476243164,-0.026093178351362323,-1.0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark12(-10.847633291254134,-51.05683299902649,-1.0,1.0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark12(-1.090558992205677,-52.75139861619038,0.0,1.0000000000000002 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark12(-10.958156638961098,-32.29381977689307,8.881784197001252E-16,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark12(-109.58274367862914,-198.23262513271013,-0.9769287461775207,-1.0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark12(-10.975832246268638,-97.4991194715563,0.0,27.774006960573296 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark12(-11.019173046958894,-12.593725857814938,-0.006310876055119846,-1.0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark12(-11.025314250516363,-33.70810053435429,-1.0296075359776165,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark12(-1.1052789028682506,-1.0248462400736715,1.0,-0.5294759436482369 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark12(-11.084978735943324,-100.0,-1.0,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark12(-1.1088452112328895,-2.1562567381438953,-1.0,1.0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark12(-11.113108187878424,-62.253111623681725,-0.8028558700140367,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark12(-11.118592055054094,-78.56064146631267,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark12(-11.125363305237386,-76.04362243815892,-97.2954494135491,-0.006635039419167429 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark12(-11.169702681391522,-100.0,-1.0,1.0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark12(-11.184891812018478,-14.50664743890015,0.22567895023227375,-1.0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark12(-11.213402326104443,-30.08659104703916,-1.0,-10.568127051862248 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark12(-11.216958476951673,-72.94212768496624,-72.48277647213892,0.0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark12(-11.271090572550548,-31.35921013612726,-82.29356918724658,16.63645193568985 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark12(-11.288573726888398,-49.43945374421008,-0.9733967187211117,-16.507576846112517 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark12(-11.352603806288073,-22.983597563526114,-22.85423674720536,-0.6920580449774346 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark12(-11.42675932861519,-70.87337640895016,-0.02406025785062882,-1.0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark12(-1.1588742315420257,-69.90148151847592,-0.9756302009046552,-0.08902189698445284 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark12(-11.612878112190307,-8.825554078909908,-0.021475931005542327,-1.0224262715053047 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark12(-116.16126836472012,-100.0,-0.009908137839460096,0.0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark12(-11.7217898931511,-22.08634628038673,1.0,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark12(-11.724533730092503,-65.5178360865387,-65.62051889785022,-44.72213843591668 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark12(-11.79191671041042,-54.61068029139632,-1.883220869990598E-16,78.11551646224672 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark12(-11.845130646539962,-21.692337362687397,0.0,-0.10786632468465829 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark12(-1.1913575101623777,-100.0,-0.054493812103431884,3.197764415347604E-5 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark12(-11.972365294711107,-2.9067362827143324,-0.9977177971804354,1.0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark12(-12.012968167846974,-30.528893654992743,-1.0,-0.8509680241201955 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark12(-12.103152024097668,-55.7752487777762,-80.76935880482814,78.84175056840371 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark12(-12.153620720891658,-25.692650430267072,-1.7763568394002505E-15,21.333865327509304 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark12(-12.190977657229553,-35.01795763190326,1.0000000000000018,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark12(-12.23801932625746,-91.10066805047049,0.5572045321831629,-1.0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark12(-12.238845177023563,-42.78209939281212,0.12737926038026615,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark12(-12.240029574030416,-62.19946957209428,-0.11107641533919832,11.004673517182667 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark12(-12.28580799975596,-16.064410269045638,0.0,-82.61116146858056 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark12(-12.388729830115011,-46.96273555074964,0.38668425714324073,-0.494216127525843 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark12(-12.446053978853698,-93.47832465321503,1.0,-1.0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark12(-12.656492422823959,-98.47131251326009,-97.68074634073656,34.818363513602776 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark12(-12.771621448301644,-60.80148268022643,79.76818724912894,-38.45505113329077 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark12(-12.842067915767213,-1.4548277858177123,-0.00527983528210307,0.04969518962605918 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark12(-1.2936092198080804,-36.739033727845865,-0.062209137078407487,-0.2007788513524439 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark12(-12.962425837963869,-99.99999842991723,0.7491968639939671,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark12(-13.04895291601327,-67.49700119909232,96.94928917018508,-1.2668169822791228E-6 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark12(-13.246794458165795,-53.976346444258354,0.51091537294975,-10.81360307534527 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark12(-13.32439986374423,-62.02627507469737,-0.05427787786507815,-0.9998641643664358 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark12(-1.3342369325210655,-99.96265466456528,0.8949198555137603,-1.0000000000000004 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark12(-13.365975642255894,-13.062741887529457,1.0,1.2994262207056124E-113 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark12(-133.9855158455035,-32.44506197592298,0.0,-0.8329514794063506 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark12(-13.45718801436238,-15.594698518209434,-0.9999999999999929,-1.0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark12(-13.488740764864275,-44.74381664073614,-0.01508362588636366,82.20810907651183 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark12(-1.3574508414722715,-38.188743028614034,-1.0,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark12(-13.604201292309247,-65.05669960745963,-0.8253092252393259,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark12(-13.695658611566634,-43.755086384897396,1.0,-1.0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark12(-13.986004523706374,-94.21150632486093,1.0,0.9999999999999998 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark12(-13.989972373148163,-100.0,0.0,1.0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark12(-141.65848926826993,-35.317563622180145,-0.7295613685307536,-1.0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark12(-14.191257696738788,-73.73336739385738,0.9999999999999964,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark12(-14.265237323392693,-18.470617108453368,-1.0,-16.014172697758863 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark12(-14.274820628722836,-6.655160898971047,0.0,1.0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark12(-14.306870950353698,-75.27228523094773,-0.9082825186152224,2.710505431213761E-20 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark12(-14.459175592719454,-91.06237621183271,-0.30560429718846827,-23.675748355657447 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark12(-14.516763051580298,-6.152647475654752,0.180510513645312,29.47805843085135 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark12(-14.567590320051648,-43.800921246144306,0.0,1.0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark12(-14.603339671765013,-5.973623034948388,0.0,-0.98363259358405 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark12(-14.743030150385607,-88.04028708232023,0.533875716474256,-90.10170522145253 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark12(-1.4758450157223253,-30.75753675489212,-1.0,0.8957666811716434 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark12(-14.957278545453136,-59.91898649319195,-58.4214106755565,1.0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark12(-14.97556937954927,-54.43792456700223,25.315899556031866,-0.013642815813076081 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark12(-14.986176643761633,-39.483506124191024,-0.7972960465655374,48.82508995469419 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark12(-15.003498977940302,-15.819855415268826,-1.0,16.60597556020067 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark12(-15.005418734362852,-82.27154062249474,-7.105427357601002E-15,1.0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark12(-15.01274511531601,-7.782398273881833,-1.0,94.88217351192124 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark12(-15.068338648044476,-93.950436659851,0.7867111409477288,1.0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark12(-15.073119066570023,-3.6013198000765563,-0.04208057051518819,0.0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark12(-15.075214913117136,-100.0,0.05950903560076845,-100.0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark12(-15.138632959525573,-1.1692906266406187,1.0,-100.0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark12(-15.17225612752796,-30.267765266428142,1.0,-0.4379872860985379 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark12(-151.80133924422844,-99.21138367533345,0.3840525410976161,1.0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark12(-15.234587271904289,-59.371108655683706,-0.003107193338998976,0.06032197365263234 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark12(-15.37181550249133,-23.479836952857294,-1.0,-0.8707657177639666 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark12(-154.22382084365566,-28.539658605928935,-0.03192619797949092,-25.48064910244993 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark12(-15.474397186031831,-65.1259892662381,1.0,0.04968448144392068 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark12(-156.15582022911022,-86.68913443161486,0.546780693968907,0.967234814937612 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark12(-15.62486995603292,-100.0,-8.881784197001252E-16,-100.0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark12(-1.573621157923864,-36.651651484904136,0.04888346117176996,-0.05696594964017654 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark12(-15.753559128898125,-13.245738812003125,1.0,-0.7101056847051979 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark12(-15.760052074657475,-86.29221062563315,-0.02500035997493251,0.4732633122579012 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark12(-1.5861410857868086,-51.5469964964065,-58.1796761877958,0.007244432698736551 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark12(-16.023629031454092,-2.557676273303529,0.021242704562398632,1.0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark12(-16.078559577402746,-62.79532718983808,-0.052655339314357785,1.0469977608828742 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark12(-16.152668349843083,-100.0,-1.0,-5.795634610449096E-70 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark12(-16.207774026133293,-100.0,1.0,-1.000000060252625 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark12(-1.6226953153661157,-17.737605027175093,-70.8046478903834,-90.81030657666756 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark12(-16.280630864007613,-81.33452307038276,1.0,1.0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark12(-16.418562239436724,-26.15417428172224,-1.0,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark12(-16.426811686474366,-25.4708904120528,0.19872233278973472,0.4471118091528439 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark12(-16.443523540595454,-64.26473868930007,-0.014761727838488753,0.0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark12(-16.483888047210325,-26.95792885884163,-0.4250276681754114,37.58163809109641 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark12(-16.628933735590998,-86.7892796842792,0.17359244074989777,0.0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark12(-16.63041324717954,-16.267630349155663,4.440892098500626E-16,68.21557610549618 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark12(-16.66034067858333,-65.60500371432822,0.0,-31.684365029109617 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark12(-16.66196448415135,-3.8128915114699584,1.0,24.86334192702113 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark12(-16.76086951383202,-29.480645752732443,0.6724096814124987,-0.2604218748436604 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark12(-16.819400314905078,-68.39319568267207,0.5918634785192726,42.02501531705109 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark12(-16.83028662574631,-15.56346042632839,-14.075672379654321,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark12(-16.934716982554278,-54.527162284464126,0.9934593193941038,-0.3632630324615814 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark12(-16.935335393160983,0,0,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark12(-17.055813401497552,-69.47851038983299,-0.5147863902309046,-1.0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark12(-17.135032684235306,-100.0,-0.7377370360045139,-54.06419729287205 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark12(-17.244781918157216,-14.151093678247623,-31.693854535473598,0.001088846605429553 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark12(-17.269047647448723,-16.326793385524528,0.1968631779995526,-1.0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark12(-17.291306993034638,-99.99997497253149,0.05044308924425961,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark12(-173.24777243118712,-7.708117603765933,-1.0,-2062.349493974201 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark12(-1.7334613555529788,-82.85879824073623,-0.04781684616070826,-90.84896526077706 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark12(-17.33815302462854,-13.308596767042621,-0.9942632708637993,-0.030236579360220728 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark12(-17.346859560961406,-37.835246672560395,1.0,0.590358373103604 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark12(-17.385477317305444,-9.074850225108468,1.0,1.0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark12(-17.4962055786479,-2.6981516928391946,0.03331082182173545,26.642984933812293 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark12(-17.640360449207872,-59.818947848943154,0.8033556020971203,15.565209456859492 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark12(-17.68384079103734,-13.313417190587447,0.16124503962140402,2188.426688400495 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark12(-17.725797648870532,-4.796196983394703,0.9999999999999998,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark12(-17.73451925187395,-1.0000000000000002,0.5176115172824778,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark12(-1.7802930951709435,-96.56026973049703,0.02641734620701233,26.850432066735735 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark12(-17.85518189090494,-60.0878256747846,-100.0,-0.06255637634776073 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark12(-17.96304243243119,-77.763790938062,0.018382630511830866,1.0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark12(-17.994308421513608,-52.93300656175108,0.9999999999999982,-29.137521239880165 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark12(-18.139148230562036,-100.0,0.0,-100.0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark12(-18.160863535552732,-83.84118873885082,-1.0,1.0157495880847733 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark12(-18.17076734041727,-22.518277177024128,-0.9032435684264328,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark12(-18.29911096264146,-63.076045923421894,0.5710437177178416,43.89754931934331 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark12(-18.323819912280115,-3.415018189601838,19.69412464848226,-87.24133376449292 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark12(-18.324004328064603,-87.21503729942114,0.9958869758423965,0.3872206715187555 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark12(-18.434263845504162,-13.054394357031192,0.04774238257349782,-1.0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark12(-18.46871573193248,-58.56504568925216,0.01411106292764952,-0.0031099135864787195 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark12(-18.521023377578626,-4.4044299080874545,-1.0,0.0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark12(-18.60624704120143,-61.05573622194463,-0.9741419327122303,-1.6392939566674036 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark12(-18.622918426217883,-43.40891431167383,0.0,-0.6188748509719612 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark12(-18.640666905262485,-71.98749514708125,-1.0,-2213.5515104063943 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark12(-18.645333084564886,-27.42494249823615,-0.05329868306651807,-0.8660904821178974 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark12(-18.680404812791565,-33.211154058368905,-24.59737306777944,1.0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark12(-18.753566745810506,-81.1863405788408,100.0,-1.0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark12(-1.8902932207601104,-99.23676041754227,-0.4518177296401442,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark12(-18.93506687077251,-98.97807890683893,-1.0,0.9908405349251773 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark12(-18.93882506038291,-29.439102837565116,1.0,0.22691728430903257 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark12(-18.990227414509523,-7.357517716507823,0.0,0.012190620840393372 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark12(-1.9006845197733107,-30.11277487737454,6.938893903907228E-18,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark12(-1.9325549151266999,-11.215005656267925,-1.487841193631347,-1.0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark12(-19.354908099763236,-15.681364846124687,0.7211530185541798,-31.663215526556783 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark12(-194.19904191459332,-100.38800069562402,0.9591592146656366,-2269.3182267025904 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark12(-19.47224341548504,-1.5015202603325406,-1.0,0.8848915443203111 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark12(-19.488637250254964,-100.0,-0.0291409808883063,1.0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark12(-19.541172358090236,-35.511823811533425,0.0,-0.8399364805426464 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark12(-1.9547907702571141,-127.24896530686564,0.04738259293686087,1.0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark12(-19.602091453795467,-100.0,-1.0,-1.0000000736928045 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark12(-19.672023949490374,-28.57161161383297,-0.05775081495165951,0.9999999999999999 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark12(-19.74712444782311,-22.04406513195466,0.0,0.1199189011982319 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark12(-19.750255422793234,-33.38663631570052,-0.024272800077110506,-0.031448853939144594 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark12(-19.765961729969007,-98.02058351542755,-76.42007932065316,60.68534730869277 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark12(-19.884877025964908,-86.79963997053838,8.406831958112991E-4,1.000000055284817 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark12(-19.9106518180822,-100.0,0.0,0.03288798564845763 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark12(-20.01810030922006,-63.9333446386621,1.0,1.0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark12(-20.137547764924086,-95.38945308815877,20.003716907077916,-1.0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark12(-2.019676853469689,-62.87611017365429,72.31723464062964,-96.8732827244905 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark12(-20.19857412658006,-49.67072626842583,-0.0028591031952371893,-17.992489274593375 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark12(-20.282266898257138,-35.1960277210615,1.0,-1.0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark12(-20.327124666252455,-72.83287561461381,1.0,-42.9569961500779 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark12(-20.340907069041776,-66.59524139553687,-37.775571530075894,0.9968581039044281 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark12(-2.0360363606741747,-100.0,0.021748156516267977,0.7698716808071001 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark12(-20.405682620151385,-100.0,-1.0,1.0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark12(-20.42226087498311,-41.98796301067894,0.0,1.0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark12(-20.44057252522285,-65.92755670688828,1.0,3.469446951953614E-18 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark12(-20.444281776543733,-91.31844579118223,0.2642024079448104,53.67210290301432 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark12(-20.450666281064848,-100.0,-0.021741678541455617,-1.0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark12(-2.045859387634591,-8.966779403858734,0.5187318693098426,0.3184503484490921 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark12(-2.0498731298272355,-56.241540875604365,0.9985760476429602,0.9063191533339666 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark12(-2.0593619077634173,-175.44585187386014,0.06202253156320176,-0.0014919583882642665 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark12(-20.654841883790517,-75.2303149783209,-0.9562805703287847,-0.030164930586573855 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark12(-2.0744705169213007,-20.886557813656662,-0.9741787528998929,0.9993197678699289 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark12(-21.023060498015063,-19.19113538216121,-73.06149705732126,-1.0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark12(-2.1140468253511737,-100.0,0.008644111426274081,-1.0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark12(-21.26493344710842,-38.48153640329437,-79.93458387605811,-0.4244820669328748 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark12(-21.28706305848661,-41.43728400520645,1.0,-75.9243057731682 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark12(-21.351618112347374,-11.252983298738414,0.6713361606777273,0.14172175705497825 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark12(-21.37605094557286,-8.314781925141581,1.0,-0.9999999999999998 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark12(-21.384884971114154,-55.775624236279064,-0.9242772090618949,-1.0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark12(-21.437475431058317,-100.0,-1.0,70.4348866303119 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark12(-21.462224068829016,-100.0,-0.7677263989031016,1.0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark12(-21.52082321845866,1.0,0,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark12(-21.6245552330021,-37.22204883722212,1.0,-1.0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark12(-21.630735965089276,-86.04002744278597,1.0,-1.0000000000000036 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark12(-21.67024796659794,-67.81709733463786,-20.01297021072853,0.5158203488212895 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark12(-21.76005428498067,-2.028986294538603,0.0,1.0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark12(-21.789297610814998,-28.884621194978347,1.0,1.0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark12(-21.850050239028945,-76.51039673140266,0.9736039142453592,49.18734961751079 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark12(-22.13786753903048,-45.63038958447013,0.014089540770595765,-0.08589163193034288 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark12(-2.220387566027636,-13.070113399863633,0.9367725389788298,1.0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark12(-2.223589968798195,-23.574022350721194,-1.0,-0.01696352177912657 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark12(-22.38105436859665,-82.25096153235052,51.44091711674548,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark12(-22.413212375727745,-74.85881742666267,1.1102230246251565E-16,1.0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark12(22.549013795843578,0,0,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark12(-22.57697191887742,-64.87925248780935,-1.0,-0.9662858596865084 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark12(-22.597930426883025,-74.39888090099416,-55.034214768108455,36.83835842323805 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark12(-22.679430490564428,-88.2952520266442,54.20733996984853,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark12(-22.68775026391991,-4.439952430440684,68.17472763298517,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark12(-22.726912033015342,-58.06411900913285,0.5600776131986711,-0.022765268461526322 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark12(-2.272882518997548,-67.36104379362453,1.0,0.35997911433636 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark12(-22.775923598355647,-99.98442578219401,0.5578544487885,-1.1869459682199748E-66 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark12(-22.782646680676933,-3.5692457199578485,0.42090021953628476,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark12(-22.824070200877486,-78.44141403141685,0.0,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark12(-22.956623103506004,-59.90407543070563,0.04085931609120093,22.261948675247655 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark12(-23.12777457266475,-31.703686906555152,0.05760930358010627,1.0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark12(-2.325036960909724,-65.53803273862775,1.3877787807814457E-17,0.5822240143617726 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark12(-23.304422816068644,-87.56838914461193,0.22999545733139934,-0.8882609182868163 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark12(-23.34938860383258,-53.06090147368611,-32.41681210953316,0.6736702060318802 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark12(-23.43237514588938,-62.80558643496676,-4.761983320452188,47.10799955284776 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark12(-23.488952989118083,-1.5296882779438565,-0.998527134387798,-1.0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark12(-23.60924586941995,-100.0,0.8918838712835513,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark12(-23.63896440697802,-76.78028379618868,66.28177577418413,-97.85936701673057 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark12(-23.72162029768777,-82.26630366758204,-0.002306116811132311,-1.0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark12(-2.376984336031084,-16.509612828724183,-0.8753111494622186,1.0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark12(-23.816537653264106,-61.6710151064658,-1.0,45.92664974710681 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark12(-23.845301780865366,-36.787411674579765,-0.49263426673106336,-72.52766544659576 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark12(-24.02397965325595,-100.0,0.02530407584451434,-0.06258383462797028 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark12(-24.043756716039976,-14.532978971616767,0.9751465099809457,1.0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark12(-2.406006054733293,-100.0,0.007674369328859065,-89.18491454655955 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark12(-24.09624355619615,-40.27591333904723,-1.0,0.5689250592935473 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark12(-24.156750433052835,-78.32781860507335,-57.738114989245965,0.9654431877877497 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark12(-24.22400344706093,-51.45086936776901,0.0,0.009816475208590525 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark12(-24.273511820397406,-32.05911903756569,0.6107854200646576,-0.3959787259419443 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark12(-24.30354367933933,-74.93596975701391,0.0,-1.0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark12(-24.35875644393559,-52.94542229068842,0.0,-1.0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark12(-24.37619477479095,-23.27958331462863,-0.0037013012792782574,1.0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark12(-24.532303287789954,-44.65997773845815,0.007187218991974831,0.8032680155334919 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark12(-24.571264290610912,-100.0,-53.04810579005499,1.0000000000000036 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark12(-24.63782883622123,-4.637457140278656,0.0,75.64217917195722 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark12(-24.841022643442614,-85.50667337881444,-68.16546718853375,80.72088211045275 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark12(-24.94620370786646,-32.84847409772973,0.073995818018326,10.322823078596052 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark12(-24.963744438578775,-100.0,0.34469561924930225,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark12(-24.966666472525844,-3.2372088248564808,0.5629662529442929,0.49439061130187434 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark12(-24.979480838610947,-100.0,0.9493637168587792,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark12(-25.01155763591617,-1.0000000000000018,0.0,-1.0000025969891693 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark12(-25.038874662492788,-94.46755368361315,-1.0,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark12(-25.103004629045415,-34.54833706286457,0.7224259741230534,-0.9961240719811798 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark12(-25.12614692884617,-12.480258613029761,0.01586976507418547,-75.38347590074046 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark12(-25.144663030674334,-85.93517509577119,-0.010319766397361797,53.23966768111628 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark12(-25.164893553325562,-73.92224191161552,-0.9448281761755468,-1.0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark12(-25.193416890789322,-39.64129827964488,-1.0,0.0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark12(-25.225559162330374,-4.412927720928295,-5.547243974909242E-16,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark12(-25.300345593152645,-32.704222561910086,1.0,-0.7217558152863623 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark12(-25.32154582546427,-31.214036692059587,-0.8606222023278628,-100.0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark12(-25.419180287184904,-20.97148367793291,0.23798766752165834,-62.68010401788511 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark12(-25.52310481791451,-71.60887401772227,-0.3030299244034345,-1.0587911840678754E-22 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark12(-25.573955191081566,-18.269758251023433,0.0,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark12(-25.63045054292901,-80.16744824682085,-1.7027640412352554,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark12(-25.69106955107128,-92.40647634885275,0,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark12(-25.862411874126646,-82.77494859865168,0.04200550288991984,0.16882718327950638 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark12(-25.866422168932345,-58.55766386648949,-0.19293115027769359,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark12(-25.91186861526218,-24.80105783212676,14.606898078378919,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark12(-26.056492939009217,-87.44503878442278,0.0,1.0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark12(-26.19088206797684,-35.93066814566793,-1.0,0.25587289875665054 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark12(-26.210610111474406,-100.0,2.7755575615628914E-17,-1.0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark12(-26.21322747614128,-84.65700489599327,-1.2573917423789008E-17,-1.0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark12(-26.22381909207393,-8.829431316004419,0.9231810558637925,-1.0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark12(-2.629359131196291,-7.9286781288340435,64.59345122532012,-1.0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark12(-26.30267100034105,-33.96019334993414,-35.47529500989551,8.673617379884035E-19 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark12(-26.409195607281987,-12.182110548297464,0.03813473645834232,-0.4471020376930833 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark12(-2.6466686787231763,-25.227597805855112,-0.9999999999999982,-2343.196981121775 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark12(-26.56596450774177,-91.12559127152949,1.1102230246251565E-16,-1.0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark12(-26.79496011406916,-25.20833304188916,-0.04868342201929149,0.2570906263963438 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark12(-26.799058390934235,-82.34389818848267,-0.9988251293701935,0.7879340980047944 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark12(-26.80334376068525,-75.62410010706637,-22.908501015003946,-1.0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark12(-26.8130233244178,-97.87524052022039,-5.323540301218372,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark12(-26.838655856485367,-10.720039540711461,41.728819760095455,-11.059723832255955 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark12(-26.93137931230045,-31.337311814319605,-17.061971038864485,0.0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark12(-26.949322300678418,-12.589811661117201,-3.9875895758997686,0.4821630242388597 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark12(-26.949995489880976,-70.13366689499806,0.7593933487560744,-26.72872492290348 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark12(-27.123878046119785,-94.95185573429436,-0.024973851312469916,1.0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark12(-27.21006500666986,-62.98009434934284,0.05010748797807296,-1.0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark12(-2.725389785964879,-99.8509510493857,-0.021602861579161393,0.9999999999999999 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark12(-27.514002683262223,-33.73906244026354,1.0,0.0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark12(-2.7630624596689253,-43.79932641677552,-1.1102230246251565E-16,27.760203026623014 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark12(-27.669715507610658,-100.0,-0.005852595551511852,-0.8959294060105594 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark12(-27.672852809316463,-7.787028665392421,0.0,-0.04786573434986311 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark12(-27.67826031159701,-99.49198742008141,-1.232595164407831E-32,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark12(-27.754991089983545,-63.23008976999287,-1.0,-1.0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark12(-27.80062580642422,-56.30097663915594,-1.0,1.0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark12(-27.87429568650102,-78.17342583482886,-1.566823567693881,-1.0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark12(-27.91404288330517,-25.681457728890788,-1.0,1.0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark12(-27.950224271333255,-78.35115134492656,1.0,-0.05820888941990282 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark12(-28.010706325352878,-64.11032637561998,0.0,-2.050851564560684 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark12(-28.089087014135362,-84.53891754961738,0.032551834253721657,-1.0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark12(-28.089125945409286,-81.6372460735289,-1.0,1.0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark12(-2.814944195073309,-62.61245011400081,1.0,25.480042467752256 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark12(-28.17337416695795,-100.0,0.0,0.0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark12(-28.19752051181428,-42.239843268553884,0.0,50.855167902109024 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark12(-28.232732589350835,-4.4608577462545185,0.8091001660104151,0.600168485052336 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark12(-28.247429036729216,-55.17267803070034,1.0,-2290.398663522424 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark12(-28.35259480641929,-17.554437404826146,0.0,-42.477655216666996 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark12(-28.407849518215173,-61.2356058987658,-3.552713678800501E-15,96.02145071006765 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark12(-28.436877447467744,-38.937493935241584,-0.8601489555874438,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark12(-28.443738917562357,-63.02386695178879,49.96555433013572,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark12(-28.52830069152105,-32.377086908950766,-0.022965253241428576,1.0000009423409046 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark12(-2.869175459639213,-100.0,-0.2724239947198486,-0.3651438745247546 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark12(-28.877752483485736,-73.2371499050052,-2.220446049250313E-16,-0.9934106504837446 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark12(-28.966628416439534,-100.0,-70.51119976905278,68.36589017544094 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark12(-29.111269902885567,-79.42781872003333,-0.9490009927278015,0.0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark12(-29.131942556007054,-76.46994508965696,1.0,-1.0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark12(-29.160585341935597,-79.83387160808468,-1.1666317811995828E-15,-1.0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark12(-29.16489518006834,-32.771155194466075,1.0,79.79729085060401 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark12(-29.24203515105625,-85.36367686435752,-1.0,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark12(-29.251912720756486,-100.30697536975218,-5.339750439873004,-2321.9328025875666 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark12(-29.305121086654392,-12.290326350774743,-3.552713678800501E-15,1.0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark12(-2.979371836677128,-42.92510693808883,-0.008894325312527165,-1.4468848569030882E-4 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark12(-29.828166899946588,-100.0,1.7763568394002505E-15,-68.49698531927245 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark12(-29.921404037281683,-51.58165579377686,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark12(-29.92461995406698,-3.985330809354844,-88.37412064531095,-0.9878873390214755 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark12(-29.926856932331678,-59.57071350800706,-0.8633442662219633,1.0000000000000036 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark12(-30.230888398492677,-47.357315163971585,1.0,-0.9998639742506515 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark12(-30.259701295723463,-100.0,-0.5881677878281539,-0.12150887662495435 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark12(-30.307797998786675,-10.788895459321095,0.0,0.5206878317156521 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark12(-30.328390144626184,-10.035848225429092,-35.36846246118883,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark12(-30.453678924318623,-100.0,1.0,0.0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark12(-3.046072014728986,-82.62771059628793,-47.60911776322364,1.0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark12(-30.52153253804788,-73.61331517820432,1.0,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark12(-30.526444079300543,-53.35749777630684,0.979813121051704,-14.955959172308827 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark12(-30.52650917379013,-63.66738003521428,-0.0040790444510097066,0.0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark12(-30.62717335028179,-47.288550387349304,0.6090846315534395,1.0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark12(-30.996610218410844,-100.0,0.0,-1.0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark12(-31.042184900106086,-54.55994968004113,-3.552713678800501E-15,-0.8781364825064926 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark12(-31.45662341639578,-100.0,1.0,-1.0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark12(-31.473747758691193,-48.497472739547746,1.0,0.21923340259926682 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark12(-31.49904057344672,-57.30180503135178,-10.84952959367105,0.9999999999999929 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark12(-31.52807285600952,-80.80044489309978,-0.04824732520485932,-0.9432182980439343 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark12(-31.673832531601423,-60.87712622627481,-1.0,1.0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark12(-31.739644219492426,-91.09462315318115,0.02998887561661359,8.470329472543003E-22 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark12(-3.1988783469554942,-65.12112838570985,-0.0591302295986425,-0.4528718257207315 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark12(-3.2055021199590072,-4.569774929129437,0.7029729441184767,93.00564256367954 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark12(-32.57910953124944,-42.05592725841089,-6.776263578034403E-21,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark12(-32.641193303737516,-35.909162095877,-0.011590287611214972,-1.0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark12(-32.68575730389994,-19.99621468408953,-1.0,-1.0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark12(-3.2860887412871147,-29.167886393292246,-0.011638960586461938,-1.0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark12(-32.87454058577319,-46.322096739805275,52.10758961388157,-0.3441519773975219 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark12(-32.98397798759994,-23.58484775104742,0.8744543457901122,1.000000000000007 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark12(-33.06333289527508,-34.75823831326148,-0.021488863683671644,0.21707063650963687 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark12(-33.15273580719588,-83.29808041050006,0.0,47.07194307631822 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark12(-33.19782054557195,-77.82246095781115,1.0,-28.960190699035774 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark12(-33.2776166386785,-84.38301486684651,1.1102230246251565E-16,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark12(-33.39246566842005,-20.504305029046975,-0.020259688098370737,1.0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark12(-3.345626868527418,-4.220562153584382,-1.0,1.0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark12(-33.645868681307675,-73.65450330485862,-0.024873176208921932,0.044297765615330886 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark12(-33.689800653086316,-44.396508006319785,-23.25200685424198,1.0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark12(-33.7719682512169,-55.06109703653589,1.0,1.0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark12(-33.779406334016684,-15.159009359256558,-58.353828773431694,53.75454503289396 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark12(-33.7946008403255,-4.740967019809375,4.905420879582152,87.09216594478545 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark12(-33.84809188900225,-67.47142885361805,-1.0,-1.0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark12(-34.09049417704733,-2.916189874456377,-1.0,1.0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark12(-34.09798224464385,-100.0,-0.4821897667427115,0.6249958068580067 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark12(-34.23780644202333,-63.29609020823417,-0.3844007818412495,98.04421314204765 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark12(-34.28612055235614,-51.892195866158175,-4.440892098500626E-16,-2267.1506656931915 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark12(-34.33563303087398,-5.064160690738037,34.24096084473425,-1.0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark12(-34.40769656049935,-100.0,-0.043170068393343586,-0.5751804400788304 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark12(-34.47681498615856,-47.12571762419717,-47.95408162991368,-85.5130581697704 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark12(-34.48338432769962,-30.634090661652767,0.0,-12.61320497645645 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark12(-34.51626117740393,-9.210686075032555,-83.58447153167685,22.684653774142106 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark12(-34.745465938293506,-45.18126261812517,-1.0,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark12(-34.74655672048012,-7.216422709410205,-0.9754923775382984,1.0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark12(-34.76935957911245,-97.07004400559886,55.227307278273486,-61.2426789797623 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark12(-34.81191334178898,-40.42288531665847,-0.5920655382004902,-40.599292600936906 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark12(-34.93091433722091,1.8317170276166195,0,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark12(-35.21180012714956,-13.336062121371935,1.0,-1.0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark12(-35.302408655295146,-40.68165959566524,-1.0,-0.8520600580386839 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark12(-35.30796136957828,-73.20045253949299,1.0,1.7527100803159925 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark12(-35.364495264405946,-61.89756027971248,-1.0,-1.0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark12(-35.45548162734485,-50.97979765721232,0.9706100989407597,-0.014602986589221352 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark12(-35.4733775460227,-70.64560321575314,10.204969103874141,-0.013310870703919198 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark12(-35.53373194540875,-7.697234687524347,40.85541507304932,0.0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark12(-35.61030313161524,-1.0004805242001873,-0.03899583039384566,0.9586925109126158 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark12(-35.88423289265906,-17.556988024490366,-1.0,-97.55174757795308 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark12(-35.949627179937266,-32.055913173207855,0.7459296776589972,-0.01119729905377187 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark12(-35.95820199434259,-72.85664516020196,-0.9999999999999964,70.84128205551193 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark12(-3.6173428680657977,-69.48843431047707,1.0,-0.9999999999999964 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark12(-36.20901593787526,-81.90888208222145,-1.0,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark12(-36.30556318084158,-45.75448981383462,27.494845622725713,-1.0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark12(-36.38559886219957,-36.2142618391553,0.020674760799994425,60.33415057025502 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark12(-36.51259939318731,-62.600495533535465,0.0,-0.362995303092759 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark12(-36.53765834901041,-16.238808476934185,0.9637503244840004,0.7573230713292505 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark12(-36.60651438724729,-82.29829930111778,-31.832586743417536,-1.0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark12(-36.64749785018853,-61.75975295905962,0.03665728044157346,-15.173358184737504 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark12(-36.701073742314954,-85.87509688839953,-1.0,2344.7248403270432 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark12(-36.71102519579475,-87.42732266326539,-35.29597861088189,-15.36205295363456 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark12(-36.737229882976074,-51.519328583657334,-0.9664086449298029,-9.138937021469701 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark12(-36.79378268864857,-72.1600265558864,57.191888713667936,-11.714536962479485 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark12(-36.82045616241763,-82.64946019593097,-0.3570036883912159,2328.7435515488646 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark12(-36.858841455183615,-32.74986959137785,-1.0,-1.000000000000007 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark12(-3.688692478697468,-9.098438926772863,-0.02208636806021622,-1.8678062827363934E-6 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark12(-37.04988021272351,-16.73744615019131,17.989972424441234,-0.4328017747929973 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark12(-37.23485529049395,-72.46219271546725,-1.0,-56.94423480196523 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark12(-37.32555545618481,-73.22164100309476,1.0,0.0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark12(-3.7330616728828154,-65.22766765030897,-1.0,-0.9166346663796944 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark12(-3.73401437514363,-60.52110442905951,2476.279987657779,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark12(-37.37965674552839,-53.31811836644927,-0.6550465329285684,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark12(-37.43927748787026,-43.08526010532604,0.0,-18.799406160399904 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark12(-37.64947608152406,-61.87209181331978,0.022466331555180283,0.06865349085506267 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark12(-37.69073242898961,-43.19243703115083,-0.08578105367992928,-0.9803291284434469 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark12(-37.812484090671305,-84.8188469604722,0.39139309539929457,0.886652403990972 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark12(-37.86141895860547,-25.460665645121853,1.0,20.667673344423335 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark12(-37.99732915874191,-58.354472417190635,0.016878437115608658,74.54077557363848 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark12(-38.066333405835664,-24.919996937627815,1.0,-1.0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark12(-38.068144079234415,-62.58394062904702,0.008886506115545423,24.767572748574274 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark12(-3.8077733988292612,-77.88868293972067,1.0,0.4751463497495013 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark12(-38.35631608221945,-86.82067381366747,1.1102230246251565E-16,-1.0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark12(-38.360423161236554,-16.717622590952356,0.0,-2266.2027625030223 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark12(-38.42572855670431,-69.2905429624085,-0.6320923965154179,-0.021091231407527777 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark12(-38.58540875756445,-43.94363838445679,0.0,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark12(-38.80307401696834,-51.27310962519015,-0.972468958052299,-0.3504690554315708 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark12(-38.90188816989641,-48.609474099053905,-17.171842914643346,-1.0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark12(3.898378816973576,0,0,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark12(-39.01025728614833,-68.2895246901267,-34.72131610140508,-13.735666361470876 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark12(-39.040339187343655,-76.62665321299195,0.06001718661135843,-8.761489017191014 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark12(-39.07556120187559,-45.553950171374694,-0.04692175112240014,-0.012378171550503133 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark12(-39.141094029326325,-16.46968015145861,0.027996128676382917,0.039071143629238414 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark12(-39.24090091236672,-96.32695157372122,-1.0,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark12(-39.382212990321875,-90.78732464675866,0.0,1.0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark12(-39.41753468834061,-91.10557296507929,-0.9999999999999905,0.8615731170508218 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark12(-39.47404552304536,-5.212568391680916,-7.829857158909533,-25.834861223651103 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark12(-39.52943581761653,-41.38562530398099,-0.05934384349787764,29.264379722560758 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark12(-39.59940322971682,-12.264564558644079,-0.910770011637873,0.7028211800458886 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark12(-39.67187157217197,-6.765433608525299,0.04220821153976926,-1.0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark12(-39.71853455148943,-48.34969432692225,-0.3607961177968928,0.9999999999999991 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark12(-39.7247110520998,-42.738364527038314,-0.0020863158257530723,1.0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark12(-39.75538565595654,-42.41206455434338,0.0,0.4246300189592268 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark12(-3.9799478001517885,-56.320389000698356,0.0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark12(-39.822339385564604,-2.791341168913022,1.0,1.0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark12(-39.88794573155928,-100.0,-0.05353672911693125,-46.02532840375361 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark12(-39.94171537420733,-78.63964450768961,-0.7604277784155004,-60.784468491937254 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark12(-40.07807331033462,-100.0,-0.6652536560793578,25.45669606509262 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark12(-40.087967038978434,-100.0,-0.9780052581839382,5.553860972950299E-17 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark12(-40.29200454707569,-50.138660622806256,0.9999999999999982,-81.07821693794031 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark12(-40.378553419156916,-92.15605778244657,-0.04174064893716793,-1.0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark12(-40.4027853840758,-8.104989856970619,1.0,1.0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark12(-40.438556761922754,-48.471471295572364,-0.8935114570967588,-29.006633493035586 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark12(-40.70988309940856,-100.0,-34.65733495140317,0.035540136647804144 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark12(-40.77418918718459,-59.89086149890242,-0.9503783984149277,1.3363823550460978E-51 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark12(-40.867082049735515,-85.81171625366446,-1.0,-1.0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark12(-40.96212628674163,-81.80013004814761,-2.5913612849508354,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark12(-40.991413260890496,-37.79061249997686,-0.04159733520413844,0.9999999999999999 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark12(-41.11251644443348,-32.44210803360159,41.54486683359769,-0.6913594978407669 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark12(-41.13240230240872,-6.034567824689756,0.0,-1.016175072652811 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark12(-41.15596026137911,-69.08240208648668,1.0,53.59513125834724 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark12(-41.207368647490796,-1.8880440390584852,-93.372279498352,12.627947133865902 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark12(-41.30837640464535,-57.08105118578297,-0.25185617666912186,0.521503997308626 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark12(-41.42303915380183,-20.849034893460193,0.0,-1.0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark12(-41.447156689669384,-50.89816274146273,-81.78610565680387,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark12(-41.62967097890562,-100.0,0.9044199136847314,1.0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark12(-41.690783225505456,-89.12793362690189,0.4616442729005823,-0.7061809235915333 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark12(-41.748931991794834,-6.306601228001314,0.6721988556466929,0.03471352892642421 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark12(-41.77970367106045,-84.70069292415141,-0.03705918646049815,-1.0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark12(-41.8719312822593,-53.19502219788093,0.0,0.21453808459831514 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark12(-41.911063935777,-52.37420282705606,-1.0,-1.0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark12(-41.93125296905133,-95.71382269976736,-0.042700639743348576,70.03927983355837 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark12(-41.96020996868117,-57.794432988280185,-31.298706468229156,4.440892098500626E-16 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark12(-42.095697163373515,-89.64525003449016,-0.059719309534968665,-0.06256587160722385 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark12(-42.10809405966767,-36.607522106707016,1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark12(-42.18598574988513,-21.16367652239054,1.0,-1.0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark12(-4.219777095221417,-65.76852228050836,-48.59311771082879,-15.795178203432258 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark12(-4.228036098351581,-23.86300138311402,-0.9728963199676202,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark12(-42.337722576068224,-6.1868518019777525,-11.312685920548333,-31.960584904724044 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark12(-42.39449746448456,-1.4048610200111655,-70.35530390658886,-0.9999999999999929 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark12(-42.41728260282678,-34.94337387446233,0.0,-0.9346666988100829 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark12(-42.44506482707403,-8.53770319101656,0.8174814714480263,94.8522508172319 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark12(-42.48533026070692,-35.73536310465968,-0.9999551522411865,-0.37343877345735244 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark12(-4.261270022484074,-70.71307393053135,0.9999999999999998,82.48024733994471 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark12(-42.661048001201785,-80.02816612225276,-1.0,-0.8852782101582664 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark12(-42.82257838692051,-32.64912394530255,0.6215611777120068,-0.06273241936922365 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark12(-42.83482851362442,-78.57729754454238,9.501668983837817,-2377.058191539416 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark12(-42.893678553469826,-53.057202995538645,1.0,0.9999999999999964 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark12(-43.07919028058866,-41.86400669589596,-54.91589837584898,-63.96493139480415 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark12(-43.085687745217484,-65.97814153968986,-49.76639874502169,0.651588241796361 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark12(-4.319862940009788,-97.71050498393802,-1.0,-69.65716267879263 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark12(-4.335646031530672,-78.87669708391256,-0.3064155413646632,-0.879954817762686 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark12(-43.3957203552625,-44.647914043360224,-1.0,-73.18075780328981 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark12(-43.51020926951601,-25.431234567615306,-0.017549634445838458,-0.5014346474477346 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark12(-43.578429917174674,-20.114269195172515,3.6778484310939774E-5,2055.6955634992446 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark12(-43.66458543293052,-82.15146278943777,-0.8510370579493892,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark12(-43.73062055531298,-16.370411234009186,0.969736014103108,-66.53645625137662 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark12(-43.817031859469346,-98.6228603936585,-1.0,0.8960611905205633 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark12(-43.867785891182535,-10.049029688526247,0.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark12(-4.3977735428474,-98.45336407132223,0.052195320885927994,5.551115123125783E-17 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark12(-4.417374643036957,-22.275489309419548,0.0,1.0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark12(-44.41479247321807,-47.7487658974332,0.8135240567755604,-1.0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark12(-44.42344574480446,-8.657321495197898,4.9355158837307067E-178,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark12(-44.56565733354609,-78.33102739310695,0.0,0.0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark12(-44.570966292739755,-12.273483638198748,-0.24066956969010866,1.0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark12(-44.67447999902632,-88.18962042480236,1.0,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark12(-4.468285235017578,-70.33770173638709,1.0,0.03159933169376233 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark12(-44.68296900130125,-32.74881049628242,-0.2443433067638674,0.0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark12(-4.471961674082679,-75.03265164040246,0.04375568984840269,-0.061847988272180965 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark12(-44.76378600981883,-67.23440378187385,-0.08915220465208507,0.0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark12(-4.481350534284914,-45.535218123131706,0.0,14.634455981434584 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark12(-44.8211240245615,-48.43281011537403,0.022784535641551248,-0.9999999999999996 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark12(-44.83225484041438,-17.0286281684744,-1.0,-0.9999999999999858 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark12(-44.840786630944784,-100.0,-1.0,-100.0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark12(-44.84636415251441,-74.73543826831013,-1.0,0.5782827861026598 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark12(-44.98173776767645,-11.118119408589578,1.0,-21.10748478066773 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark12(-45.146135010827116,-23.230298503232085,-1.0,32.01566667024652 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark12(-45.1493782743337,-2.9625107188168625,-0.043084381417551304,-1.0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark12(-4.524886478307536,-15.092338852109208,-13.792420813581344,73.54314125132689 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark12(-45.27463477306321,-35.85764248574463,-1.0,1.0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark12(-45.352536301049874,-5.1231337983904,-98.45713441441634,0.7897486511974625 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark12(-45.39401051626906,-7.6421324899860075,-16.96771972899505,0.3509618186280279 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark12(-45.7529922376431,-65.5143938535653,-0.012225643810067147,1.0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark12(-45.78301132463878,-57.0716450661634,1849.8651861521382,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark12(-4.579491528591518,-14.474034829615107,1.0,93.72579886646491 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark12(-45.86099133170592,-34.52909262075697,-1.0,-1.0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark12(-45.88167737022926,-25.14754367514749,-0.4275234429369875,-0.6824107292130055 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark12(-4.5943666562646985,-80.88462312314223,-0.8406403975124972,-1.0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark12(-45.96815541199057,-14.08715366342442,0.9999926155458229,-0.019594848609689908 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark12(-45.99900607563271,-71.79109867666824,0.0,44.1640500958613 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark12(-46.03739345509611,-49.08318889890468,1.0,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark12(-46.03994127456719,-47.81170973375419,0.5418708038180385,-0.15447183428445554 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark12(-46.17667039174646,-45.354712177875356,-32.340967451958264,-1.0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark12(-46.24324910545184,-31.46522732023627,-0.4396977098556054,1.0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark12(-46.2813518957845,-11.438986282023222,55.284270956430646,-5.341730097131675 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark12(-46.32677332025675,-42.03579817317313,64.61186293442381,-1.0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark12(-46.436459608791026,-71.96439921014728,1.0,-23.86913852291803 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark12(-46.52011691817586,-41.955117563297044,24.31130014035474,-0.9999999999999982 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark12(-46.7135731097001,-72.17175268261022,0.028560662780956352,41.89822923594835 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark12(-46.772810322195355,-52.26814863348906,-0.9852162870914406,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark12(-46.774808080196934,-16.35652465524317,-0.40332178607422087,1.0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark12(-46.84045036786325,-19.902860797866516,-0.3309808492632875,0.27042395438658856 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark12(-46.941263085502655,-56.30365810628798,-1.0,1.0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark12(-46.96552809497908,-74.36147090768644,-1.0,-0.9914466374218308 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark12(-47.03638380059657,-47.43320168178993,0.0025835971001285096,0.9974024762934927 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark12(-47.1308338250287,-40.703278012555785,0.0,-14.560996218036976 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark12(-47.14552970051599,-133.75751039561115,-1.0,-19.82180937999216 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark12(-47.1853996793611,-17.224878638917268,28.95078573204733,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark12(-47.331206780521974,-12.222811377391281,-0.9999999999999996,-0.05402794031002678 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark12(-47.401037988243665,-97.84953708022981,-0.03644135243363964,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark12(-47.46961318967378,-40.91067595960491,-0.020655869116656733,-84.53736642301324 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark12(-47.509348572821274,-77.31786738501381,54.64717203709637,-0.8468228553099106 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark12(-47.52336668003089,-4.142723648419125,-0.057348365701858944,6.708492241815321 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark12(-47.61102933555938,-28.285583942816643,-0.6044822544388739,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark12(-47.696484332607625,-43.58754741955322,0.9818979517130831,1.0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark12(-47.75899507174325,-62.80112442141513,-71.47755997709217,1.6016664761464807E-145 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark12(-4.776209214067698,-96.80610647774986,0.9961164423447232,-1.0000223705217473 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark12(-47.92140893278705,-5.236967332047434,0.0,2.356062542122748 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark12(-47.923257770949355,-55.6563465535184,1.0,0.9251696569336397 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark12(-47.933694368404026,-58.13426080123855,1.0,1.0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark12(-48.13923219403647,-52.028373861887395,-0.8862240042603938,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark12(-48.1442852730711,-31.800040785545015,0.9788381941933978,-1.0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark12(-48.18011943926022,-83.6581219663945,55.8444029242288,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark12(-48.22393032064471,-26.411206766700083,0.04808655427320364,-20.413952662398604 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark12(-48.25194212408125,-29.42046358769585,1.0,-0.2605682501097979 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark12(-48.286669831415026,-55.66956278773817,1.0,0.8861398216682257 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark12(-48.41420116816372,-26.940642834136508,-0.014723872647849367,-0.4854203451939663 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark12(-48.48711248661319,-105.1550438608797,-0.22098292403684727,-29.89364388128581 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark12(-48.499770644907535,-15.153459488351038,-60.938490782323086,-0.2887313189612385 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark12(-48.5391198536441,-40.496982597695386,0.9381519208665341,-0.5944347428572327 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark12(-48.585807735138246,-1.9628802557958107,-1.0,1.0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark12(-48.79685436240169,-32.087902088596636,0.46951840253469257,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark12(-48.8143562365274,-100.0,1.0,-7.628196330244356E-7 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark12(-49.00984550507066,-25.361641248416376,-1.0,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark12(-4.902208395328691,-97.29846630015983,-78.61426613875277,-1.0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark12(-49.036726948772554,-100.0,1.0,-0.005298922042958509 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark12(-49.28340053553,-96.3765160285495,0.0,90.98089215028892 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark12(-49.33360254673194,-15.96575503417475,1.0,-0.33439153529381827 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark12(-49.35439914678523,-36.49113973629393,1.0,-1.0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark12(-49.41272618502584,-60.234639117157116,-0.0345169866010997,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark12(-49.48382287280843,-82.58338244417442,0.0,82.47794815015496 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark12(-49.488476614938456,-1.1886296692569296,0.5316513390585857,-48.036423807081796 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark12(-49.547600457482375,-16.511073536663535,-0.9328804136536856,-62.990417079885404 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark12(-4.959229881731338,-6.46810464751985,0.978269085710333,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark12(-49.61376767741599,-50.49345340474841,-0.7596470206290588,1.0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark12(-49.64923267556563,-83.71383655336753,29.570845588696272,-1.0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark12(-49.705082326982634,-61.403317627900506,0.012095262111766925,-0.4767911387108654 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark12(-49.84297317993648,-3.613546790438349,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark12(-49.879475353063526,-36.97027042320513,-61.98580528545951,0.12988701273115377 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark12(-49.901703970857426,-8.422870316221651,1.0,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark12(-49.93585603216569,-100.0,0.49014008468118136,1.0587911840678754E-22 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark12(-50.13276000559891,-63.913687761073305,-65.19955348843266,1.0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark12(-50.17060329877077,-77.32044841265147,-1.0,0.9999999999999964 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark12(-5.020068725041012,-16.727845599196336,0.661210624045973,0.5938503149654268 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark12(-50.22018352617481,-38.09782576468502,0.4094132478212744,-55.22684870429242 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark12(-50.25834880427395,-68.96418750634433,-0.012401859868639425,-34.27628343540174 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark12(-50.41415809376966,-58.74617633912028,-69.01544592954492,0.36444547765839536 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark12(-50.53959318724368,-13.685159714450833,-97.80700643794542,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark12(-5.064592889630215,-24.556921504295204,0.061001573424947386,0.9999999999999982 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark12(-50.81532281728482,53.82219409850612,0,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark12(-50.815622136619616,-96.38439499134006,1.0,8.673617379884035E-19 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark12(-50.92825676385935,-28.799545751195613,-1.0,1.0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark12(-51.13112640786508,-41.48325965352115,0.0,-1.0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark12(-51.22072958291919,-14.97520523455853,0.9015185028607816,-1.0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark12(-51.26921060907292,-59.494373746595556,-0.025331981555345346,-9.032150421769211 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark12(-51.31764558740413,-18.37398007277071,30.430078892549737,-0.031109469295292572 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark12(-5.133127594107293,-10.842520147280993,-15.230877433945935,-1.0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark12(-51.43820757952542,-45.59743263621647,-0.9452186166125587,1.0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark12(-5.1487734376877095,-1.8263010985595431,1.0,0.1819913990975488 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark12(-51.514133114929656,-100.0,-0.6904185015579143,-42.94903305970724 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark12(-51.694727456377535,-87.88085568346546,-0.4171835822912793,-0.5544870632112904 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark12(-51.88971108173954,-57.380087623913624,-0.016969787089123452,1.0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark12(-51.90691770674948,-100.0,-1.0,0.06255272411788268 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark12(-51.927862979574144,-100.0,0.05656857243425363,-1.0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark12(-52.04627334037081,-48.512247960608306,64.49174761227107,-0.4248545349982962 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark12(-5.207439890172367,-100.0,-0.9789397728609894,-0.3715585575579643 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark12(-52.13858961567266,-2.836038425523995,0.22678022318573277,0.9999999999999964 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark12(-5.218190757240691,-8.261022885752984,5.551115123125783E-17,-0.37235855746683755 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark12(-52.193590870337374,-18.697292432689153,0.7521196155121767,-9.950638914506234 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark12(-52.22507428385878,-19.88986509878508,-1.3877787807814457E-17,-1.0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark12(-52.32721091661239,-5.339928947256728,0.974234039664958,-0.6011278412638461 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark12(-52.424025673963584,-65.91090380796987,72.59888067615327,-1.0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark12(-52.52873513809127,-77.30556476980807,-93.92796639271636,-1.0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark12(-52.62858746341858,-89.80075222607387,-39.81585208714253,-34.039908878382775 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark12(-52.79939001348156,-47.9261872674321,0.0,0.5499030396847052 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark12(-52.94546182365188,-71.98319490436049,0.48996470978817674,1.0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark12(-53.04461848646439,-45.624097177571684,4.440892098500626E-16,-0.9553693239250968 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark12(-5.309883303157029,-56.58186933811629,0.9793049136737562,-70.57714213392745 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark12(-5.312212280955393,-15.813727795573794,0.0,-0.8620130898256291 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark12(-53.19626887615454,-1.1483434718929888,0.0,2.1175823681357508E-22 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark12(-53.24498738364146,-32.46149789862925,2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark12(-53.259696358298314,-46.66648474587419,-8.990663827006102,0.06033461462971129 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark12(-53.27105404543395,-94.07897558502782,-60.60446814607736,21.13982893688025 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark12(-53.33156072947528,-45.14722436779256,0.0,4.281545149210439E-15 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark12(-53.39487971557815,-21.023789313672985,0.0,0.8099159387905508 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark12(-53.41585085816425,-95.99738180908474,-0.009439608532295363,64.91243472788085 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark12(-53.427819736400075,-49.40058305253885,0.6182688506217517,-1.0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark12(-53.559534770728256,-20.464035646036248,50.31951807077918,-1.0000000855042146 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark12(-53.60919878961361,-66.9468451422556,-0.6710628878545464,66.01974915159246 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark12(-53.92621157161923,-63.23365289892287,-1.0,-3.621507535363432 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark12(-5.394591514462032,-7.614511316313525,-0.01005202899002422,-0.09516328834434207 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark12(-54.140065080995626,-43.482610855639294,-81.95233895048375,0.0625949169645302 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark12(-54.1600902857881,-65.79166060209107,0.7871926783669828,1.0000000000000002 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark12(-54.33392241224068,-56.81619404569686,-1.0,53.62477983037549 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark12(-54.38578378053127,-28.104885262955264,-1.0,-23.059839137417185 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark12(-54.49794399443415,-100.0,-0.05392373253203858,1.0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark12(-54.5085266544467,-1.194009590768843,-1.0,0.9038131981113391 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark12(-54.55175952846975,-36.16624173399525,88.72625440547345,-1.0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark12(-5.458563074436077,-53.91763252407464,0.9999999999999929,1.0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark12(-54.689292858419705,-57.7634215685084,1.0,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark12(-54.75343044599005,-72.90067943241412,-1.0,65.2907344383758 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark12(-54.808105764422514,-18.89261540193095,0.0,1.0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark12(-54.895056966379954,-22.723296670157183,-1.0,5.701159036063785 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark12(-54.91909716703218,-4.306408702815157,1.0,61.00848751860062 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark12(-54.95844260817015,0,0,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark12(-54.960726866064704,-17.90404203883419,21.11659187128964,-0.3931629297042618 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark12(-54.979923145024564,-76.75162202156851,0.0,-6.680973856854014 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark12(-54.987665469081065,-55.033238865902064,0.0,-16.382506832226927 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark12(-55.03580622452844,-36.62666248444934,-1.0,1.0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark12(-55.08112726276215,-61.14716512787728,-83.78036144647955,1.0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark12(-55.086741782432355,-82.33159933532704,1.0,0.027003415234209766 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark12(-55.15966146910524,-100.0,1.1102230246251565E-16,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark12(-55.26216473074768,-35.865236532046694,-1.0,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark12(-55.3145197448321,-56.08308043039857,0.020673056033952808,-43.712232101365224 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark12(-55.36178361583086,-73.9280445988201,0.7714693840581794,-39.84167115849522 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark12(-55.380723294781994,-42.89087914056546,-22.399433671454545,0.6567709814817473 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark12(-55.39509376926117,-73.65555951350906,-93.87941465697315,-0.9632818522720279 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark12(-55.50130735914847,-4.672778264404556,0.015605777592711645,-0.0439875462921705 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark12(-55.58569235956138,-42.483606743144065,0.01587233012634334,-55.267715044638464 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark12(-5.56123177080302,-2.5151482675956953,0.039366643767109064,0.06255524361863031 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark12(-5.574201316433431,-32.40765962037703,0.02367095248523838,-2166.8423145640472 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark12(-55.840063859837855,-58.46942166573353,0.9426924858061643,-65.2436478170926 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark12(-55.858860546687986,-75.03919688248635,0.0,-1.0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark12(-55.9832425125291,-37.91023670274248,-0.0372211806164718,-2.0025008380264604E-5 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark12(-56.02238881171551,-70.18700209597093,-0.778698567346515,-53.03741509376187 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark12(-56.039522461824006,-41.18264016811984,-0.021404858142090602,0.008380011686414963 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark12(-56.09930661751329,-77.05063165182652,0.0,1.0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark12(-56.19422827889053,-100.0,1.3877787807814457E-17,2.5442345719273125E-98 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark12(-56.357991289611334,-36.504947112080174,-55.62141169716361,0.16206801325584674 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark12(-56.37860606876545,-10.211774690903148,0.06255257752225708,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark12(-56.41464241433988,-17.230274944768244,-11.680067735776397,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark12(-56.41469411278614,-86.00913239303787,-0.02914912928158727,-27.960691665009307 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark12(-56.496505730247065,-20.59321694032451,-0.048360077152491424,-0.059359920462028065 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark12(-56.52333457962512,-99.57146587193219,-1.0,100.0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark12(-5.659047268075875,-33.88057466902209,49.559928172208686,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark12(-56.605798799006514,-70.82102921285774,-1.0,-53.20470423276647 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark12(-56.635872071213676,-48.836754348266886,0.0,0.5080655504510168 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark12(-56.70185441444664,-19.36777061045869,-0.0216642487335231,0.9000870086999129 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark12(-56.8162543242765,-100.0,-1.0,8.673617379884035E-19 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark12(-56.862445713034646,-62.92863339847909,-32.730688999267585,-1.0000000000000064 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark12(-56.90235249401645,-41.23697889810555,0.9705205035801432,10.618730715074335 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark12(-56.923836204027324,-65.06493789846954,11.400467031809669,-1.0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark12(-57.015138319612376,-23.849420659045016,1.0,-1.0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark12(-57.01724102367461,-18.803244974049885,-1.0000000000000002,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark12(-5.70407621234879,-47.663120722464846,0.0,29.42062453453443 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark12(-57.05241422200452,-33.11531412803915,1.0,-0.05405604609988196 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark12(-57.08262501032273,-64.15375261361346,-52.02538270243865,-0.026236279696408293 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark12(-57.1729245035726,-55.14497432723565,-0.8709223730555888,0.22265729631319842 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark12(-57.20875418280042,-89.81286214891213,-0.8692514748618765,-0.06743648199895702 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark12(-57.3448899628189,-7.096167922810662,-0.037511704420637094,1.0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark12(-57.395626577529754,-35.97778891576151,1.0000000000000018,16.094404803924014 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark12(-57.44144272432621,-3.2448112158843694,-0.02067391103494403,-0.03155784943149631 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark12(-57.54239151807333,-10.776150653898416,-0.042992283358794264,1.0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark12(-57.60949360624339,-83.9832517116091,-0.8859639950195934,-1.0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark12(-57.619401935600486,-75.17096240065703,-0.9156285946913424,0.6849915576030475 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark12(-57.89611432599666,-16.786311595737278,-1.7763568394002505E-15,-29.845007481849642 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark12(-57.90792542427281,-90.84229767152588,-0.048349750301998395,-0.23005707048272006 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark12(-5.790841613530141,-6.088797705954626,0.0,0.19981664765140206 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark12(-58.00385586467149,-25.969234248904158,0.6968874539814336,0.0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark12(-58.053422239861206,-91.99428116976758,-91.64649760293997,-83.70030706011241 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark12(-58.08884580733668,-95.97998724114831,0.05062825466981109,4.161346290961475 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark12(-58.24644594070257,-29.727826431081358,-58.53960087600588,-0.9604134128361725 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark12(-58.258868850272655,-3.716933276260292,-17.387200722448707,86.31098065816946 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark12(-58.41384138724817,-5.27714094816943,47.10379200991554,-0.7266564860150178 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark12(-58.584608080475945,-32.36289628230596,-0.05879235984254477,98.1756915238024 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark12(-58.70548740203948,-35.682791845778894,0.30920900152288733,-0.46528834945301967 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark12(-58.707960379132565,-55.06185466247075,-0.057691651103037075,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark12(-58.78274551779655,-100.0,77.71232635784293,-1.0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark12(-58.80579230049865,-83.58464390336995,0.013561169270365483,1.5804973423036301 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark12(-58.951657008755475,-58.57630356464628,-0.8441085177444337,-1.0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark12(-58.982959695166706,-68.38560507910822,-1.0,-0.9817173441192575 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark12(-59.13768312419876,-72.30658591347968,-0.5102176423357871,0.06662728582872601 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark12(-59.206111848367634,-96.99199700054245,-1.0,0.03318810158016672 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark12(-59.244913908662284,-88.21525888023912,0.0,1.0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark12(-59.2932902282007,-36.2044114104003,1.0,-8.008332380732404E-146 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark12(-59.34694517162181,-54.219800073963235,-0.005927299718735256,-45.74145089983675 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark12(-59.41740910301749,-13.782807023768754,74.02423556811522,-6.105506020662062 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark12(-5.942301385707966,-1.9813899834875386,-0.9999999999999929,-1.0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark12(-59.48950224586716,-45.08014976339119,22.55080693258454,-0.6081132954674626 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark12(-59.551346117676985,-71.54211244908934,18.13881539517324,-89.39998783042616 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark12(-59.58489446779138,-15.47898520859955,77.60477875876238,-1.0000000000000018 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark12(-59.641174893139265,-80.16212441131779,0.0,-1.2338789709326767E-178 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark12(-59.65585464648791,-48.48624802771518,-1.0,0.16865766988774977 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark12(-59.65854054541629,-91.0952658578847,0.9999999999999929,19.573110544196098 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark12(-59.66266315355768,-3.941154605345835,1.0,1.0587911840678754E-22 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark12(59.69727222107605,0,0,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark12(-59.7461212882806,-47.88048170643817,1.0,-0.30818090199684245 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark12(-59.848163778430155,-72.59192757771623,-54.981203173624166,1.0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark12(-59.97379080072017,-12.448355286476978,0.9395560063820838,0.24041079757888972 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark12(-60.04968857990475,-14.763938642289922,-0.05181174915480502,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark12(-6.01484220333721,-20.36151467161443,-89.84557513867463,0.0803152506925695 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark12(-60.1496529730197,-100.0,0.9813747099542155,-1.0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark12(-60.15664446369092,-42.95609275381067,1.0,0.0022537992386903105 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark12(-60.2452751850918,-35.226456306860115,-96.66040357875269,-0.9999999999999964 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark12(-60.257842254925315,-17.028071937533785,-1.0,0.056833127016328956 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark12(-60.286657680219434,-89.75339357933463,-55.17398331081995,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark12(-60.3981999795524,-100.0,1.0,0.06363104211884651 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark12(-6.042155360626126,-36.87332761166404,0.0,-1.0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark12(-6.051383776934889,-46.793208408986274,-36.790759444389664,0.0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark12(-60.56872013933327,-37.80447103474559,-0.33888049489597605,17.76477160717314 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark12(-60.640976989060576,-11.629414276432996,-1.0,-5.809351619406744 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark12(-60.68995046689107,-64.17647913189651,50.98655453899235,-0.5429760380729931 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark12(-60.76262770922219,-97.14962796103748,0.02594793595245376,-0.9999999999999986 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark12(-60.97635956476676,-1.2170068499674187,0.04176097368031545,-1.0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark12(-61.00513904305963,-57.66407528723009,0.0,49.53066345604303 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark12(-61.167010628438916,-90.20707633822315,-0.8677200988182584,82.04141434278803 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark12(-61.17106764798328,-22.455782776722884,-65.14409907819794,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark12(-61.30441367354005,61.969901556801204,0,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark12(-61.32221922993568,-31.004010550453586,-93.94484955267744,-0.942632802730941 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark12(-61.33334631010733,-50.08542672068073,0.03646179229098248,1.0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark12(-61.40714475530738,-55.90155357843887,-0.022539243943330935,1.0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark12(-61.486043850964855,-2.081521638375122,-0.9999999999999996,1.0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark12(-61.67081933013885,-94.7648513095041,0.0,73.5409772467228 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark12(-61.69292239533224,-53.447326618449615,-0.03846698807954208,66.59971900684681 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark12(-6.171844555174715,-9.591154413534625,-66.54184783865998,1.0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark12(-61.73156249296741,-28.299535136320458,-0.9699642855564664,2157.353646886633 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark12(-61.8366054373073,-68.23833231606791,-0.7656049654373067,-0.05867867898925668 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark12(-61.99956070512385,-30.154297987600344,0.4613145958060613,-8.436443892942094 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark12(-62.16447368964527,-13.69050095886755,-0.8797568701121167,-0.06262997529756074 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark12(-6.222678477058864,-82.57585291690516,0.04945556799955179,1.0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark12(-62.23591428249461,-21.658076347817868,1.1102230246251565E-16,-0.03355672203618984 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark12(-62.28570497904441,-33.52681992239618,1.0,-31.386517841901245 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark12(-62.38174076226159,-35.69894187583333,-4.3865514193193613E-4,1.4078798233654146 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark12(-62.4508325416768,-24.425825173366253,0.0,-1.0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark12(-62.561819231081735,-33.73030883184662,-1.0,-55.65060281138979 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark12(-62.565271510052675,-50.098953850137555,-1.0,33.85405309545002 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark12(-62.568003211174236,-65.5993089766992,1.0,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark12(-62.625480086489894,-83.27697009660295,0.6647199170152192,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark12(-6.2691961661039475,-42.35777395475302,-1.0,0.3622666458407628 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark12(-62.71091587982878,-28.3711436699137,-0.9999999999999979,37.05775102880504 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark12(-62.828945321124166,-39.24276334132349,1.1102230246251565E-16,-0.654648426076757 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark12(-63.00427960795224,-89.17932475283565,-1.0,2144.5819740654156 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark12(-63.13565079020107,-62.37656013173545,-0.02684232094640519,5.345529420184391E-51 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark12(-63.15279153826865,-74.80483807606318,-1.0,0.9030211782681324 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark12(-63.21678103264453,-10.710956260316067,0.0,-1.0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark12(-63.25352416286752,-28.571065661052348,-0.7781856602715033,-45.91507993225513 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark12(-63.35720089783503,-9.030012021411494,1.1102230246251565E-16,-1.0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark12(-63.49618618068501,-45.42134005467774,-0.9784460954644439,23.008245230657813 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark12(-63.65814586116059,-99.7268416353587,1.0,1.0000000000000018 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark12(-63.69379418322267,-80.14035030561305,-0.4450157001094034,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark12(-63.776486216398865,-81.56174477801443,1.0,1.000002385729039 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark12(-63.91593165560327,-50.4274736244594,0.4582488763329914,84.49668627056809 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark12(-63.970627088861335,-13.238988721313207,0.038501905127447,-0.010672774001994734 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark12(-64.17747421431176,-5.178463355689619,1.0,-0.9667162372712879 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark12(-64.23581601785851,-8.593040438013968,1.0,0.9999999999999983 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark12(-64.24161936006954,-42.76353308634189,0.049585553532153034,-28.652002189112523 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark12(-64.49661310368427,-46.97691184565358,88.23821308453773,-1.048153569093365 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark12(-64.51418213141406,-100.0,1.0,97.64449412566273 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark12(-64.57880928658004,-42.78367232331384,-1.4538544783585223,0.7069476483109535 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark12(-64.69234465866961,-9.342391642162017,-3.5154102562939826E-4,0.8276214142705959 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark12(-64.69529562939576,-75.88618079698824,-8.881784197001252E-16,2198.8639754169144 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark12(-64.71290025131417,-17.683170073276226,0.9675616719630596,-67.88836018018574 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark12(-64.73000911617854,-62.9050878785444,1.3877787807814457E-17,-6.976481057413388E-21 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark12(-64.75104143676194,-14.701634402790704,-0.2654462477608348,1.0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark12(-64.77538412942972,-21.96327569445822,1.0,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark12(-64.86598601688364,-100.0,1.0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark12(-64.86614040223472,-66.15986082394016,0,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark12(-65.04558399150238,-7.441339560780818,1.0,2336.3266849603897 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark12(-65.09105256523337,-37.938340714155316,0.0,-55.65139583362123 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark12(-65.1048170327343,-1.327148058324377,0.31543310643215583,27.189979790680212 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark12(-65.2619902199026,-27.463185295096352,0.0,0.7047700465937083 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark12(-65.4421257352171,-49.7579121129548,-0.9863615167828464,-1.0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark12(-65.47511317779706,-86.17400792833487,-27.114635811942605,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark12(-65.50481430534154,-100.0,-0.05949181695587713,-0.04533988065778777 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark12(-65.55536188327017,-95.77545683894124,-1.0,0.9999999999999998 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark12(-6.558908596793522,-100.0,1.0,-0.9999999999999982 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark12(-65.59881976841255,-100.0,-0.036349956869096894,-1.0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark12(-65.69128446098875,-11.843203041267802,0.04696187330676577,-35.22250790054562 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark12(-65.74274179697184,-100.0,0.0,-0.9947197014769342 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark12(-65.82608457839429,-32.94711603570258,0.1372251487784561,0.04889872139240614 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark12(-6.621853961917438,-50.227059234261894,0.0,1.0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark12(-66.62834335961014,-100.0,-0.037802110077678086,1.0000004133272 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark12(-66.66271163705939,-93.58898353138872,-27.415507232618808,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark12(-6.669310931539684,-86.54655475136364,-51.78173187390689,-1.0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark12(-66.70877010485817,-100.0,1.0,55.82076089385514 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark12(-6.679879511788506,-100.0,0.9161524613275205,0.01900540952027379 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark12(-66.83886310892467,-32.323599341139015,0.0,-1.0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark12(-66.86427915572628,-75.45133000640938,1.3877787807814457E-17,-92.7964399667073 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark12(-66.90045070173298,-49.248136391407826,1.0,-2192.5376851191336 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark12(-66.91311828667213,-43.183447925946126,-93.35678323381617,1.0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark12(-66.93644347279027,-45.03368266358954,32.55575754777101,-0.2908123628684809 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark12(-6.694524625421257,-79.06566831405439,-0.8686219723355441,-0.6047133305347733 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark12(-67.05643275620254,-100.0,-0.525281237273002,-1.000002464195869 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark12(-67.23201207437315,-6.6415663174486355,1.0,-11.208564047828887 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark12(-6.7347595236737465,-74.71575431076228,-0.0012686284786207758,1.0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark12(-67.37951233810642,-32.32294585085216,-0.5575435232261984,-98.16805636886635 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark12(-67.38872461696758,-29.706961578129494,-95.48070946263383,-98.8311345420573 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark12(-67.45077461988322,-66.19574292039754,-38.85862654602516,0.022608705806751277 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark12(-67.45477570043485,-92.86053492666669,-0.0615986851794669,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark12(-67.48373425444694,-12.644950347889424,1.0,-0.04828125442287501 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark12(-67.67630317630237,-59.85941707366692,0.9999999999999964,-2194.0562659338098 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark12(-67.85499278682846,-48.027690577040445,-0.9127437982348819,1.0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark12(-6.786802197628575,-35.45380112986918,0.0,0.4392080417413595 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark12(-67.9122673823957,-27.26860846852274,-0.0620190335847864,-8.012060022993664 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark12(-67.93456849331392,-37.36422721212209,-31.82178404348707,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark12(-68.0939403376357,-31.22212776491334,0.0,-1.0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark12(-6.81229706036771,-100.0,0.00140604671861011,-1.0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark12(-68.26262969305526,-14.18250616215468,1.0,-17.068058370377415 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark12(-68.2691410537134,-15.003915385159008,-1.0,-0.7501129346825793 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark12(-68.4558124256134,-1.9195440300351416,-12.913882457421586,-1.1869459682199748E-66 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark12(-68.57940317085195,-13.928602699273364,-1.0,-0.06043736623349279 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark12(-6.871630274194322,-64.61009416613888,-29.735934183045636,-16.62890361621789 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark12(-68.76701632333584,-10.245321409737642,1.0000000000000036,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark12(-69.01693843151752,-6.175431758593757,-0.17265318063930124,-1.0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark12(-69.04383788529289,-53.96880906480752,1.1102230246251565E-16,1.0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark12(-69.05865784278923,-44.98114085172451,0.0,-0.999999999999994 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark12(-69.13050606319143,-100.0,0.4756320384666586,-0.9999999999999968 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark12(-69.31978661759234,-28.911024190827206,1.0,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark12(-69.36878818564594,-60.75301902211956,-59.78645924056484,1.0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark12(-69.42714657396336,-7.997811268724917,-0.9800009165871231,0.0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark12(-6.951252716522063,-20.266699228858798,-52.309186723155676,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark12(-69.57763671424712,-73.54956228605033,0.0386586198161189,-0.9151224686652752 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark12(-69.63992914148567,-30.851059249710005,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark12(-69.68368752011547,-76.16569157118408,0.0,0.9999999999999998 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark12(-69.71395106638826,-18.073548946866957,7.841917312004083E-197,6.497131103528062E-114 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark12(-69.76278718095739,-43.10350060635108,-1.7562978928876243,-1.0000000901127604 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark12(-69.78791780303531,-12.150626551852532,1.0,-0.8580168903483073 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark12(-69.81964812393333,-1.234799523917994,-62.1631988519991,-0.36246783387987436 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark12(-70.05303540950796,-21.23652808886131,8.840005065096983,-0.569541669905277 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark12(-70.10741493965013,-93.85829490311875,-0.049261604048968205,-100.0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark12(-70.25491191336414,-34.984476082003454,1.0,-54.268126869252036 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark12(-70.30476749948922,-76.27495990256013,8.881784197001252E-16,0.8014523658100166 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark12(-70.32638802184297,-1.0000060617798912,-1.0,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark12(-70.32825896133156,-54.79228654518842,-1.0,-0.9931399162131221 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark12(-70.35521411627127,-48.32466980890468,0.0,54.20513053708913 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark12(-70.39113117421776,-68.04813033403946,-0.448163063875747,1.0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark12(-70.43227434266461,-67.74698449902746,-79.32601458250188,2464.6722792637215 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark12(-70.55443003840121,-77.28670060148096,-1.0,-1.0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark12(-70.73529454928354,-82.45835147836715,0.010132657455556965,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark12(-70.75094154266354,-66.08643005343951,0.0,-0.507891648097528 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark12(-70.8314741716241,-41.12897848135622,0.9678911781287476,-1.0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark12(-70.86114334873186,-2.4893164066805724,-1.0,-41.01115448720984 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark12(-70.98842235475232,-66.24117726697946,1.3877787807814457E-17,-0.004368031137632783 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark12(-71.05921200981732,-102.23667959422426,0.8070782984745293,-0.4535400280412025 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark12(-71.0819478443334,-35.64480185242638,51.06574780708172,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark12(-71.163040575963,-1.000000000000007,-2.7475766578039744,-0.8646264834373146 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark12(-71.24784711883413,-31.93273640918912,0.4042627760328239,49.186247862107166 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark12(-71.4419701454166,-16.002702274885177,1.9721522630525295E-31,-1.0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark12(-7.161269186247816,-85.87819975204306,0.999999999999999,-0.06072088248929766 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark12(-71.66069176221114,-61.21835412705179,-1.0,-1.0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark12(-71.66806739636183,-31.01368341014594,0.49174690293878776,1.0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark12(-7.176903956330138,-34.93312800830394,-1.0,-0.7171139907733769 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark12(-71.81068589053928,-1.4584823330412624,0.37739382771961516,-0.999779577772283 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark12(-7.190866303413028,-50.53264424820718,-0.7572942071489238,1.000087611080023 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark12(-7.1977978817586035,-90.19323045230216,1.0,1.0674992342138605 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark12(-72.04841967258717,-75.0235461596253,0.0,-0.5454459650983783 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark12(-72.23818595195613,-49.42646223921721,98.56419333750443,-1.0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark12(-7.240003229290361,-19.536233725866115,49.9928719867095,-0.06237977555439084 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark12(-72.41627551169543,-58.94954847303096,-98.03067670048509,-0.7027330736730781 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark12(-72.46219502689426,-61.25157149760685,-0.8234148393173429,-2.926047721682624E-98 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark12(-72.67308015875014,-56.18127293421588,-1.0,1.0000015539909886 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark12(-72.78444215045253,-3.950923011201827,0.0,0.8362121500499222 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark12(-72.79073183486588,-29.986910774920645,-3.061488083492179,62.65316815417904 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark12(-7.283431069461629,-20.03223584671438,-0.06137397340756866,6.553900151543473 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark12(-72.85674670324026,-63.641390726914445,-1.0,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark12(-72.8797721247031,-66.51497784734471,0.0,1.0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark12(-72.90522859488033,-14.418766075944976,0.045637925155771586,0.9269904580778171 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark12(-7.307086824738491,-57.56191391770413,-70.7815805631634,-70.45575699555368 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark12(-73.10638566109061,-22.218032033871637,1.0,79.5918078353112 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark12(-73.17162334904394,-52.598016755815536,-0.045881187135467294,2157.409794444968 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark12(-73.28049382901887,-34.228876159195,-0.5607934775557026,47.38527594834258 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark12(-73.28674596172648,-61.121331827637896,-1.0,37.0243668078797 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark12(-73.4730821220089,-24.14578227239754,0.967293603516235,-1.0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark12(-73.58501016748043,-34.29077992010827,-0.014997440066388867,-1.0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark12(-73.62793305085238,-39.92771564620216,-1.0,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark12(-73.64141493135213,-76.41362412561104,-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark12(-7.364551236689369,-94.00168275651053,0.5656669183097878,1.0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark12(-73.6909664411995,-12.32273853385387,1.0,-1.0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark12(-73.75599661585063,-41.65070344271524,0.0,0.5898087274541841 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark12(-73.93192016405158,-78.31251520290319,45.15652453777352,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark12(-73.96072669454615,-28.135970969677402,-1.0,-1.0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark12(-7.398003757397882,-5.807839128739286,0.712131312204882,38.699588499569835 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark12(-74.00671140029571,-13.985015524267988,0.026134509755096715,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark12(-74.00701811014534,-71.54189169987447,-2468.415051975425,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark12(-74.10094326697964,-66.12380548101908,56.001380753208565,-26.65737969465269 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark12(-7.418818853474079,-39.47735475192056,-18.157748254492304,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark12(-74.50640077241569,-74.400508172484,0.02996995521633017,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark12(-74.6936238694274,-99.54944741757443,1.0,0.8056350979247912 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark12(-7.47157482943753,-74.03881387655458,-1.0,-1.0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark12(-74.95162383649445,0,0,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark12(-75.02409455994132,-46.621108079919345,-0.9999999999999998,5.482993652590712 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark12(-75.05886440575492,-87.65392389941893,-7.761383236206939,82.25765111912247 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark12(-75.2249717492056,-54.45873758848704,-1.0,-0.0428107901107469 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark12(-75.24277045127124,-41.073894350303036,1.0,-31.49988385594809 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark12(-75.30055542345293,-17.727606074157947,-31.22144061911574,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark12(-75.34229972071947,-7.014178229917674,0.018007993353333814,70.74913330697319 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark12(-75.45142718514727,-27.40645592915432,0.9999999999999999,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark12(-75.56592122329666,-9.440740686585327,0.03370788570682043,-0.4824137444242409 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark12(-75.58196379322719,-100.0,2.220446049250313E-16,0.9916633767271886 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark12(-75.58615143763863,-36.63648748275058,-0.02172312946107713,22.10335734587016 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark12(-75.74059598510536,-87.21927180098606,1.0,2228.9635643671795 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark12(-75.91378463832608,-53.67214211776134,2.7755575615628914E-17,1.0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark12(-75.92074272414644,-15.10885398067779,9.424682112287815,-1.0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark12(-76.08270022207425,-100.0,0.6248892986735403,0.3620892773038248 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark12(-76.24282607976541,-30.67628607471262,-1.0,-60.47380891990479 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark12(-76.3650529419406,-27.771362316526222,1.0,25.772600702941943 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark12(-76.42235569759674,-1.8232301409802592,-1.0,-0.023682543121661848 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark12(-76.85675750136127,-47.67899336963383,1.0,-0.6908078574494513 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark12(-76.98952648632091,-4.875977492390818,0.2265914506545914,31.136793357822146 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark12(-76.9975000902624,-94.02345534426256,-0.9999891218736532,0.025226595323848147 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark12(-77.02065155106567,-52.172977854216185,-95.89129292404193,1.0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark12(-77.1108017074087,-24.252618322344418,-94.11875953074924,-1.0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark12(-77.20016167798323,-100.0,-1.0,1.0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark12(-77.20545923153672,-74.51933101635929,-1.0,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark12(-77.25161221091562,-12.527993461184494,-98.00993292760394,-0.47061040266467735 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark12(-7.728031269966965,-26.27888658944643,-1.0,0.016259819766944024 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark12(-7.763184603647614,-100.0,-1.0,32.27850540124862 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark12(-77.65869731998694,-1.000000000000007,0.05803649056384197,-48.10017987055807 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark12(-77.73524116892634,-47.267030808494546,1.0,-0.9744845743065944 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark12(-77.74183810433578,-60.82814797672652,-0.9551834389014704,-0.012679517125076228 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark12(-77.81625361853581,-59.3367090088352,0.0,-0.060703051397993174 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark12(-77.97641880966759,-18.19120098368745,0.0,-1.0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark12(-78.02774591760047,-49.44163323372268,-0.8018878031934715,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark12(-78.24115258088692,-20.17809046729535,-0.9784179873117544,1.0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark12(-78.2944791952226,-36.277805758108045,0.9943584093795762,1.0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark12(-78.51643189326487,-85.1356716887154,-12.905691323802841,7.198888935572171 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark12(-78.54424635916453,-48.04798492237048,0.0039954882995754115,0.05028056001124703 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark12(-78.57695640279876,-98.34750309152223,1.0,1.0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark12(-7.868610288331789,-11.29920597372537,-0.7400065694304154,4.440892098500626E-16 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark12(-78.75253810269898,-48.443573639180485,1.7763568394002505E-15,0.8995862881922226 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark12(-78.93858254649857,-100.0,0.005813163681718531,-30.71623274891461 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark12(-79.12141548151887,-7.42664819771813,-0.04381963866471192,-0.010779067659354588 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark12(-79.121450500212,-52.711358756262484,-1.0,1.0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark12(-79.30297964673858,-46.23331046136256,-1.0,-1.0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark12(-79.407460951278,-35.26205825671293,1.716618774498187,-14.170775949355402 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark12(-79.42014415960386,-2.3594997506205977,0.8914260182389673,1.0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark12(-79.57106309071251,-5.015094274493296,8.423761999497944E-4,-0.9648214927407783 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark12(-79.59214583874409,-2.4142232362205984,0.0,-0.287255470289014 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark12(-7.970529783912468,-41.11114656867658,1.0,-59.98984974511692 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark12(-79.80183010639175,-68.51663823952548,80.95071969951567,-91.52365716526953 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark12(-79.82946034125271,-19.53613000894508,28.80819523213279,-1.0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark12(-80.04198044841633,-39.72590667189483,1.3877787807814457E-17,-0.4759506949848927 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark12(-80.06148110869866,-82.26257996928047,-44.12153309704121,2257.8224008322422 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark12(-80.1023617383589,-18.052843857003282,-1.7763568394002505E-15,-14.923604426563756 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark12(-80.11425253530494,-33.560267289919985,0.2544926138080816,0.013856436847570174 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark12(-80.22404755928581,-19.232593523479302,-77.4955888633869,-1.0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark12(-80.24646485685254,-80.43981633766771,-88.64955896038671,1.0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark12(-80.25098688399262,-1.0000000000000142,0.9464843357677187,0.06255942464945151 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark12(-80.32314201140004,-61.82090031398949,-1.1102230246251565E-16,-1.0000000000000009 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark12(-80.5974449170134,-83.63654278739585,4.440892098500626E-16,-17.192577744571068 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark12(-80.68292331651718,-65.08973897669121,1.1102230246251565E-16,24.686251580042196 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark12(-80.71086996082968,-8.867563555541949,-91.35089114864581,-1.0008906282087722 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark12(-80.82117361370123,-66.91868280344826,0.0,62.44587391324691 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark12(-80.97601086830515,-67.57306687369082,-0.9942146665460027,0.9555768996118593 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark12(-81.02169962614894,-44.15832312526643,0.01873918644446208,0.019917247419738115 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark12(-81.07142165147528,-24.728210176189602,0.0,0.015932482540710932 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark12(-81.148811889214,-47.89818140010971,-2.7755575615628914E-17,-0.02410827262248793 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark12(-81.22688068944588,-58.01830173843662,0.6236684618704036,0.19256439537723224 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark12(-81.24567966457472,-89.15460347710042,-94.7519340253149,-56.18036798548789 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark12(-81.34277850238938,-9.710989324458875,0.01843101937396563,-1.0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark12(-81.57965236627341,-77.19439091594715,8.48371919627698,-18.31741684523331 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark12(-81.61224694982205,-99.39968836186053,48.08721925420082,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark12(-81.96294732458182,-31.84620389341424,1.0,-41.597508763148916 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark12(-81.96886946751714,-32.857561438458596,-64.81449233273061,1.0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark12(-82.00746061243484,-26.312293240558024,-0.024637726617196383,16.266657665188248 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark12(-82.06815561483786,-53.45768404412577,-0.016817861371714246,-86.49521139446625 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark12(-8.214724033056129,-11.063395260579004,1.0,1.0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark12(-82.22468362571125,-78.63349356886279,-0.9994903401219392,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark12(-82.26267009229176,-30.457690467049247,-0.9999999999999996,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark12(-8.24078050324297,-11.322048636905487,-0.05102852580400752,1.0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark12(-8.24485120448438,-11.88450038968982,-83.0188342595039,0.9999999999999999 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark12(-82.89575364009103,-2.138293393935058,-98.79910145491917,-78.73668186037571 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark12(-8.292790448866796,-74.81998168341602,0.0,-0.4446470115092631 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark12(-83.04839275701903,-87.97753467632359,-12.877647911581661,-82.10867063895162 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark12(-83.13895278840646,-52.67860423183362,-81.3840745076738,-0.26082691750267495 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark12(-83.16313308709115,-100.0,0.06119923545018757,0.9999999999999964 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark12(-83.26292901913945,-17.51948647660801,-83.01487523516806,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark12(-83.27918868829241,-1.8732768506652193,-1.0,-1.0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark12(-8.33213041641556,-99.06476234008561,1.0,-0.17967938084929846 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark12(-83.37369374968864,-45.003831910275316,0.0,-45.156085127870114 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark12(-83.44631912849484,-100.0,-1.0,-51.41458838317701 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark12(-83.58885071732225,-20.651025037111708,-59.21035100423904,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark12(-83.59826647760886,-17.782376899701234,16.5425194484681,-65.21067654533678 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark12(-83.70268400925676,-93.03796914160944,-1.0,-0.805670058102848 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark12(-83.75447675969055,-64.5765168813463,-73.15034415679622,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark12(-83.80995628013802,-100.0,-0.011469215339717898,0.9969837168738203 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark12(-83.84745303374403,-15.701042804935582,1.0,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark12(-83.9593927587309,-21.56850718578508,-0.9999999999999982,1.047597699533044 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark12(-8.40525600078935,-70.03543631727995,-1.0,-1.0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark12(-84.0845067522046,-71.83340163164178,-0.9768361504618365,-0.5783437473111004 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark12(-84.18486395974564,-61.621029368436105,0.0027578296636629474,2.279543821230474 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark12(-84.21134464836062,-38.95443841132986,-61.527925726201985,-71.27354129601022 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark12(-84.27663547667014,-50.11637220405948,1.0,-23.573650853864365 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark12(-84.32644297461766,-4.076413695712096,-1.0,-64.45573486241594 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark12(-84.32968211829444,-39.761030500361194,1.0,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark12(-8.433707026422642,-1.0000000000000018,1.0,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark12(-84.35303496709156,-9.35924666407489,1.0,1.0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark12(-84.35788263673035,-100.0,-24.798584541825768,-0.021302129174902998 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark12(-84.41539972862734,-75.82792580412986,-1.0,-1.0000000004464615 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark12(-84.43003117531964,-84.08474399730548,47.968761532766166,-8.838975978582184 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark12(-84.53469716676443,-100.0,0.001971703627957605,1.0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark12(-84.53747000575855,-100.0,-0.8177950382308768,-1.0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark12(-84.58479570080041,-7.402245140826494,0.9865890408513068,-1.0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark12(-84.68360301411792,-100.0,-0.8947534852570415,0.9456745853877185 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark12(-84.68671317212443,-88.55279821924049,-17.763782114662025,1.0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark12(-85.10253050250142,-68.73947263869977,1.7763568394002505E-15,0.0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark12(-85.10435598544709,-25.729697142334402,-1.1102230246251565E-16,1.0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark12(-85.13990491129593,-59.027360260723945,0.0,19.592861386510215 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark12(-85.1450472365961,-12.365088779206197,-0.34105935543689236,-1.0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark12(-85.18142983015117,-69.01228409707119,-7.208276610179837,0.718975530974177 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark12(-85.36057924826173,-32.85490297599918,0.0,1.0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark12(-85.5041636153039,-99.96351628019882,-0.9269883403108711,-1.0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark12(-8.551745860920558,-11.827937657635239,1.0,41.24597561570208 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark12(-85.68627614786341,-1.2012001456711172,-29.433021465517314,0.9807588738489005 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark12(-85.82188720747828,-63.787613611475095,0.9537486588915063,0.9993749627326604 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark12(-85.91775577466917,-4.974309558089177,1.3877787807814457E-17,-1.0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark12(-85.96267433373649,-60.66413699734435,0.9300901858261061,-1.000049022775001 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark12(-86.03680714485776,-4.923700741563977,0.8873174005818862,-0.5608369803560115 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark12(-8.615192905420813,-55.84884348354151,0,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark12(-86.17639539772415,-13.051403342153366,-8.881784197001252E-16,5.255525237718142 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark12(-86.19758053251336,-56.37074991601693,-1.0,-0.04135263911331586 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark12(-86.38845431988672,-89.4935660205527,-83.32597639654433,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark12(-86.42951010647039,-79.27763075478653,-1.0,65.65648908321816 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark12(-86.53679487197891,-29.987139561619188,73.91627233656166,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark12(-8.663534884514894,-100.0,-1.0,-0.06255286478235636 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark12(-8.669121873376273,-89.4513786488353,0.05327768490836519,-1.0000019110484564 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark12(-86.83829262726151,-92.9691184703132,1.0,-89.34502966460246 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark12(-86.92254243194837,-1.9382184928611998,-5.989975760051882E-16,56.32239995467606 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark12(-86.94469483540566,-6.862783855521833,10.145754424528,-0.9302356106215556 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark12(-86.96711990072367,-85.11685640627773,-1.0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark12(-87.00221862490356,-69.05435432691883,-74.00876748263818,0.0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark12(-8.70795201781799,-20.118677499679315,0.7093735341292822,-1.0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark12(-87.09064990672282,-93.58865731603832,0.9783351070167602,-0.0024212402622741103 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark12(-87.09747682741286,-62.36314029777385,-1.0,-1.0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark12(-87.09988826419566,-7.224915702298185,1.0,5.140168039952584 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark12(-87.17391389809471,-42.85143109927057,-1.0,0.3377582826779031 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark12(-87.26484842977638,-4.387995951182699,-89.1037171094925,-1.0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark12(-87.29773154091008,-49.98885680988852,0.00703521860211714,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark12(-8.730609262165117,-93.50791553795985,1.0,-1.0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark12(-8.741840134650495,-34.43560236723624,-0.8411834894474551,-5.469353296390906 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark12(-87.58139309529349,-61.354394703719834,-0.04734439568618473,0.9890081439001974 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark12(-87.79951249995088,-21.949959593919715,-0.010187996156534762,-1.0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark12(-88.11605578421046,-93.59405112676477,-3.469446951953614E-18,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark12(-88.27343071891823,-100.0,0.0,-0.6807175450437141 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark12(-88.36195128761202,-17.285649753998,-4.440892098500626E-16,0.8751866425888579 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark12(-88.37002558897318,-47.364170537993374,-1.0,56.616914236971894 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark12(-88.37549933897185,-7.391512280415657,-0.7879212117405261,0.999127004682274 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark12(-88.38661228003434,-61.39365126789424,1.0,-45.3206307727445 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark12(-88.49764204063261,-79.50021583524733,23.52297480008626,-0.05802637827446411 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark12(-88.5259526357967,-11.624627832558279,0.005377954936997692,0.8725302927744047 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark12(-88.58235378814497,-119.41774526719436,0.5689180802929363,2195.5830132459437 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark12(-88.62158477243455,-100.0,-100.0,-3.0123370099194837E-6 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark12(-88.67603912648349,-87.41687887053018,0.9548058860958853,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark12(-88.69681223271587,-96.02258138332584,33.25261071446149,-0.9999999999999999 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark12(-88.77666824397771,-32.18841066465229,0.05625711816601584,-12.95785472437901 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark12(-8.883025790159934,-25.068025338881313,22.734607703059282,-79.40471931512542 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark12(-89.35586965524148,-78.98672072717855,0.05358713774684484,1.0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark12(-89.48379560618528,-31.39296082472685,-1.0,-1.105878686366509 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark12(-89.66979602473741,-106.49866435294011,25.750880612685194,-2319.2065900476236 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark12(-89.67615721455348,-69.93287727084795,-0.012410885360245427,-42.29158102488391 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark12(-89.75150203113019,-16.361337070804723,0.6981304125826866,-0.5468538663852573 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark12(-89.7604189368297,-2.1166079138180294,0.2521596249013907,-0.04715328477615746 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark12(-89.76060624565866,-51.19125869174886,-1.0,74.43889617884344 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark12(-89.7671093476867,-87.73370527844492,-0.9739927225026949,-2047.083667913449 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark12(-89.84847173806034,-6.843162381447939,-64.2521085264935,1.0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark12(-89.88749719290547,-24.554444619472136,-0.01136623129690087,-60.275920345168934 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark12(-89.93305510255625,-75.08567532735115,-8.881784197001252E-16,0.8970082199441246 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark12(-89.98471024720769,-79.57495116848895,-0.20611415057605953,53.776958194736714 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark12(-90.11945439159669,-99.9897272059113,-0.015144439072323013,100.0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark12(-90.12310032317231,-3.7089504514377296,0.8204312485022635,55.735946044818235 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark12(-9.019336389055306,-38.67890795518061,-1.0,92.82358361881121 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark12(-90.20442045640178,-36.01598720072268,0.0,1.734723475976807E-18 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark12(-9.024568686739327,-1.839123518458181,0.035844533579452276,-0.8633693250176862 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark12(-9.054965753764478,-68.36068399578548,0.0,-1.0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark12(-9.059485908822843,-38.36372466240408,-0.8654690148108273,-0.786766167189672 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark12(-90.71914783305955,-5.7942479327040655,-1.0,10.452137980419705 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark12(-90.84049812809675,-74.09452995997296,0.0,0.06255253663113237 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark12(-90.93582266069284,-17.368152390813112,1.0,69.52322582800295 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark12(-91.10457992733203,-8.048271656209014,59.422536718175834,-1.0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark12(-91.19921667867219,-12.66824067057161,-1.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark12(-91.25900021618145,-70.7364381122515,0.0,82.60876401040925 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark12(-91.45155552750319,-48.80429764168226,0.7548458713057418,53.65544135333212 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark12(-91.55914015097125,-45.14552190369002,-33.856707657654056,-0.02624802001512308 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark12(-91.61146495220156,-100.0,0.05805187965844605,100.0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark12(-91.6435616456287,-1.0000000000000022,0.8190314082188659,-73.86531073121932 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark12(-91.73442202963172,-66.94547517912883,26.895110943796155,-99.06144866022841 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark12(-91.9119933324678,-1.0000000000000004,-0.9954292121448833,1.000006287296548 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark12(-92.07912572914842,-100.0,1.1102230246251565E-16,1.0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark12(-9.216670109193103,-19.062806520588513,-0.9806651799783137,8.605928398378595 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark12(-92.22958911468446,-97.19905747525823,3.552713678800501E-15,-26.0562196728535 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark12(-92.23189773569662,-75.6901686611638,0.9474377952031849,-1.0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark12(-9.227394273091107,-53.24458833824802,85.38056796629797,-0.01936744744019459 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark12(-92.29657674254767,-100.0,-1.1102230246251565E-16,-1.0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark12(-92.46752774598728,-77.50119706776744,-1.0,68.21690589721076 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark12(-92.50447521976668,-21.963441809903728,84.247778993987,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark12(-92.5997804753891,-95.3908671839653,-0.6496625439966943,1.0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark12(-92.616126426162,-16.001386072831796,-0.973383263213945,23.101931004092016 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark12(-92.70977984509955,-36.67634080284329,-5.551115123125783E-17,0.14411214247762705 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark12(-92.75938601652803,-86.51606885117575,1.0,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark12(-92.86571806981816,-76.64081748601988,0.0,-0.06255323601824525 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark12(-92.98509993536683,-1.6665503181395116,1.0,-0.059532675812900115 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark12(-93.13050547281823,-12.886327258709722,0.04289109693357407,1.0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark12(-93.35383243733875,-50.29824388865326,1.0,100.0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark12(-93.46140511649344,-10.332572055462293,-68.97643628709496,3.759253443195078 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark12(-93.47559402845425,-52.67678972908616,0.0035299391672367697,1.0000019575205905 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark12(-93.54497480679423,-23.18410449455186,-0.9999999999999929,-38.44796528896306 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark12(-93.59217178084867,-73.8196117460065,-100.0,0.016652141208278244 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark12(-93.79043176660048,-100.0,-0.9577460145628492,-0.9314512920760811 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark12(-93.86291608281735,-6.14065113796218,-0.05945353764651434,1.0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark12(-93.97307844343214,-28.985581647098286,-1.0,0.7018790339332287 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark12(-94.09484619555434,-94.35608262374006,1.0,-0.5414077100251036 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark12(-94.50106663746074,-39.321937461456045,1.7763568394002505E-15,-1.0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark12(-94.54878589915434,-39.873880943373024,4.440892098500626E-16,0.36250681633144954 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark12(-94.69020765149943,-65.24377874193753,0.0,-10.254659347390769 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark12(-95.0417786341612,-59.16792190441713,79.27982444435341,-0.5116236583287055 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark12(-95.04522233845172,-50.187963281337744,-18.059896828976576,-0.654160589923281 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark12(-95.14014341850405,-43.020724747613805,-0.11848618959794667,1.0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark12(-95.18906097322338,-53.49820934609766,-40.90423863516679,13.377019879941443 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark12(-95.27031417793368,-87.97542976863252,1.0,0.27575167593968686 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark12(-95.28391962439471,-65.55311411064068,0.9999999999999991,1.0000000000000002 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark12(-95.35176908195673,-75.44264152452378,0.022603526128154416,100.0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark12(-95.38424379935826,-77.86502878965268,0.0,0.7887644567396279 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark12(-95.42197647623567,-94.78419931667975,-0.892342789877554,0.7906352474548815 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark12(-95.47843688427321,-66.79017826427886,98.40624033811508,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark12(-95.48845855660555,-2.4471267015843576,0.05467765629321486,1.0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark12(-95.51736876774841,-69.0106601872782,0.043425613660045506,1.0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark12(-95.53387504391365,-8.984099503667839,0.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark12(-95.54458631691219,-81.08380552087874,0.0,99.78291181997864 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark12(-95.57629609926407,-64.42947736178442,-0.8431554354092079,-57.431366395663105 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark12(-95.65240344610552,-26.41495477343294,-29.810368995650904,-9.888549644489459 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark12(-95.73480713332452,-97.1287087609658,-0.3053625154592833,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark12(-95.80418673868832,-75.91583309605855,-2.1097695787700155E-4,83.4742507466974 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark12(-95.81829673526096,-96.19103710843574,-1.0,-0.37427704080556967 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark12(-95.91369354913901,-34.040397856197146,14.542912250681738,-18.98159829620421 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark12(-95.9312719910319,-21.472630604747515,0.4084227756056895,1.0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark12(-96.03182463995232,-76.7259105324574,-1.0,-0.5983645453544142 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark12(-96.03337502601958,-90.47147368396071,0.05544071064336942,17.368980392670505 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark12(-96.05617775979394,-36.161217399079874,0.023933195650129913,5.030866435730758 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark12(-96.2412599516161,-83.32262191071418,33.83889112979111,-92.87545007731019 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark12(-96.29159561563804,-52.11746844533942,-1.0,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark12(-9.643918234084197,-59.15271488071523,-5.027688086357912,96.61661130820636 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark12(-9.647216266428924,-14.792623623905278,-0.24313314223189442,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark12(-9.65008727275939,-93.37651322333603,0.9999999999999929,1.0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark12(-96.71063843440399,-1.5511106861338018,0.9982342444238648,-1.0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark12(-96.82325329209388,-100.0,0.0,-75.24402131996412 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark12(-96.83258283204167,-68.74210320176591,-0.05849473138899129,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark12(-96.84316429424766,-99.12379528261386,-8.256549322473532,1.0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark12(-96.88292242427751,-46.455238801091156,0.0,-5.867030527434087 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark12(-97.24027502790717,-69.62721043933487,0.0,1.0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark12(-97.2751270716658,-34.806528625415154,-24.868708859524702,-84.3033195118796 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark12(-97.31581815027643,-78.28764978321986,-5.556420024728513,1.0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark12(97.31986150870534,0,0,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark12(-97.32536253335462,-83.7559397925867,-74.47788438919203,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark12(-97.36133485453087,-48.78601062970293,0.0567269425935093,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark12(-97.3725947072497,-3.374050037854529,-1.0,0.0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark12(-97.77585681529419,-86.4671522318756,1.0,1.0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark12(-97.82356444024073,-53.88699845671977,1.0,-1.0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark12(-97.85139993698319,-1.5055951325734895,-7.582673118209172,-2473.6610582760713 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark12(-97.89438982742097,-38.463788934574474,-0.5088526114851448,24.60698061117594 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark12(-97.99762598178975,-38.26249961009061,2.0220884151597995E-15,1.0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark12(-98.02435613040569,-100.0,-0.10146068045609424,0.050644313318052636 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark12(-98.04774081268755,-80.17556754075832,1.3877787807814457E-17,0.0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark12(-98.06849438110088,-16.20593292104364,1.0,0.9999999999999996 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark12(-9.815347500172209,-40.590062780483905,0.0,87.93880128538146 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark12(-98.17809824823411,-87.16365943180693,54.28219714467006,-0.9110390051565389 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark12(-98.26264848402847,-86.3635932466111,0.1714943155065345,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark12(-98.32952729479392,-34.83937252322377,-0.03176997202869891,-1.0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark12(-98.44974883520729,-100.0,-0.013949642424288727,-0.9999778898348676 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark12(-98.47036351796419,-45.55101221885364,1.1102230246251565E-16,-2048.156987014521 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark12(-98.70021071766384,-13.406429652155879,1.0,85.83064509654105 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark12(-98.73691583677034,-84.98925596510752,-1.0,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark12(-98.76040779353733,-80.95378382885949,-1.0,1.0971416141005648 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark12(-98.76404355179062,-12.647079813960218,-0.06286094674188265,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark12(-98.80193208524783,-13.41658689350266,0.850829444180165,5.2710989716152616E-82 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark12(-98.99952237000923,-95.1773907298558,0.03502153185185369,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark12(-99.19057103897961,-3.5137649432086304,0.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark12(-99.1959146205347,-98.88302553056036,-1.0,0.036276621537629346 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark12(-99.19915433829574,-100.0,0.0,-1.0000000359645775 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark12(-99.31294862312703,-8.754580714146137,1.0,0.7744175104851487 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark12(-99.3421654292259,-98.82314556701252,99.31702272075943,-1.1704190886730496E-97 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark12(-99.45337054743321,-72.6479912069201,1.0,1.0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark12(-99.46088704637408,-70.61663709981613,5.551115123125783E-17,1.4661930788384634 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark12(-99.4637436318012,-4.465518047333088,0.8718222981205253,0.8318101130685106 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark12(-99.50015920811278,-1.0,0,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark12(-99.52234385823104,-4.735494172880814,1.0,-0.970997880135127 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark12(-99.5666672956499,-77.43575775659386,0.0,0.0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark12(-99.60500435224604,-2.1250352553460172,-1.0,1.1170523693426697E-8 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark12(-99.63149029972097,-1.904987167196548,1.0,-36.76839905484017 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark12(-99.70995715383607,-8.240054742402686,3.939675283809386,-0.02683752695762511 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark12(-99.80122574581036,-98.89477922766436,0.0,1.0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark12(-99.92109258208413,-10.973681138579764,-0.033376410005710566,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark12(-99.92643159533216,-98.98215021833126,-1.000000000000007,1.0000610726186046 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark12(-99.93296205514879,-100.0,0.7448447765422685,96.48621115176591 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark12(-99.96591248543717,-100.0,0.041147266073847374,39.33089927078313 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark12(-99.97807095682765,-1.0899009344022534,0.5118050980389568,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark12(-99.98656753031835,-93.98904458329191,-0.15900283973347484,64.48461597302318 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark12(-99.99866121196317,-100.0,0.05906348547613929,-0.9688064757869352 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark12(-99.99999998983901,-44.821151579351955,0.9369053246440092,100.0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark12(-99.99999999999999,-64.57828014165194,-1.788596110345509E-15,-1.0 ) ;
  }
}
