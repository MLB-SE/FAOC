import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,0.0,-0.012920943474155736,-0.029783346102829882,52.74076060398218 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.005393963826797327,87.82597888909547,-44.62373909662898 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.006305778600610792,74.48366139739338,-0.02108913951496305 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.0116490908963518,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.01921416257829413,290.1982547133509,-100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.022746431709419028,-9.441543296243236,77.53191720358237 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.025002323952104673,-100.0,69.71223478318987 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.02504923509404222,0.34417373682107044,-4.5639633671744235 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.028274252603551986,-79.83062230999289,8.224950590776928 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.033634639585521764,-6.317460331175304E-176,2.3970182335951E-94 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.03568053518625547,100.0,-5.048092025321111 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.03978256011626202,33.117010560437585,-80.00490373099642 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.0498757439245065,5.186432137517599,60.04449421181593 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.05052401508464244,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.05373260119748664,46.02540247446038,-100.0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.056475500183453264,-100.0,22.714048791093404 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.058502318741872,7.229404429298121,-74.20291119149763 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.05885461714874329,-1170.8564703022857,1200.9131529316574 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.06089479745505867,1.4210854715202004E-14,0.005431999275871235 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.06208695446670165,88.75795631433533,-100.0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark56(0,0.0,-1.1102230246251565E-16,-0.0767922507362484,20.248308330842875 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark56(0.001919185401392884,-94.7582451264524,-0.022771821087757105,0.07076495115471826,-22.197377390405556 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.3423062313216908,1184.7064522796716,-1146.2450430040697 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark56(0.003629381036377236,-100.0,-0.017100239143672927,-7.933507680650711,1.3052018401293841 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark56(-0.007254241631692082,-20.92107047154034,-0.019663880662374303,-28.10937739480195,0.012294694610653729 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.7584325498338131,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.9556990371670563,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark56(0.012008572114168043,-35.477735865774434,-0.04805858112384512,36.304507324844934,-49.25175590948763 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.232595164407831E-32,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.235264856234508,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark56(-0.0155978505760879,-52.95655795653955,-0.0044356280080195265,37.860021202969705,-100.0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.7763568394002505E-15,37.35083274825044,-75.1462235015858 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.7763568394002505E-15,55.47226976294834,-91.9912708333051 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark56(0.018140495295021708,-73.27149897118831,-0.051521441391492846,-0.016274462098418513,96.51909336808808 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark56(0.01818916435357396,100.0,-0.018932874439427032,0.5913643008235608,-2.6562244704445845 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1841.1779249861404,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark56(0.020069420843783492,55.91941266295041,-0.025389414912380143,-0.014752570836178897,32.28956435581267 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark56(0,0,2.1684043449710089E-19,0,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-2.220446049250313E-16,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-23.974236678652616,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark56(-0.024447389134749642,26.96149978815445,-0.05099119479298922,18.427138064253,-0.08524364018534712 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-2.771121600359559E-4,0.0,-88.9889384099644 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark56(0,0,3.3474935336011953,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark56(0,0.37137742232260607,-0.03384330493480978,32.897089205621086,-18.46411389881558 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark56(0,0,37.410571407651844,56.5534261082629,90.83745714699992 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-45.38351237089757,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark56(0,-0.4811806304757442,-0.025118198671581368,-8.340592393583286,6.769796066788388 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-4.819378408065205,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark56(-0.04855610094409357,-99.99999999982785,-1.3877787807814457E-17,-0.09150018452954978,17.167138349186615 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark56(0.05209998597050958,-9.339738116303877,-1.1102230246251565E-16,-0.018612816162230504,84.39326500104738 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-5.551115123125783E-17,-31.76601625994647,2.220446049250313E-16 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark56(0,-0.5635756993153791,-1.1102230246251565E-16,-0.02943638357943007,53.362408549824536 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark56(-0.07296875341049495,6.859827545298387,-2.6670478237521966E-16,2.220446049250313E-16,-6.738733183534938 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark56(0.07459962421139978,-7.190668488856946,-0.019335903126854872,-10.034785600552937,0.15650916983942834 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark56(0.08309331391975583,-99.99999999999847,-0.030783487530312625,0.7228676398702045,-2.173006841303538 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-84.71841532731881,0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-875.7703555842348,0,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-88.0092270334109,43.97679119565717,86.97481134938525 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-8.881784197001252E-16,-1.5938572274455118,0.9855313887257172 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark56(-0.08965423853375493,-12.784658563916302,-0.043183430195375246,0.5124824165886596,-2.767885230141266 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.0013860609798189358,-20.150289060826182,21.72108538762108 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.0017210252868785551,-0.09224578406114593,10.71967955095188 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.005694473943349137,88.95831257415789,-88.96091386724784 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.006702341980449552,1.2889166366597729,0.28187969013512393 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.007206428179441948,-0.017270851383087482,27.809655002329297 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.010795225526682044,45.08629672298167,-61.67401808481283 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.012123792684931096,-100.0,99.68451875025616 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.0173729636182869,-0.021265480626339928,6.23365446101103 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.0188675664697201,13.058197620088716,-96.04215936581963 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.02280137157500181,-68.18032451004896,63.55581707127083 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.02316779255913494,-3.185561778234522,0.4930986859295672 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.026410920436762162,-5.950263336172488,12.232647231889999 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.029021777360481615,27.93930129267838,-100.0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.029106691676561356,0.6749984271327132,-0.6749984271327133 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.03200239599141416,94.76829811272212,1.0502343355642085 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.032130598273965846,5.05076335230562,-0.3110017669067478 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.03243380778563308,0.04502618548813227,-1.6158458765436474 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.03317123208613412,1.7669807272105733,-2.3377176359071283 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.03527237182998744,-70.55710160346581,3.968497519577838 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.03551296265661101,99.50026016978491,-100.0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.035616353508736355,57.34369452329537,-63.83731407654244 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.041722935797710414,0.07607101537878594,-1.918184036131778 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.04181901626736284,9.159857941108399,-0.17148697467734098 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.046189193340555795,21.174663347951988,-44.67148633726396 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.04698901427212332,0.871599839871474,-2.4423961666663705 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.04875197855880678,1.414474642410509,0.15632168438438754 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.049630095842080696,-14.049732257754666,12.478935930959771 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.05150511462984285,-0.024654062806362342,63.713487676746304 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.052223422712300724,-6.333063279085228,7.833060380032819 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.05456391413453175,31.19403991918739,-29.62324359239249 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.055255602846008695,-72.37709523798775,67.15696189359747 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.055666255147452104,-100.0,0.015707963267948877 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.05576357858926822,30.762728838198157,-0.051061670603306 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.060957388941077856,-1.2850142622140046,1.2223960254639556 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.06214134677465921,-0.6821222277804084,2.30280771219872 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.08684684684857275,-1.274119775852369,2.8449161026472654 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.5331721774836985,5.068052481842023,-3.5680524818420225 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.5989617403386175,19.770714996057382,-8.775160014768794 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.999851105897878,-6.548479681069322,8.119276007864219 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0538564358907998E-9,-99.99899168369302,98.55524270347877 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.1102230246251565E-16,-100.0,98.5 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.1102230246251565E-16,-30.230426862603338,47.509076399837056 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.1102230246251565E-16,48.517023269601914,-50.06385778429361 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.1102230246251565E-16,66.79264765986116,-0.8899982612703852 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.1102230246251565E-16,71.51715451087301,-0.021963909743583962 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.2199231209592587E-9,3.5974628617321076,19.964482040191342 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.3877787807814457E-17,-0.2497890846818136,6.288490663216164 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.3877787807814457E-17,-0.47199292541906057,2.90501217793485 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.3877787807814457E-17,-0.7248374796441122,2.2956338064390067 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.533788767824616E-16,10.227242608278766,-11.798038935073663 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.7763568394002505E-15,-0.0019273005713902418,0.0019273005713902416 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.7763568394002505E-15,4.548977808622001E-13,-61.22258118676038 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.865198878683341E-16,15.225885992409857,-16.725885992409857 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-2.662324730438976E-17,-10.791628572837448,9.22083224604255 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-2.7755575615628914E-17,-4.105742737971553,0.3825851805734146 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-2.7755575615628914E-17,4.548603295768785,-6.119399622563683 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-3.469446951953614E-18,-15.962732998657753,15.962732992812791 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-5.551115123125783E-17,10.788828958439504,-10.789783354193512 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-5.551115123125783E-17,99.99999997519623,-100.0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-6.938893903907228E-18,100.0,-1.0398363870156528 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark56(0,-103.2502351522261,-0.02495977536885799,-19.11507844975707,20.685874723972777 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark56(0,106.27958698666863,-4.440892098500626E-16,-4.253624393245516,0.02606632528542305 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark56(0,-10.733851235118763,-0.053107318814951385,44.45548990045543,-0.03533413601587121 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark56(0,107.4390417113847,-0.05831666745429037,-0.013939642687878076,112.5651813225162 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark56(0,-108.99286789797736,-0.034070047211921084,-100.0,48.79352125749396 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark56(0,1.2139965316365693,-1.1102230246251565E-16,-26.416443512500834,-0.21629771621751281 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark56(0,1.2736645459373572,-0.019413440965782097,11.705049007758833,-0.07079410218555715 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark56(0,129.8664486784964,-0.05468648705221835,-18.84383166879807,0.08335864777415981 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark56(0,13.049595605127177,-0.0187643948326532,6.218375919833861,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark56(0,-136.02878220871736,-0.0350498686504821,-0.5502930886155042,2.854472206341711 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark56(0,-142.01465248004288,-0.011832834699148125,-13.700763023794309,13.700764596669556 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark56(0,-144.04599048655228,-0.03290833632012597,108.57864754457168,-122.72097865855679 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark56(0,-14.759204710017169,-0.05414274096988034,-3.552713678800501E-15,36.86875791519145 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark56(0,-14.952838317533336,-0.03450366799985171,2.343067059772634,-2.3430665757048317 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark56(0,-1.5106672681572952,-0.08196209724667292,-0.8669019285750615,5.548988447220752 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark56(0,-15.186752424049454,-0.04616047307858925,2.601476536308063,-0.6038095308075018 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark56(0,15.68800266651232,-2.7755575615628914E-17,0.6179653355282247,-2.5418842069065417 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark56(0,15.861896783077658,-0.05127186004729928,-100.0,5.258796206408892 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark56(0,-16.161745493525885,-0.04345313414826235,2.289342820665656,-3.8601158587905706 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark56(0,17.257283720221974,-6.938893903907228E-18,27.10685884715466,-28.677655173949557 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark56(0,17.44646673950708,-0.054189838928143275,-4.500975399629306,2.930179072834409 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark56(0,177.72494523578501,-0.016375486486037476,0.04179497765920814,-37.58337519885231 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark56(0,18.476849506690378,-0.036271345577226444,62.07391857699339,2.2579344948024747 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark56(0,18.713985627681552,-1.1102230246251565E-16,-5.268316959044455,53.89218667904174 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark56(0,18.764062903703334,-0.028199903718789332,40.792678667531646,-41.38981807720557 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark56(0,-19.247392506446324,-0.020453500064697372,-0.018533718075412153,41.51940108009063 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark56(0,19.43496059520851,80.03757771501324,70.81165959817469,-74.10155778934573 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark56(0,-19.54075928030951,-8.881784197001252E-16,46.3885991546427,-75.92820757749179 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark56(0,-199.4016268521888,-0.006744763588857339,133.49162781399355,-0.01178911813647275 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark56(0,2.003621962496439,-0.008909125826095876,-0.1398425518387714,11.232606285717054 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark56(0,20.065486946742745,-0.014238319789889488,-0.03699044176303003,42.46492477321057 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark56(0,20.646023497149663,-0.005033724955890092,52.81725779985315,-54.31725779985315 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark56(0,21.10278640632419,-0.044961237731615575,31.77700160702662,-33.33278160139054 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark56(0,21.661665973591884,-0.04364482863749342,-1.950566364477769,0.8053026830571082 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark56(0,2.177292037746266,-0.5453703967751905,20.13392155925961,-81.31804509286675 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark56(0,-22.634425957249036,-0.009397872349759764,98.49999999973397,-100.06829683456309 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark56(0,-22.69185607762837,-0.024698761545431172,-76.3090782221915,74.73828189539661 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark56(0,2.301817386439881,-1.1102230246251565E-16,-58.43142895903954,0.026882729975609965 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark56(0,-23.22675981421741,-0.05040843051570566,0.04591494801278888,-34.09921855101209 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark56(0,-23.99741118740164,-0.050432849621285275,-88.23120719864899,26.316003910720326 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark56(0,-24.270573557302964,-1.1102230246251565E-16,0.0217164780976898,-72.33200152109369 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark56(0,-2.445825369785431,-0.05181075098359728,-10.67547975001047,12.246276076805376 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark56(0,24.715182234372744,-0.0293203801905407,1.934790256955167,-0.3639939301602701 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark56(0,-25.01652833015926,-92.7715088957162,11.887206268980123,14.928299505451974 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark56(0,-25.18137480344126,-0.2790844331734137,4.4483079417149325,-5.947963607537081 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark56(0,-25.212423475683018,-0.023386985485814225,74.36128392228575,-75.93208024908066 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark56(0,-25.24986021353216,-0.056072055997874765,27.894964013874784,-76.51885381772168 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark56(0,-25.259152611776294,-1.1102230246251565E-16,51.74161361715858,-73.66381514308104 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark56(0,-25.743060836616515,-0.017210394121291262,-564.5918978092735,2.8664895304607256 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark56(0,25.930891406018105,-0.04749851474008876,0.07941163228328896,-19.780431174003787 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark56(0,26.25035429783801,-3.482597927182064E-4,-9.690921589247562,11.26171791604246 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark56(0,27.216629827113763,-0.012135788343051686,-14.247406145837681,0.110239826707088 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark56(0,-27.49016468222414,-0.014899389759414378,13.293432715477655,-11.793432715477655 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark56(0,-27.919608972870332,-0.003850817250273703,34.74419687896057,-34.65253018634529 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark56(0,28.204907501875194,-5.551115123125783E-17,-0.3751152776707846,4.18750293655991 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark56(0,-28.24691609649545,-0.010274207439216185,0.05321287229346655,1.5175662104281076 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark56(0,2.883450502901057,-0.03431706171959181,26.981595399010914,-28.55239172580581 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark56(0,-31.182008726039182,-0.020226351364727533,-49.38042667964453,0.003686436302996881 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark56(0,-31.551455460289816,-1.1102230246251565E-16,17.357943052953814,-3.232280474144215 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark56(0,31.709381086584727,-0.0019319899333638535,38.6136432138492,-42.397974572520944 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark56(0,-32.31682733786197,-0.009319547409606277,0.012644266016485734,-39.0700102290143 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark56(0,32.68580247105962,-0.20258905788152898,-2.0764062472929066,0.7565244630800491 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark56(0,32.907275561428015,-0.01661005594021345,98.49999999955537,-100.0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark56(0,3.3008533244835743,-0.055753440379673114,-0.10543307406053525,7.414925507151057 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark56(0,33.17802350439729,-1.1102230246251565E-16,14.861549511700012,-24.28574353676359 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark56(0,-33.53022768289843,-0.043234587645128386,19.280556285419056,-26.948537343653797 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark56(0,33.652559699518704,-0.05002723795803907,20.151092373992892,-0.07795092681040824 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark56(0,-34.94650424439368,-5.551115123125783E-17,0.3791858475166334,-1.949982174311529 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark56(0,35.17280043698857,-6.57018180526539E-5,4.3736181606188635,-5.944414487413759 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark56(0,-35.607705718392026,-0.020694169070472224,8.788337113483635,-74.1414445803444 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark56(0,35.638265078362906,-0.03939875867126953,13.742852522709143,-9.029586092095897 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark56(0,-3.56829325202564,-0.02188412896919234,-0.09429210591470394,16.658831739481172 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark56(0,-36.36195755915202,-0.061059085350642195,79.24075864588525,-80.6926691915151 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark56(0,-36.516642220868654,-0.014990234720551537,-74.62254622685829,59.58671534488897 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark56(0,36.978309199759146,-1.3877787807814457E-17,-183.23072802924804,18.233582875543327 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark56(0,37.31086073017582,-0.05132052379542196,-313.56031850008134,90.54608906361999 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark56(0,3.745495036433665,-0.014619181172658424,17.62008374302072,-19.12008374302072 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark56(0,37.877528388358705,-1.3877787807814457E-17,-0.7226694504001728,1.8730910533318548 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark56(0,38.58240398548399,-0.0037527464618831163,6.128044362424401,-6.128044362424401 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark56(0,38.94597440257245,-0.03456085176536096,3.2106855773495466,-4.781481904144442 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark56(0,-39.21818828419258,-0.03236031054332866,8.951770456887415,-2.66972987687244 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark56(0,39.23653925172699,-5.551115123125783E-17,36.74682360217692,-47.65905747280793 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark56(0,-39.28950435291524,-0.04520623578208105,2.284209826082278E-16,-13.618488697560164 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark56(0,-39.519217339667044,-1.3877787807814457E-17,37.16030232567823,-38.66030232567823 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark56(0,39.94750461444017,-1.7763568394002505E-15,-11.874108764879152,10.381704535273274 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark56(0,-40.519019475888676,-0.012747390201671326,-3.837055074824394,0.4093754966148838 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark56(0.4063987494291721,-2.091260469915042,-0.030083551491194863,-0.06042891305222042,2.646534420658022 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark56(0,40.75695034528553,-0.06176020544511812,-0.48146779136706924,3.262515904407253 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark56(0,42.826569926665925,-1.7763568394002505E-15,-0.4171302361431968,3.7657215677255707 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark56(0,42.880177055796615,-0.006472610155384473,-0.024402138490371428,64.37125694597063 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark56(0,-43.4156116227165,-0.011638284936437565,-0.5696752713209309,2.757353892424754 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark56(0,-43.527397323057585,-0.04293685671507604,23.71844885954937,-0.06622677292669721 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark56(0,43.928298699504516,-0.009959814929225874,-0.027388546641581968,57.35230669040541 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark56(0,44.42875038176448,-2.7755575615628914E-17,-18.251287969591335,2.220446049250313E-16 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark56(0,4.4937110414828565,-9.475591089137939E-15,0.06020663990969296,-26.09008456793034 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark56(0,45.18722082666753,-0.008787227385747443,-107.12234942366781,51.600275720522596 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark56(0,45.68117786916407,-0.02431146858720329,-84.84173442081571,0.018514429690978898 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark56(0,-46.09314938324722,-0.03059485930848107,1.385291310680259,-1.1339104740529584 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark56(0,47.669864218552696,-0.005790235166480806,1.6788886638884621,-0.9356167330100296 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark56(0,47.688818507788284,-1.232595164407831E-32,-76.63065228488882,6.046972084919258 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark56(0,47.88092674797238,-0.05349393143654643,25.337250982117304,-0.05916770207693389 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark56(0,-48.03775238083469,-0.037176628017720495,-20.948963618615114,19.37816729182022 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark56(0,48.44425495208956,-1.1102230246251565E-16,-45.29039169025941,43.91812508046106 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark56(0,48.67229652958289,-0.03986645703312863,-72.3581500630139,63.00416842903941 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark56(0,48.7939178178352,-0.17574651667258323,-52.31325202409044,3.6970465310792626 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark56(0,49.351427886039346,-0.029797747625771753,-25.88077757254996,20.05296245186362 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark56(0,-49.646136013354294,-0.014815977861908275,-89.81446343170573,20.742530441518447 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark56(0,49.67890579489747,-0.06217941368358548,-13.26083703974434,0.11845378403241281 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark56(0,-49.6858590312704,-0.03417378982794336,-16.641008063414098,16.641006556985147 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark56(0,50.454291598412006,-0.016031539837533304,0.196645126777228,-2.531059219679399 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark56(0,-50.77490846262376,-0.043280359667749735,30.41422662856058,-6.852263258293758 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark56(0,-51.36628161680479,-0.0198562445426259,-33.70980367669236,32.383200696427565 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark56(0,-51.59592184467242,-0.0027054231763768977,0.6068131149383332,-2.5885998310279223 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark56(0,-52.122687975532656,-1.0,1.5867693132886895,-2.0966509603183336 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark56(0,-52.56850357844071,-1.1102230246251565E-16,31.96257266028347,-33.53336898707838 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark56(0,-52.67905508753884,-0.05211250652656726,7.6979467269912245,14.22240552134243 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark56(0,-52.68452991246653,-0.02421167360590501,21.816224186388087,-0.0637048604931526 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark56(0,-52.80432665653712,-0.04987948060776584,-0.01133531315648297,125.66603454979024 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark56(0,-53.70575241429856,-0.014186841422098358,-0.37074826950227546,1.9415445962971687 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark56(0,-53.85088571660445,-0.003922826532340745,88.57120573607668,-90.14200206287158 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark56(-0.5419393337315562,-1.7298506981207495,-0.041882905765784184,1.5986216993038072,-0.982594148120829 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark56(0,54.218526259162864,-0.04731902248948941,0.02387965444371497,-65.77969252014549 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark56(0,55.721836757682105,-2.7755575615628914E-17,-36.606051449002905,0.042910837542349256 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark56(0,55.74160779048074,-0.019348217061580436,1.6249492764583267,-0.12058825121551486 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark56(0,-56.66683035905344,-0.057959700769362785,0.02298789520312748,-68.33145500772908 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark56(0,-57.429230292034674,-3.469446951953614E-18,0.026095941436643722,-60.193127372258594 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark56(0,-58.392778725786286,-0.006123395013427707,1.3185659908974696,-1.1810451999785536 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark56(0,-5.918163362635582,-0.03364073842095851,-0.06249078004640935,25.136449339059784 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark56(0,59.353120362770774,-0.03128980337640641,165.92101486551428,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark56(0,-59.98096687305238,-1.1102230246251565E-16,0.8014683694201399,-0.8014683694201397 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark56(0,-60.06625391588059,-0.015448331919657221,17.445133184023824,-15.874336857228926 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark56(0,-60.22607202409854,-0.5925713081531891,-17.296246123423362,15.725449796628467 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark56(0,60.58723468902499,-0.044685464160393804,3.655308765281192,-0.42973013434996643 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark56(0,60.78840743366496,-0.05357836415129197,0.09761967267201087,-16.090981293008056 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark56(0,-60.803671535187505,-3.469446951953614E-18,34.93164347549275,-36.43164347549275 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark56(0,-61.26313371174219,-0.043107426492062326,8.71435454203126,-0.18025389249640902 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark56(0,-61.58870678266659,-2.220446049250313E-16,-25.087472960855024,2.647806700596128 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark56(0,-63.73464487910933,-0.7889176181026998,12.269607923673624,-11.070754636051497 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark56(0,-64.29356545926879,-0.05002265632160213,100.0,-118.85719389588664 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark56(0,-6.521103983237026,-0.056515850438207005,-3.817151220998768,0.37946696102558114 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark56(0,65.53300195268228,-7.700664136640611E-4,1.7763568394002505E-15,-13.586001345468546 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark56(0,65.6650384640117,-0.0559093960775669,73.94225743613312,-0.021243553838637616 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark56(0,66.11465084840458,-82.79556802711683,-92.76212331976122,86.88248041512776 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark56(0,-66.11631422028617,-0.024075366024908864,-97.82232507240437,96.32232507240437 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark56(0,-6.628480747730997,-0.024661895920103816,-1.087037780749473,7.105427357601002E-15 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark56(0,-66.34400963085784,-1.1102230246251565E-16,-0.02831589032622972,55.47402213730954 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark56(0,66.47508171865994,-40.68585107065476,-26.250029384989375,-6.686535472693549 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark56(0,66.55311689908314,-63.36016495694625,20.098605494519447,90.25298746976577 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark56(0,66.9106622015801,-32.83828546692986,92.27160466907142,-17.32929638382214 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark56(0,-67.17136203039759,-5.551115123125783E-17,-1.5152189817783863,0.4276803439078752 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark56(0,-68.0088187195702,-0.9999999999999991,2.9476282821713387,-2.700615442090457 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark56(0,69.50430317323747,-0.06192692284277553,-1.2552623385609722,1.2552543522812836 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark56(0,6.976222138139539,-0.021616928920710144,-74.57532843854673,92.39534336723061 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark56(0,-70.0529552780977,-0.06236718034442501,1.8724172056834236,-0.8389136363557197 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark56(0,70.24254996575118,-0.039462063081496024,-0.7370836882778973,2.1310963080255694 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark56(0,-70.24872929451712,-0.022898489809690205,-14.54415365021702,3.619302270804761 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark56(0,-70.89071551654904,-0.011791004522979346,-100.0,98.50201671580476 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark56(0,71.13047104353959,-0.05819167101674638,3.552713678800501E-15,-21.6302477023373 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark56(0,-72.67196370923182,36.24749885955674,49.82949199012825,-47.11748298210083 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark56(0,-72.98136932308695,-0.014754386228651273,2.220446049250313E-16,-34.41847652843744 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark56(0,73.0890242443187,-0.002172842805021102,-78.05811439352627,0.020123421363675294 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark56(0,-73.71560595160315,-0.03130522393082922,100.0,-99.99989684342067 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark56(0,-73.75196567173717,-0.0381035326290257,26.716466104891378,-26.716466104891378 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark56(0,-7.396704839903063,-0.03454386586091276,-0.08200010499470167,19.156028237968417 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark56(0,74.15287128956521,-5.794181755609251E-4,0.13371456748543312,-11.74738367205966 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark56(0,-74.76592427558734,-0.03575721477760832,-1362.3270748472696,6.938893903907228E-18 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark56(0,-75.17226617839185,-0.015547432836783604,0.04632352367851477,-33.909258235535624 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark56(0,75.2065297710918,-0.00724797070788899,2.4868995751603507E-14,-28.044546206955715 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark56(0,-75.24097691908793,-0.011658452356895152,-423.36306643990184,0.003673968992621037 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark56(0,75.82478967071344,-0.05145082489088598,-42.92960392143497,41.358807594640076 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark56(0,-77.16160398292818,-0.015619234130947882,2.4685945275468844,-4.0393908543417805 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark56(0,77.6496352579109,-0.06038354744588981,-75.4490479334817,12.625314614998473 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark56(0,77.82030481396093,-0.054394742493097115,10.984316084671507,-10.984316215503254 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark56(0,78.21911792220905,-0.007823400718457857,-57.33691968405643,4.440892098500626E-16 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark56(0,-78.3904437250687,-0.04543227739319872,0.03870893559947953,-40.579682764927725 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark56(0,78.44444747421697,-0.023741281627430832,-79.39441956600908,9.695609377621835 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark56(0,-78.87163758177269,-1.1102230246251565E-16,-3.575131560908911,0.0356490916747586 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark56(0,79.03160520884197,-0.037049219488312454,0.7797941473318873,0.7910021794630094 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark56(0,-79.45452262850499,-1.6467676037041608E-14,1.1384291015898476,-0.6435169403491745 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark56(0,79.71056754880088,-0.06187423903327302,-11.545465510307197,10.073003551597338 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark56(0,79.9611037148237,-0.06049670493525498,1.1102230246251565E-16,-15.98413210959417 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark56(0,-8.022770722028415,-0.02681963682324429,3.034900093047284,-0.02829559763402184 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark56(0,80.33246670527448,-0.018969022703914484,0.05120903396834843,-30.67420345726074 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark56(0,80.6206576499542,-0.05312356768322202,-0.18329464965108977,0.183294649651085 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark56(0,80.64202084531429,-0.05760456953096996,4.301549284351424,-4.301549284351424 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark56(0,-80.64805685277113,-0.03563677706760543,-8.946798306920632,2.7344093265359426 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark56(0,-81.20367369666236,-0.012810060594609984,-90.4166775310162,88.84588120422131 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark56(0,82.3702591634637,-0.013692338678105813,2.8078646898722273,-15.37418839089015 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark56(0,-83.2080870903871,-0.039241009157862,-33.18725471551871,0.2688300339223104 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark56(0,83.32610260284622,-4.4169899326442705E-14,-4.241343366601797,0.3703534920478351 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark56(0,-83.60203356120287,-0.02039030317646429,50.5407880332873,-71.435286874137 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark56(0,8.457609263152476,-1.8606371938798705E-16,19.221640563306032,-17.650844236511134 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark56(0,-8.479534398683642,-1.3877787807814457E-17,-7.188566189398506,7.188566231960226 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark56(0,84.84447699502002,-5.551115123125783E-17,8.472499731067195,0.9522835460858106 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark56(0,-84.89062794618206,-1.1102230246251565E-16,-100.0,32.84043748553793 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark56(0,84.98599560536574,-0.033763657305375894,96.44638145570832,-98.01717778250323 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark56(0,85.19209035099198,-8.861998761495078E-17,-34.55528915444178,36.12608548123668 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark56(0,-85.4686764403755,-13.176888978979377,-40.97686720587899,-65.33056378336511 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark56(0,-85.48458239970856,-0.004099457804664031,0.029466847622464397,-53.30724028984293 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark56(0,-86.29777125132873,-0.02158675177777534,-0.03216642846134388,48.83340805718007 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark56(0,-8.709218466614018,-0.01527482326365255,-79.99079519277072,1.4559754332265271 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark56(0,8.725771124541684,-0.01828201971901766,-27.826304268440882,1.2550794179067077 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark56(0,87.33717563676439,-0.015550300632364289,-3.552713678800501E-15,23.240452694311745 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark56(0,87.6899134890215,-0.026374454010676562,-0.02331650691874312,1.5994522243463638 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark56(0,-8.78441917214876,-0.0015440399409007433,4.721220259203578,-0.2573124375400737 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark56(0,-87.88708451567138,-0.024977804350333893,-0.12305488354868288,12.76500599972905 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark56(0,88.71074697288886,-0.057877533481940066,42.3110531744764,-96.60878532402207 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark56(0,-89.14303081270839,-1.1102230246251565E-16,3.581907655493084,-5.081907655493084 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark56(0,-89.37499012027521,-0.041394006949178164,8.118635119235906,-9.68943144603083 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark56(0,9.009827782680729,-0.017512038340643965,81.69639376876512,-83.26719009556003 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark56(0,-90.35460075827602,-50.83649520541744,5.121185244926707,-39.38321576309749 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark56(0,-91.04898926625974,-0.05082508064360468,9.202457670540483,-10.773253997335315 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark56(0,91.23042051368853,-22.76608541534948,-35.705824585906214,25.263695626096535 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark56(0,-91.28380532607453,-1.1102230246251565E-16,-2.2436715945793413,0.6728752677844445 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark56(0,91.4169440881752,-0.03333332834884414,21.270306888460226,-23.785694696243453 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark56(0,92.09288946569873,-0.059326192788034846,0.021748427844338433,-72.2257414668163 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark56(0,-92.13503052009808,-0.010563754319100473,1.2805360927089753,-1.2805360932618655 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark56(0,-92.77386822556709,-0.05941863844837718,24.06911175044109,-0.5779631753125363 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark56(0,-93.34691629131545,-0.04453009643242217,26.555992938148016,-76.77793564281357 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark56(0,93.51111157958482,-0.014983496661781975,28.963107641267413,-0.054234384868175674 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark56(0,93.91939914500952,-2.62491234967065E-15,-37.84641051510238,36.27561418830742 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark56(0,93.93247641791348,-2.7755575615628914E-17,13.288736677243936,3.990022917499927 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark56(0,-94.26275103515755,-5.551115123125783E-17,-19.11053999824371,0.08219528736180429 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark56(0,-94.82652968728905,-0.03432926088363873,-97.30400698652372,15.67091792855004 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark56(0,-95.45803089103592,-8.881784197001252E-16,18.5704551013669,-20.141251428161794 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark56(0,95.59261197051622,-0.004154752961943515,-0.14188146801405827,0.14188146207174995 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark56(0,96.05892069926975,-0.04453407230732145,1.5699331917260424,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark56(0,96.17111899324581,-5.17077308869918E-16,-42.32449950288133,41.36889301554854 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark56(0,96.22472958854196,-0.05083494555672008,-93.01471584676008,6.054421077735981 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark56(0,-96.22797734426575,-0.05918584638722145,-60.27725244774774,12.998780896052903 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark56(0,-96.2600870203303,-0.04183453444419344,-11.492480029126096,0.13668036166379505 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark56(0,-96.32011076110925,-0.667746536351955,-1.9533593059171885,0.3939368142875228 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark56(0,97.00254453980838,-5.551115123125783E-17,-57.93005520786565,56.35925888107076 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark56(0,-97.25159843842856,-7.105427357601002E-15,2.9729867541064454,-565.762277083419 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark56(0,97.7558793711771,-0.0482760665782626,18.025767940500643,-33.69441180882061 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark56(0,97.85341432050161,-0.06133574611905371,2.4665208425294582,-0.6368469707249742 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark56(0,-97.92961590939916,-0.004669358488754696,-50.72658678786296,3.67096136691066 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark56(0,-98.69297499439145,-0.02201082394413198,1.4288681910017502,-1.4288681910017484 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark56(0,99.66695258110323,-0.025308072593229727,-4.649850080954705,3.0790537541598075 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.75144865226547,-0.01152227580285066,86.16834611509708,-0.018229389301458183 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark56(0,99.78390066751811,-0.04949737603569132,-12.616973874018125,0.12449865890818758 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark56(0,99.84081157425948,-0.010252051292300713,-100.63887492475719,99.12377588693482 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark56(0,99.95565118608948,-0.056679643875300445,53.6197217963427,-1.8542393389060103 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark56(0,99.96837265648686,-0.003009495898785696,98.5,-100.0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.98113838893079,-9.68836298250373E-4,-0.04774382930222027,26.162319656018575 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.99998496924357,-6.308718902034464E-5,-67.56891367176087,66.06891367176082 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark56(0,99.999988541582,-0.03377880826019164,-100.0,98.5 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark56(0,99.99999999979873,-0.053892316089549766,15.369106402541199,-16.939902729336097 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.99999999999805,-0.021938899155984792,-0.19528071544507464,8.043786214193302 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,-100.0,-0.005269140243711501,0.07241840713812757,1.4983779196567704 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,-100.0,-0.035720545405594516,8.009344377043131,-0.19612046290545432 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark56(100.0,-100.0,-3.1285768134120465E-10,10.455221268151433,-10.450436707499797 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,34.82754032765612,-0.0013709502106254712,6.802253041467426,-0.23092294820835335 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,-6.092175843763524,-0.019241477302993963,-2.145494806474681,0.4524172727691358 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,-82.55780468603163,-0.023221939312249834,99.9999999935389,-100.0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,-88.18436865913291,-1.4802409786045605E-7,0.10856090152551157,-5.339951136584531 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,-91.4186936229706,-0.037637515753345674,0.05311017255071789,-19.417637128933166 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark56(1.045189517433645E-4,-100.0,-0.052460335614321923,47.25127611777233,-0.03324346887224243 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark56(-120.73529782933794,-18.185127586396476,-0.010565308228888015,-130.06887191836114,0.3259830880581518 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark56(-1.4157482855868437,0.5217160549602805,-0.003823827586320877,38.843209712038316,-0.04043940597185186 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark56(14.181883347957807,-53.148060287181885,-1.1102230246251565E-16,1.222794263977589,1.9193472016299722 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark56(-14.572327332559507,44.04124528087665,-0.015269470501525878,-14.510437073809083,0.1082528609444948 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark56(15.359727183145347,-51.71724585483187,-0.010232606460999622,-0.1036690810012604,14.802294464779134 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark56(-17.6029287886903,-78.34854456200337,-0.0406184934952325,0.043104476128517255,-35.70588440021979 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark56(20.443126820384194,30.762094820749752,-0.004464551543332369,2.086706479022643,-2.310457441632945 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark56(20.648881922964545,-101.8008787371897,-0.02846473126323598,0.043288782909980776,-36.286451620997866 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark56(2.1497641334860638,1.4107934774508555,-0.048937896333785064,-181.94853836809023,41.5653316951535 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark56(23.61905049404475,23.9325355853331,-1.1102230246251565E-16,0.052917516743489657,-29.683863179164558 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark56(-30.440289583781983,-4.955060742525184,-0.002797167400240744,0.1977018269109121,-7.9452797747930015 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark56(3.0576757019465255,-1.5042919030427482,-1.1442452217444547E-5,0.10174714285305876,-15.438235244240813 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark56(-30.9555904595568,68.36879449235485,-0.012318135903577247,20.612843858718037,-24.539609568855443 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark56(33.78758549384937,94.90104717455849,-1.8634602447689737E-17,10.048497010300792,-0.15632152004271493 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark56(34.06966697755573,-13.438341456670488,-0.002343625214173868,-63.24378854792893,27.07888577527875 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark56(-34.10047285078754,6.622101182556857,-2.2026165269370224E-18,3.8972467613050696,-44.71178409962796 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark56(3.887138803081538,95.37428904616314,-1.4898611921415017E-16,33.98369551888661,-0.04622205745463639 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark56(-40.212874799915596,26.68866397507695,-0.01256687807355017,33.78108068918708,-72.64824098430088 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark56(-4.996209854038628E-4,38.51077873441829,-0.03386195487333869,4.019333845933926,-4.0193338459339385 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark56(-50.14354425182939,33.725321792073295,-3.246961204106731E-4,24.544800845349247,-0.06399711029199617 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark56(52.07474897727995,-100.0,-0.04389978757106311,-100.0,99.99999999777104 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark56(52.19079158250584,-15.926580729921207,-1.1102230246251565E-16,26.548656035621846,-0.004107343736379058 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark56(53.894057720850725,-13.822070652156327,-4.2037236908093044E-4,-7.3247726915694145,0.09921671809457566 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark56(-5.46584202334229,-99.48052569590102,-0.007657173055704938,83.70370165980752,-0.018766151265077857 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark56(56.31672139554176,-40.74329855700046,-0.043664052684072606,2.8708529327346284,-0.5471531853422515 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark56(56.37575590678678,13.292901067060395,-5.551115123125783E-17,3.6194410052636727,-0.21282781838998188 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark56(-59.39934973544361,-46.15835865604315,-0.061649621851048664,0.3912523032372377,-1.962048630032136 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark56(60.05012957523283,-88.79888052701666,-2.9824138247725626E-10,-19.588772053151313,0.02492086822841255 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark56(60.183065811808476,31.46966743529336,-0.014815989746116615,10.568303509964565,-16.374810582114165 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark56(-6.075920693187495,-43.90630675121207,-0.014040155502079932,-87.32820544554903,57.883068905207075 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark56(6.164887024757072E-5,11.391151591682307,-0.023676144197238482,67.03189753858958,-82.73543226854812 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark56(61.7854499430876,-18.318623961389868,-0.029777598945434004,-70.42418671780533,32.97991884574178 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark56(-6.570516493139223,-87.77778545907911,-0.023484773644569246,-0.03397997714671404,46.227115457221466 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark56(-70.0326734238808,-62.378735394325375,-0.025230639738610783,54.48080510184631,-56.010119147628146 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark56(80.92747962308654,6.032205453742166,-1.1102230246251565E-16,26.857295704332675,-88.36656403416315 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark56(-8.120066443309902,-100.0,-0.01601911092507656,20.159554787729373,-21.662363990123275 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark56(86.64801438655599,-8.044826163128889,-1.1102230246251565E-16,55.18878712764429,-0.02699996245424607 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark56(-88.44765407348143,-56.068377049713085,-0.004280176914358461,1.244660778666392,-1.2620276574296387 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark56(-90.78350874758986,-57.654054831772314,-0.003137572477676931,6.135411839911818,0.14877091308886461 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark56(-99.54762660815625,57.43790177466701,-2.7755575615628914E-17,-0.061094880765663634,25.710768350950133 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark56(-99.63042822871914,-53.24389562900782,-0.023078147810068367,-100.0,98.5 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark56(99.85321262783098,99.86542498568124,-0.03792349458811489,-0.9050351753473185,1.735619089271402 ) ;
  }
}
