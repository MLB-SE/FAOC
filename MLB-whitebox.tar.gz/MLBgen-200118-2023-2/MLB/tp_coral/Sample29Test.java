import org.junit.Test;

public class Sample29Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark29(0.7798243310270294 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark29(-0.8825403896888844 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark29(-1.2757779512398824 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark29(-1.494140625 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark29(-23.330437094460436 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark29(26.753267994149454 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark29(-36.814979502087006 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark29(-40.091595918037484 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark29(-40.191031648850895 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark29(-40.19140625 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark29(40.7937512973196 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark29(-42.01517552707381 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark29(-53.71407821744685 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark29(54.92334796340202 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark29(-60.10473252593411 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark29(-65.55835253388933 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark29(-6.615345254806755 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark29(-709.0004488944221 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark29(-709.3468164862868 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark29(-709.5619702307368 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark29(-709.6546542822905 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark29(-709.7731106094407 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark29(-709.8050125584275 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark29(-709.8769991987964 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark29(-709.886988123145 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark29(-709.8959311515074 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark29(-709.929599807114 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark29(-709.9919288155444 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark29(-709.9943406519056 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark29(-709.9995074342296 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark29(-711.8080787321477 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark29(-714.8275577092038 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark29(-716.5145233478194 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark29(-718.4415274080831 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark29(-723.998679861067 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark29(-731.9502239413337 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark29(-742.6634552594593 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark29(-745.0977420218945 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark29(-745.3416447845709 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark29(-745.606786378712 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark29(-745.9999999391987 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark29(-745.9999999984905 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark29(-746.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark29(-746.0000000000063 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark29(-746.1914062628327 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark29(-747.19140625 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark29(759.1593921234697 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark29(-771.6108663885224 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark29(82.87904613190594 ) ;
  }
}
