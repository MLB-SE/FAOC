import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(0,25.025026708744534 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(0,-34.20495898879419 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(0,48.986055201869334 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark38(-100.0,0.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark38(-100.0,-100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark38(1.1102230246251565E-16,-25.337992719657308 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark38(-1242.7591402099413,-2.6916555404529477E-11 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark38(-128.5060364445891,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark38(-1.3022818450778857,-29.661260106693035 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark38(-14.028941108276257,-70.60505367958982 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark38(-14.550250343283494,-74.48925283534082 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark38(-16.12494147883585,-64.0935341381298 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark38(-17.296160931800017,-38.41566798997484 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark38(-17.726857507022146,-69.07492981403864 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark38(-1.8720994484020554,-54.73104889455098 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark38(-19.97644642157144,-52.766054505079715 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark38(-20.095498888573495,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark38(-20.124332392862016,73.79396177064405 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark38(-20.13549944169945,-20.37696029988338 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark38(-21.56530268405419,-24.988302219078633 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark38(21.831001571796406,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark38(-2.220446049250313E-16,-98.64962319424669 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark38(-2.2250738585072014E-306,-100.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark38(-2.225073858507211E-306,-100.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark38(-2.2250738585072216E-306,-100.0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark38(-2.225073858507429E-306,-100.0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark38(-22.295860586612818,-93.4591606070411 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark38(-22.962964898848327,-2.8380269717541324 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark38(2.465190328815662E-32,-62.26705103354622 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark38(-26.01444354167208,-31.108795947943776 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark38(-2.6669872318230645,-86.90189505485868 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark38(-27.636048291776234,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark38(-2.908630104447674,-46.49900373623676 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark38(-30.61230499259797,3.944304526105059E-31 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark38(-3.3752295184244754,-53.95832551821753 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark38(-3.4773857656688377E-13,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark38(-35.13842249326579,-83.92180153602962 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark38(-36.11821815257961,-10.420625306616003 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark38(-3.649224115855347,-82.78225305006812 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark38(-3.9907915743794544,-63.79904823368725 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark38(42.260918111798304,11.265602686283131 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark38(-43.23498599888234,-24.34212420882291 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark38(-44.19639249913403,-79.61939377925177 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark38(-44.4739340664834,-53.64841370399092 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark38(46.3792305011259,-37.81929138089577 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark38(-48.52709642598904,-79.07789536455267 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark38(-48.63140248988307,-91.90753129834573 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark38(-48.67175677919446,-48.67175677919448 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark38(49.9097725066116,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark38(-4.9E-324,-4.819179251237325E-162 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark38(-50.09253824179034,-96.76515649906159 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark38(5.0314955818883096E-17,-48.713794483421815 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark38(-52.27631886959007,-52.27631886959007 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark38(-53.349945025278785,-66.69930261210354 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark38(-53.46032438600886,-53.46032438600885 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark38(-53.76123716193948,-53.761237161939505 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark38(-54.33581836515163,-2.2250738585072014E-308 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark38(-56.84448681741243,-56.84448681741243 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark38(-59.836969539199835,-10.809380536505913 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark38(-59.90025266217575,-59.90025266217576 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark38(-5.9E-323,8.710167184807579E-17 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark38(-61.235404237294944,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark38(-62.543560705184525,-62.54356070518432 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark38(-62.66946591240985,-20.305337427012418 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark38(-64.46567064792575,-70.22237476187307 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark38(-64.58434071343083,-19.259186432759947 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark38(-65.23698262393728,-63.93269752554292 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark38(65.70402246358191,-70.18229093029123 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark38(-65.87425695436923,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark38(-66.00242754756155,-96.55934847335782 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark38(-67.27262582160603,-67.27262582160603 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark38(-6.746753670973994E-15,-100.0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark38(-68.82937955528239,-2.2250738585072167E-308 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark38(-69.30277907552478,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark38(70.54992558521627,78.98100783351856 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark38(-7.105427357601002E-15,-79.17584288443356 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark38(-7.105427357601002E-15,-88.07616721518774 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark38(-71.69704560434317,-13.844196819165916 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark38(-71.9946101151409,-61.24359591816055 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark38(-74.58899459001472,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark38(-74.84205526552823,-41.89228681954844 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark38(-75.41856548557155,-52.682059768524006 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark38(-76.62692528598166,-17.69245264619134 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark38(-81.91778781436294,-51.08198268268163 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark38(-82.06315984643928,-63.34248110167853 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark38(-82.07294683528615,-17.92832241592575 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark38(-83.3977872281843,-83.3977872281843 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark38(-8.4E-323,-100.0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark38(-86.47837688586597,-12.03815371118344 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark38(-87.00463073287568,-81.45518074996987 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark38(-8.782458218730085E-227,-195.12472769478495 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark38(90.14377650539907,0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark38(-91.31366876147938,-91.31366876147938 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark38(-92.09281750614815,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark38(9.274217007316722,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark38(-93.93778277595533,-37.92108506085648 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark38(-9.473202420383359,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark38(-95.88047739591991,25.55437181350291 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark38(98.09954588179892,0 ) ;
  }
}
