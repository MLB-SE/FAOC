import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(0,0.5783582623702728,27.372735974026313,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(0,-12.017848621210987,95.01124325346231,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(0,-120.95028427023979,60.139705222227235,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark79(0,-124.22868488134998,57.34231241461188,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark79(0,-131.47084253718427,85.42999076445287,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark79(0,-137.2957720438364,100.000007467976,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark79(0,-13.997500232751719,76.00249976724828,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark79(0,-142.86428001362654,71.74078633223044,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark79(0,-142.94378795312662,94.35199154558009,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark79(0,-146.48531372476785,47.423258978823014,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark79(0,-146.69323052911597,80.55959162251676,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark79(0,-149.41833449009985,30.58933536354485,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark79(0,-149.4742977065858,67.16711457187483,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark79(0,-150.73902277290685,92.50046167066617,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark79(0,-152.51233700073828,27.488100144017913,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark79(0,15.273615921516082,-14.26808354158446,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark79(0,-155.13548632205712,79.96652140704325,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark79(0,-1.6862380429109862,88.31376195708901,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark79(0,-1781.4153881408845,873.6501539591002,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark79(0,-187.02982609508214,-7.029388952906923,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark79(0,-19.770986593640288,-69.14019411242201,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark79(0,-20.760809259211292,69.2391907407887,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark79(0,-21.09046509045953,68.90953490953999,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark79(0,-22.939555172188108,-11.054667562050355,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark79(0,-24.152621006834266,210.7561534819106,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark79(0,-26.816374678608952,172.95765333250762,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark79(0,27.19864821066473,27.198648210664732,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark79(0,-29.614717845130333,-29.61471784513033,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark79(0,-32.33353706356526,21.787604277484945,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark79(0,3.4499161242691514,75.08004087128273,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark79(0,-35.83109617172751,-17.562932072362685,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark79(0,-36.54996323063288,53.45003676936713,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark79(0,-37.065827842115915,6.033044696191524,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark79(0,-38.3871822713928,51.61281772860718,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark79(0,-40.32054453825313,71.22430007372304,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark79(0,-40.566685078594865,14.908731050771124,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark79(0,41.97748402010336,45.33412602609036,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark79(0,42.13354104591727,42.13354104591728,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark79(0,42.41839622862608,48.91490704791255,0,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark79(0,43.685296415946475,76.38951690115714,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark79(0,-46.140836717956425,43.85916328204357,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark79(0,-46.25733852145277,18.506042736348775,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark79(0,-47.2229195766032,-34.808836541331715,0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark79(0,-50.27875704720432,22.73983050753938,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark79(0,-50.68335016831822,129.31665068545726,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark79(0,52.09043655698653,52.09043655698653,0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark79(0,-5.308195256946835,84.69180474305315,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark79(0,5.517021893469668,95.51702189346966,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark79(0,-55.55408019056116,34.445919809438834,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark79(0,-56.552845202402665,33.447154797597335,0,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark79(0,-56.742062334841094,-29.686698006485358,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark79(0,-59.12820596875876,-59.128205968758756,0,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark79(0,-60.66610430640396,-47.40520323719486,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark79(0,-61.86160042277688,28.138399577223115,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark79(0,62.390251576526,-38.248490232920496,0,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark79(0,-62.88975605286131,117.11026774698453,0,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark79(0,-63.15796647840899,-16.016654840350725,0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark79(0,-65.85600739931645,24.14399260068355,0,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark79(0,-66.53525033203496,30.4030247654415,0,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark79(0,6.842150757959558,19.93555845708157,0,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark79(0,-70.61215909437618,19.38784090562382,0,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark79(0,-71.58562460365766,-88.92762473263558,0,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark79(0,-71.89926398521203,155.74740656613005,0,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark79(0,-727.3062141141858,2011.6274093123016,0,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark79(0,-73.58183343057007,10.939986161612026,0,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark79(0,-75.32653782259845,-75.32653782259847,0,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark79(0,-76.06955005492557,16.195408645018915,0,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark79(0,-77.68835063291073,131.81089442718508,0,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark79(0,-8.087339378955178,81.91266062104481,0,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark79(0,-82.40753076498356,7.592469235016424,0,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark79(0,-83.39721229654896,6.602787703451023,0,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark79(0,-84.39820376271709,5.601796237282908,0,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark79(0,8.830580943626899,98.8305809436269,0,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark79(0,-88.4796237698845,91.52037623011563,0,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark79(0,-89.7500155530202,-89.75001555302019,0,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark79(0,-90.19569131248532,100.0,0,0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark79(0,-90.3332796446661,3.7638487366479296,0,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark79(0,-91.0575172199281,95.07210705597709,0,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark79(0,-98.85404367976408,-8.854043679764088,0,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark79(0,-99.06425452712165,41.947045407856024,0,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark79(0,-99.45585450882753,94.4007903364824,0,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark79(0,-99.60288839072065,134.68035886071408,0,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark79(0,-99.88733450968851,88.08485354667951,0,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark79(0,-99.89325904404318,80.10674095595694,0,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark79(0,-99.97892869268208,48.251185445115766,0,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark79(-1.0386533863576195E-26,-47.90439344699401,42.095606553005986,24.23062076804159,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark79(1.0451147607165987E-16,-3.0059022779642266,-1.956942642570803,0,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark79(1.0647837714997367E-8,-99.89680026908711,98.61705430283412,0,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark79(-10.92665471006677,-68.66575185187656,3.4404117432923016,-16.441908623764263,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark79(-1.14499220488754E-29,1.6702869183921525,91.67028691839215,15.739076148884003,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark79(-11.848024412316555,-52.93513666338234,37.06486333661766,0,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark79(1.2038205760088027E-5,-58.050179222491415,31.949820777508588,-75.8033183650121,0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark79(-1.2636875026469304E-27,15.000115985467367,15.000115985467371,-30.50974997684974,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark79(1.3182159065598911E-23,-35.29681259100506,54.70318740899495,-31.05729455243839,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark79(1.3260030474740828E-14,-102.02828208944376,135.26742671529826,0,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark79(-1.4610047138914619E-30,14.890530857586214,26.923233954283496,0,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark79(-14.951904090130057,-7.226280961384816,51.451050756157,0,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark79(-1.5757442408265402E-6,-173.91440534547039,6.296679918171208,-97.37848765488282,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark79(1.651247159260593E-29,-34.738076638132284,-10.20360587179448,0,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark79(-1.739421649729455E-26,-5.34721479526716,84.65278520473284,-32.61921771182183,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark79(-1.8486377550097562E-32,-61.102546074865515,28.897453925134478,0,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark79(-18.928881233898466,-64.3893830807318,25.610616919268193,-28.736528535690017,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark79(-19.4076145515154,-52.870793690008554,37.12920630999144,-16.720987032250605,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark79(1.957303900575986E-18,-25.35170003452501,211.8663091752331,0,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark79(-19.785916701771296,9.06053360598126,9.060533605981263,-47.75011031732231,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark79(1.9962088078546867E-6,-90.86898691285859,89.13101394353355,-100.0,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark79(2.026354320541159E-25,-80.46731093932827,-80.46731093932826,-40.61354334395535,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark79(2.2291030654137235E-9,-68.49790344408993,165.60899450872796,0,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark79(2.234115050409504E-30,-58.33503067030553,31.664969329694472,0,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark79(2.303813175143068E-34,-43.14825802158213,46.851741978417856,0,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark79(2.3507462766617204E-29,-72.61002249427108,17.38997750572889,0,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark79(2.376732367593524E-8,-59.06480455069894,136.82288936622524,-30.943035222714826,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark79(-23.831654190081693,-53.51320512746372,36.48679487253627,49.778026924710026,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark79(-26.60691682281518,-91.36821565081456,89.02516267966749,0,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark79(-3.6067740669023904E-11,-83.15167712092943,96.84832287950434,-96.77354206858064,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark79(3.637646100669792E-9,-13.910897560962809,33.462118401364165,-44.56004436194875,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark79(-3.732622500278576E-9,-7.121460038802544,-6.8531248874361985,0,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark79(38.17261152363125,-77.31018996183391,135.95015327169978,93.4243443151422,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark79(-3.9451463155470216E-14,-21.894549978063772,158.5425920012427,32.84977208263507,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark79(40.6878109902992,-65.64924500370309,164.2865647051455,62.1295544923305,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark79(-42.001428087397976,55.30258752166981,55.302587521669814,0,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark79(-4.468987384128994,30.21803224640981,30.21803224640982,0,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark79(-47.99680763949568,8.990718578699841,98.99071857869984,0,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark79(48.83553031722572,-71.60406828266147,18.39593171733852,0,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark79(-49.35519313907379,-73.09228812394453,2.3094217338207557,-96.34183834813605,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark79(-5.040162533190321E-35,-54.142035579304086,35.85796442069591,0,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark79(51.400920041357324,55.51837826252822,55.54823834391122,0,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark79(51.690087104614946,-90.77067724005747,-81.08422377953914,-22.39830738180393,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark79(-5.67691132368938E-26,3.479876495670858,3.4798764956708617,99.94275955533735,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark79(5.728013625287842E-9,-5.691291113906889,-4.973338248806442,0,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark79(57.29110415371207,-72.08917319636981,17.91082680363014,0,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark79(-5.977121749629601E-9,25.25238049641951,25.252380496419516,37.99919296001767,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark79(-60.26532162960012,-105.42015827124878,97.95087954138424,73.95298244559595,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark79(6.166409416413776E-4,-90.47518068380674,96.89986754102759,-49.76075125146343,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark79(-6.583174374708552E-9,-58.7838923749388,31.2161076250612,-74.26169523720293,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark79(-68.41335171452224,23.093696191387735,23.093696191387863,74.5617475630512,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark79(-69.51468196469295,-56.31810162285662,131.94447288783056,0,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark79(7.256496270109553E-29,-95.34098730690462,100.0,0,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark79(72.8060274330488,-51.767424347322894,38.2325756526771,0,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark79(-7.3146102397601656,-80.28506110532078,9.714938894679207,0,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark79(7.365235203394029E-12,-100.0,-10.013391313897953,100.0,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark79(75.96525050025164,-99.69763512040551,-99.6976351204055,67.7847528824654,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark79(76.11482358078207,-1.7014256082169354,88.29857439178306,0,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark79(-77.73966249827649,-53.0047245466019,36.99527545339811,0,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark79(78.78401128375533,5.23558856906406,95.23558856906405,-43.62728777679172,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark79(8.031327337979524E-26,22.468188247590508,22.46818824759051,66.10453356281465,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark79(-8.148626471522774E-28,-77.64493137793822,12.355068622061765,0,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark79(-83.4878262439506,-71.31072277487999,18.323533327939117,-48.27336575185155,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark79(-8.404343675615352E-9,-34.18541274709099,55.81458725290901,-100.0,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark79(-84.87306651799054,-161.70492843406873,66.13668032023388,-18.604984998851066,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark79(-86.69660959038964,-30.85534872146076,59.14465127853924,0,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark79(8.85524677089372E-9,-56.208926651719146,33.79107334828085,25.767863261818306,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark79(-9.123140384433668,-96.45406920655468,-44.213645031603896,0,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark79(91.710609977397,40.40135192871308,40.40135192871309,100.0,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark79(-9.356957335704028E-5,-26.298956551832205,-23.74632045923515,0,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark79(97.21720164831419,-192.8395319098601,9.616349359083529,0,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark79(-9.744700708488874E-5,-137.0713894361447,100.0,0,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark79(99.88512787427163,-80.71924455898902,-69.1103250104145,0,0 ) ;
  }
}
