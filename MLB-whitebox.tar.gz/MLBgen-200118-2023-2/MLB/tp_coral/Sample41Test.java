import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(-0.0019694786490801527,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(-0.40513273710649855,0.5692652717819018 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(10.020476746707184,90.38947748459219 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000004 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(-1.0716701964282762E-32,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(-10.867708811464368,131.30043099609418 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(1.276199931177697E-24,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(-1.3562018786764725,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark41(-2.661770318652401,9.746791547911306 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark41(-40.87137532837322,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark41(-4.502600021913539E-9,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark41(-4.622657349420517E-9,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark41(-60.53349235365915,-8.441892381234965 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark41(7.691552268056867,51.46842402419387 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark41(8.468431685705602E-5,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark41(8.498249137149879,63.72198925991877 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark41(-96.78359209172154,0 ) ;
  }
}
