import org.junit.Test;

public class Sample18Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark18(0.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark18(-0.07457302869843829 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark18(-0.17400316620354772 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark18(-0.22107911341898046 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark18(-0.33485444235361683 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark18(-0.4306665531849836 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark18(-0.4398695499013624 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark18(-0.5401110675218774 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark18(-0.5523153694398957 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark18(-0.5640390804874755 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark18(-0.6048933079411825 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark18(-0.7071067811865476 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark18(-0.7343611664525724 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark18(-0.7788712818038732 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark18(0.785025884639694 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark18(-0.7877891201995055 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark18(-0.8190323167677036 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark18(-0.8423769678961284 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark18(-0.844312778151604 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark18(-0.8603772875723337 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark18(-0.9175630556183876 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark18(-0.9350136454120417 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark18(-0.9449052158188636 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark18(-0.9471503565833808 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark18(-0.9735558845608239 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark18(-0.9774384407030539 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark18(-0.9858862168579776 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark18(0.9950329998675321 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark18(-0.9955497762088328 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark18(-0.9967849211354007 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark18(-0.999146206463152 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark18(-0.9992705473512444 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark18(-0.9996034109847939 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark18(0.9999912189558944 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark18(-0.9999999999999974 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark18(-0.9999999999999991 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark18(0.9999999999999993 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark18(-0.9999999999999998 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark18(0.9999999999999998 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark18(-1.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark18(-1.0000000000000004 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark18(-1.0000000000000009 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark18(-1.0000000000000018 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark18(-11.083634591502218 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark18(14.096900317466577 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark18(14.222582048878962 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark18(-1.6940658945086007E-21 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark18(-17.052556040492334 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark18(1.734723475976807E-18 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark18(17.71210689448992 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark18(-19.594073039380433 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark18(-22.903737217327233 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark18(-27.087907622917157 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark18(-3.0096985588247094 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark18(-4.551905024887958 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark18(-4.951981895418143 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark18(-5.2131714110170435 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark18(5.421010862427522E-20 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark18(-57.29798523499472 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark18(-6.0834930121445114E-210 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark18(-6.123233995736766E-17 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark18(-62.025092943201955 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark18(78.59415805740471 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark18(-98.14919130635136 ) ;
  }
}
