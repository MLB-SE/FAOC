import org.junit.Test;

public class Sample04Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark04(-1.2215935946197032 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark04(-1.494140625 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark04(-19.652518385843877 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark04(-24.058235967510086 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark04(27.058726944360757 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark04(-33.34178656354656 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark04(-37.20256230568146 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark04(37.94341771334629 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark04(39.28220562796872 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark04(-40.02913319418484 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark04(-40.189912215801 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark04(-40.19140625 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark04(-44.033653330541675 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark04(-51.5142125121332 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark04(-51.65855377456394 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark04(-709.2689744706048 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark04(-709.2948626902446 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark04(-709.4624737719596 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark04(-709.4846966748231 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark04(-709.6768236936753 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark04(-709.7130331901666 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark04(-709.782828216686 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark04(-709.8089402394901 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark04(-709.8415795104968 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark04(-709.8457860108759 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark04(-709.9919347911974 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark04(-709.9922167896138 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark04(-709.9999309795147 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark04(-715.0429283372853 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark04(-723.0723896260819 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark04(-725.9262204039865 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark04(-726.979620472555 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark04(-729.0652904167797 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark04(-733.3040229328416 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark04(-736.612128899176 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark04(-737.3665772198993 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark04(737.9241661075564 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark04(-745.2955670041374 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark04(-745.8523499410404 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark04(74.59297948853646 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark04(-745.9999999980027 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark04(-745.999999998112 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark04(-746.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark04(-746.1914062501141 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark04(-746.1914070755921 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark04(-751.6964292952447 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark04(78.8161667836836 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark04(8.024160788360703 ) ;
  }
}
