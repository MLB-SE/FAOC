import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(-0.0011279155975451594,-0.0022558311950902853,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(-0.0014249444766842637,-0.002849888953112778,-0.7846856911591062,-0.7839732189208919 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0.0014810526155415726,0.0029621052310831587,-7.405263077707794E-4,77.16636918520534 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(-0.0015412765346921571,-1.7763568394002505E-15,-47.7462939337749,-5.357559401607174 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(-0.0015652358997639464,-4.2132957940910883E-13,-54.14346644495212,8.671860621163209 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(-0.001583464766218878,-3.469446951953614E-18,-0.7846064310143388,-72.93760882097394 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(-0.0018347520214002694,-7.4121867106641E-14,-44.755822444237346,-35.164821278627564 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark07(-0.0018749833433986396,-0.0037499666867884247,-39.58033425448387,-98.19353509885904 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark07(-0.002253389905811032,-0.004506779811621842,0.001126694952905516,-0.2404222567068388 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark07(-0.0023660458850928026,-0.004512688792516391,-62.986921231428184,0.002256344396258214 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark07(-0.0024503409306237955,-0.0049006818612449266,-41.62874968639119,-79.57224828712302 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark07(-0.0025747107699934935,-3.197442310920451E-14,-91.21249280792179,35.4447962052063 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark07(-0.0039751908684029225,-0.007950381736805765,-0.307405175087408,-0.030496115374553448 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark07(-0.004605086334053917,-0.008779830808665344,-0.7830956202304213,10.530347785444679 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark07(-0.0053233846414956825,-8.908922390262992E-15,-4.787035173151625E-16,-22.74204084646431 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark07(-0.007582962369798496,-0.015165924739596768,-79.53761214275622,0.007582962369798385 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark07(-0.008135679252514233,-3.457875577864323E-9,-50.243535372667914,100.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark07(-0.00829526452973395,-4.1932185434557715E-5,-0.09524852230115291,-62.04774886262409 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark07(-0.009217710824720893,-1.1330371232788286E-21,-28.76392080942426,5.665185616393555E-22 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark07(-0.010640520280124676,-0.021281040560229975,-0.7800779032573859,26.659597559131512 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark07(-0.01142500814987596,-3.848638592581475E-14,0.00571250407493798,-19.633794333140802 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark07(-0.011836677494942908,-0.023673354989885754,-0.7794798246499768,100.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark07(-0.01255206881952775,-0.025104137639055356,-0.7791221289876844,-3.673960777331618 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark07(-0.013602711906597122,-0.0024405144432536607,-0.7785968074441497,-4.483858582336461 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark07(-0.013642540399466437,-1.0237316534311796E-14,0.006821270199733219,-26.393739949623313 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark07(-0.014723128188467466,-1.8311541120326976E-15,-0.7780365993032147,-0.7853981633974474 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark07(-0.015010642959618514,-2.6318581198453017E-14,-0.7778928419176391,1.315614587422134E-14 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark07(-0.015028940466670583,-4.3368086899420177E-19,-75.34011613250625,51.138059073082324 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark07(-0.017361058373285786,-0.00832153044845098,0.008680529186642893,0.004160765323192386 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark07(-0.021397007635170575,-0.04279401527034099,-38.819402121256765,5.868192591423405 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark07(0.02143165920570379,0.042863318411614774,-0.010715829602851895,36.759841991188694 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark07(-0.021641618629523407,-0.04328323725904659,-62.36425468407959,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark07(-0.022677993702852756,-0.04535598740564536,-0.7740591665460247,-50.952460769847 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark07(-0.023186686557549237,-1.1233236563157334E-12,-0.5265104791465444,100.0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark07(-0.02430195192780704,-0.04860390385560724,-0.7732471874335448,-100.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark07(-0.025398428411229614,-0.050796856739065685,-25.075532523015546,0.02539842836953285 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark07(-0.02876012626433736,-1.0339757656912846E-25,-102.90138057118433,2.5001922601129643E-10 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark07(-0.029177478449307362,-0.05835495689861472,-0.042661522076606236,40.90494653171777 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark07(-0.030155349329423764,-0.060310698658846654,-30.834030880161293,-59.100753216357106 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark07(-0.030841177268134068,-1.161801845118853E-13,0.015420588634067034,5.809009225594266E-14 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark07(-0.03149269335403662,-0.06298538670807319,-65.6461148635173,16.126917361657817 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark07(-0.03192396038138068,-0.050890677959509134,-0.24164868720235244,-87.32891536489872 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark07(-0.032185638209336315,-7.107699117464013E-7,-149.25186382298605,-96.60733076942722 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark07(-0.03462115777256629,-0.04685942640027915,-44.73969998022131,99.9662455443933 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark07(-0.035083099656768646,-0.07016619931353725,-47.68342958076419,-46.30209390703666 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark07(-0.036962036776729754,-0.07392407355345222,-0.7669171450090834,0.8210452798547395 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark07(-0.037394215747464266,-0.0747884314949285,-99.92734382121748,57.26776362825001 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark07(-0.04342319076365708,-0.08684638152731396,-49.35361264189843,37.926778074357046 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark07(-0.043989271410921744,-4.440892098500626E-16,-89.88566908268157,42.37698923435262 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark07(-0.044986483018478296,-0.08997296603695637,-42.92247929526774,-69.34166001909708 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark07(-0.04527934000031841,-0.0905586800006364,-34.99341985588451,-0.7401188233971301 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark07(-0.045951574426819713,-0.08876235439711819,-1.2694233332387854,-32.9423293388051 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark07(-0.04749382756272726,-5.490471155148131E-14,-65.9959510333437,-0.22001976929190642 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark07(0.048976077316276984,-4.163336342344337E-17,-21.22227435138376,-59.291176706187564 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark07(-0.04915849395431149,-0.09831698790862275,-2149.0544284144858,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark07(-0.05084674253918553,-0.101693485078371,0.025423371269592765,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark07(-0.05169445577291354,-0.103388911545827,-100.0,9.021984658076617 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark07(-0.05444598768247497,-9.582559883295494E-8,-72.2139071369249,4.791279950566718E-8 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark07(-0.05485601065501111,-0.06690646573136971,-0.7579701580699423,-58.08621411816884 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark07(-0.056047591884489156,-0.0953398516014965,0.028023795942244578,0.04766992580074825 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark07(-0.056105822771682856,-3.1554436208840472E-30,-65.89515075843728,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark07(-0.05916335771733383,-0.036542334727057924,0.029581678858666915,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark07(-0.0631740408464898,-2.7755575615628914E-17,-18.461865388640994,1962.772785675127 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark07(-0.06480241542757324,-1.1102230246251565E-16,-32.55234955318623,-0.3030259967770139 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark07(-0.06494734624915086,-1.4060101987362983E-16,-45.380424913594446,-1865.8903263324 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark07(-0.06661416534218172,-1.1102230246251565E-16,-100.0,-15.96340317762126 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark07(-0.06841176505025265,-0.05030126572536452,-0.7511922808723219,-0.760247530534766 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark07(-0.06972096149537675,-0.0012155395558339094,-0.75053768264976,6.077697779169546E-4 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark07(-0.07112550786631999,-2.2313426963856668E-14,-63.294878562073094,28.59317798640977 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark07(-0.07223320337662956,-0.14446640675325909,-38.881752827392546,0.07223320337662997 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark07(-0.07270655210262755,-5.541328202712324E-12,-137.3242276203481,2.7706725802545407E-12 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark07(-0.07323060603613935,-0.14646121207227866,-0.7487828603793787,78.66976966150357 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark07(-0.0733389396027054,-1.3838827108642627E-30,-22.681550328798394,-91.43669910908967 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark07(-0.07463713561843176,-0.11855253610971805,-0.7480795955882324,-33.08326154643773 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark07(-0.08008184485360129,-7.888609052210118E-31,-83.1828278128515,-33.804355096563754 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark07(-0.08139744448104957,-2.7755575615628914E-17,-88.99109526735408,-60.22547327133523 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark07(-0.08175463875008226,-0.003169741203991382,-98.04588645837468,-0.7838132927954526 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark07(-0.08210928189967988,-2.7755575615628914E-17,0.04105464094983994,54.981330622837426 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark07(-0.08540158786125862,-0.17080317572251713,-0.5047136879504919,3.7629399976560647 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark07(-0.08543597201993154,-0.17087194403986142,-0.7426801773874826,0.870834135417379 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark07(-0.08862855605247051,-0.07153546972512072,-17.874360910948187,-55.5521403244571 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark07(-0.08870129266531816,-2.802596928649634E-45,-27.124992367004765,1.4012984643248169E-45 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark07(-0.09025255800909382,-0.17902911965067497,-76.0122065970587,100.0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark07(-0.09049244834132186,-1.9309355187263884E-16,-113.80293082273413,-93.65168414058391 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark07(-0.0932672891081176,-0.18653457821623515,-24.299187753229052,0.10197610902390912 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark07(-0.09340992793146916,-0.18681985586293778,-0.7386931994317137,-93.70258561588334 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark07(-0.096441121081968,-6.938893903907228E-18,-31.137819586087474,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark07(-0.09701209819655432,-0.19402419639310753,-85.50259790866562,65.79091394396451 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark07(-0.09773660259692116,-0.19547320519384226,-0.7365298620989877,24.20297879797987 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark07(-0.10156799065626425,-1.1102230246251565E-16,0.050783995328132124,-76.97012008887063 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark07(-0.10299530693115706,-7.105427357601002E-15,-0.5177447994710941,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark07(-0.10376144734838486,-0.055534205791766385,-0.7335174397232559,31.849702616818714 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark07(-0.1042469494874837,-4.3137313342247395E-16,-21.191948134741335,-0.7853981633974476 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark07(-0.10697959862239641,-1.0339757656912846E-25,-69.74683992413141,100.0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark07(-0.1071045293960967,-0.024239402148888298,-100.0,74.00829925718226 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark07(0.10824658198867645,0.5725887543614361,-23.472767915655986,-100.0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark07(-0.10919174939824494,-0.2183834987964898,-0.7308022886983259,52.76558836172286 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark07(-0.11066980280174873,-0.09748454914148974,-100.0,88.71844046085495 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark07(-0.11690175450070024,-0.23380350900139907,0.05845087725035012,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark07(-0.11856293188493328,-0.23712586376986652,-0.29237990826151194,-79.3323739596705 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark07(-0.11863233266235726,-7.59882993875421E-11,-6.816813535948924,-31.396194575125882 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark07(-0.12334002917170703,-2.7755575615628914E-17,-63.55470179374561,-0.2221028915329994 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark07(-0.1246537518107412,0.65945698274399,-83.84957486189506,9.190037444144965 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark07(-0.12502332106528513,-3.552713678800501E-15,-13.061428334865155,-94.34466699180723 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark07(-0.1270326487108592,-0.01876393149075704,-0.7218820444947482,0.7947801291428268 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark07(-0.12773661481729576,-0.03112801989140973,-0.7215298559888004,-62.55211590158677 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark07(-0.13159279809474356,0.7355309452738672,-110.62542040528423,162.99560582928189 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark07(-0.1332658582528537,-0.07139221161665386,-84.81696960316978,0.8210942692057751 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark07(-0.13366027151883503,-0.1664277697260816,-0.7185679786658308,-258.42525083275467 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark07(-0.13403880741919805,-2.0816681711721685E-17,0,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark07(-0.13412613860643488,-0.20389650120068026,-16.267421475549245,0.10194825060034018 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark07(-0.1379482512144081,-4.9231268399044325E-11,-83.14700393621438,50.77317437384848 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark07(-0.14350363456470186,-0.28700726912940366,-36.463681359832194,0.8942031555115407 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark07(-0.14394620254501267,-0.04021229035665333,-11.379139346008799,12.00014077509531 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark07(-0.14398643615310214,1.2252062278689184,-0.7134049453208972,91.26885038891113 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark07(-0.14616988212308035,-0.29142969044579364,-9.81996443938273,0.14570978703476578 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark07(-0.147046181179604,-5.551115123125783E-17,-21.096600416881813,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark07(0.1483583080771225,1.5796645042954576,-70.2827329925806,-153.611920883171 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark07(-0.14964678198553436,-1.1102230246251565E-16,-37.181912346230575,29.990617399085053 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark07(-0.14997908451610942,-0.29995789959690633,-0.7104086211393936,0.14997908443402908 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark07(-0.15012132603809888,-1.1102230246251565E-16,-25.949085719997385,0.7853981633974492 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark07(-0.15044321827367718,-0.07468848100285841,-38.38944466192458,-0.7480539228960191 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark07(-0.1521952448175782,-8.88178413517412E-15,-55.7475336295528,3.21671481989101 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark07(-0.15235834204983975,-5.551115123125783E-17,-98.23180867583409,53.24872660070048 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark07(-0.15682216353541062,-4.440892098500626E-16,-97.98345109153766,96.38820995883385 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark07(-0.15757591235618923,-0.15829514816333495,-24.364277245840128,31.56317383028746 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark07(-0.1587176316579438,-0.22840441772659784,-25.81000607987656,0.8996003722607472 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark07(-0.159933618355071,-0.238799784195828,-47.80851257459249,48.76463466162484 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark07(-0.1607761802921259,-1.7763568394002505E-15,-0.7050100732513853,-0.5320427313416988 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark07(-0.1608189152570407,-0.017595159060734056,-0.7026851818418081,-0.5531926414800125 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark07(0.16087398171210765,-5.551115123125783E-17,-35.413340066921705,90.86455185101222 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark07(-0.1633557391957794,-2.5579538487363607E-13,-41.368238202184116,-100.0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark07(-0.16413528718550818,-0.30845386074719217,-0.7033305198046942,-59.31116173403105 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark07(-0.16680130988807093,-0.33360261977614175,-0.02407163650156217,-23.54727107157661 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark07(-0.16960936463909249,-0.07024887381176903,-40.1650074656314,0.035124436905884515 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark07(-0.16980218409876557,-0.33960436819753104,-73.09222581602941,0.16980218409876546 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark07(-0.16983621216994,-8.881784197001252E-16,-21.874190990967822,1760.3708719508213 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark07(-0.17296227377583206,-0.3354248436405074,-0.6989170265095321,20.825303179366518 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark07(0.17357400810176504,-0.01980456839475043,-58.989653063706086,29.220287735038582 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark07(-0.1754876893261077,-0.20871948220708963,-82.69814608416206,100.0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark07(-0.17560122900801778,-0.2783450235913518,-44.3699526120883,39.20685610795829 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark07(-0.17640034752695044,54.558172990496644,0,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark07(-0.17822911919930634,-0.35645823839861246,0.0010492280074706484,0.1782291191993062 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark07(-0.17935856155073737,-0.12163441118848758,-0.6957188826220796,-0.7245809578032045 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark07(-0.18408054441569405,-0.20461248627599665,0.09204027220784702,1.0471975512021316 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark07(-0.18524573572974246,3.6000922153391364,-87.9192009680239,-4.944063883385034 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark07(-0.1872352149774361,-0.37447042995487195,-100.0,0.18723521497743603 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark07(-0.18885752037395398,-2.220446049250313E-16,-100.0,-36.64920664328191 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark07(-0.19489858784012526,-1.195199117392621E-5,0.09744929392006241,-28.41715656553771 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark07(-0.1975921044988285,-0.3951842089976565,-3.1354201691199393,-99.46646458288554 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark07(-0.19797300857799316,-0.38183473489205666,-100.0,-0.5944807959514199 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark07(-0.19817412274466273,-0.39634824548932535,-0.6863111020251169,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark07(-0.20051479093804223,-0.4010295818760844,-39.94777909993634,50.49086143124206 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark07(-0.2007999383967608,-0.39380191370753004,-4.01442552392535,0.19690095685376505 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark07(-0.20336554211360888,-1.1102230246251565E-16,0.10168277105680444,-0.7853981633974527 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark07(-0.20382112354406423,-2.220446049250313E-16,-3.945181787759841,100.0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark07(-0.20420852692975933,-0.40841705385951854,-39.903095348409316,-56.32265403076251 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark07(-0.2057565967417386,-0.07220565179272086,0.1028782983708693,58.155566907389186 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark07(-0.2068859999146169,-1.1102230246251565E-16,0.10344299995730845,-20.063830880982493 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark07(-0.20959479489325236,-7.105427357601002E-14,-0.680600765950822,2025.8061074153243 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark07(-0.20966422887345115,-0.07987416683223186,-50.00097106289161,17.126486778763216 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark07(-0.21054077231907603,-0.012444760534916964,0.1052703861595381,84.57052628638681 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark07(0.21070245803061916,1.5698095335263298,-0.10535122901530958,257.61111867493264 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark07(-0.21201102276309725,-0.42402204552619427,-0.24763245834883874,1.0755314100972193 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark07(-0.21248085503469138,-0.00865317850113902,-35.488042753920624,49.46148860425661 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark07(-0.21265559857276864,-0.011968055217356777,-22.48533792170508,0.005984027608678337 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark07(-0.21371075394675007,1.0796636262730308,0.10685537697337504,-100.0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark07(-0.21519691758741505,-0.4303938321610907,-0.6777997046037427,-44.65476866079594 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark07(-0.215618646506044,-1.6362226998952021E-18,0.10265180585725453,31.08077331883606 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark07(-0.2170720639756699,-0.019934574673793923,-21.061986096754012,-42.57914326830263 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark07(-0.2181666237686143,-0.35888884064089194,-0.6600574756931912,0.374626349362034 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark07(-0.21991451022850317,-0.43982902045700006,-100.0,-50.2926145644729 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark07(-0.22128561952299286,-0.44257123904598566,-100.0,0.22053940286624932 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark07(-0.22158744973470637,-0.44317349529415967,-17.95101554037708,37.964483774376156 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark07(-0.22512502823491864,-0.39244933974798224,-130.0847367774277,-125.71300907139374 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark07(-0.2253923296215618,-0.45078465924312344,-65.77974617565572,68.1654518631693 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark07(-0.22613177668100626,-0.4522635533620124,-0.6723322750569452,-99.49189537679993 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark07(-0.2273982384090083,-0.4547964768180165,-54.22483798911152,-51.968221909914476 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark07(-0.22764780280037655,-0.4552956056007528,0,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark07(-0.22938011730711674,-0.45876023461423343,-0.67070810474389,-65.51260290551409 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark07(-0.23061468217953787,-0.02118448931443741,0.11530734108976894,-0.7748059187402295 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark07(-0.23155731060840912,-4.8474642257503685E-15,-54.6105967051034,0.7853981633974507 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark07(-0.23165479718927606,-0.46330959437855207,-0.22819190305342485,80.19493342748468 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark07(-0.23182795621484034,-0.46365591242968063,-0.6694841852900701,99.9779559301123 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark07(-0.2330038588325617,-0.4043714005855189,-0.6343760642386519,63.03401264176345 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark07(-0.23419526027988358,-0.46839052055976693,-5.556056009950747,18.350711048874015 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark07(-0.23499441773933002,-1.1102230246251565E-16,-64.63453871891831,-2165.586711825891 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark07(-0.23599539098657188,-0.23910387943828335,-0.6674004679041623,-0.6658462236783066 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark07(-0.2365726649173544,-0.34076902998414615,0.1182863324586772,67.71462657239789 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark07(-0.24081809012149333,-0.4816361802429866,-0.6649891183367016,15.826795023389918 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark07(-0.24091832287324746,1.0619456211264513,-70.36390763880253,100.0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark07(-0.24150242908327427,-0.39687490321309143,-0.5786996204170349,0.983835615003994 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark07(-0.24244558713522363,-0.2131275543844566,-73.96000755077321,0.10656377719222832 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark07(-0.24246572719201384,-2.6469779601696886E-23,-69.40558939588794,-31.86991521010469 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark07(-0.24317117840861435,-0.48532562126269146,-53.80498763957955,-109.71506565132918 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark07(-0.24747365807865304,-0.49494731615730597,-0.6616613343581217,0.24747365807865232 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark07(-0.2489770090842205,-0.4979540181684404,-5.45174726045607,-29.65801919476617 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark07(-0.24922318247915073,-0.039797269151651854,-6.422385481069633,53.42697373936748 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark07(-0.24948084376139312,-0.4989616875227861,-100.0,7.033591362750841 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark07(-0.2521454777510457,-0.504290955502091,-33.765000965206994,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark07(-0.2525657820880891,-0.505131564176176,-100.0,-81.34519399730824 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark07(0.255258852147649,0.6244169777342911,-0.9131149132698395,-11.311937705767633 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark07(-0.2556234393403072,-0.4557661002017757,-0.5883462585617723,-14.811439780859653 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark07(-0.25594370311720915,-0.5118874062344152,0.12797185155860458,-2191.6480244890718 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark07(-0.2593723566076112,-0.4972994591682795,-0.6557119850936427,0.24864972958413978 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark07(-0.25938258661207003,-3.815896102411402E-13,0.12969129330543794,-38.75234751132953 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark07(-0.25963117709903116,-1.1102230246251565E-16,-58.03067936450167,1.1420108003676765 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark07(-0.25976272905292047,-0.5020020146128465,-0.655516798870988,75.91005301651964 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark07(-0.2599626347303691,-0.20241965006504667,-22.52976320331374,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark07(-0.26012622261743323,-0.37474700069744954,0.13006311130871656,0.1873735004821481 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark07(-0.26130208187504855,-0.522604163750097,-38.09031818796201,0.26130217996436816 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark07(-0.26177116309684756,-0.5235420264835976,-57.70078058778529,74.4031965472264 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179935653741104,-0.523598713074823,-68.3540877017403,9.927451355467525 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993795255158,-0.523598759051031,-100.0,-100.0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993872836155,-0.5235987745672309,0.13089969364180776,-0.5235987761138328 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993875428233,-0.5235987746527998,-14.791567867527055,-0.5235987726121591 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877495264,-0.5235987145968546,-0.6544984693784683,-0.523598775598451 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938778059325,-0.5235987754616416,-0.6544984695071516,-0.5235987755966962 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991398,-0.5235987755982785,-85.50691909948831,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991449,-0.33574975542415275,-100.0,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914735,-0.09500759801526237,-72.76827450183092,-50.78228581336117 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914774,-0.5235987755982952,-100.0,1.0471975511965959 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark07(-0.261799387799148,-0.5235987755982959,-5.058646298792425,0.26179938779914796 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991487,-0.5235987755982973,-0.2553542830911393,0.26179938779914863 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.02649379294769945,-0.6544984694978737,0.01324689647384969 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.4536593052576835,-60.879598490483744,-29.46649339594834 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.5044190638383395,0.13089969389957457,-46.77529595686569 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.5203687676204416,-100.0,61.087280565923315 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.5235352046584673,0.13089969389957457,90.41983708170586 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.5235987752974589,-76.03655390439644,0.26179938777632905 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.5235987755982972,-0.6544984694978737,89.80744123619341 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.5235987755982979,-90.34553495811373,100.0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914935,-0.5235987755982983,0.13089969389957462,1857.7724969881456 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991494,-0.36662684787183336,-38.63836781738921,54.145221100765454 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914946,-0.5235987755982987,-100.0,-14.04921734481912 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991496,-0.016083569813721596,-3.059181734761361,1917.604677012219 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991496,-0.27403772242818736,-10.833593971990556,-73.75094550597558 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914985,-0.5235987755982985,-4.421971777159702,1.0471975511965974 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915,-0.08863511288367623,0.130899693899575,0.4677277601822236 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915,-0.4194660321173075,0.130899693899575,0.20973301605865377 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915,-0.44329500982595926,-67.20254012456462,35.33847960185177 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915,-0.5235987755982983,-82.10776388996906,-0.523598775598299 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.23365759321880714,-0.6544984694978728,-22.96472335149212 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982825,-0.6544984694978728,1.0471975511965894 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982965,-93.02367708208243,-0.2284328008008032 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982983,-100.0,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982983,-12.982156978655397,-52.902166104869394 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982983,-67.07896001770361,-11.941548989839523 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982983,-93.63189552960495,56.991918282148845 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982987,-0.6544984694978733,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982987,-6.501677716375319,-0.5235987755982989 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-1.1102230246251565E-16,-0.22506548552142208,72.62510523090131 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915113,-0.4593003234358941,-100.0,97.61202282181301 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991519,-0.44233246277317145,0.13089969389957545,81.44470744920073 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915307,-0.5235987755982945,-56.120414126457085,0.2617993877991472 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915346,-1.1102230246251565E-16,-0.27397352620715004,-1919.698367572228 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915446,-0.5235987755982984,-100.0,0.26179938779914913 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915785,-0.5235987755982983,0.13089969389957892,99.02315975525588 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark07(-0.261799387799158,-0.5235987755982983,-71.85269496469903,0.2617993877991509 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991598,-0.5214136584350302,0.1308996938995799,25.838335127416133 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991722,-0.49531631724340913,-23.488912154633926,-67.46162915534003 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877992307,-0.008889166275660772,-0.6544984694976275,-0.7809535802596179 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779987505,-0.5235987755966643,0.1308996938999375,-60.196934218549224 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993878009604,-0.30715293677024275,0.13089969390025755,-0.6318216950123269 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938780126205,-0.11042341012547952,-0.4554831960705781,-0.7301864583347085 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993878367372,-0.5235987755983,-100.0,0.26179938779915 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark07(-0.2618098559208353,-1.1102230246251565E-16,-58.38885208814329,-9.041251333064423 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark07(-0.26187795579885514,-0.3559757344231907,-0.6544591854980207,47.8994569070555 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark07(-0.2620875858558594,-0.22288027798131052,-75.89701637937604,27.314562975711027 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark07(-0.2621825620300925,-0.48370531030089614,-99.97776576132082,1.0272508185478983 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark07(-0.2624616631767991,-0.5235987755982983,-49.33998374631112,12.050279872848591 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark07(-0.2625371398633227,-0.41413048247272577,-20.255395703602055,-24.512134269962843 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark07(-0.2626672891035808,-0.5235987755982987,-0.654064518845658,-0.5235987755983018 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark07(-0.263582862453843,-0.2617594207788061,-0.6536067321705272,16.617398620134885 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark07(-0.2636083998905661,-0.5235987755982987,-52.48764043197349,100.0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark07(-0.26361670036615287,-0.5235987755982805,0.13180835018307643,100.0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark07(-0.26383590634103626,-2.220446049250313E-16,0.9173161165679663,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark07(-0.26789047789939,-0.5235987755982983,-12.498560393983404,-53.25158244399397 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark07(-0.2687149284952281,-0.5235987755982876,0.13435746424761405,-90.67759605096519 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark07(-0.26892666151806754,-0.5182617121224309,-24.19120716913171,-0.5262673073362328 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark07(-0.2690042917640086,-2.7755575615628914E-17,-8.185009642186284,-0.7853981633974483 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark07(-0.2709791173130923,-0.5235987755982885,-100.0,99.99121041554045 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark07(-0.27141689215420584,-0.2983752435368032,0.0745938108842008,79.66416224017772 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark07(-0.2726594411071777,-0.4926582668906355,-16.204236706716255,-0.5390690299521306 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark07(-0.2730263418214197,-0.5235987755982876,-0.32062786310744945,-79.04955843946031 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark07(-0.27331238046500417,-0.43489800469479745,-55.68292637135427,67.90583956534283 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark07(-0.27511120084977014,-0.4995818313515955,-67.56485732098366,0.24979091567579775 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark07(-0.2760939333794532,-0.5235987755982987,-0.6473511967077243,56.22214795482876 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark07(-0.2764235024552798,-2.7755575615628914E-17,-67.52904171328224,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark07(-0.28053236809800863,-0.5235987755982984,-0.6451319793484439,-6.681656394336382 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark07(-0.2818168658132064,-0.4873071000492416,-34.9305404428032,-70.59794028418159 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark07(-0.2835169290707862,-1.0658141036401503E-14,-79.65902184673489,72.51450304751202 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark07(-0.2882744170911529,-0.5235987755982969,-43.17117664714477,83.59321697543513 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark07(-0.29253268976466207,-0.014957712836166044,-37.76046667981559,93.86131139183084 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark07(-0.29516674200363013,-0.5235987755982983,-0.5307026263019909,-54.625216592706906 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark07(-0.2954856912302108,-0.5235987755982987,-0.6376553177823424,50.828998386607594 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark07(-0.2959904481152796,-0.0021460006966677863,0.1479952240576398,88.74975054394058 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark07(-0.2975237332855427,-0.5235987755982602,-0.636636296754715,-0.1023064120939439 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark07(-0.29816334409244405,-0.48420126891384163,-86.82194523066981,0.9273620342937675 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark07(-0.2989602299948865,-0.5234989100691554,-21.76421075905371,-648.0866563046633 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark07(-0.3003724301144758,-0.5235987755982987,0.1501862150572378,0.26179950593988355 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark07(-0.3012357635805171,-0.5235987755982876,0.15061788179025815,-53.78307495537555 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark07(-0.30430773661264193,-0.09295106923446975,-0.6332442950911273,5.963637338654401 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark07(-0.3054168125306477,-0.511344295479338,-37.34878525810102,0.25567214773966906 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark07(-0.3059091359004378,-0.0035283350697339648,0.020188480525767716,79.37527945248821 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark07(-0.3060803901671869,-0.5235987755982983,-0.6323579683138547,1.0471975511965974 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark07(0.3065526831246506,0.6132422447050841,-64.68818090470451,-13.469396689035149 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark07(-0.30729962626035984,-0.015693867252136715,-79.31157244005149,-0.7775512297713799 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark07(-0.309532866164877,-0.523577708663258,-0.637874693932531,1.0471870177290772 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark07(-0.3125792310786053,-0.5235987755982987,-3.761423596124135,47.1190636790574 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark07(-0.31310148559206835,-0.3761995058591179,0.15655074279603418,-100.0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark07(-0.31366571659783893,-0.5235987755982985,-0.628565305098529,-0.4351818520947027 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark07(-0.31705626973305356,-0.5235987755982987,-7.574741661548553,-95.81109622471618 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark07(-0.31757642006850784,-0.2796670106924298,-100.0,0.9252316687436631 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark07(-0.3186082206309219,-0.022342261875148414,-0.5950915423479363,-21.409962733190795 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark07(-0.31868417391086284,-2.3780734138976834E-15,-17.671459503220518,1.1890367069488413E-15 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark07(-0.3206688705309623,-0.5235987755982986,-0.6250637281319671,111.81647743473312 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark07(-0.3241735048943003,-0.3982144921060695,-0.1717274229438639,0.20420591014233969 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark07(-0.32624242872516906,-0.5235987755982986,-63.0333656706034,52.32504975317412 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark07(-0.3332460099929582,-0.27153069291066206,-100.0,33.44017874013783 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark07(-0.33406357038713774,-0.5235987739492801,-0.6183663782038794,1.0458826300318158 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark07(-0.33420660123128326,-4.3368086899420177E-19,-0.5717567965781983,63.6159363148739 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark07(-0.33563256968350375,-0.081394036055497,-0.6175818785556965,28.951694486405867 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark07(0.33671484262993473,2.2144498093162874,-92.5270433452814,-11.317401025476958 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark07(-0.33868328449559576,-4.440892098500626E-16,-198.33395396583398,100.0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark07(-0.3400761077961867,-0.5235987755978047,-77.5472728406086,0.2617993877989022 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark07(-0.3402098101163857,-0.5854838415341421,0.17010490505819284,1.0781400841645195 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark07(-0.3428271303775638,-4.340974077926603E-4,-26.261406964233373,2.1704870389633105E-4 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark07(-0.3494514992573232,-8.155503578407254E-6,-77.84160000086935,35.34160653723386 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark07(-0.34967669847532745,-0.5235656803604397,-14.268138600339228,97.03923871456597 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark07(-0.3497019251021757,-0.02723242786194513,-9.473927757914865,0.013616213930972565 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark07(-0.3510545360538657,-3.552713678800501E-15,-86.31536943650234,-0.7853981633974456 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark07(-0.35169371587513765,-0.5235987755982983,-80.26761264917697,1.045882630877174 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark07(-0.3562566719444633,-0.4265505171592646,-0.6072698274252166,31.139044117314143 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark07(-0.36276760259519886,-0.5014694631265596,-0.6040143620998488,1.036132894960728 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark07(0.36576552957354974,0.7315317731188448,-52.712782172351965,-99.99997372394114 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark07(-0.3668301040892472,-0.07412179193846669,-77.6461079466729,-80.01921686244245 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark07(-0.368048948451591,-0.5235987755982947,-56.98470017871961,73.93944057800127 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark07(-0.3690314396158474,-0.5235987755982983,-65.68521783078626,100.0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark07(-0.3710348128850071,-2.7755575615628914E-17,0.18551740644250356,-73.04186762583271 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark07(-0.3717140806500403,-0.3544067670934088,0.18585704032502015,-64.22594230661515 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark07(-0.37382731508293227,-0.5234571565261158,-0.38293958905691394,-75.67475591092644 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark07(-0.37755430930511125,-1.7763568394002505E-15,0.18877715465255562,28.534292452899944 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark07(-0.3779589709649294,-0.5235987755982966,0.1889794854824647,1.0471975511965965 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark07(-0.3787400138771342,-0.3575855199142153,0.1893700069385671,0.17879275995710775 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark07(-0.37991993641102795,-0.44404622381009,-0.3339902253581674,92.0280005607755 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark07(0.38059312557062297,-7.571113624926795E-6,-81.55099309628287,78.99254788646896 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark07(-0.38521191529788834,-0.5133981667599982,-0.5927922057485041,49.780507670018224 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark07(0.38521441372487436,0.7721261523745834,-72.29920847473751,-52.67973790529862 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark07(-0.38597993580211076,-1.0277969145300462E-12,-97.06480269397196,57.337792360679536 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark07(-0.38772727205033003,-0.4616094737065943,-87.11530528387367,75.63577637471107 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark07(-0.3886422723292853,-0.5235987755982987,-35.81885808440836,-100.0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark07(-0.39695904369564994,-0.5235987755982983,0.19847952184782497,72.68235093768182 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark07(-0.39738315543401054,-0.0016401294427733754,0.19848009584560167,8.200647213866818E-4 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark07(-0.3990922446452088,0.530853893287534,-71.9711044874205,94.75541156450994 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark07(-0.40101026104828896,-0.5235987755982972,-0.5848930328733037,-11.517855517359973 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark07(0.4029770924674091,0.8330114427966747,-0.9836597239331306,-143.2682538877841 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark07(-0.40481931680133504,-0.5230957640448882,-0.5829885049964865,-27.933514061659324 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark07(-0.40598706948876306,-0.523598775598283,-99.28496935350572,34.81931997014897 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark07(-0.40637523525588076,-0.5235987755982987,-59.12360321544636,38.56588088486466 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark07(-0.41043262237307676,-0.3010272256594456,0.20521631118653838,-7.954224687425095 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark07(-0.41557960870444166,-1.7763568394002505E-15,-3.5322743128501077,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark07(-0.41613078302860834,-1.1102230246251565E-16,0.20806539151430417,-0.5223096786983589 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark07(-0.4178996604511534,-0.3510055848553082,-0.41903888325543215,45.72524605823909 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark07(-0.41897045049745807,-0.11025846778332621,-0.5555672964938831,-2000.5280775019983 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark07(-0.42169990671678137,-0.5235987755982943,-0.5837649678670341,100.0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark07(-0.4235593422427632,-6.938893903907228E-18,-82.0339676672119,-55.36110216832603 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark07(0.42390842673966733,0.8478169716818637,-73.26155941858458,-24.3395015439321 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark07(-0.42518133852646267,-0.024526105748103412,-2.2329318964027465,98.61754704137446 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark07(0.4254886025576453,0.9273878842482848,-0.23184697106207036,0.3217042212733059 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark07(-0.4270947191720893,-0.5235987755982805,-50.79416030990507,-9.931403652948717 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark07(-0.43398049720035203,-0.01162130259590649,-122.79224524857551,-155.52014309126477 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark07(-0.4355471645104817,-3.218561093468411E-13,-94.81540402848198,0.7853981633976093 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark07(-0.44296322045704173,-3.917310920087402E-12,0.22148161022852086,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark07(-0.4438922860791901,-0.004518312770961238,0.22194614303959506,0.0022591563854806617 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark07(-0.4500010091170741,-1.804357461375167E-14,0.22500050455853704,2.0873996832840818 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark07(-0.45054239835282756,-0.3037720989815035,-0.5601269642210345,-22.253708322328237 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark07(-0.4583354924808916,-2.7755575615628914E-17,-0.5562304171570024,-65.13830339760663 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark07(-0.45839522056696325,-0.5191667927853547,0.22919761028348162,-0.5258147670047708 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark07(-0.46095417451657056,-0.001640411304980786,-0.554921076139163,-1466.000628983253 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark07(-0.46126509216281014,-0.9225301830504222,-0.26723107005603874,-63.94129243379319 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark07(0.4663988564573267,1.067611639503113,-62.24040549016961,-0.5338058197515565 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark07(-0.467424412506491,-0.5144939611703222,0.23371220625324549,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark07(-0.46960900868157296,-3.552713678800501E-15,0.23480450434078648,50.42359556523587 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark07(-0.4709293212390122,-0.5235987755982965,-2258.7790948336255,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark07(-0.47463394072049,-5.551115143466332E-17,0.237316970360245,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark07(-0.4751945899897123,-0.4715858221486613,-33.7481225928739,41.72373347818507 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark07(-0.4752245753321338,-1.26355766269752E-15,-0.39269908169872414,-57.33406592801373 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark07(-0.4754391628156649,-5.32115534759783E-7,-170.60087208492206,-153.23881234113168 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark07(-0.47548638495331863,0.6198235568882591,0.23774319247665932,0.4754863849533188 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark07(-0.47762513999236433,-0.2092511305897672,-0.5465855934012661,0.15571704916350793 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark07(-0.4785482517545601,-0.515244026328736,-24.036092685912525,51.30718771367906 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark07(-0.4786957535532477,-2.7155587265201964E-14,0.23934787677662384,3.2617064857252642 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark07(-0.4844124617303659,-0.5235987755982914,0.24220623086518245,1.047197551196594 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark07(-0.4859641484640975,-0.4254617878555613,-0.5424160891653994,-7.94344769698424 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark07(-0.4861476631528722,-0.5235987755966307,-50.28264474068907,-0.5235987755991329 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark07(-0.4863379239723545,-0.45183365674827697,-79.27005044779112,0.2259168283731361 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark07(-0.48710003805113083,-0.0012689550166578262,-0.5413304723961347,-77.75246877851963 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark07(-0.48738709994001894,-1.1102230246251565E-15,0.24369354997000947,-0.7853903064155815 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark07(-0.48899862485082213,-0.5235681765793905,-161.70287865546203,1.0489035788908625 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark07(-0.48900067631855504,-0.4480012701601202,0.24450033815927752,99.35744489941834 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark07(-0.4965711659574388,0.40013082533146094,-100.0,37.49904527089751 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark07(-0.49866974139547016,-0.5235987755982987,-9.453454932308446,0.13291880938485273 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark07(-0.5078754165177628,-0.5000241507528598,-0.531460455138566,86.99074126927101 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark07(-0.5088664970481519,-1.4208893791798046E-14,-100.0,-0.7853981633974412 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark07(0.5089186628681897,-0.43117320956495986,-100.0,-42.97764387337892 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark07(0.5090750000316808,-0.5235987755969602,-100.0,-0.5235987756003695 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark07(-0.5126107349417359,-1.8093159534841935E-5,-63.84656367140189,-2055.4922050857795 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark07(-0.5129736524766602,-0.048826035224129254,-81.91040327911192,-69.27196630976773 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark07(-0.5143951958915655,-0.36351882106812133,-27.66848638642519,-0.6036387528633875 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark07(-0.515409287507425,-0.0366439614025307,-3.1557621451535534,100.0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark07(-0.5172491992915803,-4.491490941484513E-13,0.25862459964579015,-0.7853981633972237 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark07(-0.5184025780344533,-0.4256091452553719,-37.426824588015236,0.21280457262768593 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark07(-0.5187911461266286,-4.6320526918620836E-14,6.928748910485027,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark07(-0.519183694225168,-1.0909563338307423E-13,-0.07463463222189141,58.99608809273677 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark07(-0.519642833764792,-0.0165873905987468,-0.5255767465150523,1959.6506548940106 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark07(-0.5200824597520622,-2.85740138024912E-15,-223.9306942013349,-2.6645352591003757E-15 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark07(-0.5209543683597072,-1.3500311979441904E-13,-0.5249209792175948,-78.17709032056064 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark07(0.5217806625840289,2.383843412122064,0,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark07(-0.5249108149824521,-0.40505601555403226,-33.757838099383825,0.16838248302613756 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark07(-0.5252302568212345,-0.277817526522536,0.1364941085219229,0.13890876326126803 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark07(-0.5324010624583551,-0.4669550492471146,-96.08476636414778,-99.18049433564697 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark07(-0.5342513238281792,-0.5235987755982978,0.2671256619140895,100.0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark07(-0.5345827508299351,-0.14517159254601156,-0.4926891670591642,-40.69138334588594 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark07(-0.53475524562023,-0.2833338496804735,-74.79379114131763,14.30372935268502 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark07(-0.5359993217977401,-0.17259782531763032,-0.5173985024985782,-95.0443877391449 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark07(-0.5366825124725705,-4.902693417031752E-17,0.26834125623628524,0.7853981633974483 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark07(-0.5409170316011493,-0.33355093770153177,-100.0,0.16677546885076586 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark07(-0.5411222396921845,-3.4829602864817207E-17,-77.57847291890954,-21.207070788040006 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark07(-0.5416333804207447,0.4875295659260283,-0.5145814731870759,-1.0291629463604626 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark07(-0.54187605790259,-9.466330862652142E-30,-42.05847894464186,-0.7853981633974483 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark07(-0.5423862270272798,-0.5235987755982985,0.12819208951649264,100.0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark07(-0.5430577015563955,-1.998079787809753E-13,-0.40030422914911135,42.734169058364316 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark07(-0.5453150218992078,-1.2177430085329254E-15,-100.0,-100.0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark07(-0.5464513271823911,-1.2621774483536189E-29,0.2732256635911954,0.7853981633974483 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark07(0.5481049305806441,1.1784002804261742,-0.27405246529032207,49.926434181722954 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark07(-0.5486707266158973,-1.9721522630525295E-31,-100.0,77.5643778276845 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark07(-0.5488066352621177,-0.5235987755982987,0.27440331763105874,-54.55585660532204 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark07(-0.5495076153095558,-3.0791783062818237E-12,-6.5836935301221695,-34.60505000064965 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark07(-0.5525448308888408,-0.17834329299140034,0.25031780596917597,35.3926458002615 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark07(-0.5530841939645832,-4.4266293550505626E-4,-0.501909297630964,-8.471981273191068 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark07(-0.5546412967662213,-1.2602740701157827E-13,-56.7200331305924,-62.853361568304564 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark07(-0.5548746874118606,-0.22255151600241502,0.2774373437059303,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark07(-0.5550249793736555,-5.913579174693412E-15,-57.847092670531424,-71.05240331645821 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark07(-0.5559184620019312,-0.025719163310127136,-26.286070724316165,21.157407663500532 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark07(-0.5575806864710002,-0.5235987755982947,-13.319723603987478,42.096496917347466 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark07(-0.560206977046351,-1.4210854715202004E-14,-289.5318195239871,133.78412068374786 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark07(-0.5625997532454541,-0.5235987755982987,-82.19987705573881,85.40563423075317 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark07(-0.5662977035405077,-1.758736915035405E-13,-0.4202042619951932,186.9601728368645 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark07(-0.5679023453426559,-0.3514088213308932,-0.5014469907261203,-73.11108661999845 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark07(-0.5681712539985231,-0.47673360082761174,-52.96669502726519,50.84259635227241 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark07(-0.5746153313818052,-0.5235987755982592,-54.420118337314705,123.48854210472595 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark07(-0.5772427213601377,-3.1794754795007E-24,-34.46312662711834,27.63474631937494 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark07(-0.5821386609941225,-0.4749689599224777,0.115746766205525,-41.00204136343115 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark07(-0.5822633298361712,-0.5235987755982983,-83.95031504556411,0.26179938779914913 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark07(-0.5838152638583126,-0.4962836521201289,-0.2523938476729231,41.18620648636134 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark07(-0.5851267886765619,-0.216924894726436,-66.405875443973,-53.87701839729223 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark07(-0.5855997023573366,-1.1102230246251565E-16,-96.91951673166494,78.57555716264146 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark07(-0.5866440015945973,-0.4928715216089685,0.29332200079729864,-0.5292121208813849 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark07(-0.5868233848716043,-0.3765363380726692,-19.97440707298703,-54.14702460795511 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark07(-0.5875372775186718,-2.361495192997756E-12,-0.49162952464312126,2010.2049864920682 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark07(-0.590097152154283,0.0,-50.25816202732744,0.0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark07(0.5931152638786104,2.466031838161274,-7.109779006914637,-29.50734926605151 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark07(-0.5950268891483861,-1.9498366353167328E-14,0.06910775991002671,-0.521076728351857 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark07(-0.5960865500573772,-0.3250601993386202,-15.517657975054036,-0.6202988216503551 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark07(-0.5993772386253028,-6.162975822039155E-33,-100.0,-100.0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark07(-0.5997712518225079,-0.001718201180767806,-100.0,44.93494778875603 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark07(-0.6009079640658973,-0.3318901186262432,-94.90079019299282,0.1659450593131216 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark07(-0.601387119247293,-0.35401500667029406,-0.48470460377380176,-47.081045827915084 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark07(-0.6038271423479954,-0.5235979594068736,-50.81351233693238,1.045882222781438 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark07(-0.6045101085857068,-0.5235987755982981,-30.99556138016851,0.26179938779914913 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark07(0.6056433243120627,1.7607524381721777,-1.0882198255534796,-59.7895504646714 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark07(-0.6063158049309769,-0.041732971928300534,-99.97840712799541,49.27463007061323 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark07(0.6070441169469527,0.523243571652516,-82.77043361286779,-87.18168488179357 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark07(-0.6077371386393171,-1.1102230246251565E-16,-91.7342195637069,31.364164372454276 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark07(-0.6142306177333496,-0.369427723994054,-38.06307134854433,-11.11235239100996 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark07(-0.614722569960224,-2.5858000194161544E-13,-0.4780368784173362,2.0238462048385895 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark07(-0.6148164575310022,-0.5235987755982876,-0.47798993463194717,100.0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark07(-0.616689255788474,-2.220446049250313E-16,-4.912287455193628,17.30915706530731 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark07(-0.6169540370603954,-0.12709819093969937,-96.42691394820312,46.02848743823199 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark07(-0.6212113571172133,-0.5235987755982987,-68.84022258164077,56.54012824663016 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark07(-0.6212904107556154,-0.14603234933467762,-1.2928516947822533,0.07301617466733881 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark07(-0.6217774096588209,-6.891082216641854E-13,-83.13933665174531,88.61442174867334 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark07(-0.6259719953502727,-0.5113681598262879,-68.99409737166287,1.0410822433105922 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark07(-0.6260419803785948,-0.4768154589858693,0.3130209901892974,-28.174869933572136 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark07(-0.6261775205196953,-0.5235987755982876,0.31308876025984755,27.666747781217936 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark07(-0.6309789877745107,-3.6031541222621383E-31,-99.8233680670964,0.7853981633974483 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark07(-0.632576022382863,-0.5235987755982967,-19.428440660519065,73.63866409727208 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark07(-0.6334091709213576,-0.07858412641890922,-175.70593375311716,44.808291437399326 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark07(-0.6369699806944901,-2.4652370888623206E-14,-0.4669131730502033,-86.39058761953982 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark07(-0.640328914293077,-0.5112771005234471,-0.46523370625090976,-0.5297596131357247 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark07(-0.6430047587578733,-4.4408920178798024E-16,-94.23666535801411,2.220446049250313E-16 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark07(-0.6432839386466459,-0.4791210792515485,-89.656128138681,78.87451178693244 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark07(-0.644600336122832,-0.002858925384779586,0.3223001680080952,0.7855127057703903 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark07(-0.647543685528922,-0.5235987755982986,-0.4616263206330018,49.49172328303731 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark07(0.6478054071257622,1.2956115139059068,-88.00014414327632,31.758642425468253 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark07(-0.6531562480147743,-1.5556040848156075E-10,0.32657812400114833,0.7853981633974474 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark07(-0.657905307951667,-0.4429971764192156,-34.58178931643327,-43.87715200151001 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark07(-0.6600156577010723,-0.07466986306368642,-0.45539033454691213,-68.29371429315384 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark07(-0.6633396771005989,-2.9339182243418744E-13,-4.106481632318573,1.7446346441633658 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark07(-0.6673957348713857,-0.5052260248153303,-100.0,99.9981797638836 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark07(-0.6688039579258925,-3.552713678800501E-15,0.334401978962946,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark07(-0.6729147828325712,-1.1102230246251565E-16,-10.668697233896632,98.96281049612205 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark07(-0.673735542396958,-5.421010862427522E-20,-0.026872440717569005,58.94160920896968 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark07(-0.675616476322844,-0.431871976047952,-0.19824450294588541,-43.718013681223276 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark07(-0.6788547035757849,0.1949130948544785,-94.72273187042022,-87.28072863389322 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark07(0.6798148107708811,-1.2820126438567735E-13,-1.1298119064722698,0.7853981633975126 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark07(-0.6826650480420209,-0.5235987755982876,-14.959680973727941,88.22697488949584 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark07(-0.6833888654763465,-0.5232428561584468,-0.44370373065927504,-54.67496065747656 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark07(0.6838217549673306,-3.6094765436871276E-18,-0.6160712200914408,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark07(-0.6842055059628656,-0.36405560117602265,-25.29344776397081,0.18202780058801132 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark07(-0.687827463602742,-0.523571522455612,-31.585109136099987,-90.68595923108573 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark07(-0.6910996230681168,-0.48162107613057825,-18.292150047316763,72.39881492407378 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark07(-0.6923796513877607,-0.05301159319009497,-8.752769858582491,-0.7588923668024008 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark07(-0.6926633259779705,-1.6845809241436777E-14,-74.02693229848325,-87.89265535185933 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark07(-0.6944427174850731,-0.2182335621432894,0.34722135874253635,-1869.340656445912 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark07(-0.6963769761448102,-5.233940466650856E-15,-0.4372096753250432,2.616970233325428E-15 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark07(-0.6974845119989193,-8.881784197001252E-16,0.3487422559994596,49.71334573600665 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark07(0.6978721675716419,1.6624061988295746,-69.87207844134201,-68.40669439772716 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark07(-0.7027011962763651,-0.5235987755982983,-0.43404756525926574,46.788963629751535 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark07(-0.7043288360880919,-0.5235987755982965,0.13089969389957634,-30.334717758361844 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark07(-0.7096611969867439,-2.0605739337042905E-13,-3.2173493689134034,-100.0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark07(-0.7112251460099586,-0.5235987755982983,-17.56381868610212,53.28621194772683 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark07(-0.7118153417749544,-0.5235987755982986,-0.42949049250997107,51.45938745760037 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark07(-0.7133038005610008,-3.048647528331885E-14,0.3566519002805002,43.84894757113077 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark07(-0.7144557280983775,0.13144993249816828,-28.590795928664242,96.04713396379533 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark07(-0.7151551184465503,-0.9688062451069922,0.35757755922327517,45.25188849995029 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark07(-0.7152251316042784,-1.2565541201897474E-6,-0.4277855975953091,23.33720040175023 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark07(-0.7155531882223298,-2.220446049250313E-16,-0.4276215692862833,-27.753809880703937 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark07(0.7168410458188303,1.4830842624676248,-57.002209948378386,-40.801795269980076 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark07(-0.7178143584658727,-0.1479322144308805,-85.24715084755704,-25.999453369743094 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark07(-0.718765980901928,-0.19754601717063464,-50.85557019669548,0.8315424267448561 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark07(-0.7188653549863249,-0.21713767204629764,-100.0,-37.46081451566704 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark07(-0.7209790425394876,-0.0013305096950867186,-0.18873555702223188,32.94619862518077 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark07(-0.721113014711861,-6.8249780221457824E-15,0.3605565073559305,-89.53587524101737 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark07(-0.7223598711444585,-0.3485006682421138,-18.900529249762553,-1790.5818397424655 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark07(-0.722849762569888,-3.1554436208840472E-30,-67.91334390003757,-70.56380145151694 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark07(-0.7233342579237079,-0.5231558873376432,-77.48402632462619,0.2615779436688216 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark07(-0.7242439074545677,-0.5235987755964153,-0.33653803307425045,-18.212433183768795 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark07(-0.7247964137087308,-0.5235987755982988,-0.42299995654308287,100.0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark07(-0.725359442637654,-1.7342900121171023E-15,-0.4227184420786213,-48.93937629931288 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark07(-0.72572301226282,-7.585261411746383E-12,-3.5377574391788835,39.33534285787881 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark07(-0.728970745261682,-1.1102230246251565E-16,-0.42091279076660726,-45.76518114551735 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark07(-0.7315886767135624,-0.08664424287247763,-176.08884799671102,0.045518911938627005 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark07(-0.7319928485679584,-0.031474917606644774,-0.4194026132146033,0.8011356222007748 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark07(-0.7327012238180914,-0.004126258357640625,0.3663506119090457,0.002063129178820313 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark07(-0.7355791109009346,-0.5235987755982983,-16.69686347044418,2041.8579393296197 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark07(-0.7372723397046586,-0.5235987755982947,-100.0,-100.0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark07(-0.7380621927200781,-0.027200088297480055,-0.4163670670374092,-0.5235987755982983 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark07(-0.7390052358456568,-0.22331808569929726,-45.17342068812109,37.33877500188649 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark07(-0.7394537986641416,-0.5226681630150031,-99.99973059072533,-0.5240640818899468 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark07(-0.7430719555021006,-0.2527289344493446,0.3715359462121364,-0.659033696172776 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark07(-0.7444535403526313,-0.5235987755982947,0.05110432648336649,-85.98221114058232 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark07(-0.7452316353463092,-4.595643120647509E-6,-0.07958505354117604,64.52399535175583 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark07(-0.7493072178651927,-0.14894552971182454,-53.52860391662268,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark07(-0.7513845161072293,-0.5216773008401301,-0.4097059053438336,1.0462368138175133 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark07(-0.7521293650557519,-0.5232629636366417,-32.53506941670169,-237.61855820314832 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark07(-0.7523415026863757,-0.4744536428945072,-179.94368441287986,-58.278843657559776 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark07(-0.75237672256787,-1.512553637894598E-9,-0.39473769907227485,7.562768744584503E-10 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark07(-0.7529801649381038,-0.37588108797346914,-0.32509106850244424,18.760065984742372 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark07(-0.7538074029329309,-0.27617003123905254,-161.6689498590437,0.13808504174694342 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark07(-0.756746610158992,-0.523598775598298,-45.98871970232696,1.0471975511966072 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark07(-0.757552110347227,-8.88240284744373E-16,-99.61177326762227,4.441201450581534E-16 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark07(-0.7578189868601756,-0.009337265785461943,0.34452875776713654,-0.7807295305047173 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark07(-0.7587180222928025,-9.511260610340841E-4,-202.11136126447818,122.98408025892545 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark07(-0.7596826756401676,-0.5235987755982934,-0.4055568255773645,1.055059430242159 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark07(-0.7602949563005179,-2.164789184941088E-12,-100.0,90.9225727286975 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark07(-0.7611426012800887,-1.0742552743642323E-10,0.27839972399203894,3.901943530221633 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark07(-0.7639411296428875,-0.32994753141157873,-0.4034275985760045,77.84115907110865 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark07(-0.7649839220163643,-7.322819412329804E-48,-0.39993558722771383,3.661409706164901E-48 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark07(-0.7669452817097872,-0.010550115460532422,-0.4019255225425553,53.459466677309436 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark07(0.7717427965468451,-1.6076734584011056,-49.057090570790194,4.6646632279493305 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark07(-0.7757192982458634,-0.3964377371123698,0.21960087936386635,-62.93010673965972 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark07(-0.778304343853321,-0.024343139410245573,-0.04306014447411355,-64.98222129755536 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark07(-0.778669831599842,-0.0038483916033952206,-0.39606324765683193,-37.68858795514292 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark07(-0.7801054754471117,-3.6036597741339244E-12,0,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark07(-0.7806160801313702,-0.002729272313112823,-0.3950901233317632,-109.16211348106856 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark07(-0.780657865863283,-2.1665164451082146E-15,-173.7011979947619,9.992007221626409E-16 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark07(-0.7817642390515404,-0.28708896240020143,0.3908821195257702,-0.6120312161104808 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark07(-0.7818189627157178,-0.1430051042803212,-100.0,20.956605756432293 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark07(-0.7847424439416703,-1.7763568394002505E-15,-0.39302694142661315,100.0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark07(-0.7848413348499843,-0.191512025912946,-65.84155406040087,8.087194550530329 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark07(-0.7852213809832439,-1.4790019653620463E-13,-0.3926990816987248,52.35929765884136 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981176468219,-0.09562152094343823,-82.90759667075291,-80.36946708224917 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981519073012,-0.0026298048203290433,-43.852536393043636,0.7853981454881869 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633836499,-4.0389678347315804E-28,-30.372925119283032,78.88984351829419 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633911573,-2.220446049250313E-16,-100.0,36.13715446487977 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633952559,-2.917239496942494E-12,-21.09182814976573,1.458619748471247E-12 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633967548,-2.5047079259632948E-12,-66.69068223111411,19.704971961605096 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633972182,-1.7763568394002505E-14,0.3926990816986091,-0.7853981633974403 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark07(-0.785398163397328,-2.358895730617487E-13,-37.53285771953347,109.53023286554097 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633973354,-7.105427357601002E-15,-0.14013735731078789,-58.135552243679584 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark07(-0.785398163397355,-2.5243548967072378E-29,-100.0,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633973768,-3.944304526105059E-31,-34.081814672278966,0.0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark07(-0.785398163397428,-2.267798015210307E-14,0.3926990816987088,73.71489162838425 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974374,-1.4210854715202004E-14,0.3926990816987187,-26.228579563635662 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974385,-4.4110358091900886E-10,-75.34887820057804,0.7853981636180002 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark07(-0.785398163397441,-0.10652876333503804,0.3926990816987205,-64.96769798064221 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974421,-1.328694483025831E-5,-0.39269908169872725,50.999895845903595 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974438,-2.1348797549709598E-7,-0.3926990634939077,-58.6847057101062 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-0.3667712192595308,-120.74752509625269,-100.0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-5.382643206707633E-13,-100.0,63.98298914435637 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-7.105427357601002E-15,0.3926990816987228,-61.713674361840575 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-8.881784197001252E-16,-20.628421852146886,40.03431192661872 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974474,-0.30670904651364356,-19.335732638081325,-30.857521968375252 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974474,-1.566559573192067E-15,-76.69340087058382,4.8904378765899 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974474,-1.790439877011645E-15,-92.99622056541303,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974475,-2.9352310895051986E-14,-0.39269908169872453,-13.276574215434959 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974476,0.0,0,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974478,-7.103400261908561E-7,-87.24713568322174,-1701.4302607560323 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-0.22717839734255296,0.39269908169872414,44.15838637464976 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-0.45451009029054984,0.12499318941601417,100.0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-1.7763568394002505E-15,-98.29474609561136,-38.50988967808823 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-7.503582885772798E-9,-58.23444045909452,24.034143418561513 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974484,-2.52371730430056E-15,-0.39269908169872414,-0.7853981633974471 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974491,-1.7763568394002505E-15,-0.10312161464972991,-47.207163301967704 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974492,-0.2666729286462065,-8.42426024891303,-13.567331298988458 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974492,-0.42292007727593683,0.3926990816987246,1.5861326722458386 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974492,-3.6940487290744764E-15,-71.9385180688235,0.0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974492,-4.276321421700601E-14,-3.630531849415732,1.2955964043357329E-14 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974499,-3.552713678800501E-15,0.023840329019378714,-59.770427284869854 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark07(-0.78539816339745,-0.5235987755982987,-100.0,46.84173136115055 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974514,-6.994897214856647E-15,-0.3926990816987226,176.7122010413729 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974527,-1.071143174158351E-12,-19.86192426766985,-0.7853981633969127 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974543,-1.221943077516125E-14,-1.0455881055783856,-0.7853981633974422 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974563,-2.8421709430404007E-14,-18.686318427532186,-80.01531794797799 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974669,-0.08226346100193693,-100.0,80.81217654208261 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974745,-0.03239828120172237,0.39269908169873724,-21.97494941072725 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633975007,-0.015947361940997946,-75.7957296106874,-80.22661153674369 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633975025,-1.1368683772161603E-13,-37.51835078548418,-1.8907365158884062 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633975979,-2.9970899117643227E-13,-57.75370223703687,-12.070896078037837 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633978613,-8.277822871605167E-13,-0.39269908169851775,100.0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633982192,-1.6261401941189978E-12,0.3926990816991096,100.0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633983332,-2.2054244129711273E-11,-73.20974900501392,-70.02592670258154 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981634018163,-8.736615957122665E-12,-75.1805164449861,-12.601191227574233 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981642809751,-1.767053759217107E-9,0.39269908214048754,-45.46780046730575 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853984934729779,-9.525604099836427E-7,-93.14199389046493,0.7853986396776532 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark07(-0.7854079387778345,-1.955076077265012E-5,0.08098668558845445,31.42181731701692 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark07(-0.786226539130617,-0.4089354988978453,0.3931132667188402,-0.5809304139485256 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark07(-0.787055161579785,-0.0033139963646734976,-74.53072944082939,81.83158586191227 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark07(-0.7873451371752443,-0.007443141552048616,0.3936725685876222,0.0037215707760243077 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark07(-0.787626359956207,-0.0046030864081291496,-59.96149947942128,39.27223560776821 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark07(-0.7880679778813439,-0.005345191480145759,0.39403398894067193,0.7880707591375211 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark07(-0.7892798282411562,-0.523598775598298,-0.3222339999502708,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark07(-0.7909932893908351,-0.014632040325594176,-0.3899015187020307,89.97105363951346 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark07(-0.7927388057124247,-0.5235987755982987,0.39636940285621236,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark07(-0.793214379940784,-0.3528656654207359,-29.698673951778197,29.82490574470137 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark07(-0.7940591934378053,-0.23002811401881515,0.39702959671890264,28.3893631981562 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark07(-0.7944918426551493,-0.018187358530709085,-0.38815224206987364,3.937399416572158 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark07(-0.7971769932528305,-0.5226469934514454,-12.777442918387345,1.046721660123171 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark07(-0.7990397982257882,-0.027283269656680407,-46.35611798102566,0.013641634828340203 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark07(-0.8010896828893408,-0.13803456821013663,0.3951017101719856,-31.681134784396747 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark07(-0.8024576436420349,-0.5235987755982947,-25.176804356565164,25.3295175633136 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark07(-0.8038214180103783,-0.2543703783251475,-100.0,55.49684804124588 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark07(-0.8064790210521693,-0.0421617153094509,-100.0,-63.029974139038224 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark07(-0.8069523858915062,-0.10664574142508926,-158.13389034903972,-43.10107795791225 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark07(-0.8089552619363518,-0.2940103495297022,-0.3809205324292724,-94.71015456662096 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark07(-0.8110708683281168,-0.5211877340923067,-0.3798627292333894,-0.524804296351295 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark07(-0.8120020125481263,-0.05885734326264984,-49.34073197263745,0.8148268350287732 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark07(-0.8140380824584059,-0.057279838121915484,-0.3783791221682453,92.25831752678066 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark07(-0.8148545875602854,-0.3329541185393056,0.4074272937801427,-24.995153479039278 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark07(-0.8158083381637989,-0.06082036653813652,-0.3774939943155502,-92.75396872913618 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark07(-0.8193175388534977,-0.06783875091213602,-0.37573939397069944,95.52189942998258 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark07(-0.8193339820833675,-0.06849404948713245,-0.37573117235576453,-28.716001238045028 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark07(-0.8193896091899173,-0.09469705458119648,0.40969480459495794,0.047348527290598234 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark07(-0.8208422228716532,-0.5235987755982983,-19.2834035605603,65.41138176534659 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark07(-0.8227767391191793,-0.33396940258555435,0.41138836955958963,0.1669847012927772 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark07(0.8246232848878794,2.3791274656958215,-1.1977098058414128,-86.26252107155858 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark07(-0.8254363457797504,-0.5235987755982947,-20.303988383557375,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark07(-0.8268335617952228,-0.5116226997035155,-150.4071576771964,-93.89874899089463 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark07(-0.8272946219259171,-0.5235987755628633,0.41364731096295854,1.0471975511788798 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark07(-0.8304214806762502,-0.09004663455760842,-21.805492974629544,-0.7403748461186441 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark07(-0.8316948043919583,-0.5235987755982987,0.2081633429392964,25.066633258409972 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark07(-0.8362867737241764,-0.523598775295174,-53.015210925246436,56.633679920984505 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark07(-0.8366696607328188,-0.1025429946707413,0.41833483036640917,14.788204569773276 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark07(-0.8383075898206291,-0.4326771019897026,-13.200921567666626,53.62341366199687 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark07(-0.8398239055625467,-0.10885148433020451,-26.563073475712734,99.43092879706877 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark07(-0.8409601457965125,-0.5235582128210762,-100.0,31.645124060575686 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark07(-0.841541300584201,-0.31246838343917516,0.4207706502921005,-95.83233294702492 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark07(-0.8421160808105315,-0.11343583482616668,-0.36434012299218255,41.68149484856632 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark07(-0.8442021968411723,-0.5235987755982983,-34.25278069739667,1.0471975511965974 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark07(-0.8458511905086216,-0.25090925727070873,-0.36247256814313744,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark07(-0.8518473327892168,-0.2831831449237711,-0.35947449700283995,0.14159157246188556 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark07(-0.8533755306610855,-0.5235987755982947,-45.92768157070291,1.0471975511965956 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark07(-0.853902049916027,-0.503391948588658,-0.3584471384394172,-90.22286291068879 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark07(-0.8555281588218352,-0.5235985821763244,0.4277640794109092,0.2226277017169221 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark07(-0.8567661224301311,-0.14273591806537747,-91.25256279415157,98.98083598200529 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark07(-0.8585473332462854,-0.5235987755982987,-92.75396377634458,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark07(-0.8607648747170801,-0.5026960256632991,0.43038243735853965,1.0367461762290977 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark07(-0.8627817886744324,-0.1743691630161022,0.4313908943372162,8.465370611385612 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark07(-0.8628187344631235,-0.15484114213135133,-0.3539887961658863,51.84431673701902 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark07(-0.8648098139248339,-0.5235987755982984,-139.61957867182426,100.0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark07(-0.8662710088056462,-0.1617456908164934,-0.35226265899462517,0.8662710088056951 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark07(-0.8671459649727562,-0.3720373797879557,-30.577226565197815,0.18601871405574438 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark07(-0.8719746345750389,-0.5235987755982983,0.4359873172875195,2041.0496899755399 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark07(-0.8729160599919346,-0.5235987755982983,-88.33011218623543,-90.48529792927623 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark07(-0.8758036254823816,-0.5235987755982853,-89.42099097951721,100.0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark07(-0.8768841802407198,-0.5197294613016303,-70.5362668404926,49.95225168062135 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark07(-0.8780510598223608,-0.5235987755982983,0.3229465517173619,79.99704311176939 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark07(-0.8797483501514642,-0.45524209148809924,-89.83555026317663,1.0130192091414978 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark07(-0.8803879400256692,-0.523598775598298,-100.0,1.0471975509493703 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark07(-0.883597896928704,-0.5235987755982987,-87.90649097313901,1.0471975511965976 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark07(-0.883993817502932,-0.3557160066832137,0.441996908751466,87.5374364247785 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark07(-0.8854014011739412,-0.3796822321587048,0.44016082093803655,70.09268982248267 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark07(-0.886873331933395,-0.2029503370718943,-56.069421065232,1923.3733157088477 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark07(-0.8875863602368061,-0.20484173401452258,0.29870288963740554,0.8891339507241388 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark07(-0.8879040301004841,-0.30702591072006624,0.08155067588368146,94.29662957589507 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark07(-0.8889640210623795,-0.5235987755982988,0,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark07(-0.8899607979024258,-0.5168520673424906,-15.345656513968521,100.0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark07(-0.8973486348642066,-0.22390094293354418,-0.336723845965345,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark07(-0.8980742768292878,-0.5176595966057409,-87.3316842859104,1.9971038639235417 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark07(-0.898778284383251,-0.5235987755982987,-51.04737213492487,-20.549913616683884 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark07(-0.9026727337112329,-0.2719472532001547,-49.1323787733341,0.9213717899975257 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark07(-0.9039182595247177,-0.3529887013963562,-3.1887180314049743,-24.774188132281438 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark07(-0.9057080637891843,-0.2486733483902889,0.45285403189459217,0.9084199172731707 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark07(-0.907333392176616,-0.2438704575583358,-99.99999999999996,-0.6634629346182803 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark07(-0.9110186766503044,-0.4472182256076261,0.4555093383251516,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark07(-0.9142607304492314,-0.5235987755982983,-80.21241054353246,-0.5094443789186665 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark07(-0.9163678907456885,-0.2619394546964809,-0.327214218024604,-83.90802309195061 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark07(-0.9178578214417769,-0.5235968277098112,0.4589289107208884,0.26179841385490565 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark07(-0.9204804433925834,-0.2768523103192648,-17.65226070763451,-34.29859890479896 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark07(0.9206294206788576,-0.5235987755982988,-52.383131662608825,84.48152530764852 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark07(-0.9216492866150126,-0.5219127185498448,-46.56082244586868,-100.0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark07(-0.9222182238666872,-0.5194514544159561,-0.3242890514641048,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark07(-0.9233626644532498,-0.3273453727583586,-54.93798533744271,3.8437418734922346 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark07(-0.9236063054932941,-0.4792027595416689,-1.9382718890952169,1.0249995431682828 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark07(-0.9281077193717171,-0.4804861654671623,0.46405385968585855,90.78084726666484 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark07(-0.9290149322981837,-0.3781474845440855,0.4645105206739518,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark07(-0.93120615626219,-0.5235987755982987,-0.31979508526635314,-1918.847645618754 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark07(-0.931555507763214,-0.42135408951445535,-26.572939273480188,-46.10077390040672 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark07(-0.9337351486595897,-0.5211557898808635,1.2522657377272433,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark07(-0.9377842592920553,-0.5235987755982983,-0.2617993877991497,0.26179938779914913 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark07(-0.9383987352413464,-0.5165826472062801,-74.20094300721895,0.6445879845229384 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark07(-0.9385667077722829,-0.3116052282866077,0.46928335388614145,0.9412007775407574 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark07(-0.942490419589437,-0.5235987755982987,-15.632274724846086,-24.819636908716475 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark07(-0.9435941067143239,-0.5235987755953067,0.47179705335716193,100.0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark07(-0.945822878413986,-0.5186244762027371,0.472911439206993,-85.56487771270908 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark07(-0.946225756373341,-0.5235987755982947,0.4731128781866705,-52.78228268349471 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark07(-0.9489275515158366,-0.5235987755982987,0.3807598402296746,35.15743438062264 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark07(-0.9503007661360542,-0.4589805923624879,0.4751503830680271,18.093649256594727 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark07(-0.9508681793492073,-0.5235987755982987,-75.27979621178997,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark07(-0.951577392883867,-0.520423400343474,-0.3096094669555148,68.79957810482952 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark07(0.9527378506565718,2.081537397255041,-1.2617670887257342,8.384008694709701 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark07(-0.9565754615881681,-0.5197933013892442,0.17334891449530243,50.71197725176104 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark07(-0.9588869167523264,-0.5235987755982983,0.4794434583761632,1.0471975511965974 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark07(-0.9597810443723751,-0.5235987755982946,-63.5408444093425,1.0471975511965956 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark07(-0.9606821674974226,-0.3505680081999495,-62.38479317834434,0.6763221027698398 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark07(-0.9607147748139802,-0.3506337400298973,-77.27404809630423,-78.36223208304342 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark07(-0.9631803415262877,-0.5179219612971713,-40.94641557990522,100.0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark07(-0.9632802334889405,-0.3947077429791059,-0.21122078229242075,6.498579919125742 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark07(-0.9655495962219345,-0.48001648827830523,-100.0,-0.5453899192582956 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark07(-0.9664228670820474,-0.5185611037658651,-0.3021867298564245,2016.40355456104 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark07(-0.9666294440112885,-0.3633208450057584,-0.2955424268189015,0.9670585859003274 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark07(-0.9689813436664834,-0.38967282167844614,-0.4361978237561617,0.19483641083922304 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark07(-0.9696069293006693,-0.5235987755982987,-67.36683108670849,-7.624140927308442 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark07(-0.971401974663419,-0.40715965643548835,0.4857009873317095,-100.0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark07(-0.9717317922949827,-0.43926185137320517,0.4689710231072538,-7.4866130642662645 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark07(-0.9722989256195812,-0.5235987755982912,-0.2640378545575775,-11.708937186307708 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark07(-0.9733065958957923,-0.968227558906044,0.48665329794789614,-23.86464964570872 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark07(-0.9735272368248129,-0.38858758905199875,-0.2986345449850418,-18.409875082719964 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark07(-0.9782725757728329,-0.5235987755982965,-53.61757055072604,-81.21406207545282 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark07(-0.9783933589862305,-0.5235987755982947,-34.10377643425183,76.96614014309216 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark07(-0.9814930533340821,-0.3921903253971597,-47.96436225075363,-66.4060430181753 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark07(-0.9817325823468231,-0.5030024170615235,-18.412148707394184,93.25265436699614 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark07(-0.9820566591604396,-0.5180591020013318,-100.0,-24.080911220867925 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark07(-0.9867531982329598,-0.40271006967102735,0.4933765991164799,-52.83992336789769 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark07(-0.9869216093041066,-0.5144293335019336,0.4934608046520533,7.15937217330747 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark07(-0.9874095005857145,-0.5091194348400849,-71.57171067760142,100.0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark07(-0.9878980836524751,-0.4304885525978931,-80.62555823936685,19.297280925129243 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark07(-0.9882690676385744,-0.5235987755982983,-152.46899969911328,-0.5235987755982991 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark07(-0.9885698653732788,-0.40634340395166146,-76.75090111756202,-42.64403185583436 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark07(-0.9892239218808158,-0.4076515169706386,0.4946119609404079,-100.0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark07(-0.9893729400507283,-0.4079495533065618,-54.95021823628245,42.7314548638266 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark07(-0.9901862321987944,-0.4660535777816102,-82.96469168066736,-18.006266747011843 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark07(-0.9910976823824942,-0.5235987755982986,-23.754469825348227,0.26179938779914924 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark07(-0.9919964225596389,-0.5235987755982983,-0.2893999521176288,27.077916926406793 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark07(-0.9927339824884166,-0.5235987755982987,0.4963669912442083,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark07(-0.994329752322265,-0.5235987755982983,0.4971648761611325,-79.47433048686378 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark07(-0.9952708947487553,-0.503376485675561,-41.74408591379384,-0.5892646352165922 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark07(-0.9972653060123884,-0.4237342852436014,-37.9996499444924,0.21186714262180073 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark07(-1.0003921202247614,-0.5235987755981188,-0.28520210328506745,1.0471975511965077 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark07(-1.0009579235959478,-0.5113683050044688,0.02065719640195951,100.0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark07(-1.0013404355338433,-0.5231064011177848,-82.90374116270381,-100.0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark07(-1.0023693864523242,-0.43394244610975513,0.5011846932261594,-14.244107539568091 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark07(-1.002424231668829,-0.5235987755875541,-138.7095795239983,26.603383520042893 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark07(-1.0031380442354751,-0.4354797616760542,-42.52297713770098,-90.62191096232961 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark07(-1.0032015175075946,-0.5235987755982663,0.5016007587537973,-0.5235987755983151 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark07(-1.003341157915833,-0.5235987755982928,-0.2837275844395317,1.0471975511965947 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark07(-1.0041646116114462,-0.43753289642799603,0.5020823058057231,71.21014925646182 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark07(-1.0048401424164202,-0.522541169667304,-0.28297809218923814,-33.752624109074546 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark07(-1.005555250074759,-0.5235987755982947,-33.772330610769714,98.56717987816529 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark07(-10.06106707292649,-0.5235987755983018,-84.62986069628965,0.2617993877991509 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark07(-1.0067739941871963,-0.5235987755982985,-35.89294726269551,0.26179938779914924 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark07(-1.00812693618504,-0.4991180435667588,-13.210646169797666,-100.0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark07(-1.0088054402870583,-0.4640223174407355,-100.0,-0.5533870046770806 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark07(-1.0102620861110188,-0.5134348030981581,-0.28026712034193885,66.07633338238662 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark07(-1.010350773961527,-0.5229266539880081,-56.97168661457555,-81.7289120734702 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark07(-1.0103674593021015,-0.5235986844565251,-23.267312921270204,22.000247052723765 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark07(-1.010530801682922,-0.45026527657094834,-0.28013276255598074,1.009215881360496 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark07(-1.0124103967283133,-0.5235987755982983,-0.04110816906758034,21.738602201695024 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark07(-1.0136822463093174,-0.521425245574062,0.4740000499975145,54.558784115926954 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark07(-1.0156943028099459,-0.4715092728908825,-56.400560249433305,-6.226470574319714 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark07(-1.016463820900185,-0.4621313150054837,-63.63996447498485,54.6162094151966 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark07(-1.0165089646179997,-0.5235244010500444,0.09947137590265509,38.60356950779991 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark07(-1.0178581081866767,-0.4977181454745138,-25.294593254175624,-52.10880006387772 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark07(-1.018585162437181,-0.48804907801299635,-67.05173943345349,-61.68068119134573 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark07(-1.0191709484079836,-0.4679669948275486,0.5095854742039918,0.23398349741377428 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark07(-1.0196340878247216,-0.468471848854549,-6.7723824763222495,1685.9186274787141 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark07(-1.0197152368349975,-0.5235987758043699,-173.58715443323047,0.26179938779915046 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark07(-1.0197527202681151,-0.5235987755982987,-0.2755218032633907,-84.71463618704014 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark07(-1.0201624147894903,-0.5235987755982987,-60.56596601886287,6.771984836822641 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark07(-1.0201997418158906,-0.4696031568368861,-24.622933511883446,0.23480157841844304 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark07(-1.020407029712612,-0.5235986155438958,-0.2751946485411422,4.463914105851623 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark07(-1.022410770104923,-0.5233421644157598,0.511186613516933,0.2616710822078798 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark07(-1.0241478135129747,-0.5235987755982965,0.5120739067564871,88.50146146384594 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark07(-1.0246637469946134,-0.5235987755982987,-6.572353926656561,0.26179938779914935 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark07(-1.0249317584252542,-0.4932656955565103,0.49443533121037103,-76.67718868921209 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark07(-1.0254227401393576,-0.4800491535864112,0.5127113700696788,0.24002457361968885 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark07(-1.0257160794301816,-0.48063583206546673,-15.215415692393696,-61.40974148686433 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark07(-1.026664488600658,-0.48253265040642057,-92.62741052623466,2057.401697818237 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark07(-1.0266847268183157,-0.5235987755982876,-72.8489040891926,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark07(-10.272014091246813,-19.705625718466454,4.350608882225958,9.852812859233227 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark07(-1.0286765207162976,-0.48655671463769873,-26.27956703035278,-1690.468244461807 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark07(-1.0299290971080404,-0.5164348657540246,-0.27043361484342804,0.25821708696285695 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark07(-1.0305890230394963,-0.5230223721632864,-0.27010365187770013,0.26151118606116147 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark07(-1.031539937737712,-0.49228354868053015,-0.2696281945285923,-33.759693743176605 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark07(-1.0326854347398593,-0.523583645999728,0.5163427173699296,-0.5236063403975844 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark07(-1.0327637695056586,-0.5235987755982943,-115.14118685180011,-99.94554558261574 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark07(-1.03465855514461,-0.5097796777007586,-19.805617168839728,-53.72778191629988 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark07(-1.0361701946163704,-0.5015440624378444,0.3009279646045613,-99.98659636189582 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark07(-1.0370424336228143,-0.5048094140947649,0.5185212168114072,6.843979007096033 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark07(-1.037097870616045,-0.5234059415334231,-8.787569683879667,146.3321228707776 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark07(-1.0377598769877818,-0.5062389860582895,-0.2665182249035574,-0.10948032401449509 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark07(-1.03781338669868,-0.5067229521609483,-0.26649147004810825,7.250762807074176 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark07(-1.038181942290487,-0.5235987755982983,-0.2663071922522047,-51.13953273506431 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark07(-1.0382157883041718,-0.5219835657372974,-39.04501043368714,0.26099178282402247 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark07(-1.0382881407069315,-0.5057799546189672,0.5191440703534658,-86.13973170441535 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark07(-1.0388427753224324E-11,-1.5965007094110087E-13,-49.41685411704012,-0.7853981633973685 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark07(-1.039309050540442,-0.5235987755982947,-99.77713235093027,70.86234830840917 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark07(-1.0394364444868962,-0.5235987755982984,-45.0403008330626,0.801719644883504 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark07(-1.0395286624981028,-0.5235987755982983,-0.26563383214839686,-39.60012821155458 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark07(-1.0405493593277457,-0.5103031291564577,-0.26512348373357536,11.295217591158918 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark07(-1.0405779697551412,-0.6380867944425473,-0.08357984935238465,-27.173736898173857 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark07(-1.0417816450582937,-0.5127669633216911,-62.99374366029751,1.0883386880166892 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark07(-1.0428428282497684,-0.5235981910135789,-0.263976749272564,-43.72285967076162 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark07(-1.0437932110757568,-0.5167900953567106,0.5218966055378784,50.51917832670312 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark07(-1.0438206094516786,-0.5235987755982983,-47.33666294527625,-73.8764944248218 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark07(-1.0443950505657502,-0.5235987755982987,-5.839050326411221,1.0406817134339594 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark07(-1.0450185795387834,-0.5235987755982983,-12.564337692118855,-39.8717874349463 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark07(-1.0451769754315143,-0.5195803261227124,-80.85658223269182,15.073816796007803 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark07(-1.045268613177754,-0.5197408995606122,0.522634306588877,23.710612863444524 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark07(-1.0454953152882285,-0.5235987755982097,-0.262650505753334,-0.5235987755983434 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark07(-1.0462736421044758,-0.5227322342374146,-42.453565962019034,25.176741497957675 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark07(-1.0463389991570895,-0.5235987755982985,-0.26222866381890353,167.62829258239316 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark07(-1.0463507527856242,-0.5235987755982983,-0.2622227870046362,-78.32297294510533 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark07(-1.0463715077727593,-0.5235987755982952,-28.484413295546943,-33.74046748034822 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark07(-1.0468679232904174,-0.5229395197859392,-48.465493407647244,1.046867923290418 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark07(-1.0470410601993212,-0.5233435112135948,-29.404853207539993,0.2616750659162984 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471067486392274,-0.5234809754961799,0.5235533743196137,0.26174048759725804 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471282942619322,-0.5234606165888152,-100.0,80.42246085366216 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471963393980788,-0.5235963520019212,-32.31420684290016,100.0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197341415576,-0.5235987755982939,-73.33571054729501,1.0471975511965952 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471974628179206,-0.5235986209831821,-100.0,1.0471974738890393 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975344581042,-0.523598742121312,-50.86806798380311,-34.80710473062771 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975510601528,-0.5235987753305112,0.5235987755300764,1.0471975510627038 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511958975,-0.5235987755982935,-0.2617993877994995,-0.5235987755983015 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511961844,-0.5235987755974748,0.5235987755980922,45.436473999127514 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511964131,-0.5235987755982805,-0.6585401196567112,0.26179938779914025 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511964837,-0.5235987755982963,-3.944998320575799,1.0471975511965965 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965246,-0.5235987755981906,-36.53313841167962,1.0471975511965435 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965503,-0.5235987756445911,-72.0750884873695,-2196.8481158912464 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965714,-0.5235987755982979,-100.0,100.0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965892,-0.5235987755982985,-0.2617993877991536,0.2617993877991492 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965894,-0.5235987755982939,0.5235987755982947,-60.00035723334602 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196591,-0.5235987755982987,-84.12969499912249,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965923,-0.5235987755982884,-34.33944339972561,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196593,-0.5235987755982896,-8.417090414704518,100.0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196593,-0.5235987755982947,0.5235987755982965,-100.0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196593,-0.5235987755982947,0.5235987755982965,-14.662304003498441 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196593,-0.5235987755982986,-95.6403887105203,38.49820608097562 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965947,-0.5235987755982947,0.5235987755982974,-0.5235987755983009 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965947,-0.5235987755982947,0.5235987755982974,-1.0292082571717458 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965956,-0.5235987755982984,0.5235987755982978,-75.18419865452425 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982967,-0.26179938779915,32.464439191839 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982967,0.4705033817992219,65.2771744493765 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982968,-34.3367040914755,20.3026249501256 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982974,0.5235987755982983,4.242820768626786 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982977,-73.31992386112483,-51.18312491480956 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982983,-0.2617993877991509,-10.780742904250893 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982983,0.2814737943658271,75.33287210660076 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982983,0.5235987755982983,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982983,-10.186239644211323,1.0471975511965974 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982983,-27.045359410824233,2208.8347124464144 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982984,-0.26179938779915,95.18075409579642 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196597,-0.5235987755982983,0.5235987755982985,-59.22411747975865 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982985,-0.2617993877991496,0.32910344423559174 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982985,-0.9280341953733988,100.0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982985,-100.0,0.26179938779914835 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982987,0.5235987755982987,-0.5235987755982989 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982987,-24.066943391348556,0.4357225143231911 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982987,-34.615432712612716,1890.0046557253986 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark07(-1.0501667169702009E-5,-9.588960535843424E-13,-0.7853929125638635,95.64019040304467 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark07(-1.0631545072302808,-0.5555126876656657,-99.99999999985215,0.2747860427529825 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark07(-1.0700007546680325E-10,-2.1400015079741406E-10,-0.7853981633439483,1.0700007546660117E-10 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark07(-1.0775486016363307,-0.5843010380835567,0.5384680333411178,0.29215052221023907 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark07(-1.085368028297673E-4,-2.17073605659534E-4,-87.96161653717219,19.378667830372656 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark07(-1.091705594883135,-0.8023038568866262,-0.23954536595588094,-83.62632913155076 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark07(-10.970937358937611,-21.683973292268977,5.485468679468806,11.60548098587999 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark07(-1.0995473050112804E-24,-8.845333737265597E-41,-0.7853981633974483,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark07(-1.1061389470676672E-17,-2.212277894135152E-17,-80.89943588317219,0.7853981633974483 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark07(-1.1102230246251565E-16,-1.254497400888003E-16,-90.32078587000197,52.63909560513695 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark07(1.1130725758641806,2.226169907903804,-0.6048307122754224,-86.64875336916353 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark07(-1.114836776824412,-0.6588783455020255,0.32054467771589473,-7.805470669559119 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark07(1.129005659990369,2.4148173141882148,-1.1183278176848117,-19.26607485606694 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark07(-1.1527660671808801,-0.9667021349040682,0.5763830335904401,-80.41139011832544 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark07(-11.553647050679842,49.57006446760687,0,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark07(-11.624907493077387,-21.679018659359897,-104.31063751970328,43.03377338021524 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark07(-1.1800009827315485,-0.7933726617604275,-0.1953976720316739,1.156836738629778 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark07(-1.1832520331641943,-0.84195822561957,-0.19377214681535104,-128.41994840891493 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark07(-11.908995167096018,-22.891534669004326,-100.0,-27.039185089875172 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark07(-1.19165430421669E-24,-2.3833086084333384E-24,-100.0,0.0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark07(1.1982290126749737,2.7649512090545922,-0.599114506337487,1.8843763626682133 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark07(1.2088194922916653,-6.140733889345215E-6,-144.75655752680905,0.5378347043918374 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark07(-12.194037271554539,-17.813990841767982,6.097018635777269,100.0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark07(1.2241927294923258,3.2664294758773877,-38.36997901726326,-19.69722293419621 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark07(-1.263599316426445,-0.9564023060579936,-59.49479316338067,-23.899972522249318 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark07(12.740904564995137,-0.5235987755983018,18.654384396984327,7.061795523671989 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark07(1.2797411408396224,3.8763389625905615,-1.130776057178878,181.3450131005875 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark07(-12.83027705510786,-18.16013798609259,5.629588846279731,100.0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark07(-12.908429889096356,-24.246063451397816,6.293553561693898,57.66848978705801 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark07(-1.3103420821795289,-1.0570590365587305,-81.95870645440895,-29.145161002953373 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark07(-1.3171262235724535,-1.063921449875097,-59.033472779600935,-94.75896434771273 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark07(-1.3209399441109109,-1.7578702250872602,-91.90144225914088,1.6693519029633197 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark07(-13.25602550579646,-24.941254684798025,-99.99726378204309,6.9847081974825365 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark07(-1.3286675650818165,-1.6940576647741379,-69.16010423915215,-32.14751564317358 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark07(1.3657145872723344,2.7467834728341223,-1.3186618161888726,43.39431830054848 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark07(-1.371395992923033,-0.5235987755982987,-88.06430097482665,18.20457789129946 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark07(-1.3798868181994135,-2.541702621517114,0.6894836220060974,2.0575647435503868 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark07(1.3836527908675256,4.207487017393194,-0.7062182556772258,100.0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark07(1.384192003061998,2.784946647525214,-1.0143686895596602,-46.94207916077899 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark07(-1.3939713411348365E-9,-2.7879426779068254E-9,-0.25145507488930297,-39.298480964751164 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark07(13.95505456086877,15.416323852089489,-31.725628448833866,39.4201690927018 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark07(-14.070979809583363,-26.571163292371832,0,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark07(-1.4093267749873271E-12,-2.8068850878550535E-12,7.046633874936636E-13,-43.9822765016821 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark07(14.104867105886498,28.21592566753534,-7.052433552943249,-16.178759148010638 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark07(-1.4166445794216997E-13,-2.82566941601829E-13,-60.80829177132894,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark07(-1.4520459489760832E-10,-5.354155759007574E-11,-77.8633424691961,-3.2008228197178144E-11 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark07(-1.4986780879214912,-1.4751578841146984,-0.036059119436702716,-95.86508002757988 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark07(-15.264317823209211,13.73283016797167,0,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark07(15.355939593075618,86.25622102692418,-26.545128576361236,-94.9016522026079 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark07(-1.537154601396689,-1.5035128759990088,0.7685773006983445,-90.50173522957398 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark07(-1.5381676395471806,-1.5055764809798324,-100.0,-179.90574207279508 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark07(-1.541210629633876E-20,-3.0824212592677296E-20,-0.8625236971607022,42.96752021201211 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark07(15.456208035503408,-30.1306865664519,-2.0699157786251163,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark07(-1.55881188855373,-1.6430311524021637,0.779405944276865,-35.30679985913559 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark07(1.5719127207668437,3.6558413907674017,-70.57864149006213,-2.6133188587811493 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark07(-1.5754897999793844,-1.5801832731638725,-47.3406750024563,65.57157410259292 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark07(-1.5786941857324344,-0.596308758511103,-136.66228344404217,101.62739479546778 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark07(-15.78732150095368,58.54843175244514,-0.7139739129882372,26.438157369635192 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark07(15.85374487997655,33.278286086748,0,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark07(-1.5931569220039438E-4,-1.370495794605901E-14,-60.44106036141646,25.1809635563187 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark07(16.12756565479476,32.41325643411299,-61.13757241370363,-16.206628217056494 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark07(1.6385862642686413,-0.13259624048907287,-27.80822437202726,0.03413377078372726 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark07(-1.6679348329376773,-1.765073339080459,0.8339674164688387,0.8825366695402295 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark07(1.7600653128407266,4.541266868648351,-100.0701008228048,-123.25302341852013 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark07(-1.7621210276900434,-1.9534457285851905,-65.98711683997847,81.17098028871132 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark07(-1.7763568393001651E-15,-2.1933827877874543E-15,-43.1978755498538,0.7853981633974494 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark07(-1.7763568394002503E-15,-6.439857100714077E-16,-0.7853981633974474,0.7853981633974486 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark07(-1.7763568394002505E-15,-1.2991731219250632E-15,0.0,-94.96543209224433 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark07(-1.7763568394002505E-15,-3.116395127256229E-15,-73.81313487077044,-61.70528234515429 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark07(1.822248786382802,3.6519015153275416,-93.97622522044729,-2.6113489210612193 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark07(-18.272608723009498,-0.3620494704992506,-17.72897132750937,79.12431769324718 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark07(-1.843596641621707,-2.16440867533084,0.9217983208108536,74.12422599728018 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark07(-1.8451766169360138,-0.5235572648294694,-7.748831593675728,185.45467688235237 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark07(1.8616806524026952,5.2886100577796915,-58.5612307085981,-4.715096948946028 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark07(-1.8872919233961093E-15,-1.802926547614287E-15,-0.7853981633974463,0.022631139299425063 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark07(-19.13921964831175,-1.0580426834239915,29.806363423096883,53.13862821555597 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark07(-19.187794544277594,-38.37558908855519,0,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark07(-1.93210443001436,-0.23841718620671384,-95.77750502695002,0.9046067565008052 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark07(1.952483316481771,-7.287544034014622E-10,-103.98783831341143,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark07(1.9605452092441975,-2.710505431213761E-20,-6.477985321056551,9.57605501660834 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark07(-19.673246447792927,-37.41343508418194,-128.39350701889566,-191.01518534085383 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark07(-19.86707211669562,-39.062397325274276,0,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark07(19.894888006118677,-45.061852828626826,64.97612682597892,-22.23115479315456 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark07(19.9973040972569,55.64859527543621,34.8527054373796,-34.803877439941175 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark07(-2.015180173222124,-2.504521356655877,-89.03129227524975,63.013298347083655 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark07(-2.0278541725739303,-2.525098891153694,1.0135074119859844,99.43714836528902 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark07(-2.0545587529791554E-13,-1.3992034272076858E-13,-1.6008910963263237E-13,87.93874965880629 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark07(-20.557780952603323,-16.494937472902095,0,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark07(-2.1184159969331473,-3.3454128615571332,1.0592079984665732,11.597454573657584 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark07(-2.126423464178417,-2.68222183344768,-29.58374560150946,-100.0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark07(-2.1322721925789882E-14,-6.3108872417680944E-30,1.0385279336712013E-14,-0.7853974234552867 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark07(-21.339897045908643,70.74083402189092,-26.030748916119876,66.94432187806339 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark07(2.1368839598714056,5.7975577080024765,-84.04804528081168,132.9751258595905 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark07(2.140586275694779,8.644720160382134,-68.90002422019037,39.65989844575162 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark07(-2.1698578535084972E-15,-4.339715540097726E-15,-11.778945034332507,96.59447421855783 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark07(-2.1749468353009864,-0.5229525703877528,-86.09236575977754,93.1406237503346 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark07(-2.1811622110785596,-3.9750842546318794,-125.71282429380445,124.50836075468362 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark07(-2.1966867971490966,-3.616930453464209,1.0983433985745483,-56.51014541312563 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark07(-22.156936035426728,-33.792040420645115,-19.554870278762724,17.677350878042972 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark07(-2.220446049250313E-16,-2.7755575615628914E-17,-100.0,3.4380229299626226 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark07(-2.2292692588700914E-29,-4.417621069237666E-29,-0.7853981633974483,-26.49994204729073 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark07(-2.2475501879987782E-7,-4.495100375997421E-7,-18.062240311305374,-0.7853979386424295 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark07(-22.568630493084683,-77.44048510199883,-26.80598177741254,-32.76701025681044 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark07(-2.277411659831008,-3.4042383417218467,-40.99358814379792,2.4875173342583716 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark07(22.82945963051924,86.16953736348734,0,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark07(2.289610834272515,-0.504459307541072,-100.0,10.59496658276812 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark07(23.804398456280367,4.913749998206313,16.459649452450336,-25.40943770832635 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark07(-23.81340013610837,-7.237285164612331,-31.789052264092206,-64.95314746549815 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark07(-2.3922299213397755,-0.523528162177499,-175.68327754998964,-91.60877657189506 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark07(-2.423962702195712E-4,-4.8479254043914087E-4,-0.7852769652623385,37.98470220437998 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark07(2.439993182928917,5.419978983613735,-1.2911375539206136,18.558527502383466 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark07(-2.442430591109712E-9,-4.884861148795004E-9,-80.51134404254469,1742.5363282523183 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark07(-2.4892542482014934,-0.5235987749007501,-140.13030290638505,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark07(-2494.031946202511,188.8999930806874,0,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark07(-2.5245058934021902E-9,-9.227490250417537E-10,-0.44969795008095365,-90.48558774920143 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark07(-25.53724863343615,-49.50370094007741,0,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark07(-2.602333705174678,-2.843249197087051,-109.59540960946657,-43.49952868352139 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark07(-2.6256774532384952E-14,-6.3108872417680944E-30,1.3128387266192476E-14,0.7853981633974483 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark07(2.6307426589064122,5.261485319004297,-2.1007694928506546,-61.19623557184773 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark07(-2656.8167910117268,61.10780345043506,0,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark07(-2.691623570293025,-3.938084628210413,-107.90082547537726,27.88272667722194 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark07(-2.7038232157784305,-0.5235927939843943,-35.59164349897793,27.19533268184221 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark07(-2.766617540951189,-1.2997094571454075E-4,-100.0,39.648286244698056 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark07(-2.7755575615628914E-17,-6.938893903907228E-18,-9.844874312525794,29.6571964423216 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark07(-27.77618920269147,18.266684291897107,-39.897777505493636,93.4929068733598 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark07(-2.778857895553488,-4.969992008526945,1.3894289477573902,62.035436149337194 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark07(-2.7822188997106423E-13,-5.554085154122385E-13,-0.20987775550164928,30.343499671310248 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark07(-2.7924927412874156,-4.014189155786772,-117.233936515833,-79.81019268325225 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark07(2.9394191943118333,-5.9525881562343336E-6,-139.3219591865776,126.67341108809669 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark07(-29.887746455730987,-2.645668026575855,14.158475064468044,-26.722894650937878 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark07(-3.0227165124185874E-15,-6.045433024837174E-15,-53.88735494567371,-47.55419454062418 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark07(3.1006948922183124,6.5765355235707625,-13.593698507415896,-62.97852398158454 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark07(-3.1261769407609172,-5.263130928995356,-42.04701742819725,25.408089161279594 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark07(31.354133187800787,63.440030616530464,-100.0,-31.720015308265232 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark07(-3.1428442071046447E-9,-6.232369314414575E-9,-99.74563323715361,0.7853981665136329 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark07(-3.148907414603802,-7.453200416387094,-26.697621800913968,1.385899769511615 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark07(-3.1514304499324908E-9,-6.302860891636585E-9,-0.7853981755299646,-122.33921746236736 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark07(3.16933637828446,6.338672844183518,-1.58466818914223,-94.24670549332123 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark07(-31.92435400443787,-62.27815414002655,0,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark07(3.256016608276129,6.5508728606813955,-9.368951856516256,81.54757268964107 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark07(-3.2679229799800864,-6.349055679364741,-20.26018599674553,2.389129676284922 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark07(-33.41885170863401,-48.74785364297178,55.181505665692015,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark07(-3.42732531811695,-0.5235987755982987,-0.6425358167722809,-19.464422188129248 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark07(34.36988785762528,70.13325624811073,-37.66311750844834,-40.56436397167184 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark07(-34.97833905768091,-68.38588178856693,0,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark07(-35.121140324310744,-53.74219046537405,-60.54370430706373,-53.70395608216458 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark07(-3.5388460169270465E-16,-7.053514144233389E-16,1.7694230084635233E-16,-0.7853981633974481 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark07(3.54873518543281,7.097470370865621,-54.3476442293026,-55.92836451975663 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark07(-35.48828523416562,-70.7185945288098,7.256135096031244,-111.5103535728112 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark07(-3.552713678800501E-15,-3.4161793900820643E-15,-0.7853981633974465,0.7258142057252641 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark07(-3.552713678800501E-15,-3.552713678800501E-15,-12.831200658147079,38.79967199757366 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark07(-3.5623102007969587,-0.5235987755982987,5.072495816545193,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark07(3.571220923996687,1.5619475553898743,-73.67802292111007,100.0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark07(-3.576254171011632E-15,-6.798961264046973E-18,-0.7853981633974465,3.399480632023487E-18 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark07(-3.5823477386861518,-5.669220555124828,-73.70944179695414,-46.61956384420714 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark07(35.998119180765485,17.161732194597576,25.34150815934541,7.042241581939734 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark07(-36.41078205934913,-3.828541325745178,0,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark07(-3.6637359812630166E-15,-7.105422708653208E-15,-66.96923815022392,-55.90291228183937 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark07(3.6646777661128698,8.025496343150763,-9.439939981504043,-4.012748171575382 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark07(-3.6777344068823847,-5.784757221362672,1.053469040043744,-46.84899284558823 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark07(-3.682647229655152E-5,-6.409399902695473E-5,-181.36628197826323,-0.7853661163865288 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark07(3.6929320565452155,7.385864113091568,-2.631864191670056,99.99999986581321 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark07(37.203194852659834,74.40638970531968,0,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark07(37.2618756092385,40.828721521059805,9.995297727772694,95.12020550004249 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark07(3.792130155500477,7.584260563398952,-30.191287590116843,177.73717532049983 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark07(3.801732743359616,-0.4945194915861753,-99.28521089902894,45.8011920484399 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark07(-3.8279229822557603E-4,-7.655845964510517E-4,-90.16669270588079,-0.7850153710992227 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark07(3.9078532193637563,8.26526991935145,-1.9532646356949617,108.30430284791312 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark07(-3.9227887267361847,-6.274781128332102,-68.75297749930925,3.922788727563501 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark07(-39.40330113670174,79.7839534166167,7.205826969147537,42.32600234523861 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark07(3.9652055451164188,7.930411090232837,0,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark07(-4.028195544255069,-6.2852689523879395,1.9482297707083793,-126.4714779132012 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark07(-41.11022742692927,-38.37130322240703,75.55508105434674,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark07(4.230030917215355,8.673525355090925,-2.9004136220049324,-6.690695572098079 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark07(-4.2414975192538774E-12,-4.679623807000303E-15,-17.62783344817644,-136.40924187900814 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark07(42.81576136358467,-88.91487089116015,-91.48958772036826,-95.62477853189439 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark07(-4.323184120919922,-8.416723041527877,-45.95524285248635,-57.827994255219686 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark07(-43.57590495938142,22.018953716055137,0,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark07(-4.382141388931888E-17,-8.764282777863772E-17,-35.37099879328466,-50.472518887713065 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark07(-4.413761256144751,-0.4524448062825286,-59.14080828518916,0.2262224031412643 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark07(44.195970757776166,-71.0697890247084,0,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark07(-4.440892098500626E-16,-7.871762333870281E-16,-45.75414555801065,3.935881166935141E-16 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark07(-4.468770944406365E-17,-1.232595164407831E-32,-30.33428876510759,84.2124417428446 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark07(-4.496796023445235E-14,-3.2457769466849505E-14,-100.0,1.6228884733424755E-14 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark07(-4.5684134323137935E-17,-4.930339285650736E-32,2.7755575615628914E-17,2.465190328815662E-32 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark07(-45.81196182300222,45.249662811895206,0,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark07(-4.602597895459493,-8.19448432655563,1.5159009232733156,83.42242111308812 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark07(-4.694881962363784E-9,-9.389763922475406E-9,2.347440981181892E-9,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark07(-4.74770438399425E-13,-2.8865292634742876E-13,-100.0,92.97203350258377 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark07(47.822909948205705,-56.063794512959866,46.16498917643145,-81.46204593523186 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark07(-47.865776547888586,-94.16075676898228,0,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark07(47.904425845284976,-53.321502687461496,91.22365288674237,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark07(48.38591539064255,98.34262710808,0,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark07(-48.47997725995137,-95.51255444921578,0,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark07(-4.90980855638562,-8.509764380081585,-56.04720586627759,3.469484026643344 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark07(-4.911919369391578,-9.68935111088567,1.670561478692676,-10.077895660118335 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark07(4.960340962465892,10.322371937457469,-2.480170481232946,-10.658522282460323 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark07(-49.61970440317663,-97.66861247955836,0,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark07(-4.974818380679966,-9.94942400246195,-65.47142457094589,34.82032602157586 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark07(5.021144623310183,10.272798574175654,-77.60130223359725,100.0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark07(-50.42953346429319,-100.85906692858185,0,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark07(5.151224256594353,10.470663844044644,-2.5756121282971765,-70.439319291155 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark07(-5.171419907207493,-8.85333791318875,1.8003117902073777,49.97401588009086 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark07(-51.889641496216775,19.79506584957717,47.56766810297438,78.42813630771383 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark07(53.251065506426784,14.887333144587217,0,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark07(5.398312850714443,0.8281517711950845,-27.546483904874115,-173.70160379234588 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark07(-5.535194647895777E-17,-1.1070389295791553E-16,-0.5780861662026191,-55.552779398774966 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark07(-5.551115123125783E-17,-8.673617379884035E-19,-42.67113801773229,100.0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark07(-5.555189926543152,-9.541175400825798,-69.53760364130837,172.08553838513302 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark07(59.18757549070423,84.39451629878988,-94.52915744710447,82.7082508229085 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark07(-6.098419371453998,-3.694220909550818,-79.8196833895586,-88.16846973488622 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark07(-6.162975822039155E-33,-8.477599091418487E-33,3.0814879110195774E-33,99.99999999999982 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark07(6.2713287620321125,-1.2639055779787731E-7,-99.7393931891621,-53.60027986888733 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark07(-6.488695602681729,-12.254079677272834,-180.62029716739735,-197.28954536966447 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark07(6.672716792922381,13.290848151739542,-3.3361158650225406,123.00919536962758 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark07(-6.682089021632914,-10.46725248100977,2.5556463474190068,5.232666756764354 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark07(7.021924999422878,14.043849998845758,-4.296360663108887,-6.236526836025431 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark07(-70.38791079077988,-30.86824078688319,50.48559709322089,-6.470671468895858 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark07(-7.2320825657939925E-6,-1.5777218104420236E-30,-56.25565124256056,0.0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark07(-72.4787398973606,38.29674578837111,0,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark07(72.79944144597823,11.880377753550704,58.310216534005974,36.211900216200576 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark07(-7.328186462712386,-0.48917568655654586,-57.599085932045426,100.0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark07(-74.25771567475232,-67.91450245536276,24.249649756133437,-98.21453279535089 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark07(-74.55734699775635,27.099281933453568,63.37234684831316,95.69223856179366 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark07(-74.65924385188862,-23.723940480307576,58.769354098948924,57.465334863324614 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark07(7.47309155500364,15.963073887999906,-3.7924385078776854,-50.38530457560145 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark07(-7.530270749372033,-0.5235987755982983,2.9628611508304,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark07(-77.46711567480332,-42.261868354968925,0,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark07(-7.814184108414653,-13.425017287322508,-45.77145054749371,157.49172801406576 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark07(7.850412530327194,17.13585168299105,-30.739089290616228,-96.53250313015543 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark07(7.884622621112939,15.76924524222588,-4.097626372357382,-7.88462262111294 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark07(79.80917992263471,74.5478959116572,33.44732968199253,-38.071554648493944 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark07(79.87917852810867,33.44045831278092,53.441811444295325,-5.832172846654913 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark07(7.9985650700885,16.06730907454744,-121.67732409088075,-10.38879292271363 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark07(8.068689771666772,17.661179087788256,-4.516899824520892,-1.7620046118092065 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark07(-82.54489910730251,-68.77980712711084,20.042039908630713,-86.60085108827323 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark07(-8.326672684688674E-17,-1.1102230246251565E-16,0,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark07(8.405886543621005,18.017270479111964,-4.988341435207951,68.99579433267056 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark07(-8.44919019152534,-16.017226365170742,4.22459509576267,-88.58493466847212 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark07(8.542890838404364,18.65122049993226,-5.0568435825996305,-10.111008413363578 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark07(86.25924787633267,-97.20702182818737,0,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark07(8.75560908252132,17.883356286974458,-39.26535281404482,50.74858218518986 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark07(-8.804725086804424,-16.03865384681395,-100.0,81.8095835068178 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark07(-8.81054501224341,65.26440801901506,69.7470369104912,-27.785985318465052 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark07(88.53354886520162,-1.8595439594591596,97.2404938197638,-53.976908862772 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark07(-8.935255438486253,-17.754995457462538,-19.296630046424635,22.172606730257428 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark07(-89.83844883340402,82.76837515453167,-20.489153746072475,26.770032185506352 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark07(-90.29840857358775,14.663355256347387,29.780253866211694,40.156038269827974 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark07(-9.108651459651618E-12,-6.890845341605422E-27,4.554325729825809E-12,-85.60839980386514 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark07(-9.126500639439077E-16,-1.7763568394002505E-15,-0.7853981633974478,-17.48450067377584 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark07(-9.190914414159364,-18.381821610288405,-85.57741943218204,9.190910805144203 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark07(9.222186087720136,20.01000736036108,-33.10145484635586,-12.360534954784589 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark07(-9.279104642178056E-16,-1.851766472473852E-15,-0.785398163397448,0.7853981633974492 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark07(9.293225485693005,20.14933504986237,-5.432010906243951,53.531325066974496 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark07(-9.44161926463849E-6,-1.8883238529115532E-5,-92.54612910394341,-0.7853887217781838 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark07(-9.49476495653599E-5,-3.3087224502121107E-24,-124.88024210858502,0.7853981564431126 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark07(9.523079258903817,20.510949906425786,-5.322952974498765,-15.752890687435174 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark07(-9.693219586811036,-18.18704308084846,4.06121163000807,-8.1852378462697 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark07(-9.69888712911145,-17.826977931428004,-97.25992827768144,99.99999999999918 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark07(9.774513858335004,19.64572259231749,-5.672626634293911,-34.81483302916212 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark07(9.91273046145324,20.80022636500684,-4.95636523072662,-84.22647610740958 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark07(-9.959737065608487E-4,-0.001991050466276272,-0.7849001765441679,0.7863936886305865 ) ;
  }
}
