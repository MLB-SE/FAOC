import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(0.0015685784636203254,-1.4699990076452019E-10 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(-0.004079855530463488,39.031826561187145 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(0.005921526397611458,-96.388981381509 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark09(0.008559435977761012,-66.68620703826593 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark09(0.009544688410081027,-59.80250956277115 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark09(0.01164752655891732,-100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark09(0.021299082516783363,-73.74948313182668 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark09(-0.021661212942886827,72.51654516931006 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark09(0.0,30.485086439533205 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark09(-0.03732324942560239,42.086269308518126 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark09(0.041949337383691866,-37.44508077511508 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark09(0.04666791080981107,-0.13157482714170055 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark09(0.0488735372557727,-32.14001717482424 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark09(0.050878488789237064,-30.873486303845894 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark09(0.0511734088085694,-30.695557778278275 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark09(-0.05524073021457898,28.435473620519527 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark09(-0.06239943275041249,25.173246895974593 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark09(-0.06403309819418723,24.53100616858001 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark09(0.06700745878248797,-23.442111599752465 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark09(-0.07683560280999568,20.44359996340856 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark09(0.0773916506584246,-7.367049320536448 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark09(0.077611035612283,-7.354576816647102 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark09(-0.07818643861807566,7.300451794119214 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark09(-0.07828417621559941,20.065310803920667 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark09(0.09479658595790032,-6.021248060933786 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark09(0.0980212589515368,-16.02505766194571 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark09(0.10259833858114108,-15.310153639111945 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark09(-0.1032676304754716,15.21092640125984 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark09(-0.12738540516740482,12.331054132383642 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark09(0.13914251321827742,-11.289118548051064 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark09(-0.1437820688050877,10.924841601245024 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark09(-0.1510562221458729,10.398752891343996 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark09(0.161562667797817,-9.72252035823415 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark09(-0.16188284173122203,9.703291034407016 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark09(0.17162901278925635,-3.325703266550122 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark09(0.17500763771142225,-3.4988381511860847E-16 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark09(0.1782844207331391,-8.8106202456473 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark09(0.19099754050667173,-2.1110224679432577E-11 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark09(0.20111274954814654,-7.810525838486669 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark09(-0.21209381210975664,2.5300824518148004 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark09(0.22836398807996786,82.86759489921732 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark09(0.2362815414970774,-6.647985775115345 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark09(-0.2561335292200404,6.132724331633479 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark09(0.27596779350136996,-2.0677021919843104 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark09(0.2784634744568635,-5.640942065592976 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark09(0.2785193839496074,-5.639809712774251 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark09(0.28709442911620897,-5.471357739787678 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark09(-0.29265160272065444,5.36746189732736 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark09(0.31665931111975004,-1.8025498150712491 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark09(0.31729257010712253,-4.950624359922998 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark09(-0.33993103200763314,-10.936065245246517 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark09(0.3848393285676752,-4.081693865960134 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark09(-0.4126399283818927,2.5579538487363607E-13 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark09(-0.42232689597059986,-8.802441853426858 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark09(-0.5061101399730603,3.1036649984497604 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark09(0.5076794786235084,-3.094070950147245 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark09(-0.5325650945899838,0.5500013554350005 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark09(0.5416900723376301,-2.8998063782414505 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark09(0.6321224059636137,-2.7000623958883807E-13 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark09(0.6381664141873243,-2.461421177727182 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark09(-0.728331093056962,2.156706395990767 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark09(0.7326810356489837,25.89743012077859 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark09(0.93438293547716,-1.6811055373057542 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark09(100.00000000000003,-64.34552550878689 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark09(-100.01578761888673,0.006073456675708595 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark09(102.882543756383,-82.7518040435553 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark09(1.0330490565064685,-0.5880408929674001 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark09(1.0658141036401503E-14,-2.0321378519837117 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark09(1.084067369737283E-18,-60.39818779091056 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark09(-109.54090543392519,0.005207119498496863 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark09(-11.141190316311224,-70.72575750281725 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark09(-11.27796849242884,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark09(-1.1376046564965918,1.3807928069074364 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark09(1.1460546839600028,-1.3706120212058543 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark09(116.69871654383,-0.004861278887358131 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark09(-11.876860980063213,34.51818349111326 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark09(1.198869931903218,120.54123489240982 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark09(1.218536416372186,-1.2890844341537644 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark09(12.314319049814188,82.53588737625398 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark09(-12.355850925991362,67.45503411076896 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark09(-124.18689564035472,0.004596266815751334 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark09(1.2596554029539782,-0.08040306516693474 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark09(1.2709507909115443E-15,-0.22986804109244993 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark09(-12.790841493214156,0.12280633198591673 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark09(-1287.4829641728797,1431.1707825148717 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark09(12.906111776474303,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark09(1.3136055202385813E-16,-0.466139484144726 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark09(-13.253425442861772,66.88444753701097 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark09(-13.25934164936433,90.51666662432595 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark09(-13.288328828464842,29.78977300022504 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark09(1.337864926901375,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark09(-13.598333056231127,34.657826541145965 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark09(-136.48558749616274,0.004182098806327128 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark09(-13.6725768754864,0.04174643593803337 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark09(1373.245896465334,-1290.3634270115695 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark09(-1.3877787807814457E-17,41.43905296988288 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark09(-1.388445399426096,-13.58164296378521 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark09(1.4039590331170996E-178,-9.232978617785736E-128 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark09(1.4210854715202004E-14,-0.04207964316724144 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark09(-14.45911350126234,-9.994661526013397 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark09(14.583925087155857,-28.014712532975622 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark09(15.148234483128348,-38.172946367904004 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark09(15.222453217637508,-10.82492067717962 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark09(15.25327396767699,-0.10298092921713309 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark09(1.5631940186722204E-13,-0.654016858400567 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark09(-1.5650701714725415,1.0036587211402193 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark09(-15.676087037546061,79.79058227992684 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark09(16.0711877966869,-1.3322676295501878E-15 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark09(16.110729980104846,-0.09750000954237792 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark09(-1.61895E-319,1.47145088911671E-4 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark09(16.278264448877522,-100.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark09(16.311379735996326,-0.09630064116087171 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark09(-16.836208842254592,60.53411524411034 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark09(1.7108817236187193,-0.9181209344340147 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark09(-17.35345465732938,2.220446049250313E-16 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark09(1.7763568394002505E-14,8.359052925707312 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark09(1.7763568394002505E-15,-23.10030838902155 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark09(-1.7763568394002505E-15,8.291879054952858 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark09(-179.05625693899154,96.57166078927239 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark09(1.800369812737878E-211,-1.0644899600020377E-109 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark09(18.263166938863236,-98.48184567398938 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark09(-1.8303590385158515,0.8581902750995666 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark09(1.8597555719589955,-0.8446251488523729 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark09(-1.8701928627635596,-20.623503985754652 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark09(-18.817483616143058,63.7859346177346 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark09(19.83700427763965,-0.07918515844478691 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark09(20.07982435974091,16.225707236032207 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark09(2.010796158632104,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark09(-20.38342217104256,88.47150665474902 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark09(-22.177390421462682,18.132154054984255 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark09(-2.220446049250313E-15,16.748919910701442 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark09(2.220446049250313E-16,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark09(2.220446049250313E-16,-20.42670588413833 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark09(2.220446049250313E-16,-52.482279520054284 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark09(2.2241089650693976E-15,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark09(-224.21536068387348,740.2888480297299 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark09(-2.2724236356190367E-17,2.694582955289814 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark09(22.817005259810813,-3.982489138894431E-18 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark09(23.23332099031239,1.148863972156931 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark09(-23.274098967972947,0.06749117673497462 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark09(-2.3592239273284576E-16,23.91644533398359 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark09(-24.178250268249798,87.07982482699781 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark09(-2.4202623070722353,4.405364961712621E-13 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark09(24.269737870325642,-9.32002948600156 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark09(-24.461548336404988,0.06421491825426062 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark09(-2.4721546723254733,2.6361135496699717E-12 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark09(-24.78463350063771,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark09(2.4868995751603507E-13,-0.09508531396005038 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark09(25.706415156997053,-0.061105226738211296 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark09(2.6026776827022347,-0.6035308702397657 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark09(2.6286613806673813,-0.051107656710769334 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark09(26.52879525220837,0.026111516571388695 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark09(2.68387241459493,-0.12562553993227343 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark09(26.873248245916216,-28.762187455590606 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark09(-27.086242153949158,23.913944181867002 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark09(-2.7564521829728506,0.5698616273839305 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark09(-2.7711166694643907E-13,0.3720722266790515 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark09(2.7755575615628914E-17,-10.206127547320197 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark09(-2.843817911788373E-14,0.01776912465853526 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark09(28.55957438390829,-1.6653345369377348E-16 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark09(-28.668749514688187,84.16957753181651 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark09(-28.861007583169652,66.887373921949 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark09(-29.03054579988779,11.920055734087676 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark09(-29.140584035354493,0.05390407841137107 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark09(-2.984279490192421E-13,0.12068124311473127 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark09(-30.15803761125921,15.261050128111558 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark09(30.30699298044514,-0.018833815910301307 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark09(30.972307462024872,-0.05071615438148575 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark09(31.74425489804758,-20.23170953333502 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark09(-32.03868747957032,0.04902811102347826 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark09(3.226187680911776,-0.48688932019942577 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark09(-3.268496584496461E-13,0.2658181874203791 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark09(-32.75689951869924,5.034282377035524 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark09(32.925221641867125,70.11812991031559 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark09(3.3306690738754696E-16,-38.220022787753095 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark09(33.835703963385,-92.86531922955352 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark09(-33.977626132663204,12.165405029686411 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark09(-3.470146602450356,0.4526599324896807 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark09(3.48743827277751,-0.4504155210592051 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark09(3.552713678800501E-15,-0.29254742077426954 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark09(3.6026231155089743,-0.05315127739101078 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark09(3.623767952376511E-13,-2.612324415284448 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark09(-36.76292785586956,37.438800101399124 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark09(37.01134190585606,-28.121558091277294 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark09(-37.097121657465195,0.04234280873051954 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark09(3.8812839954056813,-0.404710484637107 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark09(38.94136693391846,-10.680881614460276 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark09(39.10466596378085,-99.30038269692119 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark09(-39.14784360045858,83.35161345868838 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark09(-3.925631440062972,0.4001385129444657 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark09(39.360961920296205,-84.4841096759398 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark09(-3.969576474180897,45.57848689335185 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark09(40.37722784740844,-19.023579496481076 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark09(40.47651820162443,-25.148890042350388 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark09(-41.54030359258953,93.47661857415218 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark09(4.171896926518741,-86.61121453586638 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark09(43.58652082310482,-26.45964603678543 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark09(-43.80733435445134,2.729407125312889 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark09(43.88190657989216,-36.523697462604375 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark09(4.440892098500626E-16,-21.083624810293173 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark09(-44.69672433300109,44.46270153662414 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark09(44.72423371807016,2.2204460660567245E-16 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark09(44.82616228542335,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark09(-4.488077310074088,0.1271799989843226 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark09(-45.78224393590296,62.063471517628756 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark09(-4.647024133827802,-2.7504345185449425E-17 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark09(-46.70353615902263,50.349123312746805 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark09(-4.677363321867631,4.139844256024867 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark09(4.725454804443245,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark09(-48.16796133123338,0.03261081190447541 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark09(-483.887945791025,321.1017767182646 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark09(-48.40292761911175,73.86281380146357 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark09(48.662974156583516,87.810397764963 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark09(4.896969388449477,-2.4868995751603507E-14 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark09(4.9188126264081395,-45.02759078257738 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark09(-49.61345539715196,-75.6071003399363 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark09(-5.106550280117091,14.386144541098218 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark09(51.468289626689,-63.41278345225165 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark09(5.342522527270873,-46.4185314447533 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark09(-53.683182605087,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark09(5.551115123125783E-17,-67.99632030607637 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark09(-56.338533426125956,58.32165383438297 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark09(5.6843418860808015E-14,0.03407903928353506 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark09(5.765808199097705,-7.543729692547352E-4 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark09(-57.71231382959657,0.00989037299780126 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark09(-57.86402180726503,0.009864425100902099 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark09(5.817853695688896,-0.2699958453679052 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark09(-58.19825498285458,0.026990436865463874 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark09(-58.687420873728534,0.011803698447370673 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark09(-5.872229746426182E-14,6.913196309970326 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark09(58.740940363611884,-65.95387799732055 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark09(-59.504595077107595,22.386247071158905 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark09(-60.98157782749676,92.6283269132648 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark09(61.72204021346104,-14.362777372931145 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark09(6.254397854597429,1.0737198177228768 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark09(-63.00044226934633,71.33359897027546 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark09(-63.37787434813844,0.024784616760202757 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark09(64.51230828748595,-56.19531643111908 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark09(-6.460665668520534,15.734476314920443 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark09(6.465938895416912E-13,-1.2832445201939038 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark09(6.529383784417653,-0.24057344133202818 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark09(65.52810015066765,-0.023971339367129387 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark09(67.42364088021912,-38.58404802395857 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark09(-67.51638427539395,0.004877048388474838 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark09(6.770081937919111E-4,-9.04454931548382E-14 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark09(68.74817923591556,-44.79964170506838 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark09(-6.894672672014394,0.227827541860077 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark09(70.60343739473731,-84.39333527229024 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark09(-70.84012066328745,186.35686956914995 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark09(-7.089993612991293,-1.6951430085083787E-17 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark09(-71.02063060156291,78.13372202730784 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark09(-7.105427357601002E-15,3.679936533363559 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark09(-72.09309533961219,25.717161474304447 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark09(-72.9614477689128,-9.784963664848533 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark09(73.07343977832858,31.480316077471542 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark09(-73.81646111015938,5.849635850726423 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark09(75.03216615096235,24.757278435272596 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark09(-75.52704330146112,0.07001868523578295 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark09(76.74734011491442,-6.058509889365025 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark09(-76.79257898777382,3.725182947170169E-5 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark09(-77.60054282835037,0.020242079108511418 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark09(-7.7671548605310505,0.20223574204459283 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark09(-7.851283672424387,36.012552250969804 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark09(-7.917238523123558,15.966786948072055 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark09(79.91560249259607,-74.55322980786643 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark09(80.0865342829137,1.5786574460410918 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark09(-80.84702574846175,0.019429240745133823 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark09(82.67317982497505,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark09(-8.304704346246353,33.37673800855865 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark09(83.73961877511226,-19.285825237097157 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark09(84.81717483695931,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark09(-85.6342171913669,86.43857421934325 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark09(8.579945952184502,-0.18307764822166073 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark09(-86.10575564899385,6.804176752123524 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark09(86.5300010498303,-51.84564022328808 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark09(87.40233569963422,-97.42242648532707 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark09(8.881784197001252E-16,7.105427357601002E-15 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark09(90.45965931063093,-83.29801409320382 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark09(-91.6385295584434,25.094748175341564 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark09(-9.253843774410882,-33.90664724702836 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark09(92.93894424559855,38.67108245376701 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark09(94.31316949750402,-17.188952020303596 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark09(94.4476527146002,1.0885639092685722 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark09(96.77277661472456,-40.02405708079322 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark09(-97.90108722177698,64.63810830387277 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark09(-97.94276663385094,49.59212208236934 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark09(-97.94505690428359,-35.37690396759632 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark09(98.47857426265386,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark09(-9.948019361373966,0.1579004090898697 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark09(99.90537988785914,-5.3290705182007514E-14 ) ;
  }
}
