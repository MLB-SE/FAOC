import org.junit.Test;

public class Sample81Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark81(13.050523594856863,-0.7708537415625334 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark81(4.231993398735767,2.2400168788613684 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark81(65.11220187213411,-41.67267024481289 ) ;
  }
}
