import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(0,0.0,-0.20616411006611202 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-0.34987526338730923 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-15.380676773790668 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-1.5707963267948966 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-17.994640276823915 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(0.021200636099059752,-4.5779346979912816E-10,-0.4984537633441993 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-21.831946775994055 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-2621.6388858925197 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-2727.631668151444 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark27(0,0,2.9126072171802235 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark27(0,0,30.27924069226495 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark27(0.0,-35.88854253265791,3.577441882037599E-13 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-39.76884146206208 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark27(0,0,4.03241980183023 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-44.09609474902605 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-4.695790404044573 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-57.93073581019237 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-60.36540537595081 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-6.162975822039155E-33 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark27(0,0,6.408641870764086 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark27(0,0.6456159912267543,-0.2239481194181181 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-73.43196087253261 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark27(0.0,8.670086616093704E-10,-1.162642226487229 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark27(0,100.0,-0.8467035595663472 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark27(-0.12441834151808043,0.4573047831137477,-1.1236219397826799 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark27(-0.1471387396904813,17.39279194524343,-6.972200594645983E-14 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark27(0,-15.463602620768697,-14.540042444982063 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark27(0,17.187690288982708,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark27(0,18.87593520551283,-0.553093062873657 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark27(0,19.186352857456228,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark27(0,2424.694603692509,-1.5707963267948915 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark27(0,2604.7132476534557,-1.4574694131984387 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark27(0,28.267876542680398,-1.5707963267948948 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark27(0,35.86114296855965,-0.3514412733611465 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark27(0,-56.926458927387344,53.21705971095429 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark27(0,5.974410286032139,-0.5807712096989235 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark27(0,-60.24894564340624,-1.3318128973044026 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark27(-0.6127144917371987,32.82931445279924,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark27(0,61.652347062540244,-2.045795489390639E-6 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark27(0,65.04877545604666,-1.5707963267948948 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark27(0,79.66077770045517,-0.019719844361059224 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark27(-0.8176346267860568,3.905588978279991E-13,-1.5465916721719504 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark27(0,8.526512829121202E-14,-1.5707963267948963 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark27(-100.0,0.30426710910395804,-0.5653775501328648 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark27(-100.0,0.5093816511175837,-1.5707963267948786 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark27(-100.0,1.1144406090010127E-11,-1.2250803123796596 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark27(-100.0,1.9632295789051568E-11,-1.570796324061292 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark27(-100.0,2.6554403120826464E-10,-2.4331433047296706E-7 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark27(100.0,2.930988785010413E-14,-0.44091834549172587 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark27(-100.0,3.0533270585102277,2.0400961262754906 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark27(-100.0,47.47709654359315,-5.345225963945077E-13 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark27(100.0,5.655089208883985E-15,-1.570795473463881 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark27(-103.67592269943775,13.476075108312287,-6.274804048981589E-6 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark27(-1.1190587512439079,36.5203946456257,-0.008986124259781472 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark27(-112.66144691076036,130.39995030194942,-4.407660902927546E-9 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark27(-14.466162508065253,7.353237053559141,-0.040670696495089476 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark27(-1.4484008652920766,54.74017021768708,-0.010234302127741637 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark27(-1.4733678133342554,22.765360264689896,-6.123233995736766E-17 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark27(14.969062589849079,-7.458675223282513E-16,-0.15535105325081425 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark27(-1.5523021839008777,-81.76957140625214,6.793539743935643E-4 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940935257,1.0395669365597383E-11,-1.5657487805329127 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940935257,21.2075579296731,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940935328,82.28945594123188,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940935348,-1.3210953313168514E-12,-0.014227588626507593 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940935348,7.105427357601002E-15,-0.10926838732012722 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark27(-1.570790794093535,9.225929993583009,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907941117314,9.809652078396859,-1.2061322703610339E-8 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark27(-1.570790795342063,74.95017664506844,-2.967328848187593E-7 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark27(-1.5708222060854948,0.006300018395148044,-1.5707963267948963 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark27(-1.5709701540118028,12.486447752236021,-0.001208328838754092 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark27(-1.5722464104017086,0.11886240356651953,-0.3702713580290826 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark27(-1.5753816724848662,0.07635146137134509,-1.5551558985027452 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark27(-1.577885781193288,1.2396955198253465,-0.0765847011268441 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark27(-1.5818306845399104,19.997119023984695,-0.005910754111746852 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark27(-1.5883319546746009,1.5778199960296817,-0.09440968739350009 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark27(-1.6290949911707109,65.57540344478271,-0.004092020490995635 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark27(16.368539251459197,-100.0,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark27(-1.8101356754233842,0.6392570008978109,-0.9502714929379382 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark27(-1.8321096406952009,0.6575562540368957,-0.9653059056830671 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark27(-1.847815297662578,3.3131724687354573,-0.16820058178950725 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark27(18.700522557479744,68.00639299207882,-0.0015652481715007216 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark27(2.126081094170023,-2.3351258685747274,0.011790865319788605 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark27(-2143.523510370462,67.8356934278879,-2.575619539837287E-6 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark27(-2.156824702208242E-27,42.20323869012702,-4.4408920983382904E-16 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark27(-2.220446049250313E-16,0.1085541994100395,-1.5707963260286681 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark27(-2.220446049250313E-16,6.340540856458653,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark27(-2396.3125806789035,79.38318366294644,-2.3882127475616244E-7 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark27(-25.290778273056397,7.105427357601002E-15,-0.10653774808628924 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark27(-2.8421709430404007E-14,63.3441377598856,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark27(-28.81216478718325,2.5455731104336357,-0.1774709896902067 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark27(-3.012399831378605E-182,8.79451234059303E-11,-1.5690795122814265 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark27(-3.552713678800501E-15,7.105427357601002E-15,-0.4284493532141571 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark27(37.30082537327962,0.2930669373874005,-0.010177509863579792 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark27(-39.23474649923524,0.6721592688764334,-1.0119359995420514 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark27(-39.54701730594224,0.41497102223560955,-0.41246692565358317 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark27(-4.070221892356359E-22,47.56728875265769,-1.992023851954071E-12 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark27(-4.263256414560601E-14,7.352458491499795E-11,-1.570752506107534 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark27(-44.124788306557015,-94.8315012959925,-72.64867708503719 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark27(-47.925005605271195,7.105427357601002E-15,-1.171564952019906 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark27(-5.082877291583901E-91,0.00625143903471183,-1.465500336538347 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark27(50.86729609964752,73.23066468488,48.14392647031437 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark27(5.178814722692413E-6,-33.431022809944004,-0.004987311355505675 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark27(5.826450433232822E-13,-1.1763208160788715E-6,-1.5705245707077997 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark27(60.45410710080363,5.624371715702124E-15,-1.5707963267948868 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark27(-63.40530314797383,-2.6463584754967613,-1.2874313824451085E-16 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark27(64.22062276182496,1.0677838647312843E-6,-1.5707963267948957 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark27(-66.27333709465582,83.35157802295058,-1.3528804559608068E-8 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark27(69.45988890328485,-29.02055738872717,97.89787661711432 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark27(-7.084914565523397E-5,-29.929372872834897,-2.5836570050325243 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark27(-71.6089618224907,67.12797635018845,24.14995390318755 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark27(-73.24015080797815,6.409291778460155E-13,-1.5705208958997128 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark27(-73.46682352858197,92.66692774413912,-2.819653039827044E-5 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark27(76.7209316396264,16.22355090271985,34.266809287985524 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark27(-77.32345600714416,1.4296119843493216E-11,-1.335657581638145 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark27(78.01207636151608,14.776078869033384,70.38673726783452 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark27(-79.6233838305869,2.220446049250313E-16,-0.29900510497891225 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark27(-82.73554117236321,2.220446049250313E-15,-0.13236224668958185 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark27(-87.84431281357479,75.43178798656368,-0.006718349007364899 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark27(90.22228481982563,23.827812706501916,-98.68802899874751 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark27(-90.84481170448039,0.0019982168878553853,-0.009227454749453134 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark27(9.36383239843989,7.360490152433021,-3.9670199072303495E-17 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark27(-93.807481937165,-88.50289283901027,90.6453420830795 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark27(-98.27460858882289,72.82687186719353,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark27(-99.28025266091294,1.4210854715202004E-14,-0.10044975212001939 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark27(-99.31202549979758,1.662430810967292,-0.33357158834714434 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark27(99.4569419067237,2.228564707252612E-6,-1.5396409739741597 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark27(-99.9892791447616,2.7798862398561397,-0.05168146085470998 ) ;
  }
}
