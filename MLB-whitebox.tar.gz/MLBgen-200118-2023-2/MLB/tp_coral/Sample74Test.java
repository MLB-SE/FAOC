import org.junit.Test;

public class Sample74Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark74(-10.013260140424276,-0.16836062651009034,-1.4091246802359292,-1.461604294741437,1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark74(-10.016244726849909,-1.302146276306517,-1.4472346512966385,-1.4494721643852249,-65.98195981052658,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark74(-10.059138150922564,-0.03828676410969417,-1.5707963267948963,0,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark74(-10.065655697488937,-0.3820677295530581,-0.38213083078051685,-19.266211513059375,-0.52051393545689,-27.944682034064755,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark74(-10.088701983604663,-0.026556737576041746,-0.1789109631790367,-0.4795348860717643,-8.919161242240502,3.664297025478612,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark74(-10.089128753299816,-0.08950598053950158,-0.11224620294525955,-0.7361135226446149,-52.378644668879176,5.0018773657026845,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark74(-10.091901810873305,-0.038402744058082174,-0.19498829261808703,-0.2577871531172757,-39.97994082137097,4.777609057786669,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark74(-10.09442606790328,-0.5693159279396584,-0.5974280802921533,-1.0464452346761703,-76.76633985895197,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark74(-10.095963503592724,-1.2223734404502044E-12,-0.019394543775782876,-0.19754606041173695,-90.31097075486056,-20.422663429213497,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark74(-10.103153899098288,-4.822218456450967E-12,-0.290356215459851,-0.9225295987283263,-1.5707963267948983,-7.941712090352976,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark74(-10.105944623981893,-0.4176698903780144,-0.9676213171751238,-64.14895902206368,-1.3171059502678137,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark74(-10.10804037307713,-49.16283779928597,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark74(-10.11845741292366,-0.13218356231829279,-0.41897717709754856,-1.5707963267948966,-4.212129570283498,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark74(-10.131456284252897,-0.4392528213797837,-1.4319628626394205,-1.4550714966414562,-1.5708143427176586,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark74(-10.13566426823258,-6.05944736553704E-7,-0.025052244115705946,-0.06413297203711305,44.35377071676953,0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark74(-10.14719628580643,-82.68966945491644,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark74(-10.155413799909986,-0.2119277275179748,-0.13533600984521574,-38.221370382881624,-1.5431773878588715,-1409.9965807989627,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark74(-10.159907914130946,-0.0010879489070926094,-1.562562202941337,-0.9249089261842787,-33.563810716056,2.1684043449710089E-19,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark74(-10.162129966430415,-0.3467850767890842,-0.5559804075876436,-94.81100332058989,-0.7586394408865561,-76.37150352330062,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark74(-10.176878048957182,-0.4841012669951209,-0.522624586508943,-20.17903192106928,-1.373218863536783,82.32734252241818,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark74(-10.177779569963405,-0.4758650797347024,-0.5753476498592344,-0.8785376774909925,-1.5707963267948966,-89.56615913187623,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark74(-10.180481645137853,-0.4220096473287406,-1.0281413238491415,-20.334000401565817,-91.65484573801757,0,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark74(-10.189678676022293,-0.13261253373113746,-0.1805001424248024,-0.7599478938626341,-39.403352344622,175.76049984894757,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark74(-10.208349663912927,-0.09826687405151444,-1.2698693631238867,-1.5707963267948966,81.79627635437454,0,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark74(-10.223984834315537,-0.07344047894886785,-0.13681214336742964,-7.55957409371976,-1.4981902434352863,-133.1430728001017,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark74(-10.225178763202951,-0.17260149083236445,-1.4873845251184337,0,0,0,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark74(-10.237767197658108,-0.0018580874238819794,-0.5492197289083622,-1.5707963267948966,0,0,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark74(-10.262302241553591,-0.03575582166128291,-0.14503650380416994,-31.580808878637892,-0.16930166384143774,-44.165037036125845,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark74(-10.26680469067383,-0.00253274198605153,-0.3585040640511256,-0.3586232327934807,19.236754291031467,0,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark74(-10.26788091441609,-0.0983850461274638,-1.5707963267622171,0,0,0,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark74(-10.270933248299198,-0.10890045172902801,-0.5831571756205074,-1.5707963268052803,0,0,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark74(-10.352048043867947,-0.1261079657170436,-0.5280406965998278,-0.6457022714112682,-39.65062556298913,-14.693452771884886,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark74(-10.366299731202847,-0.605547224283535,-0.7542663688179942,-76.74545933143156,0,0,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark74(-10.37317193035874,-0.36178189425235335,-0.9352293736353552,-1.0231216642079501,-58.27776107226779,20.6133465765856,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark74(-103.79142279416521,-1.0477157143954507,-1.0783106270354017,-20.135041600237482,-1.342041644742384,-6.428524791166453,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark74(-10.382039932507503,-0.7374524729301922,-1.0705519697566241,-1.1453112652955408,-83.21159656248169,-2.201031723002309E-4,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark74(-10.411527951254119,-4.4207732179712725E-12,-0.5024496983820871,-1.5707963267948963,-0.9600518804929261,0,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark74(-10.420231234058873,-1.3877787807814457E-17,-0.019699401772281716,-76.47652621782693,-1.4444916784938686,-86.72436346008635,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark74(-104.22102371303579,-0.7425314781076195,-0.9721411882051094,-70.10560185313282,-76.91602166660012,0,0,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark74(-104.34145502978544,-0.37095614255912085,-0.43308853764632804,-32.009765817950246,-1.1144185082755826,41.19201874326174,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark74(-104.59104207324458,-9.35155228978295E-19,-1.024988358039621E-10,-0.18521427333144458,-1.5707963267950567,0,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark74(-104.62380775487568,-0.09582190592217099,-0.9032208820017278,-133.2778745490357,-1.5535321374839555,-8.003830415382122,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark74(-104.97527402754706,-0.11051034310206354,-0.3550099338764223,-82.77617704426108,-1.4676375437310882,-0.09996343469689672,0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark74(1.0891033420905814,-71.31840243285367,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark74(-109.97625142953746,-0.0332022496952841,-0.7545387505277361,-89.16178945627617,-1.2404198595200575,4.234128975059402,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark74(-109.98094823515333,-0.7717520356369231,-0.8512446834687601,-7.616690817507129,-1.5707963267948912,198.01011327838665,0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark74(-110.30231515762716,-0.24952054296294757,-0.5487207109097939,-1.5707963267948966,-0.0015506182152229396,0,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark74(-110.32892474460974,-0.4144829381031631,-0.42831423409634384,-1.155485380922723,92.25771617353543,0,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark74(-110.43710980546292,-0.06545260847177693,-1.993161316866793E-4,-1.4403501658973878,-90.45797581577926,1132.403193481527,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark74(-110.97699016666427,-0.22567340119218973,-0.9486506411258347,-26.269011547126524,-1.5687434543120313,0,0,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark74(-111.00489818505149,-0.3920688300549102,-0.4828348143223873,-1.4193294066266122,-1.5238536485155691,-0.3234287140420389,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark74(-111.28643611300508,-0.6393883328083252,-0.25062033940374245,-0.42493405104151893,-2.7029024503423784,10.654975184720138,0,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark74(-111.42067450470921,-0.273406818737312,-0.4569341936131722,-13.934296438962988,-1.5707963267948912,157.37891515480084,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark74(-111.47940803294632,-0.08758617986388861,-0.5407925402961187,-26.32231364147603,-1495.9159986037573,0,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark74(11.622541448824464,-17.600297005556897,-63.10549672103936,58.31848988973195,77.74307549506923,0,0,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark74(-116.2712364263073,-0.7644391801719016,-0.9491009506190811,-1.0224776395508108,16.753828325653473,0,0,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark74(-116.27452794697112,-0.017384621422449682,-0.5415529008153186,-0.7518710444978352,-1.5707963267948966,-7.694281052192361,0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark74(-116.37832113841814,-0.36980188938538805,-0.6725446166738611,-69.83895490844448,0.5000254802208763,-75.82438317373744,0,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark74(-116.45847949717229,-0.22037219818420128,-0.2785643054867118,-1.5703098278866272,114.05620507723879,0,0,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark74(-117.2974534124333,-0.1417831519111843,-1.1507359489099969,-20.207858001438005,-1.4589368781169831,-107.37354341908139,0,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark74(-117.37292705299336,-0.014993149664539908,-0.019887255650922336,-1.5697374506151505,-1.5690048034969166,0,0,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark74(-117.74260995599218,-0.23143227480437373,-0.31280956701642293,-63.62515175899895,-0.9533018788772906,-51.273521018258045,0,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark74(-122.63766692787983,-0.19086480420591556,-0.26369659594032757,-0.45216461303940036,-14.852303993734832,30.547782078005746,0,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark74(-122.83977520916082,-1.0796535461066314,-1.139774115525995,-1.1565068787978097,-102.4690108083233,23.716890475811354,0,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark74(-122.86812007954617,-0.592796625159508,-1.247992199564235,-1.5707963209464568,66.50340670376977,0,0,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark74(-122.92419564174176,-0.3222328582610263,-0.8039686035292846,-1.5707928138814113,182.3299507326211,0,0,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark74(-123.09406384761976,-1.0068692421299492,-1.473547747712861,-0.016991551416495554,-258.17483410072134,0,0,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark74(-123.09481110685476,-0.7217190510966418,-0.7887952648404183,-214.60801624038368,-1.4658473203646802,-91.10982740510504,0,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark74(-123.39139773383266,-0.4646512091898709,-0.6353883231212036,-42.78101671585089,0,0,0,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark74(-123.433340871252,-1.8651361006459848E-16,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark74(-123.46130884634664,-0.0748895012540789,-0.7055785430008212,-1.0034720760955231,-1.5425223892191886,133.91203965694757,0,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark74(-123.47038546877607,-0.05896652705564762,-0.2170741675822277,-127.00155583645542,0,0,0,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark74(-123.47911959124008,-0.3035018361464931,-0.801942441110457,-0.9997776799086258,3.2439069680179387,0,0,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark74(-12.34888067301118,-82.0796364002369,-30.968363802365985,-11.606826889888367,-13.93727765352557,0,0,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark74(-129.37327267100451,-0.39888721525151855,-0.4900554952842038,-6.919918467465144,-0.7357369738013331,-78.57328483061292,0,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark74(-129.3958023174457,-0.15986985866417713,-0.1613383938593802,-50.27257293093787,0,0,0,0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark74(-129.46137325629707,-0.03242955892668534,-0.5470456260521113,-13.154542127403118,0,0,0,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark74(-129.7391161831405,-0.24212658500190587,-0.7129098139039958,-1.5713517132489423,-102.16476703827018,0,0,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark74(13.019776957296685,77.9321082437732,-55.28031268754954,0,0,0,0,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark74(-135.17683324653115,-0.3509438226713528,-0.58024198035571,-133.31942007764144,-1.522586091770094,0.20636437393942253,0,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark74(-135.84945959082927,-0.38844110090838235,-0.44851298220406155,-101.08610927031562,-0.002221176592371421,-25.43262864738041,0,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark74(-141.4625938558847,-0.20628102273808702,-0.044594875655119326,-94.76600984851072,-0.3774734242285538,-9.391920920709396,0,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark74(-141.47836818384957,-0.0900265070179479,-0.7335670186591842,-0.7348277874786951,-27.434533657644767,0,0,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark74(14.324150083279648,-6.649153956688721,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark74(-147.85489510322057,-1.2190734379521675,-1.2661504475763374,-1.3657223851502827,-70.79168236076713,0.313395696618997,0,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark74(-154.31386565760863,-0.11280632435704198,-0.12030842764849103,-1.4023626117891297,-1.5707963267948966,-50.26566812983631,0,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark74(-154.33969651274415,-0.08615020497431658,-1.0481262667900029,-1.0944037088494487,-158.8755181584866,-61.789187443186556,0,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark74(-154.66954351189364,-0.025801305913496282,-0.6756313860968977,-1.5310542034231125,-0.05970335029027707,0,0,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark74(-155.0823467393297,-0.38710331013332455,-0.3873031720749901,-103.68812199251259,0,0,0,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark74(-155.136355337466,-0.30535845863014993,-1.287248004490347,-1.3217333725937337,-89.23949330330676,-69.71714331995918,0,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark74(-15.515292723671806,-10.08983121603859,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark74(-155.24997613676737,-1.4886388635464738,-1.5558303033601717,-8.881784197001252E-16,-63.98604555569893,-1336.0718663370333,0,0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark74(-1.570796326793114,61.261056745000566,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267934408,-45.553093477046815,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark74(-1.570796326793578,-89.53539062731045,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267936427,-1.5707963267949054,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark74(-1.570796326793745,80.11061266653911,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark74(-1.570796326794072,42.411500823464,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267943623,-1.5707963267948948,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark74(-1.570796326794893,89.61148790915067,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948948,-125.66370614344457,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948957,-1.5707963267948966,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948957,-64.97064371753,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,0.0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,0.44545655685924074,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-0.4619620410336316,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-0.8315927646297441,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-100.0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,1.2021415859081945,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-12.504399697673925,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-1.3877787807814457E-17,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-15.386548179976279,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,15.44530560088107,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-1.5707963267940674,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-1.5707963267948963,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-1.5707963267948966,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,1.5707963267948966,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-1.5707963267948968,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,1.5707963267948968,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-1.5707963267948983,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-15.708020430851766,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,1.5E-322,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-169.64600329384868,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,1.734723475976807E-18,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,1.765893391354112,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-18.53603290212809,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,18.974555921538762,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-19.456793466794284,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-194.7878424952376,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,19.64067714156423,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-2.0E-323,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,2.0E-323,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-21.991163833917618,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,22.7814363118828,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-24.825038818341888,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-24.97242537623218,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,25.13664747871836,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,2541.4977099014627,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-2572.280426463793,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-2574.483927279059,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,2599.379357654055,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,27.73846080203164,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-27.76318636341551,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-27.9564004790182,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-28.27433388230837,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,30.513043544056785,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-31.770116136778384,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-31.944164764954923,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-35.378226998463425,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,36.128315516282086,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,36.55268762254237,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-3.693670568733282,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-38.16346157491128,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-3.910318545279494E-149,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,3.910318545279494E-149,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,40.27265460135533,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,40.840704496667165,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,42.411500823465666,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,42.536722443087555,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,42.66076592772008,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-42.967569326399115,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,43.98229715454849,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-45.553093477048456,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-46.87780738816371,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-47.911911997182415,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-4.9E-324,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-50.22638206471221,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,52.356307104951554,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-53.55175693564402,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,5.414524583180082,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-54.56641411813982,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,54.97886662544742,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-56.36638745368741,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,56.37793410723981,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,56.680370911015984,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,58.062058848966444,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,59.93645343000301,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-61.29389560249773,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-61.81073452467702,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,61.842117708673996,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,62.67322572072749,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-62.83185307178638,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,62.84300386190418,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-64.40264939858709,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,65.87904616361361,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,6.657295440895972,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,66.80343116690733,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,66.81489184515056,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,67.29082519744827,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,69.11699150397546,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,6.931146637936003,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-6.938893903907228E-18,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-69.82100519503022,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-7.093674440890747,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,72.25897927114843,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-73.2616664981563,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,75.39822368623214,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,78.28477682351574,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,78.53981633974482,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,7.853981633974484,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-8.103981633974485,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,81.52941641283542,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-84.82300927631896,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,85.17844655113589,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-86.1003851086989,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,8.673617379884035E-19,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-88.26818907429515,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-90.56946191222194,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-90.73177552722176,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,90.92080254584563,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,91.10618695410386,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,92.097196887645,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,92.67698328089165,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-9.424779868583316,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,95.50601919855038,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,97.14286199297456,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948966,-9.7383219991098,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948968,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948983,109.95574287563149,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark74(-1.5707963267948988,-152.34362588141727,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark74(-15.70796326794948,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark74(-15.7398012317915,-0.11916661273606666,-0.3581836457615882,-0.41087436087854,-2.6542107484534,10.576549326300523,0,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark74(-15.739997311201394,-0.5336518780919941,-0.8063481300348297,-13.107307671715386,-0.07029608859959069,3.348411333078539,0,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark74(-15.752189725587465,-0.7426988187384076,-1.14681954657031,-1.165367395082427,-1.5707963267948857,96.40841165069078,0,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark74(-15.779003278894788,-0.9065574243562626,-1.53276165885165,-1.534062467161509,-1.5707963267948966,100.0,0,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark74(-15.78498573700314,-0.4165009738350891,-0.4467258291546954,-0.8720805037486272,-33.38536991138035,42.685451130336276,0,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark74(-15.790758624159256,-0.17404458872206355,-0.46806624030603317,-64.11598817490166,-1.2914410565188639,3.149099783831984,0,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark74(-15.80886182043306,-0.0497600821938068,-0.05711696595841737,-0.2580978925497168,-1.5707963267948948,0,0,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark74(-15.8088798363096,-0.8155460773348816,-1.0478704586389553,-70.1695074122906,-1.5598377924939661,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark74(-15.811841015419734,-0.5085961164759178,-0.6658790107208281,-0.6784085322782423,-222.35633663533292,0,0,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark74(-15.836295216263377,-0.04511963056398938,-0.649114510419062,-0.6505794442078536,10.19063886570011,0,0,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark74(-15.837373150227732,-8.849575309589683E-11,-1.3604003273355374,-0.9687118300695625,4.143618978528995,0,0,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark74(-15.850305380950129,-0.07924564611687601,-1.49555882232138,-152.32543754058787,-1.536040127318091,-1.5707963267948912,0,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark74(-15.859050117812716,-0.2930702945617375,-0.296945651874989,-1.5707963267948966,69.1251992680031,0,0,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark74(-15.866632189500677,-0.130746881620047,-0.24089998724076597,-3.3881317890172014E-21,0,0,0,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark74(-15.869637207332342,-0.8327059454965002,-1.5652330781125652,-70.42308811618085,0,0,0,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark74(-15.878156610193205,-0.11487651045355893,-0.5756582463445583,-0.9219719314022051,-83.05419886041297,0.0,0,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark74(-15.880919602560667,-1.3648342431659412E-8,-0.19691306036533646,-0.9395777648765428,-7.421106883009248,8.271806125530277E-25,0,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark74(-15.905542679792315,-2.7659659574347537E-12,-1.5092171359115323,-1.5707963267948966,1544.3268121325148,0,0,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark74(-15.920221024101622,-0.004225644586354378,-0.595932032609787,-0.7403064109947388,-72.45564675640858,0,0,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark74(-15.953532469029106,-1.5707963267948912,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark74(-15.953801648727211,-6.761040013834385E-10,-1.100473545208219,-89.5226744690799,-1.5707963266767393,-38.13600924623891,0,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark74(-15.955731632051803,-0.2834466788535912,-0.24182625883876294,-0.33891647830686567,-46.65754397877439,-0.48433880544082764,0,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark74(-15.96124712821863,-0.7674277190007557,-0.8191732908519924,-19.911846515699636,-1.4785650570192417,-1.5707963267948968,0,0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark74(-15.96595430133592,-0.9683325060597552,-1.0366791917171443,-31.066939124522868,0,0,0,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark74(-15.969926080201738,-0.004211611127214304,-0.7415787991406949,-1.5707963267948966,61.35493773886785,0,0,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark74(-15.986675648372882,-0.4295623100050898,-0.6165613255790912,-0.8999653580107034,-52.228637597283225,104.92838898117881,0,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark74(-16.01657465815566,-0.5555687953188713,-0.555568795323288,-34.5575207975828,0,0,0,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark74(-160.2312452806264,-0.2098124821197287,-0.8882667051842649,-32.36922209473088,-0.36088777552103846,66.05050383251427,0,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark74(-16.02557690698265,-1.2533928885334746,-1.3285372195315313,-1.548776321482006,41.203125739763735,0,0,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark74(-160.36242994960372,-0.23270720701907133,-0.9746624159864272,-89.50479299851823,-1.5707963267948912,-4.40583937846941,0,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark74(-16.05983184553466,-3.961908800465567E-4,-5.6319792113222224E-5,-9.09858588036369E-5,-160.39479226325386,0,0,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark74(-16.064555955562508,-1.5312574513945907,-1.5531116749888296,-1.5707963267948966,0,0,0,0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark74(-16.07312788726961,-0.023475817142848996,-0.028763604852297814,-69.19228245838401,-0.20274255040828076,0.0,0,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark74(-160.75898455907182,-0.2773571617031449,-0.3199011547490844,-0.35069699323498904,-605.4062175911712,0,0,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark74(-16.091484514763728,-0.02952987519402536,-1.5707963267948855,-1.5707963227801967,0,0,0,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark74(-160.92931515589544,-0.7833557863978886,-0.960353047622603,-89.12307467551452,-0.001108623484136706,0,0,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark74(-160.95522997472798,-0.04096756364746024,-0.17501006956701662,-1.239131835184922,-45.34038416255231,0,0,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark74(-16.103271487995997,-0.8676585150428239,-0.856610412957425,-1.2037020214279144,5.181481221884698,0,0,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark74(-16.105195564696434,-1.2615639252473714,-1.4443754555795458,-83.13375586694504,-1.5706267255641904,9.656582279221437,0,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark74(-161.15069451369473,-0.026018650824893772,-0.13441477052030404,-1.214458699307445,-1.558421272164923,-156.77548787501192,0,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark74(-16.13696131344634,-0.1617428515406789,-0.5816079370920694,-1.5707963267948966,61.2603947995009,0,0,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark74(-16.146627329846662,-1.0888478976097535,-1.117515613099158,-1.5707963267948966,-1.5707963267948968,0,0,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark74(-16.162765216867964,-0.7448887179530745,-0.8342317218737071,-1.0468863117091183,48.70442845462274,0,0,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark74(-16.167832142723896,-0.1484180957782848,-0.5982524950016879,-32.040159652063885,-0.7348618089893639,4.203025955198775,0,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark74(-16.182370405706354,-0.8610209310528248,-0.9170728138644134,-1.4230250486772198,-1.5707963267948966,-75.3859456371311,0,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark74(-16.189377559361187,-0.9240851177966442,-1.5537900062996846,-7.837543083171957,-1.5545534032711328,-1.536274160859626,0,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark74(-16.194521171868438,-0.1406478023117982,-0.7925324514679069,-0.7090481474960058,0,0,0,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark74(-167.08671974836437,-1.0615089182448902,-1.3370050798010717,-1.5707970235791926,1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark74(-167.1817888709322,-1.2226607011330004,-1.3081405686613679,-1.3089334380552486,-38.44822604072826,0.11778967850520417,0,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark74(-167.4684440136093,-0.020227276597435576,-0.03147364953521126,-0.05649210494892021,-87.16300570354372,0,0,0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark74(-167.6557848714822,-0.15043282493635246,-0.5961421676257886,-32.10090112393964,-0.8482121016195623,182.22615477371437,0,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark74(-168.0431379714903,-0.26460544440440464,-0.3224409527148975,-139.72136686955025,-0.0012109796416098903,0,0,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark74(17.167480571138157,82.06018265478468,57.83211873204024,-2.4162606776164637,61.63988844642327,10.229914038843418,0,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark74(-172.8057419673242,-0.5296271507596159,-0.8243228010042671,-76.35488158513257,-1.1028774283591218,1.5722586082236765,0,0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark74(-173.24289728913564,-0.06539678815696798,-0.2300391660034764,-0.521277936459421,0,0,0,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark74(-173.24993105012146,-0.30751338193391575,-1.0411964931517765,-1.3496431822463957,-0.013871063745193035,0,0,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark74(-173.25941890383646,-0.0069232760012570265,-1.3361308012757218E-4,0,0,0,0,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark74(-185.7322894284873,-0.05778394213511717,-0.9516670280624062,-7.412026049606569,-1.1775008636243895,147.63375903561598,0,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark74(-185.8404161830012,-0.48123944574937433,-1.4444155138391355,-1.570405357238496,-89.55786182212047,0,0,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark74(-186.11213642680465,-0.17373493295642722,-0.28558537077438473,0.12088698182153124,-15.670659510841858,5.4431436965805915,0,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark74(-186.2693516218443,-0.47479996655158807,-0.5503305721480699,-82.85811172538484,-1.0066425709017226,0.034303467395318483,0,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark74(-18.707621269404086,-38.62040020663488,39.27277934854982,-18.230540588635208,67.66051870473166,-45.01440385101163,0,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark74(-191.75635758209575,-1.106966490343071,-1.5707939706360352,-1.5707963267948966,-153.94036022662408,0,0,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark74(-192.1713483003761,-0.6876138455135719,-0.7744388272301933,-0.8051102461923525,-39.79029085261581,86.91084486243011,0,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark74(-192.40857392866064,-0.3632934434273256,-1.1943131550432033,-26.41700281804179,-1.4139828759644726,-74.49434055658581,0,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark74(-192.46405273354537,-0.8397799421862651,-1.3423502002087437,-1.4113204494786658,61.6338578113008,0,0,0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark74(-192.56213367976252,-0.35368185618267123,-0.5433392813475548,-0.7648882793860088,-19.846425512292882,0,0,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark74(19.801607926915324,90.40543721027524,90.69228748295515,-15.7559422459437,0,0,0,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark74(-198.54330560077406,-0.16039078810625684,-0.21181528814565537,-25.349951192535286,-0.5392195731198951,113.23482459800965,0,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark74(-198.54686162914487,-0.4872664228371173,-0.4916874111301094,-1.1196507587655704,-47.90529431134398,0,0,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark74(-198.91806223239308,-1.5081040463409563,-1.5481270202016881,-0.7604282382816954,-14.946286060602858,47.88445950997257,0,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark74(20.18220959495649,-67.95134088241127,87.46699171267292,30.07182531132929,-69.68581535305867,0,0,0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark74(-20.424971187523838,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark74(-21.216565102809497,-63.14279637424085,-33.88921784142798,55.29723296243844,25.975886963705832,0,0,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark74(-217.2041456760041,-0.46636157229144426,-0.19756772681985946,-6.55474554309361,0,0,0,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark74(-217.74102553621736,-0.5913468187882511,-1.0107317228050192,-1.303880390362697,-33.23731525528669,39.354855992335985,0,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark74(-21.992634271460133,-1.3545874244417904,-1.5707962422959265,-1.5707963267948966,-1.5707963267949054,0,0,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark74(-21.997508528307392,-1.5707963267948966,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark74(2.2009220549576582,-88.1774413537209,65.9932635813432,57.072466966041645,-93.20597442155893,0,0,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark74(-22.016310320707856,-1.0891566272918805,-1.4658876113935067,-76.88885169848362,-1.5706821834025066,0,0,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark74(-22.243684544748344,-0.1509969973522991,-0.2156155708324099,-6.73194908489711,0,0,0,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark74(-22.251917441418932,-0.25809654683037775,-1.472555480863794,-63.800339457200785,-1.080652383499478,161.14302600119223,0,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark74(-22.25461409747222,-2.2047321627911086E-11,-0.3441735461598615,-95.14975419493001,-1.4364161015764614,-51.769348878541145,0,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark74(-22.256039630818535,-1.1070035277122903,-0.7267325638060346,-13.346716501731839,-0.7952393708336785,-0.8478991434055057,0,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark74(-22.278908501075037,-1.5707958002832563,-1.5707963267342246,-1.5626340080570469,-1.6543606505838087E-24,0,0,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark74(-22.284758908030867,-0.022545291916424404,-0.0985844925525885,-0.9379316087462257,-13.136100655308667,0,0,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark74(-22.2874340183415,-0.4844704553648341,-1.1490031212592182,-0.15399479276560513,-228.36162064249547,-0.04220116703107202,0,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark74(-22.29003489697348,-0.028519224368460955,-0.0557690611281341,-0.1710833765643731,22.536112703363557,0,0,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark74(-22.293432461120595,-0.9383648938087792,-0.9954626611974197,-1.0742592981591679,-1.5745838825463447,0,0,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark74(-22.29705081909773,-0.26062279522022336,-0.3094029583007978,-81.9967556266405,-0.46254846188885274,1.5707963267641276,0,0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark74(-22.300523094825223,-0.5981121075502307,-1.111819057557227,-1.2379039892034314,-14.396571132615044,4.872144265887192,0,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark74(-22.306204091243213,-6.193384033266044E-10,-2.2668169667135835E-9,-1.5707963251860309,0,0,0,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark74(-22.307656249848726,-0.033631834464008636,-0.16896461563837112,-0.33881283041030785,-90.32208308201939,-7.9035409506882015,0,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark74(-22.321917695549015,-0.03306606502496501,-0.03344661483013578,-0.6602335442428163,-70.6761392308716,0,0,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark74(-22.3221009307239,-0.16673048193383802,-0.7945143239634966,-1.007748939003591,-58.44889128300173,28.243061527950633,0,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark74(-22.332698231219865,-0.6000966641620362,-0.7456001854044952,-132.69282501547838,-0.3322496345838144,-163.33767255822855,0,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark74(-22.333188807210774,-0.0946156488867469,-0.11003380987664906,-0.25441087553822683,-90.52981225338539,0,0,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark74(-22.336488425878642,-0.6690875093131138,-0.7205346626978325,-1.5707907894479134,-1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark74(-22.339518923152895,-1.570662817961629,-1.570796326794877,-1.5707963267948966,67.80781812153998,0,0,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark74(-22.345589444527267,-0.4271698051426398,-0.6159892220174251,-1.570796326737016,-1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark74(-22.347332205512615,-0.8716784824408261,-1.3509320462818588,-1.5023618908701564,-1.5707963267947793,0,0,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark74(-22.34734101959365,-0.572662766713618,-1.0631192889974956,-1.5401872783041999,1.0842021724855044E-19,0,0,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark74(-22.35572590481508,-0.7432961695038257,-1.366508718154097,-1.4345665416746485,0,0,0,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark74(-22.395372737817762,-0.12259264492916155,-0.9073913324598292,-89.0349020960143,-1.2044665907937575,61.16554101761799,0,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark74(-22.401428977414337,-1.0842296576241541,-1.4017232286677836,-6.657390943183401,-0.4102800071356745,-6.314972477691185,0,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark74(-224.06184563971905,-0.8507804692514405,-0.953946261588094,-1.0302700309463155,-70.30509595161008,0,0,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark74(-22.414501699574018,-1.145881730058941,-1.5707963267948912,-1.5707963267948966,1.5707963267948983,0,0,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark74(-22.415501322216457,-0.5035418017495115,-1.0823442958347196,-70.30735759524232,-1.495430091346996,-183.74271188634563,0,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark74(-22.422167798930566,-0.7607743980394962,-1.0312607947024441,-1.0529981881124164,-1.5707963267948966,-32.98425084893277,0,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark74(-22.434410623432747,-0.5758433417734325,-14.71480882673299,0,0,0,0,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark74(-22.436248142451248,-0.385039594917675,-1.3693003686027558,-1.396541759989061,-1.5707963267948966,-28.276876464208133,0,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark74(-22.446610301144624,-0.08689665039115119,-0.08815943033619532,0,0,0,0,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark74(-22.454439853094208,-0.033998806544806554,-7.346839692639297E-40,0,0,0,0,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark74(-22.472541248773926,-0.09509100444321184,-0.1357830045434564,-94.59044464275743,-0.3680478555559812,96.99915531518478,0,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark74(-22.48022294449598,-0.952680955942517,-1.047531385329845,-76.72024932086852,-1.4799385258850306,29.820323495338727,0,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark74(-23.13370116453035,2.688636672197674,43.56485137869174,44.743862882019414,73.74105328880117,0,0,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark74(-23.183511531849035,53.1928105720574,45.363813032211596,-80.9167584164082,84.12078512329776,-23.043682647145317,0,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark74(24.021330324990714,31.22754746039385,45.250927498569155,34.66437716124426,0,0,0,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark74(-2.476555283241993,-11.949645268523028,7.895007866237165,-98.53957892383723,-51.63605012253436,-87.8285935837749,0,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark74(-248.9466066168965,-0.17222831854027615,-0.2513111787083584,-1.0400031540073114,-1.5707963267948983,56.5340294802794,0,0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark74(25.584872647509343,-28.92553449202906,14.789337724277345,85.01684558595042,71.12060888591668,-48.19936660020816,0,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark74(-25.679192619143734,-5.412555394491861,49.12615834576059,-28.351600940894414,99.69752212683687,-85.48491508158236,0,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark74(-25.83528116970237,-3.4298231215310153,95.2444099889882,-62.09738046851903,-57.88097682923228,-72.34034959981753,0,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark74(-2616.33452244045,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark74(26.605945285875677,-62.4129302673176,74.58141891313804,-90.21690401881395,-51.86273454066912,0,0,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark74(2.7300477137024473,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark74(-2745.5738107639786,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark74(-280.98453149654404,-0.8317738235206349,-1.452715793142915,-1.5291750225694434,-209.14121766295756,0,0,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark74(-28.3487522669557,-0.061858258303424174,-1.0842558278727141,-1.42964240554855,6.938893903907228E-18,0,0,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark74(-28.353480741999864,-1.2926761862627738,-1.515019957052872,-1.5707963267948966,73.83510789012836,0,0,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark74(-28.36511423259565,-0.7415078985879663,-1.5091366480627586,-1.5095481018592336,-12.568384536057792,0,0,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark74(-28.368658924958012,-0.008745115481436416,-0.019342390950151667,-0.019729025776398006,-25.740275131231897,0,0,0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark74(-28.369362425161437,-0.04772284676065565,-0.7839630611384386,-95.03605295351926,-1.554574645536061,-2.296849304067433,0,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark74(-28.373718609718257,-0.016810447127081848,-0.9339250300023488,-50.54470920925585,-0.05410269543306092,1213.2493471791597,0,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark74(-31.375215028105046,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark74(-3.1578798733896547,-0.2859559365326141,-0.3057963364856267,-0.31343654613923905,-112.96310970857098,0,0,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark74(-3.1610674633590463,-0.0730082451272791,-1.262614178647196,-20.241658184397252,-1.5707963267948963,-6.485163368222942,0,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark74(-3.2694098729677,-0.09434146681218164,-0.4205295977882542,-0.3603310599784761,-31.802526309985655,100.0,0,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark74(-3.274693060698739,-0.9518648996566432,-0.0039036241507309074,-1.5707963267948934,-1668.826280011757,0,0,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark74(-32.75402075821307,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark74(32.953882826893135,78.47342150925968,64.24929581635726,-80.9961619073315,-37.08331756774497,50.74671108601618,0,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark74(-3.2959359571291804,-0.9316170695802054,-1.0652836133385517,-1.5707963267948966,-1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark74(-3.3213650756083055,-1.079822773747508,-1.11225571551117,-1.3786710842773513,-1.5707963267948966,-53.57237121909361,0,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark74(-3.3237959548579,-0.5718191483660098,-0.7691375853537398,-76.25510120515743,-1.2921183653851591,-111.91240058708486,0,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark74(-3.3494883428250355,-0.01507939202854755,-0.0350998775543144,-0.03509987757549491,15.589544661131447,0,0,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark74(-3.3560498738260733,-0.29487121036838687,-0.38399924019689097,-1.5707963267948966,-36.97812358205796,0,0,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark74(-3.36157980372235,-1.5707963267948912,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark74(-3.381131704955748,-1.0225149624548782,-1.045965653191614,-1.3215343913280095,42.580699685134505,0,0,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark74(-3.390380827475485,-0.5460699759733137,-1.3865431272961346,-1.407946012426708,-64.41124248904897,57.55156232662647,0,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark74(-3.3931141332522103,-0.24501318374479442,-0.9915570309945226,-19.921286115999916,-1.3512247093984715,22.019521188761395,0,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark74(-3.4072783314323205,-0.6563267710134708,-1.5707963235432718,-0.3664616188450104,-46.73668976301272,4.712596324169977,0,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark74(-3.4189918559838617,-0.963712205568921,-1.4802101843984872,-1.5706794691414616,-157.0810759765609,0,0,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark74(-3.445752441399769,-0.9505575563427782,-1.1108507458825692,-1.1744488986693233,-83.64043833594124,4.7125165244272385,0,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark74(-3.451440225206133,-0.06878364096993768,-0.8676249193792981,-1.5707963267948966,1.570796151873623,0,0,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark74(34.547185319417,54.692496345934615,17.317810728064998,94.75312696274705,91.664323768548,-33.448842974376674,0,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark74(-34.561731178366415,-0.6399029012213007,-1.5697733938698435,-1.3578369331305051,-1.570800356215347,0,0,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark74(-3.4569101110146474,-6.7504175200882805E-9,-0.6323212657208965,-1.5333741886199475,-1.5707963267948966,-44.31461448599327,0,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark74(-34.582369808668574,-0.6635269434419944,-0.8088798525857768,-1.2261425720282968,-83.53126148294982,281.3092792445659,0,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark74(-34.58499766433677,-6.780432560055389E-5,-0.5538622887382071,-1.249863767588649,-76.67502093978378,0,0,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark74(-34.607042982070915,-1.5707963267948966,-0.4486056968261288,-0.5087404499718676,-96.79456256463233,-7.926916628534971,0,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark74(-34.61599759853769,-0.1810246139549183,-0.23432928544342607,-0.3098647012138257,-1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark74(-34.624064609437916,-1.1154896820531874,-1.1154897703873945,-0.48655232560010536,35.114601230260654,0,0,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark74(-34.62983438663556,-0.03912175960393129,-0.15219657916386448,-0.7220635802297584,7.75328912852104,0,0,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark74(-3.466236912465739,-0.3975794811378864,-1.551338252728634,-1.5707963267948966,-53.81246684291287,0,0,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark74(-34.67713051763728,-1.5709633782031713E-5,-0.1811392349112822,-0.7233729246592873,57.32215189922826,0,0,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark74(-3.473042791418248,-0.014434443603511569,-0.43791072134223324,-0.43814142303631126,8.673617379884035E-19,0,0,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark74(-3.47506693682125,-0.7639541104128078,-0.9264718229789826,-1.1415154472827453,1.570796326794898,0,0,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark74(-3.4797995849033345,-0.041656419974672315,-0.1491974975765455,-19.030995064525502,-0.6088742274428759,-57.19848778418813,0,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark74(-34.808457823383705,-8.37189582694908E-13,-0.6561781668604898,-1.5707963267948966,-21.664847949094504,0,0,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark74(-34.81673868970742,-2.220446049250313E-16,-1.1867056567234566,-13.831045564362569,-1.5661433377092457,0,0,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark74(-34.82086678935523,-0.043270199860781344,-0.06315807279674066,-12.666039389623684,-0.17225753654960643,53.592261327670826,0,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark74(-34.82539467845494,-0.018133715957501642,-0.4527291911425874,-1.570796326343783,6.81206457239491E-10,0,0,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark74(-34.82804473257302,-0.07111919264976052,-0.8228969243196892,-0.9486213310343281,-127.61233221370335,163.87852142855434,0,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark74(-34.857308838761256,-0.02442628982705938,-0.03232116021081074,-19.17367482070452,-0.6396091994130183,-88.9090406309476,0,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark74(-3.488581990245485,-0.1279392874226433,-1.5707955074035158,-1.5707963267948966,-0.0919993830996727,0,0,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark74(-34.88999410550166,-6.637180098851757E-11,-0.2550736017299423,-0.2689833093518729,-19.11863685843753,0,0,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark74(-34.906161396622224,-0.40292447470447285,-1.2451362149518168,-1.5707963267948966,2.2035079751987543,0,0,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark74(-34.909626204005974,-0.10651216087660087,-0.1590078218914357,-1.3049614197163555,-182.012330927275,0,0,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark74(-34.922394262894905,-0.20762418224498314,-0.2542588123828559,-0.7901312295601173,6.172034748548896,0,0,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark74(-34.923641053083536,-0.6039116576758045,-1.5707963267948948,-1.5707963267948963,0,0,0,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark74(-34.93175165142337,-0.17520649532561128,-1.5707961720275612,-1.5707963267948966,1.3552527156068805E-20,0,0,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark74(-34.94108558116796,-1.2399873852994183,-1.4960121672453581,-1.502079479077697,-1.5707963267948966,-57.91954418318001,0,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark74(-3.4945097429487535,-0.9286447002076459,-1.3551125145965521,-1.4053587903451263,-1.5707963267948966,-83.23886895004702,0,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark74(-3.4945349906786856,-0.3421601244826068,-0.4124502385054213,-0.4355326388318721,-8.935814795815421,100.0,0,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark74(-34.95325617671212,-0.7988248993892881,-16.938801397584655,0,0,0,0,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark74(-34.95828167886929,-0.2905035141909755,-0.3936016289381833,-0.7711265108334484,-83.48098784606235,0,0,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark74(-34.996588683772174,-0.2715491070942364,-0.510323664318126,-1.2107207968846243,0.0,0,0,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark74(-35.00775628228479,-0.19930844752256172,-0.6377157960677475,-1.391308584013086,-42.82547792832331,0,0,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark74(-35.02678226165742,-0.8610740339189671,-1.5707963267948963,-1.5707963267948966,90.82416043720278,0,0,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark74(-35.031311269221334,-2.128359711653407E-4,-1.5321918917879385,-1.5707963267948966,4.5719495651291E-100,0,0,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark74(-35.04303604983961,-1.5310504435442053E-11,-0.2520316319624312,-0.5924660790646166,10.39138574435735,0,0,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark74(-35.05681855116647,-0.8004653438805631,-0.8171241683867426,-1.1453903134786685,48.4804378653366,0,0,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark74(-35.07409677739653,-0.7218325621484092,-1.2652227589230105,-1.3097003439887749,-1.5707963267948966,-7.143235814415696,0,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark74(-35.07862996785713,-0.8103163600835959,-1.232439170638938,-14.0011923271852,-0.0011392725687602145,-6.350921330890626,0,0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark74(-35.08238345889834,-1.360851350938396,-1.5707963267948963,-1.5707963267948966,-65.97441515115915,0,0,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark74(-35.08423996757557,-4.8502986753131025E-12,-0.08467382781317302,-0.6047521596935517,-51.027910887566065,0,0,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark74(-35.09764686878979,-1.4217071906740686,-1.4433627324791103,-0.013353829268874289,153.9164417026816,0,0,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark74(-35.113430303107556,-1.1763847154393527,-1.2083173586565656,-1.429066889035408,-1.6543612251060553E-24,0,0,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark74(-35.11570040020092,-0.0022630253501918973,-0.5054873085460982,-1.5707963267948966,91.33001333120893,0,0,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark74(-35.14267488922788,-1.5117832554169017,-1.5178156064993145,-35.378481561614436,0,0,0,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark74(-35.14680830528178,-0.08722115390561935,-0.8568488773977421,-26.643731120627148,-1.570796269814125,0,0,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark74(-35.244528359207706,-1.2619744802363964,-1.3507806044667716,-1.5054228092338442,-1.5707963267948966,0.0,0,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark74(-35.2676220600347,-0.2600793944408393,-0.6614673254935403,-0.6587486866548541,-40.55672199358487,-0.2839811008880204,0,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark74(-35.295482080490785,-0.07196892608591243,-0.07224459590033927,-19.94815148471671,-27.060969828799003,0,0,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark74(-35.30816105537189,-0.07687725927610009,-0.1004674202868774,-0.059819920303112895,-52.806910296976284,61.68112793298851,0,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark74(-35.3103776574719,-0.02539541312342465,-0.6805782092455336,-0.6805782094214736,0.0,0,0,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark74(-35.31157991930915,-0.2317420698123079,-0.579813000371189,-0.6317581510784367,-109.25930277344237,111.35151161751166,0,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark74(-35.31667726638093,-0.5814427032946914,-1.2397894226866455,-7.5615440035335,-1.2923862208583639,-12.785297734866512,0,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark74(-35.32496863475585,-0.7451020815401347,-0.9677167934319303,-70.17877936464431,-1.069474610614077,41.9663104395855,0,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark74(-35.329883905419806,-0.12442524711266252,-0.2598828746423755,-0.5364896523774684,-78.00332668736736,0,0,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark74(-35.33179796616403,-2.683501489521183E-16,-1.554619217287144,-1.5707963267948966,22.9847410985325,0,0,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark74(-35.33200817992559,-0.07532541091472333,-0.6527327189344452,-0.809641840345794,-1.5707963267948966,-204.30476578370843,0,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark74(-35.332921096031,-0.42532434192007734,-0.6747270153362267,-0.7055853093511305,-63.8737267451582,-2.5849394142282115E-26,0,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark74(-35.33366499532155,-0.5344828013365377,-1.5649969896841718,-1.5707963267948966,135.06707324561472,0,0,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark74(-35.3369679667017,-0.026301761844775704,-0.577116247673066,-1.046722258380381,-1.5707963267948966,-20.420431792221528,0,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark74(-35.34598834974431,-1.1820618868842794,-1.182648569396808,-13.749053153894263,-1.2975992442515576,-0.6982331549807808,0,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark74(-35.35366501765135,-1.4716374322557946,-1.4947311816655298,-1.5707963267948966,0,0,0,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark74(-35.37766490707524,-1.036126620406969,-1.1103939670154301,-76.61426345737524,-1.44260425203182,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark74(-3.5392183281049974,-0.6660507699507691,-1.1573804610629332,-1.1586692676435082,21.979206401768707,0,0,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark74(-35.39517547378115,-0.9703719583442241,-1.3190177825436515,-1.5707963267948966,-35.373677375582815,0,0,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark74(-35.39666623247276,-0.32004507282180006,-1.0285134264233449,-26.25859540475588,-1.2185475173024685,44.76838354416614,0,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark74(-35.403147567132876,-0.19477343535208114,-1.0199667537433055,-1.0240702333779768,-1.806725976102395,100.0,0,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark74(-35.40819759530265,-1.7448058048983302E-11,-1.5707963266696237,-1.5707963266942127,1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark74(-35.4139356432331,-7.836626313508312E-11,-0.508266592821127,-0.20580699378702416,-8.56407580617001,-1107.062713539685,0,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark74(-3.5417528491207677,-0.19341688608305682,-0.3888049047830627,-1.5707963267948966,-18.848152373953592,0,0,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark74(-35.42913980273013,-1.529435232862439,-1.5685423357049386,-1.5685423357049488,0,0,0,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark74(-3.5437787616422014,-0.04323280211830087,-0.43576474104236906,-7.267900419610946,0,0,0,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark74(-35.439080344244616,-7.419518534436739E-13,-0.0010504468281341624,-1.2679392930139177,-1.5707963267949197,25.99523544852201,0,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark74(-3.545566384921951,-0.5716533795948641,-1.334244276390227,-70.44928265536568,0,0,0,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark74(-35.4605620269501,-0.04512765949465136,-0.17096815426202738,-1.5707963267948966,63.08281880059525,0,0,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark74(-35.46338165036491,-0.004685924231935701,-0.6455354166986896,-13.459612425311438,-1.5707963267948963,0,0,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark74(-35.493082243135945,-1.2189712273451319,-1.4826790312990719,-0.6578602944855223,-59.03179645585535,3.8934727215423943,0,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark74(-35.49715771359684,-0.022069215777269835,-0.6469316102414964,-32.06992189127614,-1.5707963259811908,0,0,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark74(-35.50412183052301,-1.1833325966470295E-12,-0.9788225271454403,-1.5707963267948961,-35.67009065564302,0,0,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark74(-35.50668068650076,-0.2598781692240042,-0.5665453564644451,-98.8117386846795,0,0,0,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark74(-35.52988237811394,-0.011217176435878072,-0.011367276886431976,-254.51892934706018,0,0,0,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark74(-35.54299443806381,-1.57079632652317,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark74(-35.544095373066824,-0.41941242585454686,-1.229488952806875,-246.40585960915294,-1.3617255994776565,3.1905334181235703,0,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark74(-35.54580612612273,-0.07955828052702074,-0.08417362538011186,-0.10442855070560923,-43.982332611801695,0,0,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark74(-35.545840770151194,5.551115123125783E-17,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark74(-35.54877409386735,-0.9844902252511153,-1.0335661742291349,-1.1340141446817913,-33.35295337235194,0,0,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark74(-35.5591581885144,-1.5707963267948948,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark74(-35.55975755985007,-1.084007913121178,-1.2178211745520442,-1.5707963267948957,73.03986632295428,0,0,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark74(-3.5574562414629076,-0.2346991636841354,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark74(-35.58521632087586,-0.22102463779685477,-1.107145889065949,-1.5707963267948957,-1.5707963267949503,78.32987027515956,0,0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark74(-35.61164769964757,-1.065116169407642E-13,-1.2762627830909603,-1.4296973648965423,-1.5707963267948966,1.5407439555097887E-33,0,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark74(-35.625900041578774,-1.3078809382806527E-7,-0.28012842010693706,-1.1882773026912412,-86.04905367068366,0,0,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark74(-3.5646275354659682,-0.007810721063099076,-0.013727325690364165,-106.85361639933839,-0.2053821648642779,7.884440884966809,0,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark74(-3.5652984804927637,-0.07770224191647913,-0.7592219065924759,-0.9828808715800348,-1.5707963267948966,-77.28912029107376,0,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark74(-35.654848501766,-0.23474315695316725,-1.1691332349812216,-1.4398824206375023,-32.80640706487054,0,0,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark74(-35.65496091711497,-1.5323417487753208,-1.2429655065941687,-1.5707963267948963,-1.5707963267948966,-1266.6664588899912,0,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark74(-35.66748087582877,-0.3266470682559196,-0.3438611338913746,-1.5707963267948966,-10.934026885383616,0,0,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark74(-35.7211458660098,-1.8202091995294456E-12,-0.01809065188599807,-1.3716421551242033,-32.92915044097951,0,0,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark74(-35.724559620778635,-1.0020104643392522E-8,-1.0659910787762259E-8,-38.6012202590751,-0.9021093249608797,-47.14980806879355,0,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark74(-3.573484305492025,-0.23465142177000695,-1.5707963267948957,-1.5707963267948966,-42.014782106294454,0,0,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark74(-35.74048447879085,-1.0705216595233615,-1.012409963105123,-1.254588029198057,-8.10492747737011,0,0,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark74(35.7405872447612,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark74(-35.745984348139444,-1.2804791817492343,-1.564184347116646,-1.570796030511288,-69.67017337064763,0,0,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark74(-35.753919403816425,-2.220446049250313E-16,-0.1028585670688269,-38.0584899714779,-75.8659140176795,0,0,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark74(-35.77762438014369,-0.387564107765976,-1.073034865407704,-1.1739875779425335,-127.07961621972272,0,0,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark74(-35.81558763079349,-0.833697189432532,-1.0000106459116496,-1.570796289552959,34.965710305419094,0,0,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark74(-35.81718461257721,-0.18745787988267365,-1.425098173772698,3.33508879465135,0,0,0,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark74(-35.81728002328669,-0.04972004977087546,-0.4156263126222124,-32.042134216681866,-1.0949997770818765,1.6161896803607674,0,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark74(-3.581984841669936,-2.5734886951591453E-13,-3.6532591133436536E-11,-1.5195537563078232,79.57365944298401,0,0,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark74(-35.832600184418084,-1.459385990235583,-1.517191588138908,-89.48275666515916,-1.4763677835415756,-61.41817298100381,0,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark74(-35.83526196160249,-4.2078373093751104E-10,-1.5707958976999221,-72.30143950706466,0,0,0,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark74(-35.84264310868518,-0.4297001008037349,-0.494694749700609,-94.78904037143488,-0.5415328615592327,3.591439602614934,0,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark74(-35.845984276645034,-0.5762226387180064,-0.9012644181554416,-0.9227836332520762,-44.90508079979295,-28.597837323476767,0,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark74(-35.847641602408366,-0.6116993999266208,-1.1172967058710945,-1.130228053202314,60.82048847141837,0,0,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark74(-3.5854321622848198,-0.010769042814725224,-0.011180542365531357,-50.52762304749186,-0.8750624376376783,71.03363813013115,0,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark74(-35.8635238721028,-5.534082083440102E-11,-0.12890174811798882,0,0,0,0,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark74(-35.87242215364505,-1.0448868273422238,-1.570796320515653,0,0,0,0,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark74(-35.8783092890598,-1.5707963267948912,-0.6893912737326894,-2176.9694012051527,0,0,0,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark74(-35.89598733760233,-0.4308298564791444,-1.162249036112416,-1.1704275338053804,-1.5707963267948966,-100.0,0,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark74(-35.93596217386634,-0.5609050098728947,-1.2336711112761922,-1.271929127419567,-1.5707963267948983,0,0,0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark74(-35.94833562016415,-0.20608339107397017,-0.2696231150644054,-19.943417271668572,-1.515712960557451,-22.46861817727583,0,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark74(-35.950695316566,-1.2257223324904107,-0.08024526363372969,-31.72198027235043,-0.3309371534640392,6.550543294531613,0,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark74(-35.97519467661153,-0.936397748219472,-0.9920833299246402,-1.0156998477353278,-2.1202628270636175,73.11538886065202,0,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark74(-35.979351609433756,-0.813493089992898,-0.965525288582463,-4.3368086899420177E-19,0,0,0,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark74(-3.5979924481290837,-0.6100227556565895,-1.2601800093516695,-1.3276470878891935,-133.55651051385655,1.2410954294823142,0,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark74(-35.980425127931,-1.5193652238027084,-1.5403760047839943,-0.7819944994751069,-65.09585405619933,89.09444677109326,0,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark74(-35.982451262941204,-5.251768449375671E-5,-0.21212214223778858,-0.3690546354197528,-46.23738778296932,137.31187409367277,0,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark74(-3.5983065229148776,-1.2904004143272183,-1.327902542668328,-76.86137949117456,-1.4812771044834494,-1.5407439555097887E-33,0,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark74(-35.985199313635476,-1.4772639982432547,-1.4780279961240197,-1.5707963267948966,47.12369649530108,0,0,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark74(-35.993322496506984,-1.4400312361072114,-1.0814656729921197,-82.82357943060644,-0.4919118667545605,-0.31808360382164697,0,0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark74(-36.00725850276978,-3.548140141533521E-15,-5.5754933498723785E-15,-0.8376562154216187,-1.5707963267951215,0,0,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark74(-36.009155423283076,-0.1277290864736167,-0.1773437709259258,-1.09194632810895,-1.5707963267948966,50.11861545375449,0,0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark74(-36.01154971583386,-1.4886611021357816,-1.5131711913591335,-1.520819337009858,-1.9058394412842112,0,0,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark74(-3.602207627785774,-2.220446049250313E-16,-4.4535865448294274E-9,-1.5707963267948966,75.27171276424706,0,0,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark74(-36.025776178453306,-0.02944293838310786,-4.8471175078540326E-5,-0.03473622341759378,-7.863318918149273,0,0,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark74(-3.604272270112505,-0.07268679236084971,-0.9944712498123304,-1.4363136933513354,-1.436313693351335,0,0,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark74(-36.046349127356294,-0.5891695640200856,-0.6506170740697164,-0.6524621273650364,-59.01279072520802,55.348603008335374,0,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark74(-36.054443806197085,-1.362423126542171,-1.5096951776883931,-1.5309246933943832,-1.5707963267948966,34.67911398215052,0,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark74(-36.06153792494362,-1.5698922254701428,-1.5707963267948963,-1.5653898435136209,24.50034450589959,0,0,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark74(-36.063717088843894,-0.058993555535144945,-1.133294627355351,-1.4032594989241058,-152.49884157392574,112.55897297771847,0,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark74(-36.064310759060604,-1.5707963267948912,-0.05311690509050482,0,0,0,0,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark74(-36.07280941484486,-1.0002967971921144,-1.557536013678524,-1.5707963267948002,1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark74(-36.07633946593747,-0.5374995075139043,-1.3443503943265915,-83.07760108861454,-1.155841817003897,3.1418054785992,0,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark74(-36.084927173822386,-0.20022216946434382,-1.5254574817646531,-1.5707963267948966,63.304636712871215,0,0,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark74(-36.09043821071558,-0.32196093737946263,-1.0689446490084424,-13.635336390925676,-0.15052598555170515,-90.94708751150185,0,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark74(-36.100728112325164,-34.49683105820644,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark74(-36.108384417839936,-1.2196528205307324,-1.2190427451333126,-0.9533413206156605,3.2967952608545184,0,0,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark74(-36.123173822226576,-0.042977207843592824,-0.03472067184147939,-157.11646552400455,-0.06775413177092449,1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark74(-36.124875980506374,-0.5644754321609345,-0.7764354708623493,-76.52033205744085,-1.2608069785055787,-56.54531324791951,0,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark74(-36.12583732362012,-1.671649737047863E-4,-0.23568191771930397,-0.9210101356197484,-1.5707963272543533,-6.291097525533468,0,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark74(-36.127562328651976,-1.9404298357973957E-11,-1.9404298357974102E-11,-0.0045537485642399775,-7.118203168062959E-11,0,0,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark74(-36.158011198225836,28.83916665554068,75.45563641033806,-38.42523895658763,-37.33408349827365,0,0,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark74(-3.6182010757573266,-0.10698187166984138,-0.5128647981963184,0,0,0,0,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark74(-3.6363301974326845,-0.022489718406027877,-0.17260734006354242,-0.24861125665024897,-32.26151074589525,0,0,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark74(-3.650136560008974,-2.9278589707548204E-4,-0.01961739365214704,-13.17217077701116,-1.5707963267808573,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark74(-3.655186378445083,-1.0350339548603975,-0.5996979098149458,-95.1078886757578,-0.9112320712195081,-0.010777856176680397,0,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark74(-3.6629640663654293,-0.010877806285032321,-0.013295620437328152,-0.6413154734379436,-14.496779500540052,-54.559092885877256,0,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark74(-3.66830496350528,-0.20521520429644535,-0.6943055969633954,-1.0495482338492765,-1.5707963267948983,39.68829801289246,0,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark74(-36.75783993337647,39.55062479714425,5.820452759047882,-15.827822264477803,-53.80539911692821,-52.395204977043505,0,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark74(-3.7004858208865423,-0.002549168587393574,-0.007876507135576987,-0.34375295076960455,-2.480344945286241,111.93337063730615,0,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark74(-3.7217723456072385,-4.502256918882716E-15,-1.5707963267948954,-1.5707963267948966,70.16838195934938,0,0,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark74(37.25562070636107,99.12442888823668,58.88148045972943,71.79683205607466,91.48696018001249,0,0,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark74(-3.7343420243391137,-1.001548232779238,-1.1128194376321947,-1.236631364745171,0.0,0,0,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark74(-3.734444887368488,-4.715525103126561E-13,-0.9174286820164225,-0.9774793114126299,-8.110792361695536,0,0,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark74(-3.739591352054619,-0.1487848019159324,-0.47778223825400146,-6.912655415891804,-0.6339221106787439,89.7210082436852,0,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark74(-3.7548547867694047,-0.21909468077189356,-0.28457431276874035,-0.8568365228756265,-1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark74(-37.82679815812424,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark74(-3.7881778765555367,-1.9010915662951598E-211,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark74(-3.793184291200416,-0.0013074817477884693,-0.1486745909064922,-0.477722649906846,-96.13501434659166,77.10214732777716,0,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark74(-3.794571291152332,-1.3312532390094582,-1.3377055430761429,-26.626995634682473,-1.5170687064427726,1.5707963244337295,0,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark74(-3.815541806830048,-0.2823060525637817,-0.28912063404061317,-19.178361986590595,-0.7282472524621962,-1.249701439229562,0,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark74(-3.844066303923783,-2.6571838393473347E-10,-2.79980050738174E-10,-1.5707963225795252,-1.5707963267948966,-55.4435701104139,0,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark74(-3.84425978578858,-1.3174054199366427,-1.5066662097749617,-1.5186512205608969,-31.240216905202132,0,0,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark74(-3.84820219327483,-0.4369189016092875,-0.5606590857653655,-6.95775683155267,-1.5191661070910927,56.97646399760253,0,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark74(-3.853728675600732,-0.06841847710584485,-0.5796559618310229,-0.7580707787653282,12.70888578297369,0.0,0,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark74(-3.8610775615389983,-0.3071073902371957,-0.4930878485871337,-1.5315369416427582,-1.5707963267948966,-1.5707963267949332,0,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark74(-3.8687286289245293,-0.07536416371856716,-0.0937748150123509,-0.31278707460666777,41.906965293151416,0,0,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark74(-3.8745258712900323,-1.567175465291502,-1.5707963267948948,-1.5706578028484184,-1.5707963267948983,-100.0,0,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark74(-3.8857702983522806,-0.00781543742950944,-1.5424396285238913,-1.5707963267948966,78.08973273860005,0,0,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark74(-3.886121131098036,-0.11993680195661821,-0.25428948009658403,-94.61138150349744,-0.39442969561543095,-76.32456609393475,0,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark74(-3.8988429797337067,-0.12937631168763639,-0.9091472719467009,-1.3292500138162922,-1.5962335845381135E-11,0,0,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark74(-3.8995817374192345,-0.6515489679590523,-1.288908663557029,-1.5707963267948966,4.819312201463719,0,0,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark74(-3.9005415373447923,-1.2746802103781698,-1.5410205806736572,-1.570796179774679,0,0,0,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark74(-3.907976743957107,-0.5502584469066889,-80.52712026980075,0,0,0,0,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark74(-3.91612137317739,-0.7589523745131557,-1.2017309461247436,-1.229576308039077,-24.2954613116331,0,0,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark74(-3.9198666329104217,-0.020921114991792833,-0.11989086601723287,-69.97105668990662,-1.5707963267948963,-72.8521694515586,0,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark74(-3.9267540380976262,-1.5707963267948912,-2409.8884549362815,0,0,0,0,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark74(-3.940316177901238,-0.31684980740681834,-0.3697888621723002,-0.9770478542765555,-45.87413080592846,23.62246459429017,0,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark74(-3.943461087940463,-1.0857376973734547,-1.2633132287335878,-100.0,0,0,0,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark74(-3.948971907518074,-0.9092596713449811,-0.9467221908014637,-0.9467243316837147,75.54157175000142,0,0,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark74(3.949643004024068,-59.22988651473986,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark74(-3.970649415141679,-2.724051454385243E-11,-9.503893914637456E-10,-81.97182831226924,-84.81454224417583,0,0,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark74(-39.83256796876675,-36.56599301950805,-61.36378348425391,32.26517618496396,23.373902566057453,91.73310482449273,0,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark74(-3.999610849915257,-0.562878760329045,-1.2243075841475595,-1.2869954504620005,98.87539484251917,0,0,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark74(-4.011046802411653,-0.9405857077605314,-0.94135660226889,-38.65045859824296,-1.4805538962060143,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark74(-4.021665669181706,-0.0401932278163403,-0.04536272541937714,-0.0047307815743698675,-6.288039354899496,0,0,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark74(-4.0237880767324645,-1.3146924794611332,-1.51155842149619,-1.5290629802700029,-100.0,0,0,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark74(-40.32112605356948,-2.7124950842160302,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark74(-4.044286730198979,-1.1538614149799682,-1.0526749079565507,-7.5559850588779,-1.2788406930644531,-1.5727631710177814,0,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark74(-4.045040417959075,-0.5708056855232639,-0.65878831845876,-20.26474743921831,-27.458733136025398,0,0,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark74(-4.049109607546585,-0.5384299372917829,-0.7898232344942226,-1.1512602360025763,-7.803646718030936,0,0,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark74(-4.0491242145896,-0.23700993740754672,-0.43622207033597804,-1.1653233574471296,28.05489250474421,0,0,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark74(-4.055636586719912,-0.7407779525689584,-1.006957103907229,-1.1587431452294894,86.10668143234511,0,0,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark74(-4.078341822577197,-5.551115123125783E-17,-0.6232161179513656,-44.963233081353685,-1.2794711610371208,-48.288474634850004,0,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark74(-4.082447018494051,-4.4781637657198434E-4,-1.5707962544234573,-1.5707963264043912,-45.345552594330314,0,0,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark74(-40.87664947970887,-0.05614199055061968,-0.8864752574163485,-1.0789031513710259,-1.5707963267948966,-32.01701408082263,0,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark74(-4.087921299729835,-0.005905740631344746,-0.04991737858921941,-1.5707963267948966,7.0282116120037585,0,0,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark74(-40.8832325229763,-0.8292171509275489,-1.3139822993445567,-1.3881077669445452,-58.28002814590063,-7.877155935429555,0,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark74(-40.88708440396225,-0.08231488454093383,-0.44372485493670943,-20.36978968804766,-1.527543781415683,-122.5236641061076,0,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark74(-40.89373060822054,-0.8709499082074177,-0.912269019651654,-19.930562531235452,-1.5707963267948963,-1.570796326794896,0,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark74(-40.900057758053826,-1.1336793456285879,-1.182728136479976,-89.16234268880562,-1.1422928164310284,106.85894464382339,0,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark74(-40.900234061628574,-0.30781719190792173,-0.616111793039892,-7.054754169903484,-1.349966091316188,77.05082211725639,0,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark74(-40.9662252036732,-0.04206536967059482,-0.23120846363556652,-0.5560783945451526,-14.180546700980818,23.857848091103165,0,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark74(-40.970956749313984,-3.9127878093580584E-13,-1.139576290670174,-1.2499370776794319,-1.7578458267605983,35.61034446924032,0,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark74(-40.975309373619645,-1.4411867282553685,-1.4929895774950763,-1.570781586960778,-70.75992683602612,0,0,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark74(-40.97765339117638,-3.3931077818186306E-7,-0.001399658668303517,-69.26829696892783,-0.24591901412892353,87.99842864784858,0,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark74(-40.979414251468896,-0.42935240186564017,-0.6262271672000943,-1.5707963267948966,-1.570228134351668,0,0,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark74(-40.992079536588456,-2.220446049250313E-16,-1.570796326794666,-1.5707963267948966,-1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark74(-41.00828334781131,-0.5846428755058821,-1.457206343090495,-14.043330895698764,-0.7928131107900398,4.2351647362715017E-22,0,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark74(-41.01853399657773,-2.371019917457776E-14,-9.04079802025434E-4,-1.5707963267948966,0,0,0,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark74(-41.02728557062751,-2.534820327386875E-16,-6.614137825117668E-8,-1.3868017099293455,0.0,0,0,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark74(-41.029144128566266,-0.38710518908604685,-1.1383742634778422,-83.24281868507833,-1.4261961312026246,0,0,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark74(-41.04810175269476,-1.7785901523776178E-7,-1.5707962533396342,0,0,0,0,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark74(-41.052078492188684,-0.21821905001978598,-0.22826876936304716,-1.4631364443151607,1.53141682689525,0,0,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark74(-41.06923309687079,-0.26492205578100003,-0.3833842652389791,-6.758199593611368,-0.8444298090357873,-58.331622934074204,0,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark74(-41.07566557803111,-3.305842761232687E-7,-1.1087959465974282,-1.5293176188185647,-1.5707963267948966,-18.173506704434516,0,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark74(-41.08331396689859,-1.3976520603423694,-1.4619905366353487,-1.5707958458320332,-2.0194839173657902E-28,0,0,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark74(-4.111702504405002,-0.7975461176634002,-1.334985056648854,-76.87506287414858,-1.5396801901990753,48.667210662262704,0,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark74(-4.112575417495243,-1.3913487577017263,-1.432931576400524,-1.4529245687715173,-1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark74(-4.120030090780787,-1.5707963267948963,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark74(-41.349506135685736,-1.2804082143841193,-1.3183043149252995,-1.5707963267948966,-45.55297670552535,0,0,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark74(-41.35974514900743,-0.9864645602578499,-0.9969415555279353,-19.902316821058687,-1.174917706116697,-1.5707963267948983,0,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark74(-41.38169165595901,-1.2883179763248047,-1.291062343527781,-1.5707963267948912,100.0,0,0,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark74(-41.38899956426804,-0.26628613425088377,-0.8127716946290616,-1.5707963267948966,80.1108158689975,0,0,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark74(-41.393103425191335,-1.1334899755426617,-1.1414849131144387,-1.5707963267948912,-1.5707963267948966,-1.8101552320340488,0,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark74(-41.39632241267866,-0.43621237852001676,-0.36156962448969154,-0.36595547353587987,-14.163469708215365,11.000425393093632,0,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark74(-41.396561051279335,-1.077115435195687,-1.1855042218908387,-89.22638014453383,-1.5202022502499983,79.08557099531382,0,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark74(-41.400233068368244,-0.3883460929532975,-0.873963131377035,-0.9349592955461719,-1.5707963267948994,0,0,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark74(-41.40800437398484,-0.6458198045836431,-0.8382310131532249,-0.9899798611700987,0.0,0,0,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark74(-41.42759300389325,-1.1262114925264424,-1.2782371366342633,-7.848444370503702,-1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark74(-41.4379259009408,-0.2909180665300616,-0.2945034057401042,-0.18617863773137322,-40.62068223939056,9.381916862040454,0,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark74(-41.44400961180702,-0.4137265499972049,-0.6774311332799573,-1.5707963267948948,2.1895288505075267E-47,0,0,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark74(-41.45834376568411,-0.5494580156175392,-1.2687163407047168,-1.5211580510262426,-1.5707963267948983,0,0,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark74(-41.46058097470681,-1.47834983141365,-1.4928666165224902,-0.6146751080585022,-84.20710464889355,18.114223262895926,0,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark74(-41.46690919767583,-0.43630208419739963,-0.4545871285168736,-13.521079420455116,-0.9709104074610629,-1.114497527929073,0,0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark74(-41.46908869456612,-0.22715918063594798,-0.673589103054459,-1.5707963267948963,31.28717047418981,0,0,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark74(-41.47903405100415,-1.0825498254682419E-10,-1.1717816962238416E-10,-9.148811202939447E-10,-1.5707963267948983,0,0,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark74(-41.507317692243824,-0.09550355082929629,-0.3177699889421203,-0.8620167829836212,-2.258873637887002,0,0,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark74(-41.51910111094754,-1.5614776070800764,-1.5707963267177838,-1.5707963267948966,80.11035273887164,0,0,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark74(-41.52917983877543,-0.5973110356304906,-1.2961106632624095,-1.5203939968642413,-38.74893932141708,0,0,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark74(-41.55010720524946,-0.1182557065782586,-1.5707958992564353,-1.5707963267948966,0.0,0,0,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark74(-41.557354398327504,-4.440892098500626E-16,-1.386808768102942,-13.997444592738539,-1.431442539218737,0,0,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark74(-41.55747587138736,-0.2068509930471647,-0.5586440450699175,-32.03067409916569,-0.6155832276825127,53.3764737780063,0,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark74(-41.57531476156954,-0.18364422569289857,-0.1914139288407922,-1.0975830101464568,-1.5707963267948966,-38.82234536316645,0,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark74(-41.57873296015548,-0.9789566359116015,-1.0286532001333561,-1.0479783302954515,-26.254789064147058,0.0,0,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark74(-41.581727690023754,-0.3382413413926033,-2298.1463777972413,0,0,0,0,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark74(-41.58254777198279,-0.6902198009362511,0.0,0,0,0,0,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark74(-41.59518172462949,-0.12680498772250903,-0.4496329954218169,-1.1896372228171632,58.49493568161775,0,0,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark74(-41.6092672372559,-5.323583311296414E-4,-1.0058772302278243,-1.0402546734054112,-58.58396600384371,42.48829549563745,0,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark74(-41.61725066228832,-1.5485830241875407,-1.554780797102815,-1.5707963267948966,0,0,0,0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark74(-41.63431917574467,-2.3986119778930786E-10,-0.5764669622741092,-82.77015669328046,-1.2854626661191317,-42.762299802087625,0,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark74(-41.63821971574943,-1.5384711996357754,-0.1714823108347493,-1.3695743848563369,-1616.9564292878053,0,0,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark74(-41.643056618387305,-2.220446049250313E-16,-0.03476566286019542,-0.5317858770253123,-37.36072569558576,0,0,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark74(-41.652088206393174,-5.831670957048678E-11,-1.151361900038995,-14.015947763228624,-1.5705912716551673,1.7362760500025426E-14,0,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark74(-41.664173118750966,-0.22846799477085578,-0.3165998370521819,-0.4925706931973486,-38.37126590784139,0,0,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark74(-41.68878351727,-1.0952938160791492,-1.1131084557810302,-1.5707963267948966,-1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark74(-41.6917081030159,-0.31658628243006887,-1.3123064880801998,-76.78297127344072,-1.5707963249469308,-45.64692706185157,0,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark74(-41.70951502602749,-0.0723041872890667,-0.4488132310530717,-83.14707591276957,-1.4794035640754728,-100.0,0,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark74(-41.71606562779474,-0.9644380365552522,-0.9644383795989107,-0.00705212273300875,-0.0074668506110044655,0,0,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark74(-41.7198923571064,-0.27228290020974355,-0.27450800722368013,-0.2750312916844521,-50.70403375902078,0,0,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark74(-41.73781997675648,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark74(-41.76981593689042,-1.4547586285364038,-1.4617389499690618,-1.5707963267948966,0,0,0,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark74(-41.78088627484367,-0.8114048907341412,-0.8645171449967329,-26.16142661886763,-1.5679853602530651,0,0,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark74(-41.81549405981707,-1.3349859981629923,-1.4027326296530902,-1.4028574363118191,2.7755575615628914E-17,0,0,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark74(-41.81568356691141,-1.5707963267948948,-51.95424550791634,0,0,0,0,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark74(-41.8631772046312,-0.5731235597792614,-0.6263747050291206,-76.79960594322351,0,0,0,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark74(-41.87001616480854,-1.0751228972855271,-1.1200993902589573,-1.2576209194741006,-89.7693474994995,0,0,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark74(-41.87103123085217,-0.1305102407098577,-0.16152439747841574,-31.57924731730485,-2.4074124304840448E-35,0,0,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark74(-41.872850945945,-0.23451128655321668,-1.4783291526585718,-1.5707963267948912,-1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark74(-41.882532808171355,-0.20280973111720785,-0.24873487859188037,-1.5707963267948966,1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark74(-41.89174359458314,-0.7116846615571188,-1.2201075617140333,-1.570811769745534,-152.17505083363693,0,0,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark74(-41.89585278703113,-0.2833821495736474,-0.3707932010248737,-1.1339540348013015,-1.5707963267948966,-8.288203591469545,0,0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark74(-41.90252627339249,-0.0013600069596276718,-0.3309332012233178,-0.3309336904756944,-34.59313814204688,0,0,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark74(-41.90850122220062,-0.3950407350919215,-0.890911909731034,-1.5707963267948966,-1.5483342711330943,0,0,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark74(-41.916789866158865,-1.0338749867236925,-1.4488983948778298,-1.5707963267948966,0,0,0,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark74(-41.918584234420074,-0.2382828742636232,-0.27780512988398987,-0.3241226359351729,-12.600297221940968,0,0,0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark74(-41.9443227596396,-1.9642936791724533E-13,-0.130925124737806,-44.6882876703296,-0.7077810947794987,0.0,0,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark74(-41.96558435639762,-0.2875444665245136,-0.36129462856712546,-94.60907981338563,2.7755575615628914E-17,0,0,0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark74(-41.967753163905755,-0.5136124061741776,-0.8911890625985387,-82.75723028439445,-1.1739218329879384,5.832564574419219,0,0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark74(-41.9689871182342,-0.3284775411096713,-0.5964745013869863,-0.6062716434552006,-1.5707963267948966,-0.688194102920899,0,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark74(-41.97908774606889,-0.3311148931249763,-0.3311920440298397,-44.6921871931974,-0.9070040660942599,-6.088233496309104E-8,0,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark74(-41.98149469576601,-0.7939270921504464,-1.1084735458769386,-1.1085754351725299,-25.078783981831837,0,0,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark74(-41.9857573414842,-0.487733896223046,-1.230470350498034,-1.506431814073626,-100.0,0,0,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark74(-41.98910727752355,-0.12501977081877758,-0.4145207783681002,-38.40661796337246,41.1749470587847,0,0,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark74(-42.00449336820575,-0.012156798908700583,-0.18273572700425256,-0.37115981082694166,-50.264331652525414,0,0,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark74(-42.03033827134766,-5.551115123125783E-17,-0.2271802870704324,-6.710725502151116,-0.47233211565915,-0.028507787947873064,0,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark74(-42.04158052878799,-0.09590706780574182,-0.004563477711428172,-6.290954585177571,0,0,0,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark74(-42.06875940335478,-0.10366897623982958,-0.1168619277094489,-1.5707963267948966,0.0,0,0,0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark74(-42.06921499480958,-36.29784474899833,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark74(-42.07751122175347,-2.1548649328518647E-15,-1.5464060391846497,-1.423922037646448,-1.5707963267948983,1317.3554414480432,0,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark74(-42.07950757872618,-0.4085371814525078,-1.523212881780294,-1.5707963267948966,0.0,0,0,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark74(-42.09896925567918,-8.881784197001252E-16,-1.469101579312869,-1.5707963267948966,0,0,0,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark74(-42.09946273331459,-0.6572963138308842,-0.7554944179804053,-0.8186450161976393,-1.5707963267949054,0,0,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark74(-42.12327987278239,-4.861435505329063E-15,-5.45359484028131E-15,-1.5707963267948966,37.75134463449359,0,0,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark74(-42.12545848590262,-0.12179550904004527,-0.12384041065862168,-6.288501949184604,0,0,0,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark74(-42.129467975949915,-1.3042550293459423,-1.5707963267282983,-92.70965477668203,0,0,0,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark74(-42.134745513862995,-0.37857151324653987,-0.379210082094773,-1.2604334162222228,42.72186372873268,0,0,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark74(-42.15173355342668,-0.3072986437047696,-0.3091474156602326,-0.38763275841836264,-1.9268174548474097,1.6155871338926322E-27,0,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark74(-42.16458180067989,-5.205795526613302E-9,-1.5707963267948912,-36.013913714004374,0,0,0,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark74(-42.16625689872211,-0.07907837672114049,-0.7084112243115435,-1.5707963267948966,0.0,0,0,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark74(-42.18037686775768,-0.8988506894763211,-1.0724822705427752,-32.403949275885665,-1.5707948307355417,-321.366609685716,0,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark74(-42.19360545222295,-0.008110865516856233,-1.3479305571140485,-26.49479756770908,-0.8695307646504261,-28.12076166162782,0,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark74(-42.20256414856286,-0.3396373234772843,-1.570796326794894,-76.09759501590693,0,0,0,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark74(-42.20788267142569,-2.1547857902283223E-12,-0.07480367157895604,-0.07486998768196208,-65.83694045845807,3.3490722761064315,0,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark74(-42.20899052102109,-0.7375540930548827,-0.7748621011144836,-0.8996166360672431,-1.0145977804500412,0,0,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark74(-42.23943409504473,-0.17994875828301926,-0.755826140106824,-1.3028764336547949,-1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark74(-42.26935995354965,-2.1684043449710089E-19,-0.006174565504715208,-0.5309649148733875,100.0,0,0,0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark74(-42.29612634862978,-1.4544898572400293,-1.564934915313914,-1.43097377336782,-33.05914733065623,-7.859864983254863,0,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark74(-42.3114873186896,-4.758234732472861E-5,-4.827812490535734E-5,-7.964560164570518E-5,-21.082371267222555,-44.04120471057258,0,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark74(-42.31642874276842,-1.0069474463968244,-0.814889881055838,-44.83683825244058,-1.0413866844249096,6.751766225483858,0,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark74(-42.32298078973619,-0.22054895922896278,-0.4174206601911713,-69.75546722182762,-1.2194250178369093,3.269551837010227,0,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark74(-42.33111387504834,-0.41605584702929554,-0.770806355617359,-1.0087613979202374,-196.836650205129,-11.073344860399828,0,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark74(-42.35580471920245,-1.301909181595715,-1.3332547956702325,-1.357458601442774,-7.641644676080344,0.0,0,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark74(-42.35714895830917,-1.1666121620518792,-1.3450735298579248,-1.5707962905308155,0,0,0,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark74(-42.376538769660876,-0.14642538278563855,-0.28997730481653927,-1.4453879359753419,-1.5707963267948966,-1.5707957971010402,0,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark74(-42.37982964947384,-0.5212359041437906,-0.7117595229167973,-1.5707963267948966,-8.37154048731594,0,0,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark74(-42.39142072630183,-0.8691011335479473,-1.5707963267948888,0,0,0,0,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark74(-42.393969657147395,-0.043689917435087544,-0.43738522733564,-0.45050181602314426,-33.42778003744462,66.42714642181491,0,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark74(-43.62016104247359,96.831463975437,-4.603041659278233,-87.73207146717728,40.18098524246838,-64.42583535008863,0,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark74(43.708528051595124,-49.336969201367296,-97.99650334704654,-41.08275918733635,-65.59249887848198,-31.613201731033485,0,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark74(44.52479609735971,44.610146499811776,-50.998659000876366,50.10027759214134,51.87744147716455,0,0,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark74(46.066738982658705,41.98163596459705,96.03932121059734,-52.034415653108155,59.322084764510635,0,0,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark74(-47.14299065289543,-1.5648336753779442,-1.5707890629986923,-1.5707963267948966,-89.12333882368222,0,0,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark74(-47.19200653303171,-0.21172332580322006,-0.5807424324294932,-69.71146072300337,-0.6406136315455476,54.442000590645634,0,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark74(-47.19500632922581,-0.2704548027743796,-0.2704560948946416,1.6940658945086007E-21,0,0,0,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark74(-47.20418291408444,-0.4243012598041187,-0.9542271095336399,-0.961198751765352,-14.318718984621185,118.04190449336957,0,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark74(-47.214410570761885,-0.5692780130310715,-0.7831539956529857,-13.693610798528638,-37.498932060289846,0,0,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark74(-47.23218381728937,-0.4892148935039298,-0.49018298283264045,-94.80542544256738,-1.5122411591028802,0.0,0,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark74(-47.24186763300864,-0.4982751727759693,-0.5409308878089563,-1.0628724256120636,-1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark74(-47.24509039022107,-0.18191730054820776,-0.42941628165099166,-0.4972329604590863,0,0,0,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark74(-47.24852851608807,-0.017745102777350565,-0.8971827218960373,-1.3202989065148028,-20.191848439206368,0,0,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark74(-47.25977806651243,-0.9638348243541378,-1.4536087969031337,-1.5374841158967203,-1.5707963267948966,-40.97194666591011,0,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark74(-47.269847735297745,-6.975712425887502E-16,-1.10891562586631,-1.5707963267948963,0,0,0,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark74(-47.30779032551806,-0.5329558032214337,-1.5707963267948957,-2085.5976139904324,0,0,0,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark74(-47.321152917537646,-0.7956622457148411,-1.4876204294537039,-1.499285595060726,-61.919979370847635,0,0,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark74(-47.33115672351375,-0.22212266252027482,-0.6945695694916361,-1.0642075178390398,-62.961506645418325,0,0,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark74(-47.344834660201776,-0.2036450325867129,-0.5202815013784228,-1.2382171865763982,-1.5707963267948966,-34.64934244333165,0,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark74(-47.34621333506314,-0.2845041423776802,-0.35282366105954677,-61.462168425181176,0,0,0,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark74(-47.349525588354474,-0.9508702579270006,-1.5707963267800384,-1.5707963267948966,0,0,0,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark74(-47.36469370999124,-1.2467379431221612,-1.4680625998897145,-1.5707965483048654,181.69362076697462,0,0,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark74(-47.419396200361554,-0.13471679348337673,-0.3832920686632881,-0.9722719335431707,1.5707963267948968,0,0,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark74(-47.41977825253903,-1.3552432304818294,-1.5067131234157543,-18.19268599155231,0,0,0,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark74(-47.44144173303358,-0.6865564829377003,-0.7505126582634898,-0.8054593917571404,-77.69014894406938,48.716100171701946,0,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark74(-47.45182317178176,-0.44440769468047203,-0.6825188449190656,-31.573312131100295,0,0,0,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark74(-47.455368288708186,-0.17034487098678164,-0.7979939599990045,-0.8022315931428563,-7.371144713803035,0,0,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark74(-47.4650583877119,-0.017810543636104507,-0.06547697410441625,-0.09027287209050776,-97.3880261210861,28.193268085644043,0,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark74(-47.479474101424344,-3.552713678800501E-15,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark74(-47.491286555734604,-0.5426719995133709,-0.8679273441981515,-0.8734375628056827,-83.9367022555326,426.35237487685134,0,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark74(-47.51213632186531,-0.7175290038659435,-0.9978405154547898,-1.0330549832761762,-26.845641561418777,0,0,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark74(-47.5169523766071,-1.5638800494766014,-1.566451672755157,-0.5960855729586012,-2.5444592753171063,0.0,0,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark74(-47.53608295373783,-0.0035266864086074268,-1.3312195593088176,-1.338584028542063,-1.5707963267948966,-44.723060700234804,0,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark74(-47.54274275697248,-0.2963772169391079,-0.35641043454924276,-1.5707963267948966,-1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark74(-47.54419442865491,-2.220446049250313E-16,-0.5665225343774436,-1.2112047935499075,-27.887536528745127,0,0,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark74(-47.55542933991235,-0.01862056064052369,-0.029958918207348056,-0.5241911772430465,-84.14571826321689,49.72736264934791,0,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark74(-47.57857238890601,-0.001213422189987328,-0.348970453884085,-0.8924878426553191,50.20957707703744,0,0,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark74(-47.60632926667842,-0.893253117206738,-1.033845088737684,-1.0596891091334948,-6.317476135077268,0,0,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark74(-48.13156387672756,-6.158774881322053E-4,-0.30326055838904775,-31.734619684349752,-0.3544907717960647,10.01464053204702,0,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark74(-48.16114976307131,-3.552713678800501E-15,-28.838015513414874,0,0,0,0,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark74(-48.16441636095362,-4.6581945225993875E-12,-1.4828760120777524,-1.5707963265957934,99.99999999982568,0,0,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark74(-48.1908133126138,-0.18247699656787958,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark74(-48.201000237660274,-1.3189079468882055,-1.3209632435146974,-1.3992188188499701,-1.5707963267948966,2.168679903794218E-12,0,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark74(-48.229619460473735,-4.440892098500626E-16,-0.11628798458017786,-82.01614075784273,-1.2027775454603207,31.431877942620158,0,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark74(-48.24219327411513,-0.03313556304719927,-1.2238150535801537,-1.5707963267948966,-100.0,0,0,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark74(-48.257283117139735,-2.220446049250313E-16,-5.437066526850325E-4,-0.03170339148969563,-54.985209627231924,0,0,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark74(-48.27414569272578,-0.10225758686581646,-1.1966607069479958,-1.4551593924393165,-1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark74(-48.27861177062392,-0.9181910324089186,-1.2037476199065766,-1.570796326794896,-1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark74(-48.28244945734992,-4.549997887192317E-17,-0.800746908009694,-0.9358249150821359,-1.5707963267948966,-19.522941023023016,0,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark74(-48.28626853977856,-0.03692328899897612,-0.4936773017566994,-0.4937439678627423,89.93366555888925,0,0,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark74(-48.32177862208946,-1.1839339230831598,-67.78103661271386,0,0,0,0,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark74(-48.36940796379187,-0.41025143642987416,-0.5517751318086802,-1.5707963267909735,7.290826481562149E-15,0,0,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark74(-48.378218528187226,-0.793247916652269,-1.3415662841734464,-2.465190328815662E-32,-25.154857949331006,0,0,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark74(-48.38886704070051,-4.2792889246130244E-8,-0.7118633430682537,-38.43434114610178,-0.7352386592027451,0.0,0,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark74(-48.3918806689098,-0.8727417404067026,-1.186470449906868,-1.5707963267948966,-53.75602865119444,0,0,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark74(-48.40310609480032,-0.36556806588756136,-0.16801476118526182,-81.78465655436517,-0.10584594735383324,-233.064296260983,0,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark74(-48.403161951941456,-0.018644931903941897,-0.767465003763041,-1.186542992894095,-1.5707963267948966,-3.447392916044789,0,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark74(-48.404303255222025,-0.04905721936909276,-0.05190551726512659,-0.0519055172651266,-6.462348535570529E-27,0,0,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark74(-48.43745170856788,-27.75149286143032,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark74(-48.45113565640813,-0.07022907668902079,-0.5956834203972543,-6.965449070784331,-0.025306800675610155,411.9977258156182,0,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark74(-48.4623654596937,-0.6705468661738094,-1.0237079321358236,-1.3539513042836908,-1.7581402905704238,69.99606586052235,0,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark74(-48.46955737633336,-8.005609053871185E-11,-1.2668358215542068,-1.8883353665855651,0,0,0,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark74(-48.47320826719825,-0.002656687066661112,-0.05084177257967637,-0.08359840513834066,-71.79912470115005,1.3230078773292683E-6,0,0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark74(-48.49018420958621,-3.5779836405309064E-8,-4.222120939097462E-8,-4.23125348332397E-8,-1.5707963267948966,-1.0195788231247695E-56,0,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark74(-48.49454397217688,-0.6892325658012645,-0.9795184976290628,-1.5154911739537353,54.986279377051446,0,0,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark74(-48.50080567218964,-0.3704335389192739,-0.6329686642145492,-1.425822145810708,0,0,0,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark74(-48.5019317835758,-0.19274705458876776,-0.19281434614637402,-0.35754178715921214,-14.007928730055665,0,0,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark74(-48.526017218053504,-2.3121344682337914E-12,-1.2339631281790142,-1.507623215763464,-33.369422550881,0,0,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark74(-48.52844765398764,-1.185898983499155,-1.4817466291401797,-1.5707963267948966,-61.72532748216105,0,0,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark74(-48.52885543275218,-0.5794412469746534,-0.5926482932922139,-1.189936068410915,0.0,0,0,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark74(-48.538215835448284,-1.4344034885224668,-1.4492614233241568,-1.072856090870134,-2.0679369070700844,1.570796326794897,0,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark74(-48.54560703675593,-0.8781950074300573,-0.9943525607882783,-0.09804716811304703,-103.6724574188361,47.02222561350721,0,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark74(-48.55964214276182,-8.470329472543003E-22,1.734723475976807E-18,0,0,0,0,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark74(-48.56946276757983,-0.5210410956450385,-0.6571006464590741,-6.9488235003775625,-1.5707963267948963,-1.907382943144112E-5,0,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark74(-48.59867091765705,-0.298788184315703,-0.41271742541387385,-38.4668989978712,-0.9831764785099717,70.53179255201424,0,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark74(-48.61909645884218,-2.850028861054538E-10,-0.5574069906893854,-1.5707963264782145,0,0,0,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark74(-48.625314655189314,-0.406459725135504,-0.6435835685634956,-1.5707963267948966,1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark74(-48.63282618412839,-0.47415286366043236,-0.9331113429142079,-26.168854155565526,-1.052599241166059,-146.61626813631182,0,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark74(-48.63374431602837,-1.0471436643881904,-1.5193790210747977,-1.525717299856657,-1.5707963268178444,40.84443564693903,0,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark74(-48.64556515899717,-1.1761390180446991,-0.9514907586650471,-69.19473060451023,-1.570796326245048,-1433.236116035862,0,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark74(-48.6504226232812,-0.8390682083980872,-0.5684330947116727,-1.1953214330267794,-7.94420305657546,0,0,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark74(-48.674276259784506,-0.9378638009825011,-1.1088108729772137,-1.5707963267948912,-1.5707963267948966,-260.78177102074005,0,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark74(48.89711760912391,11.861517590514552,0.025612479795071863,-80.79858276511706,-44.639816725253525,0,0,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark74(49.074112508203626,26.910152419288252,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark74(52.65675134126971,90.02991779601382,-63.07789096333396,-45.33431025070538,0,0,0,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark74(-53.261130386899055,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark74(-53.408501841879556,-0.9397402442308778,-1.177492921485071,-1.1341593447998943,-52.06828996789025,1.5588533531995425,0,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark74(-53.412591663477016,-1.138134353760276,-1.3034312584191552,-1.3261936714442006,-1.5707963267948966,-100.0,0,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark74(-53.419034067532415,-2.7016136048916335E-225,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark74(-53.42710431316909,-1.0851785465564876,-1.1062790507796614,-1.533088592328861,-1.5707963267948983,0,0,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark74(-53.44450714286636,-0.8587121986840933,-1.019464914985492,-1.0383088790815869,-3.029029971131596,21.978567215749838,0,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark74(-53.448320955103384,-0.7903239685247113,-0.8437795225308382,-1.1313550633625877,-1.5707963267948966,-27.93584964356665,0,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark74(-53.448391030835424,-1.1102230246251565E-16,-0.20526572156218437,-83.01957829750354,-1.3389941431070747,1.1102230246251565E-16,0,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark74(-53.4570905875832,-1.1578891074541218,-1.4419724620245828,-2.710505431213761E-20,0,0,0,0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark74(-53.472617137685404,-0.01698178780739054,-0.4700600779478654,-0.9981295280906731,154.38577606858985,0,0,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark74(-53.47923253986871,-0.04699377572828206,-0.6834763935833951,-1.5707963267948966,41.30036740007721,0,0,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark74(-53.4975757524642,-0.19831012445742277,-0.20320707443310548,-0.22260788179527724,-6.7699009360069535,-11.820572016519643,0,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark74(-53.51040103354499,-1.4928410499542415,-1.5707963267948928,-1.5707963267948966,-41.673810033142765,0,0,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark74(-53.51713668239052,-0.47876049286858047,-0.6981696140264692,-63.78791448691975,-1.5707963267948948,2.2884851107326085,0,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark74(-53.528416761994826,-1.1992025599746192,-1.2012956350691093,-0.6121482178076832,60.30240896768594,0,0,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark74(-53.535623166378855,-1.5641702513927316,-1.564170251392731,0,0,0,0,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark74(-53.53896617777513,-0.256052003848134,-0.3158125366728473,-95.08823262135343,0.0,0,0,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark74(-53.546596660905735,-0.11111570251215053,-0.3496617968106752,-126.09052381500311,-0.4379464683157981,-128.90252538424497,0,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark74(-53.55388761386391,-14.784092796443616,-2.914689372968084,0,0,0,0,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark74(-53.562308243506465,-1.2394591069321883,-1.2648184472648034,-1.3252705279114205,-20.643033113005984,0,0,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark74(-53.57893018285551,55.89081682965599,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark74(-53.59235338825024,-2.1556938873743806E-11,-0.004235182003940574,-0.2714452674316288,-8.728658443266987,1.5707963267949019,0,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark74(-53.623966021913866,-0.37046509508315606,-1.0725617571348034,-1.0741679571675906,-1.5707963267948966,-1.570796326774596,0,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark74(-53.62824216312698,-1.567704505657355,-1.5707963267948963,-1.5707963267948966,33.1385436954923,0,0,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark74(-53.64247147573972,-0.6477626052546908,-0.8903554326727621,-164.33866705320577,0,0,0,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark74(-53.65478397454323,-0.18448020112457872,-1.1288232744413444,-1.5707963267948966,0,0,0,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark74(-54.33516760049572,-54.44601387277282,10.031577554833902,0,0,0,0,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark74(-54.36783702424917,24.57310165034201,91.97165968380659,42.66908866961404,-39.1495631666881,0,0,0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark74(-54.42259447240941,-1.2255522150830003,-1.237925823406334,-1.3095909133936667,-1.5707963267948983,-168.33018270216644,0,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark74(-54.42404522409759,-0.4615121268442425,-0.4961443626142202,-6.535267039656829,0,0,0,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark74(-54.43098579718741,-0.47313272833354825,-0.774416387223378,-63.65745300364841,-0.8321361167829499,1.6751241323867327E-24,0,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark74(-54.443769802737066,-0.07048828910052093,-0.1166021067901884,-12.683328729570903,0,0,0,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark74(-54.47694108851881,-0.15807211768849036,-0.44122150985656905,-69.98284449419039,-1.5584863383458214,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark74(-54.478524761373144,-0.6496967115238049,-0.7791691642100067,-1.0891428054705692,-47.221666651899575,0,0,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark74(-54.521019721687914,-2.3943350197218704E-11,-0.00950367268517116,-69.17771319569478,0,0,0,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark74(-54.558198055221716,-0.8821942830413921,-1.335855024373697,-1.5707963267948966,4.383369551780936,0,0,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark74(-54.57471247534978,-0.02627920135900544,-0.031079508597151313,-1.031651635824666,-79.56032273976699,0,0,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark74(-54.597734576437496,-0.102165823033741,-0.5641254739837791,-0.6049773744696471,-65.3079690476078,0,0,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark74(-54.60473264735724,-1.2625595977646045,-1.5707853683712802,-1.5707963267948966,21.98962964230577,0,0,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark74(-54.60876547313622,-0.061330080002728625,-0.41688720734517926,-1.1966089342843325,-77.37494181636326,0,0,0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark74(-54.654440695413186,-0.05867028151758239,-0.3063093910970812,-3.469446951953614E-18,-6.302430189357968,0,0,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark74(-54.66065754214384,-0.05512514351066186,-1.1959917973432164,-1.5707963267948966,-97.39151345013968,0,0,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark74(-54.6872771866479,-1.0214890909130871,-1.0353096584726365,-1.1639965277429551,-33.36708680008843,0,0,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark74(-54.68838687653386,-0.8348803500727978,-0.8769918978197561,-76.5754514198437,-1.1882669331195226,42.37290387910723,0,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark74(-54.6895258826584,-0.29251127493188406,-0.2949217223548708,-0.6764419059873944,-1.5707963267948968,0,0,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark74(-54.70837699746341,-0.8100839548330419,-1.1975531061425384,-1.5703758600334459,-1.5707963267948966,-71.36615624874831,0,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark74(-54.71898193165765,-7.097299249236641E-10,-0.6702971244690072,-16.89916784339785,0,0,0,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark74(-54.73518660438045,-1.1389942357781635,-1.3539342480335308,-1.5707963267948966,-18.66572004611703,0,0,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark74(-54.73839240447909,-1.4599141251630254,-1.5707963267948841,-1.5707963267948966,-39.26985901716195,0,0,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark74(-54.74456030796788,-1.570796326794865,-1.5707963267948966,0,0,0,0,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark74(-54.74922310749284,-0.7697078948853336,-0.8590459891825847,-70.3599960471795,0,0,0,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark74(-54.751484319927854,-1.2646903751632939,-1.5707963267948961,-1.5707963267948966,-81.13356226895617,0,0,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark74(-54.77367737677042,-0.7972474431830671,-0.9038288391645576,-76.7403221112308,-1.4815594118080713,-127.13557853325031,0,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark74(-54.78469795518976,-0.3681466535314644,-0.7634618392597398,-76.21175924037105,0,0,0,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark74(-54.78943169341953,-0.17110825952133402,-0.38031418582647947,-6.728042418134265,-0.44634804837906167,-88.51244423539276,0,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark74(-54.801984678060464,-0.9224606217087914,-1.5609167100551424,-1.570796326775607,-1.5707963267948966,-67.23528329390292,0,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark74(-54.81517258580566,-0.9493109756316964,-0.9584440394757464,-0.9677590942684936,-77.57205724312757,46.68834338689062,0,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark74(-54.82316657435709,-0.23505930211482828,-0.29620231880335296,-38.01566961279138,-0.3375177021484901,0.0,0,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark74(-54.8474684235174,-0.2517054363237211,-0.5183566336192524,-1.5707963267948966,0.0,0,0,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark74(-54.87974911385678,-4.6027047727695876E-14,-0.5679646010189122,-1.5707963267948966,-96.11558323034677,0,0,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark74(-54.88433177167018,-0.3701295934449398,-0.6942346220557472,0,0,0,0,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark74(-54.90050209063132,-2.1276390640917087E-6,-0.5757020776045275,-0.9763468134546865,-82.65775580678931,0,0,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark74(-54.909673724861584,-2.898745962810297E-10,-1.2734897871423347,-1.5707963267948966,8.073596905613806E-12,0,0,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark74(-54.91286434325769,-0.861161110831565,-7.085318873557051E-11,-0.37396192865302463,1735.0063369078098,0,0,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark74(-54.91286729890692,-0.13324922041921972,-0.8991529951114483,-1.51193992929007,3.149710020663717,0,0,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark74(-54.93204216737135,-0.8017072361990155,3.3881317890172014E-21,0,0,0,0,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark74(-54.95490771893636,-1.3840527145261683,-1.4232980541459939,-1.5707963267948912,-1.5707963267948966,-22.280327107071557,0,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark74(-54.9686599913159,-0.16381244039741263,-0.2360581636463198,-56.78567207825762,-1.5707963267948957,1.5707963267948983,0,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark74(-5.551115123125783E-17,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark74(-57.28685772566406,16.03366052115038,-20.094196709895783,-3.8529604294993476,0,0,0,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark74(-57.974947918118616,-33.02655763243345,-98.96820828265143,42.467657553132995,-65.45780476705255,81.58911434708477,0,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark74(58.935115627434584,-63.025367740101125,-54.09791246134441,27.467517809818403,-32.942513280384915,48.4838836652751,0,0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark74(59.33426861045089,-57.18821554600409,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark74(-59.73398123110993,-0.6235972424522807,-0.8179990335604816,-0.8012302663388111,-127.60148860934004,42.80327097842303,0,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark74(-59.74692983001075,-0.3766845618812338,-0.40219052907022296,-0.6211740804127582,-82.77180754010678,1.917523796133425E-12,0,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark74(-60.70716973871166,-1.7763568394002505E-15,-0.032125804367117275,-0.39504761593860893,0,0,0,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark74(-60.70717121252977,-0.5670549079889857,-0.8091209982668365,-1.5707963267948966,7.8539816420526805,0,0,0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark74(-60.708621546061266,-0.8585731687189622,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark74(-60.72700098264405,-0.5345747173594846,-1.3092207995272762,-56.11933176108717,0,0,0,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark74(-60.74743536969602,-0.04190922449181955,-0.1785902377268287,-94.71893476254063,-0.23350948062158738,0,0,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark74(-60.77919613885751,-1.5481453843550057,-1.5594286025982516,-1.5707963267948966,23.578639007031317,0,0,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark74(-60.78622244190091,-1.3360117902154924,-1.523327446863298,-1.5594957948153008,-8.673617379884035E-19,0,0,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark74(-60.792929958529065,-0.17982485021058414,-0.5063273544514539,-0.6705066668250027,-76.1556638150079,0,0,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark74(-60.79489071953288,-1.4271853288347334,-0.27071765902365574,-0.1405847080803251,-6.539901685243979,0,0,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark74(-60.831781500948914,-5.551115123125783E-17,-2.0595353139114684E-4,-0.4082051174531149,-70.86862611105416,8.809495608984326,0,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark74(-60.833160811873896,-2.220446049250313E-16,-1.5699376498665498,-1.5707963259620734,-1.570796326794898,0,0,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark74(-60.84595888002695,-0.8813645197084233,-1.5707963267771292,0,0,0,0,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark74(-60.85735115077391,-1.059796138500756,-1.0925604862497593,-1.5707963267948966,0,0,0,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark74(-60.881090973847805,-2.7780702714659806E-9,-0.48678598485974534,-0.6422184225013615,3.1438670146311827,0,0,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark74(-60.887876532056964,-0.6715579830808847,-0.7784908871224063,-1.1865533778321196,-45.79964467709836,118.05005545140305,0,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark74(-60.90391353661047,-0.8150980922896753,-1.2000502056957718,-76.86334404603913,-0.00479041543433717,-6.290837403873571,0,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark74(-60.93262643498187,-2.220446049250313E-16,-0.13239081066560002,-50.44721206719842,0,0,0,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark74(-60.94413090162878,-3.373236514571231E-4,-0.04330134122264129,-0.3607724454274783,-63.28018780874223,0,0,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark74(-60.94620866892875,-3.771190955760758E-11,-0.003154210412389587,-1.5707963267189802,-1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark74(-60.9561999360767,-0.2624626115448353,-0.3331467058952028,-50.64234464469631,-0.8324808657620171,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark74(-60.97369662083013,-0.030338355706788042,-1.5707963267948912,-1.5707963267948966,0,0,0,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark74(-60.981349684933974,-0.568751584648498,-0.8098554317336522,-1.201263744780819,-127.53915653688807,55.19721317569113,0,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark74(-60.99451104822046,-0.009651161212252261,-0.6420235849657085,-0.2631971006265085,-6.535257875825896,0,0,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark74(-61.00239661293009,-0.06207710306967047,-0.2735373616303828,-94.79646895700027,-0.5486954255907549,3.054725780078827,0,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark74(-61.00483694480995,-0.5220012129722114,-0.7562253002120332,-7.439413782306122,-1.2218136466255545,98.79917189781426,0,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark74(-61.01167521028227,-0.011112706326073946,-0.30571904115030357,-1.5707963267948966,-12.660092556829598,0,0,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark74(-61.02973630334378,-0.8426356471367538,-0.28800490586413624,-6.288406102950241,0,0,0,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark74(-61.03146489942791,-0.6157879438822216,-1.5697531442428958,-1.5707963267948966,1.9721522630525295E-31,0,0,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark74(-61.03582885633436,-2.1955960854951781E-16,-1.5707963267948948,-1.5707963267948966,78.35446385916829,0,0,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark74(-61.04542396543826,-0.21943388688236998,-0.25572362547413513,-63.12322509008631,-0.3102786787132144,-1.5707963255540578,0,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark74(-61.04810304108493,-2.6676830379214207E-18,-6.465827772137418E-9,-207.31345456308867,0,0,0,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark74(-61.05512232015084,-0.1125108788248963,-1.1519870036927722,-1.1519870036927746,-34.56298145630303,0,0,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark74(-61.113507532357744,-0.12247370464918211,-0.33335708197306246,-82.72581704416031,-1.3519151300206005,1.3274193661498215,0,0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark74(-61.121365274512655,-0.813886908390437,-1.389348708670041,-83.07150406481519,-1.5707963267948948,0,0,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark74(-61.14337746846892,-0.35830088614105793,-0.3626993578899058,-13.571098360828701,-1.570726392991782,0,0,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark74(-61.1486690134422,-0.2057562077194064,-0.418945812595578,-1.1299474490732693,-83.69305419785115,0,0,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark74(-61.15844340751909,-0.7614687623002327,-1.5503137297699838,-26.688080199527732,-1.5707641898945095,-1.570796326794898,0,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark74(-61.15952861588161,-0.5225993848546879,-0.7467366016724223,-0.6759335175540551,-21.112495639571875,117.4514784244939,0,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark74(-61.17016729262153,-0.07319826393813413,-1.1509543146151935,-1.2464042707370073,-58.26867592394327,89.88519723457694,0,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark74(-61.179095180954064,-0.8433854669923507,-1.5174804005692726,-1.5707963267948966,-1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark74(-61.179246763141585,-0.12039302538986735,-0.43920768411950756,-1.316504530991109,-1.5707963267949054,-7.866242976400845,0,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark74(-61.185118201484,-1.5707963267948948,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark74(-61.21812637843001,-0.8239469096186215,-1.0189754815895757,-1.0622500529230479,-2.0365315084854996,4.712972617237999,0,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark74(-61.242047695551456,-8.648428921584318E-19,-8.648762869109357E-19,0,0,0,0,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark74(-61.24538974781984,-0.2863303047089585,-0.29309493060992287,-50.602113031048454,-0.3960714078794252,-100.52437290126885,0,0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark74(6.19531033849816,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark74(-65.97344601586262,-1.8624344530895187E-9,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark74(-66.00394212173848,-3.263636218878347E-12,-0.17662801540129003,-1.5707963267892222,-1.5707963267948966,-67.3322472473491,0,0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark74(-66.05024914785851,-0.5717292362951703,-0.586369455432176,-13.224057601558478,-0.6889319399822134,-1.5635328755447293,0,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark74(-66.0666233884313,-1.509187643011864,-1.5434944067421799,-1.5707963267948963,100.0,0,0,0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark74(-66.08951391006715,-0.3580253559395533,-0.7340289959552257,-89.12103590409116,-1.2625438724485178,-39.246499290015336,0,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark74(-66.09059094544453,-0.19880103673852517,-0.5611171026263013,-0.629907181653067,-128.177468289857,131.3162225541843,0,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark74(-66.22351857712826,-0.019979823690677388,-0.7967411756425307,-1.5707962085161526,-1.5707963267949054,100.0,0,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark74(-66.23717231866218,-0.15750552940774487,-0.6287632465249542,-0.6731501768863215,-7.908812765966653,0,0,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark74(-66.23862237788221,-5.932307577751055E-10,-0.4782437933937749,-1.1378843182377147,-80.2465857920802,0,0,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark74(-66.30317036846219,-1.4143397920216867,-1.5707963267781349,-1.5707963267948966,0,0,0,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark74(-66.30478368497354,-0.19179256457583643,-1.5707963267948961,-1.5707963267948966,-53.429724220272554,0,0,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark74(-66.31621166292864,-0.2110176212697663,-0.2152340138128777,-0.8124827802737103,-1.5707963267948966,-22.8160891003863,0,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark74(-66.31870231398888,-1.3541178505231581,-1.5707963228932216,-1.5707963267809117,1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark74(-66.34560365830983,-1.1030006744373184,-1.119423157852666,-2.0290436562439036E-11,1.5662339012534903,0,0,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark74(-66.35720779376969,-0.07071305405349623,-0.20647540686112587,-56.77617182917863,-1.0772500133213332,-19.62233981180031,0,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark74(-66.36139818751738,-0.2702195937390384,-1.3492439427474743,-7.65695928886745,-1.5707963267948963,44.96171002851887,0,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark74(-66.37052093204093,-0.05330907247180108,-0.31617584330272336,-1.5707963267948966,-73.53281966674942,0,0,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark74(-66.37313859623636,-0.25553926314073616,-0.255582896464975,-1.4741131580582074,-83.15552215139283,0,0,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark74(-66.38799382487886,-0.149404088106871,-0.43684113305987743,-13.8109156341514,-1.491063647095661,100.0,0,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark74(-66.40316164752792,-0.005434487822461973,-0.010324910940628991,-0.01230392512954207,-31.394831526806552,0,0,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark74(-66.41233823220401,-0.8340269633177747,-1.3784772479684482,-1.5707963267948966,19.819614537307785,0,0,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark74(-66.44180697317071,-0.9022003435954442,-1.1850672583610062,-64.16748520352714,-0.9632213033254173,3.3034276461420564,0,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark74(-66.4530085791252,-0.2279312552610026,-0.38872805252087356,-1.3960187373861095,100.0,0,0,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark74(-66.47903882509739,-0.5361741299067763,-0.5402509862165467,-0.5405608387935376,-1.5707963267948966,-99.98446613742226,0,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark74(-66.50167442698981,-0.4115522207920135,-0.5014686674206718,-0.54872955186928,-2.3952289310096897,42.94486644228204,0,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark74(-66.51776014090576,-0.3306379805628994,-0.4684382081369852,-1.5707963267948966,-70.68516127201292,0,0,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark74(-66.53254993905114,-2.220446049250313E-16,-1.482958590286344,-1.5707963267948966,21.989613360277655,0,0,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark74(-66.53463677550438,-1.1877017888889152,-1.375983068123931,4.0389678347315804E-28,0,0,0,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark74(-66.54161445482976,-0.0720295991338179,-0.12764539610672418,-1.3395049057687891,-95.97649989488794,0.04809250816117888,0,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark74(-66.58623794052865,-0.3040419796718701,-0.6682683513800166,-1.3877787807814457E-17,0,0,0,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark74(-66.59057453673097,-2.023009112467547E-8,-0.3858915499981428,-43.82851433956445,0,0,0,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark74(-66.59155841016863,-0.9531250748983542,-1.07908829639849,-6.710318076088285,-1770.7306218311774,0,0,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark74(-66.63193973966196,-0.6473153089492052,-0.8902689449716709,-1.5707963267948966,1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark74(-66.64822407612918,-0.2631352964392276,-0.27108831246858967,-50.6605427143242,-0.4189601514291632,9.545502063453974,0,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark74(-66.69423455989764,-1.4040820728265668E-10,-0.4096731599988051,-63.74399547959142,-24.554851000535148,0,0,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark74(-66.70880178115051,-0.0338580002035866,-0.3020232922831757,0,0,0,0,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark74(-66.72386862221471,-1.3084371136607018,-1.4596839064578413,0,0,0,0,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark74(-66.7353153895084,-0.022812417518752792,-0.23873583812984034,-100.77301217656839,-1.1390860463711405,-1.1885131044262351,0,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark74(-66.73612863227672,-0.7056558992523707,-0.9494457010473759,-1.5707963267948966,0.0,0,0,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark74(-66.75196375784192,-0.10063511585691938,-0.11768734225459712,-56.715081253465776,-0.416332387552451,1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark74(-66.80193968682855,-2.4994760506193757E-19,-1.916980818989907E-13,-0.22510116307971353,-59.381543909774415,-1226.4317403913467,0,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark74(-66.8049699192748,-0.19566319160288015,-0.5183332752756742,-69.11482671491665,0,0,0,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark74(-66.81397597973117,-0.12223504270956076,-0.16944025953015174,-0.17067959997283003,-2.1408696475089233,100.0,0,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark74(-66.81565292138367,-1.5378205683135282,-1.5707963267403653,-7.596055976146588,-1.3129360877209437,-13.656896751954012,0,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark74(-66.8231683420192,-1.466956297120534,-1.4879763939084067,-1.5167043521988088,-1.5707963267948983,42.5931521320973,0,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark74(-66.84882946046118,-0.45441017854892163,-0.4716999576785387,-1.5707962935016742,-1.5707963267948966,-1.570664493749655,0,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark74(-66.87520516613264,-0.18443951621670715,-0.2118917061259285,-94.57937513767081,-0.2920450645320388,35.69578234130457,0,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark74(-66.87811163679396,-1.5510385436232645E-15,-1.4761570674466278,-9.860761315262648E-32,0,0,0,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark74(-66.88945492127914,-0.5531979449042224,-1.5707963267675236,-1.5707963267948963,0,0,0,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark74(-66.9086875244407,-0.8174080810634767,-1.5707963267948912,-1.5707963267948966,-219.91018650746014,0,0,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark74(-66.91412167682333,-0.3705719027242931,-1.3509196171166646,-1.5707963267948966,-4.158037083381068,0,0,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark74(-66.91887126356302,-0.5368313404446752,-0.8121518110026316,-0.9177737089480266,-1.5707963267948983,-0.001853175056810134,0,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark74(-66.93893523272105,-0.3389258567776143,-0.3540239016995727,-0.5270493362438722,-98.0550378489235,0,0,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark74(-66.95227766961904,-0.27061443427790616,-0.38546213525816886,-1.5707963267948966,-15.19109068799077,0,0,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark74(-66.97472839910397,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark74(67.7429698435648,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark74(-72.41609532960756,-1.474976299833829,-1.5018534704954614,-1.22780200687656,-2.562488985172359,-7.894117040663041,0,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark74(-72.42701325755783,-0.3515609277198768,-0.7034929415750579,-0.4999670428864389,-163.8627924827449,0,0,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark74(-72.443362288477,-0.1399072152585874,-1.5067300085881266,-1.5707963267948966,1470.1494787155898,0,0,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark74(-72.44791306173295,-0.38883413668916017,-0.13825722725649672,-0.4779145047725001,-87.99760439396785,0.0,0,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark74(-72.4485499896349,-0.11542318872479185,-0.4353466627732216,-82.1189729636461,-0.7915467795438508,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark74(-72.49348524490439,-1.5707963266704124,-1.5707963267488896,-1.3510956644952152,86.61349822718276,0,0,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark74(-72.76943991779561,-0.660158522382795,-0.7664105882998249,-459.6198368992551,0,0,0,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark74(-72.78419010255536,-2.220446049250313E-16,-0.11267289059823499,-0.7698936056427713,-52.32220537609828,73.43595040354418,0,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark74(-72.78501342832647,-0.046239679743324894,-0.09899256014686397,-13.377874727982913,-1.5707963263808573,-89.70323349823151,0,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark74(-72.81635925637718,-1.0775026981718618,-1.077502703620396,-1.0793144895167572,69.20420276028304,0,0,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark74(-72.85091645730625,-0.23920302478259314,-1.489103768360847,-76.9375892727359,-1.555602817503576,60.06943020631731,0,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark74(-72.86019051032211,-0.03601613916540709,-0.05471599322480388,-19.0142792232389,-0.16557880801596989,1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark74(-72.88674156422495,-0.18730603328981665,-0.195140058592374,-0.8218510637995702,3.191232059594134,0,0,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark74(-72.89311315012728,-0.51765189141695,-0.9442896149262167,-13.615279624300852,-1.4395185415761196,-39.185391039485616,0,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark74(-72.89466295826233,-1.4005302772187262,-1.4083764916361277,-9.2264330812387E-14,0,0,0,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark74(-72.89978771988255,-0.039608789861576454,-0.04158429552894799,0.0,-128.6080780673069,41.92039438117424,0,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark74(-72.90397581607876,-1.4009401339639898,-1.570796325845119,-1.570796326600592,-83.2565669271845,0,0,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark74(-72.90733692746406,-2623.0476072664183,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark74(-72.91596231535213,-1.0362339275639465,-1.0711080274926297,-1.5404790351747968,-45.678435798691936,-7.859306772572868,0,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark74(-72.92364982437634,-0.12805870104449102,-0.20323341565580044,-31.884412583465835,0,0,0,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark74(-72.93600180610542,-9.536972565935152E-7,-0.056459493775205705,-81.74445960835547,-1.304079781082032E-6,0,0,0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark74(-72.94195820057679,-0.848304438285731,-1.355958027903495,-76.86160969423716,-1.5399000285293216,1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark74(-72.95990706899946,-1.864647484752032E-4,-0.43095459503443007,-25.133387065894738,0,0,0,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark74(-72.96097555288048,-1.389210138588947,-1.4158948238902356,-1.5094451416565584,0.0,0,0,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark74(-72.97077472137728,-1.1662454974773908,-1.5707963236988993,-1.067705859250577,-58.41445142738714,9.42951614739161,0,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark74(-72.98989958074097,-5.162175768354478E-19,-0.9457533586571145,-1.2471562471326592,-33.197153708197874,0,0,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark74(-72.99199991217205,-3.1440353865901624E-8,-0.017334528380430644,-31.572806201287968,-0.37487696738177856,-6.657029403079674,0,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark74(-72.99713726378076,-0.9467152840042126,99.45169822308382,0,0,0,0,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark74(-73.00852178902879,-0.6699167069875704,-1.1025224823956983,-1.259621366248714,-1.5707963267948966,-27.345143231326173,0,0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark74(-73.01732113715836,-0.11130247288577078,-0.5045746898730021,-0.6651745930030052,-33.816214799396825,55.017100955284775,0,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark74(-73.02726059047384,-1.273906044619765,-11.546989519232561,0,0,0,0,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark74(-73.03087951691334,-0.016700201317640318,-3.531767525666137E-5,-56.75074187513428,-0.7120753076652949,-19.820533566833653,0,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark74(-73.0392539234578,-0.002349785943036463,-0.8522154262657321,-1.5705487637170836,-1.5707963267948983,0,0,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark74(-73.0416049463159,-0.6569766163512328,-1.5707963267948895,0,0,0,0,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark74(-73.049769151832,-0.5785455167836121,-0.610215358007981,-1.5707963267948966,-0.4155600104466993,0,0,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark74(-73.05050081611972,-0.01993843888542908,-0.021229634979668045,-56.527210994047074,0,0,0,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark74(-73.05317347404161,-5.577254344223073E-12,-0.005370591743906012,-94.96207677554209,-0.9078340607261851,-100.0,0,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark74(-73.05938957117156,-0.21065222432211808,-0.21200807460570506,-63.0456262934829,-0.3271636483669556,-44.30941069364816,0,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark74(-73.06579596195837,-7.106912284345241E-10,-0.004563562433305468,-76.07103876465074,-1.2524058786181833,5.551115123125783E-17,0,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark74(-73.07138778669487,-0.407852054247003,-0.6560436712250721,-1.5204008644930922,-1.5707963267948966,-1.5707963267949197,0,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark74(-73.0767400117303,-0.5246698195329036,-1.0851094556796606,-89.05942162052779,-1.1199587087079474,-34.09652951183803,0,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark74(73.0780360217172,55.697336890411265,-30.77573662852147,-45.82908006186739,-3.2838101524665007,0,0,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark74(-73.08464274386381,-10.700671184744621,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark74(-73.08600644431263,-0.02390723007808737,-0.08934896384872987,-0.15879366924148053,38.01075268918659,0,0,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark74(-73.08760094361719,-0.5244488118938977,-0.5876555816760848,-1.5707963267922858,-1.5707963267948966,5.739718509874451E-42,0,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark74(-73.10713637913977,-1.5533760801325442E-10,-0.3487169351599592,-0.3561487940716325,-63.4178673897865,0,0,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark74(-73.1161091170789,-0.3522290082338757,-0.4276995775440591,-0.7887585978680932,-45.791425585331496,38.57912028330823,0,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark74(-73.12265711918675,-1.4524707267407,-1.498960461193522,-7.80639379952752,-1.5644240210503855,-50.2650395604345,0,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark74(-73.1296004695372,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark74(-73.13964810349398,-1.4831767370289828E-6,-0.8220958297190109,-1.5467474827374446,-27.704889574064012,0,0,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark74(-73.14317262678155,-0.35328303465171706,-1.4363888876960136,-1.4367039385329734,-26.61939078804419,0.0,0,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark74(-73.17137192466467,-0.6839292154338931,-0.929251894131739,-1.5707963267948966,53.58958952372746,0,0,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark74(-73.21322681140448,-0.46461535283554284,-0.8477951960565898,-0.9482641108904776,-1.5707963267948966,-54.486337260546705,0,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark74(-73.21493154359273,-0.5703259696941076,-0.7940983494758647,-0.8930369002352031,-1.570796326833837,72.94390544017843,0,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark74(-73.23382453657993,-0.35416942060152756,-1.0428820208054828,-19.900848971384264,0,0,0,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark74(-73.25435219283267,-6.791662893816256E-11,-1.5707963267918992,-1.5707963267948966,-34.223627002747655,0,0,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark74(-73.52683381800698,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark74(-7.374704154059458,4.134233094410305,-34.29187657751274,29.386336251489666,-78.96837876669701,-98.63862752378284,0,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark74(-78.54140115079352,-1.888789185061925E-5,-0.043699826484122975,-0.05575456066920366,-91.172429968346,0,0,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark74(-78.55898131566681,-2529.006484248281,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark74(-78.57563636576805,-0.06687456963871607,-0.9357946757308215,-76.54846087850919,-1.225590917934726,270.2246124961355,0,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark74(-78.57782984552529,-0.0493379525333154,-1.3414269729150843,-1.5707963267948966,-1.5707963267948983,0,0,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark74(-78.59823523747221,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark74(-78.60022417288798,-0.5100070087224201,-0.6733518186981772,-1.5305051311745395,-1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark74(-78.67661429886704,-0.30884264277333084,-0.2590284191845937,-0.3437298921052392,-309.4014700138057,0,0,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark74(-78.67854803419152,-0.5194923117894161,-1.2370800347248,-1.56139511564765,37.69911986078286,0,0,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark74(-78.67910226632789,-0.038186331358193035,-0.0541229439457829,-1.5707963267948912,91.11436437301307,0,0,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark74(-78.69849421737052,-8.46498620616637E-11,-1.0212945788585657,-1.162684687867349,-64.19654083969004,0,0,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark74(-78.7559199997884,-0.009526505412982646,-0.03435827689297861,-0.3109996180722637,-1.5707963267948966,-1.5707963268024743,0,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark74(-78.76151436992826,-0.49216229561516384,-1.4853707948266146,-1.5411163830105028,-1.5707963267948983,1.563131392038589,0,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark74(-78.78441412154385,-0.27985432222821977,-0.4583707577040518,-0.679432282291387,-8.572561602625585,0,0,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark74(-78.79691642682195,-1.332352584572585E-7,-0.44581067503966026,-0.873630072761064,-44.90031509796104,-99.99999940692375,0,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark74(-78.84808263646482,-2.814020291861519E-7,-1.1726658162059833,-76.79131226477264,-1.3934422385549363,54.815917177294395,0,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark74(-78.88303779975165,-4.334798025728539E-10,-0.6188951647463827,-19.87025849398414,-1.216121744537538,-36.27416071227279,0,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark74(-78.89488109106678,-0.4196054792752187,-1.491560396855637,-1.492189648753797,-6.5524632348238825,0,0,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark74(-78.90242352032516,-2.528290651178643E-15,-5.720359895296761E-15,-39.23712041270603,0,0,0,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark74(-78.90664266749003,-0.11111146358161998,-1.268623856905478,-1.5707963267948966,3.0225290500407738,0,0,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark74(-78.91699401776836,-0.47285187886426744,-0.7199561973469991,-7.174256657583584,-0.9617551356535393,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark74(-78.91855990579889,-1.5553968149178308,-1.5707963267948917,-1.5707963267948966,-8.673617379884035E-19,0,0,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark74(-78.92038290101306,-5.697574140701818E-10,-0.7533707164391479,-1.2129048997150143,-1.5707963267949054,0,0,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark74(-78.9445736848124,-1.3675084466164442,-1.5593154558914049,-1.5702641207244983,87.9334904840442,0,0,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark74(-78.94546248125577,-0.016809659447995798,-0.019299912400228204,-0.021579396464890724,92.51316641543012,0,0,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark74(-78.95464635650616,-5.658417355852885E-7,-0.08063350750991681,-31.50166444075241,-1.000333545415646,-20.986158088471115,0,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark74(-78.96582638673303,-0.7610962598264813,-0.7610963175855738,-0.5065097245783372,49.7589727328534,0,0,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark74(-78.97780618049003,-0.4155048383880924,-0.49502182312494114,-75.98367215688515,-0.8597001942380282,-164.21925128161865,0,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark74(-78.99115952630493,-0.16293251706038786,-1.0000076915033589,-1.5707963267948957,1.5707963267947846,0,0,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark74(-79.00013167517052,-2.220446049250313E-16,-0.007711529186433605,-0.47075783063786336,-7.92302025178833,42.56182780313519,0,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark74(-79.00074538252554,-0.140161524491355,-0.4908173444611289,-0.5122934235955375,-1.5707963267948966,-4.978108419787935,0,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark74(-79.01716670905762,-0.49087206885289514,-1.439326872973688,-14.027329831271459,-0.8764441514174204,-120.25877493042802,0,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark74(-79.03490560976252,-0.7793594044136116,-1.1751057958668194,-1.1824310819284947,-8.117139373142358,0,0,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark74(-79.03949452086542,-0.6503478594897274,-0.9380206247266354,-70.0573673705163,-1.5707963267948961,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark74(-80.62905136466172,26.146699061545362,-21.270852443190364,-79.65416795364217,21.81220219146826,53.48841005598899,0,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark74(-81.08379715241449,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark74(81.42725818381317,-78.22870881461009,52.258501348678834,38.88240320040086,0,0,0,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark74(-82.32866615658821,80.1495423638963,55.818948960683656,-0.9871299787541403,-84.09828481385368,0,0,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark74(-83.76648691196513,4.131597235723518,-6.604056950140105,66.43206236035545,-1.948738898783489,0,0,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark74(-84.30784623805371,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark74(-84.82778710834319,-0.9399109159413018,-0.966587369505009,-94.48614941639877,0,0,0,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark74(-84.8403698206313,-40.3103415476681,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark74(-84.84109194130505,-0.13213876874615416,-1.2361982740000788,-89.30674128260844,-1.3879598845069077,-1.5707963267948983,0,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark74(-84.85203609448939,-0.6944717077093433,-1.0171003061835013,-1.253930229912742,3.3034990339172983,0,0,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark74(-84.90358884935132,-1.1102230246251565E-16,-4.673786144343475E-8,-31.585378508679405,-1.2525180766238568,0,0,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark74(-84.92331070845925,-0.23235129010195998,-0.4434657824667238,-0.513565227366839,89.0278198981261,0,0,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark74(-84.92371339795945,-8.881784197001252E-16,-0.04962296232070891,-0.6404924806950858,0,0,0,0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark74(-84.92446142299003,-1.3412403829605868,-2.220446049250313E-16,-7.60274528202015E-15,0,0,0,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark74(-84.92530819114805,-0.9636144604843476,-1.2242769507238933,-13.401717891906028,-0.8613786740855356,-78.60355350040304,0,0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark74(-84.93035802198057,-6.209347309680236E-12,-0.17921699697583718,-0.3953239373882633,-1.5707963268060063,85.36548778572799,0,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark74(-84.94144995831446,-0.7452513199135353,-0.7886846851538277,-7.511118729459142,0,0,0,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark74(-84.9758089467227,-0.6593430166128746,-0.58797666602878,-1.5707963267948983,-1552.1853031009518,0,0,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark74(-84.99419183429339,-0.6727359459571495,-1.040419596246331,-1.5707963267948966,10.64718860324514,0,0,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark74(-85.00516549782878,-0.29929752688471256,-0.737620031326762,-0.8859437935651764,-52.48664160798315,71.70881387946962,0,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark74(-85.00604975902468,2.465190328815662E-32,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark74(-85.01384834364605,-1.8475438040187505E-6,1.3552527156068805E-20,0,0,0,0,0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark74(-85.0225823515353,-0.06449260919166538,-0.0721123621884688,-1.5707963267948966,0.3158957739831489,0,0,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark74(-85.02499613119492,-1.0503625465124338,-3.6086891694186995E-4,-1.5707963267948966,-1769.8496413928112,0,0,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark74(-85.03056079308591,-0.4215351189748302,-1.2960390203573349,-1.416663611705022,-1.5707963267948966,-1.5690879408631386,0,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark74(-85.0675141739048,-0.2643416820975961,-0.3433483013362521,-1.232595164407831E-32,0,0,0,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark74(-85.07071268970688,-0.10647534242868945,-1.554480408530418,-1.5544806520099939,21.9486492133356,0,0,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark74(85.73034518703045,-69.81938400198246,-72.74985589394663,-79.8278925706526,-67.47141070782106,-97.15204958606809,0,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark74(-86.06279848276135,10.223563324237688,-30.280357594006205,17.913637575511302,18.860791534369724,61.13938066395187,0,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark74(86.72473337483234,-0.6912173674491982,79.26548054547399,3.0911168486336607,66.30290875895943,0,0,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark74(90.26654071445984,57.7308503039165,12.894134476703826,-87.54800443550826,-38.63244968024793,-94.5719280213934,0,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark74(90.5851537697439,-26.012878993501687,73.68896308403214,-80.46588434177755,0,0,0,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark74(9.093252177670294,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark74(-91.11553997258912,-0.4826898698060171,-0.7767955920376056,-38.55372211816943,-0.9705978633642092,-84.37668926640741,0,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark74(-91.1194055093431,-0.16916469485321184,-0.5096136380285874,-76.65519586035293,-1.3427378651916797,-29.53496088744356,0,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark74(92.31693121984566,-64.65201442305417,33.67592300981613,0,0,0,0,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark74(92.71093918106331,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark74(9.357115550844071,45.41552499839855,-78.59380411524148,91.43118617056217,-68.14013603258826,57.03414219399755,0,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark74(94.15635679558665,-91.7834250034314,18.064944176377324,-57.522794902829474,0,0,0,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark74(-9.49084465280707,-0.9052505926501967,-1.448328496255267,-69.2800274025589,0,0,0,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark74(94.95653319769798,32.449520408882876,-93.66811390646619,-3.2076591923750186,0,0,0,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark74(-9.500784211067556,-0.18380159646251704,-0.7102391870805842,-1.4056031480520639,-45.63911933860172,63.84102289287237,0,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark74(-9.508811228974533,-0.4640267477659141,-0.6637029774475134,-1.132870110214001,-1.5707963267948983,-58.849437357122625,0,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark74(-9.521188130317713,-0.8486354420135405,-1.0093101903823893,-70.1648636763004,-2.1684043449710089E-19,0,0,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark74(-9.530623269954594,-0.09941468557922153,-0.7782011781699658,-1.5705910775849177,-1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark74(-9.54646046126141,-7.299782048209898E-10,-0.186104931430498,-0.7304724516356965,-65.15709532555881,0,0,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark74(-9.546832848693128,-0.22071210563746968,-0.4447452750556221,-13.311871280620691,-1.4124653321999325,184.73364113907377,0,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark74(-9.547392969668612,-0.0013558199611834658,-0.5190199608360405,-1.5707963267948963,0,0,0,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark74(-9.549191930475686,-0.29720701544142825,-0.3215067008878732,-97.41936537832618,0,0,0,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark74(-9.554220933016694,-1.5707963267948963,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark74(-9.563660136742463,-1.2834866496193211E-14,-7.659040143821658E-11,-0.17353691289628756,0,0,0,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark74(-9.576195317945178,-58.63987154566015,-51.930339311447035,6.596699736615989,-21.925698753354965,0,0,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark74(-9.584945308501872,-0.03597712455808022,-0.8529780006609207,-1.5707963267948948,-90.73866133179891,0,0,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark74(-9.600251037597594,-0.08796784872712657,-0.4056311853896359,-1.5707963267948963,-58.025446454483045,0,0,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark74(-9.607273677776513,-0.15686614356651973,-0.26055929810928025,-126.53881041055183,-1.5707963267948948,0.0,0,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark74(-9.610027722081695,-1.287570735085164,-1.3783042160898995,-1.5495061359222164,-1.0113179456281288E-13,0,0,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark74(-9.620687160730384,-0.40578646524913353,-0.569305406577156,-0.6374306863225672,-1.5707963267948966,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark74(96.32030522120806,-97.62781030491247,-75.00665764304804,87.71374166450653,3.691412796724663,0,0,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark74(-9.644828904209467,-0.38237016343413827,-0.4114081065418282,-94.73920115017324,-1.152452572048233,0.0,0,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark74(-9.645889174573426,-2.0741500948637336E-11,-0.05305051318181503,-0.2777186481182648,54.73691546132664,0,0,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark74(-9.661712870690234,-1.9689801258788895E-12,-7.353511468654848E-10,-76.96198883842537,-1.5707922174146203,-58.08670197755268,0,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark74(97.12642791572594,-67.01042603776956,-90.53119035589661,-52.991168405657454,2.0222551111782394,4.5153963031369955,0,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark74(-97.38937234075621,-3.7856262481431576E-20,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark74(-97.42405081274508,-0.015153279998864734,-1.0659699863364986,-89.03235305966382,-1.1597072921976121,123.98748166350023,0,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark74(-97.66528820367071,-0.7466569606548902,-0.9657041240636436,-1.1652395846709933,92.0979734502235,0,0,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark74(-97.70124241792425,-0.4753214985574008,-1.530444301420701,-6.0044825761070415,0,0,0,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark74(-97.70437213710197,-0.3170281695956719,-0.5743440752846832,-0.6202976953205706,-82.32458224613119,0,0,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark74(-97.70744996869296,-0.3492818426846227,-0.42302152593947845,-0.45095866208112884,-51.934353666873385,-0.009206687333823012,0,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark74(-97.75686563206202,-0.48871170092853444,-0.5003748919430594,-44.60286263521804,-0.6363322665312862,-82.4819788805146,0,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark74(-97.76188281640093,-6.065559383675568E-4,-0.18794422147709655,-1.5707963267948966,1.3552527156068805E-20,0,0,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark74(-97.76225728372678,-0.5982351414268574,-1.2971016777146573,-1.3859027245018278,-1.432590882021796,0,0,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark74(-97.78513496260047,-0.17001658530831945,-0.7389249090742869,-76.15483742513022,-0.9315902017534841,10.375259007543518,0,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark74(-97.79327733314501,-0.0016336205988436731,-0.2751461779662313,-7.146769578084985,-1.0633819652256058,6.5991256291585065,0,0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark74(-97.81653566709277,-0.2930455108811022,-0.3908508871638713,-0.4106833854246267,-121.95061521330088,130.74951929296512,0,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark74(-97.81884988162571,-0.861921565353873,-1.1643820161227003,-1.5707963267948966,-66.03871552541942,0,0,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark74(-97.8560375482998,-0.8097227047834357,-0.8261612980800739,-1.1307665704667154,-1.5707963267948966,-6.905891583875407E-5,0,0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark74(-97.85786796157245,-0.5669778455127314,-0.7542589122476925,-23.365638621775318,0,0,0,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark74(-97.86721013136176,-0.3146600256683138,-1.3970636599495172,-1.516320739800605,-1.5707963267948966,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark74(-97.90306400781294,-0.24387157801227716,-0.4027484918528143,-0.4035384483271996,-12.705511524012293,0,0,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark74(-97.9367673218406,-2.4423536221919444E-12,-0.03567164854308852,-1.5707963267948968,0,0,0,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark74(-97.9403981554307,-0.008659874414548184,-0.11078783958300775,0.0,0,0,0,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark74(-97.94611487557073,-0.09273003052296089,-0.1083056042969289,-94.53593713845974,-0.5254814133475948,41.36618591001497,0,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark74(-97.9564143957293,-0.354931449524271,-1.471100645417321,-70.5965826558503,-0.018777880366799053,-3.1496497929266556,0,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark74(-97.9599801129751,-0.5343118547361042,-1.2896621917819384,-1.292940851557304,-6.5334961665720614,0,0,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark74(-97.97562728402843,-0.7190328851900395,-0.8203225142756827,-0.8444762160710388,-2.080799127926543,67.23032568338725,0,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark74(-97.98269431522684,-5.046174576884928E-10,-0.7842673803249158,-20.21181692057587,0,0,0,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark74(-97.98538995727317,-0.08699879157935375,-0.34708855883097467,-19.31027951738075,-0.8067144335157262,51.30380472405565,0,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark74(-97.98850389120413,-0.030186441952384273,-0.1395677321071688,-0.13978005199678303,-32.16589101002836,-13.163814440297397,0,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark74(-97.9995906300027,-0.3428532301403491,-0.4719915918390156,-75.90118139307826,-0.502957710815553,21.97606490834119,0,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark74(-98.01250920655878,-0.05720015022429803,-0.2985597005213296,-0.2999918629461291,-71.50155212793842,62.78143652341187,0,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark74(-98.01570098048818,-1.2276294953475566,-1.2276394202963183,-0.60798849338059,-46.51075832754144,53.895053081593915,0,0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark74(98.01869152662965,-23.264597454288833,92.16595771729672,-21.886756127515966,-71.79911774068167,0,0,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark74(-98.01894614915861,-8.227067056115642E-11,-0.0012168826306596177,-0.973296294107426,11.762220377527036,0,0,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark74(-98.04611683145629,-0.10572359989419254,-0.10754908779309615,-69.23917390565867,-0.2943261593518032,-95.59145995141304,0,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark74(-98.05710148363092,-6.938893903907228E-18,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark74(-98.0681010855015,-0.8880526270091791,-0.4228306230665453,-0.5261459842450863,-579.8886486958318,0,0,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark74(-98.06943967260375,-0.012021939159398644,-0.3265069505044327,-0.3266676339479254,37.75232473199914,0,0,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark74(-98.07522304782346,-0.6797136492027409,-86.68513244066781,0,0,0,0,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark74(-98.09910524532194,-0.36553713258356485,-0.5932258155402611,-1.5564923109448208,-1.5707963267948983,10.409026626556482,0,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark74(-98.11588524716754,-1.022479379463703,-1.0816239672634012,-7.497260518877602,-1.3895162744443348,-1.7532967972666331,0,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark74(-98.17745205573803,-0.008826486234207714,-0.05938604753769157,-0.059484309850654206,0.0,0,0,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark74(-98.17977413749499,-0.7362583011661883,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark74(-98.19562428851884,-0.0715603168650083,-1.5342397249745323,-1.5707963267948966,47.33496811111678,0,0,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark74(-98.20850716466464,-1.4214195727641172,-2.977540706360452E-8,-69.31823403819058,-5.2317916646803475E-11,1118.111876860676,0,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark74(-98.21386763356325,-0.2662921040452926,-0.5303609524351128,-478.0139778043389,0,0,0,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark74(-98.27186802978983,-0.35611422178778096,-0.4845159648088785,-0.5479599246991429,-1.5707963267948966,-8.992687582078744,0,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark74(-98.2951129384009,-1.0411968170558683,-1.5559028220311242,-1.5707963267948966,0.0,0,0,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark74(-98.33826343697008,-0.00437259928296372,-2.6869559635940895E-11,-0.536613756640409,4.631849295994238,0,0,0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark74(-98.34604350520557,-1.2088099172736828,-1.3934462571673425,-1.5707963267948963,9.007433328479392,0,0,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark74(-98.3654704610122,-0.9989757752492006,-1.5707963267948961,-1.5707963267948966,-95.42502903826986,0,0,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark74(-98.37244734294794,-0.5564576313463949,-0.8768026884226532,-95.08745524879936,-0.3589028128377961,4.326431775851799,0,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark74(-98.39604867585689,-25.78928739890904,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark74(-98.39651512493099,-0.02269224579959217,-0.8113552593617714,-0.8941437697905277,-1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark74(-98.40988048657736,-3.8106587430475695E-6,-0.9278821557375749,-13.578385065178157,-1.470166652867492,-98.44157786297244,0,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark74(-98.42613803170238,-0.4380526824502602,-1.2658146123721867,-1.5707963267948948,-32.022359347724475,-1350.746244001842,0,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark74(-98.43777879542219,-0.0034087869934550483,-0.03813993158360762,-207.5489367838103,-0.32366908572406317,0,0,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark74(-98.44766122297638,-0.005531588528033273,-0.13825323495166697,-76.55365625096648,-1.1608710863135763,-4.7254319129676494E-11,0,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark74(-98.47353772844477,-0.6924462886269857,-0.7294475257738128,-1.0406078341595495,-58.151112063179596,-7.8898982661566395,0,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark74(-98.4765319836901,-4.6001903262659536E-5,-1.1273293933644812,-1.5707963267948966,-39.21437971644097,0,0,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark74(-98.48876012814216,-0.17537823260571628,-1.212199789434118,-50.096272047917836,0,0,0,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark74(-98.49618053299429,-0.4137876458697627,-1.2913933348231024,-1.3324389990959378,-1.1963112775364664,-176.76807543463786,0,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark74(-98.52653095897064,-1.0900983851266517,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark74(-98.53532654633835,-0.6682439378452847,-0.7023930689214104,-0.7125428204801121,-1.5707963267948966,-20.768534162871752,0,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark74(-98.57386034364903,-0.9994868468723541,-1.2382514180538517,-1.4495456571899403,-1.5698318045702488,0,0,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark74(-98.58340666159656,-0.8130765472391728,-1.3275745170790911,-1.5553689263383288,-1.5707963267948966,-62.50761047044122,0,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark74(-98.58946353754096,0.0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark74(-98.60687129250185,-0.5927775265125304,-0.6029927795482279,-64.3413602456426,-1.5201071455726292,0,0,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark74(-98.63027946812524,-0.051942255020523354,-0.10313841444688299,-370.99473565072066,-0.3024151195753829,-88.26751245310832,0,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark74(-98.63588395456313,-0.17440062985459678,-0.36351783020271294,-0.46291934930538226,-38.59055326438674,0.0,0,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark74(-98.64480858125059,-0.5732839052239967,-1.1849359698539928E-9,-1.570796323129005,1595.0483516429938,0,0,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark74(-98.64766566108918,-0.5271685870168944,-0.5890572252364734,-6.971999641889118,-0.7958854411891358,-0.9205474632580084,0,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark74(-98.65934505872812,-0.03283179809596733,-0.7026380790153404,-1.5707963267948966,78.38044699209442,0,0,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark74(-98.66667440687624,-0.23912608020761902,-0.3936366647847448,-1.0255370218096238,84.5700695908606,0,0,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark74(-98.67329348728722,-0.7400069160979557,-0.7621811520062087,-44.97897339610661,-1.0299177271211148,-40.99892060342046,0,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark74(-98.67703226207304,-1.2252058466324556,-1.4482898141644422,-1.5164589601924279,7.624951058593652,0,0,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark74(-98.67747799102473,-0.6108069645115085,-1.0727097992985422,-1.5707963267948966,-66.04754746933692,0,0,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark74(-98.68261238200088,-0.029586124429131277,-0.03061271884705726,-0.1494829951465143,3.290328732380729,0,0,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark74(-98.69807247770389,-0.7667610864352907,-1.415815342641565,-1.5707963267948948,-1.5707963267948966,-1441.2862553442517,0,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark74(-98.71994385184693,-0.33756171988710915,-0.4727772240131459,-1.1656048822031493,-1.5707963267949197,0.0,0,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark74(-98.72239587148027,-2.2944361666764617E-4,-2.483397999247318E-4,-2.716632349347439E-4,-50.26573715743329,0,0,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark74(-98.72973149327755,-0.9053553914894792,-0.9302359468388839,-1.5707963267948948,20.68164868442876,0,0,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark74(-98.73240278034618,-0.44459584238341954,-0.44459597450689575,-50.10361847552753,0,0,0,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark74(-98.73483604398199,-1.0988911864358308,-1.4190754933196805,-1.423402364087454,-165.82520337503723,0,0,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark74(-98.75783505308918,-3.590053064699607E-13,-6.8551299093553E-8,-1.5707963267948966,0,0,0,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark74(-98.77579846074367,-1.1102230246251565E-16,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark74(-98.77993100188444,-5.9326553351506524E-5,-0.9415219216608852,-1.1069423654807862,67.18899583361907,0,0,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark74(-98.78762396713705,-1.3613770258223181,-1.5171019122087834,-1.5707963267948966,1.540362719013977,0,0,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark74(-98.79768462370308,-7.317472537516499E-5,-1.0962890058309684E-4,-87.96930628771746,0,0,0,0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark74(-98.811874943545,-1.537240324417178,-0.050228133951351624,-6.328098888062483,0,0,0,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark74(-98.81985421392677,-1.3015779739162159,-1.4858580544847961,-1.509145987922005,-1.5707963267948966,-1.734723475976807E-18,0,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark74(-98.82692430755365,-1.5324048107457733,-1.5624033324414937,-1.5707963223031343,-1.5707963267948966,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark74(-98.84208684100702,-5.301218502102436E-11,-0.40454076031269504,-0.4835972809428778,-1.5707963267948966,-26.622499666580033,0,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark74(-98.84757901915013,-0.4710295215418664,-1.0965064978507908,-1.5707963267948966,-20.44826981153117,0,0,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark74(-98.84916216431786,-1.2256041001234277,-1.5707963267948957,-1.5707963267948966,-100.0,0,0,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark74(-98.85422864038303,-0.9817346897730878,-1.5707963267948948,-1.5707963267948966,0.0,0,0,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark74(-98.85886364977915,-0.2331337785149766,-0.821073289322032,-2.029283607408149E-8,-58.859529174304015,0.003157328583363125,0,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark74(-98.86169542263555,-0.03545089216524657,-0.3807447188699501,-1.5707963267948966,-68.35888597555994,0,0,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark74(-98.86796439459336,-6.091710146076861E-4,-0.15056929922892537,-89.16431812548697,-1.3121398384767358,17.019877726150096,0,0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark74(-98.87209728016646,-9.636948326570602E-8,-1.4897887287202944,-117.14246261094925,0,0,0,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark74(-98.88393281309318,-2.220446049250313E-16,-0.07841701217859572,-0.08045937166070838,-32.140870065264096,-100.0,0,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark74(-98.94147103143528,-1.3551332662507727,-1.5707963267948954,-1.5707963267949019,0,0,0,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark74(-9.927804492751417,-0.30763401403945506,-1.3677954676210902,-1.5707963267948966,1.5707963267948966,0,0,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark74(-9.929896371408418,-0.1546227167712948,-0.8051092171121422,-1.5707963267948966,-78.7204499946734,0,0,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark74(-9.93864067848007,-0.4817657267155955,-0.6104294955668992,-0.6607866523873291,-13.640014922117105,-32.728428349760314,0,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark74(99.38704614055746,13.935395322815182,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark74(-9.945708893818693,-0.9219053488623731,-1.5690641937631518,-1.5707963267948966,54.04236110500547,0,0,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark74(-9.992618535142762,-1.1566925431386408,-1.5707963267658689,-1.570796326794371,-1.5707963267948966,0,0,0 ) ;
  }
}
