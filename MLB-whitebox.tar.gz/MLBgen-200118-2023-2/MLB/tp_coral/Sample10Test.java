import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(0,0.0,-0.004570858044759693 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-0.05059136291427979 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-1.5707963267948966 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark10(0.016097312033176384,0.22144145057817705,-1.5707963267931218 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-19.39956723000593 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-2624.1173301651747 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-26.405042516844944 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-2741.383959686059 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-3.1512272143234554 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark10(0,0,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark10(-0.034450656143789615,1.0574916089231794E-6,-0.5572798093794571 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark10(0.0,3.807147493884693E-11,-1.5707963262810856 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark10(0.0,43.33249484887604,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-46.41121373487158 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-51.740325359595964 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-57.177894913535134 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-6.0792188110793575 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark10(0,0,6.299955565795017 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-72.60066274170158 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark10(-0.07366854364691733,-4.440892098500626E-16,-0.30645780320869787 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-84.27830236437744 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-8.766724278604926 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark10(0,0,90.45705151196964 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark10(0,100.0,-1.5707962986578428 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark10(0,10.789941538953059,-0.47615241950035947 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark10(0,1.597778440211897,-1.1458919705848414 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark10(0,1.652078471187934,-0.3048175750792903 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark10(0,16.959832438812107,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark10(0,1.703419542690987E-5,-0.33603551312510327 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark10(0,1.922376320826146,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark10(0,2324.640708679849,-1.4290962694605227 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark10(0,24.191240295826805,-0.06497815785646119 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark10(0,24.378416138739,-0.06447856469094404 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark10(0,2444.317636978896,-1.5707963267948963 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark10(0,3.335691388215899,-0.4903172352081333 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark10(0,35.85761910082604,70.90955247364093 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark10(0,42.60426153566931,-0.09847269104575196 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark10(0,55.816363763912534,95.71002738163443 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark10(0,77.24354582866417,-0.6887776836127273 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark10(0,-78.2008626063552,-0.2812689161649189 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark10(-0.8873331380253049,64.64427283607387,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark10(-0.9691385744529448,0.16741055257979634,-0.2390717696729885 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,0.07258111840415897,-1.5707963267526919 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark10(100.0,1.059390568533547E-7,-0.641285919175356 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark10(100.0,-15.503935397549089,-2.911645755864013 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,3.7086895853936625E-7,-1.5707963267948963 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark10(100.0,6.466729403198467E-17,-1.5707963267948963 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark10(100.0,8.131023701656699E-16,-1.269205515008655 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark10(-1.1102230246251565E-16,73.6589979703993,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark10(-1.1463741657149267,7.105427357601002E-15,-0.010764547310993744 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark10(-1.227474822625261,35.32291575996668,-8.901304925424511E-10 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark10(-13.324332546149776,39.53588607830193,-74.11285018241918 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark10(1.4235446695342866,3.9600008535940425E-4,-0.38639548862321993 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark10(-1.4329812921777474,1.1102230246251565E-16,-0.8044006550588847 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark10(14.583495505238751,0.3444331227308333,-1.5707963267948961 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark10(-1.512219144596418,0.3445375590855035,-0.024673924095253597 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark10(-1538.5634925789172,6.468801873353093,-0.08157449890722512 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940927015,-6.504318075689457E-4,-2.1060763286036108E-13 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935115,3.4067609161668133,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935257,0.17815746420204492,-1.2672870806794445 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935346,1.3322676295501878E-15,-1.1596569434798047 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935348,16.35305153488238,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935348,2.3588056006325497E-14,-0.13636363278499486 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935348,46.560829653251695,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935348,7.804480694870556,-4.371503159461554E-16 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935348,88.29339119999085,-6.123233995736766E-17 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark10(-1.57079079409354,1.517683756446786E-10,-1.5707915810405901 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935453,0.013311651868609648,-3.958228359733565E-12 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935684,3.3963939516906615E-12,-0.18185071314972887 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940936052,1.8256515242076922E-9,-1.5707963267948957 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707908172458314,64.42335155535125,-2.310327455420553E-6 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707911503572665,0.001046006836561521,-0.6697949266964645 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707915879468763,0.7743110865770859,-0.0012670971162297984 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark10(-1.5708156501596227,0.005601617037791594,-1.563297555871719 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark10(-1.5708347316986426,0.0026645626382445255,-1.569807909124425 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark10(-1.5726430587855058,0.06077655460030197,-0.9244771260774471 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark10(-1.5979395719717053,27.710407876314296,-0.006661225241075708 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark10(-1639.1216528238135,0.05249540882092907,-1.4836819989271854 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark10(16.69003623166371,-5.0732155875462865,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark10(-1.8071507834610006,20.63318253602752,-0.025068607253940892 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark10(191.25578577329063,75.32536482972188,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark10(1.9721522630525295E-31,30.67365669026793,-1.627751542747662E-16 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark10(-22.168507166942074,5.909839228315265E-10,-1.5707963267948963 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark10(-2.220446049250313E-16,8.908546557021879,-6.922782003787378E-18 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark10(22.969348461017617,8.881784197001252E-16,-0.9689114179811431 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark10(2.4158453015843406E-13,1.8238966143499145E-8,-1.5668607786981728 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark10(-25.30963320253464,1.5999065817374643,-0.11474505953229519 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark10(-26.258512543195113,66.79902223882218,-2.5899210731097686E-11 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark10(-26.554997271278864,18.73237714518352,-0.0017960816893583254 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark10(-27.046392083663054,0.5166851430797155,-0.03530676817264556 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark10(27.436736592939,93.07434302304017,-81.60077102637555 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark10(-2.8421709430404007E-14,1.6463214086722906,-0.30385317263849626 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark10(29.359383723959724,2.408348937906908,-26.64397269916283 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark10(-32.47245469004716,-26.053266249218666,-95.0051853180957 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark10(33.18843564684668,13.687823134132884,-2.105376623901032E-13 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark10(36.8000272097033,1.5974354046090646E-11,-0.0011604600147690548 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark10(-36.862323495822366,-1.8409745083357336,80.24510583646642 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark10(-37.03650958824265,82.75376449798648,-44.891349310237196 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark10(-42.59668608272187,1.7529510343778714E-7,-0.39570326567304903 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark10(-4.440892098500626E-16,1.60909457301249,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark10(-4.440892098500626E-16,78.32309742386464,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark10(-4.674914855222701,2.1082848833961435E-15,-1.5707963267948963 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark10(-53.45629938281847,1.4210854715202004E-14,-1.2325881245020676 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark10(-5.909106315382871E-126,99.36733705350599,-3.77540061333283E-14 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark10(5.930634526300629,42.278201578800314,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark10(-64.76734489933042,1.0679251211333935E-10,14.432952396842254 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark10(64.88056961244848,89.80241975002471,-8.084948428021036 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark10(-65.9235438927135,-4.736560795196198,23.884821941330458 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark10(-6.661338147750939E-16,1.7421103370396773E-14,-1.5707963267948442 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark10(-6.663837580856054,1.7734206636529488,-0.3272335526252861 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark10(-68.66616470116925,-60.72197720562307,4.440892098500626E-16 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark10(-69.66833881463516,4.476419235288631E-13,-1.4146459051099707 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark10(-7.105427357601002E-14,-90.98529001446967,3.627448932326013E-15 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark10(-73.9288090820625,5.400468604592479E-5,-1.5005861739363953 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark10(74.5266738879336,0.03317862382654451,-1.5707963267383471 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark10(76.48021898389767,1.811978749807594E-6,0.7467656335032918 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark10(-76.84730570693895,0.5496894838414654,-0.2751099065848699 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark10(-7.6997665358846445,0.6314096474779407,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark10(80.43632416253593,48.024153799219945,-0.008877197384931534 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark10(-81.73735217326032,-90.65591875181161,2.1625347733039733E-6 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark10(-8.881784197001252E-16,9.869907949053129,-8.881784194344285E-16 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark10(-91.42019063867195,1.9212208577464647E-12,-1.5707963267948901 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark10(-92.07746052096743,3.0647469132066956,-2.7152165586463843E-12 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark10(92.78103955850185,0.43461683716843885,-0.781404814252842 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark10(-93.50529270701256,-4.493092505585338,78.52288270219239 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark10(-96.81270417633678,-94.34511392973306,-62.859033269218536 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark10(-98.75226807072589,1.1884100613413855E-14,-0.19319387314794662 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark10(-99.43127761437061,221.99918550835278,-5.551115123125783E-17 ) ;
  }
}
