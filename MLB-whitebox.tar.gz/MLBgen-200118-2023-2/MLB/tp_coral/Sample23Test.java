import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(-0.0010903679779558763,6.617444900424355E-24,0.7849819113909107,18.39905666279641 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(-0.0016704380292352078,8.352190146176019E-4,-0.7845629443828307,100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(-0.0032884503361305375,0.0016442251680652657,49.60645598961309,-64.43766565515375 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(-0.003394572008711834,0.001697286004355916,-41.34077779094697,-0.7862468063996282 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(-0.0036624082309517983,0.0018312041154758957,0.04019553699264067,-71.7881388284935 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(-0.004724082031420243,1.3412225037950022E-15,100.0,-6.706112518975011E-16 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(0.005225870564169851,-0.321983829650067,-36.91597417220453,0.1609919148250334 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark23(-0.005828135597099049,-0.011656271170934363,-0.7824840955980318,-63.16043201750424 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark23(-0.006920075549838867,-0.013840151099677709,0.0034600377749194333,14.353049370545095 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark23(0.0,0.8039573761825125,-0.5127242367402126,-0.401969991045922 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark23(0.00844580556834728,1.5860045451098523,-170.86648103223453,-104.56006674267766 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark23(-0.009903540778588349,-0.01980708155717659,0.7903499337867425,0.7953017041760366 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark23(-0.010696684634786452,0.0053186322841569655,0.4016641938603668,0.7827364111110958 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark23(-0.0112582274521138,-0.019050915824359343,-68.57904205240774,-0.7072964085218478 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark23(-0.011949164069868935,-0.023898328139737864,69.15393436847958,0.08676829979475481 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark23(0.01292606660191515,1.592882640034277,-0.006630072616804927,-93.47344769262706 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark23(-0.014562257545445989,0.007281128772722016,0.7926792921701595,59.273330419030835 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark23(-0.015062009806298723,0.007520327596956739,-100.0,-0.003760163798478369 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark23(-0.015160177987312479,-0.030320355974624943,64.89825935289268,7.47686835888742 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark23(-0.015742789370382846,-0.029452725619420216,-100.0,0.014726362809710108 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark23(-0.016114176924372014,-0.03222835384874401,-35.77003904592235,-2.340574879142075 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark23(-0.01725111440134386,0.008625557199028959,-1.1202188247220646,-88.74200568189268 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark23(-0.01726431424413513,0.08812944745806171,-80.84622529342951,-3.987837078516435 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark23(-0.018178403143377153,-0.03635680628675411,10.195664762211493,7.494735911604208 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark23(-0.018209424953626208,0.008081914369363926,-48.92686536613091,-0.004040957184682059 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark23(-0.018224131262337965,1.5029009228061727,-0.7762207303413412,-91.07168745369225 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark23(-0.018378413996859466,0.009189206998429728,0.009266970970250197,-0.7899927668966631 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark23(-0.01849360892794292,-0.022334035380447342,-100.0,0.011167017690223671 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark23(-0.01855430862168994,0.009277154310844964,90.37369127061433,0.7807595862420258 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark23(-0.018801466352468158,0.009400731186857497,87.69541323969224,-0.7419929013006433 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark23(-0.01885705966065051,-0.03252670974806842,-0.775969633567123,15.784415531660194 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark23(0.0190366845384915,-74.94274807951997,-12.726817985176453,-46.1592902708293 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark23(-0.01937301832673182,1.3039355173853624,72.6610225165746,164.23904344979405 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark23(-0.020146678556786313,-0.04029335711355907,-0.7753248241190547,13.104915615962659 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark23(-0.02056714555438116,1.350610674237823,92.81036368832737,21.398264437271987 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark23(-0.021693397285583282,-0.04338679457111031,91.54532725903148,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark23(-0.022791166835447962,-0.03743204648752295,0.0,100.0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark23(-0.025247593075379604,0.012623796537689747,-9.699514761979614,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark23(-0.026606838006271546,0.013303418997070401,7.9062551932715355,-0.006651709498535219 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark23(-0.027303194821563403,-0.05460638964312614,-18.294999420965162,0.8127013582190113 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark23(-0.02752039666357243,0.013484321195644801,-56.96310099413947,-0.0067421605978224 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark23(-0.02779829392365718,-0.05559658784731378,94.29802724373418,1805.7308933713607 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark23(-0.028097278069003112,0.014048638725274967,85.79803719151472,8.128608923048017 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark23(-0.028663957204841373,3.8380855780305845E-17,-94.99427579382697,-0.39777412855198097 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark23(-0.03408407285976847,-0.06495931062235281,68.34524994917241,-0.7529185080862719 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark23(-0.035579134506073244,0.017789567253036598,76.99637098311185,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark23(-0.03572660735005104,-0.07145273231351279,-99.99999967330793,65.31653304272885 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark23(-0.03857323422897302,1.0471841040432306,0.019286617119300024,37.96288813282608 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark23(-0.03874192446793967,0.01937096223396974,-51.43552741474373,-1627.2991747538047 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark23(-0.038867011521396266,-0.010022310176512847,-191.75237664893467,-91.09307829006858 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark23(-0.03917338415161094,-0.07824703700753677,85.18288408402678,-6.660470996778029 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark23(-0.04162806564079809,-0.08324251026602196,100.0,0.041621254591970705 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark23(-0.041960190882491824,0.020980095411287435,0.8063782588386942,0.7749081156918045 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark23(-0.04303779996978199,-0.08607559993956394,0.02151889998489087,-0.7423603634276663 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark23(-0.04322463261979546,-0.0864148031037564,0.8070104797073461,-36.42572051694988 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark23(-0.0436307408156793,-0.08726148011797111,-0.7635827929896086,0.04363074081567042 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark23(-0.04435143362543317,-0.06318066112234297,-0.7632224465847317,-10.387669311814673 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark23(0.04456853519652377,-0.02229566198124779,-0.022284267598261853,100.0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark23(-0.0448756443600421,-0.08975128872008412,0.09919202381145198,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark23(-0.04515182320597314,-0.09028916053319724,40.077159682236214,8.726230741910172 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark23(-0.04573398432269085,-0.09146796864538133,0.8082651555587936,210.29034429968246 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark23(-0.045935621106910414,0.022967810553455204,0.022967810553455207,-54.64897505837858 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark23(-0.046950274531984366,1.4767133548446834,-151.26185822601676,0.04811609989815979 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark23(-0.04707655997401275,0.005426103824427986,-71.0126958281304,53.880738929165155 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark23(-0.0471778926600534,-0.09435578532010679,-0.761809217067422,0.04717789266005339 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark23(0.047756851875690856,1.666230248990201,-76.0767950931337,-14.970220806061938 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark23(-0.04848648261735167,0.0029818848472125126,-76.6906162095146,49.706230562136724 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark23(-0.049105262920384085,-0.09821052584076789,84.48865328774637,57.290511231040384 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark23(-0.05048369121649898,0.003599593644838908,-40.46533086694339,2107.6973573790647 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark23(-0.05059113120582823,-0.10118226241165648,87.32999437813996,99.99999330706632 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark23(0.05094753819440323,-0.614847201356818,204.40104515129323,40.69276866950817 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark23(-0.05147348314306288,-0.05710716428529053,-38.12933620540726,-0.11427727510035202 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark23(-0.05159641272821425,0.024793517210442317,-0.44357456396342454,55.77901499580773 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark23(-0.05360184707301151,-0.012819377391491416,0.02680092353650576,19.879324744740916 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark23(-0.05509413631132107,-0.11018827262264211,99.88353202110326,0.5918746780280505 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark23(-0.055233469965114704,-0.077436797583605,0.3065642393404506,-90.51225171419976 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark23(-0.05535689562229451,-0.1107137912445888,-100.0,100.0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark23(-0.05733256183468345,-2.7755246165141902E-17,19.606240334016615,-0.7853981217131969 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark23(-0.057340034819728436,-0.11468006963945686,-83.95688180450578,-48.838364998964074 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark23(-0.05881702250197295,-0.11733685170041833,-0.7559896521464619,36.48686774374179 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark23(-0.0597376546089143,-0.11947530921782858,0.02986882730445715,0.8451358180063626 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark23(-0.05979035268201148,-0.37084844070561107,0.4920132510067403,0.9708223837502539 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark23(-0.061321558757370574,0.030660779378685277,0.9334010219899783,-11.005852804115854 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark23(-0.06149426365031829,-0.12298852730063642,78.9974549140679,14.085442974060912 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark23(-0.061536790116532014,0.024019080979811203,0.030768395058266007,0.7733886229075426 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark23(-0.06609910380554078,-0.12451325816390772,0.8184477153002186,0.8476547924794021 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark23(-0.06658668144603802,-0.133173362320397,-33.41394487945345,0.8519848445576468 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark23(-0.06721129712932755,0.03360564856466364,100.0,15.570072574633866 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark23(-0.06760627761360373,-0.13521255522720743,0.8192013022042501,62.105587583375666 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark23(-0.06762711138822011,-1.3552527156068805E-20,-96.61000906693529,-0.0010083467894499848 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark23(-0.0679452094868831,-0.06431604753322007,100.0,0.03215802376661003 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark23(-0.07029303342292742,-0.14058606684585478,-56.16286566121481,0.8556911968203755 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark23(-0.07114222636762424,-0.14228445273524842,99.87037927630858,0.31941465427809906 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark23(-0.07189778599923816,-1.1102230246251565E-16,84.2784256212027,1225.8148206153126 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark23(-0.072790367454901,0.00906964540459776,-0.73344360621209,-1768.0074958207524 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark23(-0.07317590920075556,-1.9251010659256107E-4,-0.7127011043718252,8.673617379884035E-19 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark23(-0.07353127485796818,1.3952140301899607,-0.029294657286085504,84.1210300944403 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark23(-0.07379284370150271,-0.012573141701495524,0.8222945852481996,24.297969253744693 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark23(-0.07673986205867675,0.038369864681135256,-14.82168999268574,0.04922349192518001 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark23(0.07783744652230337,0.1556748930446068,-91.00748094108133,-0.8632356099197516 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark23(-0.07882809254801892,0.03941404627400935,-44.92556476534621,-0.805105186534453 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark23(-0.0800847799691416,-0.15887568830378393,0.825440553382019,100.0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark23(-0.08119283582893222,-0.08233597444611883,39.35429679776134,0.04116771900665514 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark23(-0.08165804713839621,0.040829023569197966,-22.8923924885946,-0.020414511784598983 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark23(-0.0818171397513614,-0.16363427950272277,0.0409085698756807,92.16358942263656 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark23(-0.0824791447739714,-0.062119035387107724,0.0412395723869857,0.031059517693553862 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark23(-0.08249530876525801,-0.08538457680863498,-40.79148105094452,65.23073985039252 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark23(-0.0838720254696016,-0.7434573556645034,0.041936355278740844,91.48058737643328 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark23(-0.08464607944379157,0.04232303972189576,0.8277153254380837,-0.02116151986094786 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark23(-0.08524207759626751,0.03534528951993132,23.82546971264929,23.593201492662708 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark23(-0.08606723075804945,-0.16523338331550083,-58.82659217418022,45.58715248287835 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark23(-0.08639634469336543,-0.17279268938673079,-65.71612745033454,-99.69359438929459 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark23(0.087205362454571,1.7452070517040381,0.7417954821701627,52.56283306487181 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark23(-0.08927902170926724,-0.7406213528691267,0.042228657858322416,88.04898825974325 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark23(-0.08936380071255279,-0.17872760142486022,0.8300800637537247,-29.22862417192758 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark23(-0.08962794187093914,-0.17925588374187817,-84.05121654569899,0.8750261052683874 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark23(-0.09078005934335248,-0.18156011868670488,0.04539002967167624,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark23(-0.09079783914518913,0.04539891938708679,-0.7615321958753565,-3.0942731489245716 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark23(-0.09118448057954166,0.045592240289770825,-0.7357555125725325,-0.7594355964488675 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark23(-0.09183987917441239,0.045919939587206166,-57.07351901519282,41.885102548189934 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark23(0.09508238161362165,-0.8156437146271835,-79.30236589538106,0.4078218573135918 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark23(-0.09542073703273161,0.0477103685163658,-0.5904056090798435,-18.022777595050542 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark23(-0.09824754700383576,0.019330998536058436,0.8345219368993662,0.7757326641294191 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark23(-0.09852588543290874,-0.11200330254660303,20.853017170469663,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark23(-0.09874721831343591,-0.1974944366268716,11.007343727519846,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark23(-0.09884797317087946,0.0319984600588068,0.04942398657271046,-0.015999230029403403 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark23(-0.09992748213824093,-0.0038289016399919162,-168.78714064052085,0.05622031504905557 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark23(-0.10073956295032661,0.05036977351068368,0.45889581142443353,-0.025184886737220993 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark23(-0.1008503255199734,-0.049057860810632625,-27.064163463704503,66.5987703209238 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark23(-0.10096040848320853,-0.18802020227358016,90.37863047181317,-0.6913880622606582 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark23(-0.10290716763633287,-0.2058143352726656,100.0,-0.6824909957611155 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark23(-0.10343355518995738,-0.10846242679945789,0.6155918964181427,-84.00973787655465 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark23(-0.10398435226029396,-0.17201820918894262,0.8373903395275943,0.8714072679919196 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark23(-0.10461728566332262,-0.2092345713266452,100.0,93.82793158232593 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark23(-0.10566821582849184,-0.2113364316569837,100.0,-0.024736864620745314 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark23(-0.10573669459395234,-0.21147338918790465,-0.7325298161004721,0.10573669459395232 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark23(-0.10574818100764971,-0.1844286883337285,-0.7325240728936234,-68.70179799512216 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark23(-0.10676039107093516,-0.08583084742499913,0.4629997664447454,-0.7424827396849487 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark23(-0.1069593368557118,-0.21391867371142337,98.202983318355,98.5565150468648 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark23(-0.10752167044738291,0.053405024000618743,-0.7316373281737568,-0.8121006753977577 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark23(0.10764242023212796,1.6600589049586738,-101.23155737532728,-10.252301918078917 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark23(-0.10834416609279085,0.054172083046395425,0,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark23(-0.10902416618890573,-0.13283154677895337,-73.73498785545905,0.07113712933728425 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark23(-0.11064438821883293,-0.14428282902651418,0.05532219410941647,-0.7132567488841912 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark23(-0.11135034019374149,-0.2206407441013164,-33.660199176100676,88.35244901712669 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark23(-0.11268086503624908,0.05634043251812452,0.06440694171034786,-0.8135683796565106 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark23(-0.1143897086888815,0.055468509204932605,0.842593017741889,-62.35363725721514 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark23(-0.11511092166364256,-0.11925128850278524,100.0,95.30085988186498 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark23(-0.11575169107991412,-0.2315033810742604,0.14013552548566433,-33.03375054782062 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark23(-0.11829766621645944,-0.11561439987546795,-0.7262493302892186,100.0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark23(-0.11977872799286804,-0.23955745598573597,-0.7255087994010143,14.031225046842508 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark23(-0.11980631898675362,0.05990315037759465,0.05990315949337681,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark23(-0.11991362044475617,0.059951392814720485,1.630737717915892,-0.029975694859111526 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark23(-0.12022591608560243,-0.10353065386353477,0.8353487056212501,16.154556410413996 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark23(0.12249242820118782,-0.6309444186413954,-0.5881293597244284,0.3135638792645309 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark23(0.12255232625736845,-0.8466743265261324,-0.1489242368146655,100.0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark23(-0.12306818439260475,-0.24549347485307896,0.07128337925439271,-0.6626514259709088 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark23(-0.12404845481636533,0.04943728395146761,-0.72114605544969,98.27364114411077 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark23(-0.12529726293726196,-0.1602640094651019,-17.75071680749098,0.08013200473247273 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark23(-0.12874371396089185,-0.12796955366315943,75.13920006435004,3.709862680132332 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark23(-0.12887559990484654,-0.2577508668151017,0.04667950400223577,0.44055141444364204 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark23(-0.12892354603905987,-0.2578470657061903,-37.814512888994244,0.12892353285309513 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark23(-0.12993266821802746,-0.2595930984092365,0.850364497506462,-0.3605955003841389 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark23(-0.13029269642524124,0.03378357629856932,-0.7196302655433537,-0.01689178814928466 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark23(-0.13223107433505002,0.058829544128251456,-0.931895514076716,-0.814812935461574 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark23(-0.1335617306190402,-0.2658536989408853,0.8521790287069684,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark23(-0.13431484263370208,-0.26862968526740405,37.51693445776483,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark23(-0.13482342565889482,-0.26661493927539576,100.0,-0.5408038099687502 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark23(-0.13500036058005424,-0.2699776189709118,-178.2138181234801,-0.6274073809762597 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark23(-0.13551797322832648,-0.27103594645665274,-80.72116678705245,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark23(-0.13587962623127647,-0.2717592524625525,-37.487874570807605,0.13587962623127625 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark23(-0.136314229370272,-0.27262845874054387,100.0,80.24693805804047 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark23(-0.1365349078445326,-0.27306981568906513,-53.71536680853833,-33.37189942285756 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark23(-0.13834113888437902,-0.004362104085380708,0.8545687328396377,-1.3771715945236012 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark23(-0.13865702683036152,0.06932851341518065,86.823763419768,-2107.41255758515 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark23(-0.13868561810547628,-0.2740734470319608,34.26765781323613,-23.133696233518034 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark23(-0.1395823873965681,-0.07003487541430552,-9.25457001956698,0.03501743770346435 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark23(-0.13992360324085998,-0.054891062147887644,-48.30547642077359,0.8128436944713922 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark23(-0.13999230345669647,-0.20794797145738145,-71.43601928108043,-0.3482499820329211 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark23(-0.14050348580923322,0.06365788456559378,10.220113241887166,0.0011579447942910437 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark23(-0.14104313153197276,-0.2820862621411458,-32.75788787009764,-0.4358842971803177 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark23(-0.1419914504835054,-0.00782286878898586,95.24116460089343,0.00391143439449293 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark23(-0.1422153797338095,-0.2844307594676189,-0.3858559116137471,-50.56904850489648 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark23(-0.1424554577189004,-0.28483460290359364,-0.7141704345379981,0.644477806170083 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark23(-0.14270422103541258,-0.2854084420708247,37.6125980759241,-0.6426939423620359 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark23(-0.14508226470153335,0.04228686837334728,41.91110508978553,-0.021143434186673637 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark23(-0.14532810810405217,-0.2906562162081041,22.544878521090066,55.091168487677464 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark23(-0.14539490654968928,-0.2907615782306974,-2.2801374714205376,-0.6400173742820995 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark23(-0.14680535310811096,0.07340267655405547,-97.41791653175005,-60.97521112743118 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark23(-0.14699135599325852,-0.293982711986517,-6.067479851878943E-12,0.6943196810553331 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark23(-0.14710755110107337,0.07355377555053622,0.07355377555053669,94.6365481173296 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark23(-0.14809937126181286,6.938893903907228E-18,-0.7113484777665418,0.03390695240408356 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark23(-0.1482511538541381,-0.2965023077079287,-0.7112725864703531,0.4963421740536223 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark23(-0.14876547524633188,0.07438273762316533,0.07438273762316594,-0.8223680002281903 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark23(-0.14992709284009176,0.07496354642004577,2253.38474901599,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark23(-0.1519345171789157,-0.30386903435783136,0.6096446996209703,60.13037561176168 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark23(-0.1520728652670773,-0.3041457302258799,-46.16955563515357,2022.7632920685437 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark23(-0.1522906223347213,0.07614531116736017,0.861543474564809,100.0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark23(-0.15246777319592042,-0.10863880139821754,0.6767593619992307,-25.779934865764705 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark23(-0.153710902528859,-0.30742180505771777,-98.99003492447903,0.01583780584456656 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark23(-0.15414629350113818,0.05542337839638933,-74.70161575117595,0.7576864741992537 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark23(-0.15483594936196324,1.2525392445616836,-13.660458669680208,166.15215104131033 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark23(-0.1551474275855799,0.007086520544241637,-0.7078244496046583,0.7818549031253276 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark23(0.15551994277379536,1.8818310076098166,0.3433879313571463,98.0192715514901 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark23(-0.1556346689682491,-0.3112512598218983,36.98377802625434,-0.08934298230174723 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark23(-0.1568307714695356,-0.31366119364100586,-0.7069827776626806,16.916972416372992 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark23(-0.15860127057811435,0.07930063528866396,-0.7060975281083911,-0.03965031764452509 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark23(-0.1609611221891282,0.08048056109456403,0.0804805610945641,-45.076493484381416 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark23(-0.16240221664674387,1.2459918913925356,-100.0,79.49221722949764 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark23(-0.16259866875164386,1.0706541805591687,-156.02014852558068,100.0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark23(-0.16263952933203396,-0.3252790586640675,0,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark23(-0.1635757913855888,-0.03657633133824767,-19.852436403210557,90.13936043793693 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark23(-0.16490859217905768,-6.886643776679339E-16,-0.621057855430066,0.0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark23(-0.16516566101266006,-0.33033132202532,-17.616405775297128,1907.1413788304837 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark23(-0.1664167249908664,-0.3290091246104074,60.558437330448776,0.39234928423353166 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark23(-0.1680908567257845,-0.33618171345156894,0.05875321657295196,0.16790871551694964 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark23(-0.16815120693890157,-0.33629768092923273,-0.7013225599279975,100.0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark23(-0.16906017736551604,-0.3005839492166513,35.41328789127003,0.0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark23(-0.16980923490181477,-0.3141592688145822,-100.0,44.102953783950525 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark23(0.16995485851869585,1.5908318516580455,-0.8703755926567962,-100.0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark23(-0.17019015133173543,-0.08612611796097625,91.36429599691607,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark23(-0.17110354553305937,-0.3422070910661187,-0.6998463906309186,5.967872614715957 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark23(-0.17226440304681695,-0.22425594111488234,0.6267630777863857,2011.1759650132117 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark23(-0.17247235733933644,0.0862361786696682,-0.1231369764828365,0.16572726341531294 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark23(-0.17277059187112373,-0.3305972528177452,53.88525790877344,-0.6200995369885758 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark23(-0.17280950418909197,0.0,-0.648871662055995,0.21320094922215105 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark23(-0.17458229727204141,-0.22391241428122366,-0.6981070147614297,-0.6734419562568364 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark23(-0.17534783118861874,-0.08277734594014324,22.663560979517186,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark23(-0.17633343792561745,0.08323310550305599,100.0,90.35139126465775 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark23(-0.17765868115770186,0.08882934057885077,0.0882595914697519,-0.04441467028942539 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark23(-0.1779517150744599,0.036598136838357,55.88955222806551,27.802309615176277 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark23(-0.17872952939712528,-0.17011574926412454,0.08936476469856264,0.08505787463206228 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark23(-0.17885389288226905,-0.34421432534150337,-47.157073784248084,-13.72893580511457 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark23(-0.17926700991572858,-0.3351147161426357,-3.4032995118824303,-41.36480501468214 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark23(-0.17935941956480883,-0.2598674377952791,-0.9300565931421404,-33.11301835124752 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark23(-0.17950190534632754,-0.351355562580217,0.005378138861235072,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark23(-0.18106930183709571,0.021544372574162765,-0.6948635124789007,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark23(-0.18107390209468177,-0.36214663185056617,96.10082393167745,-100.0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark23(-0.18183688501321707,-0.3636737700263367,0.04897484921735461,51.86988943490647 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark23(-0.18225488894803332,-0.3645097778960663,-0.6942707189234307,100.0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark23(-0.1823430613424002,0.049799764747731956,75.65303247573772,100.0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark23(-0.18329429694416677,-0.3665885938883335,0.09164714847208322,-87.83925909989725 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark23(-0.18602801357297372,-0.37205602714248354,0.09301421034430216,-0.5993701498262065 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark23(-0.18615579198652252,0.09307789599303402,-0.6923202674041871,212.94592614416925 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark23(-0.18625726370612605,-0.1539106279720248,-0.6922695315443853,-11.69899665660595 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark23(-0.1873532748100344,-0.20166257619999428,100.0,0.10083128809999715 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark23(-0.1881333780971508,-0.3762667561943014,-9.79543158856806,95.46493296961759 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark23(-0.1894782744445779,1.1918397779057406,31.820153698312094,-68.92552107375316 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark23(-0.19040278863129867,1.1899907495322992,0.2063056392787167,-41.9801684216353 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark23(-0.19150048550634913,-0.33474465059668246,-59.0396997143193,-70.7031990340857 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark23(-0.19161982694830293,1.1822639827642085,25.25429345879214,71.67816623213487 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark23(-0.19232363808789,-0.38360698497155216,-0.6892495937565286,-34.73877245978379 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark23(-0.19268629625048028,-0.38537259250096034,-75.44445150697375,-46.073400544007676 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark23(-0.19334395305119537,-0.2066701676803998,0.1467765132801162,-0.4944653172029403 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark23(-0.19394053600333705,-0.2968816485766738,-21.04304510029617,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark23(-0.19415139543439647,0.09707569771719723,0.24287535763869056,0.7368603145388498 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark23(-0.19458548296135292,-0.3768886390904564,-0.6881054219167718,0.9738424829426765 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark23(-0.1951820794671722,-0.3903630105275219,-66.64775149334011,0.0800318722025833 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark23(-0.1957239895372345,-0.34959470484364386,0.8575096767550126,-0.6106008109756264 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark23(-0.19583535140579272,0.09791762390403713,0.8833158391003446,12.53714275050378 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark23(-0.1974159506476032,-0.33196774257812933,-68.16475995435286,83.87717692447099 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark23(-0.1976366821379343,-0.3952733642758659,100.0,-100.0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark23(-0.1976907819739403,-0.060707001991818686,-0.060411691104497706,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark23(-0.19813593792185308,-0.3962718758437061,-0.6863301944365219,77.9506503089866 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark23(-0.19852571719080175,-0.3969050306436344,7.024720668520266,0.19868178242066376 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark23(-0.20044109534287147,-0.2185056483184801,-0.6851776157260125,-31.080257945745362 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark23(-0.2017505251728068,0.018753757281748662,-0.8426646486417948,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark23(-0.20364626634234118,0.10182313317116615,0.10182313317117059,0.7344865968118628 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark23(-0.20482908494568447,0.027651380648912927,18.13687247474252,-95.09451740701995 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark23(-0.20517367018433785,0.06911862886648369,0.10258683509216893,-0.034559314433241846 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark23(-0.20618590574798767,-0.4123718114959753,0.10309295287399384,0.991584069145436 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark23(-0.20618894114904987,-0.38505877692305307,0.10309447057452481,0.19252938846152653 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark23(-0.20748565732493318,-0.6539264638375513,-19.79730808502795,1.8864721520611605 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark23(-0.20778700377022707,-0.09747320089219469,0.8892916652825618,52.22419355812647 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark23(-0.20829291381832643,-0.18052648966330942,0.11324028553140009,-100.0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark23(-0.20986978484149493,-0.19985123487982737,-100.0,-18.203669425611352 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark23(-0.21013075188126618,-0.33217257495992314,0.8904635393380813,-0.6193118759174867 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark23(-0.21093638458960243,-0.4065006506209449,0.10546819229480132,-77.62335950248924 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark23(-0.2112210660928467,0.10561053304642332,-100.0,100.0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark23(-0.21379122526934102,-0.4268747932000435,100.0,-0.5719607667974265 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark23(-0.216177777571263,-0.4302710312994398,-0.6768832248981458,1.0005336790471682 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark23(-0.21662255075808123,-0.4332451015161623,-0.262398868329644,4.508975892266648 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark23(-0.21684899599051344,1.0635621578125916,0.11165174234731046,100.0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark23(-0.2169558255856675,1.0626453323131606,105.4295075306471,100.0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark23(-0.21717518765187036,0.10858759382593228,-74.40388780180751,0.7311043664844822 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark23(-0.21823664948711682,-0.14524478360983686,0.10911832474355841,0.0726223918049184 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark23(-0.21854671832551975,-0.18567733633150502,88.44046746536016,-0.24670139589842405 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark23(-0.21864572146057307,-0.4255452293592476,0.8947210241277348,91.29867127026472 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark23(-0.2194409771749418,-0.43888195434988353,-0.023192330473163603,-56.68433186869268 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark23(0.220897452735491,-0.11088157268704667,-0.8958468897651937,-68.31873980362461 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark23(-0.22361250385608816,-0.050668955280158856,0.8890709517958986,0.09679647370175815 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark23(-0.22443913907217272,-0.027435594304273336,34.75245181808457,-0.7115345034319818 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark23(-0.22603323459272096,-0.016660214512403515,-152.86538125533235,41.68277165104982 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark23(-0.22659979755585366,-0.45068785963709396,-4.931960243554777,20.95307063418916 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark23(-0.2267705858901543,0.11338529294507707,0.7058535636372464,1.874087056510934 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark23(-0.22679118709476492,0.08413946831455033,0.6368427260322138,11.894787869690749 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark23(-0.2278892016603552,-0.36286458882421574,-0.6714535625672724,-53.70727082463675 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark23(-0.22953262670466962,-0.17134959692829077,0.7045856879491046,60.64741800931319 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark23(-0.2302370547634432,0.11511852738172158,0.8869257742713614,55.95693944255723 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark23(0.2315260761907648,-0.1176934005989028,-37.79793417879077,-96.32211849163514 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark23(-0.23202827357980915,0.11601413678990369,46.69082212779644,-0.8434052317924001 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark23(-0.23206637585433204,0.11603318792716599,100.0,46.009068345541124 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark23(-0.23340108272153093,-0.4493606622764406,-47.79270850080509,-94.80842790868395 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark23(-0.2334496240402914,-0.46689924808058025,-0.6686733513773025,1.0188477874377384 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark23(-0.23388166939782162,-0.4677633387956429,-0.14236241714153308,45.68401542271596 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark23(-0.23418804250883807,-0.46837608501767597,87.36728739588526,-61.918354196852384 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark23(-0.23419556003753597,-0.46766977352410777,-0.6683003833786803,78.84775398910882 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark23(-0.2341974804137248,-0.17662606112582668,0.3776757209382013,100.0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark23(-0.23488760178982712,-0.28968912634602473,-0.6663879512250204,6.615646026412892 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark23(-0.23513632058246348,-0.4690804812687606,0.11756816029123174,61.37694368325612 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark23(-0.23515775800868668,-0.47031551601737326,0.11757887900434334,-33.017956319778214 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark23(-0.23669785259455575,-0.47339570518911145,-0.47848688025620845,-40.36614896065987 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark23(-0.2381193090610115,-0.16839647851580045,-23.364517252602067,0.8695964026553485 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark23(-0.23841494943781383,-0.2961848343802989,-0.6661906886785411,11.46698074627934 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark23(-0.23853812142933162,-0.42858546994508145,21.277126097299412,-73.14548216476663 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark23(-0.23975282629286998,-0.47950565258573985,-13.468584541504555,-38.76381673737801 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark23(-0.24016047870249016,-0.46183265204452784,0.8963918159468509,64.82380495851528 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark23(-0.24061167816217113,-0.1914551070685866,0.12030583908108594,-89.58726765572729 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark23(-0.24067574361114621,1.0811670334913583,83.70757984483383,-100.0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark23(-0.24174947129597774,-0.2949430254451175,0.12087473564799023,-20.0490586442785 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark23(0.24281754965209784,-0.15696443673869187,129.46983930343146,15.706425800083466 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark23(-0.2433970818160689,-0.22550795195128823,100.0,-56.657888924014 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark23(-0.24433488317197494,0.09633121487658039,0.12216744158598747,53.74414329659454 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark23(-0.2447265137169492,-0.1012503967930296,100.0,-60.29686066726419 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark23(-0.24548643552172128,-0.2627510746296982,100.0,65.4290936093199 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark23(-0.2468081665062256,-0.49361633301245117,16.090486628803482,-100.0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark23(0.2468909800614773,2.0645673587655753,41.09266238308169,-0.2468849199379669 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark23(-0.24710671550868185,-0.49421256959707327,0.12355316509338021,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark23(-0.24729992609454624,-0.1837626008242739,-0.6617482003501751,1533.6184657744693 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark23(-0.24799543348567038,-0.43235807035098117,99.994622310416,0.21618889626560378 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark23(-0.24844134811533536,-0.3103459089174678,9.02208409317214,99.7796201727809 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark23(-0.24870098158522547,-0.04091772901240728,0.49001952618624967,85.66438172518383 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark23(-0.2487555503625538,-0.4409123464931093,104.79649751856451,-90.6782429495173 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark23(-0.24878696219695576,0.28109136115816136,-0.45886716103478875,68.9883072002759 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark23(-0.24951537472770027,-0.4990307494554005,-68.23248631467989,-14.325974800088472 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark23(-0.25089785888156846,1.062165799913609,100.0,100.0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark23(-0.2520904486380309,-0.5041808970420808,-0.6593529391925539,21.10400718484737 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark23(-0.2528206676302478,-0.19174002147813285,0.7674066893712677,29.043752471398523 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark23(-0.2531263736542926,-0.44558396117592913,-0.6588349765703012,62.93107584923419 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark23(-0.2534340568340583,0.023379723368731065,-0.658543698060659,-2.0823570702595418 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark23(-0.25378146743818586,0.5742548187192142,-0.03372200682091875,30.375054441142403 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark23(-0.2538893625431722,-0.5077787250863443,83.76685362659684,67.45090860950906 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark23(-0.25441111386544674,1.061974099064002,-1.4636693791838358,99.99999998285949 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark23(0.25555662544325186,2.0800761455932686,0.17794654157113743,-100.0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark23(-0.2576385987317947,-0.5152771974635466,-0.656578864031551,35.63084524567724 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark23(-0.2577283610910587,1.055339604612779,0.12886418054552934,84.29517452754143 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark23(-0.25806690057294235,-0.5161338011458844,100.0,-100.0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark23(-0.2599847281928842,-0.14204772254846898,41.975398214174234,99.99997441881412 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark23(-0.26073414941723044,-0.5212435543932338,-0.6092490859739959,-1.3101745495982797 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark23(-0.26250977432823996,0.13125368758366615,20.606810425810234,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark23(-0.26296016887950135,-0.5259199981882057,0.13148008443975068,21.72423270822175 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark23(-0.2634377934549552,0.13171889669870943,-69.43295573493891,42.769729305636936 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark23(-0.26411334857720714,-0.36740028459328333,-33.11305101407369,57.30047093710983 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark23(-0.267499518454654,-0.008049249901599831,-4.495072894650488,0.0040246249507999154 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark23(-0.26752247169187005,0.13376123584593413,-62.30061297666652,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark23(-0.26803514817964924,-0.5360702963592984,81.083222057049,-82.09065908592964 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark23(-0.268460840544094,0.0,-97.78205348556247,-4.154825158089077 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark23(-0.2687459431933923,0.011506458114830087,-55.56518861089058,-4.923375133268496 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark23(-0.26879764322441113,-0.2913329688525612,-28.744948547151967,-13.913879577402469 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark23(-0.2694615501061443,-0.5277148266239959,0.9201289384505205,0.32533369417218816 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark23(-0.27002981490668976,-0.5400596298133792,-0.3693770377515122,63.26980067999625 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark23(-0.27014402813371347,-0.5402880559469398,-0.22973619148789612,-53.757643519594936 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark23(-0.2701455593117285,0.13507221640209252,0.13507277965586426,-0.8529323151334568 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark23(-0.2716189839427992,-0.5165875079562989,0.9212076553688479,0.25829375397814947 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark23(-0.27168911229005266,-0.5433782245801052,44.51490112745827,-1586.9467497264259 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark23(-0.27177134562486777,0.13588567281243374,-203.4501065343943,-0.8533374283044391 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark23(-0.27246222703795875,-0.0881386848871652,-173.79777234053597,-99.99999999977246 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark23(-0.2728160572978878,-0.34711980122136044,-53.657021020172984,0.16503698659650354 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark23(-0.27305553458142573,-0.6128442756425079,48.87110413304261,-2.009256460211388 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark23(-0.27526814524017446,-0.5025695121365867,-23.0595671222882,0.2512847560682933 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark23(-0.2759707319698089,-0.5406544890322958,0.13798536598496122,99.99999999999993 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark23(-0.27711365684508094,0.02016171040765863,100.0,-0.010080855203829316 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark23(-0.2774246479184352,-0.5103877575927545,8.80804117002955,100.0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark23(-0.2793351340606969,0.13302361501343293,0.9250657304277967,-54.24387513455312 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark23(-0.27933579949497245,0.1396678997474862,-0.6457302636499619,-40.0427482740174 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark23(-0.2800412852245733,0.14002064261228642,32.015759102099885,9.919605943057359 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark23(-0.28037295327561185,-0.5607459065512236,0.9255846400352541,100.0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark23(-0.2804217768006022,-0.5608435536012043,78.95450881983358,-9.28140117577787 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark23(-0.28152927696599683,0.7066614149683196,99.99717338295095,-63.1854278161577 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark23(-0.281805708799044,-0.5636114175980874,0.140902854399522,0.28180570879904365 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark23(-0.28253121592212516,-0.5650624318442494,60.15004186302768,1.067929379319573 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark23(-0.2832244348055893,-0.18512376392326452,0.7130996454771137,-0.692836281435816 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark23(-0.2833330756450648,-0.5666661251465639,8.781044879605965,75.08018316948093 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark23(-0.28381938798905954,-0.4161375247017225,0.9273078573919781,-0.577329401046587 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark23(-0.28394624102718063,-0.5588446060849864,0.9273712839110386,-48.41576648235891 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark23(-0.28406553309098,-0.5580255044883149,0.9274309299429383,0.27901275224415745 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark23(-0.28423667094047583,-0.4394606713774074,-91.58608684918305,-0.5656678277087446 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark23(-0.28424654545471434,-0.03765971569135351,36.519182397095456,0.01882985784567678 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark23(-0.28451633537790505,-0.20473429095041995,0.14225816768895252,0.8877653088726583 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark23(-0.28873333481257335,-0.5774666696251466,0.929764830803735,0.27960078906019203 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark23(-0.2902252375168333,-0.5099556744117668,-0.6402855446390316,1.0403760006033316 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark23(-0.2915307601318574,-0.5830615202637146,0.649857487448904,47.362138385008286 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark23(-0.2915807845404448,0.0125210723322882,0.62737959598603,162.59189151265412 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark23(-0.29203799702987077,0.13645371986480725,85.03972431678527,-0.06822685993240363 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark23(-0.29247260752240006,-0.5848678174841202,0.6064086523507964,-100.0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark23(-0.2930733929727473,0.4415704394111224,0.012141106503698434,-8.718295818513084 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark23(-0.29471453111161855,-0.5433615642801325,0.39688984844768715,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark23(-0.295094181378025,-0.5901883627560497,0.14754709068901256,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark23(-0.29569077109953307,0.06280292234076576,0.3446236042492429,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark23(-0.2966054316871225,-0.4008003407390591,-0.6226956858282453,-90.87035597894499 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark23(-0.29789635530588754,-0.5414649345638547,0.14894817765294377,-16.923351337773106 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark23(-0.2982303563586756,-0.5964607127173509,-0.6362829852181101,96.9458324053261 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark23(0.2982461242753856,-0.9345212255351418,100.0,0.4672606127675709 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark23(-0.29830071209040293,-0.5966014241807756,-13.065431913154647,0.2983007120903878 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark23(-0.29867985508971795,-0.5973579649666078,88.45821319893317,-21.69799658220474 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark23(-0.2991107468684655,-0.556815062874924,0.14955537343423275,11.210667062734773 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark23(-0.29961745110658244,-0.5980976293875486,-94.63626908829724,0.2990488146937743 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark23(-0.3010847633195017,0.12014493281017313,3.776143686126571,-52.273818806280715 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark23(-0.3014869276809079,0.9677743121069154,-0.05390403191993458,78.05593124149844 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark23(-0.3023212180029695,0.15116060900148454,0.7497858990374591,-76.15085242174904 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark23(-0.302535649679413,-0.3877496834425783,0.3439420790737521,0.9792730051187455 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark23(-0.303254238229311,-0.6065084762293286,0.9370252825121037,0.743418699149569 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark23(-0.303407727442561,-0.6068153529739855,89.33796011193944,0.30340767648699274 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark23(-0.30400827841370237,-0.33655395381344744,0.15200413920685119,0.9536751403041719 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark23(0.30421414325525864,-0.16360092204758223,-47.269707047328374,59.7247894836714 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark23(-0.30527116750909,0.09847459664316993,-100.0,0.11784999023912324 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark23(-0.3055822983595492,-0.5413231226804197,77.6095170070131,99.99999999999999 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark23(-0.3056549692285929,0.1193150034645076,0.9382256480117448,-30.91549997435409 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark23(-0.30623515172518334,-0.3155302481518387,0.15311757586259167,-0.1524761995575403 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark23(-0.30623749953475415,0.11898726930103834,0.5722620148825871,-0.8448917980479674 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark23(-0.30642810415792643,-0.47493685846718436,0.15321405207896321,39.33114371859478 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark23(-0.3066384223987909,-0.5640646985331852,0.9387173745968437,-71.151844700636 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark23(-0.30668076055833665,0.1533403802791682,0.9387385436766166,-1.4892222780360527 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark23(-0.3071543065237871,-0.6143086130475739,-0.6318210101355547,-0.47824385687366133 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark23(-0.3075470218375319,-0.5024270980972081,-0.5519096481952892,17.971653191307116 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark23(-0.30777323439718,-0.6103717646044756,0.9379911045485678,0.3051858823022378 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark23(-0.30792982972247984,-0.5208166924454355,-82.74428897900381,-19.723343353221708 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark23(-0.30895231176235344,-0.5230623336678024,0.939874319278625,21.46728169515495 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark23(-0.30939840943879093,-0.4994293138069503,-6.058898142468053,-63.48321870611842 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark23(-0.30985164063482673,-1.3881379728070227E-17,-34.869389728958275,-0.7811479003292946 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark23(-0.31080841940817333,-0.6216152690986824,-55.575952313087726,0.47731344267355824 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark23(-0.31087495961980494,-0.6217499192396098,1.1843290503685593,-75.60868247566532 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark23(-0.3109759458481996,-0.6096541732948255,-5.40480707731091,1.090225250044861 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark23(-0.311890706126636,-0.623745784004044,-0.6294528103341303,-24.039610660179903 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark23(-0.31207943127131016,-0.012131564375646636,0.156039715635655,-46.41062370228187 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark23(-0.31337641976911157,0.940758237482354,-0.6291548606142573,23.877005989533146 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark23(-0.31415330644980904,-0.6282843849114421,-0.6283215101725438,-79.91434985808735 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark23(-0.31415926345423856,0.09838332397396345,0.578007962401315,36.895114501885274 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark23(-0.31415926535840555,-0.010127193954772906,-100.0,122.42910094049807 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653589509,-0.6283185307179009,75.94981811017887,-100.0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark23(-0.31415926535897754,-0.47168201155112144,-41.92256815254923,-31.792042481852633 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653589789,-0.4842678027013623,-7.27034745187396,-1997.381510066085 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653589811,-0.21962535680976103,100.0,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark23(-0.31415926535898997,-0.6271489167431146,-0.37043817193075623,2067.804518639608 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark23(-0.31415926535900596,-0.6283185307177597,100.0,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653590579,-0.6283185307179192,0.15707963267952896,100.0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653598838,-0.6027829592126542,0.9424777960773902,-100.0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653607105,-0.6283185307169665,-0.628318530717093,100.0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark23(-0.314439329065804,-0.4253293061789032,-2.0052681686840805,-5.114968916923518 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark23(-0.31481038865019156,-0.37019713971284673,100.0,-5.4050016524223725 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark23(-0.31514650177669057,-0.6187126734028536,0.9429714142857935,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark23(-0.3155430898388362,-0.5855581101770836,0.9431697083168664,1.0777645483310545 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark23(-0.31602340614305136,0.15801163427223394,-0.20597322215936675,-0.07900581713611698 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark23(-0.31736024440147254,-0.6239073265834381,0.5803461860594548,-81.3700837909641 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark23(-0.3180736122725008,0.07910678327995024,-75.86357782446169,0.6765212706053896 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark23(-0.32116917033245573,-0.6248135782312203,0.16058458516622787,0.3124067891156102 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark23(-0.3219944399816135,0.9133057925505823,-138.21826042295473,-19.804823142532964 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark23(-0.32300299854078235,0.12077659918472364,-88.47967445565216,0.741716308649466 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark23(-0.3235052201844531,-0.620357046820132,-0.6236455533052218,58.32847615316129 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark23(-0.3236248051347541,-0.6043797259249829,-32.628997959447425,0.3021898629624914 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark23(0.32420407728310763,2.2191566743130897,-100.0,30.306349631891145 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark23(-0.3248346229963645,-0.6184822695224705,16.54681121466691,88.08299980481128 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark23(-0.32554989041342897,-0.3517563235342775,-83.70192791512687,0.17587816176713877 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark23(-0.3258905799491236,-0.4910984004394696,0.9483434533720101,1.030947363617183 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark23(-0.3262831694287,-0.5471090813634335,-0.5759448951042215,-6.014750216773336 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark23(-0.32645835122847666,-0.40530959153136736,0.4291570627765886,51.21213379321824 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark23(-0.32650348310303134,-0.616205929576569,0.16325174155151567,-39.015950593600856 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark23(-0.3276398089922126,0.14445695276478776,-0.397885711821983,35.32677520698676 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark23(-0.32812486467903756,-0.621335731057929,89.96439630189185,100.0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark23(-0.3281520937522221,-0.5425354480264494,113.4748610291957,-55.45815205343765 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark23(0.32869344824419755,-0.16671351092402706,-22.149351366539346,-100.0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark23(-0.32933403822704405,0.164667019113522,0.01961738822648673,-0.3928774878970622 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark23(-0.32963494548563044,-0.05086156280447225,65.67398935554151,-0.7599673656394674 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark23(-0.32970044427077205,0.16485022213538558,-1.0259942412242768,1941.2719465188334 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark23(-0.3297472682808936,-0.6203034250793813,-0.6205245292570014,1.095549875937139 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark23(0.3300937911851969,2.028647526113291,-0.6236040110799437,-57.412370032150534 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark23(-0.3301050802475636,-0.5190679949626151,-88.95114447186397,92.66522367900195 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark23(-0.333725940340694,-0.5433267602878502,34.39564407248922,-0.5137347832535237 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark23(-0.333794063290048,-0.6185011317524238,-28.841393323772053,5.357411333031664 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark23(-0.3360325565062954,0.16801627825314766,-97.6609287685232,-20.503500080253048 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark23(-0.33652649318510347,0.16826324659255154,-100.0,1954.4004303015486 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark23(0.33666327834671234,0.6733265566934248,100.0,0.44873488505073583 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark23(-0.3380173011163734,0.16900865055818667,100.0,-0.8699024886765416 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark23(-0.338381790800365,0.16919089540018234,-46.13939694853541,100.0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark23(-0.33846293748951695,0.16923146873515457,100.0,100.0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark23(-0.33941344874448565,-0.6781681947220938,99.85983757516016,73.09537808192412 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark23(-0.34041303153361335,-0.008765421673672669,-0.6151916476306416,0.004382710836836334 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark23(-0.3412366581267214,-0.5824730309120356,81.93604777626157,20.979445152333998 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark23(-0.3430280917427403,-0.609201503196635,0.4911684682354327,37.07162853634598 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark23(-0.34404633909911575,-0.33649674739882557,-0.6133749938478896,-58.77233595088247 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark23(-0.3444913376443693,-0.6124930143217265,-0.6131524945752636,67.00046023374144 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark23(0.3444961541373803,1.4575289328706076,56.31939587397692,-1.5141626290708525 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark23(-0.34517088501771886,0.17257148115958726,0.17258544250885943,-19.41670629312415 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark23(-0.3451920483067843,-0.032817973777098934,7.0547036393674185,48.904391780134326 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark23(-0.345890328295698,-0.5995848650296114,-0.6124529992495993,-98.75755008439764 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark23(-0.34640538339530186,-0.15753660459784485,-0.6121954716997974,0.07876830229892241 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark23(-0.34646969132442756,-0.4419497086492902,-0.13054315307856046,-39.09887183368655 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark23(-0.34681067590221804,0.15012529571653677,-0.19539474612805205,-0.7604076376505621 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark23(-0.34694882600688315,-0.13871585292102084,0.6467057771433566,-0.018479694471929854 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark23(0.3476667147115178,6.081120558739604,24.464694242615224,25.23355602805089 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark23(-0.3479983810959873,-0.20959454232034547,58.3005472809392,-130.89527952767213 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark23(-0.3480601046019922,-0.4025101753957472,-0.6113681110964522,35.3767929402521 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark23(-0.34827843541254744,-0.5569080953248448,100.0,86.67585543628336 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark23(-0.34846080120979794,-0.5971100598793297,-0.5575138873706209,100.0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark23(-0.3486474857487835,-0.5290729089107885,-0.6110744205230566,0.26453645445539425 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark23(-0.35218067772702044,5.345529420184391E-51,-72.55014282517807,-0.437565028930182 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark23(-0.352407808986881,-0.22974405315260832,0.9616020678908888,0.11487202657630413 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark23(-0.35253362574175506,-0.6091313505265704,100.0,17.599020505451563 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark23(-0.35363541393592757,-0.5885476528709523,-12.653316694332753,-87.01123523727455 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark23(-0.3536755452547169,0.11179802118229332,-0.413714898621123,-0.11000530680772824 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark23(-0.35517492551146734,-0.5912202781777485,-41.542866115267955,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark23(-0.35539755735074463,-0.5749144423448176,-544.0964435428889,0.2537637779641271 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark23(-0.3557234197505408,-0.6075364535161967,0.9632598732727187,0.3037682267580917 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark23(-0.35614303155468235,0.09992200576532984,0.8853201691627781,0.7354371605147834 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark23(-0.3564602715111266,-0.6794126681639375,0.8494206273897174,-27.936318140850407 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark23(-0.3566058487362856,0.17830292436814277,-100.0,-0.08915146218407138 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark23(-0.35664833201591256,-0.6070739899165576,0.9804764399963766,-0.354983101812806 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark23(-0.35707756213142633,-0.3545512790356932,0.17853878106571316,15.994561650092676 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark23(-0.3577133763332665,0.13225823940410733,100.0,-0.06612911970205365 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark23(-0.35824066601950283,-0.6062778303876968,8.470329472543003E-22,0.30322888066501025 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark23(-0.3593712591318247,-0.5987631047343076,-29.44242899343377,0.2993815523671538 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark23(-0.3594284431613841,-0.44092951063841324,5.222489157175348,1.0058629187166548 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark23(-0.3599669484493946,-0.5691664528996646,0.6965202334397477,0.28458322644983225 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark23(-0.3604866106786486,-0.3664433354950982,0.5923697138604102,-0.6021764956498992 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark23(0.36096420794824713,0.721928415896496,-61.80442556321349,26.428268749308565 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark23(-0.36129234788747744,-0.5875723006575441,87.3957603299504,-885.643175572906 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark23(-0.3617892829715199,0.18089464148575984,-100.0,100.0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark23(-0.3621428787523732,0.18107143935199252,-97.40512655363607,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark23(0.3627523708787182,-0.18258850315244318,-88.1459064533514,-0.5931177982464972 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark23(-0.36281915315624813,0.18140957657812384,0.1814095765781243,39.489802415397826 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark23(-0.3628775177669068,0.1814387588834532,0.9668369222809017,-0.8761175428391749 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark23(-0.3630387942685343,0.18151939713426712,0.8578295752783048,27.132606320343328 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark23(-0.3631256782043026,0.07229697549856239,-38.317001160520405,-0.8215466511467294 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark23(-0.36362397582254413,-0.010048009088691745,0.18181198791127184,-77.80668992758345 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark23(-0.3643098534254525,0.8421766183082111,-100.0,27.853524320437245 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark23(-0.36481385721980775,-0.5951645056829682,100.0,-100.27723920110256 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark23(-0.3649664933758135,0.17472079218990522,-0.6025824794633245,1890.0812405041945 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark23(-0.3654893504872696,-0.2902165085883137,-0.6026534881538135,0.14510825429415664 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark23(-0.365495229694939,-0.16932674631692884,-33.75587772696862,51.751024065562916 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark23(-0.3676335766919809,-0.5354925628048871,-68.6278028247624,-12.722410413607824 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark23(-0.3681217912457272,0.8256828371999245,0.1840608956228636,-18.474188912799175 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark23(-0.36875893682728433,-0.5216634928171082,-100.0,93.51973651897964 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark23(-0.3695356598191286,0.14686456526014124,-0.600630333487884,-16.516327842387852 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark23(-0.3700618274881681,1.734723475976807E-18,-3.28208427042701,-0.5718461776669247 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark23(-0.3713033349058665,0.8248460083137452,-12.892897071567113,60.063278739825364 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark23(-0.37140756173549283,-0.010731747719218315,0.18570378086774644,0.005365873859592975 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark23(0.37174588080272875,2.3142880884003407,0.19158800529353126,-26.26152585585662 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark23(-0.3728922021142591,0.18643439637545722,-0.4753917511019148,-0.8786153615851768 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark23(-0.37301644128519484,-2.9469868360776336E-4,-0.5988899427548509,-0.7852508140556445 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark23(-0.37436174507168507,0.8021186897600521,-151.92365651592556,104.02604472353156 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark23(-0.3752931550944318,-0.5950920642723353,-75.99597526008829,1.0829441955336159 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark23(-0.37547788768172413,-0.567747102630863,0.18643548943254606,-0.5015246120820167 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark23(-0.37664100559486335,-0.5839647978128184,-0.5970776606000167,89.04093922958326 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark23(-0.37722007570874894,-0.5411509322281517,0.9740082012518227,-99.5312127440624 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark23(-0.3772926768168385,0.816210970020002,89.87682279645337,0.3772926783874482 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark23(-0.3772961029670364,0.0044304025706213,0.2151233242516029,-42.78325331435144 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark23(-0.3775531391399395,0.1887765695699697,41.499973245597445,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark23(-0.3776615827753011,-0.4546762207445818,-48.868787686362026,78.58121929756713 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark23(-0.37790110929410725,0.18895053098297693,0.9743487180445018,-0.09447527471883391 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark23(-0.378379908353995,-0.5317060011963961,-0.5854907147210753,1.0512585993891728 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark23(-0.37860378460820837,0.064254381259887,-0.5918289041901601,-30.661340642811005 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark23(-0.37876761973360634,-0.33587390678923934,52.60643871942399,3.316953954781134 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark23(-0.3788190844786232,-0.5959886211579792,0.1894095422393116,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark23(-0.37945761772222397,-0.5954700068906407,-0.5956693545363363,83.19921622179984 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark23(-0.379651771608681,0.06272139264276881,-0.5955722775931078,-100.0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark23(-0.3817773264845868,0.0,0.5805562688488932,77.84550456742915 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark23(-0.3819287803151805,-0.08138301415134613,0.1909643901575906,-1857.716270360352 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark23(-0.38239022181193705,-0.5535717314077299,-28.992718941204874,-100.0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark23(-0.3858855294724084,0.16563106647784265,100.0,75.14588008129392 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark23(0.38649742137381793,-0.9786468740843572,0.5921494527105389,-97.90258429372517 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark23(-0.3871320825118792,0.016152299778223356,0.20945973462923817,-0.7934743132865599 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark23(-0.3871601255832232,0.3505659582976114,0.9789782261890598,-41.40227240738938 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark23(-0.3874332703737009,0.5121314082585349,-0.5916815282105978,-100.0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark23(-0.3892063179841491,0.7921618796454817,-68.40307662861441,-38.880433901713936 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark23(-0.38924878824641107,-0.5529514409172224,0.19462439412320554,-69.09142964553662 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark23(-0.3901116114695803,0.19505580573478998,-0.3099534624124643,-98.13355717598495 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark23(-0.3912540684645953,-0.58977112916265,-78.37286974818764,17.7047619729631 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark23(-0.3914643150869909,0.02175009392406542,0.03555297386983698,-100.0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark23(-0.39151902369682834,-0.5896386515490339,-0.5896386515490342,0.25165466261382574 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark23(-0.39163493192874255,0.19317609419022655,-92.27686232138538,0.6874951959828939 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark23(-0.39203922584322376,0.16042074645512194,0.04149691688111193,-17.835757981580183 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark23(-0.3920522582933005,0.1960261291466072,0.9814242925440986,-0.0980130645733036 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark23(-0.3924500705855787,0.12363032603903709,43.448819863623875,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark23(-0.39260229553982984,-0.589097015627533,-0.17636032421969525,-96.03286849766113 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark23(-0.3927840674111529,-0.4455283337854769,25.78276908935374,1.0081623302901868 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark23(-0.39291512987511873,-0.26649069691737926,0.19645756493755936,0.1586552310644901 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark23(-0.3933324081927524,-0.039423543475871535,-80.28177609834287,0.8051099289484069 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark23(-0.39525903070798807,-0.5324169706266768,76.27784559067514,-83.0394182125278 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark23(-0.395470457334432,-0.583865563620487,3.7372279739218737,91.37758466959446 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark23(-0.39609377898330433,-0.14137096195301646,-72.27203979943961,-4.342677569627986 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark23(-0.3961267107696999,-0.20071662068898127,-0.22935230526781605,-0.6638143570996426 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark23(-0.39650080607782917,-0.5871477603585336,0.9836485664363629,-0.49174699027307184 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark23(-0.39791509369461675,-0.14801914545944173,100.0,93.621821723766 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark23(-0.39791875064961046,-0.07961190561824594,19.22967963741977,0.46625990226387165 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark23(-0.3986755191118087,-0.5355254964433532,-100.0,59.3379777853891 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark23(-0.3988416052487865,0.1994208026243931,0.9848189660218415,-0.09971040131219652 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark23(-0.39910356696123134,-0.5569937296749004,0.9845720504391393,-0.5069012985599981 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark23(-0.3991110329378671,-0.5078515127996479,-100.0,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark23(-0.4009415954742641,0.021407569426476827,0.20047079773713206,-100.0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark23(-0.4013621054547975,0.0769249363426486,0.20068105272739875,-0.0384624700106172 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark23(-0.4015490480813942,-0.3800460426168316,-0.5846241565993634,0.9754211847058641 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark23(0.4023367378404502,1.6089446570048311,-84.58316985710371,8.6742549556304 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark23(-0.40478015613769264,-0.5830080853285989,0.9274429718210111,12.9741843318129 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark23(-0.40627000602840485,0.033164045748232215,60.246446738992766,-0.6901960866862967 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark23(-0.40646682988009014,-0.5821647484574014,-0.5821647484574032,-100.0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark23(-0.4069623158003893,-0.4941399072896544,-0.46090554431247877,-100.0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark23(-0.4084865609744138,0.20360982128230629,0.2042432804872069,-45.66289449173685 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark23(-0.41016482748558675,0.20469304686955825,-0.5803157496546549,-1.6240127463200154 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark23(-0.4109634239181935,0.09284070948246267,-66.38523826608534,-0.6201642639073991 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark23(-0.411041399388263,0.02664589470704415,54.478572042585796,-82.31585885586884 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark23(-0.4118249774814927,-0.5794856746567018,100.0,18.971582134445793 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark23(-0.4133887322242119,-0.11684165788632161,0.1831666329383188,86.52158507625069 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark23(-0.41357268799773106,-0.39909419915161715,-98.28557141223826,-0.5858510638216398 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark23(-0.41411559271281884,-0.42047169256863237,100.0,-100.0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark23(-0.41420620844165534,-0.19654108392858188,100.0,-98.53333187335173 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark23(-0.41626659775152874,-0.5170996041534396,0.5698201939702732,-53.224643721514425 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark23(-0.41654843843230244,-0.49539361135923193,-3.5019977540968776,8.290585112591606E-4 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark23(-0.4167211369118746,-0.4112612088869947,-37.674522796915014,-0.579767558953951 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark23(-0.41677960709921286,-0.5199095829697155,-14.95173961917854,-50.03069187486526 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark23(-0.41680589133763435,-0.5214602219373883,-66.4078012444498,0.25175500123809863 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark23(-0.41759776209958765,0.7356008025957205,0.24181267069202547,-68.70133672395504 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark23(-0.41854880881157736,-0.36917278951632504,0.20927440440578868,-35.158772415732265 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark23(-0.419916234471013,-0.3333946030778407,-31.04114684581191,0.16669730153892032 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark23(-0.4201345677365827,0.20369526336464175,-70.53396393233908,-2171.4956563001356 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark23(-0.42090517959319285,-0.5741676786894654,0.9958507531940447,88.06526451370286 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark23(-0.4210543241934505,-0.5745120135552104,0.9959253254941736,-80.65253033612947 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark23(-0.42118678298272977,-0.10790057582879209,92.9932832435106,3.7622176023043963 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark23(-0.4213316616412356,-0.5703831193992052,82.4914989388663,-0.02176094507965387 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark23(-0.4217956714482519,-0.2325976903711418,0.2108978357241259,1888.333623699022 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark23(-0.42328940853063146,-0.15657080052892247,0.20873039981635816,37.42019017371942 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark23(-0.4232939269019742,-0.46297426075731507,0.2116469634509871,45.76124495965588 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark23(-0.42335298994965326,0.21167649497482655,0.21167649497482666,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark23(-0.42720957916304714,-0.2521171127620314,-97.42959520761984,0.1260585563810157 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark23(-0.4275313246845477,-0.1030962272835437,98.36870772921893,0.6059746900600873 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark23(-0.42804790448751245,-0.5693089833765674,0.9994221156412045,0.28465449238310225 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark23(-0.4282601447666618,-0.09947372862246806,-61.75219924204665,0.04973686431123403 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark23(-0.42866464947869815,-0.35497479142179783,-103.44407440441306,0.1774873957108989 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark23(-0.42871833015387595,-0.41602956818483894,0.6428685087872968,-0.5773833793050288 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark23(-0.4293848323160612,0.21469241615803059,100.0,-100.0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark23(-0.4298001343743457,-0.8596002687486755,100.0,100.0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark23(-0.43000190248610515,0.20708792582769256,0.21500095124305257,0.6805392801641773 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark23(-0.43008043045521166,-0.5703579481698423,-0.5703579481698424,-28.81658964074843 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark23(-0.4301616961020391,-0.5391409169003629,101.27142827519131,8.123379050289586 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark23(-0.43020236391928374,-0.5702969814378058,-0.5702969814481662,1.0705466480921775 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark23(0.43043886243019885,2.4300846698995926,47.08954102592625,-2.0004404983472446 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark23(0.43050177102777026,1.2665131171263018,-0.21525088551388513,99.99513516375099 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark23(-0.4306260404558475,0.1540908799108179,-40.10668994261855,70.68884722269335 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark23(-0.4315324987569744,0.2157662485582894,-97.75154898025401,-0.893281287676593 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark23(-0.43162490117076047,0.21581245058538012,-0.5488659709686146,46.87513595974449 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark23(-0.43236229345100646,-0.4373007146891878,0.21618114672550326,40.033418886101444 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark23(-0.4326366715725661,-0.42446634415317375,100.0,74.76184837623947 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark23(-0.43342349123662,-0.5686864177791382,1.0021099090157584,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark23(-0.4338145686348326,-0.4033864533921388,80.39901379243639,0.20169322669606937 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark23(-0.4343020680175865,-0.559029269280897,1.0842021724855044E-19,0.27951463464044857 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark23(-0.43477630590176963,-0.5371659554846622,-0.5680100104465635,100.0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark23(-0.4347829661265471,0.7011859851262171,0.21739148306327355,-26.26580107778362 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark23(-0.43571613398510933,-0.5675400964048886,1.003256230390003,-278.53636543597554 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark23(-0.4361936784426188,0.17049801418189112,0.2180968392213094,22.134405312877547 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark23(-0.436341856402288,-0.18892477563050286,-53.52874515867238,-0.6909357755821969 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark23(-0.4363828978745295,-0.5672067144601834,72.33778960224917,0.9367639670704956 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark23(-0.436570686145021,0.0,0.6341729512899582,62.46109100094455 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark23(-0.4367958037603734,-0.16994514177143882,-0.5670002615172616,5.831081044366471 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark23(-0.43771055947711063,-0.09421957007785653,33.21537659341782,100.0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark23(-0.4377120263460944,-0.2427858378698559,-28.49188278885032,-0.2970623661469201 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark23(-0.4382345415986378,-0.3506843694516074,0.2191172707993189,-100.0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark23(-0.4385396589250626,-0.4575214950872482,-0.2380050980679933,-67.35590970878432 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark23(-0.4385711675235049,-0.741715216949461,23.220233622403875,0.43857121195761406 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark23(-0.43886344594989246,-0.31417080791126556,0.21943172297494623,-49.58271683797961 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark23(-0.43984573987917747,-0.5135635690015454,0.2220683768168723,0.8131691535465648 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark23(-0.440428781618707,-0.1854728245155126,51.23653321321214,-62.60436074269247 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark23(-0.44083461590788714,-0.356065496651018,0.22041730795394357,-55.59248381145532 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark23(0.44139565647534457,2.4510835736677685,-90.09030366917585,63.177363972224995 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark23(0.44145511455522285,-0.640423796140228,36.75549310855169,0.32021189807011385 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark23(-0.44186000876305226,-0.5585954153907378,-28.197305221883887,40.32366960256698 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark23(-0.44230984644745297,-0.0888592006728108,1.0065530866211747,0.8285128434144131 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark23(-0.4429916303427301,0.22149581493295728,0.6340133057132841,0.6746502559309696 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark23(-0.4432217188202119,-0.5440197064329548,18.52188499138775,100.0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark23(-0.4434134661479028,-0.5636914303234968,-64.87289873660977,9.083899695674901 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark23(-0.4438424244642021,0.10362740762840948,113.85707921130097,-0.05269722412830147 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark23(-0.44488395115125334,-0.49433250818344987,-99.55266453741862,-27.442193564516007 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark23(-0.44561651826934456,-0.21804329137295353,-90.32258691133647,-16.562859438025193 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark23(-0.4456292938175916,0.22281464690879577,100.0,-97.4820489603112 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark23(-0.445900710878781,-0.5559611011904884,100.0,0.7471612748083322 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark23(0.44638018956193204,-0.22320446520471537,-100.0,-0.668115695005193 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark23(-0.4469640473884131,-0.4141076343953783,1.0088801870916548,66.0401732431026 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark23(0.4469899000884743,2.464776121682227,-1.008893113452566,-45.99938610722787 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark23(-0.447264497656645,-0.5617659135039701,-30.740257687241815,0.2808928209731778 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark23(-0.4481525363615746,-0.3082381576974851,22.151827139219193,-66.7066167810773 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark23(-0.4482232762271803,0.22411163811358925,-0.5612865252838581,53.370895155010075 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark23(-0.4482727183970425,-0.5439231855178107,-79.40915512290037,-100.0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark23(0.4484433651241251,1.7427565993613512,88.00332123198855,-99.99538388416957 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark23(-0.4488073787411806,-0.04693231862248082,0.21513078527999266,0.023466159324315068 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark23(-0.4496042472470201,0.2108921770533616,1.0102002870209583,-4.2696250399406175 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark23(-0.4499389744200202,-0.5565395396217202,-105.63211814356102,-48.72189849418645 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark23(-0.4502837704162701,0.047233672769809276,32.31798417941973,-115.16945117979773 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark23(-0.4502952102923573,-0.3951440094904652,1.010545768543627,-1013.4131855298161 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark23(-0.4510529039224076,0.004254204173138564,-34.63055428540059,-0.7741216977769023 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark23(-0.4511151201859625,-0.3095771586950584,-2.6458553666151357,-1960.5979669244089 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark23(-0.4512370358058524,-0.47232721675080547,0,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark23(-0.45228947196746894,-0.5143279185667841,54.314337001920585,-1662.1729936830927 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark23(-0.4541079356762282,-0.02066546985055977,-3.482612050944337,1.3632459551288387E-36 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark23(-0.45457050394690574,0.6579875904519831,-75.74646046116108,-237.05628866528374 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark23(-0.4548828933444129,-0.5576023474042682,-13.437778317340232,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark23(-0.4550311309725146,-0.8035308241653192,1.0129137288837056,1.8682668742787711 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark23(-0.45565803867696275,-0.5558784030421376,1.6521217940167446E-15,0.2836233511623405 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark23(-0.456161892323975,-0.4700156334216121,-100.0,1.0204059801082543 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark23(-0.4571733786294368,1.951563910473908E-18,0.5237183668369956,5.569174126764564 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark23(-0.457203168480256,-0.26960842083264874,-64.82287708682887,-0.650590018909135 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark23(-0.45744599107748307,-0.5190090164867502,100.0,-63.017801038429525 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark23(-0.4580143169267198,1.6796517301017081E-15,0.5654010743213669,6.174142836033713 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark23(-0.45888622553277864,-0.1970179673821749,0.22944311276638932,-109.85145441361675 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark23(-0.45933737072301994,-0.35538959596175207,0.22966868536150997,-70.01774672575952 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark23(-0.45964036710402695,-0.5381271501774667,1.0152183469494618,-1.7019741733741371 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark23(-0.46010470080478966,-0.3009507622056127,-22.42214813151878,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark23(-0.46066200092622855,-0.5549810137494221,0.23033100046311428,-37.579006716990484 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark23(-0.4614104666028131,-0.5546929300960406,1.0161033966988549,100.0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark23(-0.4621992989827052,-0.22710366115260766,0.8461090534043457,1.6026208204409036 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark23(-0.4631209025077565,0.11431039363163409,-9.375246382376524,-60.44137271032489 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark23(-0.4632362405306425,-0.2042345064076616,-0.553780043132127,0.8875154166012791 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark23(-0.46425289944333187,0.12623283586031464,0.472291045960908,91.43348555450446 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark23(-0.4658021106906278,-0.021520068654272917,-7.401240419288976,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark23(-0.46628763764524495,0.23314381882262225,-0.5522543445748258,-39.19740075838253 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark23(-0.46763602740576604,0.2230789276321459,100.0,-59.784398830483724 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark23(-0.4682046428363084,-0.5429931319633832,15.460289108556207,34.55955873202595 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark23(-0.4696136203004076,-0.47485444327472787,264.77212850997927,-7.6444720210504835 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark23(-0.4701778910765425,-0.46078391299340715,1.0204871089357195,20.559752143005426 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark23(-0.47130355477018177,-0.5497463860123573,0.2356517773850911,0.27487319300617863 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark23(-0.4715379634081067,-0.49262074233850733,0.8123598518509287,0.2463103711692537 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark23(-0.4724950429781978,0.005825946800502994,0.6892436616880202,68.88606800645059 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark23(-0.4727434127977048,0.1702318476087862,93.66771764341922,31.290946346965953 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark23(-0.47281783598786964,-0.5489892454035132,1.021807081391383,-0.4534092695718166 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark23(-0.47301838093294307,-0.5286528210089846,72.2114291127688,40.05454710019458 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark23(-0.4731396100755228,-0.10832864778790992,24.583912847890172,-0.7312338395034933 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark23(-0.4732061038015849,-0.5487951114966556,0.23660305190079234,2.443886697072761 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark23(-0.4745522034596107,-0.5252920393675684,-99.99999999999999,100.0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark23(-0.4767446553350648,-0.3114596871728393,-0.15910263061290797,69.58765053568523 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark23(-0.47749137234321176,0.23604381008407493,0.23874568617160588,11.368703373997178 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark23(-0.48066075895952726,0.2403303794797625,0.24033037947976363,-34.64728299075357 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark23(0.48115321924026494,2.519130501770774,-0.08830704219217148,10.534098187079806 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark23(-0.4817232845322794,0.24086164226613968,96.09242556371078,67.40758320350997 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark23(-0.48195932404632685,-0.3966687174429203,51.29185897043447,0.9837325221189084 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark23(-0.4820291183363775,-2.8152748981261335E-6,-0.3190648891455366,3.7952528602030296E-5 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark23(-0.48292796287534356,0.589233591933032,55.71437306299305,-73.3286710512637 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark23(-0.48418256527014836,-0.21068309910417904,-0.8307349734828852,-0.6800566138453588 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark23(-0.48426702133817967,-0.543264650999535,1.0275316740665381,100.0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark23(-0.48465817617596074,-0.4431357704094957,100.0,73.57208705946299 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark23(-0.4848774229983457,0.2424387114991715,49.30724424246469,100.0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark23(-0.48504149372288163,0.24236856133908974,-66.0285633853579,-0.5592864675682614 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark23(-0.48622586433438175,-0.048078959360023286,0.9980418436849132,90.84623808784434 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark23(-0.48703134929552216,-1.0268231905352527,-16.091814729927588,-0.8349335638569642 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark23(-0.48723152958981814,-0.2230105624087494,-0.046025927056216505,-0.524043979651565 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark23(-0.48960004420987957,-0.021249166174297507,-0.5405981412925085,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark23(-0.48987237856860677,-0.540445079003534,0.24493618928430338,1.0556207028992153 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark23(-0.4910831412340565,-0.5398565927804198,-69.56837066955721,-87.27201430386484 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark23(-0.4911077191901588,-0.22621071361706455,-0.5398443038023689,0.8971885998865474 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark23(-0.49128569763092433,0.24564284881546178,-100.0,0.6612618186673505 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark23(-0.49145040685674557,-0.5394396836169968,0.24360167272524189,156.274977923427 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark23(-0.4915893527291656,-0.3860847907313043,100.0,0.6674311318343128 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark23(-0.4919394179663802,-0.9838788359327362,-0.5394284544142581,1.2773375813638164 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark23(-0.4925867127106272,-0.21508018515427924,1.0316915197527619,0.10754009257714187 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark23(-0.49266672173637627,-0.49042240035462725,0.19636778219103845,-72.05865955040383 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark23(-0.49340848045020236,-0.4474412246459871,-6.410685593689916,-54.26527549826653 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark23(-0.49400481413989816,-0.15797289317184182,-0.48376381575874916,-30.885970278221563 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark23(-0.49514883163495904,-0.10767453574821317,-98.12528294280327,-60.51926389837116 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark23(-0.4977710122605921,0.24888550613029603,0.0460456202170222,99.0283868144657 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark23(-0.49910788688660546,0.17280921487054912,1.034952106840751,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark23(-0.5001144120563218,-0.016155869976167705,0.2500572060281609,89.54323971158455 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark23(-0.5004344632253919,-1.6403724941242902E-40,-0.3791314712305557,0.16039629619243947 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark23(-0.5011466261687156,-0.5341020223535858,-0.5348248503130905,54.21727908459329 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark23(-0.5014455877323909,-0.5346753695312406,0.25072279386619545,-88.05299671823187 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark23(-0.5021849264656937,-0.513904931092425,0.2716511643431647,-1760.7493531430448 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark23(-0.503652480729329,-0.1469433367339832,-107.30408052051946,-129.23401819023667 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark23(-0.5039918524845621,-0.5329388745187889,1.0373940896397293,62.689571444674286 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark23(-0.5045498364124783,0.5600684341348618,4.088949153777175,-28.542626402228212 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark23(-0.504692071529946,0.0420031226086435,-0.30815259293793146,0.0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark23(-0.5052390921220956,-0.5297561066751185,-0.5181718508925788,1.0502762167350075 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark23(-0.5056320764537643,0.12635264047191574,-100.0,94.70842267294464 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark23(-0.5058072732919776,-0.44297495764232736,6.6789442829381125,43.32923442339225 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark23(0.5065141105307845,-0.2845536816870841,-29.14059777875246,-0.6431213225539062 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark23(-0.5066140965703819,-0.5320911151122568,81.651516186815,-34.7015364115401 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark23(-0.507416129465661,-0.5316900986646177,0.2537080647328305,0.265845049332309 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark23(-0.5080160866129091,0.2540080433064533,0.25400804330645377,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark23(-0.5082644394489759,-1.0165288604530698,19.073897007857745,-0.2771337331709134 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark23(-0.5088682550056915,-0.14720857161445883,100.0,0.8590024492046772 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark23(-0.5103932309039491,-0.4435406706524765,10.3457388275595,-17.795951459579744 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark23(-0.5104655225899646,-0.2362478024078627,100.0,44.27749415570851 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark23(-0.5105848671148339,-0.46713595280257203,-68.16429505886988,29.157322406291577 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark23(-0.5108809849356291,0.2554404924678144,1.8251081073297257,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark23(-0.5115984070750382,0.11580552407868798,1.0411973669349674,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark23(0.5118910809155962,2.5945784885940686,-1.0413437038552464,44.25580675409645 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark23(-0.5119426571068445,0.2559713280925819,100.0,-0.9130950242836675 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark23(-0.5128206928720862,-0.46922251204419096,-0.5289878169614046,-2015.7688307663543 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark23(-0.5148537662690418,0.02703934170423805,-26.433128351392575,59.45304116558443 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark23(-0.5155645616778449,-0.12302043185389282,-0.5276158825585259,0.06151021592694644 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark23(-0.5164823079262273,0.5295650187063156,-47.355948520046084,59.4265861969877 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark23(-0.5170399415852347,-0.526869183052996,-99.48366295007519,1.0488327549239462 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark23(-0.5176987003386901,-0.526548813228103,-88.41646566359975,0.2592249837880882 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark23(-0.5193542109211764,-0.1979307198278804,-26.90170049485441,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark23(-0.5202435618145892,0.014583864240603579,100.0,-0.79269009551775 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark23(-0.5210750626985585,-0.523481152707639,27.842074803852505,0.26174057635381903 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark23(-0.521084359188172,-0.2326760339862739,-92.06537041202607,69.6011158963898 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark23(-0.5215059075205375,-0.5171893718150398,-26.058326280313,1.0439928493049682 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark23(-0.5240211665709518,-1.03116116575013,-0.5233875801119724,3.6571522436874377 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark23(-0.5243822523744835,0.43139590798163835,0.8966111980605582,90.90806138099643 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark23(-0.5273372897877273,-0.24380450851668,-0.5217295185035846,-19.570640833436237 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark23(-0.5281315635206814,0.26406578176034046,-60.242537415798836,23.214048516471355 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark23(-0.5284936281105062,0.195708909158272,-51.19507905928645,-100.0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark23(-0.5287861460220773,-0.31415926535646355,100.0,-2206.043862520401 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark23(-0.528788185739877,0.16793426149149407,0.26439409286843946,-0.08396713074574702 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark23(-0.5297296657148449,0.510850218791204,12.580655456592265,-100.0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark23(-0.5299685542585038,-0.0213969178027964,1.0503824405267002,94.22798982825671 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark23(-0.5301118550594284,0.5105726166760381,0.31639357881097685,-100.0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark23(0.5308471653202053,-0.2654235826601028,-100.0,0.9181099547274997 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark23(-0.5311372940455998,0.012354250471225514,54.235464384452165,-80.6483185701688 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark23(-0.5315377167729808,0.26576885838258113,-64.88418322208773,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark23(-0.5318092229306199,0.0989788495145345,-49.123886022099875,-0.6219689544142369 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark23(-0.5327428429851476,-0.5107464254953076,-34.59735212483563,1883.16524253043 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark23(-0.5328726043071464,-0.5007746338523533,64.37483391160295,0.2503876180964575 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark23(-0.5330893015298049,-0.0060496808447268145,37.18024836795699,-0.7803402472014481 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark23(-0.5333588538577629,-0.07953222860760127,0.7678184800583874,27.572406879036173 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark23(-0.5341797479067455,-1.062650143982711,0.04824944190669944,-100.0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark23(-0.5345777029888926,-0.5181093119030016,-0.518109311903002,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark23(-0.53520019351466,0.21599898495789938,58.734120693493615,46.718092403047045 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark23(-0.5352903107039106,-0.08841082347810404,0.2676451553519553,100.57605970842424 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark23(0.5359242151107584,2.63411613839441,100.0,100.0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark23(-0.5369552944723384,0.24070843442685685,0.2684776472361692,71.68142589045891 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark23(-0.5377772573568824,-0.4204822358468395,0.2688886286784412,0.9956392813208681 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark23(-0.5385850189353016,-0.4566707346611789,0.269292509467651,5.615981963474965 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark23(-0.5388245876442062,0.2306526545208838,0.9498326865147892,-72.01794189045047 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark23(-0.5402376321439863,0.059925189320436244,0.2701188160719932,-88.63663677154288 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark23(-0.5438190004982387,0.2719095002491193,0,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark23(-0.5442298861322334,-0.5132832203313314,-100.0,0.9512078252305929 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark23(-0.5448016238592714,-0.024820790774122692,76.48552863556236,-32.23188481912739 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark23(-0.5448491750931009,0.48109797660861897,-0.5129735758508978,-99.9999999999984 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark23(-0.5456312619173851,-1.0903952729336293,100.0,6.036045415977284 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark23(-0.5460756891344581,0.026712089987933063,101.34732062013816,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark23(-0.5464768218626317,0.27323692668207683,-38.80108390447914,5.036799749034767 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark23(-0.5469178270658237,0.47650028991338833,-19.90914113232427,0.54716782139991 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark23(-0.5470737044759946,-0.5118613111594509,1.0391771956808387,24.02509478443113 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark23(-0.5471183885958982,-0.4817851915651208,52.93040341229726,-552.1034545470844 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark23(-0.5475291312195952,-0.18648925305969388,0.3675610761396781,-0.6921535368676014 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark23(-0.5479444365208703,0.25810786270748265,0.32924251119618,1.1996994988703022 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark23(-0.5480838585668834,-0.03134277739482586,-200.29016263148372,-0.05035498136176386 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark23(-0.551294142202337,0.2195751514494707,62.58462261847308,-45.92572767772426 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark23(0.5513299691927694,1.727976574845822,-100.0,-0.69123752844412 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark23(-0.5521905607200548,-0.16197377505812058,100.0,0.08098693894459333 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark23(-0.5521928446221374,-1.0620248538839185,135.2484595179574,-100.0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark23(-0.5525902715463857,-0.46973727577615465,-51.05781129956882,38.61073248990273 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark23(-0.5528934580653426,-0.5089514264028651,39.016605557887644,0.2544757132014325 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark23(-0.5547465572520669,-1.0993981706630476,-147.5740254779447,-100.0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark23(-0.555345367714672,-0.5077254795401112,0.277672683857336,0.07710231510986887 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark23(-0.555801850345036,0.2777397022462265,-96.0583468576949,95.71432900225369 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark23(-0.556075651071567,0.27796993343031984,100.0,-0.13898496671515992 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark23(-0.556356305352143,-0.30970066230513815,-0.5072200107213768,87.29731488526967 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark23(-0.5578857160135738,0.14794907747783276,-0.5064553053906613,-16.012241188587566 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark23(-0.5583266070520405,0.45414311269081487,0.2791633035260204,1.343724770449489 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark23(-0.5583599566306253,0.2791799782295678,-92.19556992147908,-0.9249881525122321 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark23(-0.5612252559273452,0.28018330833537375,10.26227609870612,20.227758853236267 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark23(-0.5617340162932953,-1.0798528241397038,1.0666224177059733,-0.2454717513276025 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark23(-0.561856213897068,-0.5026941900988969,0.280928106948534,-38.58909004337672 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark23(-0.5629372036774078,0.1081937830702715,-0.5039295615587444,124.35778880306867 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark23(-0.5644434244996814,0.2822197545569729,1.067619875647289,0.644288286118962 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark23(-0.5647201379430948,0.27924923803086277,1.0666175252961412,0.645773544382017 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark23(-0.5651902145249768,-0.4294753031054618,-94.42100154731953,-2017.0980972768054 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark23(-0.5655006999604854,-0.4769410149343927,0.0,3.3806339467205976E-6 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark23(0.566012333213,-0.42496580950225393,-0.1333675086329733,0.21254374838567125 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark23(-0.5671831936477187,0.24325438015170264,1.0689897602213076,-92.78029239141647 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark23(-0.5673551453668051,-0.47241311984391965,44.49976986928223,0.2362065599219597 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark23(-0.5675742105219895,-0.12443055914280077,0.2837868277657976,-0.7231828838260479 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark23(-0.5679046048857219,0.12538032212671288,-0.5014458609545873,66.64058659195607 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark23(-0.5680368360329535,-0.5013797453809714,-6.219518231370337,37.22389214328275 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark23(-0.568779842179396,-0.06207651450877005,0.284389921089698,-92.23486811954358 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark23(-0.5689318828913918,-0.8048547048992009,-53.12352968404572,-12.17177754521758 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark23(-0.5706077414512853,-0.4879224716981343,47.71442589338891,0.2439612358490671 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark23(-0.5723148440569336,-0.055629384829243844,-97.72485838412084,0.8132128558120703 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark23(-0.5733784228500443,-0.36675808641973484,-49.925533361492064,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark23(-0.5735504889226992,-0.49862291893609845,0.2867752444613496,10.930876676318618 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark23(-0.5755999367892234,-1.149946736061936,-89.52317824321241,15.497518745288332 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark23(-0.5761326924448367,-0.17332366382092437,0.2880653824308377,68.60137086437481 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark23(-0.5788908482910288,0.2894454241455144,0.29420093727280394,-33.13279287977776 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark23(-0.5797148303511841,0.15804442392516216,183.25438873790338,-0.07902221196258111 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark23(-0.5799964763607728,-0.4850982739679872,1.0643110036612398,-0.5428490264134547 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark23(-0.5808410794375575,-0.25248742282421693,75.65637807554742,-2217.5806975245027 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark23(-0.5814696011665409,0.08124243282550492,100.0,-61.743677348524386 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark23(-0.5814790813873294,0.17023971140937724,-0.4946586227038452,-103.75157306016033 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark23(-0.5833288001581085,0.018282383440611838,67.24241890891514,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark23(-0.5839243411639838,0.23635667768338042,0.29196217058199214,-0.9035765022391385 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark23(0.5846701705594504,-1.0777332486771733,0.4930630781177231,1.324928329645098 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark23(-0.5850926266389722,-0.1646400129820948,-84.62053499477436,-81.99205229239662 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark23(-0.5852652219083098,-0.46324287615457127,0.5634481664221944,-22.09203216737981 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark23(-0.5859361200346829,-0.49243010338010673,-100.0,1.0316132150838173 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark23(-0.5862673314857354,0.2931336657428676,-42.414890955874036,-10.583368603513515 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark23(-0.5868245194123268,-0.49184668416404304,0.10191095143393578,3.6918201965760935E-18 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark23(-0.5868779922938355,0.29343899614646235,90.95503405275872,-2.502913988265576 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark23(-0.5876471480066322,-2.465190328815662E-32,-44.01944278310942,-0.3009351504380395 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark23(-0.5889516515358961,0.39289281656081054,39.626493759841004,-36.38725952542972 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark23(-0.5895173669038378,-0.10585111809748847,-0.010409032481017873,-0.25732917563821484 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark23(-0.5896294497661819,-0.3753953893454419,100.0,0.973095624460654 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark23(-0.5918593638570747,-0.16065008517970492,-38.576553963520595,0.08032504258985246 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark23(-0.592007358962553,0.20522575009276256,99.84434603600432,-71.7510758923265 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark23(-0.5934678103492397,-0.48866425822281206,-87.51178452088368,0.22439524511068115 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark23(0.5936840558612356,-0.2978348549464868,-114.17957549947783,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark23(-0.594809809070938,-0.449515726574585,-87.49430411649561,1037.5652849005658 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark23(-0.5950570450762429,0.11383330711078893,-100.0,-60.04605290173971 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark23(-0.5977516355910252,0.37524534244137425,-31.502052996284668,0.5977754921767633 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark23(-0.5981393885691867,0.2952651725306887,-0.4863284691128549,-0.36515447365872333 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark23(-0.5987333870388839,0.2993666935194418,-0.18687757996881466,-13.048982815963848 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark23(-0.5991003091559677,0.29955015457798373,-11.106616307786295,-87.71482248780836 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark23(0.5992734852825848,2.1368506645781373,191.9307108713887,88.5841032678336 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark23(-0.6015021227591351,-0.48464710201788064,99.99992414975023,91.71179020890406 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark23(-0.6017398333819706,0.1532556941140765,-0.484528246706463,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark23(-0.6018051822213633,0.2996336769697594,-135.12274044187595,-35.75457705364832 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark23(-0.6022706415746236,-0.4716425323063753,1.08653348418476,-12.187344373560446 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark23(-0.6026230086124922,0.301311504306246,-0.4840866590912021,32.066699927793906 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark23(-0.6038916305067779,-0.04837088113520316,189.1146250669746,-76.5663429232878 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark23(-0.6057841474361825,-0.33604361935256655,0.30289207371809124,-2160.8017343674283 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark23(-0.6058284064991974,-0.4411426088329154,-0.37477295547440104,0.22057130441645767 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark23(-0.6068926801447841,0.2602022022532047,0.17915042924501046,-0.9002018334090394 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark23(-0.6071056148948888,0.3035528074474443,0.41774530326362086,-18.17191551539553 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark23(-0.6077996227289497,0.03457590250425137,100.0,-0.802686114649574 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark23(-0.6083041507541902,-0.2843687910592417,1.085932701896326,0.1421843955296208 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark23(-0.6095109294410821,-0.480642698676907,0.30475546472054105,0.24210057835152277 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark23(-0.6096696704861837,0.05919780235609262,1.0902329986405401,34.936453133540745 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark23(-0.6104908221854763,-0.09026830387551144,0.3052454110927381,41.819840633459734 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark23(-0.6112912434513756,0.24190415316112368,-47.06642409264326,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark23(-0.6121472104256311,-0.16074881900074656,-72.40839504499337,-63.62531632634414 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark23(-0.6124690630094201,-0.13097208920079184,100.0,100.0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark23(0.6129090167599037,1.3325926907611738,30.577060927586622,-0.675200942103356 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark23(-0.6129214807771592,-0.15665480885937977,-8.628658855452052,-10.815903016351648 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark23(0.6131796006848006,1.229998579330325,-74.1338513883974,-0.8859346498516416 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark23(-0.6132520851775229,0.03132172224470442,67.53625631617714,-14.192251280795734 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark23(0.613987933972417,2.79877219473973,0.07704782753613637,80.5745283223755 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark23(-0.6142367514560234,-0.36414212905842014,-0.47827978766943663,-44.58635178213362 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark23(0.615037482430243,2.8008712916553824,-0.17177734720221643,35.57832963501835 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark23(-0.6153609175091918,-0.39820555543826963,-55.50762514599172,77.92223611683002 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark23(-0.6176030782824993,0.3088015390217569,0.3088015390222801,100.0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark23(-0.6176540062524081,0.19343243373620783,0.30882700312620404,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark23(-0.6178803831059221,-0.18043480263588918,1.0943383549504093,15.709072409390032 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark23(-0.6184564343585163,-0.18881561679845954,-99.35752980363958,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark23(-0.6197532150119286,0.30635036936773713,28.839384021519386,-0.9385733480813168 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark23(-0.6201882037680129,-4.832717044402499E-21,0.41765458452461085,100.0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark23(-0.6203856108611351,-0.47520535796688007,-0.4752053579668808,-100.0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark23(-0.6221109142926492,0.2475356476564088,0,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark23(-0.6227821287625034,0.29150860159305336,-0.47400709901619653,-0.1457525343509863 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark23(-0.6228227800885794,0.309263191843896,0.28317499816584346,-0.9363000596426052 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark23(-0.6228507735126733,0.3114253863346078,36.86159687470399,-51.39289208867919 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark23(-0.6229086193335966,-0.2838107643914506,100.0,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark23(-0.6229271805103465,0.30246256893403256,-0.37053963537563456,22.374615880698677 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark23(-0.6245140909380125,-0.30456753673279385,0.31225704546900623,2037.6912780792022 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark23(-0.625724992341733,-0.22991444490473406,18.476491195383385,-0.6704409409450811 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark23(-0.6258318955304782,0.30151487344310357,82.12941523077019,3.4363602584559656 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark23(-0.6271835452521353,0.22499327390730967,0.3135917726260675,-0.11249663695365482 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark23(-0.6273672838728441,0.31261401296898383,60.66564255473757,-63.77245574755529 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark23(-0.6274275150469013,0.12216365044737643,85.58395203683962,-0.06108182522368823 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark23(-0.6274565391694257,-0.4186260390993871,1.099126432982161,-57.12622060900703 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark23(0.6274661746212624,-1.4511922336084098,-0.19553341549087122,-121.82524039374033 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark23(-0.6280942948980831,0.27450701880625966,-98.52834788473356,-73.17170950216165 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark23(-0.6283183888449645,0.31415857847611234,100.0,2089.1917611318204 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark23(-0.6283185307178636,0.31415926535893135,64.0219964973658,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark23(-0.6283185307179584,0.31415926535897887,1.0995574287564276,1988.957622527432 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark23(-0.6283185307192465,-0.1360073537185864,100.0,-100.0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark23(-0.6283185308290519,0.31415925677630435,100.0,-0.1570796283881517 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark23(-0.628328173124833,0.31394786791001444,99.99884616635154,-91.14537264532792 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark23(-0.6289850105791723,0.251240656068921,1.0998906686870344,-49.12197336328791 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark23(-0.629899713541791,0.3109967555910203,100.0,37.501149582510564 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark23(-0.6304755034992251,0.3030294578278384,1.1006359151470608,-0.15151472891392004 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark23(-0.6308819105212913,-0.14469017635834816,-100.0,23.950500002327008 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark23(-0.631809569788312,-0.192347754710413,13.140985358535389,100.0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark23(-0.6325248035118184,-0.09270185219182711,-100.0,187.54649014737572 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark23(-0.6329667380488484,-0.4473924359512824,-100.0,100.0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark23(-0.6333688663183693,0.2722186063861973,0.3166844331623032,-0.13610930319309866 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark23(-0.6333710112738802,-0.46057362612127595,52.17531970025099,54.09428437795231 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark23(-0.6341470195833243,0.30250228762824777,-30.070944359113422,12.41685989322799 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark23(-0.6342022488335735,-0.46664553102136486,-0.3095515240806887,0.23332276551068243 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark23(-0.6354807630928688,0.22566680216470694,-462.22097552834896,-0.8164337724928261 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark23(-0.6359884024920571,-0.46434269060187455,1.103392364643477,0.23217134530704245 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark23(-0.6361728812235277,-0.2768619143280355,1.1034846040092121,49.37397827218407 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark23(-0.6368962081000898,-0.4660832955154468,-100.87598363001676,-1485.9534939188827 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark23(-0.6379826184202435,-0.4662336117456665,1.10438947260757,0.23311680587283323 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark23(-0.6383812936834156,0.2940330763218461,-0.46620751655574055,-0.9324141933349018 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark23(-0.6386157179888068,0.11171185316079058,90.67285515970909,-100.0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark23(-0.6388955522057969,-0.30665345694401736,-2326.684971304411,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark23(0.6395364612860276,2.8274227386796933,0.4010463258895326,-86.20900038173616 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark23(-0.6397020165390265,-0.4387948324468573,3.816977350377518,-97.20566410236908 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark23(-0.6403321427794856,0.12945915319911405,0,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark23(-0.6403351015820751,0.29012612363074597,0.7327805442388495,1997.5589483169458 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark23(-0.6405329313551616,0.2309518129588972,-0.46513169771986745,-0.10493403680952812 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark23(-0.640812432036238,-0.46495704522450776,16.67167143063327,-1.6921595355153585 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark23(-0.6409104652969171,0.2889753962006999,-100.0,100.0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark23(0.6432944101682693,2.8573555699933473,26.76284795525233,-1.4286745393392737 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark23(-0.6437101204923216,-0.27757090913299615,1.1049669829179374,-6.802894921943875 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark23(-0.6454973947168638,-0.4626494658839604,0.9646235762279503,32.35988945874219 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark23(-0.6456784139916873,-0.44820009777138237,-4.135321798560294,99.38962005504197 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark23(-0.6462221190070314,-0.35743398012028715,1.1085092229009639,-69.14988016971358 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark23(-0.6469143868631093,-0.4619409699658935,0.32345719343155466,-100.29942529813681 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark23(-0.6474723308770058,-0.14283041631450288,28.323007977814285,-11.878844083124605 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark23(-0.647872758477666,0.03772543167298098,-0.4614617841586152,2.3177492006257276 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark23(0.648925967084464,-0.7338918941632813,104.81357879760233,184.490503016133 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark23(-0.6504346008217063,0.05268991936111167,0.32521730041085317,-38.7941585142336 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark23(-0.6512575906554896,-0.45976936806970325,100.0,25.914539128674363 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark23(-0.6521020726048616,0.32605103630242693,1.111449199699879,-0.9484236815486619 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark23(-0.6522952573896521,0.2662058120155909,-0.45925053470262206,2040.4032764018418 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark23(-0.6539655235305979,0.26286527973370055,0.32698276176529895,77.04258973260843 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark23(-0.6546958666425848,-0.0432760443149582,1.1127460967187404,2083.4042543610008 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark23(-0.6547733325536156,-1.1236457751730515,0.3192650933174264,-1.7916100373783694 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark23(-0.6566055260072262,0.21302964202265298,0.3283027630036131,-88.96734108882282 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark23(-0.6573437149197581,0.25610889695538025,0.32867185745987904,0.6573437149197582 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark23(-0.6573455924289573,0.25610514193698064,1.114070959611927,-228.71364279270355 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark23(-0.6576183032176199,0.14571168513294644,84.71555906221073,-94.77496818599428 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark23(-0.6582287966010117,0.22810864273064144,-0.45628376509694246,30.578654569682357 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark23(-0.6589364987473193,0.25185386481120864,-22.907873607299315,31.637421140784934 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark23(-0.6589988146868799,0.22832326822003432,0.14679138134904057,-0.6216265554901194 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark23(-0.6595843595579827,-0.07905734413487364,63.64418034124646,1926.7906199949323 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark23(-0.6598093238865903,0.16277813200299107,-119.61239615164703,-0.08138906600149555 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark23(-0.6605403495664,-0.2987022935281516,-88.40163382494087,-58.86905378979286 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark23(-0.6607466991454005,0.10496019587944849,-0.4550247146869293,0.7329180654577241 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark23(-0.6614042887634798,0.037859575453990324,100.0,100.0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark23(-0.6624555106887304,0.1753162403166948,-46.28225277436405,-100.0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark23(-0.6632893231083723,0.014208559188266278,0.37504672644129633,12.054112880944464 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark23(-0.6637652208991288,0.2432658849966387,-0.5574621087301157,0.4431779947294672 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark23(-0.6655412286179575,0.239713869558981,-79.11611731723576,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark23(-0.6672378484546457,0.1567062275094622,100.0,-0.07835315225422212 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark23(-0.6673553456941173,-0.45172049055038954,-51.379045403302804,49.063120050178355 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark23(-0.6680874559846072,0.22129894234803962,27.029129595002445,5.434883803333259 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark23(-0.6690472419358244,-0.4251549385778977,93.07533876349315,0.21257746928894236 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark23(-0.669650382987747,-1.3323815486185469,-7.041255059881724,9.122440389677365 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark23(-0.6699955376756623,0.23080525128153992,0.3349977688227369,-0.796608271481942 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark23(-0.6707576223948388,0.22928108200521813,-0.4500193522000288,-0.46945807068702083 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark23(-0.6710922810893354,-0.4427611910255229,-30.553798062905223,0.22138059551276149 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark23(-0.6720213073744762,-0.22143009404710343,-0.4493875097102102,47.734573072946894 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark23(-0.6722948959682689,-0.31512884236004957,63.292020892557424,-44.16671975544185 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark23(-0.6746422773450854,-0.10125692442648249,-0.44807702472490557,70.8835393006737 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark23(-0.6752271728876167,0.22034198101966296,-0.44778457695363993,-59.43269394393596 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark23(0.6785518593955651,-0.3437258057008218,52.28350458938748,-90.28464024326846 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark23(-0.6792110718489344,0.1386805587680936,78.7614475369429,100.0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark23(-0.6792763295127949,-1.3579693329368563,0.4993934574462165,-44.08875091922956 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark23(-0.6793050349419378,-2.6619657656772673,8.979601418791685,-100.0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark23(-0.6807168623839662,-0.40969538492989954,-56.11780506610987,1988.0612323573164 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark23(-0.6808957919334753,-0.44495026743071053,1.125846059364186,30.98609868570401 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark23(-0.6826728488435637,-0.4428563806193473,0.7921239732152179,0.33225358269228905 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark23(-0.6827698675876281,-0.2287720747952875,0.34138493379381407,-58.47273251448699 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark23(-0.68297779185712,-0.3141592653589794,1.1268870593260083,12.063581742805832 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark23(-0.6831816300222187,0.20443306674992856,78.87593591863808,-56.17591787341508 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark23(-0.6845542050749307,-0.4431210608599828,-90.78721620433896,-0.5638376329674568 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark23(-0.6851378982756096,0.05480819093169686,-90.95640530070031,-0.43085592661877864 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark23(-0.6852919659682586,0.14803214814018917,0.3426459829841293,-8.471077724082818 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark23(-0.6855330296881379,-0.43026204837215687,-13.178766832908687,73.85748377192446 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark23(-0.686946341668818,0.1922571256548832,-97.2716802499302,91.27166676560725 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark23(-0.6870141930841535,-1.3706120327867097,-0.8957161008625749,0.6853060163933549 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark23(-0.6870984874868611,0.19659935182117394,2304.8880915505124,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark23(-0.689333912158571,0.056285368363616195,17.85553591717925,-0.8135408475792564 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark23(0.6901100810853891,2.9235539161657047,-0.5549991954694353,-0.6882238100810368 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark23(-0.6928138151402727,-0.4389912558273118,-99.8982295066091,96.67025485473378 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark23(-0.6962990221016112,-0.17473551857719166,0.3481495110508056,0.3270956006395931 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark23(-0.6967168229697205,-0.39210680943624276,-63.83737752692129,0.1960534047181214 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark23(-0.6980032677625587,0.1330872505846362,-0.20070416697270382,-1.865231072899768E-15 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark23(-0.698420363007341,-0.016306125871494714,0.3492101926697498,53.21978370455927 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark23(0.6987760416070299,-2.4048729155791264,83.68910397665664,-95.40197439466253 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark23(-0.7002542130810654,0.11338828346128715,-0.1197856545031647,40.21831025488328 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark23(-0.7009009724871695,-0.16189995386289702,0.0,-0.03395304313887815 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark23(-0.701006005307844,-0.16827381319647583,1.1359011660513794,0.08409540023910465 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark23(-0.7011764010180013,0.16844352475889363,0.5486316551027506,4.689323581421432 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark23(-0.7030277914249258,-0.06494507493667911,0.35151389571246283,55.94294699679706 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark23(-0.7056740956969741,0.14719420100678865,0.3528370478484871,-48.97003808671834 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark23(-0.7059540331484341,-0.003701097365328579,-0.05234952554739036,-0.1122451432238834 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark23(-0.7069234445532186,-0.3808629808212396,1.1388598856740577,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark23(-0.7070924006332511,-0.1655115270761912,9.935577039404546,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark23(-0.7072059080881137,-0.017515220132277576,-100.19899103010496,100.0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark23(-0.7081113602558365,0.1545736062832232,-0.43134248326953006,3.082151875475631 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark23(-0.7083656230290911,-0.4312153518829026,0.2500004304529847,0.9996909190194672 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark23(-0.7086140351222765,0.12285613263820205,-0.32905272016362314,0.7239700970783474 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark23(-0.7092166971813786,-0.2778163930579737,3.9312134456629537,77.06945330638528 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark23(-0.7108338115576327,0.0,-22.122381880383493,-3.3202727882330826E-7 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark23(-0.7120216110599797,0.14669750757617447,-127.3971994564823,-0.07334862189907695 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark23(-0.7130954976094401,0.08362311837816805,0.35654774880472007,22.83374926433202 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark23(-0.7132329966374511,-0.4287816650787226,-0.4287816650787226,-12.62699848705841 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark23(-0.7173685049721428,0.13605931685061057,25.890556335373667,-94.63362049053106 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark23(-0.7174192259223067,-0.2243480445587156,0.358709612961155,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark23(-0.7175087916524472,0.1357787434900016,0.3587543958262236,-71.39707272707108 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark23(-0.7176960554912061,-0.4011492609635954,1.7817417020489258E-8,0.24001765569964928 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark23(-0.7190451211880062,3.240478240129973E-4,-0.1254641242818277,0.0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark23(-0.7197213250684247,-0.42553750086323583,-0.42553750086323616,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark23(-0.7204376691899059,-0.4251793288024952,0.06763149139820752,-0.5728084989962007 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark23(-0.7206867654966297,0.11096277003666215,-185.95032801231923,-57.377670636359156 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark23(-0.7218796768900972,-0.40855021154604215,0.3609398384450486,-9.16896769473691 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark23(-0.7226725223857752,0.12545128202334072,100.0,-0.06272564101167036 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark23(-0.7228529764970159,-0.4095712088295663,-56.212444164491316,0.9901837678122314 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark23(-0.7233106957760489,0.12417493524279798,1.1470535112854727,-59.74929813649004 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark23(-0.7237859831254385,0.0311968553427861,0.3203801913030828,0.7697997357260551 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark23(-0.724834434800803,-0.42134879269403935,100.0,61.90442671008517 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark23(-0.7250040297328865,0.12078826732912207,-0.42289614853100504,-17.219722111730285 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark23(-0.7255748350252762,-0.4014868869695025,-75.72718281037784,57.970500898865836 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark23(-0.7256374697860111,-0.02250187447983043,61.1829630708865,-19.5790447318966 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark23(-0.7268272944278564,0.1171417379391737,0.3634136472139282,0.7268272944278619 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark23(-0.7277442661684225,-0.4215260303132369,66.19199893997036,-4.719991524219672 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark23(-0.7287256491218318,-1.1016184375001699,93.37492605545337,100.0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark23(-0.7288998760736949,0.11299657464750656,-19.73647825017014,-0.033746574259438944 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark23(-0.7309095833454273,0.09817967825844603,100.0,48.466283274808575 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark23(-0.7310912863764266,-0.20615917173527265,0.5240148758370887,-38.49246586323607 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark23(-0.7342096829891012,0.10237696081669402,-17.484788396733837,-0.05118848040834701 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark23(-0.734420861975062,-0.01339040092836459,-0.14659294841587328,0.058263756379987576 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark23(-0.7354854499424358,-0.05912281383831488,0.3677427249712179,-0.7558367564782908 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark23(-0.736398273719898,1.3050608935997049E-54,0.008541729205281545,-0.16070819176737125 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark23(-0.7368572363393447,-0.41696954522777574,-0.12959569973148288,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark23(-0.7369409324459518,0.09691446190299279,-0.41692769717447237,0.6423949982712323 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark23(-0.740445144546167,-0.04591515661355707,-12.224246357416956,-13.73616349950686 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark23(-0.7405835738376467,0.07091308132680348,0.3702917869188234,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark23(-0.7409967793947575,-0.41103838245998414,-6.779498792714256,0.9909173546274405 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark23(-0.7419090460974885,-0.24454747024730583,0.37095452304874427,-0.6631244282737954 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark23(-0.7420386539211998,-0.0939661101201078,-0.4143788364368488,-28.852761105574118 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark23(-0.7420620825199353,0.08667216175502557,-97.97916456232842,92.46961854048308 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark23(-0.7423851992941546,-0.10870199925528701,0.3711925996470773,97.78829125252035 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark23(-0.7425073754251152,0.08578157588191121,-80.4157542989652,-100.0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark23(-0.7427658475417679,-0.3344515970554412,68.08225824920473,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark23(-0.74634033695821,0.07069148181566695,-0.4122279949183432,-88.84010845100697 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark23(-0.7464835073162052,-0.3836708512190863,-3.8292067584870293,1733.1352264103207 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark23(-0.7478742859248053,0.07504775494213976,-0.41146102043504557,-242.73474258779035 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark23(-0.7496592259126661,0.04498162766993774,0.3748296129563329,41.82474166746459 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark23(-0.7497493966320589,-0.026766296098008735,-50.833071120337344,63.76312504615608 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark23(0.7536887986965048,3.078173924187902,100.0,-0.753688798696502 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark23(-0.7538480308833935,0.06310026502810939,-100.0,19.76203417494072 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark23(-0.754526990006558,-0.007769929468838921,-100.32335720323877,100.0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark23(-0.7545732667441356,-0.40608475022924695,-100.0,0.2030423751146235 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark23(-0.7548094704263603,0.061177385942175894,-77.0705776544854,24.34743189314446 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark23(-0.7561399758133482,-0.2070613217693712,3.5991273991618553,0.10353066088468554 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark23(-0.7567951870613425,-0.36151263855924015,-19.95453569185476,-19.29959757062457 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark23(-0.7597559270855475,-0.40550324237373825,0.3798779635427737,-0.5826465422105791 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark23(-0.7601180014792057,0.008849718365581793,1.1654571641370506,-53.95189737726216 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark23(-0.7604859946357202,-0.0026005440603221325,-23.252085188817492,2.3582879098227068 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark23(-0.7610637831301805,-0.18971774849981435,0.9381860099398244,-0.6905392891475411 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark23(-0.7617480236794942,-0.03695678434480394,11.956430597682878,0.018478392172402103 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark23(-0.7634614501456052,-0.4036674383246456,1.1291355392312925,10.580815033449268 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark23(-0.7643680639396171,-0.4032141314276396,0.38218403196980855,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark23(-0.7649610387993087,-0.07216877811936155,0.3417557950927834,51.30245378114423 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark23(-0.765444256373849,0.012144647732692547,1.1681202915843727,0.779325839531102 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark23(0.7666136064320581,2.0823455755911637,-78.20022373051323,-100.0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark23(-0.7666662665863178,-0.3867514852596697,1.1687312966906072,0.7666662665863175 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark23(-0.7680113207069041,-0.3714673744245352,-26.637699201751005,-0.5996644761851807 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark23(-0.7688242326428245,0.03314786150924437,0.38441211632141226,65.78882203583447 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark23(-0.7690302695624591,-0.26350856285408514,-67.32650278913363,-0.016799891806606126 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark23(-0.7690770137248067,0.032642299345282844,0.8836459272112718,-0.016321149672641866 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark23(-0.7701020192883163,-0.0636260450871795,24.954376042813266,-53.77116065813268 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark23(-0.7702864426284769,0.03022344153794221,-100.0,0.7702864426284771 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark23(-0.7703402370285841,-0.2935560387602488,-0.4002280448831562,0.9321761827775727 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark23(-0.7715148396527276,-0.2855060378027921,48.29448024719354,0.9281511822988443 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark23(-0.7743005376021618,0.022149983834919704,0.3871502688010809,-0.7964731553149081 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark23(0.7761366983185448,3.6260248721545976,-144.1473163415305,106.57242075048387 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark23(-0.7775751733963474,-0.39661057669927446,-56.07853668013944,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark23(-0.7784900059670734,-0.04831995421447899,-129.20145179030158,0.8095581405046878 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark23(-0.7786797557041322,-1.538901215262758,-127.38045929814994,126.4293026525972 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark23(-0.780260327255223,-0.21167675961817922,-86.98194084054899,-58.86485841684451 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark23(-0.7807890341947067,0.009218258405414159,0.5490071086903487,0.7807890341947412 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark23(-0.78126278675402,-0.16106367099351493,49.8291799159902,-84.9940195507908 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark23(-0.7815583569204989,-0.09313809757727642,41.80874314712378,40.55695882226661 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark23(-0.7816024350204225,-0.39459694588723615,-0.39459694588723704,82.61590877406303 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark23(-0.7818074807625695,-0.03366608592577627,0.9379385655630674,0.016833042962888144 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark23(-0.7819484923729019,0.006899342049092594,-0.39442391721099734,98.69142757516235 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark23(-0.7820003572166898,-0.25990641237014694,-20.58621916876531,30.871303446807076 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark23(-0.782018784886095,-0.07343562065547515,-142.59586936576002,39.07966554933041 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark23(-0.7849475831715912,-0.5953271565192528,60.582364154528356,5.744157231696448 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark23(-0.7849926711709934,-0.2579188815003379,-78.07387230741966,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark23(-0.7852146356926689,-1.061923591045045,-0.3926434934683735,-0.25443636787494484 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark23(-0.7868667096891453,-0.1866129974416251,1.3866695599588098E-32,0.09087130691151214 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark23(-0.7871876204792644,-0.2921888104166458,0.6392839299115993,55.17492838903637 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark23(-0.7872972471200717,-0.0037981674452470526,0.5479434836684216,-0.6438706168054866 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark23(-0.787743953522499,-0.39152618663619865,99.96496871214009,0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark23(-0.7878881666337083,-0.014622393061170637,67.14411805960206,0.7927093599280336 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark23(-0.789299683422329,-0.01945953258365732,-0.0711488075018607,0.009729766291828661 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark23(-0.7895010905738769,-0.021206258971074532,-0.34838110245794496,67.63799193400004 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark23(-0.789605677858281,-0.32828447617644996,-97.93804530204719,1.2733803583525543 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark23(-0.7898979826401415,-0.3832357694670134,51.135831316790295,0.1916178847335067 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark23(-0.7901139536676945,-0.1486333128458541,-19.55095392393173,0.07431665642292706 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark23(-0.7913421438690028,-0.35442295665166856,-5.360632685199493,29.981870670700133 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark23(-0.7921846641542445,-0.013573001513592543,1.1814904954745704,15.59087314010548 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark23(-0.7928220162000366,-0.014847705605176842,1.1818091714974666,-1.16009001460279 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark23(-0.7928876466943929,-0.014978966593889476,100.0,-0.7779086801005035 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark23(-0.7930743177303676,-0.12613730342558105,-91.30582640516324,0.06306865171279075 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark23(-0.7931773594055858,-0.32399629655940965,0.3965886797027928,0.16199814827970485 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark23(-0.7931954212878233,-0.028191966066540272,-72.19938459576397,3.119229986811794E-10 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark23(-0.7958750317705139,-0.30905752340319453,-2177.366510459905,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark23(-0.7962827266370611,-0.3680496745912082,1.0976598827221957,-100.0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark23(-0.7970485042419231,-0.023300681688949942,-4.181664576965957,74.81358396348928 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark23(-0.7996420111699625,-0.3106930774579475,-51.48183236026987,0.15534653872897386 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark23(-0.7997967028635932,-0.38549981196565036,0.39989835143179675,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark23(-0.8012524276732886,-0.19635641436607604,-0.19258395859521404,0.09817820718303799 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark23(-0.8032726191541845,-0.03574892078506102,0.8563771830345746,0.01390908178428063 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark23(-0.8039450975113417,-0.3834256146417773,1.1873707121531192,-97.59697271533994 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark23(-0.8058006056840838,-0.22916369461235178,0.9471508459996201,-2174.0911123775395 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark23(-0.8077429574921453,-0.04468958819546544,-54.516662090213046,18.41758799425957 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark23(-0.8081298557095679,-0.04546338462424094,1.1894630912522322,-96.50427495761825 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark23(-0.8095022517464592,-0.04820817669802206,-0.27238197748240156,0.0344557060668812 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark23(-0.8113058697678204,-0.051815412740745526,0.9125317621317004,73.06003055071862 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark23(-0.8120111149676388,-0.05675715919222331,39.98617132183405,0.028378579596111654 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark23(-0.8126748246506301,-0.22832787078348793,91.49205793536107,-4.901903853550049 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark23(-0.8127878143370494,-0.07461376951012094,0.4063939071685247,-0.7480912786423878 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark23(-0.8134761937969968,-0.33847371253940295,10.455819633217313,44.39339356176919 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark23(-0.8159263938630158,-0.06105646093113526,-17.885956247949338,56.5629896708121 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark23(-0.8160802833727742,-0.37735802171106103,-26.975972254147273,-1057.4627764228737 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark23(-0.8171370783309992,-0.37497246159350944,-5.708876182407117,1.5000344307205085 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark23(-0.8182465188728553,-0.06787113211821078,-0.37627490396102065,-1.409512189456184 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark23(-0.8184561581367886,-0.06611598947868091,100.0,-30.012516413665843 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark23(-0.818617782871834,-0.06643923894880525,100.0,-0.08426038116556657 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark23(-0.8186554830934202,-0.14502993780568166,3.2311742677852644E-27,0.07709783878475412 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark23(-0.8189355287446801,-0.08449169543941383,85.55122791741334,0.042245847719706964 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark23(0.8194087046179412,3.176562801948883,96.9799610012348,-11.513044922584179 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark23(-0.8197925491842784,-0.07184328896502268,8.297089834243302E-12,1.2047031065304088E-8 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark23(-0.8201403489243266,-0.06948437115088417,6.759264336662994,-6.535885833648748 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark23(0.8212251954476394,3.199726392778531,-1.3251451086681385,43.179629603817986 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark23(-0.8215265094473112,-0.2375101078728976,1.196161418121104,-1939.1605212953705 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark23(-0.8224195030363342,-0.3741884118792811,-0.37418841187928126,0.18709420593964077 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark23(-0.8227265578859979,-0.37402419098553336,0.1314503095189266,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark23(-0.8243662957857555,-0.35565844230879184,-46.35230296801255,181.7077386140544 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark23(-0.8247229460171941,-0.1546361701551833,0.012262279406916585,0.0802642788650772 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark23(-0.8251598711213451,-0.0795234167338889,-0.37281822783677576,0.8251598711695396 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark23(-0.8256739325885211,-0.08899572070804214,1.1982351296917089,19.06057277269865 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark23(-0.8258494766673856,-0.30131271877754773,88.20468019595103,-31.677039156187895 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark23(-0.827606381517134,-0.08441643623937178,0.4928801141364838,-50.895724178219936 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark23(-0.8276425432871332,-0.08448889395443462,100.0,44.42330259950482 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark23(-0.827886217813024,-0.08497610883115314,-64.04596047689718,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark23(-0.8291800205123712,-0.08756371422984613,-99.40889983479056,97.87318811104308 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark23(-0.8294547672769661,-0.3677202214765052,-47.525474887106135,0.9692582741357009 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark23(-0.8316680813360993,-0.09253983587757617,1.201232204065498,-26.40573693088598 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark23(-0.8320122354454,-0.09322814409614519,100.0,0.8296903048141477 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark23(-0.8320718342056992,-0.09334734161650715,0.4160359171028496,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark23(-0.8343378291484226,-0.09797615644497416,-32.720708282635485,0.8343862416199354 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark23(-0.8346255551513987,-0.2381204236922975,35.070173180993926,-27.130881809164723 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark23(-0.8355687097369608,-0.3141592653589784,53.88350434502788,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark23(-0.8365190250300467,-0.267674409746088,-0.36713865088242487,0.133837204873044 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark23(-0.8367615713366865,-0.10272681587847665,-0.36701737772910503,-13.504389037968346 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark23(-0.8373148274348248,-0.10383332807475337,-10.267920751942313,0.051916664037376714 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark23(-0.8380168418160008,-0.10527064722031058,-0.3663897424894479,-0.732762839787293 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark23(-0.8384591540257628,-0.1061219812566292,-0.07856963190160975,0.8384591540257629 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark23(-0.838650784404402,-0.3121714772611375,0.419325392202201,0.1560857386305687 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark23(-0.8393279389511176,-0.11215196015676922,0.192330045732496,-2048.5151444753797 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark23(-0.8411029481584105,-0.3648466893182425,-84.94733266108143,98.89927039986628 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark23(-0.8418058748771456,-0.7299091153239207,1.2063011008360212,-72.67707463857853 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark23(-0.8421645956142927,-0.19680119192666187,-73.97388481572662,0.09840059596333094 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark23(-0.8423722824099951,-0.34620686165941983,60.392771454681494,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark23(-0.8429659926429107,-0.11513565849092504,-0.363915167075993,-65.82077701194859 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark23(-0.8430153890263092,-0.36389046888429344,90.78410132372974,0.1819452344421466 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark23(-0.8434216207554193,-0.2940132940856195,33.11927649374035,-100.24174063052982 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark23(-0.8438187245412352,-0.16684872027151523,-88.37045105208578,0.0834243601357576 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark23(-0.8447838407759998,-0.2838618604555686,-0.0699846575109205,59.152791534450216 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark23(-0.8448728074751539,-0.2558407194806364,-38.89991998177658,100.0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark23(-0.8454451312625646,-0.12009393573023663,-100.0,28.89474822724627 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark23(-0.8472038596414027,-0.2688602272170413,1.2090000932181495,-0.6509680497889276 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark23(-0.8472814390544992,-0.12376655131410429,-54.915129235459794,0.7044724061979508 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark23(-0.8484891175795957,-0.12618190836429655,100.0,11.669543834651055 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark23(-0.8493546912778507,-0.12791305576080528,-0.8698474635110784,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark23(-0.8499447106681352,-0.12909309459770596,-0.36042580806338076,66.71609173874899 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark23(-0.8511972452467998,-0.20352436021485554,-69.66338357355345,93.55839251445863 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark23(-0.8516342085866369,-0.15191480082313902,-40.78228796831879,0.8613555638090178 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark23(-0.8522142153314394,-0.27454002294446844,1.2115052710631677,-0.7991296984545563 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark23(-0.8524589768723532,-0.35128633742827475,-182.14843464411314,-0.6081754270111769 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark23(-0.8526252638568814,-0.27268080743034595,0,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark23(-0.8539278291613924,-0.17953278952247279,0.4269639145806962,-0.6956317686362119 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark23(0.8541923406986162,1.8487128762762555,15.584760117327065,-0.13895827473985733 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark23(-0.8542427625886768,-0.1376891983824584,-77.01129219489759,65.0083997236126 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark23(-0.8549715022019091,-0.2363410576410414,-2.465190328815662E-32,0.2036528133649364 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark23(0.8550561907784725,3.2809087083518413,-4.331237093481088,-83.32967656787548 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark23(-0.8553735337343422,-0.3229304243010132,-92.83361044477937,0.9468633755479547 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark23(0.8571066873914235,-1.2101396528405288,-1.3543452975824135,-234.1954255413171 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark23(-0.8587138478208202,-0.3560410853550192,53.545722088781645,-0.6073776207199384 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark23(-0.8593475126661686,-0.20729914119695403,-43.59365823053525,-81.58104454135702 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark23(-0.8593562270729278,-0.14791612735184753,0.4296781135364639,0.07395806367592377 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark23(-0.8607129651684546,-0.15364373402521192,66.39605662098293,92.00932163714847 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark23(-0.8610233301514643,-0.1523752656752073,-2.7116880420261538,-99.975408983542 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark23(-0.8622072859698885,-0.16660015546741005,-0.3542945204125041,-57.10497933561253 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark23(-0.8628444840441256,-0.16194632484226065,-61.01067153287164,100.0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark23(-0.8642092788680595,-0.15837408123870392,12.37196568639159,-0.7062111227780963 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark23(-0.8648817161520119,-0.15896710550913476,0.4324408580760058,205.89198597638014 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark23(-0.8664488294400443,-0.24943553660860296,-0.3521737486774262,0.12471776830430104 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark23(-0.866493972120128,-0.23635441875851274,-42.14146998547683,0.11817720937925635 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark23(-0.8671643084154868,-0.16353229003607725,12.495196701464678,72.17809933676651 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark23(-0.8672077144637269,-0.3517943061655848,0,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark23(-0.8683810654333196,-0.1672235221255276,19.860372346873167,1.6537792288307713 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark23(-0.8687256478169488,-0.16665496883902586,100.0,-0.43726148964747247 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark23(-0.8688682978360267,-0.21119793797986777,-0.3509640144794349,-0.6797991944075144 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark23(-0.8696144128259854,-0.27673842148456335,68.76446787934135,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark23(-0.8702021316216918,-0.20734724582645078,1.2204992292082941,1.6504184825733574 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark23(-0.8712157362250484,-0.32299478481041805,100.0,0.9468955558026432 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark23(-0.8717288274988932,-0.34442952097924395,0.4358644137494466,0.17221476048962192 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark23(-0.8717303957270086,-0.17266446465912091,1.016783846971357,-32.976000417217875 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark23(-0.8721652543952823,-0.21422201041665817,1.2214807905950895,5.588566872924117 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark23(-0.8729330661880291,-0.34893163030343377,-100.0,1.4686572786209473 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark23(-0.8742053657413826,-0.17761440498432166,-80.59639888249131,11.665910200039624 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark23(-0.8754373098122075,-0.22871519557566133,-0.04836736139796599,0.8997557611852789 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark23(-0.8767439352293706,-0.18378618520312168,0.4383719676146853,0.09189309260156087 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark23(-0.8786041175640962,-0.18641190833329635,0.21621724304814857,0.0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark23(-0.8818954958939915,-0.19299466499308662,-13.76372865126011,-38.06089835157275 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark23(-0.8820953809631102,-0.20182634862667714,-90.8344465365902,8.3215410628923 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark23(-0.8823434391851317,-0.3442264438048823,19.965970379092603,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark23(-0.8827313981071333,-0.21025279827352003,1.2129068420722244,7.2671851456548815 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark23(-0.884460735416931,-0.3072168688143761,0.005181765578405231,-149.22864815836266 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark23(-0.8854319307480762,-0.3362842475039907,-0.3426821980234104,27.550236260021506 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark23(-0.8865741393562625,-0.2023519519176286,-15.553222934426806,1010.7490592079367 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark23(-0.8866479274267809,-0.21731677219489126,-0.3420741996840579,0.10865838609744563 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark23(-0.8879811596165192,-0.3024104308935114,0.7020400663120594,49.08730608633705 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark23(-0.8900325165511567,-0.34038190512186983,100.0,-58.91853203465756 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark23(-0.8901081308947308,-1.2920900308968557,84.98077936937979,-92.82061755936765 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark23(-0.8901927020004855,-0.2095890772060746,1.230494514397691,0.8846775144928369 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark23(-0.8912300688908956,-0.21166381098689485,-24.91187002653827,12.40680766764548 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark23(-0.892178313501804,-0.21356030020915587,0.446089156750902,24.01763238189656 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark23(-0.8923433472272198,-0.28887354429094136,1.2315698370110582,25.26878278827015 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark23(-0.8929833635857893,0.10388348583449776,-62.38550421018584,-0.8262378288257362 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark23(-0.8932956766710289,-1.687702014099416,0.9812391874456323,97.44137473696115 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark23(-0.8934093829555545,-0.33201678167656384,-81.3192180237959,0.16600839083828192 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark23(-0.8937501639122052,-0.22066787888845943,-93.72013654427047,0.11033393944422976 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark23(-0.8947289985887513,-0.2368507335315448,-46.14157808304965,-40.07233070208024 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark23(-0.8952400136061602,-0.21968370041742435,100.0,2120.269015742016 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark23(-0.8955459943614271,-0.22033859155801536,0.1353572204347954,0.11038355625088545 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark23(-0.8955496984537229,-0.22179427221383408,-153.74813541642177,0.07663654528740454 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark23(-0.8957450271318437,0.447863482277041,0.5146963188596815,9.696194936131278 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark23(-0.8958887499625505,-0.3332761906185852,0.20387584654196605,0.21861621260275085 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark23(-0.896368968193797,-0.22194162181204388,-21.273538279120164,39.44707289326325 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark23(-0.8969502336289952,-0.2231041404630948,-62.43343414313411,-6.571768455314462 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark23(-0.8979140883774231,-0.8265986862477274,0.4489570441887116,151.86619601566227 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark23(-0.898786303025783,-0.22890705161525726,1.1148772770771411,0.11445352580762863 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark23(-0.8989863072048077,-0.27348282118631473,-0.3359050097950558,51.13639189209566 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark23(-0.9005498319486959,-0.25977076364511614,0.45027491597434793,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark23(-0.9011653734596078,-0.3141228389034144,0.4203274363570018,0.9424595828491554 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark23(-0.9012475242274751,-0.27255609098306227,100.0,-73.74300899179492 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark23(-0.9017416004273141,-0.23268687405973199,0.45087080021365705,-43.73172358032514 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark23(-0.9042223230646175,-0.24358027109944613,-0.33328700186514,0.9071882989471713 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark23(-0.9054066440800295,-0.2640139441032689,0.45270332204001473,-0.6533911913458138 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark23(-0.9054703488424098,-0.2717067647992555,-0.33266298897624336,-949.4482321240164 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark23(-0.905995813892197,-0.2411953009894976,1.2115996432735692,-100.0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark23(-0.9066537780119969,-0.3320712743914493,47.66069830949164,0.16603563719572467 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark23(-0.9070478427116445,-0.3212596322674794,-0.3318742420416261,67.25021224775273 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark23(-0.9089330155299638,-0.29165975615088,-0.015696093988873876,7.804843374119329 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark23(-0.9105651824621303,-0.33003448089606563,-0.3301155721663831,-10.693900625564735 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark23(-0.9106747047120416,-0.33006081104142737,-0.3300608110414275,-0.6203677578767346 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark23(-0.9142813180151983,-0.3261909404763179,75.42073653140406,-14.214986016563685 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark23(0.9143550812525278,2.675083465385258,0.328220622556253,54.426002558682995 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark23(-0.9144462956864167,-0.25809626457793716,-2.559631499142971,99.00020656750644 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark23(-0.9176716458237549,-0.27197424719602037,63.40253076678654,-59.428489756355525 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark23(-0.921896279114379,-0.32445002384025856,-93.30606064086719,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark23(-0.9222672010671664,-0.27899911742495975,-0.32426456286386507,21.401214624883806 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark23(-0.9227493776946254,-0.3069592170273249,12.558093637458152,-1796.3420383096875 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark23(-0.9227518543722767,-0.27470738194965705,52.23495494581636,0.13735369097482852 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark23(-0.9240033424050127,-0.3233964921949418,25.30342497185078,-0.6236999172999773 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark23(-0.9243279913002235,-0.2924218182335383,6.673641298199698,-54.94517952352033 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark23(-0.9247305700419299,0.06323079078430122,78.9822858620987,0.7734195940820854 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark23(-0.925453869378298,-1.073310173228712,-122.49846464777872,0.5306789610969476 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark23(-0.9264151460664924,-0.2820339653380885,5.7468790485788475,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark23(-0.9269372713650377,-0.2830782159364056,-9.608479894163494,-63.11726743530943 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark23(-0.928211008235675,-0.28562568967675217,69.39186832621645,-27.546739905570604 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark23(-0.9283838028443245,-0.28597869568198,-34.35891760442934,-96.47232495309326 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark23(-0.9304368492007773,-0.29803090228628015,46.74654366521452,-21.373298593445565 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark23(-0.9314725565861682,-0.3171106308544193,60.25129544675278,0.15855532415620915 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark23(-0.9323126942639408,-0.2938290617334758,66.42850781924015,-82.71661962265361 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark23(-0.9331587811965619,-0.29552123569801453,25.04490622288851,1890.3497510260318 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark23(-0.9339994849930937,-0.3018148818790299,-28.299827900091838,-84.84275260070181 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark23(-0.935277898189908,-0.29975946958499117,-97.09373439445434,-26.027370430833958 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark23(-0.9390743731644549,-0.309565667660707,-62.3929141043437,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark23(-0.9391605456141316,-0.3100785529638008,0.46709474816499635,0.14369040947836798 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark23(-0.9391749689417168,-0.3157510125328573,94.72301500890276,0.9432736696638769 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark23(-0.9400098711922751,-0.3105652572800424,20.01748332278449,5.61744416690294 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark23(-0.941301527591505,-0.31472039739079044,0.47123889803846675,100.0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark23(-0.9415670878661295,-0.3123378489373651,1.256181707330513,0.15616892446868258 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark23(-0.9415910096774851,-0.3125294158392708,-93.06133578127809,-95.9843249218439 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark23(-0.941660490421845,-0.31294112634263027,47.25927590544748,0.15647056317131508 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark23(-0.9424777960756208,-0.3141592653594447,0.4712388980377127,100.0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark23(-0.9424777960763908,-0.3141592653578864,-29.291773756220817,100.0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark23(-0.9424777960769347,-0.31415926535898037,-97.99051386998195,0.15707963267949018 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark23(-0.9514062421881637,0.45375784099866256,28.082438305752824,-24.635065731610894 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark23(0.9578444593826703,2.492665336392783,-0.6419389976345293,-2.5872917267709363 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark23(-0.9594239496245345,-0.2644342780543028,-38.792996316167155,0.9176153024245997 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark23(0.9609915882912092,-0.5354979477182964,-28.40715714641843,54.51244119867434 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark23(-0.9724461551030591,0.9492548538379907,9.825244251410663,17.602520555044237 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark23(-10.021697306114984,-20.02420556938171,-67.53939203260987,20.21920097238393 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark23(10.051165130325842,6.686139475418784,-92.45183704543318,-3.2700222234232967 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark23(10.206055490346348,21.98290730748759,-4.949402082751156,-10.991468716105103 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark23(-1.0255033119011472,-2.0510066238022038,13.261874764043217,1.8109014752985502 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark23(-1.0313511337573957,0.463308559390722,100.0,-71.68942872046932 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark23(-1.0435783887164387,-0.287587911148826,-143.21185675319472,14.895337757581785 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark23(-10.461481759936985,-19.352167193079076,5.097072170117939,82.84232249372319 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark23(1.0476642859742582,3.663306215171228,-1.3092303063845774,-1.045416754978292 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark23(-1.0490899366488227,1.0153113255280606,-119.04817967369395,-94.7863698153636 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark23(-1.0634541134439197,-0.052899902850534586,-100.0,-0.758948211972181 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark23(-1.06587199479284,-0.18061840105881943,-100.0,-95.01598871186089 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark23(-1.0691955110052038,-0.24348330394462303,-100.0,61.693277131207346 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark23(-1.069327049321081,-0.2445242357251704,-100.0,-0.646886789394228 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark23(10.706189682647285,-5.358604027184049,-56.40181979241924,59.469516648245495 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark23(-10.725932641682759,4.57756819694605,2.1477907222924224,-100.0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark23(-1.0799446454679722,-2.158613631916145,100.0,54.48625526756611 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark23(1.0902247015175897,-2.8884215663111656,-0.545011733951368,46.99729548483493 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark23(10.956195348467944,-5.483704213027611,73.2252941739463,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark23(1.1192875557423345,-0.5853085433342097,14.613313183664946,-100.0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark23(-1.1202440017643924,-0.6696916767338885,0.5601220008821961,1.8796391520681794 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark23(-1.1226997590009038,-0.222492304364185,-100.0,0.13516380733135208 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark23(11.25002008714916,24.070836501093215,-5.6255649239136805,-100.0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark23(11.28273588512191,-5.641368077863547,57.57328675213425,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark23(-11.333816700165276,-22.60701881644312,1.9681993406594462,8.946925410270005 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark23(-1.1376170176920666,-1.9387482247816483,22.73393211913,-65.79027509476802 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark23(11.411060032422686,24.152473549619383,104.8400101036341,26.40828561465321 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark23(-11.437829859376532,-17.351482038866607,-25.1616321176719,-64.37712794529068 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark23(-1.144889064026355,0.0021013975711829426,-61.51963818382213,-100.0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark23(1.1469206308284778,-0.749232011964805,-74.00609452377984,10.557802882235592 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark23(-11.494135066768973,-22.977472020606942,6.531067661909192,8.330814538508823 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark23(-1.1499221111935929,-2.2998429533312543,0.2562484598433213,1.9353196401775357 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark23(-1.1595853447461686,-0.7483756277980729,-35.587530423905136,158.96047293087537 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark23(1.166701270660007,-1.1451231129537902,-0.5737634206096158,28.845837987667046 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark23(11.804647542388208,23.609295084776416,-6.169145142419281,-57.30427584987589 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark23(1.18308435403162,-0.7887938040199118,0.19393158235682229,0.3943969020099559 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark23(-1.1845099905607188,-1.0837088621810191,-100.0,-99.99573143240356 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark23(-1.1850071275256577,-2.3700142550513124,1.3779017271602774,1.1850071275256562 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark23(-1.1865400633124226,-2.3580360842629178,0.593281607452705,60.86717324642714 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark23(-1.1918764797554147,-0.00827761034734742,-37.900947319282615,-84.27653942066652 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark23(-1.1933605688341395,-1.2075520720819264,1.382078447814518,95.45774330068544 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark23(-11.952801889407361,13.91783102413881,0,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark23(-1.1982591279690986,-1.0806052354568203,-0.18626859941289894,100.0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark23(-1.2215685820941848,0.25795018722787644,-45.981242752443436,-0.12893020476034933 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark23(-12.225696124905596,-24.449696530405806,5.191139331004016,82.13520948409759 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark23(-12.359314385016704,6.146933463444049,5.568088521685497,-2.288068568324576 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark23(-1.2404478378053985,-2.4782691969957926,0.34747620088193676,46.00591518278508 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark23(-1.2467606705221974,-0.9227250142494985,-0.1620178281363495,45.99898607197983 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark23(-1.2592826119622262,-2.4966953130698255,0.6296413059811131,-29.3823804170228 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark23(12.682358778703891,-6.34117953327036,-81.4838717549176,3.955987929600162 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark23(-1.2711774028950054,-0.12368355063930318,54.03627781922931,84.10300571656835 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark23(-1.2803682765696753,-1.4371145378137722,0.6401132337612294,-82.82514901219481 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark23(-1.2824797025879258,0.6373483212176135,-17.720717686795567,-12.88463468212963 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark23(-1.2885712714784603,-2.5771425429569206,-15.019768257462035,79.77755580079067 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark23(1.2905347007091403,-1.4306655137520183,0.1436836159466108,-41.697163645414726 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark23(1.2906899490389607,-0.6454190757329242,-68.97461636295334,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark23(-1.2936473654595324,-2.587294730849741,94.44304279724984,0.5082492020274223 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark23(1.2964993546909764,4.159934731808756,-1.6812295738781016,-2.865365529301826 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark23(12.978613748362248,-6.625744147044883,55.85293055090475,0.9814387123537098 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark23(1.3082559096918012,4.1873081461784984,77.18621421775514,-4.448317832470698 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark23(-13.13410441779006,-24.921101102524727,7.352450372292478,-100.0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark23(-1.3143370655793887,-1.0640918493006726,0.9431663718922562,-0.2533522387471121 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark23(-1.3180738072298386,0.22683461904045532,0.13562358037238598,-98.57675970660803 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark23(-13.374477929651789,47.36955951698337,17.537038711025716,-64.27194947609189 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark23(1.3465818035903947,-0.6744127418829677,-151.46627009191917,2.4211934303423925 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark23(-1.3472183844060792,-1.7867253257323688,-103.10363421922617,-58.680293392754095 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark23(13.493663829810316,-96.33771177972925,41.376060678267976,-69.22293391409247 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark23(-13.628408308193851,6.028806057447277,-100.0,-3.0144030287236845 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark23(-13.801936423499871,-26.033076520204848,0,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark23(13.859065037304191,27.71813746185957,-7.714930682049544,-42.1142874926109 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark23(-1.3880845985184278,-2.5528232539100952,-0.09135586413823438,-43.491420181403434 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark23(1.395639189345412,2.791308560567154,-1.4832177580701544,100.0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark23(14.051733090530645,29.674262507856184,-32.83993838343926,-14.837131253928092 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark23(1.413561744329909,-1.4921790355624027,0.07861729123249378,-29.098706388947956 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark23(-14.180870694820687,-26.79094506284648,0,0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark23(-1.4213392226778427,0.1663122411331286,32.12422827898798,-0.08360331759786474 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark23(-1.4253501538346718,0.6437834597964872,49.95816202612703,0.47633270912631254 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark23(-1.4273287835088557,-2.379038532436084,90.74847430760059,0.40412110282059305 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark23(1.4615139521800469,2.926689802343107,0.05464118730742484,-1.4633449011715534 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark23(14.681711829169526,30.9342171176073,-100.63509664485149,-68.08878550643269 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark23(1.4743690871234594,4.518869060977996,-73.30378616599828,42.50828671988171 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark23(1.4817003994785758,4.534197125752048,-69.82099249648314,-93.37314507693337 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark23(-15.2335091178061,-58.788178747895024,-99.8172497093765,29.394089373947512 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark23(1.5399836232699344,-0.7747785297159471,31.431779089971663,0.38738926485797354 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark23(-1.543899371787224,-2.0160580137041775,47.88496470171045,-11.621446777083579 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark23(15.534761546494792,-7.767380773247396,-58.708133220168385,100.0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark23(-1.5611853744568727,-3.122370748897826,82.61158526619431,1.561185374448913 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark23(-1.5645489983258212,-0.002779607991063459,55.00595847860447,-0.001757698641390676 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark23(-1.5693452433127586,-3.053914956241022,-74.817201297743,36.8588596473616 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark23(-1.5733199706699728,-2.759110623362684,-74.09124401840616,61.06345349982114 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark23(-15.91269294428281,34.7722431503515,-33.97883945127778,34.5172810502755 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark23(-1.607346866000172,-3.214693731993615,-51.80630190575437,0.8219487025993591 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark23(1.6090680204084886,-1.126875968957776,39.591168841151344,-78.31194492693923 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark23(-1.615955472038574,-3.225491211134592,1.5934029614607372,-100.0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark23(16.279973272883822,32.85033164430948,-8.139986636441911,-21.63755480253941 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark23(16.282250624069476,-8.926523475432187,55.054647431231544,4.2986718838782645 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark23(16.292054841304484,34.15490600940386,0,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark23(-1.6441941344947746,-3.288057768376557,0.036698903849939124,39.343131128222836 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark23(1.6546109708347012,4.879778668792017,-0.04190728716767975,-41.70979724086744 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark23(-1.6547294244824802,-3.3094360637635822,-21.003281471191663,89.61916200183146 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark23(16.629302345793693,-8.314845633426298,81.34580774203113,0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark23(1.6673081270046608,4.832241098225528,-0.8336540665628331,-1.6307223857153155 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark23(16.745489472880127,-10.020441745810553,-9.15814398081221,-106.51596596395547 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark23(16.80441079039217,60.538332077320604,88.8405268722505,84.97847772410435 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark23(-16.86048961357992,-33.42819707783669,22.62908689909793,16.71405957721699 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark23(-16.985461746306438,-32.774536497192486,24.19228174491714,44.66060779041041 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark23(16.9894935841153,-1.280144955360136,-100.0,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark23(-1.7055682830083287,0.7437097281078622,1.8261077750024646,75.81752316101637 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark23(-17.296786685158885,-34.593570270523784,21.959060608495932,17.296785135261892 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark23(1.7370261281257067,-0.8708761141006686,15.625845103990322,0.4446364043409333 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark23(-1.74295485328329E-10,1.7027914672773147E-12,-51.48595113914133,-26.341320692610253 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark23(-1.7452777300908267,0.49285915866317137,-0.36043750233992355,-187.30333748429243 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark23(17.527462618952036,-8.763731309476029,-15.978349434983702,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark23(17.61907510935564,36.78516406938959,-8.813459578770521,-17.61192726002284 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark23(-1.7620238421969958,-78.83211935955102,-65.81573827307315,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark23(-1.767390855801174,0.0982972645031388,47.22193578315438,-73.48227030284762 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark23(1.7683672416083498,-1.5568309581709654,-89.5660307353011,0.7784154790854823 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark23(-17.701381369145878,-35.40276273623567,8.07358786399008,17.701381368117836 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark23(1.7857637379812756,-0.8929369520733277,-66.08288192090527,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark23(-1.8007347127998985,-2.760224775072896,0.11496919300250102,-100.0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark23(1.8251857492945731,-0.9861942206362868,-60.46581458472687,0.4930971103181434 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark23(-1.833593997275934,-3.666617440922054,1.3730659688167974,100.0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark23(18.479950799907172,-9.98516859896596,-17.10352008324857,12.332063741581727 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark23(-18.51602651271805,-60.61627710943134,10.043411419756474,30.30813855471567 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark23(-1.8707579070713087,0.1499807901382062,84.28555306698104,-100.0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark23(-1.881184583620826,-4.767841873177322,-77.59323836711361,0.04632582411948963 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark23(1.898690242568271,-1.7347428396727873,-0.42744342489115067,25.999959834841782 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark23(-1.909670894698796,-3.284742456002645,99.12870017657664,2.4285494590947456 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark23(-1.937565604761038,-3.650462264585604,-16.499463971232526,99.99999999838822 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark23(-1.9581999385242992,0.5097373241500128,30.037741241682028,53.1566331372744 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark23(-1.9671382225629843,0.8126618351661833,35.540118489521376,-100.0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark23(-1.9716894801252527,-3.943175951331168,60.132626066791275,-88.34934432647218 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark23(-1.979985802708828,-2.3891752786227576,5.446148970778903,100.0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark23(1.982665394922371,-1.7288475248945305,-0.23370917751889686,206.8194335852075 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark23(19.830696400728428,88.60892020897299,-66.83352141894721,-13.567184704132956 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark23(-19.84275790621936,-82.1654844116973,-92.29637067334559,-75.95253080640036 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark23(-1.9884639873221024,0.9942319936607042,0.9942319936610511,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark23(-1.99807068623861,-3.801896597959968,1.7736971918335207,-51.50721288925639 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark23(-2.005617172194736,-2.4961098715900034,-76.07822930225825,0.4626567723975534 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark23(-2.0182428726948647,-4.036485745389731,-77.30895352719479,2.803641036092314 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark23(2.019063820009623,5.599757884066643,-0.8530814306775752,-16.934526597650905 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark23(-20.267273518839733,-40.534380463201,5.693945486035036,17.926044844548887 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark23(-2.0734445185568307,-2.576092710318765,31.831617926389256,57.642165435476926 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark23(-2.093371237465518,0.2619789441802048,-191.40837287095317,100.0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark23(-2.0952171271654696,-4.186156431952111,0.3115746790156466,23.2939065292402 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark23(-2.0982221764670446E-5,1.570711135966715,13.32350482927498,4.2595414090877223E-5 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark23(-2.1030130151102666,-4.205469191168151,1.0516808138923242,-141.6194444600029 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark23(2.126812092601026,-0.6447154056017312,26.55062063340789,-93.05901585572832 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark23(-2.1403340452382476,0.2851632195679675,1.8555651860165718,196.01804070915193 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark23(-2.1420386067452433,1.0709462113932344,1.3902400127274739,120.418701730696 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark23(2.1504123728472897,-1.0752061864237525,-100.0,0.5376030932118763 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark23(-21.718744204364953,-23.779131014090524,0,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark23(-2.186725215552259,1.0932474791957236,0.3083545665402533,100.0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark23(-2.2021718142194664,1.1688007733404093,111.69467528179928,0.02869685008217715 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark23(-22.11597781075247,-90.30553431596609,95.88520292871738,91.95989965222685 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark23(2.2289962605220595,-1.895473591096551,-73.02941704713693,0.9477245886312541 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark23(22.504741364620855,-94.73110598608339,33.45631533825076,-26.3152203757421 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark23(-22.519963859055636,-14.741324453533267,-34.9064836634908,82.87200366530644 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark23(-2.2576074519869516,-4.515084274644914,1.9142018893909434,2.257542137322457 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark23(-2.2594942103690023,-4.518693733603183,1.6828613987997052,97.29632600160902 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark23(2.265097230797138,6.1007529115253885,-1.9179467787960174,40.93141652617205 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark23(2.282456270302506,-1.186664952269779,-100.0,-34.829026971155656 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark23(2.3122866205391075,5.556486233193103,-1.822008060178624,-3.543217267212769 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark23(-2.326508737618801,-3.2779482913995768,1.1632543688094006,-4.644243567628537 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark23(2.3357047929026264,-1.4120567992237603,-10.369111844636883,86.25294110549723 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark23(-2.36125961440076,-4.722518845566017,154.52037196022118,2.3612594227830086 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark23(2.3779103640140935,-1.961605947538777,-0.40370547047373095,53.05858581618874 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark23(-2.417177880787561,1.2085889403936487,-97.03560162805623,-0.6444868069482109 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark23(-2.457188190367887E-4,-1.3358493191153E-5,173.57305052148504,0.23124962190997683 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark23(-24.57700467533715,39.10728161980447,93.35941678590706,69.06809685638925 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark23(-2.4618016831807257,0.4501710431977438,-1.9416910924364046,-43.3977159212594 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark23(2.463661381982125,5.890804510563264,-19.259487891878855,98.40753378807194 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark23(-25.15600424731607,11.794775701183717,-31.46726039859275,7.250587280605713 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark23(-25.440315021440153,-50.8806300428803,0,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark23(-25.52435378604872,-51.048707572094614,0,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark23(-25.556281031428398,-78.49011183740606,-22.864477122980915,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark23(2.555790279247256,6.682376836400467,-29.9263296214464,-2.555790254802785 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark23(-2557.123518162858,195.4943772695363,0,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark23(-25.83911773474597,-24.175166937153563,24.583851850550275,-24.998142320728633 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark23(-2.589172899204151,-4.998337456085512,96.32729083321702,93.59493583450468 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark23(-2.5957451118945696,-5.178867605593898,-15.85632435027776,10.693415436721075 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark23(25.999584453171437,-6.682207707641268,-10.06034021846392,-15.217626857900001 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark23(2.6113347176973223,6.790367822287787,-2.0910655222461094,-99.99891366468961 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark23(2.6131532651286435,6.757531729695119,-2.092163194668523,-30.86943217093382 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark23(2.6150620810401626,6.7833788297735715,-194.3686855270632,28.040583162036903 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark23(2.620698058141435,6.795035181359579,100.0,-100.0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark23(-2.626236980207783,1.1826723353851436,0.5440115878343736,175.59963014712906 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark23(-2626.8557625746043,87.11342349136217,0,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark23(2.6315602357918912,6.832779055151831,53.057948906315815,-3.416378417590237 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark23(2.651214108126935,6.655107163112644,-91.48098520851576,-8.818520138236526 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark23(-26.634652924760616,-24.419263875804177,-15.792324455720234,33.702602084806045 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark23(-2.6704097915104743,-5.329235028384474,1.7226427796542616,-87.65640841633015 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark23(26.765521346431015,55.09753953363594,-13.38299029703264,-27.54876976681797 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark23(26.90412480452204,4.3475126407452365,-65.54244839214203,46.21233838268304 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark23(2.7012724761732496,6.73393392484747,101.09519445077594,-81.12081764677609 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark23(-27.128487779459814,-54.25697540085696,13.708604277571055,27.12848770042848 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark23(-27.167381176087492,-52.76396602538009,0,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark23(27.264865202647037,54.54800967723876,15.442966277690344,-27.330023357674392 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark23(-27.30637456418394,31.794579955764107,0,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark23(2.7846297852870032,7.115897888807482,-85.74145620330161,-3.550385999678661 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark23(27.9571657787413,-0.8500636471618179,-94.94526027305558,-85.37588186888128 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark23(2.8085166765681273,-2.1799714037475812,-0.6203469740657448,5.302266340673077 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark23(-28.241907356432193,-56.483104025991764,14.120953678216097,-73.83334452713984 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark23(-2.846757997144191,65.33596391407501,63.38055870607474,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark23(-2.8561344598013267,-5.165956858498138,23.621860634563927,80.11867806101569 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark23(2.85718160373803,-1.4286205213877448,-30.39494948166314,60.359369166801194 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark23(-2.8682743729491875,1.0316235245877343,-99.99956496573319,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark23(-2.876239442430016,1.399713007443137,100.15644102036475,-0.7051005421847323 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark23(2.878404721691242,7.327600573032359,-1.439202360845621,93.71791052028094 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark23(-2.9094028450361753,-5.818805690072344,76.14229967040086,2.1240046816387235 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark23(-29.19295600788587,11.606847666898148,-66.21254500572496,-63.24789046127528 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark23(-2.9199271328947334,-5.839854173787692,37.21313839423512,2.919927004586221 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark23(29.214253137302933,-33.849791161461525,55.563970956861,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark23(-2.990018361896538,-4.903168296824227,45.47594796532587,3.2325794223356854 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark23(3.061143139056388,7.14460882200174,-153.03173962165866,-3.5723002177372014 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark23(3.090107543683248,-2.3179943628782045,-2.330451935239072,63.94071403710724 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark23(3.1460150575334977,6.765848469201288,-1.5557859646490215,-216.93916569524265 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark23(3.1517247801231605,-90.69461023722525,84.16332221772177,-18.186858572148438 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark23(-3.162158738679583,-4.753521150564269,3.4785771242254935,-100.0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark23(3.222604841970906,-1.6113034620038567,-7.10906552552826,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark23(-3.2313505554379005,-6.4627011108758,1.6156752777189496,2.445952392040452 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark23(32.41772135193916,65.29354478092584,-15.42346251257213,-116.68800328065561 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark23(32.661502954033416,66.89380223486172,-91.36367113916624,-33.44690111743086 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark23(-3.2892485728593157,0.8649161230382275,6.355389229378208,-18.134331416103883 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark23(-3.3386008349989553,-6.658779936269274,-90.51243203744822,-118.40760032037058 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark23(3.3482081935108936,8.26721192026936,-0.9543174194757378,-53.61700560345483 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark23(-3.3755227909654977,1.1177110473411171,95.90651542798014,-1.0236728046486936 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark23(3.4096038689849606,8.362863951553454,-1.698016906189638,-100.0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark23(-3.4260360374007943,-0.14104496891672103,1.9797796037260988,100.0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark23(-3.4266483931067655,1.7133242001605273,2.3577302548345864,-1.6420602616741395 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark23(-3.4371973315253195,-6.700005451800049,1.7185986657626597,2.5645979959815115 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark23(-34.51647989573978,-85.12539208605526,62.01619482187144,99.2761245979658 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark23(3.4749877660696695,7.465924595525778,-0.9520957196373865,-6.081579853367048 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark23(-3.5230357742233567,0.976119723714313,-77.08771869840533,11.41086648854452 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark23(36.468730688805266,63.45928280485268,-24.15084189268495,-30.72591413974112 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark23(-36.66200316793484,-81.75685331361689,-26.202160389048316,-40.82701007122558 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark23(3.726473712349438,8.42487770567842,-2.7176925125943967,-126.73205784649868 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark23(3.7271857549066545,-1.863592877453328,-17.566893543545234,0.6463495424296459 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark23(-3.7506610617820093,-7.189017754723733,2.801128368294264,1.2362033008133473 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark23(-3.798430936981018,-7.591311816065653,100.0,38.36083941300514 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark23(3.851572966046071,9.273942258831122,90.90805755680357,-5.422369292813009 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark23(-3.859285208846823,-6.864597427896273,-105.17401511169216,94.53686889876869 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark23(-39.496248588549946,57.18367663050469,-90.46982577630223,8.190592177594795 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark23(-3.9822759381540607,-7.9324966434145825,-56.201986417727625,32.239835723286234 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark23(4.034894445868891,9.633689073492452,-2.744048805063145,254.1797680382965 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark23(4.03884558541654,9.648399768282879,240.2496851007269,-83.37956242330986 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark23(4.04779699706002,9.658649817988247,-2.319186609747592,-10.325766118610977 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark23(-40.502314110293234,0.3776562017324494,-61.58658893272544,91.04950016082142 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark23(-4.050719125682505,-7.68223957174214,68.16834675168198,171.86415974454468 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark23(-4.055777021494427,1.2424904369542544,2.81328667414493,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark23(41.01901716652878,18.50876002289135,26.322261553971884,-84.59644698632107 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark23(4.132419057325603,7.243089645866753,150.40442865863935,91.36652854058538 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark23(4.140954706155938,9.852596988561167,71.89552256251677,50.837370612293626 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark23(-42.30674996622342,-83.04270360565195,0,0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark23(4.278940471173559,-2.176485122410081,-70.93016836530248,-100.0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark23(4.34249434695703,-2.8384273962815927,-2.956644478109811,40.69610737699689 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark23(4.356999302325434,10.260833605492511,-2.1383956693535833,-23.19264616867161 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark23(-4.364771717660612,-8.729502219179277,123.88879271306322,95.47093551934645 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark23(-4.365658731606319,-8.72756582174578,17.055135838299748,-13.685835479008132 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark23(43.71187890427771,88.99455413535031,0,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark23(-44.202955031505844,-55.868710680830034,-92.95189570872833,11.535697739574857 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark23(4.4266530846126715,10.422284336046905,-157.40857910206165,45.83781170318875 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark23(45.52168524209432,6.939388736903254,6.019703575957649,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark23(-4.5906233614656955,-9.181246703300443,-100.0,6.161419678445118 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark23(-4.622872265911257,1.9492288402449085,3.0968342963530766,54.51868956636059 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark23(-46.26239877779037,22.505154089632505,23.085797113346267,-171.19917535674324 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark23(-46.6449709305113,-66.6418970468709,3.546529689971109,-99.6195257669473 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark23(-46.67244189628359,-47.819021901572036,0,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark23(48.02976804994364,13.70181653777533,-96.84030417749167,22.059754217812028 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark23(4.834580513491032,1.7109070719338035,-158.99089895149683,-6.370188793865779 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark23(-48.38577617110937,79.69491193469841,36.21535151034038,22.19582433457701 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark23(-50.00000000000001,-100.0,0,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark23(-5.002512426287996,-9.999590148633343,3.2753455385669037,-39.76793241107862 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark23(-5.04600959358753,-10.086275343238869,1.741635398949012,34.10280510676381 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark23(-50.744132513976886,-100.0,0,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark23(-50.88459329702473,85.96855740784005,-90.58329299473237,-96.42722604828502 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark23(51.07751179659695,-83.25144679451064,-42.7437595381295,39.0344655407622 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark23(-51.3499283939044,71.04149529466017,13.915788012236092,-98.52636121140345 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark23(-5.178238688937124,2.5891193271534707,1.8037211810711136,100.0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark23(5.221714264448901,-2.6108623678652605,-100.0,1.6661748844169373 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark23(5.293235064796198,-2.7270947636668255,18.622262083014054,-79.76920069644271 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark23(-52.947631628947285,-105.68011619154669,0,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark23(-53.01294761296587,-92.49832647448119,37.57023839656779,52.42508349925137 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark23(-5.367359803262243E-9,1.2376021649078724E-25,0.7853981649942642,72.12139150728908 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark23(-5.389015269594979,-10.733891173261876,-79.39164289145519,-18.989692254106387 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark23(5.419549818254405,12.409895938492832,-100.0,-6.9903461326438645 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark23(-55.07647519967749,-32.376122057518586,-50.662170302055486,32.01289496087796 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark23(5.5205920864410105,-2.78243293971878,5.8795521402595154,95.39551104122891 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark23(-55.530206028198606,-94.37206470043591,0,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark23(56.48691819704666,18.172372301035992,62.07290904042844,10.273799072123651 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark23(-5.683756704668369,-57.32412920873144,-24.780882167336287,37.598043179986604 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark23(-5.724646264446563,-11.449291332873521,-13.510446907953442,5.724645666436761 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark23(-5.733374244490537,-11.453623433976341,2.8454216533209005,128.24863656460448 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark23(5.75160239685332,6.346261590566808,100.0,-94.27579672987636 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark23(-57.75546252260699,10.240987975721325,56.89711559231097,-32.31116541444514 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark23(-57.82332540198119,-13.230266263103331,-79.3223189977478,87.66877527093777 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark23(-5.875905694775915,2.8613841783335707,2.1754104066416646,22.19106646020242 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark23(5.894843755548377,13.360105658867841,-46.76591574607285,15.311093397023221 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark23(59.20143198436634,61.00623404610303,-12.239028337420038,-3.0203644850159463 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark23(-6.0655005854950215,-12.127884702140266,-25.74154007611527,6.063745962129171 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark23(6.067062979387774,14.820820530662695,-169.33687217334557,13.864094396462633 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark23(-61.31400667054854,-56.48429463078883,0,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark23(-6.1325622193641305,-17.007663808485987,-100.0,-36.324608980698876 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark23(-61.74216094571423,28.411057058772656,-90.73457720153777,-81.42776154189646 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark23(6.191966833467266,13.953941745423254,-2.399413113559913,-9.33075473160943 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark23(6.196626576014154,13.964049478823203,-72.51555496909758,-2.7765267521050045 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark23(6.2186259854845165,13.978015317717874,9.480991028892038,-6.213389753843801 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark23(62.444717117205265,-24.00775671780275,-31.222358558602632,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark23(-6.318747333764974,-12.63749411318144,43.93909918199846,6.31874705659072 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark23(63.457326102663444,30.7576428906836,16.439473739106063,-44.49209870073996 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark23(63.97692939920802,-14.823658381063566,0,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark23(-6.513912668279784,-13.027825287578693,-73.99853720159928,6.513912643789347 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark23(-6.54815350421383,-13.012219196618874,2.78428928136634,34.7457280956029 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark23(-6.585778624322727,-13.072219812844065,3.3698029928991877,-94.01636747508506 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark23(-6.670549134913439,-11.770301943031981,0,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark23(-6.70454661862199,-13.408042872827256,-30.692047999738605,6.703996578046031 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark23(-6.715619982337269,-12.407880784257733,-22.575510444493162,-2.4354788166290398 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark23(-67.52429462709662,33.03063608859861,26.547436340790163,-16.515318044299306 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark23(-67.66373158880185,-13.513813367435517,-37.753334221312265,71.09131067974477 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark23(-7.007157943780702,-13.179953951679945,-72.83876639836872,73.31572143315748 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark23(-7.181964398335296,72.06818142978153,0,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark23(-7.185812265540656,-14.03807056042772,2.80750796937288,6.2336371168164115 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark23(72.47389830641083,-88.6899579047411,-63.123793613714405,23.138333310437957 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark23(-72.75897084954528,59.917441301813625,0,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark23(-7.322213249989096,2.8757084615971014,5.972673230851145,-1.4046472591769081 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark23(-73.25833705400227,-48.4061382993751,-9.632039210007107,-75.52397459399495 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark23(73.64223608727295,-19.10009730979378,3.5195960641968043,-56.19710157636955 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark23(-7.365814459743773,-14.715238244707118,100.0,64.69167756444594 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark23(-74.62460724871936,-60.29038831533957,0,0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark23(75.43231131812269,-23.128366809352443,21.25867547190485,-0.5485132609206005 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark23(-75.52908264497862,-87.9203474643772,0,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark23(-76.26977774610268,58.725194076940625,96.37274777479271,0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark23(76.27176665747237,-28.03085593936885,95.67845877809958,66.8136262892541 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark23(76.40083351155366,-44.54812575693783,63.48485884242464,-92.50280583083838 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark23(-7.786242050547116,-94.94656122553369,-7.6312984545972,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark23(7.787304663394302,17.824680331927734,23.792870370902435,-100.0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark23(7.803807252164759,15.607614504329518,0,0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark23(-7.915296100063341,-15.83059220012668,0,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark23(-7.996114580432823,-15.987247342357648,3.998042805765631,-47.77097344416119 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark23(8.03577884714844,17.642347966347184,-89.12708670411162,25.744084057577258 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark23(8.134612082061938,11.50779728600577,-82.2880999077166,-184.81789341392283 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark23(-81.82508259845626,49.63319935666274,-94.86828029911946,88.82885301724542 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark23(8.386840286468303,18.3444768997315,-3.408021979836703,34.81005869993877 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark23(-8.408431010447874,-16.81247740715513,3.41892548352675,8.406238703577564 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark23(-84.22728884822696,45.809109165051154,-76.98618646439861,62.034706274642105 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark23(85.61106751462447,51.72733432736257,25.451395664635413,10.262952997332945 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark23(-85.62526901810052,50.16826609014072,0,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark23(-8.674691867496522,-17.349380752216383,97.4744245341262,8.674690376108192 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark23(-8.712591965649018,-15.854387604503142,0,0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark23(-8.766292902832886,3.5978284249092525,-74.15713695289173,89.5069540151076 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark23(-8.832640053807525,-17.623972957365435,3.630291747708042,6.462828539922763 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark23(-8.98407497544962,-17.967050327444735,3.706639324327355,6.6272074510992764 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark23(90.25934776861874,-9.55231604148392,55.05814984179085,-89.9284671276978 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark23(91.09296512891962,-87.35869217177527,-82.05817250641914,95.96509638329474 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark23(91.33767431635465,-73.71512518357702,-80.87216312673264,11.884028670214676 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark23(-9.160533491346063,-16.757106543919104,4.578590661216321,-22.281197641100885 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark23(-91.9090294687619,-28.077109620955795,82.88308598832239,-94.42265628022457 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark23(-91.92878933535181,4.315615411176026,0,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark23(92.38567708535004,-66.50232946065128,7.5442838019830845,50.88344180825487 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark23(-93.54042795779598,-12.55462329686246,32.35608245383577,-61.632303379267775 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark23(93.80434787607885,39.853593947487695,26.469497065925736,-69.94920262985893 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark23(9.413043788787652,20.334405728816655,-34.482775785974475,28.334705600341703 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark23(-9.471744709415873,4.602040410144278,66.9794983766833,-63.34854174427903 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark23(95.37478200740463,93.84942587929257,0,0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark23(-95.67683059841383,-33.77578721206814,-80.25744618084619,35.03923520211649 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark23(-9.821956594118788,-19.641312252027557,136.7000626028252,-34.97372267335301 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark23(98.88948302290575,91.75761588362053,-34.68034739975478,64.14808128676756 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark23(-99.38755128366903,-1.266298254831895,48.176948459130585,-44.11878580297917 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark23(9.949669267415716,21.469721907859288,-5.236569533160287,-9.949462790532195 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark23(-99.67339302972363,0.35292751552870527,62.217619341424665,60.362533543038694 ) ;
  }
}
