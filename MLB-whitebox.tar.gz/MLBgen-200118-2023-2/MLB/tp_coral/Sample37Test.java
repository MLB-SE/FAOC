import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.006843135968674474 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.008211196185720748 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.008772564666370553 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.01270817411895564 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.01882289952752103 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.024452245712968404 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.02992293216430797 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.043974223178704364 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.04623646631480938 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.04671542892624703 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.047905935841669134 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.05185659649246155 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.06744210772705972 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.0682988247994123 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.06970979500009805 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.07034124444152745 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.0731529975669043 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.07395679929098264 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.07423782554271074 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.07625896098606688 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.08295773277545493 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.08721571151879015 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.08811315096785677 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.09175388866789547 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.09225179692594598 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.09755341112715094 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.09956604737908847 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.10007673786199667 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.10457199589808397 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.10770689021678029 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.10936809328472297 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.1143986898081355 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.1149448737917993 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.12169292736594706 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.12222155645122257 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.12751622762663506 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.12771514027261283 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.13317564965176132 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.13360417523753654 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.14635691213157465 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.14743967127501373 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.15458588167286536 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.1557278625196965 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.15710378360185032 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.15877874116227986 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.1601373616005528 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.16578868082777376 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.16653921063272037 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.1694687536236914 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.17675050196602893 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.17922795678259007 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.18783294184503063 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.19022058997379537 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.19499231092180702 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.20671253663979294 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.21824340108924556 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.21895140173167071 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2247408078317079 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.22981775141667526 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.23368396649817047 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.23447331921974746 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2378698395258847 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.24272608813934937 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.24278971181360753 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.24431659525195326 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.24490736712851913 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2490909948986657 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.25747258004109597 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2634328052961325 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2663451150225882 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2704550975363258 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.27471451190978424 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2777790668330722 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.28588558178026346 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.29648539004898544 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.30623725583373185 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.31274492934403336 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3153203994891408 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.31687984955919823 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark37(0,0,0.32430010297863987 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3333950645246375 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.33600331097311287 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3374221833938451 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3391823323174883 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3549145845338395 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.354987611371115 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3569971269649215 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.36835215094599727 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3705440066576102 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.37266185299604615 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.38384672124070107 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.39135889300506355 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.39136149090515904 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3922850970067788 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3932287587350274 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3938767690469911 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3942418045806644 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4162552678487401 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.41726378766264555 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.41771155939176197 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark37(0,0,0.42431873057128655 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4314979641865353 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.43450918222888824 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4528392994179029 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4598193599282241 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4620154751348764 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4636750148037976 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4669262549914013 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.47674757286866054 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4808366883828512 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.49216026787327527 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4922093822682698 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4971596239159265 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5082122631441237 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5136149731882682 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5155293463238201 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5177573363008969 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.524692431560768 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5285015816171494 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5297360923035122 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5406759579325118 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5447868954695281 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5470725042115854 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5488776960780797 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.550410323578369 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5516623207216207 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5670140169029736 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5729916394832602 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5885760342723074 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5906795188586926 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5920461467047384 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6040333842156147 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark37(0,0,0.6115639735766933 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6123301626773556 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6308550963624312 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6353674055169451 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.637172532187078 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6374859920993199 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6410833871306831 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6426829578953175 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6445646138248219 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6468409871455123 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6536343877839847 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.654743994665985 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6565733971833103 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6770378132794761 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6846398825749436 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6854171207523674 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6881764835422501 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7011875032379882 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7034350470573534 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7164769133148163 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7213906924622058 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7340258404915119 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.737180154987298 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7391747747181591 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7399945063062314 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7404247931591925 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.742474123528237 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7442431554523052 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7511936731553841 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7524093664991303 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7534599065067864 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7598204265689465 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7599988256507402 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7703700336215382 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7731500863767957 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7787035681222185 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7802290526649074 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7840230098349132 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.785074999684205 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7868427871282004 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7875561682124399 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7887666467640213 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7926337692404388 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7927796820426467 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.795080735334154 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7951152823935994 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7985921415034571 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8045663931856751 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8074517129500869 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8083609916285126 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.809427870591108 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8229234845875197 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.833624598870873 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8425315920344474 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8450559819651744 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8455541961790609 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8501982822683241 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8505943304990597 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8626298890621658 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8633918969626944 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8641641579051753 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8644416503507841 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8709034801643464 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8709335657562289 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8769615846210534 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8780391229983309 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.880670200840612 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9085667566443902 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9095723806774025 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9135768284036212 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9138591124845563 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9174937747528609 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9181427275763951 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9245494259415779 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9329306019489625 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9400324654954915 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9480662734639393 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9501578488548859 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9506938849929831 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9516842256568179 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9540524417203784 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.958108980424413 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9762819679912695 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9772416033372906 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9884568668450084 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9934464242555572 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9970451482662981 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9972108255590215 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.008024880632604 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0285705300134693 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.032744747288317 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0392409751098342 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0441781900425405E-246 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.053811866938052 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.067122212596928 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0682897380121514 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0712649707759159 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0832683259385107 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.090016250440219 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0904203782814261 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0914420349042429 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1124935114537173 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1172635558957091 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1299034611393195 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1329895754885646 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1536096611991005 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.15665165286876 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1644980607443638 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1656456444884924 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1663089227355243 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1678814319751893 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1762904273067818 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1939806297676938 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2003328775381306 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2022529196198652 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2026426432776331 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2062127513652783 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2102372239120314 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2112899324166646 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.213518973223131 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2150214413257667 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2185065011885965 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2225601603939138 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2230129608438602 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2243136167678772 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2245660685851896 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2288250727561234 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2352838526803318 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2375071872051584 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2449901187500103 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2460002948285505 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2490147987127411 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2544201496375667 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2548952667657147 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.260279424973568 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2645840620608197 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2691916926005435 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.270860162148253 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.271455955858098 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2723627948798613 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2733731200532539 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2762325752527386 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2805068511450912 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3035789576479502 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3041425944698517 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3094965889204688 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.311811580552972 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3223881770605033 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3254427905623727 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3263287094672833 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.327701267199724 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3364509423987174 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3588799374054763 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3648698802317285 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3649590032423724 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3674398445928118 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.373552348365139 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3804613773990768 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3861287836098333 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4041714257599338 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4176893376387945 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4237331275798653 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4243735088040594 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4250973913137557 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4378146481964782 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.437952628269528 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4390485930918002 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4465562728558048 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4469603826331814 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4482299283623092 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4511596459421794 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4547883486955155 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4549981731198487 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4575444829077444 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4609296692038765 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4661371199170263 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4707787774325563 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4719586402115663 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.476612796333383 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4860757683231185 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4897762848048377 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.491369062485976 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4918399440031218 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.493363663365268 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4976847507336304 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4987191506287405 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.499221388677781 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999987423 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999996945 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.499999999999762 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999645 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999716 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999787 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999822 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999858 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999876 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999902 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.499999999999993 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999947 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999956 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999964 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999973 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999982 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999987 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999991 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999996 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999998 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.5 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.5000000000000002 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.5707963267948966 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark37(0,0,16.430635105420933 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-20.33956930654321 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark37(0,0,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-24.3748524455615 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-2640.2858144587153 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark37(0,0,26.452275545033004 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-2717.6331235010894 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-3.3683802431849728 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark37(0,0,3.9892695977026567E-26 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-45.35182313612507 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-4.9E-324 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark37(0,0,59.512716018237654 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-59.887734795737636 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark37(0,0,6.356741167795988 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-69.98147191248358 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-90.83765992791217 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-94.40547826100473 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-98.89407584096239 ) ;
  }
}
