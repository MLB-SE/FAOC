import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(0.4073764644409579,57.888229046863074,775.8540730163812 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(0.5600464244468952,-77.68945737555337,0.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(0.6659854427098537,15.742388176752149,-40.19140625 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark47(-100.00000000000297,100.0,-745.5295464193123 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,0.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark47(100.0,100.0,0.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,100.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-40.19140625 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark47(100.0,100.0,-709.9760284887128 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-711.8420364065962 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-714.8960281837556 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark47(100.0,100.0,-721.4865200027682 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-726.9040152859886 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-727.5945514085216 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-745.861078780672 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-745.99177514023 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-746.0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-746.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-746.1915316487404 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-24.028447171561808,-745.9999999973052 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark47(100.0,48.111869590893654,-709.0969889559886 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-626.3478971097251,-717.8860579966943 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-627.5224585888992,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-645.9999999999494,731.7802799505714 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,79.13204946772902,-756.3429593607749 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-79.31439938041328,-744.3665847340156 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark47(10.307008065040748,53.685480014875424,75.15661018440215 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark47(10.365667819822493,38.22741366054089,-745.6018832631971 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark47(10.7508757935272,3.4017539312251017,-713.2305378116381 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark47(10.905470149076407,-12.3996107740764,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark47(-11.066268463564304,100.0,2.220446049250313E-16 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark47(112.16225459593872,96.00747727258329,-709.8872770664595 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark47(11.384650048977733,-11.384650048977733,14.415819569598227 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark47(-118.83953633206923,-627.1604636679308,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark47(-11.918689197778562,47.86751012612075,713.892903664934 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark47(12.069197579218098,-7.29979005100347,-793.4629319848902 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark47(-125.07633712356622,-620.9236628764338,0.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark47(12.55729545462556,-12.55729545462556,0.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark47(12.73619750730984,-83.31751978929529,-746.0000000000056 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark47(135.10389881713394,-51.53768024780607,-709.9462644055296 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark47(-137.9832085897072,-571.1712847057028,-1.4941406249998905 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark47(13.839240225078115,-38.06964825089176,-27.009293163425127 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark47(140.28514895240093,-61.07447561622343,-708.5223156884904 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark47(-141.5927949708207,-567.7943456254972,-100.0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark47(-151.28753017299715,-561.6990060967147,-707.6327103235109 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark47(-151.78018122903933,-558.1451104539283,-718.8690566516354 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark47(15.230413505191137,23.80775066510698,-763.7084579768147 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark47(-15.981824902092583,-58.36299803990506,-720.0427309197928 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark47(-16.702562460167094,-36.08045742448377,-1.3896964514598542 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark47(167.32918524152942,592.9758587323179,49.110201555949374 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark47(-16.776260317648806,-56.880106645371995,-10.542583807920252 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark47(-168.20499544286736,-577.6361771015878,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark47(-170.78700900920592,17.95534073794751,-745.5913530787669 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark47(-170.8769812805301,-575.123018719558,-744.3603929067508 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark47(-177.89338575247777,-569.2980204975751,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark47(-18.075065746055145,-19.3021566523679,-709.9447700679492 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark47(18.452177024921788,91.32895673162409,0.0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark47(-188.7181458717657,-531.3466699807663,-717.0727811168049 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark47(189.09462154291336,525.8134052066664,-711.1059578031505 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark47(-190.91022224489836,-519.0893856344867,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark47(-19.193846648504916,19.193846648582674,-745.077996384018 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark47(-195.4037451548073,-521.3689844408882,100.0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark47(-196.8213639593453,-603.5674053469678,-726.3275415009641 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark47(-19.695986059369687,-8.801217322035427,48.545530460955405 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark47(-19.714385554658193,93.45458871950382,70.91045504723422 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark47(199.89629361079608,521.2027742304512,-717.265674818033 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark47(-20.03739801738209,-15.297699248333046,-62.44635893010777 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark47(-204.24398904101665,-560.3429052757198,-79.31443702547367 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark47(-204.2740575742544,-578.1907353913457,-1.116557644309697E-8 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark47(-212.06766273447423,-497.2158945459306,-736.9390017932841 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark47(2.130999059157233,-2.130999059157252,-732.2511401288592 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark47(21.557676596015277,-21.557676596015277,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark47(-217.02339137951685,-492.69949924364687,-709.0864280911732 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark47(-21.85863313055654,-58.23304185105269,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark47(22.28695889744739,-22.28695889744564,-778.328643133326 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark47(-22.47803952836675,-95.74608458963097,-37.042809678444534 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark47(22.490387760470625,-23.893737305951433,-745.6304927884626 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark47(-224.94880888504048,-484.31135514202475,-709.9953253964327 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark47(-22.719599503223577,22.719599503223577,0.0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark47(22.74465747445585,50.95333013631844,-717.7967552590385 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark47(-230.132925620189,-479.2729204271744,-744.7532975276132 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark47(-231.5615449932697,-620.7410643167573,-709.4647711614151 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark47(-231.74846488801995,-514.8410992402834,-12.543465443095243 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark47(-233.41021531386895,-476.4207423444701,-64.47945708197727 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark47(-234.73703685557211,-498.37030223694217,-745.7882681170472 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark47(-23.884288215596946,60.64716229791617,-745.9920472264608 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark47(-243.2917870967894,-465.95867866319884,-743.2829490207461 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark47(-24.708974665553683,-68.04945750416263,-708.0368015217371 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark47(-248.14064951316539,-525.2618216102584,-745.3462859202406 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark47(-248.14256897045055,-484.85520853224745,-709.3927557200781 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark47(-249.35246507040492,-460.00729906120876,-1.4940777886625596 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark47(-252.40832467926384,-571.5986323126867,-714.2582635558574 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark47(258.53796593361756,465.81437640391295,-708.0099506433205 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark47(2.6189916500916013,-71.63353435210746,-745.3381072074634 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark47(-262.4105475768354,-447.38009064570076,58.59874633072508 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark47(-264.1327064935755,-481.867293506425,-41.98250495764277 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark47(-264.49010059862,-481.5098994021956,-709.2444829303757 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark47(-265.12577438576716,-446.0027838297296,-709.4537981320354 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark47(-265.2451068871227,-555.3400531755691,-41.138730599935826 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark47(26.583868534252076,-61.366989313315415,-709.324739793334 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark47(-26.700721497340908,26.700721497340908,49.77315435994455 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark47(-27.114915360994104,76.27697639697496,72.97659965631166 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark47(-273.1726064558952,-436.2069271410319,-745.3179221267552 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark47(-273.4511855611995,-436.0817740025414,-709.9216338096337 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark47(-273.50784602372084,-436.1629768055176,-709.9167318383865 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark47(27.462591871480726,34.987448362449186,77.76786400993387 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark47(-275.5195752963099,-470.4804247037217,-31.620723314709842 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark47(-275.60883350044406,-455.62328621125886,-709.122045924777 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark47(-275.9504275152816,-470.0495724887102,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark47(277.5770504788396,435.14547965868707,-39.760869387407595 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark47(-278.5875935675694,-430.94772360574,-5.883650065637197E-20 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark47(278.6207875169055,435.0647428041651,44.34729956534241 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark47(27.87715684569426,69.48034814231943,-745.8186750693465 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark47(-278.9966202867006,-434.3945588355038,-100.0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark47(-280.0753826367998,-465.488341090663,-732.8444383356048 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark47(-28.007866948217387,28.007866948217387,-40.19140625 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark47(-282.1885683205485,-469.8525939043794,-736.4459949226327 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark47(-283.4038362277443,-426.37282459528194,-709.6764282601981 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark47(-283.4885553615174,-429.07944228647443,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark47(-284.41643483081134,-461.5835651691731,-48.01248300304785 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark47(28.76056475161363,46.91499856741527,-70.3226010772566 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark47(-288.7055721699199,-455.607883359537,-709.3932129735043 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark47(-289.4714718912402,-420.8141277160479,-709.2005464892525 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark47(-290.48199757857975,-513.1712958468894,-722.7609629463727 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark47(-29.788301589512123,29.788301589512123,-22.596409898107584 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark47(298.69601088239136,416.80137330667145,-40.19140625 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark47(-300.11491201861145,-420.84272347984404,22.685329247119896 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark47(-302.1442719968102,-407.64400230235367,-745.9997221689916 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark47(-30.267015546534594,30.267015546534594,-729.3908607124879 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark47(-303.209056457845,-460.6424396570371,-708.6611355730514 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark47(-30.40369392395175,30.403693977969528,-746.0000107958862 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark47(-305.03270812955316,-413.11365206735275,-715.5241298037841 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark47(311.8403302521374,432.3225238645994,-745.9129559103914 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark47(-311.9899440127927,-434.0100559872073,-16.85754128801688 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark47(-314.12861224611765,-412.09139575740943,-709.8812015655178 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark47(-315.1487990056372,-394.35725013953487,-100.0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark47(-316.26719867351784,-427.90345317508604,-8.342640489922749E-10 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark47(-318.10200369674243,-436.23778888171637,100.0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark47(-318.1377789364196,-427.8622210635805,-14.130060220071954 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark47(-319.327725626061,-395.4497583311629,-767.8203952199169 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark47(-321.25406145180864,-388.62025960252066,-719.5820802055979 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark47(-321.6993789529052,-387.863200451784,-811.909405276274 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark47(-323.6127946122066,-385.66366574399694,-2.5791599656032673 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark47(-323.9191952141597,-422.0794341068557,-2.0103206785335539E-13 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark47(-324.31557870774066,-455.4267729016119,-745.6781803137469 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark47(-324.4128314755749,-386.4407315247369,-40.12564305066226 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark47(-326.6189625674187,-413.2674488873149,-35.579825996185036 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark47(-326.856629952331,-404.971213280964,-745.4265339823401 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark47(328.78916021872317,409.20079248993466,-0.14803021031717378 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark47(-329.7977843739598,-379.585251540862,-709.6038516460769 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark47(-330.33923126924003,-514.9883845077649,-1.494140625 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark47(-3.30505480814665,-100.0,-720.8211786089496 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark47(-334.43293459820177,-380.64474302905614,-723.8050017580697 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark47(-334.693709707531,-458.9366797105177,-100.0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark47(-335.4259686427873,-388.41594606806404,-40.19140625000001 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark47(-33.67506039335433,58.3534824414271,-709.5531052927724 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark47(-337.3718037029721,-399.52056387723286,-745.9999999999999 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark47(33.83786151403058,-80.9106605616244,-18.622487133023327 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark47(-340.9299501952582,-368.38604193781373,70.79464658743711 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark47(-341.9437449913022,-404.0562550089108,-736.57229063454 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark47(343.7993748238377,382.1236561656285,-100.0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark47(-344.0856416536028,-397.6945580138576,-709.6336814367784 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark47(-344.3148197596257,-364.7337786293412,-746.0270596541534 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark47(-345.7387885858732,-363.89581604631394,-727.9037627167912 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark47(-345.9619363113991,-366.1212363157032,-716.2111008741987 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark47(-347.23200109199513,-432.7957345402269,0.0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark47(-34.74011740063851,51.749281024404354,32.646496934639885 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark47(-348.5816137851542,-406.5598111131406,714.5366731510619 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark47(-351.45239782478217,-365.3408488259038,-41.586779244425074 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark47(-353.16542189671515,-383.4624991680613,-100.0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark47(35.36779285040672,-35.36779285728002,-746.017243129525 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark47(-355.31208793365056,-353.73754423120477,25.630772961690113 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark47(-356.7187008329582,-353.2169582084763,739.4914123729067 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark47(-357.0402724562871,-360.68305028046456,-745.9969378004868 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark47(-358.4070406723564,-403.3563588729525,-717.5029675676877 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark47(-358.47401973886247,-353.06523872505943,-3.562498986268352 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark47(-359.0944180802371,-396.4961041574294,0.0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark47(359.1799454464738,356.4475933808043,-745.8288885529621 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark47(-35.94424238762686,35.944242387790176,-709.6810281523572 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark47(361.0386456700271,394.61207926131857,-742.5518669984615 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark47(-363.08191823113,-353.5024553882349,-809.975201304691 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark47(-363.13545534698676,-403.95920412475147,69.82920700528678 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark47(-363.18160533738217,-352.4758089597852,-709.7139402665927 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark47(36.51668670951099,-36.51668670951099,-64.69339678143069 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark47(365.21137770869484,424.0579304519164,-745.945496392052 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark47(-367.42869898283254,-341.5863033062278,-40.19140625 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark47(-369.0893897613558,-356.0450101988765,-748.2826704436764 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark47(-369.8607462983691,-339.82567197968905,-85.4022634589282 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark47(-369.9186349394187,-382.7824116057382,-1.1021495485387263 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark47(-372.5388827665159,-378.4850612812303,-790.3486171009868 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark47(-373.0146353311248,-336.55541669814147,-718.4994073455244 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark47(-376.247252987834,-337.31337330615014,-41.685546875 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark47(376.293829289559,365.32354517565557,-712.6258359263024 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark47(-37.655164516977415,-78.21983508891377,-721.4085288183329 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark47(37.81350816155489,-3.354504296548953,9.030316482242924 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark47(378.7878501790049,444.5613877104051,-40.076238230888194 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark47(378.96086783229623,393.80495632991216,-745.9999999999884 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark47(-378.99450269837087,-330.75865043457617,-709.0437994793335 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark47(-379.49323899953566,-329.80694951066334,-709.5615029653421 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark47(-380.12781450562807,-365.8721854943719,42.30875110500054 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark47(-380.4925491207086,-329.4037178033896,-709.0873973764819 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark47(38.14538414592638,-38.14538414592637,-707.072467048402 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark47(38.15176033734224,96.40377968488056,-5.0630551322782225 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark47(-381.66316325478743,-350.9038583603176,-735.6712019224294 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark47(-383.6924431608021,-326.2674512339053,-717.0401606287226 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark47(-386.0778885258662,-344.2434504190415,-706.1895580594521 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark47(-388.37730824257,-324.17719828802467,98.12007620278092 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark47(-389.83660656258394,-356.16339343741606,91.264347597588 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark47(-39.33454823362557,6.3887844582879865,0.0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark47(396.9456659154722,358.273958995992,78.92941314741785 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark47(3.978530220832269,50.70624856004049,-1.4941406249999987 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark47(398.9281444960658,314.28686119988913,-777.8661522342856 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark47(-400.0687362503636,-368.92120446227034,-99.79156294791458 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark47(-402.2259186301563,-347.8149187349079,-745.9093472308509 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark47(-402.49144901719103,-367.188069882037,-40.19140625 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark47(-40.810348520586004,35.86009543164323,-49.62557089571167 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark47(-410.333941087431,-335.66605891256904,0.01364546362133851 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark47(-410.360243036273,-299.25373059421173,-709.1410601635876 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark47(-410.7939360887973,-299.0459936632022,-40.00242211662117 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark47(-414.49693075404855,-296.195785500514,-717.1592447475772 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark47(-417.00455613038713,-292.1290175848211,-100.0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark47(425.83527409343577,320.237877907065,-28.958032515537255 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark47(-427.9918543114829,-296.3080853966672,-709.31145607666 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark47(-428.5870088291556,-280.53023998383196,-100.0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark47(-430.1034505868345,-315.8965494131655,-1.4946790040033022 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark47(-433.10518862987357,-333.8423275671514,-719.7338857771158 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark47(43.38643180903378,-79.40309516288352,-43.83944602247099 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark47(-434.78941485191655,-274.5128956982285,100.0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark47(-435.1021923346318,-306.27193992588434,100.0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark47(-436.08749942679697,-273.73788543408654,-792.9583613259456 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark47(-439.9508637646931,-279.77945749550827,-0.08863235170579742 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark47(-44.285196733203904,45.19118619049801,-757.4050725097886 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark47(446.31552416287445,295.6164930486034,-735.7441503133123 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark47(44.84312685938556,32.16715163251541,-709.0958841905015 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark47(-449.74489419072654,-313.5261722654497,49.869077377189654 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark47(-4.552260884674354,-83.19154574001448,-709.4939376779816 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark47(458.79377601831595,289.70585302675295,-710.4822067528806 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark47(-460.2221147283536,-285.7778852716382,-788.2018450051382 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark47(-460.53995725159035,-285.46004274840965,-100.0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark47(46.18405563382092,-23.060864503218312,-73.83034371530901 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark47(-461.9722554642705,-247.15997975972653,727.1176801699457 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark47(-462.7715516254482,-277.5613183920457,-28.82435677044863 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark47(-463.9270141911709,-282.0729858088292,97.4385583982361 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark47(-465.0134529605428,-244.43304686355341,-779.9229942516426 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark47(-465.02741481854986,-247.27234799243746,-745.8005139130545 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark47(-465.3556617609494,-246.86951478795905,1.707722529129768 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark47(46.681208028870884,23.473011135672905,46.30274301639989 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark47(-46.72558494480503,36.170845349131504,0.0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark47(46.78919046873068,100.0,-40.047586011720405 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark47(4.709520269991941,88.1650101689873,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark47(-473.1549370059803,-272.84506299401977,0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark47(-475.24411411216306,-270.75588588783694,0.0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark47(-481.2340081695378,-275.36584323214726,-100.0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark47(-482.04926727029397,-263.95073272970603,94.69239032528006 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark47(-484.94668294078076,-260.77196313529555,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark47(-48.69164050682249,47.19749988182249,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark47(-489.9233232960514,-219.84987682201455,-746.0000000014493 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark47(49.88978342644285,-20.798084167951373,-745.6840624171639 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark47(-499.05844034500615,-265.7375701456889,-745.9986005962444 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark47(-505.8289127450425,-204.17095964038853,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark47(-50.7407815957924,50.7407815957924,-728.6260129800859 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark47(-511.1116315649818,-198.0682910417564,-709.5091985753975 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark47(-514.6801561443234,-264.7735158539858,74.47198503674394 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark47(-51.54659980533125,11.355193555331248,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark47(-517.4191328034354,-192.1248203965309,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark47(-517.5059126057696,-197.62617659545464,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark47(520.3150035251057,199.663812774718,761.12030580467 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark47(-520.9710495656611,-188.12183109732212,-709.4193402249448 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark47(52.122875852391445,-52.12287584770856,-745.9999999790691 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark47(-52.32672815917427,52.32669867072289,-746.0000005415505 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark47(-52.81397267468841,58.01529752116954,-709.0313314827281 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark47(528.8179683478528,184.79894838966135,-39.99502629569407 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark47(-529.2833402399959,-283.25792097379275,-39.02523731254633 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark47(53.00072001067548,-93.03460830331215,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark47(53.33531388800287,-38.04472089383781,-70.10660344400183 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark47(53.366781398461285,-63.19430661097671,-728.8010891991116 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark47(-534.4457917158826,-220.68292893666288,51.00799280121521 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark47(53.50595609448098,-32.8326891040617,-741.6426010023331 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark47(53.992895267863666,-53.992895267863666,-742.4733665604863 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark47(-540.9597988580301,-211.8038543260114,-726.3671441377404 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark47(-544.9676910237754,-164.80919471003995,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark47(-546.469301595345,-209.21741893481538,-48.57147269583475 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark47(-546.9879233896946,-242.867945392241,-745.9995627979267 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark47(-548.3442454228879,-197.65575457711213,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark47(-548.6556106032772,-188.24406690813964,-1.2806124121714024 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark47(5.513145353687165,-55.91190576905631,-31.068378836475333 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark47(-556.589886978593,-161.89053464538154,-60.0109599082119 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark47(-567.3495076604921,-169.3849780729108,-783.5815004353094 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark47(-567.7576736147582,-193.18055488049828,-721.0368755281343 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark47(567.9116426521331,178.1677677481966,-2.1429132718553536E-11 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark47(-56.829340422376106,-66.94457884643965,-731.2107940413119 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark47(-572.9572564040021,-173.04274359599793,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark47(-575.8054207327818,-133.97859087439414,-726.5249184165393 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark47(575.889701185863,178.7249979159597,-743.8969904733842 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark47(57.60880425611617,-91.65432896825278,63.09560155053751 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark47(-577.7106766332207,-142.77278031996033,-1.494140625 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark47(-57.87283851325393,-53.03378231431179,57.27649519181114 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark47(-582.8948393322003,-127.00051232827633,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark47(-589.8464305498948,-156.15356945010524,100.0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark47(5.924047302860373,-5.924047302860373,-97.25048868340198 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark47(-59.359795998016,59.35979599801598,-746.0214623472665 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark47(-59.71108923630861,-89.86311064447077,-67.66281207731262 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark47(5.973940814308605,35.570085250181194,-40.48977434865944 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark47(-609.8516211983596,-100.0,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark47(-61.41000468478863,49.378349836400815,763.9772761583849 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark47(-615.3570801746196,-100.0,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark47(622.813034373622,87.54564004949447,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark47(63.178870830280545,8.331541747300804,12.934324770935348 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark47(-63.46745902869877,11.70691034089269,-73.30050412868425 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark47(63.74848830325294,87.02365910633299,-55.39221176863101 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark47(-638.4033292373289,-71.59667072991898,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark47(-639.1376476894548,-70.56473512818751,-745.9694417714612 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark47(-640.0109260467052,-69.95127271321928,100.0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark47(64.07817576760999,-55.57597999089925,-823.4952236876143 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark47(-64.0796940061421,51.15876073938995,32.59302471611883 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark47(-64.18257770241459,-43.13557508652623,-792.4288182347076 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark47(-6.419461333844197,-61.66737642832454,-727.2603871833904 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark47(64.72962452996143,20.078037732808262,0.0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark47(6.482135422221489,-62.534846730227045,-16.183046876236574 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark47(-64.90754377865167,24.71613752865167,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark47(-655.8060214715974,-88.61920315915202,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark47(-656.473527298996,-52.71870574666336,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark47(-657.1229913369299,-52.79712262151262,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark47(-658.3364127410899,-100.0,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark47(65.85011033292554,100.90403055765864,-742.5117274469314 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark47(-659.8325972476242,-86.16740275226789,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark47(-660.054647291112,-85.94535271217389,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark47(-66.42075535214055,66.42075535214055,-40.191406249998714 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark47(-66.64008284624921,71.41331115783012,-736.9514596750879 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark47(-67.06816896328303,48.164587583526156,-40.09272185789285 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark47(-678.899497901217,-67.1005020987829,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark47(67.96212961151852,-18.56010919911128,19.7628458727265 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark47(-69.32079268923823,8.593308990909804,-760.0155985879114 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark47(69.99735288433331,-69.99735288433331,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark47(-70.01335194621134,-19.25033053938204,0.0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark47(-70.5471561789794,-49.77049776667369,0.0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark47(71.00932170038766,-71.00932170038766,0.0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark47(-71.04126661157022,71.04126661157022,0.0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark47(-71.12170231146044,51.9424160053415,29.15961797422247 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark47(-711.2934065840291,-34.70659341597097,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark47(-71.70635810689065,71.70635810689065,-707.0108227301682 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark47(73.09163364161128,32.31876121572566,2.902605884010214 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark47(-74.26338743122425,-62.821317481562374,-1.494140625 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark47(75.88493309598613,-15.954048890844888,-740.6261504183462 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark47(-76.25187040241106,36.060464152411065,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark47(-76.355053884352,53.20930141555132,-718.4954673287406 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark47(7.697136532644681,-7.697136532644683,-40.09540334313197 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark47(-7.7369791699259025,15.593711159669642,-1.494140625 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark47(77.53635531833822,-39.277450334213086,-64.33680347522876 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark47(77.6271541095056,-84.8547352618636,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark47(-77.7125117419192,54.882675127375876,16.815274281876412 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark47(-78.76445859314569,-85.46931544755321,714.8431142542481 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark47(-79.0546424543699,-630.7650893370102,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark47(-79.26777285105271,79.26777285105271,36.10079358749465 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark47(-80.24000578796996,80.24000095755329,-745.9990347560317 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark47(80.44672924186682,-153.67368028622667,-709.863869538318 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark47(-81.01961910802393,-2.2626101136244703,-40.19140625 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark47(-81.18926572915092,19.83429113265116,0.0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark47(-81.3712126631762,81.37121266300197,725.6660063348793 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark47(-83.43220384763252,-627.1644753927303,715.4550988244094 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark47(85.2194068087399,-28.52339055161345,0.0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark47(-85.30751174295297,85.30751174295297,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark47(85.73533304966723,-68.48437759786832,0.0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark47(-85.94035652322935,85.94038031373147,-749.1914847711002 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark47(86.27711307949278,47.28148508903189,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark47(-86.98759382160935,67.08763974745392,-45.66579732619138 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark47(-87.84433318663582,-14.779314748391243,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark47(87.9747833995728,-87.9747833995728,-99.21710466090714 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark47(-89.760401694415,18.838812448519732,-750.0559993086371 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark47(90.02661967617911,7.635514915490191,-709.8886604965686 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark47(90.9332691917244,43.30531500943505,-93.46023480574475 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark47(-91.11865610311628,-654.8813438968834,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark47(92.49430067048522,14.883958249099223,0.4419630401979191 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark47(-92.66505836145326,-38.66183188659038,73.64817440845957 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark47(-94.16399382997483,-655.0274124200255,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark47(-94.26958815137185,-97.6726397033844,-711.5590275657585 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark47(-95.03814091490597,56.54595937729698,-27.40125356597305 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark47(95.63633512027926,-85.05539641990664,-24.81316554240732 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark47(-96.84460070609337,92.382859384103,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark47(-97.44430904620012,97.87857030772466,-709.0293608683486 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark47(-98.028985746647,-623.4323062831078,750.3727298450403 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark47(98.61116518942555,72.06695304636622,-711.1682609830654 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark47(99.75005621955961,-52.33553005800316,-708.9050272145122 ) ;
  }
}
