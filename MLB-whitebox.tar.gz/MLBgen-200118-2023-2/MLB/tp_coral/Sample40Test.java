import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(1.0236696820009123E-4,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(1.6729061460708424E-37,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(1.7298221062401587E-9,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark40(2.233300881308394E-9,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark40(-2.5281022679371006,8.919403345085811 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark40(3.4004663522570127,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark40(-4.2487275396503845E-9,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark40(-43.78762581945561,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark40(6.618860679616446,99.36131843108052 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark40(-7.148330822486266E-15,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark40(80.55194499884044,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark40(96.23328420005234,-46.541003485004005 ) ;
  }
}
