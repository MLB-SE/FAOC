import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(0.8388393162212406,0.9158817151910178 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(10.328205940617337,60.730074042084084 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(10.656652385660431,23.65665238566043 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(1.1453222007887058,38.508062552122084 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(15.409082065969006,28.409082065969006 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(2.004873402603281E-4,3.2659177121382815E-7 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(2.0725888032157788E-14,2.9792636813633122E-8 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(23.9988681232365,26.0011318767635 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(25.447159065050258,41.980402382915 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(27.172312714946287,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(28.767770188722437,38.204143079050056 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(-3.2108171011246395E-5,5.63628926796158E-5 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark50(3.223055738147178,5.382521515726329 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark50(3.3641098308104525,5.445005166212341 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark50(3.881517516588939E-23,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark50(4.49694672422558,25.522738382677474 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark50(46.52647229381262,71.0663715926149 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark50(48.79688662846985,31.86101517498571 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark50(-55.78429553549624,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark50(59.966325368381376,60.35498585861136 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark50(6.018367142350584,68.25435329603118 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark50(-6.442026251641495E-5,2.8284444341529695E-5 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark50(-7.575726413505901E-37,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark50(-7.951485562890532E-9,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark50(-81.5703557385471,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark50(-8.769367939014494E-9,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark50(90.0250983030545,91.91163636438603 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark50(9.035841761464043E-39,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark50(9.550988124605929E-5,2.2414522745975246E-5 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark50(9.867660793740696E-5,0 ) ;
  }
}
