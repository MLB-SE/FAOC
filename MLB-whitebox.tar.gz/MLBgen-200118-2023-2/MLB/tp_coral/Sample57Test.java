import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-0.001114345584601435,-0.011043817739734695,0.2744430072702124,-4.244449164243932 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.013451510924857857,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.01709919871597709,0.16267098321800688,-9.656278555160396 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.017654849837213826,-135.16449307413467,100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.019013962328566225,-6.442066336079789,54.83676078795554 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.022878992339772728,-55.30325006101968,3.471838763269137E-19 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.025724803332662916,-92.32777396591182,-67.51979991331993 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.026144432207152117,38.82359785345582,-16.905973535125995 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.03321112520362038,-62.58222146614996,42.16849899849643 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.03682193260457689,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.04196852472500012,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.19623184310628972,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.5302312082187406,-1261.0642020030118,1215.0947353659863 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-0.6352777550982154,-0.044521206253723376,0.003800736835516627,-13.941356795150991 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.6585013506232444,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-0.8888974819902549,-0.05877117802724732,-3.528897644276725,0.19385687413749508 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.8938051814084398,1272.7369394530128,-1170.7560595268017 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1.0,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-100.0,-0.025425632021186403,-7.412352335027952,2.220446049250313E-16 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-100.0,-0.026621980674998453,0.4366066701211332,-3.597734775316555 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-100.0,-0.036331621815296145,0.07726286605895998,-20.330546961540133 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-100.0,-0.041830212345890704,2.9078795650554943E-18,-15.7367107529382 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-100.0,-1.7763568394002505E-15,3.552713678800501E-15,-41.739205660405766 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-100.0,-4.861712392494333E-4,0.058299728629990194,-7.017811656268329 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-100.0,-8.673590042966861E-4,-89.34321336995441,8.881784197001252E-16 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1.1102230246251565E-16,0.0,5.429952282385436 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-13.04641119174103,-0.021287879799272935,-38.1467287906633,0.04117774646981945 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-13.178867950532746,-0.04804321219708274,0.19909156180207926,-7.829561574585285 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1.3877787807814457E-17,-99.92346647554858,25.97889154838337 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-14.523864039848782,-0.3026454735237046,0.0133770165222614,-7.2962657793439964 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1848.286619264654,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark57(0,0,1.9721522630525295E-31,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-20.2231122388071,-0.02053052380967349,-41.442666998347434,0.03250869500537196 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-2.3195518329882856,-0.04414586280884346,-9.653693009516047,0.16271455133765822 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark57(0,0,26.070179213921563,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-2714.933966366682,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-28.444818898194214,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-28.94470352745572,-0.0566984959993056,-54.8232546431241,0.02533502085233278 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-32.2571572683992,-88.62899875489578,58.36927297533887 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-32.457167729296714,-5.882685802072748E-23,-3.859762341656896,0.4042799957935732 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark57(0.0,34.97622352669781,-0.029731910826928123,-32.052973609496036,0.038312953347209196 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-3.552713678800501E-15,-7.381762259079078,81.48525313216487 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-36.48890691690619,-0.05235026805622889,-4.089464360346086,0.19010127319130898 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-39.53644750856804,-9.656262294137914E-4,2.7755575615628914E-17,-10.24862338838973 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-4.332761301337975E-12,-3.8558717841646146E-180,7.312694019888868E-67 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-4.440892098500626E-16,0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-4.440892098500626E-16,-94.22760437120942,9.397065750963828 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-4.697304785937466E-13,-5.0487097934144756E-29,7.315149368285876 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-47.30517138551062,-0.02642426917038395,-7.814922535847316,0.20099960295058583 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-4.930380657631324E-32,0,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-50.54149961911987,-0.0413372830416886,0.34005690913761555,-4.344105462219304 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-53.334838770992825,-0.0013703614042587823,-4.110286681617742,0.3821622306346419 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-62.431159346719085,-0.059364526878059105,4.440892098500626E-16,-7.294708714844315 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-62.45942161638318,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-68.95919049019064,0,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-72.46478681654455,-0.049548166633492916,5.550986052741665E-17,-3.404884847647081 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark57(0.0,7.63702451681742E-6,-0.05928330928003832,0.1778658376048642,-7.2445739186875935 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-77.19172353757178,0,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-79.30615786645389,-0.030873263166322315,0.06761572412210815,-22.347421793625774 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-82.41224968300287,-2.7755575615628914E-17,-41.49534590046159,0.037854759195468546 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark57(0,0,8.44049429103461,-72.81764012958705,79.91782369657432 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-84.62692182139507,-2.7755575615628914E-17,-38.528617949987186,0.03866043780522381 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-86.05509628886084,-0.057564962674405355,0.35030428221818266,-4.411334287344721 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-8.881784197001252E-16,27.661818140375903,-19.535533611507717 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-89.61275672729471,-0.012268894040824372,5.026992484193309E-4,-35.22203825880938 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-92.27630464433962,-0.036794088420100846,-19.0973963704625,2.4580382119314274E-17 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-9.580091463254021,-0.15789801457460184,-97.85626212712883,0.016052077737796835 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-97.82588294136175,-0.27177448088727696,0.2814316328256554,-3.9751049842470154 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-99.65618785310089,-0.007820254890989142,-76.30263218155494,0.016572849263397416 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-0.0038644559037010473,-7.03692149396208,0.7537327402704342 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark57(0,-100.0,-0.020849149215873636,-46.02208051811674,0.0016566879259507228 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-0.061500548511329245,7.074136098567497,-8.644932425362393 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-0.9999999999998926,-9.798664747486523,9.455252510549835 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark57(0,-100.0,-1.1102230246251565E-16,-10.304170401102652,0.15244277468730516 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark57(0,-13.002550486982884,-0.045256220100516886,-60.666322319006916,4.440892098500626E-16 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark57(0,-17.634011039523386,-0.03433032729797928,6.860115203521321E-16,-7.783185307179587 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark57(0,-17.670252764741868,-0.04897431514484771,0.022037474102006155,-58.76396637470181 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark57(0,18.10214882341414,-0.062174722436170005,0.09085735806132078,-17.26599023489516 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark57(0,2.1927543335324056,-2.7755575615628914E-17,0.3471870532390236,-3.099548095579422 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark57(0,32.16608150014715,-0.013186527109246518,5.097116460128736E-4,-73.75300722010839 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark57(0,-34.6019217611114,-0.051858378919931725,1.0379986001171049,-1.0379986001171049 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark57(0,3.552713678800501E-15,-0.2773420931464552,-1044.786178166444,2.625914903184659E-5 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark57(0,-37.86197772906571,-0.004188175341956313,-2.2377741121585757,0.6669777853635779 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark57(0,-37.881154105231694,-0.014865880955195072,-11.008537004099738,9.50724056895842 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark57(0,-38.469697203696356,-1.1102230246251565E-16,0.020480688797431798,-76.69645988622797 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark57(0,41.01118279456966,-0.011435506894268551,-4.710837409810551,8.884107153369472E-16 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark57(0,43.256453953902565,-64.35148710885909,-92.15430941773748,74.27782691444597 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark57(0,-49.37692249007038,-0.04653722857228754,15.222324842410996,-0.10319030391589673 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark57(0,52.61782838127758,-0.027688305047002867,-16.32070346420155,16.320703404891347 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark57(0,-53.965208202911505,-1.1102230246251565E-16,0.7805775791822461,-0.7805775461339963 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark57(0,-56.63133489174454,-0.004277543171508219,0.008402598736468134,-28.75783197208068 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark57(0,61.450211765911035,-0.04595772954854873,0.08330767121114135,-18.8553623448882 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark57(0,-62.89029777258261,-0.05335048524794757,3.552713678800501E-15,-27.875522699369576 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark57(0,66.87746694245824,-0.012357090259795922,0.0646291535619087,-24.304764030217548 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark57(0,-6.698367292681922,-0.04806483042901455,0.022112295697021774,-66.44580467055162 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark57(0,-70.34843850647658,-0.011968718739099504,-9.574737879653242,2.5576971182333333E-4 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark57(0,70.818418957918,93.50757248278791,-18.081351498269356,53.54429649315432 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark57(0,-78.75247962355206,-0.025692732754690393,0.012262914985950488,-91.6051012606455 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark57(0,78.83218009213294,-0.013664683024081668,-3.926161611419976,0.05610833314541621 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark57(0,80.15431717826084,-0.6281602473013342,2.8421709430404007E-14,-2130.262869315366 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark57(0,83.62865167792357,-0.01879211001265338,-3.706547136560404,0.008996008030009795 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark57(0,-91.15384735091962,-0.0066838412780294175,-5.571706276927677,4.00090995013278 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark57(0,-92.83417753729447,-0.026659397589165634,0.8766608501003356,-1.6925769838470788 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark57(0,94.83677053959376,-0.043699407303272056,-1.0315857966049592E-15,4.386852850881603 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark57(0,-98.12577483800249,-0.028971685482668885,-7.60159647121705,6.10159647121705 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark57(0,98.24836254598962,-0.05803906339549192,-4.515403254091987,4.440892098500626E-15 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark57(0,99.37444028666663,-0.019470346089047907,-1.7608457655393281,0.1900494387444316 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark57(-1.1152960620196648,2.7191890496399367,-0.028442444828146174,0.0207854303107653,-35.77866016813568 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark57(1.8969949111375757E-15,-0.28903153714538216,-5.829531264481406E-9,-50.703421844491444,8.143668099238959E-16 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark57(2.220446049250313E-16,4.036358618532029E-5,-0.012421675472696738,-0.40443647750693706,-2.8647627996001117 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark57(29.686340178204755,19.932116926807453,-0.02132909128291842,0.35518627781817624,-4.422457805636887 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark57(-43.63278234810785,-67.12335278457097,-0.014504675061719754,1.3234889800848443E-23,-13.072750432067469 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark57(-55.518277096134426,28.141137757919147,-1.1102230246251565E-16,-1.0829991340940313,-2.060548138829945 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark57(-85.42179317310911,22.094386324696757,-0.001500436709888725,0.01839784278382385,-78.86530552705527 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark57(92.2993148086401,-66.8010294354304,-69.0926200074643,-43.88259308759919,50.60397531546789 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark57(-9.438396619377201,79.7341598976736,-86.47903552582348,56.652318450039985,-7.38782508818106 ) ;
  }
}
