import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(18.790795807914407,99.53240641230673,-55.22805003939239 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(57.47407487873781,-66.9565277655029,-9.482452886765088 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(-95.33539761676192,63.94510747876433,19.50290986387077 ) ;
  }
}
