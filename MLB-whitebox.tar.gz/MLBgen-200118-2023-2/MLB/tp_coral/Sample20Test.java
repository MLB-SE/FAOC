import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(0.007538757113788749,-208.36277161945364 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(-0.010056235118947186,156.20123318669457 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(-0.010061406162218952,42.87804564883847 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(-0.015707963267948963,100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(-0.015707963267948963,100.00000000000001 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(-0.015707963267948967,99.99999999999999 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark20(0.015813917936565437,-99.3299910304234 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark20(-0.016603898260177077,94.60406840496651 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark20(0.01674226954544849,-93.82218596653338 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark20(-0.017093056290517383,91.8967503585838 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark20(0.017778813523034565,-88.35214592693326 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark20(0.017909851952885556,-87.70571252778093 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark20(-0.01949428567553735,80.57727033137871 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark20(0.020147086093946137,-77.96642747592632 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark20(-0.020279732440723668,77.45646208036676 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark20(0.021705974148145277,-72.36700440505764 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark20(0.021735502764683674,-72.26869071311114 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark20(0.022045570820528423,-71.2522410774747 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark20(-0.022409762464590362,70.09428722279354 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark20(0.02479765710112003,-63.34454583307991 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark20(-0.025038638112190016,62.73489475572384 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark20(-0.028100209352805883,55.899808683740225 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark20(0.03100406552805782,-50.664204840277144 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark20(0.03772574062201881,-41.63725617829471 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark20(0.038920494695404706,-40.359104864624406 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark20(0.03998533235088512,-39.28431338298293 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark20(0.0425206417405877,-36.94197129897752 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark20(0.04307124711799659,-36.46972010101295 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark20(0.046561547980705664,-33.73591289202423 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark20(0.04748333189144624,-33.08100472784774 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark20(-0.04852581235773351,32.37032520372758 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark20(0.04971710115742081,-31.594688552360182 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark20(-0.05756067860776426,27.289399027047097 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark20(0.06068246181017761,-25.885507606935022 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark20(-0.0630497270281083,-24.913610269794734 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark20(-0.06600253570725895,23.799029991239273 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark20(0.0697214869240326,-22.529587306512994 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark20(-0.07006177917465806,22.42016039699604 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark20(-0.08005887620124301,19.620514318067684 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark20(-0.08108831072532297,19.371427431948643 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark20(0.1158502463486144,-13.55885184799747 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark20(0.12729005533043036,-12.340291020514444 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark20(-0.1362073283308785,11.532392170405657 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark20(0.1566523306803589,-10.027277091714794 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark20(0.15755342174231582,-9.96992835461225 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark20(0.18353680836926856,-4.361789476724979 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark20(-0.24305771727374764,6.462647409075103 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark20(-0.24964790681968665,6.331703686326889 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark20(-0.24997458913436446,2.720645326546361 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark20(0.25434641078103226,-6.175814795150387 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark20(-0.264325412379906,7.300251486936747E-15 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark20(0.2719586182015251,11.55173045945479 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark20(-0.2744450457613115,3.0919413977685655 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark20(0.27752307336715165,-5.660056685509531 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark20(0.2853913652312719,-5.504538632987239 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark20(0.32156253634234133,-2.881771572557952 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark20(0.35031992018146685,-4.4838909702343415 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark20(0.3539612473913249,-4.437763564151669 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark20(0.4242441276041852,7.411642423930782 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark20(0.42896395978151247,-3.6618375296492562 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark20(-0.4401821238099526,3.5685145802810467 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark20(-0.4584241969146475,3.4265126870852285 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark20(-0.46174197554564017,3.40189198726992 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark20(0.5115940893508233,-3.070395767840316 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark20(0.5851001427992146,-2.684662354174023 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark20(-0.6160093205786028,2.549955454114695 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark20(0.6252880874903896,-2.5121161880747316 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark20(-0.6443816466697753,2.43768011536784 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark20(0.6590580358264118,-2.383396061357829 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark20(0.7733276817126722,-2.031216991115592 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,0.02596394595406852 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-0.8788927281145487 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-0.9286593867950756 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.4210854715202004E-14 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.8586373703761776 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.999999999999928 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,1.9999999999999645 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.9999999999999716 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,1.9999999999999805 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,1.9999999999999964 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,1.9999999999999982 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.9999999999999984 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,1.9999999999999991 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,2.0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-2.0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,2.0000000000000036 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-2.0000000000000036 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-2.1316282072803006E-14 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974484,1.9999999999999991 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974484,1.9999999999999998 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974484,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974484,8.881784197001252E-16 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974486,1.9999999999999991 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974487,-1.9999999999999822 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974488,7.105427357601002E-15 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974497,-1.9999999999999964 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974527,1.9999999999999887 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974598,-1.9999999999999645 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633975052,1.999999999999821 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981634027367,-1.9999999999704812 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark20(0.7853984021565036,-1.999999392005243 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark20(-0.8364276677281168,1.8779822660116599 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark20(0.860314783794764,3.6516780982567085 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark20(-0.8920685907907046,0.43807148239802984 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark20(0.9106919233038856,-1.7248383197428918 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark20(0.9967381499868199,3.1518735925090615 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark20(100.0,-12.472136111535699 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark20(100.06546526351534,-1.6796524807476272 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark20(-10.083835996595791,0.15577352317722484 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark20(10.135775310995243,-0.15497544870503432 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark20(10.364124275655781,-0.15156093124862743 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark20(-1.0415755935920212E-20,2.916448807822589E-303 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark20(-1.055382210958598,1.4883672573637097 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark20(1.0679931433415597,-1.470792520146862 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark20(11.012579811430587,-0.14263654417872887 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark20(1.1102230246251565E-16,-100.0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark20(-11.132077053423217,75.63250120543839 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark20(11.169756461986609,-0.1406294158821365 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark20(-11.330639426230483,27.772763698272094 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark20(113.78222627564807,-0.008899710693122634 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark20(-11.446328117470529,0.13723146066356337 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark20(11.470183142843423,-0.1369460545863177 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark20(-11.78097243848706,0.13333333799706784 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark20(11.788664279678287,-41.039871623694346 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark20(-11.863201889328332,0.13240913721681857 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark20(11.905972450961723,-0.1319334756790919 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark20(1.1912845025382084,-1.3185736265754144 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark20(1.1932940557385405,15.796237172967905 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark20(-1.2332676543692025,1.2736864712456395 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark20(-1.2347718358518165,1.1344944845831861 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark20(1237.728958255681,-1382.1825849649235 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark20(12.71692984757344,-0.12352009058231772 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark20(-12.827751796445355,42.57087857367142 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark20(-1.3005103383878236,1.2078307110894713 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark20(-13.051983326602539,0.12034924405651815 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark20(-1326.46040841204,1274.7763740985683 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark20(-13.373719622446004,21.55387308148204 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark20(1.3635402019105527,-2.8421709430404007E-14 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark20(-13.646939651127227,73.50561382732403 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark20(-13.743565523175231,0.11419613336473589 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark20(-13.819287840798737,33.89938076454794 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark20(-13.927398693204072,73.31000102085773 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark20(-1.4110478618277429,0.44277265665918897 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark20(-1.416384724411995E-16,100.0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark20(-1.4210854715202004E-14,0.25376413778184315 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark20(-14.328372446815873,0.10962838470491931 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark20(-143.8542040320973,0.010919363374631822 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark20(14.594259236594027,-13.84429491460331 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark20(14.648246979757602,-32.50309671593166 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark20(-14.694592988837002,0.10689621195933086 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark20(-147.3535186698912,26.053169665307465 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark20(14.99976803756231,0.2094427490960288 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark20(15.153859404484708,-0.10365651975958201 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark20(15.202679588556393,-60.383186735834784 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark20(15.215516470371874,0.020618481760867863 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark20(-15.241710055174067,0.10305906103112505 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark20(15.242715762003655,-0.008714479149156087 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark20(-15.719898308054454,2.7755575615628914E-15 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark20(-15.796774313418723,35.74747340911878 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark20(-1.58E-322,18.25289864367903 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark20(-159.4358255990104,9.076280743940401E-4 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark20(16.152865147661373,-0.09724567823946192 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark20(1.6197734404349444,-0.32072089797383896 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark20(-16.210118659433405,71.13080133864759 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark20(16.367021303775378,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark20(1.6390325657779636,-0.9583679785211103 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark20(1.6765792694319357,-0.9369054928891671 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark20(-17.023856125359572,0.0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark20(17.031790533772053,-0.016081963700479866 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark20(-1.7071267847242666,2.8421709430404007E-14 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark20(17.600018101225505,-33.82609143985131 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark20(-1.7763568394002505E-15,100.0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark20(-1.7763568394002505E-15,4.152753515167106 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark20(-1.7763568394002505E-15,8.95601952499102 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark20(1.7883390842318052,1.75670972093054 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark20(-1.8032577014200157,68.81595918490025 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark20(-18.06373112599296,92.523924323962 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark20(18.107469613731425,-2.8421709430404007E-14 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark20(18.160190602884086,-0.08649668723991434 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark20(-18.199775038185663,4.440892098500626E-16 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark20(18.722771805239784,-0.08389763776084003 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark20(-19.088067981245274,0.08229205430000885 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark20(-1.912141698968386,0.8214853154671289 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark20(-19.249257524478864,-9.809581602653708 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark20(-19.315212771085747,0.08132430874105245 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark20(-19.50861395736517,0.08051808961045472 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark20(-19.525417069524195,0.08044879764675983 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark20(-19.596942280845767,0.08015517442892417 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark20(19.70518011993296,-39.52994561101089 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark20(-2.1015228422647686E-286,1.239367965326566E-16 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark20(21.151444892932417,-70.35558531437414 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark20(-215.98365669801655,0.007272755498283917 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark20(-21.641066795884548,0.07258405242266582 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark20(22.058749377938216,-0.00689060500870331 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark20(22.132134937809653,-0.07097355637893799 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark20(-2.220446049250313E-16,3.552713678800501E-15 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark20(2.220446049250313E-16,-57.444153951082214 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark20(2.220446049250313E-16,-88.11752890390588 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark20(-2.220446049250313E-16,8.881784197001252E-15 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark20(-22.650206610954964,0.05357821444593728 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark20(22.770494961015267,-0.06898384639790278 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark20(-23.2522915006191,83.42977577512082 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark20(2.356194490184336,-0.5111896403701209 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark20(2.3561944901923444,-0.6666666666666667 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark20(2414.9146112057306,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark20(-2422.1740375236514,6.938893903907228E-18 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark20(-2.426089360259496,9.947598300641403E-14 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark20(24.34734306530726,-0.06451612903302298 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark20(24.38781572152429,-80.97203474002347 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark20(24.489991593605126,-30.561923204366636 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark20(24.714453022857015,23.262155754579194 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark20(-2.475961068648684,1.0658141036401503E-14 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark20(2.48114404098501,-0.634321708550142 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark20(-2.4811944873269502,0.6330806935343324 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark20(2.482534616919779,-0.5450956301150675 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark20(-2.4825346177633816,0.07522076134265844 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark20(-2.4825346177633816,0.632738941707122 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark20(24.9417554502845,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark20(-24.975995204252744,87.04286249678513 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark20(-2.507270522741905,0.6264965477586699 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark20(-2511.7526796249276,8.881784197001252E-16 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark20(25.405556565629396,-0.06182884924158394 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark20(-25.931630239912487,83.28997926506355 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark20(2.6061944901923453,-0.602715690790333 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark20(-2.6061944901925345,1.6029056795057788E-9 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark20(-2.606194490195496,0.6027164635780382 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark20(2.6061944960644534,-0.6027164623234812 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark20(-26.140380082705292,14.150164788488226 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark20(-26.57547719357725,77.96211296417277 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark20(26.863020690182708,-0.05847429985299292 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark20(-26.925839427185167,0.058337877674834004 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark20(2.71840022248887,-0.5778385072955636 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark20(-27.558839880797056,125.2814414026083 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark20(27.615275846481726,-1.116617961225419E-4 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark20(-27.988624347263702,0.04204987366046469 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark20(27.999827207415933,-64.02438956532335 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark20(29.661097471470498,-43.63329840068968 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark20(-29.90994574176422,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark20(30.039925771096165,-89.50118021179114 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark20(30.631150999962365,-0.05127325400168604 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark20(30.75686850007152,-0.0435966535409519 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark20(3.0861640392572127,-0.5089801795412523 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark20(-3.098717290508162,0.5069182437540718 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark20(-31.059342064702,0.05057403738685496 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark20(-31.094856424835985,-0.20206510110016462 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark20(-31.106006361598073,3.5853697932251976 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark20(31.366198309915518,-22.986385318035964 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark20(-31.571008932702355,42.178716824493335 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark20(31.681996188158767,-21.9639813298828 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark20(3.21460452836546,-4.4763637241374E-12 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark20(-3.2789810730438202,0.21772460093002388 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark20(-32.99143083193337,0.04761225224807397 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark20(-33.45168439504633,86.7028101265692 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark20(-3.3714134848937602,0.46591624961848765 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark20(33.77212102602781,-0.04615171102007555 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark20(34.46879121990173,-95.33419141070634 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark20(34.55105388644903,-0.045463051053587826 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark20(34.63340317974601,-33.37489381392025 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark20(-34.89627205707089,3.552713678800501E-15 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark20(35.663201851529394,-17.08957533688981 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark20(36.24081747054842,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark20(36.28796294301316,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark20(-36.359997867500596,50.08208832567398 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark20(-36.38727375943065,30.361638613227115 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark20(-3.6477101321842715,0.4306253155741555 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark20(36.91371367967736,-0.033359127074229174 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark20(36.92506419554442,-60.91743884474313 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark20(-36.98610897227427,0.042469899387697296 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark20(37.982169686396475,-58.11100941633916 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark20(3.851029099290045,-0.407890017524012 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark20(-3.9221675433020153,0.4004918987913673 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark20(39.39667402389654,-22.35860318679785 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark20(39.43129313547507,-8.79296635503124E-14 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark20(39.445907526062484,52.83052892846834 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark20(-39.56851880747707,0.039698133115310626 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark20(40.05531837996507,-0.039215674480335166 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark20(-40.0895066809399,0.039182231382800074 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark20(-40.8824851136262,-31.910158294123292 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark20(40.90371972325434,-0.03840228559706947 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark20(41.499762532493726,-1.6977286272060824E-15 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark20(42.65529010991861,-38.55647230944776 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark20(42.96600169858868,-0.036559052848673446 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark20(43.19689898685858,-0.03558572616469148 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark20(-43.303046299856085,36.12471317796596 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark20(-4.440892098500626E-16,33.68630780721483 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark20(44.978161669276005,-83.4976570265576 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark20(-45.4738473717853,0.03454285083802944 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark20(45.54198671376445,-0.03449116826342019 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark20(45.55032400189171,-0.034484855184118146 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark20(45.55588870423179,-82.28910795987386 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark20(-46.00676409908966,42.29352819468616 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark20(46.05543886823017,-88.77201747860381 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark20(46.20006110020083,-40.60901898119318 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark20(-46.520411090870084,0.03376574475506247 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark20(46.73749535827151,-46.21225277021057 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark20(47.037728099603584,-0.033394391911715005 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark20(47.10646295123416,-0.03334566487025413 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark20(47.483216728032374,-38.43734338041958 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark20(47.503975535402276,-5.6843418860808015E-14 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark20(47.71930460887094,-0.03291741863528514 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark20(47.865312819016424,-62.450881432051084 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark20(47.94967438158651,-91.59491876351744 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark20(48.8807016855215,15.559570585741596 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark20(49.278599794834975,-63.64009072466463 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark20(-49.28723850113459,0.03187024419634987 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark20(-49.36558254425841,0.031819665561256344 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark20(49.52670368021767,-0.031716149270445304 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark20(49.64711940839902,24.546168365199648 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark20(-49.69998685538872,59.75503090938875 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark20(49.84459811218008,-9.39113410707793 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark20(49.874407132188765,-54.74321206400043 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark20(5.018216732528694,-0.313018829301015 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark20(-50.458543001268914,0.03113043368603399 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark20(-50.99819960727212,-15.352736766913239 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark20(-51.68661884674275,17.383522446899292 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark20(51.69062157755866,-89.17761586518644 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark20(-52.2533291646067,0.030061172214435494 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark20(-5.235053894287473,0.30005351587859685 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark20(-52.62167694761701,0.029850746422888996 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark20(5.342508796042594,-63.21397495614556 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark20(-54.42291957940399,9.438126488464277 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark20(54.93630722488618,-27.334951405973978 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark20(-5.4977871437821335,0.2857142857178453 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark20(-5.500262358782466,0.2855857092501687 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark20(-5.551115123125783E-17,0.5418295819153798 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark20(-5.551115123125783E-17,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark20(-55.54923868999023,0.028277549140884053 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark20(-55.631076387366065,20.85080686586751 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark20(5.5925932170883215,-0.10721386036389902 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark20(-56.05507976602059,25.41629187488196 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark20(5.61767553896037,-0.279616776707897 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark20(-5.622787143536556,5.551115123125783E-17 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark20(-5.624127271353175,0.2787060006987519 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark20(-56.393079844730345,0.027854416377325768 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark20(-58.533491082099175,80.29638349251334 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark20(-60.162765261506955,0.02610911117478032 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark20(60.33318156960337,-37.868973614216216 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark20(60.93708129929289,-0.025777347606786738 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark20(-61.23461338824164,0.025652098378341037 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark20(-61.28576970190718,0.02563068611906516 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark20(-61.86802031350766,0.02538947131061775 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark20(-6.217248937900877E-15,53.88823618377026 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark20(-63.44187357147772,21.763701146048547 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark20(6.394884621840902E-14,-0.16765020727009983 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark20(6.55293117595339,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark20(-65.88538827697279,61.592576358157686 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark20(6.61934791535019,-0.09618288621081311 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark20(67.1324604318832,-46.7505203093513 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark20(-67.54592117499291,7.105427357601002E-15 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark20(67.67241336066365,-0.02321176752516946 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark20(6.782740649053588,1.3895261721634888 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark20(68.28126423110385,-0.02300479266872389 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark20(-68.32969162201562,0.022986175747030206 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark20(68.398459841978,-93.23249221913863 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark20(68.45598034314904,-0.02294607890970185 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark20(68.76659773134367,-31.676253748799212 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark20(-6.942243343005998,0.22626638813769098 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark20(69.4336394651541,57.64808611590351 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark20(-6.959845324774035,0.22569414311601577 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark20(69.72382892522054,-43.59328710429841 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark20(69.83621590265935,-0.022492575041355885 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark20(69.93877433126138,-0.02245959186180331 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark20(7.105427357601002E-15,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark20(7.129539155054111,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark20(71.47123286916643,-7.038880964205241E-9 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark20(-71.59757299673883,0.02193923985197716 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark20(71.85173051794344,-23.523119560902195 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark20(-72.05949921133256,69.21622266555892 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark20(7.214602075589639,-0.21772459663570812 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark20(72.47564321880499,-3.7711784481758177 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark20(72.48780717588674,-0.021669800591201025 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark20(7.25231946871294,-0.21659226866265868 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark20(72.53523370560933,-17.553341196169384 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark20(-73.71535711113117,0.02130894278144524 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark20(-74.1794429823049,196.17102240714243 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark20(-74.6170566085382,4.440892098500626E-16 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark20(-75.27004187064621,11.758474950059778 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark20(76.18386599019152,-0.02061847566715962 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark20(-7.7137523666383885,-84.03607727893419 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark20(-7.858591051447661,2.4868995751603507E-14 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark20(79.3246242703719,-0.019802127539122753 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark20(79.4685248025792,-0.019766270113823925 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark20(-79.80975250445806,0.01968175915226844 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark20(7.9889171879950425,-5.329070518200751E-15 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark20(7.993605777301127E-15,-0.2863037525062282 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark20(8.033263667527677,-0.1955365081745768 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark20(-8.045440355920789,0.1952405657496321 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark20(-80.9224019858656,12.07835283422412 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark20(-80.93583024903464,-81.82717758994822 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark20(8.207786259862644,-58.61002091357399 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark20(82.34046702916103,-0.019076845000631292 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark20(-82.3486690927819,0.01907494491532203 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark20(-82.56398190187129,0.003990982540734933 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark20(82.801561124686,-31.3471566504614 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark20(-8.31212980332273,2.7228182586243976E-17 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark20(83.423545907125,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark20(-84.12898385660807,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark20(84.41296490611778,-0.018608472389778807 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark20(85.53281066095882,-2.8421709430404007E-14 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark20(-8.569784220178065,76.98378865835068 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark20(-8.639379797338453,0.18181818181888634 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark20(8.63937979736998,-0.18181818182022724 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark20(-8.639379797371928,0.012419847273831094 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark20(-86.49372887147825,13.27908200349988 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark20(-86.56874612823621,49.930882214152774 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark20(86.71446706659324,80.10661077376255 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark20(-87.3055362646878,0.015553468574011782 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark20(8.76571992494297,-0.1791976403815019 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark20(87.75488850637853,-0.01789981565164034 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark20(-88.40368968402095,93.7371381442187 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark20(-88.86913670041562,66.99605946535294 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark20(89.22451316342378,-71.87853755680389 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark20(-89.60478534576409,0.01753027274975949 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark20(-89.62434224109093,-61.163276541635405 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark20(9.036450642132564,-1.4210854715202004E-14 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark20(-90.43261954160192,0.01736979791979021 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark20(-9.04503304207573,26.38427693683782 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark20(9.092461310064664,-0.17275809852016025 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark20(-9.108593829654922,-32.71846328484867 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark20(91.62048402564275,-84.40285378373417 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark20(-9.162444419900268,0.17143856538799004 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark20(-91.90411178251745,81.6356090975805 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark20(-91.9418395383868,44.949776411836154 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark20(-9.232978617785736E-128,7.896825413969131E-177 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark20(92.46773184980708,-65.29704553405098 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark20(9.41597832216511,-49.04579261727866 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark20(94.56142739656381,-0.01661138553045971 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark20(-94.57191557862292,65.55523141165617 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark20(-94.72533212903596,-54.84173229716893 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark20(-95.94980572750656,14.386964204232228 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark20(96.4971701061763,-52.45478672353201 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark20(96.60397409788581,-0.016260162601626132 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark20(-96.73031422545718,0.015454123111824345 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark20(-9.691469530330961,0.16208030390838513 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark20(9.702122755004353,-0.1619023348250579 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark20(-97.0977649433092,66.89511228883194 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark20(-97.13022134152773,73.6339762160548 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark20(-97.64371296168086,0.01608701962625425 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark20(-97.72101421312857,7.105427357601002E-15 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark20(9.860761315262648E-32,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark20(99.99999999999491,-0.015707963267949765 ) ;
  }
}
