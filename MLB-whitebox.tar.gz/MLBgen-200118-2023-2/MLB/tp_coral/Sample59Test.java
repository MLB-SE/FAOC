import org.junit.Test;

public class Sample59Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.18560109101151667,-1206.654968018848,1246.4950764410264 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.9999999999999998,-88.81870823610271,41.197914249852175 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark59(0.0,100.0,-1.0,0.19054709344781173,-1.6342585722738634 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.0,0.3497097040089301,-4.4917150104440395 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.0,-1295.4808031399916,1178.6133562727969 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.0,17.983212016542385,-97.22669853330524 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.0,5.660612095491734,-0.6276710795250022 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.0,6.006249285549303E-146,-3.463323111934566E-46 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.0,64.82766392198945,-38.47001751000789 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.0,68.97470070146225,-1.3013119615952835 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.0,-7.653485978723197,0.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.0,-78.26222925724176,56.64466467315812 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.0,7.888609052210118E-30,90.02609565159662 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.0,80.31813496043071,-41.269166227095845 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.0,-82.39422918477781,0.01906439737754229 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.0,-85.16423363645247,-28.866315833199366 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.0,9.86307415289367,-36.92707348416059 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-11.131435761656888,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-11.517290631519886,-1.0,0.9409883733350739,-1.6693030498525288 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-12.447076843399046,15.772568966845313,39.920738391541505 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark59(0,0,1.5509024620136387,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1746.7706702255496,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark59(0.0,182.22816735258323,-1.0,8.017653874934517,-9.014130719140535 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark59(0.0,2.0679515313825692E-25,-1.0,0.029672113633196773,-0.029672113633203878 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-2.265712134943115,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-2639.1118796233463,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-28.832571721981196,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark59(0.0,31.54156754361704,-1.0,0.46110998746569015,-1.466423364441308 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark59(0.0,35.22763927301448,-1.0,-1.1759389777475118,2.8421709430404007E-14 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-37.49320038151546,-1.0,0.22351473088108853,-0.37691045497190423 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-3.752903533430969,-1.0,0.6429931975546759,-1.9763468916266476 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark59(0.0,39.266739639216354,-1.0,-1.2086362209260035,0.6535101245761961 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-43.29194336128249,-1.0,-1.2446991476771503,1.24469914767715 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark59(0.0,43.688282258237415,-1.0,0.3314649844083782,-4.738951022529761 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark59(0.0,47.30240445892119,-1.0,0.09669875023638141,-1.3302441786463113 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark59(0.04730730197210208,-60.95291699032048,-1.0,3.7369129869928297E-4,-38.779409867111056 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-48.19584604921725,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark59(0,0,4.950492791976259,0,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-5.2710989716152616E-82,-1.0,-2.181126048813993,0.7201617506472398 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-53.08811913807715,-1.0,-0.58770598071011,0.5877059807101094 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-5.551115123125783E-17,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-6.162975822039155E-33,0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-75.0705871454897,-1.0,1.7763568394002505E-15,-0.04065848571288248 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark59(0,0,80.31994716443378,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-82.10404577463385,-1.0,0.6317511170836099,-0.6317511170836151 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-83.61513316710088,67.5983763192987,10.331896412839953 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-83.7585140435166,-1.0,-1.4382351580213326,0.2843209867049836 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-8.471828360560892,-1.0,-0.18180707035076776,0.0015119980991058855 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-96.61613681908379,-1.0,0.7287386861568177,-2.1554999867084548 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-98.73684907550187,-1.0,-0.9796139703046327,0.9796139703046325 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-99.1298033502583,-1.0,-1.7002352686491238,0.8456385994942901 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-99.99999999992309,-1.0,1.057564833269549,-1.485295536813222 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-1.0,0.013416649462069495,-0.04229623657031745 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-1.0,0.17072355333847433,-9.200817907536317 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-1.0,-4.72234055878179,4.315434523636458 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark59(0,-10.836816305203325,-1.0,6.305900068451195,-0.17107545017770343 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark59(0,-11.711754962627126,-1.0,3.4809082505504625,-3.480907947508854 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark59(0,144.70593284325264,-1.0,-1712.0681507976276,3.469446951953614E-18 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark59(0,-18.24804870998799,-1.0,0.5180790149581984,-3.031962850148709 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark59(0,-19.010766746344856,-1.0,-3.8502883130016414,0.4079684945905555 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark59(0,-23.089561840185752,-1.0,2.88967063041443E-14,-2065.2061036075784 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark59(0,23.484391674047316,-1.0,1.1474044572960906,-1.1474044572960906 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark59(0,-23.837026300376237,-1.0,-0.03421614964883801,42.135606306901394 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark59(0,-24.01501360067633,-1.0,14.742522146483745,-16.313318473278642 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark59(0,24.562536821673714,-1.0,-12.697275173760563,0.12371129280090543 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark59(0,25.584856745851575,-1.0,-0.35634099922918683,0.35634099922918594 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark59(0,35.798910433440795,-1.0,0.019290182536833456,-81.42983218509733 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark59(0,-42.22791436564063,-1.0,0.5451825222340059,-0.5451825222340063 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark59(0,-42.57596048519281,-1.0,1.5833289473934722,-1.5833289486236568 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark59(0,-43.30942078424488,-1.0,-100.0,0.015707963267948877 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark59(0,45.17273678192674,-1.0,0.028626803147959942,-54.87152437790936 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark59(0,-45.561751644460514,-1.0,0.11171433581738266,-5.022679613284752 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark59(0,-4.743920763157021,-19.835342047036605,-73.72842885820174,35.30694809907385 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark59(0,49.893820361736395,-1.0,0.009001928790831941,-51.09331429028485 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark59(0,-53.135159694572096,98.10137954786404,-89.10844017486347,-46.21661096645362 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark59(0,57.41882912306735,-1.0,0.42051486190870985,-0.4205148619087099 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark59(0,-59.427876368960646,-1.0,0.018241604413520806,-85.87301396867103 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark59(0,-60.63914899723164,-1.0,0.7507107689586476,-0.8239930237074841 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark59(0,64.33052202993683,-1.0,-2.8763160743498175,-0.2672302708278467 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark59(0,66.78384615788144,-1.0,-0.21313538863627265,-18.565624206107593 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark59(0,-7.82597424335102,-1.0,1.7763568394002505E-15,-17.852053072742578 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark59(0,-8.426090086405884,-1.0,0.12159762082518455,-12.917985698528595 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark59(0,84.86580487627668,-1.0,0.06045352761273992,-20.579843829187894 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark59(0,-92.28447805959574,-1.0,-0.13863113267262933,0.13863113267262905 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark59(0,-92.52796492033876,-1.0,0.02133819872190477,-73.61428896912429 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark59(0,96.6133120166181,-1.0,-0.0011429755591748207,0.0011429755610166126 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark59(0,99.59778156859545,-1.0,-17.190612986941805,-0.017350281007159307 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark59(100.0,-100.0,-1.0,1.2346652807401464,-1.2346652807401588 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,100.0,-1.0,-19.655925038032546,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark59(100.0,100.0,-1.0,7.676944683903904,-7.676944683903905 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,32.94810273359098,-1.0,-5.987384777511263,4.617998938537873 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark59(100.0,95.8134496585372,-1.0,-1.689600733623088,0.6230651518843071 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark59(10.609855533900998,-13.802374134669332,-1.0,-0.04908465242682425,0.049084652426817144 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark59(-1.0842021724855044E-19,-2.2542192712921385,-1.0,-5.012898241527844,3.713104922396835 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark59(10.910571120231229,100.0,-1.0,-1.7928160840866811,0.8707918962968098 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark59(-11.713732726368285,-48.93314610142698,-1.0,0.07940090511269844,-19.546946683279607 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark59(12.36341089734474,0.9367725782545309,-1.0,-0.8737593975115876,0.7662379949100371 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark59(-1.5334008479695882,-9.872708124366715,-1.0,-16.563028300593484,0.003441132234915961 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark59(-1.6790820952636717E-21,-6.77625954461114E-21,-1.0,-2.6072570178443684,2.6048322993467057 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark59(2.2054937603365307E-16,-84.27946852144616,-1.0000000013386774,-5.9008555098819055,5.8948617770482485 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark59(2.2504075268881876E-8,82.73292140181945,-1.0,9.697355085538842,-11.006821297819108 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark59(31.75851164397522,-99.9763861843354,-1.0,7.103998382685766,-8.653052696260321 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark59(35.927050306759654,35.92842544641382,-1.0,0.04042320842452796,-38.85876841178277 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark59(-38.48005909856077,-10.060666737943414,-1.0,0.039196454863540696,-16.2736684497216 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark59(40.24542273116115,-0.05953971059980745,-1.0,0.8261448825748496,-0.8261448825748497 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark59(-60.305973403195146,-41.363819269546305,-1.0,-1.2279453362219264,1.1320798893183772 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark59(-70.30580311492581,-100.0,-1.0,0.6201875847674768,-5.3268943714836166 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark59(-7.105427357601002E-15,-97.98113689446554,-1.0,-0.5666023015885315,0.5666023015885309 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark59(-75.3700723841967,75.17254944100335,-53.09827712038664,16.915688075646074,18.967514101176917 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark59(80.3153331079359,-99.99967718424814,-1.0,-1.0691699339925576,6.294005880685448E-5 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark59(-8.236734996376576,-9.36344849160127,-1.0,-3.6750172827138194,0.4260845326270992 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark59(-8.533583356061536,-12.555731917745483,-1.0,0.3199016407036885,-4.910000939964048 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark59(93.41286268808102,-31.797406163974927,-59.669879954196944,-29.41118088089341,48.41560812709949 ) ;
  }
}
