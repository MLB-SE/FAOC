import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(0.9197794200529898,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(-0.946637233956352,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(-1.0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark19(-1.000000000000007,-0.04448484979561898,-0.9999999999999999 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.01199919765973445,-0.6728788088056341 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.01547105099899762,1.109687089041301E-16 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.018518032119417216,-0.2904292714513041 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.023558478672407148,-0.9999999999951533 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.023865881302415626,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.03096889734883909,0.9999994324262361 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.03226086636332952,-0.6879950310443858 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.03598235876888989,9.597652665027287 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.04025786075940588,0.3199215699468275 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.04899643498068584,1.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.05518069013616844,-6.1711342228489405 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.061764911635682374,0.9999999995883373 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-2.7755575615628914E-17,-0.7071040270873439 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark19(-101.11625719928125,-0.04540217890231658,-0.014684245396079654 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark19(-12.60019661890475,-0.0208743639064021,0.0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark19(-13.407686735253204,-0.03345906673008109,-1.0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark19(-13.620735832255892,-0.04982965439651693,-0.6437364255918873 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark19(-14.932377153826536,-70.96046242656932,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark19(-15.465324983892405,-1.3877787807814457E-17,-1.0000000004960534 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark19(-18.031222999632405,-1.1102230246251565E-16,-0.1601030509311423 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark19(-19.40430258294191,-0.05019452680002177,-0.9225037312465373 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark19(-21.320246141138682,-7.105427357601002E-15,-0.03893983154885028 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark19(-21.527957237289115,-1629.352250430432,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark19(-24.76643138385404,-3.469446951953614E-18,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark19(-25.73216759294491,-0.03610797589315989,-1.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark19(-26.057597582535763,-2700.610993828757,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark19(-26.728710844934398,-1.0118E-320,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark19(-27.07536338942637,-0.021484789280186267,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark19(-28.449342943464288,-0.007173186539567333,-1.0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark19(-29.76700625927812,-0.0218420038186197,-1.0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark19(-30.64668951964481,-0.05439823224813731,-1.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark19(-30.838278972908824,-0.04351764873808195,-0.6157413377358552 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark19(-31.171504428238947,-1.7763568394002505E-15,-69.81313797844358 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark19(-31.87131116320587,-0.01353739519812533,-0.2680281410333265 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark19(-3.243655246777563,-0.0574215450057704,73.11016721109407 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark19(-34.03842141318481,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark19(-34.30182202565335,-0.03378581794228443,-9.723461371658034E-63 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark19(-35.32848012238641,-0.008350533979881156,-77.91939682405788 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark19(-36.16279968286172,-1.1102230246251565E-16,-0.23342412430646134 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark19(-36.81690538275895,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark19(-39.368335383640925,-0.0592996800674056,-0.21760890772377195 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark19(-40.74510609406543,-0.04334547830353395,-0.3505363972437835 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark19(40.93392023144483,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark19(-42.35116442815965,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark19(-45.24018527583784,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark19(-4.595867031632369,-0.010017900494296406,-0.9924129931760975 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark19(-46.24679063294397,-0.9999999999999405,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark19(-47.691319487745176,-4.440892098500626E-16,-100.0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark19(-48.87791798010564,-0.048981595671694106,0.9999999999999999 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark19(-49.633642497154625,-1.1102230246251565E-16,-0.9999999999999999 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark19(-50.93916791609011,-0.017098292189466457,-21.628606324777152 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark19(-51.60344935008569,-0.014374345631056329,-0.6747363234141802 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark19(-57.13251417719407,-1.1102230246251565E-16,-1.0000000007309413 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark19(-57.40739802449561,-76.01441765339969,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark19(-59.62223129929356,0.0,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark19(-61.1552345226458,-15.571435365848913,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark19(-6.187945464696995,-0.9999999999999999,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark19(-63.379878849872725,-0.0063291826630469394,78.25276543960669 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark19(-63.44309721155022,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark19(-6.499364574001628,-0.03692343622590791,-0.22168051306879022 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark19(-67.1930700581037,-0.01612406911811881,-0.3109753823210326 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark19(-71.70090869134565,-0.05539420187173508,-0.999999999999999 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark19(-72.24194322743507,-0.009342620488108593,-1.210184973390412E-122 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark19(-78.83018186340249,-0.019085203839364476,-21.680637547377426 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark19(-79.1776527187998,-0.003981345898288243,0.9999999999999998 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark19(-81.46697171885356,-1.1102230246251565E-16,-1.0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark19(-83.34435948326632,-0.036589715924278926,-0.10361772689684416 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark19(-84.55527355798054,-0.05077855306734896,-0.9995865390704948 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark19(-86.52430439369554,-0.05904550049239544,-0.9999999999999999 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark19(-9.10114896498851,-1.0,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark19(-91.34140573573646,-28.464198609933035,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark19(-91.38350235641408,-0.037821405131580055,9.926167350636332E-24 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark19(-92.74495232216674,-8.881784197001252E-16,-0.7520826058550343 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark19(-95.87009003885025,-0.013089272504418492,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark19(-95.96664193964652,-0.02867031846032375,-0.045685404865317025 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark19(-95.99757897236245,75.52922894768602,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark19(9.865015749776077,0,0 ) ;
  }
}
