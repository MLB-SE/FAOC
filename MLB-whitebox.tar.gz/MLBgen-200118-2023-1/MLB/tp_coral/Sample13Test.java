import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(0,-0.15725734408906078,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(0,-0.3970869398486627,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(0,-1.0199901057809058,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark13(0,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark13(0,-17.145937662732067,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark13(0,-2628.895873606669,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark13(0,-2654.4213685750296,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark13(0,-3.0814879110195774E-33,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark13(0,-40.748218925688164,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark13(0,-41.18308659863388,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark13(0,47.80799029565196,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark13(0,-49.33071179396244,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark13(0,-49.782956728112104,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark13(0,-65.31909843119911,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark13(0,88.18968676789876,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark13(0,93.44589113077143,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark13(0,-9.486102136409968,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark13(0,9.860761315262648E-32,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark13(-0.9999999999999998,-1.5707963267948932,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000009,-0.02742794479704877,-67.1179400529362,-0.8816379500132124 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000036,-0.2366705881994009,-50.69230677756036,0.9978669083841976 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000036,-1.3799925319164073,-47.95159084447573,0.7237966262677893 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark13(-1.000000000000007,-1.5707963267948948,-100.0,1.0000001192632388 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000142,-7.395717272120014E-6,-30.86241952760782,0.833025692063781 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000355,-1.5320706712104095,-100.0,0.31517116039131565 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.0012658347980151511,-34.68936704588185,-1.0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.0032628082447367923,-10.949539657571535,0.04344279577835683 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.014497232763322222,-67.24535688603162,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.02442804019004005,-1.5707963267948966,0.02144325036333558 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.025750759455654082,-86.87114986508968,0.20378649867515009 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.028433367738498028,-44.4384816046855,0.0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.03301218279223183,-0.08587456693496794,-1.399144533463641 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.0330758680800994,-16.44872979197683,-76.67591681865322 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.033310752051313376,-95.31340203998789,0.9817926202281334 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.04015386784003956,-15.257133483406456,-0.007600321211216013 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.04726643957054679,-3.4969792820701735,0.0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.05123451428399449,-93.93100058991944,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.05371835196562058,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.06955548023963823,-5.5619518707354025,1.0000000468443468 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.07005860952618215,-0.07468663581115642,-95.08536218527665 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.07698904844855596,-6.953088111993929,1.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.08094848984461578,-1.560244455728045,100.0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.08465107873752231,-1.5707963267948983,0.1434149697343754 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.08694687337592877,0.0,1.0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.09140143223581101,-43.08220502762141,0.8548359669710871 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.09217181965948296,-1.5707963267949019,19.921496292716142 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.09696017972994853,-63.807378389429644,0.0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.10138764266278577,-54.25367479031087,-0.053291820382015964 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.11621870444326654,-23.546706249637673,-100.0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.12968498741147758,-100.0,90.7783910460939 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.13070182660832508,-19.031942966526998,-0.7070102384306214 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.14207252491284683,-94.84776107209221,-54.197381746581705 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.1442016413936642,-14.797425015567477,-1.0000000000000009 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.15209127001413558,-15.663033182947391,2.710505431213761E-20 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.1860894995745271,0.0,0.9999999999999982 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.19370022383451477,-2421.533129983063,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.1962491676520961,0.06643852876833453,-100.0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.19921263233141226,-72.24560257470542,2.2697955651659032E-8 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.20660554920952004,-0.0717098941143787,1.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.21042838949173076,0,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.2144433413157504,-25.13920356511362,-1.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.2389210395282829,-3.1553961733455935,1.0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.2497720145654736,-77.40110254605003,-37.23586625797773 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.2511129480760719,-62.36090607543832,-1.0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.25323157041658817,0.0,-0.3638841150746421 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.26900206824802775,-83.73028549373254,0.9999999999999996 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.28168598298516645,-74.67939055551724,-1.0000002559610623 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.28266649461430693,-53.85475044353261,-0.14163339746209536 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.29193698936127765,-122.59322502562209,31.357017647234667 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.29515406382856135,1.5707963267948968,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.2975761619653253,-1.5707963267948983,-0.03238817116593817 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.33503112784552713,-1.5707963267948983,-1.4022335533734918 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.34587279689915984,-44.5248107777876,0.00971067404867786 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.3679131127230444,-28.502663168521263,1.0000007152232364 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.3762067246299452,0.0,-66.69812734029668 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.39454805707566915,-9.509859206425382,-22.108696066398068 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.3990739986051486,-60.88323540173157,43.86329840972402 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.39912974610922414,-11.154703764213039,-1.142987391282275E-100 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.4396537106960926,-32.77816538424123,0.02390572360884677 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.4420331612837414,0.05873976358475516,-6.943210233382629 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.44241067905558207,-9.6130001721246,0.5993179069292065 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.46812606948452257,-80.2557551650274,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.4725362485434926,0.0,0.3620901716212712 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.4781672943950831,-4.532316711725482,0.0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.4882336981443861,-23.898310226886004,1.3435778790592146 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.4935375584744608,-5.112212328855783E-17,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5068804053623406,0.0,1.0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5076258911481553,-49.02102255682661,-1.0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5086394623731145,-81.53666179124616,1.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.541470737758193,-77.35375351626743,-42.449520039582865 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5432161873760513,-68.51912375546942,-1.0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5518110045395599,-40.75380829661754,-3.506898312916178 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5743654391135372,0.8669473276045362,5.421010862427522E-20 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5793891300893935,-4.523137402837509,36.510139514098526 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5799311795070516,-58.057031195210484,1.0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5834372454463461,-36.64456190097647,-0.5843896233200984 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.6430495680791415,-0.10146607132363411,-0.6299257196487593 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.6503216606194522,-34.58938269600107,-1.0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.6683545194350586,-58.30099060193115,1.0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.6773719400938086,0.0,-0.8157246181978738 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.6790337682506187,1.5707963267948948,-39.72296440692337 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.6884155755060899,-33.17240019062267,-1.0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.6950668635513266,-4.582033460384277,1.0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7082735257840458,-12.235236096418795,-1.0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7696598067162757,-53.707944265014476,0.06256070237162277 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7925317812770913,-71.57608875157914,1.0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.8335632199633405,-0.36960070492460523,-0.9621933438487693 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.8530433640824097,-23.629099558259583,-1.0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.8765691985162891,-1.5707963267948966,-15.596950150345307 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.8807084289370731,1.5707963267948877,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9122014526607092,-63.72973206125869,-1.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9532191375740152,0.0,-1.0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.958546656418055,-94.45925587137701,0.06255252524470602 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9676817284233774,-90.50158361720194,1.0000000253329249 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9686961705683645,-19.389584075242368,1.0000013013603763 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9699951543018499,-35.366336253959055,0.017936143872841454 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9751320447841845,-12.29129450993571,-0.4857574415124153 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9810424671481806,0.0,1.0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9903841765336356,-100.0,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9930457020493708,-30.28556289613136,-55.586875872560014 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.0578469924787486,1.4164519222983776,-8.316327812515919E-112 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.0689425127600174,0.0,1.0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1024490576237156,-1.5531849478461464,5.293955920339377E-23 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1073607777129022,-100.0,-0.9999999999999996 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.114213617352441,-65.94680163400308,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1221707258908187,-44.27761473370281,36.091013392247575 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1273072654878664,-66.18426411578955,1.0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1290798008317684,-20.335116045564956,0.041332042037677874 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.131058058565441,-1.5707963267949125,0.970829156270949 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1700785934613112,-27.54182092285798,-1.0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1822153656500387,-63.909962971694874,1.0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1926506162441326,-0.336027126529253,0.31723564661201564 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3037206793591887,-19.83304521862756,6.938893903907228E-18 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.323505924305623,-1.2414416081859452,26.995345886922607 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3380526470658172,-44.084027784046754,-73.75947831747281 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.341266026482965,-31.88649787687485,100.0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3480150895835856,0.0,-51.90184106227584 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3627064120294385,-10.872007368757522,-0.6987355421884089 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3946340926418912,0.0,-0.06262026809595554 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.397770344633708,-73.63180974104014,0.5347632796658444 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4001251776865198,-8.811302473909892,-2.1175823681357508E-22 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4064751134418318,1.3827408192219879,0.5314778103274314 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4097179851063197,-35.86606065886252,1.0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.424215299296919,-38.64931197289167,0.9934070769582112 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.434656839420238,-35.74831582417298,0.012950517572830014 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4575237393503642,-54.83607916819716,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.462189622316126,-48.39400951760132,-2.8853058180580424E-129 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4700129375008917,-9.59785776040108,-1.0000047790576492 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4884772809775484,-34.69390722548702,1.0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4927897085064912,-38.860168142339845,0.6479362096295755 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4932874083596048,-72.40055222901228,-0.9658812268565752 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4936666404544268,-95.21591133836307,1.0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4980239978684085E-4,-37.73181841573791,0.9061817175732916 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5065016249966172,0.0,-1.5709099088952725E-89 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5077633703622637,-1.1865334212379446,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5114969031438605,-72.72344878048821,-3.636213629364754E-16 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.523305327098862,-4.278822872374782,-0.25683396735305664 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5238874040628865,-66.34791526340317,-0.6304999937057743 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5291253873727633,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5294301147102658,-79.76567782351627,1.0000000807904086 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.537298917337502,-135.5484441878217,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5403594220117136,-0.7555547897813378,4.7477838728798994E-66 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5441909963541924,-72.86386784324199,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.555637330052564,-1.5707963267948974,0.4158327648332648 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5598759663362392,0.0,-0.03238303382538457 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5625571244781788,-47.7517723579366,1.0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5698179121048401,-14.566108830425922,1.0000000001938676 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948548,-19.34993433920785,2.710505431213761E-20 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948664,-68.79816571634773,0.03225704533118584 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948841,-67.1160001855788,-29.095526080190925 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948877,-31.113531778609712,-0.05606368990551358 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948881,-21.71440503157303,0.13409313153809022 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948903,-45.27025574479091,0.7858798229373116 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,-100.0,-42.9787780872393 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,-2.7099756224989306,1.0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,-6.612290116032087,-1.0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,-66.35614044373983,-0.08739092425421546 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,-88.47228238764681,-0.34198811716561184 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-0.11311536136491895,1.0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-13.331138405542726,-27.287246157067866 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,1.7763568394002505E-15,-1.0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-19.69310250817782,-100.0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-23.61542774777668,99.62119082778568 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-90.62715709655409,-1.000000533197293 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.570796326794894,-97.25758407277738,0.364862304600164 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948954,-100.0,-0.36607764113303987 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948957,0.0,-1.0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948957,-0.5927431376111236,-100.0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948957,-26.621618585023214,-1.8231764704888866E-16 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948957,-36.551036557415486,-1.0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948961,0.0,1.734723475976807E-18 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948961,-26.897378165956766,-0.0625525273141051 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948961,-32.779281821805824,-0.9999999999999991 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948963,0.0,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948963,-0.05715413371810682,-1.000000074045276 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948963,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948963,-23.789237895787984,17.94808203860824 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948963,-56.411463279148485,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948963,-60.45765450128755,-0.36209034272856017 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948963,-91.71071304038244,0.9999999999999999 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,1.7128589199644606,0,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-2.220446049250313E-16,0.0,0.0625534336808109 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-2.220446049250313E-16,-4.340772511083912,0.02498295737019586 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-2.2618582926576243E-16,-1.5707963267948966,47.94978292813358 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-3.552713678800501E-15,0.0,-0.424668256411895 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-3.552713678800501E-15,-10.394260037745312,-12.616285929490049 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-3.552713678800501E-15,-5.803243546071011,-0.013238123992411524 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-3.552713678800501E-15,-65.94089514531672,-98.44584072170765 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-3.552713678800501E-15,-79.63421578030577,-0.9999999999999997 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-4.440892098500626E-16,-31.80639055935943,-21.643925363690133 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-5.437937439614921E-15,-2.3090325913354377,-1.0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-7.105427357601002E-15,-100.0,0.0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark13(-1.0,-0.11801556434892618,0,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark13(-100.56845383561627,-1.5707963267948963,-1.5135973374006082,0.02683015988894899 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark13(-1.0057875398100162,-0.6777584541078426,-59.52059429501036,-0.3640184203217407 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark13(-100.70224873193118,-0.5174558479523294,-8.162433469566519,-2208.813343395047 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark13(-100.82188717587901,-1.5707963267948948,0.0,2319.2026688078486 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark13(-1.0095655104235408,-1.4328715916783918,-52.611549514426265,-0.2719610663685206 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark13(-10.105286635126003,-1.5392443698812208,-10.994318689194326,-37.44595592319402 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark13(1.0,-1.244893234509743,0,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark13(-101.42963413811657,-0.0021049422729724106,-65.49156639704827,0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark13(-1.015115299174862,-0.5910703629539413,-162.41558238084104,0.0014296096283369572 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark13(-10.174751590219145,-0.5979864887739869,-47.01717001004047,89.50510993110657 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark13(-10.188518062156106,-4.440892098500626E-16,-2366.5596421039822,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark13(-1.0213545277506995,-0.9929525251727782,-1.2770339618423487,0.0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark13(-10.219281846633184,-1.5707963267948948,-59.86855993201016,-1.0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark13(-1.0219371699494744,-0.8549249863585722,-95.29379020831324,1.0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark13(-102.26499466236041,-0.17461714147200524,-77.50851778191591,19.127207023241716 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark13(-10.27605230745025,-0.32722711944499494,-22.513746565238435,49.481278534411835 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark13(-10.294732001046977,-0.8053218809715437,0.6685862277194383,-0.9999999999999999 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark13(-102.9728868070955,-0.9759729466138298,-59.106865429545316,-2281.0254957823167 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark13(-10.298084140794437,-0.16482227880618083,-47.007681303524905,0.4017051776699115 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark13(-10.347247914219757,-1.037137773631261,-8.879190055756666,0.0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark13(-103.49838356097622,-1.5707963267948912,-77.12184069016293,0.039354766478444 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark13(-10.421923917822838,-1.5707963267948948,-10.418690542886864,-1.0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark13(-10.440996481389305,-0.1791511872960896,-7.007130034762113,-1.0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark13(-10.442508631344113,-1.066505558998112,-83.65322564408993,0.9860696831360605 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark13(-10.476877322108685,-1.2135289018502367,0.0,0.0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark13(-1.0637433791303499,-1.5707963267948948,-40.113039940225946,41.33877311218802 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark13(-106.53453592819213,-1.5707963267948912,-54.64557325515153,-0.34605726629926525 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark13(-106.74404240470838,-0.34085173438111127,0.0,0.5729865183630665 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark13(-107.10575483814351,-1.5448545697085567,-14.604622012565201,-1.0000000000002558 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark13(-1.0785195194738968,-0.32853598039451115,-0.9548711429722035,-0.04014568501151952 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark13(-108.22557053536701,-0.30032766802760236,-0.6697131933195521,48.68319928438151 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark13(-10.91497009166428,-0.7517496681791124,-1.5707963267948966,0.06255476727729514 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark13(-109.36260509992373,-8.329248924652265E-16,-92.19592784154962,2042.8134144974476 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark13(-1.106506094073188,-0.00162678152351333,-100.0,0.6645795088188313 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark13(-11.095531860330608,-0.11501530076906838,-6.789804809954614,-73.39681101096724 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark13(-110.98543587108912,-1.5707963267948957,0.23119087354708587,2050.48648373879 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark13(-11.136862106934071,-0.757920421256022,-0.13693075129879664,35.36191804892256 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark13(-111.40735233001205,-1.1927445482189099,-67.31864157784707,0.38804534476436064 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark13(-11.152165480704042,-1.5601243333781332,-45.58072985245024,0.13514296081747118 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark13(-111.72465891328574,-0.6320197958463734,-67.87464190489956,60.28146982190603 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark13(-1.12181947388898,-0.0025297798237044404,0.8739408669626954,-0.9999999999999982 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark13(-112.4497811238548,-1.5707963267948963,0.28093138439580667,0.0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark13(-11.261862282039079,-1.5707963267948963,-20.543597873991928,-74.45026855070547 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark13(-11.267872496677072,-0.27846364675695157,-42.92741961409143,-0.2605764598322742 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark13(-11.267926972991418,-1.333889076381908,-10.955123560980098,-60.49851035139522 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark13(-11.309121407568332,-0.05198890497292917,-2.8773590545392373,-1.0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark13(-1.1352451915554558,-0.6728171242311465,-100.0,1.0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark13(-11.372889566854727,-0.8189134882494216,58.800460932636355,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark13(-113.89942165103865,-0.030548393312387123,-1.5707963267948966,-2187.106394653611 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark13(-11.438377549748107,-1.133787156607318,0.0,-2103.9891714309956 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark13(-114.75714107983485,-0.15369474777173409,-9.82164367673283,-1960.661742719522 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark13(-11.50735745748803,-1.3228876668119633,-1.5707963267948966,1.0000000000000009 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark13(-115.3712391320829,-0.32104504920104615,-101.74532823778594,1.0013014132648625 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark13(-1.1551414650896517,-0.6441991239937442,-16.095280920127678,1.0237715283855777 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark13(-1.1552915314081311,-0.35301332037907635,-53.4025616551389,-69.46274008687708 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark13(-115.85520985316074,-1.167172955700707,-59.37569857858873,-2054.5551788691046 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark13(-1.1713091555295734,-0.001954948454681202,-0.009006644320427803,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark13(-11.727065480053724,-1.5453780172422742,0.3920356317222058,-78.36999422982849 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark13(-117.44164710709427,-1.5707963267948963,-45.32312276649924,-1870.0742444866635 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark13(-11.844583772529177,-1.3896440260827192,-31.17398622226773,-86.70668988685134 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark13(-11.949767862438536,-1.1864617325754359,-82.2974783535788,-0.9625306140728507 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark13(-12.04710939131948,-1.5707963267948912,-72.75563127177139,24.466224848100566 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark13(-1.2062784020262869,-1.5707963267948957,-44.32848285526413,-0.0049083806989239365 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark13(-120.98573162542108,-1.2061058882724922,-4.239165548221543,1.0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark13(-12.107208422108716,-1.5707956882268583,-25.166436184239217,-0.36208955796033654 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark13(-121.88492132905037,-0.8765795229616202,-122.59902985092839,0.9999997910073879 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark13(-12.209309027618488,-1.2693676830707616,-77.65566305618046,-0.47706984167876154 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark13(-12.304735369272066,-0.7102826808941096,-59.89356803642292,-0.9888097073423852 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark13(-12.340194234313557,-1.5707963267948957,-32.63902189467139,85.42012524298283 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark13(-12.356546946805068,-1.4747511135277356,-73.28934416557783,2123.201406142638 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark13(-124.30894498809045,-1.5003120886244563,-100.0,-1.0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark13(-12.442775680191708,-1.279652006913715,-99.70916334892124,-78.62300152630901 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark13(-12.44819442223292,-1.5707963267948963,-90.60943080330345,35.749144545053895 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark13(-12.486724285387634,-0.3673282520374088,-34.997977111608066,-0.6165050711917437 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark13(-125.19817524601167,-0.34567046220805975,-92.0306044400091,-1.0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark13(-12.573572698167858,-1.4600599263202523,-1.5707963267948966,7.061951220928476 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark13(-12.58774787211679,-1.547067666591218,-82.64774730788098,-93.91150139507727 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark13(-12.605867687233806,-1.1513920223416216,-28.755090397298574,7.305623810639911 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark13(-12.664657115585383,-0.12046508423619917,-36.53222883468832,14.199214542347079 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark13(-12.68695203057404,-0.21601172989652379,-26.501452839265603,-0.05661019371383656 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark13(-12.716184987274552,-1.5052382471731411,-68.43060447959549,-0.26445811882587933 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark13(-12.804400739585766,-0.9744523760625095,-8.165196224879342,1.0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark13(-129.30787102919098,-0.48088205152497565,0.0,45.94453384021541 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark13(-1.2977005219442195,-0.04152264205016548,-79.8635800456764,-1.0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark13(-1.298572413887642,-0.0343073118290137,-32.48044281149931,-1.0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark13(-12.992837127080339,-0.888058601477939,-70.03961778601348,2277.927963509626 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark13(-13.025039705848982,-4.440892098500626E-16,0.0,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark13(-13.079580100916179,-0.7589514264909029,-27.17106932014283,-79.9322080941222 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark13(-1.308027263242911,-0.3293843294096092,0.0,0.23135304455443007 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark13(-13.114079450773701,-1.7763568394002505E-15,0.0,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark13(-13.13718533740121,-1.468614118163249,-75.80434969938926,1.0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark13(-1.3138354448737743,-1.5077262231792146,-27.868373821610184,7.954294671095312 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark13(-131.50556296097187,-0.4387144274263049,-9.472473280049073,1.0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark13(-13.199526252649093,-0.8819884386277101,-2.4888177384817166E-16,0.1700102935483494 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark13(-13.212417534031193,-0.45708862300290287,0.0,1.0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark13(-1.3217424330941765,-0.9734828615068304,-59.81958788025345,-0.9194831530351304 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark13(-13.218919297414345,-0.7380051548012435,-95.67863265665389,-1.0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark13(-13.23698060429976,-0.7616615091436767,-36.46166837989795,0.2748173497184885 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark13(-1.324185798077167,-0.9808058824528408,-87.23320252759672,-1.0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark13(-13.241860024852288,-1.5707963267948957,-4.52226385870577,67.57840724695555 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark13(-132.66434943924898,-0.0877558448917132,0.5424649251347027,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark13(-13.312343533345924,-0.42056975072064673,-35.455681860687484,1.0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark13(-13.323432943276455,-0.14438563028384813,-83.69000429562581,-1.0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark13(-1.3366553295065755,-8.881784197001252E-16,-30.595393703253166,-58.93669302511722 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark13(-13.391729095043756,-0.07250831251588274,-62.147288274874974,0.9332741277028643 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark13(-13.429468024475781,-0.3960495641026436,-45.75724964320458,-100.0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark13(-13.436855378762417,-1.0137057916096959,-95.46055360501288,0.7709820647137148 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark13(-13.445875305850894,-0.14276008021584802,1.307044184298138,-0.9746703375271134 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark13(-13.512959275526343,-0.48435081477884806,-4.74945537574898,0.05299943213286068 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark13(-13.531443655183354,-0.35586431851232475,-0.5701578774759342,22.161459237318024 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark13(-13.567680465510682,-0.05990067958089253,-6.803092848796564,63.69036844637847 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark13(-135.91668525009638,-0.12197497621476736,-14.454609764242456,-0.33940284194275283 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark13(-13.606259037290188,-0.4542828088161478,-1.5707963267948966,63.740303974259604 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark13(-13.608051730937984,-0.01925213276111215,-7.811178441442301,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark13(-13.66183707686961,-0.8817640682357608,0.5350638097157222,-67.38569438622771 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark13(-13.722010977804905,-1.4711930281787549,-50.19222598083066,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark13(-13.744693524570305,-0.6673949441610794,-1.5707963267948983,6.604305633647905 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark13(-13.747882750401331,-0.05853707602249356,-12.124952400744206,-0.04156281108042655 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark13(-137.76291182693797,-0.3904840188465506,-100.0,4.641676199545227 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark13(-13.837104236856598,-0.6172995806058993,-42.688186538467136,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark13(-138.43030949371592,-0.7683134910456089,-0.4000601377841315,-43.74025310153253 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark13(-13.846294254295819,-1.483920241373054,-73.86999357765875,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark13(-139.45173553085056,-1.5707963267948948,-10.815718083363095,-2128.3442406580857 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark13(-139.67049213923823,-1.3185479275438396,-49.18824788177359,-100.0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark13(-13.97965883075703,-1.5707963267948948,0.0,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark13(-13.995711633660669,-0.1974069638375435,3.385880263545738E-4,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark13(-14.036547633776138,-0.4408848901111858,-62.58886642756473,1.0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark13(-140.63332008657767,-0.30043799045147074,0.0,0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark13(-14.097163942933882,-1.3240831897359684,-13.3302655747304,-0.04708079253728798 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark13(-141.23518357946955,-0.8804224913098295,-25.196365908694233,-1.0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark13(-14.129185875566172,-0.5810409740887157,-40.48792085283793,1.0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark13(-14.220090415221758,-1.5707963267948912,-39.342156136044096,0.0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark13(-142.20448544008968,-0.46460026514698516,2.3535090162125414,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark13(-14.241436679859012,-0.40759255024884955,-53.76376761109528,-0.4489845170560479 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark13(-14.249026154484245,-1.446797554238118,0.0,-32.46603071334087 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark13(-142.93355825626054,-1.5489150318499192,-94.32260381643609,4.255926022348305 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark13(-14.381426312067958,-0.3184480178220761,-61.288635205856934,17.777019863986737 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark13(-14.415635788795228,-1.3247698871543263,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark13(-14.423601048827845,-0.2932822680011289,-4.288295098108442,-0.010390876490467296 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark13(-1.4504788266819453,-0.8385283080373087,0.0,-73.08345123686138 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark13(-14.51933175364484,-1.3664921758893294,0.0,-1.0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark13(-14.523799729086972,-0.605944495264396,-1.5707963267948966,1.2924697071141057E-26 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark13(-14.60530916147636,-1.5707963267948957,-68.73237178381105,1.0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark13(-14.615635572477672,-0.8418180411931439,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark13(-14.735397292717353,-0.27266879221389634,0.0,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark13(-14.744742642428847,-1.318954274031606,12.368180397623888,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark13(-148.1431930711044,-0.48797145140085973,-1.5707963267948983,40.56250357967659 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark13(-14.81773540950958,-0.41542749152912906,-56.91878963919518,1.0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark13(-148.30842906271033,-0.7485090534506766,-81.67666531143013,-100.0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark13(-14.959777005059928,-1.3493707221456808,-30.073923843586297,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark13(-15.019847809364691,-1.5544108341927143,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark13(-15.071955407439313,-0.8036178047878854,-29.888860194154148,-6.406665904585923E-145 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark13(-15.076159495582207,-0.37495723434635814,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark13(-15.077863824711361,-0.08169988227653327,-88.67112195774935,-0.004588883937464975 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark13(-15.080715867888014,-0.57650137210189,-1.094981662297406,-0.9302320078632257 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark13(-15.202498721609212,-0.715187544621009,-75.68398974572526,0.011701329815738015 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark13(-15.202749234017432,-0.046201846349247525,-37.70382134012048,1.0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark13(-15.24361556646528,-1.5707963267948912,-61.254750607085676,-50.841748117680076 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark13(-1.5344994355770738,-1.5445332817795778,-82.01510188902161,1.0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark13(-153.47094405811097,-0.9195723839482639,-37.981058920000606,2281.524873448774 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark13(-15.381597737813786,-0.5400196690321576,-1.5707963267948966,3.885998603498882 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark13(-15.393277764250731,-0.24765244259508667,-71.14336727109689,-0.034429033315197755 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark13(-15.403241971826034,-1.5707963267948915,0.6223049795490254,1.0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark13(-15.445501704934212,-0.7100170413740584,-71.44632673105633,-76.39010435550423 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark13(-154.66417197120057,-0.09248648297622708,-18.97317970151005,0.0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark13(-154.72551414250722,-1.570796326794891,-100.86227486221755,-0.586497418558731 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark13(-15.505168083957386,-0.06307694623337035,-25.566236365904487,0.4393511863472961 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark13(-15.581128250880955,-0.5598144004234151,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark13(-15.592867269109535,-0.21387588007566347,0.0,7.825615097914036 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark13(-15.613700286259096,-0.5030374134894038,-92.81140069146099,-0.8678065889888147 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark13(-15.624177428382346,-1.4210324242444856,-1.5707963267948966,0.047729310087380274 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark13(-156.85106334739544,-1.4558126976957857,-0.2381900167215412,2080.844026383276 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark13(-15.691420405659223,-1.152766498134282,-0.5134110211512619,-100.0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark13(-15.717436984382552,-1.5707963267948828,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark13(-15.72171378227386,-0.6752992591145386,-1.5537850407991334,91.81914186287682 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark13(-15.757804115677871,-0.0374560661326081,0.59022307878746,-93.58706965211567 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark13(-157.58442099715396,-0.6931465077749833,-76.30243619324237,-2062.8070979085555 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark13(-15.764323828720759,-1.1512624268042664,-78.22630210462549,-0.018727534982406063 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark13(-15.814781923173726,-0.39965132452225216,-31.276410838284548,0.0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark13(-15.835567930863377,-1.1158373956454974,-78.29855394569555,1.0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark13(-15.838040247783482,-1.5707963267948948,0.0,-34.67393185700746 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark13(-15.915400625290559,-0.5225946086361186,-49.12002917045548,0.0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark13(-159.51737206838948,-0.025318609010953723,-34.89522636449506,-1.0000004116421464 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark13(-1.598746098072393,-0.13026719365164255,-3.3818500668444713,-1.2684874695268933E-7 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark13(-15.992457245498997,-1.201357250982113,-61.36343491414024,0.04815312921281068 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark13(-16.09183186268066,-0.4664000987082758,-1.5707963267948948,-0.8975337392116501 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark13(-1.6159007367065459,-0.47669561930788557,0.0,17.64914816270793 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark13(-161.7819005382038,-1.2492790160917036,-68.62869071564185,11.307877191754809 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark13(-16.183234958284256,-2.220446049250313E-16,-72.54355888461036,2.710505431213761E-20 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark13(-16.19858999481484,-1.5707963267948957,-99.54833872054627,-53.292692749083635 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark13(-16.21427824696721,-0.10853414181041465,0.275409080465181,-0.34871521868986477 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark13(-16.242206818719357,-1.0057608301867456,-32.50191722597961,0.417982374242968 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark13(-16.25981860529557,-1.5476187147296987,1.7763568394002505E-15,-1.0000000000000142 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark13(-16.341130745102816,-0.9476583821888038,-71.47280994179015,88.18706890504046 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark13(-1.638422229259417,-1.4659210761878148,-22.72786135127666,-0.9989015601536082 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark13(-16.4407805603943,-0.7585066277167126,-82.48219117401138,0.9996679309294233 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark13(-16.483327077483807,-1.5707963267948948,1.1597676981616465,-0.2676406422791182 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark13(-16.501399773546638,-0.04550331836074908,-49.3579507795977,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark13(-16.526573479138882,-0.9454047410820965,-59.74184092800411,1.0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark13(-16.537207405749726,-1.3510213857934976,-74.72260387698945,-88.68260982732299 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark13(-16.58238659996052,-0.7791126474275035,0.08258044424414572,0.0026177215554300526 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark13(-165.92729339626467,-0.022857326413106338,-164.6498718479094,1.0000000000001164 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark13(-16.634306540856315,-0.33387823113800863,-36.557997193266935,-0.06748564968136561 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark13(-16.650208035136316,-0.5942707460811749,-62.588990797858045,-61.991379065432106 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark13(-16.76077402421969,-0.13556595012434114,-74.46076042083439,31.932692862024055 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark13(-16.795870777171686,-0.47929255688871053,-2.83857196892064E-16,-1.0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark13(-16.94733850485016,-0.047269255942635265,-98.8012400804578,1.4287342391028437E-101 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark13(-1.6951925945043058,-0.17500853477566183,-89.99285841953268,-0.15024535485022517 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark13(-16.988788425881275,-0.1607359739035127,-33.334901919275936,-0.3326014837379505 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark13(-17.050840444140647,-1.432232718675206,0.0,-31.70150481413173 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark13(-1.7053449408535908,-0.6688902985126012,-0.0028911050028305463,0.5714574773900409 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark13(-17.11426419175198,-8.27266704516174E-15,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark13(-17.13885540023736,-1.3433416685228678,-99.20847851911519,-1.0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark13(-17.17741503983521,-1.5707963267948948,1.5707963267948957,-33.80784430271582 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark13(-17.29191716735295,-1.124402990603059,0.0,1.0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark13(-17.31037634422492,-1.5131901767391862,-100.6976777273012,1.0001759363939122 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark13(-1.7315896767335763,-1.2323210818527004,-53.78434037310709,0.01441771443489559 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark13(-1.7332950492998975,-0.1549375886983536,-163.61138314162497,-73.16850916363532 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark13(-17.410702008917877,-0.7162481232877898,0.0,56.64051935180435 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark13(-17.423270520800074,-1.5655416049243949,-28.813502441556313,-1.0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark13(-1.7428946521082627,-0.7776314683611306,-0.8872366018936023,26.97141461501434 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark13(-17.431106950144382,-0.8439793304938517,-15.623533909932465,0.9999999999999994 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark13(-17.441877670962928,-1.7763568394002505E-15,-85.89683296876879,0.6987544177995111 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark13(-17.47370370448567,-0.8522318003030294,-1.5707963267948966,-0.005900546253040938 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark13(-17.48111223048964,-1.5313267657618943,-1.0571605704679783,0.7868113865302413 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark13(-17.502607373268354,-1.4176861784536356,-31.7076617122095,-0.8215779135848 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark13(-17.6146528393122,-7.105427357601002E-15,-52.38882905831843,43.01880040681348 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark13(-177.97114688234512,-0.4664054686579925,0.0,-37.097757026041435 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark13(-178.41827428232295,-1.5707963267948963,-122.9891248889549,0.03229277350893071 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark13(-17.913997204308885,-1.442926151204421,-1.5707963267948966,-0.2916167036519077 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark13(-17.943081787681933,-1.195212087282096,0.0,1.0000000043108128 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark13(-1.8105576888679495,-0.0016093051845479157,-31.935324820982057,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark13(-18.118599386507647,-0.43146120643512376,0.0019364603059224027,-64.89962172923859 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark13(-18.139359990770195,-1.4535019462641354,-17.207346316290753,-1.0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark13(-1.822073006029397,-1.0872499334426349,-84.22448518329475,-1.0000000308236516 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark13(-18.349770403709247,-1.3829529604582285,-1.5707963267948966,-50.15675429363728 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark13(-18.358691355903797,-0.5744481462589321,1.261842415713381,37.10269692393777 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark13(-18.386205203135056,-0.2732433190122836,-17.266792220618193,1.0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark13(-18.479671456830445,-4.440892098500626E-16,0,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark13(-1.8562346807657661,-1.5707933541046892,0.0,-0.851965748880072 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark13(-18.60158290788163,-0.7910845468117831,-88.15248712002604,-0.037203845388592546 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark13(-186.4122675551419,-1.570796326794877,-8.256346934975547,2063.16424942807 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark13(-18.71397441739385,-1.5677761047494627,-68.26320566737319,-1.0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark13(-187.38956601941425,-0.14764127859127274,-39.24967585233258,1.0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark13(-18.844487695322663,-1.4900344740742304,-31.203292645567544,-24.005281036606036 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark13(-18.846449789628338,-1.1301829648973296,-34.48155957308006,0.7489021558626661 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark13(-188.65131128115132,-1.3583551201511987,-157.4780072469665,-0.03135518435106302 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark13(-18.877981192952873,-0.9416076399171684,-70.57959854537543,-1.0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark13(-18.950312416976843,-0.09072970329879648,-21.28935163127079,0.23278650076654328 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark13(-19.017157798754766,-1.5707963267948912,-37.00442177833559,-0.8931864054868703 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark13(-19.126148483496692,-1.5707963267948912,-130.7362625939189,-0.026414455447719254 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark13(-191.60080532021198,-0.4871468486352162,-77.556980980463,0.1310854938019519 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark13(-19.1811107525026,-0.8620682837773239,-5.490040985692488,-0.2788329842164803 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark13(-19.249489119329304,-1.5707963267948948,-1.5707963267948966,-4.016568487356871 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark13(-19.39472227115545,-0.04066991087021833,-70.10542465385008,-47.71768861785787 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark13(-19.40117310202737,-3.552713678800501E-15,-9.886076216463962,-0.6250532173166612 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark13(-19.5032816893501,-0.06287666702927946,-17.941952248976392,0.8620369793251496 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark13(-19.562281477666048,-1.4380967151761577,-53.84301136726984,0.0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark13(-19.56233257007917,-0.03724981616646407,-5.859378945537358,78.67254547147627 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark13(-19.590094500144538,-0.8652538212250391,-147.92057223455265,-0.05851303218689249 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark13(-19.639389616528213,-0.614640325680385,-73.52173716987004,1.000001712914539 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark13(-19.652191057348546,-1.3136614377446034,-53.63693506113485,0.9999999999999996 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark13(-19.6949464658905,-1.5707963267948948,0.140948314565855,-6.353588019511902 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark13(-19.698685594183072,-1.1205089644090989,-17.858987250597828,0.09406681108076143 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark13(-19.702929645782472,-0.0323319101647017,-37.3087571717545,-1.0000000000000002 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark13(-19.716145548321254,-1.5459187558961691,-88.18193165868536,-0.394311586242714 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark13(-19.745329921101035,-1.5706661422154407,1.08027707211645,0.21887685600441253 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark13(-19.78994262327602,-1.2390319458914516,-1.081160855455145,2067.5709686168484 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark13(-19.794033246016227,-0.12110550239408462,-1.5707963267948966,-0.4228794723109844 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark13(-19.802107423646238,-0.3402802890475204,-73.02498936116807,0.9999999999999916 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark13(-1.9874101641954547,-0.08607848725866751,-74.04812817955987,33.799575030066194 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark13(-19.909756205162395,-1.3830467989643442,0.0,-0.7936412238399052 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark13(-1.9967762314411175,-0.5466264105676297,-48.35884828766539,-39.18826729850673 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark13(-19.992858510316005,-0.8407714903940828,-44.24339578860401,59.777799551205376 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark13(-20.054372656559934,-1.183774999935084E-16,-87.05096738303864,0.0013693107496379753 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark13(-20.28948477568002,-1.3024311208284836,-37.197530525530254,1.0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark13(-20.429836482072645,-1.7763568394002505E-15,-0.38097637825713004,-0.071694079019053 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark13(-20.547409758270952,-0.1894699977783795,-80.7247780071034,-0.002494660471486806 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark13(-20.627694200370605,-1.4478301828427431,-1.1358446008012866,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark13(-20.70453309390183,-0.14603713175214628,-45.0106102420604,-1.0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark13(-20.730436992190377,-0.4892984271405243,-186.40696872150218,-63.240515210333385 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark13(-20.735478365144857,-1.5707963267948957,-14.550157149549847,-8.668335368225902 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark13(-20.788711438341466,-1.0140354872713857,-30.365362248344212,-0.6559569549754869 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark13(-20.789660529327403,-1.5707963267948961,-40.98034650965561,-0.06276923607145805 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark13(-20.8637889864939,-0.45428601090788123,-1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark13(-20.875213209096955,-1.4730378332089287,-83.39008071416256,-0.4793990931816585 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark13(-20.976842618947188,-1.5707963267948912,-23.154977262798823,-51.30069886298696 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark13(-20.977368104127116,-0.0061324592212516574,-9.900112439016981,-21.20452616125754 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark13(-21.040998381886855,-0.5519903685888732,-1.5707963267948966,-73.60818646552505 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark13(-21.047683404554864,-1.5323246921922846,-43.34570334365565,0.0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark13(-21.11506311802236,-0.514207501809137,-47.71197768629495,0.5566533891046737 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark13(-21.15753007962005,-0.2009387151329478,-1.5707963267948966,-1.0000000086607146 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark13(-21.201886754206626,-1.3679617120867424,-82.53532997460717,-1.0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark13(-21.246717423923457,-0.959155998302577,0.0,-100.0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark13(-21.351290163081934,-1.562071963625573,-57.944873148143806,0.9999999999999992 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark13(-2.1358823730727416,-0.2541890663227551,-1.5707963267948966,-66.43590738366439 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark13(-21.394442850949687,-0.040159840309266226,-18.195350606654095,-0.035907331256159324 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark13(-21.418901242517364,-0.4684677777472839,0.10447421091577225,-0.37759404005444697 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark13(-21.55250386610177,-0.10613695803002192,-14.432272868726656,-64.54157862808302 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark13(-21.639080548236045,-1.406193348016643,-1.5707963267948966,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark13(-21.64461440902572,-1.3055491641333363,-46.84267554165717,84.81218337830444 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark13(-2.180356624876879,-1.5521174898305334,-1.3136238376894058,0.9999999999999999 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark13(-21.846101489425024,-0.19043106656219885,-9.260554457798236,-79.7109563095156 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark13(-21.858613468738522,-0.18724485280434325,-82.46184351204356,-0.9676786066347608 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark13(-21.961812111363457,-1.7763568394002505E-15,48.09806011237313,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark13(-21.965510419544025,-0.76064009059343,-72.08747026481511,-0.20532374855657173 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark13(-2.2088105372931,-0.016433184656175867,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark13(-22.16200389156226,-0.038780682643214215,-73.87419022954867,1.0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark13(-22.164954007390556,-1.5707679069799818,-1.3521821986030838,-0.8819121449236771 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark13(-22.21982404772855,-0.6681547032638623,-34.190518355631234,1.0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark13(-22.308211177270337,-1.2361031832407985,-39.27122205801218,1.0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark13(-22.38319848394811,-0.754981698162065,0.3903553579615675,-12.24272258087089 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark13(-2.2411519082260707,-0.16776533034748653,-4.587975781621785,6.497131103528062E-114 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark13(-22.48202523131178,-1.3398692128062595,-101.03962290065948,18.779196193819317 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark13(-22.489991523187538,-0.8224665638468345,-80.55472981358496,-0.009572234649228961 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark13(-22.50054133040788,-0.1186928629997664,-30.339639107576005,1.0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark13(-22.551976850593302,-0.7475925702271244,-10.450121679421116,1.0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark13(-22.662026377677094,-0.887181678431967,-37.72189970349014,15.777227997283944 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark13(-22.688170704541108,-0.03315895838479817,-30.020301823834885,1.0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark13(-22.71158169847631,-1.251672611568158,-2.6092999051500385,50.73512874634568 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark13(-2.2808216728509336,-0.034862853697568676,0.0,51.361544978520676 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark13(-22.90282126481684,-1.3438567850845542,-70.13741278132986,-0.7889500665074607 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark13(-22.922159140726038,-1.0759217630863036,-1.5707963267949125,2084.1217186446465 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark13(-22.948218361429788,-2.5459072336718675E-4,-10.946896988428964,0.6475187290066665 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark13(-22.957544950310943,-0.46047999682660645,-1.5707963267948966,0.6680694881375167 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark13(-22.964382268864583,-1.570796326794877,-53.08772889643413,-0.6856825860427425 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark13(-23.023693919800937,-0.019382708148039537,-44.48631582089203,0.754527035934144 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark13(-23.111525194750016,-0.6144294038537481,-39.04080262517328,0.20765979645327107 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark13(-23.154449273023364,-0.0765210584452198,-59.94822910365388,6.938893903907228E-18 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark13(-23.162673452931216,-0.6222160316688385,-1.5707963267948983,85.9449143029075 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark13(-23.17598002328224,-0.4278426103016386,-41.54498270451086,-1.0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark13(-23.190906296815726,-1.3815934590125194,-87.11293002475378,-15.82459858144422 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark13(-23.225956989387655,-0.383590612146115,0.0,20.977341402556277 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark13(-2.3227246892995197,-1.243638690849238,-89.56677570247167,1.0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark13(-23.258552225074773,-1.5707952627443114,-1.5707963267948966,-0.9941290049831136 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark13(-23.317828259563697,-0.2068776557341243,0.0,2135.115574739011 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark13(-23.44067826310041,-0.039520768730502476,-0.38959807590299816,0.6921748689916596 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark13(-23.457380379186148,-0.008900427092759039,-88.50043845666747,1.0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark13(-2.366792805202122,-0.4677584935037689,-87.02164724828523,0.06342555390482411 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark13(-23.681780837729754,-0.05421255113421528,0.0,0.9999999999999996 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark13(-23.72058605156076,-1.477065690452523,-81.81098771474716,94.67631880728999 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark13(-2.379015202143492,-0.3470664067786555,-18.020352053300982,-0.8893919895482532 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark13(-2.3793013218466115,-0.13642947095005503,-27.869211199444408,25.89981901153405 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark13(-23.81721090201009,-0.8305679015498599,-100.0,-1.0000005560232401 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark13(-23.85304998604118,-0.1468188037359801,-27.447982775511548,0.6322699081486531 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark13(-23.86200512034557,-1.0673433402652692,-7.0593072677982045,-21.22787875543087 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark13(-23.878198291565198,-1.3493673772069883,0.0,-100.0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark13(-23.8785293946168,-1.0306315187570547,-73.73694096246597,1.0111576222076195 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark13(-23.90506634217129,-0.1320384711425131,-0.441873295151779,-0.021580832113161155 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark13(-2.395732895070997,-1.2737383514434768,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark13(-24.033567861937996,-2.990509044967145E-4,-1.5707963267948966,0.7668939968060919 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark13(-24.073264918913274,-3.552713678800501E-15,-94.22961388051077,-57.145915338441846 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark13(-24.12079968225344,-0.8374708073154412,0.0,-0.47933306248761964 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark13(-24.13184288281233,-1.1628047872860228,-56.363357719491745,-1.0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark13(-24.17484848899708,-1.497090667185285,-64.9206586023487,-0.9705477480819119 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark13(-24.200683373297032,-1.5449409320396519,-48.957876221824115,-0.06265690088655522 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark13(-24.408909935757038,-0.34728052785653807,-11.229377348299167,-74.83950466506964 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark13(-24.429521832872254,-0.06126918487959132,-45.7139080692875,-70.29652237585466 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark13(-2.4434074189784667,-1.4732896692380855,-61.956633825669606,1.0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark13(-24.48189190281869,-1.1427153139190034,-17.84462553530888,1.0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark13(-24.629664898038286,-1.1802356634419915,-38.88103198429677,-20.40017228869963 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark13(-24.640409448602572,-0.5270863932464063,0.0,-0.7714388687445934 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark13(-24.645759762726932,-1.1600141322371833,-52.47721799727019,0.10886506574476018 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark13(-24.710688807159208,-0.061781191173346336,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark13(-24.734847565928405,-1.5458974788206976,0.0,-1.0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark13(-24.767004408346757,-0.03711304341847715,-8.450763970143598,0.04390638953678838 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark13(-24.784809000743437,-0.24706143152720994,0.05994129651251374,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark13(-24.97212448146116,-0.19954706467382133,1.5707963267948952,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark13(-25.005810025364056,-0.7374481428216318,-71.1760174813735,-0.04373108628480815 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark13(-25.00583646375382,-1.0563149652458323,-77.22006685860109,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark13(-25.048523070222306,-0.2564481994614478,-25.12394408583025,5.736417416305571 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark13(-25.134595803205343,-0.936046778389088,-45.3876630238585,2224.921980153442 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark13(-25.17821924807464,-1.4745781535230995,-0.5252158898222063,1.0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark13(-25.18130020232406,-0.1331670466443832,-86.6338613523213,0.15524934618117184 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark13(-25.187707417178128,-1.7763568394002505E-15,-100.0,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark13(-25.19514038938696,-0.41804229264097237,-3.385029753279775,99.63870621714416 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark13(-25.26352854169935,-0.04334407559240194,-54.32122264002977,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark13(-25.37623715272268,-1.5476986168686335,-3.843532869050396,0.0626620762438617 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark13(-25.54595843551326,-2.988022153414252E-15,-1.5707963267948966,0.6871293613455234 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark13(-25.616526198043317,-0.41922841278916234,-88.49560005714183,-49.55831061616733 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark13(-25.64034186262677,-0.8640075589576789,0.0,-46.9610834995976 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark13(-25.65646156274009,-0.265608297333168,-8.664673814750643,4.117051958956736 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark13(-25.70104651908354,-0.36332327339458825,-63.62156554953739,-34.68210501493458 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark13(-25.776047635897143,-0.39292170053359043,-44.769515976419804,1.0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark13(-25.781457990115307,-0.16869179693629616,-63.992354675155404,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark13(-25.841246183075253,-0.9751801143683105,0.0,-1.000000110722811 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark13(-25.857129203356717,-1.1501734022770194,1.363443014544738,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark13(-25.878852551994896,-1.5657896223231629,-0.4105077945762235,-1.0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark13(-26.09770143379177,-0.5977992867213656,-1.2499326455629252,-63.73175848806425 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark13(-26.227044517966114,-1.5707963267948948,0,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark13(-26.23273566495297,-0.26444037771459317,-1.5707963267948966,0.565926579628526 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark13(-26.300745576848623,-1.0406092236161022,0.29516840080866946,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark13(-26.305896887109036,-0.0585520616232742,-53.65883474248317,110.0054130177505 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark13(-26.339579807359144,-0.9494101932912788,0.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark13(-26.415852020801065,-1.5707963267948963,0.923440667080376,-0.7841207308414966 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark13(-26.465397712741726,-1.4095730391160606,0.1310729867767919,-1.0000013781635875 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark13(-26.479771850123967,-0.19714354317728677,0.34032990027335985,39.48515050555562 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark13(26.54201237087821,-0.964301365863836,0,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark13(-26.58391836671966,-0.13392784439706773,0.0,-1.0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark13(-26.622335993659284,-0.02170660077222746,-27.95503176049462,0.05030131397940024 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark13(-26.623900005665966,-1.506948588996925,-98.31645577050868,-4.011637823494194 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark13(-26.630530149006404,-0.004969285735531459,-84.63331795745516,-0.6583197975680568 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark13(-26.630688898802422,-1.5654616682102547,-21.33074659178964,-0.0276625712678137 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark13(-26.66505880552604,-4.440892098500626E-16,-49.72771841573215,-1.0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark13(-26.673449067998313,-0.2505671518312533,-93.35494343142118,-1.0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark13(-26.695899733879685,-1.132240267094346,-101.99980860123135,1.000002759468269 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark13(-26.746262184246763,-0.020359866083300426,-6.453058184915065,0.09257226333239965 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark13(-26.812852930544878,-0.022546991200670087,-9.463631835232729,0.01710373983276611 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark13(-26.852848552258333,-0.77394290817917,-94.30222393898117,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark13(-2.6872821764962205,-1.5290966739993173,-0.551788428135053,-0.04898959230657697 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark13(-26.978747967575867,-0.9313828220267858,-34.58222599575002,1.0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark13(-27.044916881248035,-0.21065484238404597,-1.4134240018982611,-0.3784358581644849 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark13(-27.055891862193526,-0.15051574085784525,1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark13(-27.057979937764188,-1.0543531196649558,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark13(-27.091230423794492,-1.5638565781548168,0,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark13(-27.149543284154333,-0.10133424468524765,-1.3990208250534408,-1.0597202619990382 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark13(-27.19073584993108,-1.2432115549540645,-78.33085115862069,74.45618581017064 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark13(-2.7273369822017037,-1.2355118939267982,0.0,57.22030429060312 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark13(-2.737445003411991,-0.6722045457200683,-76.49830369036854,1.0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark13(-27.389254677955922,-0.3071782999486876,-32.56004867666322,-40.233995763662485 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark13(-27.390191352763612,-1.5122118722858247,0.0,1.4073157539545913 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark13(-27.41328410678939,-0.08915987026563697,1.130721009371114,-0.7373845303665754 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark13(-27.415409485729946,-1.235710123853151,-36.7593889793055,1.0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark13(-27.500988013578702,-0.23472078240438066,-16.420754478469092,-0.044364849784727774 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark13(-27.56573849732615,-1.0472029841452095,-31.58668821543135,1.0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark13(-27.5793171602963,-2.220446049250313E-16,-53.49332701588989,-1.0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark13(-27.581450665731857,-0.7832919213666409,-91.65271737439281,-79.2599470177927 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark13(-2.764275136601804,-1.5647919680655176,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark13(-27.669840790530515,-0.037979408889207665,-26.89245104969345,-100.0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark13(-27.722417939260765,-1.254551243909308,-1.2131502215501613,-2210.8590776971455 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark13(-2.7823512150770777,-0.009606085116218646,-15.47024062439836,0.011251216199817808 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark13(-27.824071540393795,-0.7257077060269165,-74.55942712443131,0.2955672394035811 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark13(-27.867871770650268,-1.5150349330518231,-53.85461587550837,83.30070974336918 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark13(-27.886569102498115,-1.5707963267948948,-31.217412123110705,-1.0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark13(-27.903627722043076,-1.5707963267948957,-64.89351392845373,2.0506162091249376 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark13(-27.922621440685468,-0.10673005579538915,-1.5707963267948966,-0.8300902120628885 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark13(-27.928547667324867,-0.008564453732632706,-1.7763568394002505E-15,36.574300584313434 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark13(-28.109420315756612,-1.5320408294511432,1.3877787807814457E-17,-1.0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark13(-28.218609560424063,-2.220446049250313E-16,-1.5707963267948966,0.9935674682243422 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark13(-28.310320393719138,-0.12608227763781962,-9.649363006286762,1.232595164407831E-32 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark13(-28.43900990624671,-1.5707963267948895,-83.8478279255549,33.3914198115413 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark13(-28.477934139186942,-2.2791976881489846E-17,-4.5221553631328995,5.902578475433795E-4 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark13(-28.651467551537902,-0.8278438509248833,-46.84159574633565,0.9223045144213582 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark13(-28.7428871198873,-1.5026046528355834,-32.73842616392267,0.8757903783475012 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark13(-28.755617208073453,-0.20870840731065177,-100.0,0.15624663990851156 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark13(-28.819560425006998,-0.2770820022798528,-0.9503785630723027,-1.0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark13(-28.8869175320349,-0.10663789609238372,-46.23212086692874,13.32047777094905 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark13(-28.96506042006264,-1.3974918181490235,-96.94486456687318,0.06260545326597058 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark13(-28.985536506998606,-0.2657020491167242,-16.031828635204516,46.38338666427993 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark13(-29.144605364198686,-1.5707963267948957,-49.51090014330888,-2132.5729196605553 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark13(-29.173195728711992,-0.7644650943073241,-49.90348329688682,1.0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark13(-29.191365781033827,-0.14141678194250062,-4.730157617445426,-1.0001039904759395 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark13(-29.278290018074163,-1.5707963267948963,-49.21792970903459,-1.0000002646613675 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark13(-29.2895156812165,-0.7615551831550178,1.054667390889768,-0.7136869080976336 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark13(-29.307896255329567,-1.0782951823058493,-5.833908992003909,70.70455585380333 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark13(-29.324238931979593,-1.1065782005441214,-73.41446946761411,1.0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark13(-29.369306720271652,-0.5200024704701561,-15.071715063138996,-55.409702679314485 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark13(-2.9379543603216547,-0.2726756362983258,-1.574271816415691,0.0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark13(-29.42796110551323,-1.5703457558088356,-1.5707963267948966,21.568513279512146 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark13(-29.475567604894124,-1.5008596769098967,-1.5707963267948966,-0.5463155917021362 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark13(-29.52866541727128,-1.326850195185961,-66.30995372942425,0.509259150569819 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark13(-2.9601786783508146,-1.1409192781952981,-86.39886455171941,-10.852693479661795 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark13(-29.64389587850689,-0.003474758739131416,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark13(-29.657693912090096,-0.056658368554546874,-1.5707963267948966,-62.58343111865388 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark13(-29.81966804507482,-0.4972369105981021,-1.0994902780288163,0.9256083299385347 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark13(-29.90227973396617,-2.405177028116486E-15,0.6406057512746044,-67.95793290841694 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark13(-30.045843462451522,-1.4157780615539224,0.0,-0.9297807044389814 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark13(-30.07075676759334,-0.7847444310011352,-24.164486424787214,0.9999999999999999 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark13(-30.096224497619133,-0.2663887466162076,-0.7855943585640014,0.9999840892872887 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark13(-30.14734839677187,-0.007622089217094896,-4.981798229166799,-0.9999999999999964 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark13(-30.152341341701014,-0.01412708664340373,-34.29555738945349,7.513749744913756E-4 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark13(-30.32030420885852,-0.872627045686703,-1.5707963267948966,0.010928082111000404 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark13(-30.464292341042132,-0.6373508061903793,-1.293223196208842,-1.0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark13(-30.492312067055085,-1.2218681773464266,-0.08782156360257369,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark13(-30.504300132367263,-1.1585296417384188,0.0,-1.0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark13(-30.511791134648675,-0.26657671628768,-28.834720248772946,50.407859373906234 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark13(-30.529436000651103,-1.5707963267948963,-36.99819533754297,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark13(-30.552068285014094,-0.15594187123921913,-31.710441788250357,-53.329232429694315 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark13(-30.582464007061713,-1.0131907435236245,-14.439688353454727,1.0495776420302236 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark13(-30.59835587886788,-1.5552396905510684,-1.5707963267948983,-0.03649345929669556 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark13(-30.631726331486988,-0.02010128014676467,-0.5065463248497961,-1.0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark13(-30.64461119699291,-1.1083803082119146,-88.75984888464548,0.9999999999999996 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark13(-30.71276262253014,-1.2694835524023766,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark13(-3.073509088075866,-1.152729410666275,-73.27204360915803,-12.601979332276997 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark13(-3.087625961539965,-0.7439479667871729,0.7079924483752533,0.006914771811682777 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark13(-30.881588983470266,-0.27181962514056734,-0.35914617713017427,-0.36253172891021396 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark13(-30.93959955116852,-1.0446866657954312,-101.74067537527867,1.0942789468507073 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark13(-30.943333977843242,-1.1966665296190797,0.0,-1.1816464292978313 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark13(-30.99289104961021,-0.8614339877183338,-10.274242908022927,-0.9683275528359019 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark13(-31.020064923253468,-0.6712097931450431,-100.0,9.363352709384397E-97 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark13(-31.185074570096525,-0.5702972585913457,-45.052009730253644,-1.0241101585323564 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark13(-31.276676042190676,-0.03449915016246501,0.164747818610683,0.4977456232033057 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark13(-31.318008267494733,-1.0032047605995547,-11.97713442503337,0.047940020083941104 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark13(-31.352765842676682,-1.0317787616805212,0.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark13(-31.35823151065383,-1.530211149794386,-37.87674651192293,-0.36209439705543217 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark13(-31.480683058174336,-0.07371384644239576,-77.73344703700872,-1.0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark13(-3.1485434179288916,-0.3949493789546028,-1.5707963267948966,-39.963334883900835 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark13(-31.534484559142754,-1.4790094344495317,-37.76659055507656,1.0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark13(-31.577878904763566,-0.10826931609688195,-67.45091935004355,1.0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark13(-31.631598889922245,-8.881784197001252E-16,-11.434826840826615,0.3620948781856793 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark13(-31.641962614916245,-1.5387988355062678,0.0,43.07679744818221 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark13(-31.648757444773725,-1.023630243778066,-22.50369094373978,-1.0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark13(-31.779957660455274,-2.5281270722638494E-16,-54.00647968980425,-0.05284521796326061 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark13(-31.81155143284235,-1.0422438333546435,-0.8161732162456337,-1.0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark13(-3.1811734535468474,-1.570796326794877,-85.82144771776534,46.18063597482441 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark13(-31.841004795905363,-1.3985941742113304,-95.77274129094968,-93.91247421522621 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark13(-31.949068638438458,-1.065571570859916,-34.27788774577595,-0.8975477703937047 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark13(-31.953269288367537,-0.034237425465210705,1.281009115080933E-16,-0.14831872271357824 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark13(-32.04811641979816,-1.2920889748294493,-99.51994143412377,3.515684790568763E-5 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark13(-32.14356548641904,-0.4061749187243988,0.4291321861265627,-1.0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark13(-32.21665447367603,-0.8611207955945377,0.5713668007370868,-17.19809688365747 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark13(-32.29612318365362,-0.8175070564614408,-64.98483000496836,0.9999999999999858 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark13(-32.300226868557964,-0.6624585818880079,-1.5707963267948966,-0.011149902215317642 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark13(-32.444314945711625,-1.5260578390863513,-1.5707963267948966,-1.0000000000000009 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark13(-32.47846983630144,-3.469446951953614E-18,-65.3403584733471,34.54904372819357 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark13(-3.252675991319194,-0.5702007714452125,-37.81635744065771,0.010211062185484324 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark13(-32.63556093713799,-0.9093854722804307,-90.14255902620603,0.019965291027375043 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark13(-32.660584199219244,-0.04893989142496391,-77.92587438977182,5.122967696091152 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark13(-32.698980378180735,-1.5136095049403029,-14.766755243202471,1.0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark13(-32.701987261963865,-1.365720747173277,1.3612065976953236,-98.38201277012195 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark13(-32.72904877020713,-0.7571673171147032,-61.991108665676784,-1.0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark13(-32.791938648276364,-1.5553017503334639,0.0,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark13(-32.93184515826531,-1.5697960467071304,0.0,-0.9999999999999829 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark13(-32.935308361996526,-1.1506505186133402,-1.5707963267948966,74.89725124075365 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark13(-33.04633210578874,-0.8124754695113648,-1.426258981218039,-0.49803889550276326 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark13(-33.07236024456479,-0.845460582628978,-84.30120358401231,1.0000024409070014 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark13(-33.10032187304408,-5.010163986827486E-4,-73.52645260745649,-0.24418688629841567 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark13(-33.117085106071116,-0.6484723603163409,0.0,-2.205627008594016E-15 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark13(-33.142395582197416,-1.3740930011152255,-66.83304180684752,2.722061061896536 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark13(-33.24173355075748,-0.7027731324372029,0.0,-1.0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark13(-33.25331928635116,-1.4217436306582696,-18.208901337615323,1.0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark13(-33.26497573881169,-0.811790001709483,0.0,2.002083095183101E-146 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark13(-33.281661684373965,-1.5707963178140756,0.0,-1.0000000806875329 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark13(-33.285225856802356,-1.5707963267948912,-65.37446891579961,0.5233603081600469 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark13(-33.39410726603865,-1.4197468385387992,-3.919540099315451,100.0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark13(-33.413358337835845,-0.06747374470909162,0.0,-2051.231120950635 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark13(-33.42059223165611,-1.128840063690646,-69.62862250351176,-0.9814097432569178 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark13(-3.3451358098716617,-1.5707963267948912,-1.5707963267948961,1.0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark13(-33.555652509552864,-1.1270913254789938,-55.07210631323961,1.0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark13(-33.56750911110596,-1.2022441952678176,-46.81871557033722,80.8673842197368 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark13(-33.56782003486548,-0.8843225406122032,-11.53157184594315,-0.5862617596346875 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark13(-33.6232491028326,-0.0013943239750095898,1.5707963267948948,0.01466205050390021 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark13(-3.3658241400198907,-0.21590075126663366,-139.97624455805942,0.9999971999893007 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark13(-33.72376997546213,-0.35286861634205186,-10.927597955423089,51.503163757226375 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark13(33.886209778717586,-63.024129720037394,30.419836872413327,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark13(-33.88942913691606,-0.9215714932232182,-1.999205460011181,3.552713678800501E-15 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark13(-33.98839573490241,-1.162286068417454,-1.5707963267948968,-1.0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark13(-34.067772841970154,-1.5657644001570112,-64.57497566020648,0.44669935115626247 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark13(-3.4071021457001884,-0.1257534410861078,2.220446049250313E-16,34.877335420036076 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark13(-34.08576142215899,-1.5707963267948963,-1.5707963267948966,-47.89279203259901 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark13(-3.4206655662174796,-0.05418892084877891,-26.7902869632287,-0.8874602903271529 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark13(-34.30462615251406,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark13(-34.33008110187088,-1.056873097478416,-1.5707963267948968,0.05729740137434962 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark13(-34.334907527956034,-0.8373918046218272,-75.04857934681503,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark13(-34.34935894775791,-1.0340915504104373,0.0,11.194073531154075 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark13(-34.375577638475775,-1.101158941461359,-0.09800452402706039,-0.9165535034541277 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark13(-34.39635469466811,-3.552713678800501E-15,-100.0,1.0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark13(-3.444574131765904,-1.0954960106391005,-97.81924974530104,-76.12075371245739 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark13(-34.50368899439245,-1.5385833129039916,-59.2645236894892,-0.04284557810490011 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark13(-34.627555746237235,-1.542473643366288,-28.17577984316004,1.0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark13(-34.857650772160895,1.734723475976807E-18,0,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark13(-34.87650621751486,-0.31476754862978384,-29.46464802570446,-1.0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark13(-34.89893119215877,-0.8818914655952443,-30.240675317719543,1.0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark13(-34.91810280968454,-0.5483165889495212,-10.665329776785336,72.77018637941416 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark13(-34.92118086516922,-0.03769347265749714,0.0,-0.9995551278251744 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark13(-34.929163341835945,-1.3656255447295607,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark13(-3.4990080159570094,-1.4046649331907908,0.0,0.951500773638076 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark13(-3.5059451282748606,-0.12172243173141517,-58.55435860740512,1.0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark13(-3.515704630697123,-0.14352436580853473,-0.520354504440723,1.0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark13(-35.1833972990111,-0.7776469907351037,0.10136658843364754,0.9881188952236647 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark13(-35.27643019098805,-0.7021506113429633,0.38940953393576555,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark13(-35.28439095831368,-1.459313023953258,-1.3432100257861144,0.019717582080714946 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark13(-35.295667997902584,-0.8670321964731564,-12.95915060239767,57.904466627358886 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark13(-35.402729035665104,-0.009075615015208186,-72.5459739270411,-0.014187120396318212 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark13(-35.45620535243819,-1.254602027805339,-64.95285934740699,-1.0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark13(-35.4658339946787,-1.374362562779237,1.0591726883448804,0.9539036274074622 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark13(-35.46753821326101,-0.9925021572017368,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark13(-3.5500830507007657,-1.0480802223727193,1.5576232922031146,-0.48681930325311384 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark13(-35.50835975645042,-0.5490493004826962,-15.043142560955609,0.9999999999999987 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark13(-35.59225564598993,-1.664623490333627E-16,-62.1795586837371,-52.04951633930021 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark13(-35.729009249800285,-0.7731874254053102,-84.74497902240988,67.80586988876135 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark13(-35.80003552248966,-0.6182385435359615,-4.680163131550117,0.46478528446741074 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark13(-35.81070590143507,-1.1007228547055574,-85.32971394067886,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark13(-35.838453793645286,-0.4855210677547961,-86.44034335424406,3.469446951953614E-18 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark13(-35.849981212490206,-1.5615469086791267,-31.97134761526215,-0.9744539327610078 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark13(-35.884459960246204,-1.4012302111921104,-99.71824652157672,0.65915806893782 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark13(-35.922072438208914,-0.7763810305390357,-19.150568358838502,0.03656753679119443 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark13(-35.930472729244826,-1.5020377247675523,-2.1336360833198427,2243.313885531445 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark13(-35.93881082034147,-0.05295155341561872,-72.79833932638977,-0.0307426969094938 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark13(-35.95372009900921,-0.8979503576754553,-27.591740484477306,-0.7868251461692379 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark13(-3.596896199976655,-1.5143325665708043,-1.0687479986761157,35.592104999099746 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark13(-35.984092381237076,-0.44158552981916444,-87.11146907926208,96.03199734721659 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark13(-36.00631441626976,-0.12114896609966108,-4.434233496468025,1.0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark13(-36.01159019043768,-1.0382206905330087,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark13(-36.06151796269088,-0.31390132930615433,1.2304540640425625,-0.04437265492260331 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark13(-36.11659806686072,-1.3257907878683783,-6.701413939395124,-0.9731225397744081 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark13(-36.122753332179016,-0.3615687899190167,-18.305770904734516,-2132.0628280607048 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark13(-36.151937505556695,-1.0248126284933157,-13.326950815583762,-1.0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark13(-36.32325591382345,-0.2758690543695207,-1.133004464680622,-1.0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark13(-36.323606796850925,-1.4662304003650315,-1.5707963267949054,-1.0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark13(-36.32640311390759,-0.3965729450431219,0.0,0.8412059957179849 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark13(-36.411747926569504,-1.5707963267948912,-42.23694291075353,-0.4631345746808968 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark13(-36.41587940173139,-0.6417099683725316,0.0,0.029198330449556262 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark13(-3.641762010926245,-0.8979255447991775,-61.675646807022815,21.972204360472332 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark13(-36.42712505077803,-0.9066317512815077,-38.879748281994026,-46.344585713169316 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark13(-36.56215825430198,-0.0034785975800087914,-63.6027097354803,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark13(-36.6643319680655,-1.5707963267948948,0,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark13(-36.71416939538736,-1.1755519985719052,-39.168700652943855,-8.805254571710335E-134 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark13(-36.9425557485657,-1.27008801192394E-15,-20.61172054356433,-44.458992808423716 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark13(-37.00817239475298,-1.3293299810507664,-24.29041437897105,0.06328025831357964 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark13(-37.08821105998418,-1.369859518949819,-1.516434320861364,1.0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark13(-37.11102309274586,-1.1634632054651728,-0.7097828018107126,61.3380563584639 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark13(-37.1214614657718,-1.4455085547810564,0,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark13(-37.134680150426135,-1.5707963260899636,0,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark13(-3.715369116938409,-1.3420522112257557E-15,-1.5707963267948966,-0.04809975204690031 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark13(-37.167139010175006,-0.4777225465999706,-87.20177399646597,-52.397667612975596 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark13(-37.29213390443299,-0.17291040790205273,-83.91829981016805,0.9615997091561692 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark13(-3.7314586163360417,-0.06939112693071513,-72.12320023870839,-1.0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark13(-3.744908468032823,-1.1862871629131337,-1.5707963267948966,-0.011783511864018466 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark13(-37.46883621362716,-1.2320093600131834,-34.86309432704191,0.9999999999999929 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark13(-37.49589549578785,-0.658277840664818,0.0,-71.78913133297819 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark13(-37.49683914181527,-61.54318162270278,-43.0277612014349,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark13(-37.512220297272734,-0.8307294283905023,-0.3586098718799913,-0.6663598627567717 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark13(-37.67246818194593,-0.4165180781043588,-22.860654110874435,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark13(-37.68103040484581,-1.5181803504643094,-45.12000165462828,0.0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark13(-37.811461122760456,-8.881784197001252E-16,-17.48932170785595,0.011698007748224411 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark13(-37.813784815881135,-0.3966428332085087,-1.5707963267948966,-3.2944368572595385E-83 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark13(-37.820815211471555,-1.0414587420294816,-72.03038065662935,-34.5905268067265 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark13(-37.87633311479837,-0.03745484145013203,-66.22237223961332,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark13(-37.91542888737757,-1.4060618250084695,0.8752411533463791,-1.0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark13(-37.99741096833504,-1.5707963267948912,-89.10921664846339,-1.0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark13(-38.198550950499744,-0.21726511469335585,-1.5707963267948948,0.44148471110619514 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark13(-38.21491206778716,-1.4049545709858267,-32.743873024869394,3.469446951953614E-18 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark13(-38.35681985493592,-1.3362172403910606,-49.2337597594211,-5.322388846343848 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark13(-38.46353232081788,-0.6430742393238563,0.35082234226577486,0.029724486664330328 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark13(-38.4833395466693,-0.940293257220047,-59.83692777581674,-52.4607521130462 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark13(-38.53567780906115,-0.6286153673671572,-24.98188393071804,-1.0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark13(-38.55993075059412,-0.7179668706383663,-30.10516497649718,-18.294093638850196 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark13(-38.56237900591007,-1.436525884116506,0.0,1.232595164407831E-32 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark13(-38.564488310696476,-1.232595164407831E-32,0.0,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark13(-38.572513172943616,-1.3698344074621929,-0.9309448497127771,1.0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark13(-38.57336665305631,-1.524191022789826,-32.49915700077476,0.9884094743787564 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark13(-38.60019071577553,-0.34114961565112945,-18.637706140444564,13.50133549684953 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark13(-38.650587994074094,-0.17800042090472656,-62.65140479958004,-1.0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark13(-38.67539746530277,-0.2665707842779754,-44.32704770920265,0.06255252622533257 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark13(-38.68038563367637,-0.2490258619179695,-66.09656393738302,0.9896332545495738 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark13(-3.8796996313958636,-1.387854179592531,-73.90453023484217,-1.0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark13(-38.82093475067675,-1.5707963267948912,-63.137884608451834,-0.793894752043937 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark13(-38.84366213636624,-0.017530057594674887,-22.102257434816707,-1.0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark13(-38.846526331365226,-1.0804921919299955,-1.5707963267948966,-0.23186065873376904 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark13(-38.85586118873337,-1.3977256634791362E-31,-0.17542504402162049,-1.0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark13(-3.899584287385884,-0.8992632687658645,-39.170200834348215,1339.6873285725976 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark13(-39.045437880249025,-5.551115123125783E-17,-77.2829784009477,0.0625980871009615 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark13(-39.1111220077707,-0.5349288482935091,-158.57889355878316,-0.998586697189705 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark13(-39.12314961134016,-1.5707963267948961,0,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark13(-39.148375532171414,-1.570796326794737,-4.2590854533867395,0.0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark13(-39.15600207527613,-0.03423239466960653,-33.88877387873357,1.224456016217597 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark13(-3.91613584749165,-0.1687858543205656,-137.38239911225583,0.4867385487770193 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark13(-39.161948574448495,-1.4385709318487827,0.0,87.36819646619685 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark13(-39.19876934242375,-0.1927070276656111,1.0624755159020678,-1.0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark13(-39.22891696195717,-1.5547501812131939,-12.408200893211884,-88.14322180911668 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark13(-3.927226787411284,-0.2899060297075017,-11.142358543131536,-1.0000000000000184 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark13(-39.309106536111564,-1.4860817378976119,-1.5707963267948966,0.9999999999999996 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark13(-39.31137795490913,-0.6158391325769039,-0.10519954374421892,0.04898300914720721 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark13(-39.39026926307227,-0.9122514781887497,-31.24581442968355,91.3070366238224 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark13(-39.51015721142292,-0.5662514426463479,-15.181537969429755,-0.6710065429965701 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark13(-39.59290769594244,-0.840974252128782,-40.0941334174953,-1.0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark13(-39.62001656813416,-1.5707963267948948,-58.564769558129136,-0.2947410287188432 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark13(-3.9631757242904513,-1.5707963267948961,-5.084132269214659,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark13(-39.641884481484155,-0.036050079515743794,-52.24662294897672,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark13(-39.674716183809736,-0.5212676619632504,-82.60753859071959,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark13(-39.709937122934555,-0.3613713960498046,0.0,-83.47842285725915 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark13(-3.971691236713506,-0.06013863862931251,-100.0,-0.6983286595972183 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark13(-39.736466019925956,-1.2062196647022287,-67.03064750448645,1.0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark13(-3.976324035254948,-0.5816978607687111,-89.13660817057972,-0.1021303140070442 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark13(-39.872590891523984,-1.5707963267948963,-33.31801294170815,6.38662642089294 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark13(-39.89549860354912,-1.0916270876454872,0.1438276335953779,-1.0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark13(-39.96992469698041,-8.707488505251736E-5,0.0,0.99999572539566 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark13(-40.04803701872734,-1.4948611803542655,-0.8908308980789449,-1.0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark13(-40.0484846554681,-1.4582630787734985,-81.12654187543762,0.22261417302263187 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark13(-40.079953865725976,-0.0822301240837442,-62.579805598299316,-0.29098612000652047 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark13(-40.13508546745345,-1.2394749929141682,-1.5707963267948983,-52.32611406467065 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark13(-40.13705656795706,-0.8099752185075206,-67.21122666913644,1.0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark13(-40.15621590110016,-0.8227809796363708,-22.815501275596326,-0.9286717712149225 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark13(-40.28422319936905,-1.330285213741432,-90.9361350555956,0.9411942645514517 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark13(-40.38310470257444,-8.881784197001252E-16,-89.76974055003525,-31.56275300495915 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark13(-40.39927000560333,-1.2630589318428636,-53.441344474104916,0.9286893424978331 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark13(-40.47484123292251,-0.4892068880360855,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark13(-40.52744589126666,-0.21941389754671514,-24.129736001508522,-1.0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark13(-40.52800376928021,-0.03903727814773624,-1.3877787807814457E-17,-1.0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark13(-40.602921743326846,-2.0798082870306849E-4,-1.5707963267948966,0.02776110615660715 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark13(-40.64717067764468,-0.5059732504404704,-5.615772605587438,-0.9415743398745444 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark13(-40.70453076965334,-0.5405245125093927,-24.25888349094409,0.02043916560191035 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark13(-40.74738813370982,-1.0038014540660691,-95.08059997340379,0.6375484808721738 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark13(-40.81394026596535,-0.24717510155319522,0.0,1.0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark13(-40.8439786722433,-0.5328048450124768,0.04821558118338143,96.76332126263154 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark13(-40.872203320380635,-1.555475603923616,-53.86647221502475,1.0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark13(-40.923475576429176,-1.5707905366250436,-31.607903114832954,-0.46185944402910306 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark13(-4.093699999227283,-1.0858536854281873,-91.89433330432715,-1705.1599217592982 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark13(-40.96884817869478,-0.5429626740251559,-34.76768803600736,2150.645805300788 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark13(-41.00687211998895,-0.7012862821610886,-10.486394409248675,-24.3141769201999 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark13(-41.04459481083511,-0.49597257521604116,-1.5707963267948966,41.5976487981984 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark13(-41.058713849736726,-0.6147263584202551,-88.23885879488621,-1.0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark13(-41.065002818854104,-0.19887338081260902,-18.838858574274052,47.8981401388811 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark13(-41.075330111448835,-1.2046782307226067,-24.48982323607808,2245.906933534208 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark13(-41.10995408071327,-0.6222795344589258,-26.513749073768807,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark13(-41.13094118700153,-1.5707963267948961,-88.16705749700168,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark13(-41.225637908290786,-1.3188276316684022,-84.43534370313168,-0.05369088966222263 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark13(-41.24329660715289,-1.2851405579003363,-1.5707963267948966,-0.06255344255499928 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark13(-41.24706256785296,-0.6846546789255148,-73.45071222300678,0.3766582142602415 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark13(-41.289174233754956,-0.6532576640849115,-99.05455423626094,-1.0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark13(-41.42244687514911,-1.5707963267948948,-2.364642562093465,1.0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark13(-41.484532825430875,-0.22329832806764927,-1.5707963267948966,-29.673314211352036 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark13(-41.57764446916242,-1.54145785104707,-45.717252320096975,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark13(-41.59514868743823,-1.2548728701153344,-3.910823200014988,-1.0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark13(-4.15984983344255,-0.4550893022106809,-95.73314792231675,1.0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark13(-41.68779572329053,-0.9960709753747831,-1.5707963267948966,79.96319296764847 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark13(-41.70581048786556,-8.881784197001252E-16,-37.8505823157727,-1.0000000307560304 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark13(-41.78780448892121,-1.2542595563688363,-26.306700803054397,-1.0000000234983597 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark13(-41.80593175307325,-0.07368836578615401,-43.03977836110175,-1.0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark13(-41.844128028560164,-0.29404716092050187,0.0,0.0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark13(-41.917636841228386,-1.0264552624456411,-66.14463741851998,-16.839675290277548 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark13(-42.00992144783837,-1.1190291646543624,-88.74101125019034,73.79529239614018 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark13(-42.01929362858611,-0.19041851614093475,-19.87477408263888,-1.041750090826582 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark13(-42.0917476748903,-1.5443269112434537,-79.68037746713145,1.0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark13(-42.25660256104014,-0.03068742904546199,-3.355640274878205,35.95709779137326 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark13(-42.25931029500327,-1.4710075592443084,-28.74187801217559,-0.033763944805708684 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark13(-42.306499144384226,-1.4385088749058532,0.7900311287363558,-1.0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark13(-4.237508699426559,-0.8801895750137981,-49.12363071085821,-1.0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark13(-42.43841383752713,-0.04761948713434563,-62.274264760228704,1.0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark13(-42.46961080973595,-0.5588242237716536,1.1690302175701577,2001.281074846318 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark13(-42.470018105557955,-0.020975898512256067,-11.258229792093617,-0.9870138400556127 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark13(-42.57326836134373,-0.15803373332920814,0.0,-0.19589791388889 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark13(-42.672546582506676,-0.9397605236534758,-84.24558834818164,-95.57428909182113 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark13(-4.271445536887411,-1.517986774012248,-75.35043254673009,1.0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark13(-42.72096059079415,-0.8259802754886999,-1.5707963267949019,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark13(-42.847472030207875,-4.440892098500626E-16,-0.4171462194365745,0.7815589712179364 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark13(-42.85878675497881,-0.3041444691076457,-31.642802363533363,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark13(-42.87658758127491,-0.4879213901439252,-12.522572608398395,0.2744217918255458 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark13(-42.88563653534252,-0.00765113894163851,-34.215667116798855,-40.389349771383536 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark13(-42.89635840835217,-1.409786770948343,-1.5707963267948966,-47.90738856813046 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark13(-42.993874200458976,-0.43995989033144567,-57.38961106834879,100.0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark13(-43.080107031053736,-2.038372188630947E-5,1.1176954430064288,-0.41564069704699413 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark13(-43.09391578874935,-0.4872867102783913,-82.07172602543756,0.3621086018613967 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark13(-4.322414146813635,-0.3518276015142101,1.4905519940640624,-0.9196575258006399 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark13(-43.239017280697496,-2.220446049250313E-16,-24.772239098343302,6.344994601364354E-6 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark13(-43.34282465376721,-0.3768062781509798,-38.02749290404631,1.0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark13(-43.39457087136547,-1.5707963267948961,-31.324909026733643,-0.9994536860440778 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark13(-43.46654283377797,-0.9654577279823684,-4.615125329255905,0.0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark13(-43.47530615639834,-0.035896329674947935,-96.89055893705479,-1.0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark13(-43.50019628809727,-1.56874456844537,0.0526550344487473,0.06621956940681673 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark13(-43.51767815487177,-0.006446701768021959,-0.37581087056536044,1.0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark13(-43.5557654868515,-0.8750584850755712,-90.37432473592115,-1.0000000550849657 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark13(-43.57379107361751,-0.3944831400371036,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark13(-43.665114894817634,-0.4146983892305781,-67.25814286257146,35.71919880862535 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark13(-43.74197574952748,-1.4513309273535762,-22.476170831722,-12.83340563523133 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark13(-4.374735426867332,-1.5707963267948841,0.0,0.015669707979474114 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark13(-43.74817656057931,-1.3141911451559796,-38.83121442640894,0.0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark13(-43.7503299897474,-0.40204985841441643,-1.5707963267948948,0.151187067962681 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark13(-43.838781189221535,-0.35535752314671654,0.3614575871060014,-11.287173342339969 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark13(-43.962423059952414,-1.1102230246251565E-16,-0.4221386435203949,-100.0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark13(-44.039834411699665,-0.1202694926459825,0.07725619610906398,100.0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark13(-44.21398551487809,-1.4489381311649736E-16,-1.5707963267948966,-0.9999999999999999 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark13(-44.24883343967617,-0.9927525750920568,0.06734468957649593,-0.05270655139397873 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark13(-44.618057382679595,-0.0440015945591001,-1.2046706277463473,0.005305363699710353 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark13(-44.73516586282891,-0.3668551291660173,-48.843420095290455,-26.15890833146397 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark13(-44.76984961832012,-0.6613910659943105,-46.74459438562022,-57.71046139530201 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark13(-44.808223771317614,-1.128735823914794,-94.67337934744405,0.08093421744448115 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark13(-44.90246909898467,-0.8206206924390251,1.1727697551892922,-7.74535529856863 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark13(-44.92626882992506,-0.2952191753468867,-31.565074424424424,-94.92110687236683 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark13(-45.00895978364648,-0.3060746974535403,1.5599008503256515,-1.0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark13(-45.11143178713648,-0.21357147701583018,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark13(-45.11534511004904,-1.4628755325426877,-46.63577938024856,-1.0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark13(-4.515351385793821,-1.5707963267948895,-31.269701715551832,52.31593788617252 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark13(-45.20361143753689,-0.4118631188475139,-122.97957895321176,57.866120042591604 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark13(-45.27085074465511,-1.5707963267948961,-1.4079953965079242,1.0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark13(-45.333891009482265,-1.1102230246251565E-16,-64.50651590102385,-2.2227587494850775E-162 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark13(-45.44110311664491,-0.0536815205764076,0.0,1.0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark13(-45.684243129123715,-1.5707963267948957,-88.09536579231393,7.105427357601002E-15 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark13(-45.698964778712494,-76.41624441544948,77.12119796947763,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark13(-45.70116406715352,-1.1291448906676784,8.881784197001252E-16,-58.94656264264751 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark13(-45.73072570148727,-1.4821563363437034,-121.47673342929627,12.16657719070011 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark13(-45.77567622494248,-0.03359255794418607,-52.231202396077755,-1.0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark13(-45.85186391569062,-1.1978437564510622,1.5387563534871422,-1.0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark13(-45.871113472055306,-0.47309301306390894,-136.25355670729263,-0.999711131503008 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark13(-45.880006950014625,-0.5232873232596453,-44.45186399496843,1.0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark13(-45.96589261111659,-0.7929439209066907,-100.0,-11.307076999687766 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark13(-4.610616207414025,-0.9434189007833278,-63.18379765492671,-0.006463209512005935 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark13(-46.11092889380346,-0.7139824314057392,-100.0,-0.5949890374872038 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark13(-46.18750887997768,-0.08054489470063905,-40.814041355337494,1.608611746708759E-86 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark13(-46.20681228021341,-0.3096859163622474,-49.726912599166106,-0.2525401501642013 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark13(-46.21069868187685,-1.526134894269919,-9.648870435255152,-0.9999999999999964 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark13(-46.22231563425532,-1.8979903050747365E-15,-0.9274194738764951,39.875775258081376 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark13(-46.23241579328586,-0.7677895368428838,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark13(-46.25936961992012,-1.503531890913433,-66.20316414369141,0.5731329598737043 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark13(-46.29000642343869,-1.4508214424032517,33.89969946956747,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark13(-46.29815373756486,-0.6251767884344348,-66.45950919284304,-97.8792757708496 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark13(-4.637440923752096,-1.5707963267948957,-38.84433920759467,-50.04072988449772 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark13(-46.60837986730139,-0.11310838409880883,0.6418655473515241,2232.6099030628206 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark13(-46.763064316828135,-0.17801212558411195,1.3103346255847912,0.038596578404086146 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark13(-46.80478325380056,-0.3352628855394917,0.0,-0.47795907288046546 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark13(-46.86248485361409,-1.5707963267948957,-21.51345057820653,-0.6581175025832885 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark13(-46.865119843111636,-1.5707963267948788,-43.35231468024596,1.0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark13(-46.958939571395405,-0.8488043014731197,-12.509351276808278,11.685124142230691 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark13(46.97822610129862,-0.24098447078762852,0,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark13(-46.99911922723427,-1.5666717640112218,-2.0777361758507595,-36.547753094533505 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark13(-47.22682444149001,-1.5707963267948957,-30.300676590633017,-0.3622330179804784 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark13(-47.332934824987376,-1.5706107522728947,-4.3896389544931767E-13,0.9999999999999996 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark13(-47.364190157878895,-1.490180045323502,-56.90133146684678,-27.77215848608578 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark13(-47.374690948035635,-0.5409725553110187,-77.60253452927108,29.11026855456913 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark13(-47.544742642316834,-1.4827134395343684,-71.07709882456616,31.64995206312506 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark13(-47.55962702318695,-1.5707963267948912,-67.92518839506471,0.3491304884514097 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark13(-47.68892767868388,-1.239151622988918,1.570796326794893,-33.14170172183088 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark13(-47.7246060948435,-0.015646417549382566,-1.4015552492171246,-1.0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark13(-4.780966200085048,-0.473747507691403,-98.73235251737889,-32.01413469181291 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark13(-47.82100282011342,-1.4996244187571364,-20.56868476904279,0.10819519239422981 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark13(-47.857074454478415,-1.4751567946123776,0.0,62.77871642491664 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark13(-47.86248187503992,-0.9581633306498993,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark13(-47.868973117147306,-1.280038460193317,-21.12021808708261,-0.021438696484236353 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark13(-47.87720729278186,-0.25787269824438264,-20.03907185777942,-54.49558710194668 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark13(-47.91072496423742,-0.7140975532867344,1.4433797397803687,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark13(-4.811212540674458,-1.4409474684356063,-0.8127867241273492,-67.19457373232277 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark13(-48.116176511528316,-1.065612164309504,0.4000665957663993,-1.000000000000007 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark13(-4.8146618282532,-1.570796326794893,-100.0,1.0000000069102744 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark13(-48.21891976911238,-1.5707963267948963,-49.12919198730488,-0.6378029759090302 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark13(-48.24163827271914,-0.7480484292066678,-63.113949500847156,-30.649207349193546 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark13(-4.834878156507557,-1.329429995449993,-92.41577474140664,26.733805496791543 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark13(-48.500545652863714,-0.2611343062726764,-1.5532896324786327,1.0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark13(-48.74302111672912,-0.19803543979686788,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark13(-48.8653139317225,-0.5607366245747869,-26.74181472674465,-0.497976376545451 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark13(-48.86556405506984,-1.2825574834796445,-98.75030690038793,-40.103397800160835 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark13(-48.89788669183555,-1.5707963267948948,-19.755690514105034,-2144.2823014780242 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark13(-4.890323379550942,-0.287887026122907,-40.85336895811962,1.0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark13(-49.03151980274677,-0.2804352051285831,0.0,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark13(-49.04249260586524,-0.813773262054379,-86.90620690221878,1.0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark13(-49.39380725761521,-0.783224271112002,-31.64813819795492,12.151749317809397 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark13(-49.41143348957212,-1.5707963267948912,0.28457135576044046,-28.07388722594996 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark13(-49.43073518792795,-0.6436196393157978,-29.947944233410936,-37.64986972219286 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark13(-49.471621703822805,-7.105427357601002E-15,-12.843428201866118,15.866431117399088 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark13(-49.51152776787153,-3.552713678800501E-15,0.45083479379362956,1.0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark13(-49.565539788144484,-0.2201524894607303,-1.5707963267948983,74.03218682793894 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark13(-49.58901094346773,-7.105427357601002E-15,-80.29042543201169,-2157.060781987099 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark13(-4.961395951841006,-1.5707963267948912,-94.16733710923171,0.3626052892723354 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark13(-49.66666606070418,-1.5707963267948948,0.9908113140617354,-70.31643109901484 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark13(-49.6722147483762,-1.5707963267948912,-45.06149036424216,-78.93934612326782 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark13(-49.75184692277032,-0.897543825013216,-0.6328524547637269,-76.25748611815789 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark13(-49.775019956265965,-1.1863574225195141,-32.189713418786766,-1.0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark13(-49.8690124022531,-7.105427357601002E-15,-47.06896321465888,-97.5856349112364 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark13(-4.990629941620414,-0.18870877028900704,-0.26723049643643937,-1.0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark13(-49.99173674166006,-1.7763568394002505E-15,-15.372721671706067,-84.19421038603627 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark13(-5.016005429067544,-0.029472727273354593,0.0,-66.91583821713225 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark13(-50.19390687373728,-0.8969688663196345,-0.005001445121315062,-1.0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark13(-50.23584555233871,-0.17150251690461005,-22.85355868802445,-1.0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark13(-50.38090481882076,-0.005278126414990083,-1.5707963267948966,-0.21274954449503325 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark13(-50.40195197187412,-1.5644250682209757,-0.042415255634043865,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark13(-5.045027411449569,-0.19427043609633202,-17.675142884769883,-0.028515554999127793 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark13(-50.46827983523184,-0.21029395490757302,-78.79951321864195,1.0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark13(-50.51840619638861,-1.5707963267948957,0.0,60.9677216829817 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark13(-50.56042591873999,-1.6893050908924249E-15,-1.5707963267948966,-81.57638140477405 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark13(-50.593839589497115,-0.8937428371905523,-1.5707963267949054,-1.0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark13(-50.600019599918355,-1.367599176858567,-32.72826259254751,-39.25470727775175 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark13(-50.66058251404549,-1.124678178085525,-3.234892639572397,-0.5047386042983903 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark13(-50.680840334105696,-1.1771139493205947,-4.994282821398748E-16,-3.6821537470210723E-16 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark13(-50.73520129309288,-0.16587502289650247,-1.5707963267948966,53.18536171735916 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark13(-50.77126867187239,-1.468572010356537,-1.5707963267948966,-1930.2918170303367 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark13(-50.79171739023987,-0.8693971982297144,-56.91313919110146,-1.0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark13(-50.81148931833755,-1.4168781752951856,-27.679745761561293,-1.0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark13(-5.084741361097204,-0.1734645977877452,1.5707963267948202,0.36681737696303707 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark13(-50.96286203950975,-1.5525355304867066,-1.5707963267948966,-41.38084394098522 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark13(-50.96357046424895,-0.384504851620256,-57.537701693882354,-46.70253271431713 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark13(-51.00543697182394,-0.989424952906205,-31.916787938486234,13.502894456194078 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark13(-51.11607169377546,-1.0600231511985272,-47.37775672348487,0.04132452040600568 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark13(-51.39573494760636,-7.105427357601002E-15,-90.05942868618459,-1.0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark13(-51.39765835527401,-1.325521478483226,-0.46157836215821685,-70.8912415898748 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark13(-5.142977537814365,-1.5707963267948961,-13.917094807161362,5.1977048828224496E-113 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark13(-51.4829146205821,-0.688228922854737,-55.964116685837375,-1.0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark13(-51.487250542972205,-1.483938903604231,-44.66267510446922,1.0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark13(-51.5472920876851,-0.14457198659320447,-61.3934233422987,-0.022843547690672747 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark13(-51.55633649056097,-0.5865589965360698,-10.337868781181815,62.68188288451651 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark13(-5.17273291634268,-1.0266382298589434,-7.675943200359669,-62.06662331425108 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark13(-51.80588221744495,-1.2419555182733781,-46.48830786196903,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark13(-51.82031859110918,-0.02027809694996116,-44.34627129324224,-0.704100785661691 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark13(-51.8463693337757,-1.5552429497218538,-23.84709739978912,0.034194553959390826 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark13(-51.90696000546376,-1.4215223605888365,-6.119219668655049,1.0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark13(-52.03501027646696,-1.5707963267948912,-69.78542890467892,-1.0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark13(-52.0871044290361,-0.048684821181446895,1.5707963267948966,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark13(-5.2088579155187436,-1.5130824401564817,0.0,0.0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark13(-5.2142779697437955,-0.6435370690092928,0.0,0.9452284646817721 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark13(-52.16784848675479,-1.0665807421278048,0.0,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark13(-52.2183264899462,-0.5402578871877495,-28.465536797890366,-0.7266180130583284 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark13(-52.253742931460245,-1.467946580657316,1.5707963267948948,-0.5760989171012649 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark13(-52.26205987427623,-1.5707963267948948,-52.34126532096308,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark13(-52.416718635108595,-1.3712358080108675,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark13(-52.4471517845771,-0.9273237356437232,-32.97905828262196,27.406913619689004 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark13(-52.45311167410921,-0.29238901545123763,-89.39067561944185,-0.0627081281123558 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark13(-52.776598921691466,-0.42856751077573213,-0.3354161757465704,-0.0022154959491297033 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark13(-52.86200871426108,-1.5707963267948963,-32.489017492714744,0.009523177804263531 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark13(-52.88910863755677,-0.6095999540190843,-80.09526147877548,0.984704340277157 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark13(-52.902850882233125,-1.5707963267948806,-27.10690226327717,0.3200155842923682 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark13(-52.923018594342835,-0.10904841402880733,0.27186453043197034,-12.15052880797555 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark13(-53.074579080375855,-1.1102230246251565E-16,1.5707963267948961,-0.06255280105165786 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark13(-53.14522815190408,-1.5707963267948948,1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark13(-5.315659011702653,-0.39896572035673356,0.0,0.9986352156896219 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark13(-53.23224962033164,-0.5456734399416767,-43.67910463074886,1.0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark13(-53.26479179075312,-1.5707963267948912,-4.162426543633664,1.0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark13(-53.3002963875831,-1.5678229017381882,-1.409622781961045,0.5557631297669441 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark13(-53.34542524412069,-1.303970351570213,-74.88144331970608,-35.36427096120795 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark13(-53.452570356567584,-1.5186153755703242,-20.4665177317332,-0.5571137931019949 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark13(-53.464379760590425,-0.11268854561211218,-40.205186676383356,-0.6139209445754784 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark13(-53.466323277244335,-0.4668816379997577,-1.0123693255978186,-100.0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark13(-53.512838878767084,-0.20859140788461672,0.0,-1.0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark13(-53.59832237864712,-1.2554113010218162,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark13(-53.610493446012825,-0.5406942239916707,-36.87572124470538,-28.42821904269801 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark13(-53.66203423479536,-0.8922627652812638,-30.674260712544807,0.9999999999999817 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark13(-53.67465389509929,-0.5387712938866911,-9.43477033624697,0.6488595808918971 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark13(-53.72660477879378,-1.5707963267948957,0.0,-1.0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark13(-53.74433900718455,-0.7146057653688587,-25.196021428669987,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark13(-53.805666084316556,-1.3456907942462522,-43.544314981375905,-1.0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark13(-53.86160699894309,-0.4635532429064377,-52.615020804141565,28.01903148493713 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark13(-53.943859303908305,-1.5292874023575675,-71.30001531176686,1.0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark13(-53.96300494166667,-0.6704467408489061,-76.42220442162635,0.08786985608162975 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark13(-53.99538109609407,-1.5707963267948948,-23.89344350415456,73.73508249208334 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark13(-53.99602604610751,-1.3550986262600246,-1.5707963267948966,-0.9999999999999761 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark13(-54.11049890710594,-1.5707963267948912,-64.81664169782758,0.5406948696807417 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark13(-54.19483235979071,-7.105427357601002E-15,-39.29473788598763,0.7938463588768929 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark13(-54.262647097197075,-0.7723380791285996,-1.5707963267948966,10.052727729869183 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark13(-54.300951070850616,-0.3149290396659117,-51.70507211783707,-69.03000939456658 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark13(-54.35122158017136,-0.5199500171407254,0,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark13(-5.440569719998952,-0.6358325317828185,-3.169444670106884,0.06124102797430313 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark13(-54.41083819640343,-0.5349731103518239,-67.89959010962002,-0.2116867251997001 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark13(-54.44183456566326,-1.2957196444134103,-43.10711797063438,30.80500335949857 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark13(-54.45747928869262,-0.009326579515759083,1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark13(-54.61932226625421,-4.362233865327297E-15,-3.944304526105059E-31,-38.15966393596192 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark13(-54.80175497585326,-1.3137502815902975,-33.40414927471767,-85.45474251757173 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark13(-54.92515436904572,-1.3279022016796307,-45.42648856116292,-1.0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark13(-55.0314185547317,-0.322740791075807,-58.31446093192334,-51.73335576930856 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark13(-55.09937075486895,-1.5580042545603614,-26.184442094414024,0.6097669245435594 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark13(-55.12792475734505,-0.7230653236647296,-1.5707963267948966,60.803020408241096 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark13(-55.176041137471415,-0.8723958034365675,-37.9293060688375,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark13(-55.25651380121447,-1.4112685006433023,-71.60088808339995,-83.21621960557194 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark13(-55.31114712026526,-0.7137439819534904,-56.43984983297135,0.044332614963417116 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark13(-55.31694062379702,-0.35496036114604823,0.2813345228897931,1.0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark13(-55.4091114179283,-1.1589584759754827,-94.77292598623508,-0.15009661413133246 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark13(-55.51428777340634,-0.3973934415533189,-67.29503848850362,-0.2695047655934663 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark13(-55.52103031898445,-0.024883850517211707,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark13(-55.562825234624945,-0.592482350649916,-29.96329837939112,-70.20156869491389 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark13(-55.60135842803637,-1.076562264619159,0.3709588644227111,-46.05325359094587 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark13(-55.60202204392333,-4.440892098500626E-16,-79.83224937204578,-0.19197931285387237 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark13(-55.609375246147025,-0.21293300470490764,-94.33997487486941,-0.050520772509156014 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark13(-55.67685750419098,-1.5707963267947669,0.0,-1.0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark13(-55.705781528079925,-1.5707963267948961,0.16324139417773154,0.8573765775149269 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark13(-55.835212948896725,-0.8663096059495214,-1.5707963267949019,-29.710147105693927 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark13(-55.838760583829725,-0.03122259114095982,-152.58672120219433,-9.512133947257164E-10 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark13(-55.871342742609784,-1.4701868483783165,-99.43958989657357,1.0430389586656785 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark13(-5.588143268103339,-0.2837639337380614,0.0,1.0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark13(-55.893953007656094,-0.3591981548314879,-23.46043356302389,1.0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark13(-55.9222216485763,-6.670224405640024E-6,-64.54378449740554,0.02669972158096559 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark13(-55.94920042323618,-1.1228945721830113,0.0,36.102189022365295 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark13(-55.96492536702526,-1.3460264459970404,-0.11123731975141293,-1.0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark13(-55.99693738580065,-0.7972705857560239,-0.1860749771253607,-3.3409558876152446E-52 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark13(-56.131470611327984,-0.8877906429653609,-35.132112409860696,0.018544594438112794 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark13(-56.17784975507889,-0.0011041930511322667,-72.18028551845705,1.0000000000000002 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark13(-56.178828759309866,-0.47215709595273303,0.0,56.89177711276574 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark13(-56.388088200359135,-0.43534074003424905,-21.2520087717082,-20.31892642310723 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark13(-56.400522626215654,-1.5707963267948912,-44.20659085652912,-1.0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark13(-56.47397463123962,-1.5707963267948948,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark13(-56.48628325556911,-0.9190915062988883,-1.5030497163765728,1.0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark13(-56.5271082376881,-0.7281822869163506,-23.996989716497055,0.9357296614143725 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark13(-56.6935046136348,-0.09669718814266082,-0.8418869297856446,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark13(-56.78316216123536,-0.23172858042961764,-95.57094725961093,-0.15877896057882745 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark13(-56.83445058679092,-1.7763568394002505E-15,-12.745356446436467,-49.29441909089133 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark13(-56.83694175936538,-1.5707963267948957,-1.1121221088103255,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark13(-56.85238489579738,-1.5707963267948841,-30.149744706030816,1.0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark13(-56.86444283227966,-1.4547091313303642,-21.18932371320972,-0.22332298739564593 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark13(-56.87261894696427,-0.7362056507762422,-32.681409732048735,1.0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark13(-56.924703730947236,-0.9947971251753831,-57.891536285266376,66.35086807608184 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark13(-56.9999797119783,-1.226037800124421,-10.647669222825364,20.06792316560721 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark13(-57.0722724341254,-0.3291436968549569,-1.570796326794896,0.4977881001074741 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark13(-57.10080066337473,-1.5707963267948912,-61.15851201141841,-82.8015787034923 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark13(-57.1088952634543,-0.2673626233541242,0.0,0.8542964094007122 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark13(-57.140192838382376,-0.3557115345959529,-31.810114536481386,-1.0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark13(-57.33201174103492,-1.3121894952006519,-68.4207452783021,24.5282231401784 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark13(-5.744138762058924,-0.22989123459708197,-79.61822968423311,-1.0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark13(-57.59826135414692,-1.4084754698158803,-31.270005117061416,92.51892320940345 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark13(-57.62612014903785,-0.44292262323274656,-10.498138110746805,-16.83399249173219 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark13(-57.63071454045496,-0.44553822407660826,-8.097130664489422,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark13(-5.763615631075118,-0.004210958414619713,-66.61772998614641,-1.0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark13(-5.76793861302997,-0.7766398154112603,-25.813154684968858,53.916028472957066 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark13(-57.680629787524516,-1.5439689244873223,-9.088021817457175,-87.27768208726702 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark13(-57.700467947337096,-1.1222119088891882,-5.38840736698323,-1.0175630714945374 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark13(-57.73044740698416,-0.5892456935852576,-60.47536835823135,0.9999999999999929 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark13(-57.85740270200623,-1.1307622529566823,-1.4563950348161248,1.0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark13(-57.941990545185874,-0.4135944105911068,0.0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark13(-57.950006539854215,-1.546009955044596,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark13(-5.795618583389742,-1.4479333756544461,-66.92665557315539,-89.97211111239412 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark13(-57.99479593387809,-0.41709470127518206,-47.80582682934409,-1.0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark13(-58.00074856623512,-0.961758759676449,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark13(-58.01969302413954,-1.5707963267948957,-9.985497311047894,27.71722512269399 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark13(-58.02488469405792,-0.7172777298057805,-76.49494861948817,1.0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark13(-58.13429976249979,-1.0322259077784612,-92.59528379596101,0.03760905831006782 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark13(-58.1870756935113,-0.1967228760087143,-49.430789221956076,-57.96110584305909 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark13(-58.24718042073736,-1.4349333017826633,-0.7167600539283179,-0.1235726813490019 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark13(-5.836739441109646,-0.26248594519413637,-46.3844131938671,-1.0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark13(-58.420326406545904,-0.001576356411313734,-1.5707963267948966,-0.9999999999999964 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark13(-58.45847493897894,-1.301967634943935,-53.46654516124651,-0.09142985993009489 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark13(-58.49882607852304,-0.8610646480643254,1.5707963267948948,-2141.2043291630434 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark13(-58.577212682832325,-1.5171541036313092,-1.5707963267948966,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark13(-58.61126722178999,-0.9482895004921702,-68.96835287000621,-0.014630092032842271 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark13(-5.875622811540303,-1.2323070334215673,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark13(-5.87708172656656,-0.9645093880229743,-62.70867046619817,1.0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark13(-5.890613202178152,-1.0196927824323296,-1.5707963267948948,-24.292694357150694 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark13(-58.921116106462975,-0.8229036356291761,-13.011521308370334,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark13(-5.893371234913376,-0.8023942481871281,-33.00946181567082,-1.0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark13(-58.958330653009,-1.5707963267948948,-27.72527130929564,-57.071007272164124 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark13(-59.07549882790873,-0.7215689058098178,-8.355517566908318,2.1175823681357508E-22 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark13(-59.11655193071147,-0.0659906513482846,1.2231768547641693,-0.05389314557334507 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark13(-59.121265709194596,-1.1120359629713423,-68.7048037463031,22.14559034415234 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark13(-59.20076930119043,-0.2659211994113767,-73.93428874016249,1.0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark13(-5.923818549143121,-1.5707963267948948,-100.0,1.0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark13(-5.930462467914452,-1.4243110534462886,-74.27884400029994,-0.5553672287192355 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark13(-59.31251577822515,-2.220446049250313E-16,-11.54473496540486,-55.47114863826074 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark13(-59.335605402772735,-1.5707963267948912,-1.369831107508337,-0.4248263052696124 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark13(-59.35964215922841,-2.271972891571269E-16,1.3484080378020179E-15,1.349401336733507E-79 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark13(-59.42795087952162,-1.5707963267948557,41.8416990202941,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark13(-59.44476299649136,-1.4862120387756697,-1.366240298953707,73.94155774562918 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark13(-59.495084705756085,-1.5707963267948948,-8.337735108239677,1.0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark13(-5.963642170908232,-0.9183547121265049,0.0,-1.0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark13(-59.63765200377287,-0.5389342947585319,-45.1362632746913,11.51439166823775 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark13(-59.64174159493273,-0.08624069071020744,-75.53903696628043,0.021292921947458243 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark13(-59.73894338471697,-0.07208447042445698,-44.282822359899605,-0.6042914678561884 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark13(-59.84746347637939,-1.4064032824599442,-4.005866441600745,77.68636092811359 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark13(-60.02739744338094,-1.5707963267948912,-30.124671897428712,1.0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark13(-60.12498646576201,-0.5674670592388,-0.23267349085649913,0.6388798861152698 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark13(-60.14046151142534,-0.5517734918790725,-1.5707963267949,0.025878740784118084 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark13(-60.15304831726864,-1.5635340494196015,-23.975075220389293,-0.9683460372412467 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark13(-60.263462097928986,-1.5707963267948792,-0.5418187669165171,-0.1878588561301705 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark13(-60.265966020480214,-1.1261160813262592,-100.0,-1.0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark13(-60.27166902140611,-1.2555531127615305,-90.74808982246373,0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark13(-60.28134656463787,-0.5673960191341993,-56.89912250538234,-0.9999999999999993 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark13(-60.386154890956284,-0.12249402377393659,-0.28834997516060323,86.76469827104917 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark13(-60.437958743132654,-0.8635354356607343,-1.067972111733048,-0.00985053511846054 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark13(-60.58230540681291,-1.1352767708972493,-71.75312684114961,-32.33112528699 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark13(-6.060960843307068,-1.3872883247009675,-88.09829274863318,1.0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark13(-60.77602904954079,-0.3426303735845754,0.0,1.0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark13(-60.78263381366223,-0.3565306161833163,-24.86218231434256,7.7175786021782535 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark13(-60.89789820010278,-0.43512927705732807,-51.91017560988689,-2139.425953905296 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark13(-60.90058974701787,-1.5543108897970632,-1.5707963267948966,-0.046318440146914774 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark13(-6.114693497478948,-1.2357802512987546,0.0,0.5134014679118999 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark13(-6.116295751176835,-0.14298762635682039,-6.905215680707542,-0.12122503571528043 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark13(-6.119690469733164,-0.4764328395291879,-5.995541681655325,0.6234939913296614 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark13(-61.19756953653,-1.4414782854209216,-24.99736676082369,1.0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark13(-61.21317742040293,-1.1102230246251565E-16,0.5593562759132066,-7.996875345235904E-17 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark13(-61.32840019065163,-0.14198076535375262,0.45273005198978356,1.0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark13(-61.38497085593396,-0.5010499696402875,-31.722657450485862,-1.0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark13(-61.495779951887535,-1.5707963267948963,0.0,-0.0165058010787821 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark13(-61.51352071003698,-0.4594788965340304,-100.0,1.0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark13(-61.59884143793739,-0.9904539433899346,-3.0553855815103526,54.8160614875935 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark13(-61.69342866631554,-1.3126204304820543,-47.093037118327985,75.68319448719993 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark13(-61.76873826465577,-0.6187393428988419,-100.0,49.84418233429916 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark13(-61.777471639694305,-1.5707963267948963,-19.129958244346142,15.751956374364882 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark13(-61.80007278231396,-1.5707963267948912,-17.66974022730406,0.2502968132905088 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark13(-61.825232619262664,-1.1550202497887485,-88.14300324108126,-0.06259774239172633 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark13(-6.188775440444859,-1.4423355555600628,-4.244344250183974,1.0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark13(-61.924855933842714,-95.9298527625567,0,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark13(-61.98865284010723,-1.0385959479019415,0.0,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark13(-62.043253516188855,-1.5707963267948961,-1.5707963267948961,-1.0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark13(-62.107648151128565,-0.2880367942922104,-67.0741271184799,-2.0303534698525194E-115 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark13(-62.244942225843396,-0.3031978851526694,-88.7029798146853,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark13(-62.49106772691757,-1.385856272731881,-99.91218749547772,23.52748015602259 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark13(-62.54277888375617,-0.06700601890627148,0.0,-0.44060069556888837 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark13(-62.54492316105971,-1.5707963267940812,1.5707963267948963,-72.70661905324548 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark13(-62.550474806758196,-1.5707963267948937,-78.34175587219065,0.028247148277610046 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark13(-62.71647845819406,-1.5369147407312407,-35.09770421885452,82.9951857607659 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark13(-62.71748968810543,-0.6722091862232604,-21.569292651966524,-86.98086598393648 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark13(-62.73335302466108,-1.3100834255198994,0.0,-61.01915373906679 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark13(-62.832399410909176,-0.35780459656021435,-33.54983116769543,1.0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark13(-62.96818483947434,-0.42635634169515324,-100.0,-0.4349080857101484 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark13(-63.09656212987383,-0.29713838774640666,0.23293396069279837,1.0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark13(-63.16680104210146,-1.0858349345096756,-1.5707963267948966,0.6056525148738784 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark13(-63.22213361053506,-1.564528567016966,-0.23692428612810784,44.444050863111556 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark13(-63.246861546654706,-1.5707963267948912,-45.13465158686905,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark13(-63.27818797898253,-1.7763568394002505E-15,-48.45847463977947,61.325383625335505 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark13(-63.66643975819264,-0.20002265610178163,0.0,1.0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark13(-63.67759379296182,-0.1901689257710356,0.0,3.089923093987358E-15 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark13(-63.71455554648004,-0.3437940763820226,-29.377602698105314,0.6525029296976494 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark13(-63.73887524480234,-0.08651665036387866,-100.0,0.2304189517420413 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark13(-63.79236812188691,-1.5609387266496824,-6.822872914545435,-32.04018967754311 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark13(-63.79481030531058,-1.4920471702476181,-1.5707963267948983,-0.06275231929531098 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark13(-63.8504349075042,-0.36828147572873604,-27.324177296656302,41.8382948497271 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark13(-63.98881686359514,-1.436271678317262,-43.261807364134135,-3.39443524999812 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark13(-64.01627056706049,-1.5707963267948963,2.09433735072595E-17,34.61271841202076 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark13(-64.1368059562386,-0.013447150879435599,-23.95219351413112,1.0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark13(-64.22685084834738,-0.9921242883881036,-32.83696738812935,0.9329480476029735 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark13(-64.26962571571958,-1.5400531345874167,-72.37457573103988,-1.0000000282343529 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark13(-64.30358767827681,-1.570792919724002,0.0,1.0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark13(-64.31414287624254,-0.0835932493804605,1.3874674350525866,-0.3056633489882715 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark13(-64.35282881428162,-1.5707963267948948,0.0,-33.87902626604075 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark13(-64.38186553566622,-1.570796326794895,0,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark13(-64.41220072644599,-1.5661124445273877,-4.93419437165254,0.02217216783343999 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark13(-6.44342207524511,-0.7594868112605013,-32.79660528039251,-1.0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark13(-64.50673768623858,-0.4481850974117293,0.22776021477056915,0.0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark13(-64.62011479687405,-0.7278479185549582,-1.5707963267948966,60.891396730368726 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark13(-64.68908208879279,-0.6861344348711143,0.0,0.050866156540878844 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark13(-6.47568597376975,-1.5707963267948948,-67.49871049004408,-0.5971270151451176 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark13(-64.83701876629354,-0.779132360433348,1.4097155819857734,0.04697877053199245 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark13(-64.84646246248121,-0.009936031573672737,-135.5075816012974,-0.793080360384733 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark13(-65.05977894593973,-0.7674117583927225,-65.15824670107033,-1.0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark13(-6.511721368168907,-0.17060580645568035,-79.45622405371645,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark13(-65.31762720294172,-0.9342896862956316,-11.07076274780616,0.0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark13(-65.34645123248453,-1.5698222334368626,0.8316327134525536,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark13(-65.38602646505741,-1.5707963267948963,-39.209044905973784,0.017465729219846945 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark13(-65.39660912170885,-9.087053573556982E-4,-25.14889223933903,0.9637843921923439 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark13(-65.39679199599641,-1.3597441866659632,-62.90060354525586,-42.8650213701647 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark13(-65.46820238711086,-1.5707803515709502,-1.5707963267948966,1.1267676533844275 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark13(-65.77941472239067,-1.0100940471981252,7.315116427431035E-4,2.1175823681357508E-22 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark13(-65.89392030031799,-0.05471899852524989,-1.54216821753754,-1.0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark13(-65.89467717307173,-0.6106326911354167,-75.39239917616315,-1.0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark13(-65.92315688645711,-1.53603392538246,-37.9055126787424,-88.63218389001551 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark13(-66.06096741918643,-0.9091915333976982,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark13(-66.06281079238197,-1.4732280335212122,-61.93764869798147,0.47006297244788264 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark13(-66.08460581485161,-0.9331254094646316,-4.873313502432595,-1.8060872677125417 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark13(-6.610803716306918,-0.5956968301430414,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark13(-66.1201118254768,-4.440892098500626E-16,-6.8548257729905515,-93.08301175987312 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark13(-66.14775687691994,-2.220446049250313E-16,-40.24926276408964,-1.0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark13(-6.631247282773299,-0.08769095404239097,1.241743550247601,-0.957336443682367 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark13(-66.35102473899438,-0.08301042827181884,-59.72577286312035,84.85538092958541 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark13(-66.36362371925637,-1.5707963267948963,-36.00480563036703,-0.4531099498827127 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark13(-66.44394170722035,-0.22742480033398818,0.5195468377732885,-1.0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark13(-66.51719209652427,-1.4252996530962643,-26.051391685049083,1.0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark13(-66.5419720149335,-1.5707963267948912,-76.11247637892103,21.957043946724724 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark13(-66.72034298160366,-1.5707963267948948,-1.5707963267948966,-0.6035803250980626 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark13(-66.79441692524837,-1.5350871908850574,-82.21051238290602,1.0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark13(-66.89464128457567,-0.1804019076180452,-82.95874840619896,0.929146595549887 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark13(-66.91467266359903,-0.04907103729705947,-7.978205052497102,-0.16363837353756713 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark13(-66.96624914349812,-0.7827113267121354,-27.42544307148684,-1.0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark13(-66.98277058515802,-0.11037280061890187,-31.131753518485166,-80.63215986896103 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark13(-67.0039832411362,-1.5707963267948963,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark13(-67.00457480632618,-1.5707963267948948,-13.341455696204221,-74.74904733439828 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark13(-67.13925765074697,-0.39493819392788065,-1.5707963267948963,0.03687418886291771 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark13(-67.16829584221936,-0.5296573105536362,-0.08002685814402519,1.0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark13(-67.25003953962408,-1.0153982675086837,-19.318436878617423,1.0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark13(-67.33189835342472,-0.5373924330016564,-42.668051646267,51.25833761845021 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark13(-67.35084370545287,-1.549665397726077,-34.00476704210385,-1.0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark13(-67.35710581672691,-1.1560510470528709,-44.53141370475067,-1.0000042534615887 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark13(-67.37987170230308,-1.5024137031719282,-72.42777048933135,66.20180088252707 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark13(-67.4897267585137,-0.43546596022407474,-30.113229623120493,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark13(-67.50188885688493,-1.5707963267948948,-82.11135689101573,25.22920062973171 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark13(-67.5122610687838,-0.0574217119877873,-9.064038954948188,-0.9999999999999929 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark13(-67.55882010422404,-1.5707963267948948,-38.70475242267868,87.77085296005026 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark13(-67.57355078770857,-1.4065733927340183,-64.94593325882883,-1.0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark13(-67.60400427299115,-0.28772298131019136,-0.5222439734011388,-2346.0704778179856 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark13(-67.6107526847771,-1.395262658893978,-26.464485001976737,2.989274785496952 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark13(-67.6415718976894,-1.0100480445755968,-0.0813741564390921,-87.62761630117714 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark13(-67.66266378107116,-0.2833341623046429,-4.424984136347649,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark13(-67.67974029508119,-1.5707963267948963,-37.51468750254298,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark13(-67.72116280317145,-0.49223224268547994,-57.43872970013197,-0.015860770477341524 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark13(-67.72192951727021,-0.8305765846072792,-88.09610796579518,1.0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark13(-67.745325200774,-7.105427357601002E-15,-36.71865952662561,0.6418090213678197 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark13(-67.75074742383653,-3.552713678800501E-15,-1.5707963267949019,51.39993554914168 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark13(-67.80966713142786,-1.254202036375728,-11.479182074212417,0.022933795111303182 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark13(-6.7820427725323,-0.8518121094333927,-31.472664781885086,1.0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark13(-68.07237658256176,-5.15659166418739E-16,-13.388275723980314,-1.0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark13(-68.07308503639362,-1.5707963267948948,-1.5707963267948966,-0.36921843816795463 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark13(-68.09434101245779,-0.4950557446731285,-103.66791208179319,34.960090902676 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark13(-68.09931776475462,-0.05287819404170718,-11.068546340619623,-0.5418469206557652 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark13(-68.14239926061114,-0.025472436265108152,-44.23441798349029,0.002009555763180257 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark13(-68.1658452284487,-1.3564341456249327,-1.3600950158692373,1.0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark13(-68.1844825026761,-1.2109490304415742,-66.27343654586926,79.39279632292389 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark13(-6.840554058372392,-0.36866959935018534,-164.60892771571218,1.0084873610432423 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark13(-68.44621340295495,-3.552713678800501E-15,-74.4850032449021,63.486323542215324 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark13(-6.853120947975142,-0.09430884745268839,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark13(-68.78619128164149,-0.3963931847672,-28.220467500930567,-1.0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark13(-68.82590199937113,-1.4491191406187858,-86.41187000727693,55.747610371701896 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark13(-68.91365004350627,-1.453102312963386,-36.68979908975951,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark13(-6.912230981181722,-0.8934723802649229,-31.6269809214605,1.0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark13(-69.14775287232723,-1.014197663353885,-28.020023910394627,-0.05223660005582076 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark13(-6.921137128480642,-1.165179894001207,-1.5707963267948966,0.7986965891608182 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark13(-69.22009534081782,-0.03955595614050017,-9.758886031158049,-7.724168997017205 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark13(-69.29820308426417,-0.1685557675541043,0.0,-0.19731813137238108 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark13(69.39565531999753,-26.891700797631387,20.104172419023826,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark13(-69.45918241493563,-1.5662813508814901,-26.843540778545105,0.6410440747602004 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark13(-69.49325461198846,-0.8891874133635487,-1.5628831971753667,1.0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark13(-69.50173287522128,-1.570796326794877,-33.49377707034299,-31.23671474249197 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark13(-6.970868823856689,-1.5707963267948912,-89.88877101130457,1.0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark13(-69.77974548374297,-0.15124325178020726,-13.505506557143079,0.42417169595844006 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark13(-69.8629611227695,-1.4514004005444883,-1.570796326794901,-0.3993309571857706 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark13(-69.86413169409204,-0.3820452771434333,-39.15397651686713,-47.44630080892478 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark13(-69.88476710668036,-0.5351492285246517,-82.42365968065997,-0.9947632905589356 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark13(-69.90837123306646,-1.5611898368962422,-1.5707963267948966,-65.36301669961689 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark13(-69.92204888272313,-0.7449000465536766,-0.2310245362930376,-0.039206965677632793 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark13(-69.93281556185445,-0.5169946967142809,-1.5707963267948963,48.79081525200837 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark13(-70.10008024284565,-0.5750966232558641,-4.819216844220307,-1.0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark13(-70.11510244093883,-0.4247993241164569,-1.5707963267948966,0.77955432961732 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark13(-70.17005534640256,-0.10770732480037792,0.0,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark13(-70.18957454177134,-1.5707963267948948,-71.3259835003564,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark13(-7.021493455837152,-0.835307015822222,-13.387113825593008,6.938893903907228E-18 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark13(-70.24650252394765,-0.17994928430445833,-95.31472471436683,-1.0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark13(-70.25128272184625,-0.8395987477952694,-0.15880384198876313,-1.0000000002001923 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark13(-7.032820428271492,-1.570796326794896,-72.51004964934245,-5.573824335175166 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark13(-70.45227130141505,-1.5707963267948912,-52.414060326485945,-49.38512097190173 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark13(-7.046491389236503,-0.08122553218050821,-11.617211621299134,2040.2935237672757 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark13(-70.48311577301091,-0.9916852469449954,-49.691319999615644,-40.58173694348015 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark13(-70.55309556921914,-0.2152019882719609,0.21644366725799558,-4.994838774941272 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark13(-70.67444457722769,-0.6431292206193377,0.0,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark13(-70.72562028670347,-0.0028951801267764936,-1.5707963267948966,-1.0300377509443037 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark13(-70.75635198059304,-1.1404562189210878,0.0,-0.7531900104781579 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark13(-70.76169434306989,-1.7763568394002505E-15,-67.0026935893965,-89.43893999320343 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark13(-70.80472973387313,-0.5782391498764733,-84.94830072879573,0.0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark13(-70.84829282430083,-4.6071123002438895E-7,1.8580910752576808E-5,-0.5247322506172653 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark13(-70.86586907268469,-1.4512604013935544,-31.42674990849632,0.6583731544959033 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark13(-70.97645943848082,-1.5397628635589957,-1.5707963267948983,23.115776065606333 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark13(-71.06903731839095,-1.5707963267948912,-144.69910972687364,-0.6117765026414181 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark13(-71.09577997016268,-1.2811664250718275,-0.431901202336073,24.20106118935413 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark13(-71.15250575379994,-0.8152345082249399,-4.572722862986382,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark13(-71.29273199170616,-1.0499648891485727,-72.6350677469566,-23.333618365446455 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark13(-71.33015281241389,-1.075077361066751,0.0,0.3667100629828619 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark13(-71.37083539029753,-0.011322602727484452,-1.5707963267948966,0.33305847836008706 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark13(-7.137919619037761,-0.5653115413192982,-72.43952890198673,1.0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark13(-71.43648917646877,-1.3232550761350232,-85.53525367185033,-22.023638746978413 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark13(-71.44374056326487,-5.092188283176231E-16,-1.5707963232158981,1.0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark13(-71.55483500111683,-0.0762311719881601,-94.53873189467119,-1.0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark13(-71.74980569311201,-0.17824408112673273,-32.30311289312435,1.0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark13(-71.7514444792689,-0.021883199129779318,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark13(-71.82748176449189,-1.5707963267948948,-0.8749787325909564,0.0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark13(-71.98294778583104,-0.02458227418553205,1.2728862354971722,-1.0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark13(-72.09371076394348,-1.5707963267948912,-53.716292824936815,-61.5133177907311 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark13(-72.1391147437705,-1.570796326794893,1.5012664326029594,0.2270691154369577 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark13(-72.14052131171808,-0.5069351564042204,-27.85263072437775,1.0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark13(-72.1582285398085,-0.37313191326620293,-58.183418377742036,0.3899842832281535 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark13(-72.20141095301669,-1.5698747177003984,-31.07772824879782,31.165966147547167 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark13(-7.225432431588813,-0.48814396296504925,-7.3836796890212835,1.0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark13(-72.36240994389011,-0.9471464220052476,0.09409489177021158,0.0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark13(-72.38085160179543,-1.9086832843599193E-16,-45.479136774975046,46.85213096525388 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark13(-72.41656100778474,-1.2853822289094694,-50.02125405091713,-96.67992337637182 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark13(-72.54748635715993,-0.820798080617044,-4.440892098500626E-16,-0.2863881552033085 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark13(-72.75581491044889,-0.47687770627672066,0.0,-29.6264445391119 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark13(-72.80932457619296,-1.4599595547073512,-6.412613722251052,86.49494404040993 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark13(-72.81381258269354,-0.3613636521587804,-33.26306153343069,-80.13728303932525 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark13(-7.287054545667167,-1.4295388105976767,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark13(-72.87168486660913,-0.5064609998144399,-1.5707963267948966,-0.05912720648335561 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark13(-72.92632484852126,-0.19635078642908538,-1.5360189244473206,1.0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark13(-72.94497669770037,-1.4521169148115542,-94.10190910193334,1.0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark13(-72.98146370335475,-0.2412897813573948,-0.3078665381225627,-1.0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark13(-72.98587995520327,-0.12280330874676276,-4.1087803939725145,-0.9998451486199234 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark13(-72.99092780085454,-1.241308054893977,-58.00494097747557,86.91717513475784 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark13(-73.08422290347734,-1.0170880021425432,-62.69656256305191,0.5113924991241285 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark13(-73.09115427053541,-0.19130508785186184,-66.45231170737077,-0.06266640759418174 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark13(-73.22333587085937,-0.39422587774886475,-162.58542546669744,-1961.1676622006464 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark13(-7.323584711919997,-1.5265894330963476,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark13(-73.27507237104753,-0.752301613686849,1.5707963267948912,64.64647245403336 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark13(-73.30072681950327,-0.5088225958225835,-1.5707963267948966,-13.437876991681652 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark13(-73.55722149570514,-1.5530107310355135,-120.49325091005949,30.907994496567795 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark13(-73.5932037491166,-0.6777877234300864,-31.485061701257948,-1.0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark13(73.60731300101008,-84.33855214321574,-53.95426012276976,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark13(-73.62411119893423,-1.5707963267948948,-30.32956372620987,0.7662988672340019 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark13(-73.65553966364988,-0.10639305283382026,-1.5707963267948966,-0.9725520850269544 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark13(-73.66320252080136,-1.1968224209407055,-64.9006498940021,2232.145745054333 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark13(-7.368752418153908,-0.26230538980442475,-15.323504844857919,-1.0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark13(-7.370304288777577,-0.13086287666098867,-35.31822764665731,-0.348877582052717 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark13(-73.74548736496602,-1.3905081221670126,-66.08173978944811,1.0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark13(-73.80617590982283,-1.5707963267948877,-61.717138400292335,1.1698234493523643 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark13(-73.87921433856917,-0.5963112843005071,-4.425457375069472,1.0000000881878328 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark13(-73.95481112571976,-1.3368018182012802,-15.75615813287176,0.6001966386706765 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark13(-73.96169994353932,-2.220446049250313E-16,-61.149543852885266,0.0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark13(-7.403067432818534,-1.3632151605349474,-100.0,0.39375914219221864 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark13(-74.1361303814951,-1.7763568394002505E-15,-1.5707963267948812,2124.817157757495 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark13(-74.17092243977001,-0.4589556663940826,-66.29461011118164,30.687973767489602 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark13(-74.18294314546573,-0.8886068176655276,0.0,-1.0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark13(-74.18514394462814,-0.5776076646556636,-41.44975686764481,1.0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark13(-7.421138171683078,-0.10407564498143032,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark13(-74.21772216835978,-1.5707963267948912,-4.7201739534616,23.31008493323624 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark13(-74.33437499576257,-0.1390414654207064,-77.70424355912904,18.016641658118544 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark13(-74.3616354352204,-1.5707963267948912,-67.38657488151989,-0.3488212256794867 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark13(-74.39497656483867,-1.5571354155321349,-54.78669060970107,0.9999999999999991 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark13(-7.460278160333168,-1.5707963267948963,-1.0431364059866812,-56.6007788618347 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark13(-74.62443002898263,-1.1123787671945309,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark13(-7.463340261135496,-1.4099121867430906,-35.91988811908452,0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark13(-74.67578597316682,-1.0927117673075077,-38.48566684018437,1.0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark13(-74.85885584227398,-1.5652079005745743,-38.73523896986947,-0.9768498578689535 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark13(-74.95737464103624,-0.29861523119484623,-54.51996024644603,-1.0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark13(-7.496226478204812,-1.356390446123099,-92.33381631848623,1.0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark13(-75.03918665775808,-0.4696657592544544,-57.81336010109759,-0.9999999999999957 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark13(-75.07895419489321,-1.5707963267948912,-20.645240881386144,-97.24243289769112 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark13(-75.08460965450224,-0.8322090716704935,-1.1921744326944155,-0.06258959763136437 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark13(-75.18147426585566,-1.5707963267948912,-61.04965788486318,1.0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark13(-7.526296362363238,-1.5707963267948957,-0.08109508401292753,-3.6648919635740933 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark13(-75.2854760719062,-1.5707963267948957,-8.391961761880367,0.768526328825694 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark13(-75.35248903812298,-0.6087940223856743,-49.201207941428756,0.0015185689318404803 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark13(-7.5600022749589435,-0.49054301884270424,-67.78603918176498,83.54264151790264 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark13(-75.69533437591312,-0.6561413996977463,-56.494095703891325,-1.0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark13(-75.71057076270776,-0.764022528944934,-43.887539773677155,-0.5265578807675184 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark13(-75.89009336349224,-0.5824855137132507,-50.998495887517045,91.57648083657782 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark13(-76.00518905506712,-1.5707963267948957,-88.21878566989426,-0.547998839454686 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark13(-76.03424490276672,-1.5707963267948948,-33.56637218081621,-0.04543216018569249 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark13(-76.28381571585044,-1.5707963267948948,-0.6060854065828281,-1.0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark13(-76.31968705934725,-1.118011789634274,-79.73357213930564,-1.000000000000007 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark13(-76.35271311767225,-0.650001221861729,-1.5707963267948983,0.6865745753331366 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark13(-76.37520338399402,-1.5707963267948963,-1.5707963267948966,-12.282854887182037 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark13(-76.41885637612413,-0.019000645727816276,-14.145751669670538,-1.0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark13(-76.45482403767276,-1.5707963267948912,-40.55863226327663,-0.8695830860120091 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark13(-7.669297546666217,-1.5312180822340886,-29.95606829220408,-1.0000000000000002 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark13(-76.72411895253731,-1.5707963267948912,-71.76307097763,-22.66653163552934 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark13(-76.78285378400025,-1.5707963267948926,1.033884321740609,-1.0000000000000018 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark13(-76.86679677824999,-1.5707963267948912,-78.49513648926205,-1.6062115015590623E-8 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark13(-76.8957463072814,-1.4981281120703063,-76.36087755470989,27.889990839375784 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark13(-77.06693793070522,-1.3903590923976767,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark13(-77.07452104852631,-1.5542652121689355,-0.5694306909194756,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark13(-77.14088222163322,-0.1361685353198332,0.0,5.421010862427522E-20 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark13(-77.27683653290848,-0.165144324620627,-63.510555554039094,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark13(-77.35161205239787,-0.8702099644779082,-26.044127950676092,18.668906328581798 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark13(-77.36562007436746,-1.1592929985977936,1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark13(-77.36652708272466,-0.07841052679920178,-31.785047117369174,-39.522089542464855 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark13(-77.381068628374,-0.32082682342665797,-100.0,-1.0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark13(-77.55156739109535,-0.686826091599909,-0.9588900574925823,-56.205025713376315 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark13(-7.757179508701849,-1.5707963267948961,2431.3614814225225,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark13(-77.71261650595581,-0.17783126525898083,0.0,-1.0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark13(-77.72257818973671,-0.47105065110466793,-68.46289530705998,55.64621424194965 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark13(-77.89932704738322,-1.5176253712614223,-38.94370472086705,-0.8890888284065741 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark13(-78.11450605726743,-2.220446049250313E-16,0.6563640093420355,-1.0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark13(-78.1963143749744,-1.5707963267948948,-77.43850689535907,0.63221124745352 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark13(-78.20653906539057,-0.7513478209180722,-33.879421957356385,0.062499377091560754 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark13(-78.40287273964663,-0.47285186296550585,0.0,23.55826204054626 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark13(-78.50434762972944,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark13(-78.5549459338295,-1.3917482472487854,-1.5707963267948912,-16.14253240316023 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark13(-78.63423161712657,-0.4214177736001119,-88.23392927837857,-83.36112335922259 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark13(-78.66393236263337,-0.15434826796845152,-14.429469397714058,0.0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark13(-78.81069251409818,-0.6108876470445601,-11.083650378381401,1.8991135491519597E-65 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark13(-7.890045532174312,-1.2215553362228064,-22.13435662355926,-85.70046856769575 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark13(-78.96207777775555,-1.1102230246251565E-16,-0.2500004377536698,-1.0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark13(-7.9019275879623105,-1.398134679087435,-75.13540789238176,1.0000012273808683 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark13(-7.902457697123566,-1.1820628832237348,-42.06979817177419,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark13(-79.04861574573576,-1.5707963267948948,2486.919113882353,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark13(-79.05895755954779,-1.5707963267948202,-66.42560463382058,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark13(-7.919121053167888,-1.4035411294749038,-11.983263838870158,-1.0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark13(-79.24156320262226,-1.2472801575588248,2.6645352591003757E-15,-1.0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark13(-79.36974381099296,-3.816465962707244E-5,0.0,0.761322713017871 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark13(-79.49567438839377,-1.5230103242925859,-66.69095037629904,18.870881571075955 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark13(-79.49932564411235,-1.3877787807814457E-17,-16.069983322692877,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark13(-79.56815656551242,-1.5707963267948912,0.0,-24.25790904026313 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark13(-79.60203970570225,-0.2425307264643622,-2.7325063613927076,0.0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark13(-79.69394294241994,-1.2490004104005739,-3.5000738894944448,0.0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark13(-79.70622955504307,-0.20640863491070305,-1.5707963267948966,74.37693328543554 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark13(-79.72907559705057,-1.5707963267948948,1.5707963267948961,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark13(-79.82664953626082,-0.348096093605605,-61.055838963394706,-75.77254599602033 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark13(-79.84434379930974,-0.4558883035529577,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark13(-79.90248334654511,-0.6634846826571346,-6.182861980922098,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark13(-80.03084558961679,-1.5707963267948912,-1.5707963267948961,1.3234889800848443E-23 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark13(-80.0410906332215,-1.5491401444121915,-91.9445504654556,54.221357943893 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark13(-8.005980634901261,-0.3269861867581205,-66.0348297331301,48.841872634529764 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark13(-8.011617061907303,-0.12814017603056005,-12.478297577986188,9.705415485444817 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark13(-80.1176433477855,-0.7576129015373846,-21.961729016274415,-1.0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark13(-80.19399445131695,-0.9482275028520527,-39.29462705223957,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark13(-80.20621947146876,-0.5442830033936313,-64.9353997982132,-0.5189991745609528 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark13(-80.5377065959034,-0.07363214361116377,-62.05204549611008,-26.215527245104248 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark13(-80.55624941657855,-1.5707963267948957,-73.26812815163811,0.4349612660856022 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark13(-80.64370688860471,-0.35476196451351344,-1.5707963267948966,-0.6274253271244308 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark13(-80.73978988721976,-0.4373149660630935,0.20915724117126358,-49.94581641019927 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark13(-80.78312974369364,-0.01672632546477899,-10.560386710929208,0.5873922430954361 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark13(-80.82250976402699,-0.9696524731447054,-74.94890347481807,-99.44389338928734 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark13(-8.086315783590988,-1.559729387422881,-1.5707963267948966,-87.5849412773323 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark13(-80.87415674603733,-1.519010691104142,-1.455140563438331,90.63865098952968 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark13(-80.97293402073852,-0.829900206220381,-23.14121803232922,0.9999999999999999 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark13(-80.97523965746427,-1.570796326794734,-23.904380397341967,0.9472094574567849 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark13(-80.9806150124486,-1.3054686577488086,-70.17706370894336,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark13(-81.14142826573759,-0.20968125700139284,-82.5733449504171,1.0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark13(-81.17033754717986,-1.2017245064260358,0.12006008810375601,-69.35644237467491 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark13(-81.20269163784779,-1.5707963267948957,-42.42261930196683,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark13(-81.40305015991697,-0.04191124877078556,1.4873548011191897,0.0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark13(-81.4632543142832,-0.13394164396964925,-18.62988696983679,-67.16247039379505 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark13(-8.147429380714598,-0.7506788739454524,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark13(-8.147877394721707,-1.54180081738341,-10.437264204672077,6.6174449004242214E-24 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark13(-81.51660878218955,-1.5707963267948963,0.0,-1.0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark13(8.151812738137192,-0.7803842014187021,0,0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark13(-81.5195775504964,-3.552713678800501E-15,-50.0417407390073,-1.0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark13(-81.55548163007427,-2.220446049250313E-16,0.1664542467213349,1.0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark13(-81.67054089427113,-0.9834529339340818,-86.18096658504336,1.0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark13(-81.71679648465452,-0.6192848356195295,-62.74969331735458,-0.011505412661800312 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark13(-81.71977681441307,-1.002628894913741,-64.14075212434325,50.53547484227738 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark13(-81.74987373995926,-0.018823733821783567,-0.058334623272941144,-1.0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark13(-81.78171767785919,-1.5390341734904422,-62.09312313841846,-0.9259254178695552 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark13(-81.89069273735771,-0.004653825067884598,-65.05430862084273,-0.5725398370599621 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark13(-81.95449414371589,-1.5707963267916405,-17.31647739640964,1.0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark13(-82.18197239478397,-0.4091445856316973,-2.8036347148838985,-87.63360188487069 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark13(-82.30747450869362,-0.7104757660568946,1.0489619831004036,-52.845820352358416 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark13(-82.33300018789089,-7.105427357601002E-15,-9.549152832798221,-100.0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark13(-82.59820249962117,-0.3870878445659768,-1.5707963267948966,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark13(-82.62972237691284,-0.21716999678900487,-83.53748428449698,-2.5737787947340145E-85 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark13(-82.64125868086165,-1.5707963267948963,-61.7670377907319,1.0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark13(-83.00879082689511,-1.570796326794895,0.0,-1.0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark13(-83.02727221675714,-0.5610449236475707,-32.65549673181707,54.8773514250272 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark13(-83.03059058078186,-3.944304526105059E-31,-14.525664228737277,1.0000191203225515 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark13(-83.0350801531901,-0.2634447674481456,-9.232209445781065,-0.9587213705441916 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark13(-83.0789449564809,-1.5707963267948521,-1.5707963267948966,-32.532581462410135 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark13(-83.13886062362153,-1.5707963267948912,-84.78706102148317,-1.0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark13(-83.19283016534668,-1.5707963267948906,-73.29858561626097,1.0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark13(-8.32049910546666,-1.1974745645240812,-45.32698780761677,9.273015376718553E-69 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark13(-83.2221855407474,-0.01127613855833694,-66.47402923846393,9.344295054564325 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark13(-83.38065671389286,-0.5214042181132754,-44.24416147731607,-9.515429617296817 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark13(-83.50216234922972,-1.150624784119851,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark13(-83.53505126527332,-1.5707963267948948,-8.986478605482164,-0.4144320737988869 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark13(-83.5441056435534,-1.3139623822151283,-58.373025491544574,-0.9999999999999999 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark13(-83.5923152093881,-0.780431325603365,-27.868270880728417,1.6854041278012135E-5 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark13(-83.95856826004629,-1.319381294833793,-103.2508769568621,-0.7191184857876227 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark13(84.07183286169314,-93.69275166874323,0,0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark13(-84.07548240262648,-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark13(-8.413333766646328,-1.565431113649297,-1.2155132215372353,0.0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark13(-84.17582075328238,-0.793904938606962,-1.0841092506661045,-30.86788605866397 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark13(-84.18988636559307,-1.5707963267948912,-31.027730188565442,-0.9986603704161251 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark13(-84.2239929330397,-0.021083663155893384,0.4867188292404373,0.023071124345778942 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark13(-84.35029505948305,-0.06986868564625429,-44.15586178686565,-1.0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark13(-8.443751144597275,-1.5707963267948948,-1.5707963267948966,6.938893903907228E-18 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark13(-84.53432552719931,-1.566868459198015,-44.71609707332111,1.000001856213736 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark13(-84.576108082246,-0.25045052371202225,-12.959686236709256,-1.0001533173213633 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark13(-8.457733959567948,-1.0237445347825176,-13.692247866074883,-0.9992236117143644 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark13(-84.69616130460908,-1.5678039851157675,-31.530857910349884,0.9739693634243416 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark13(-84.69758693180277,-0.8547291451322018,0.0,-0.9999999999999998 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark13(-84.72586471749186,-0.025539080644938032,0.0,1.0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark13(-84.82834651921708,-1.1852343302513897,-0.0592501987091968,-1.5672438017110384 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark13(-85.0052629608561,-0.42833560957642813,-88.18636376335812,-65.79979382415078 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark13(-8.50303183898545,-1.3096588677819367,-8.24975572963481,1.0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark13(-85.0421530892117,-0.08264744843275196,-10.638792701732157,-100.0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark13(-85.21972980324146,-0.7521516000198102,-51.651352729482696,-0.024610522269732704 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark13(-85.32519522187332,-1.4338069199021306,-61.3415877213902,0.0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark13(-85.35706788624705,-0.1941658290172751,-1.3314886696271941,0.13225276342089454 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark13(-85.36449614872187,-0.14872261877664505,0.016174157580546272,-99.13311090027592 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark13(-85.38384428818249,-1.5005211404719887,-45.29337009733098,1.0000000000000142 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark13(-85.41769356357275,-0.10560456004855692,-100.0,-4.251566512902872E-7 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark13(-85.63626405139998,-0.6848763125409913,-10.866179047666009,86.80228553932002 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark13(-85.66080924716867,-0.017194599333089554,-1.5707963267948966,1.0000000252289902 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark13(-85.67674657741956,-1.4283677666380696,-164.50946105694888,1.0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark13(-85.93714825603602,-0.025308490523656135,-3.1153492349459437,-57.77826027740127 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark13(-85.94810099700506,-1.4399962661977541,-66.25778171033106,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark13(-86.02125114927446,-0.4750299283874895,-82.56102672685,0.0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark13(-86.02867715761268,-0.0015174058971996196,-80.03461377596813,1.0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark13(-86.09063373057258,-1.542610174656731,0.0,0.24613186455195923 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark13(-8.609445895909744,-1.141462019247423,-69.29263837442153,91.44755920460912 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark13(-86.10273782137368,-1.570796326794896,1.0501051037777171E-14,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark13(-86.16597671255225,-1.5707963267948963,-1.5707963267948952,-0.9198083539763364 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark13(-86.42067283068984,-0.20917237659058094,-0.016835731983464768,0.020386240224293417 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark13(-8.648454667766066,-1.1995006275246825,1.5493632766924863,-1.0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark13(-86.63193934422502,-0.20455845498572067,-18.642980212745627,-1.0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark13(-86.68246547333952,-5.551115123125783E-17,-20.39439671307332,0.0031138722333149405 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark13(-86.68660150070201,-1.2893835334866013,-94.20266786672522,-0.4417044301348163 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark13(-86.77089489361134,-1.570796326794894,0,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark13(-86.78658604735874,-1.0183334339298682,0.0,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark13(-86.85408605346029,-0.5784824828900195,-6.485234839315661,0.7453135543094762 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark13(-8.693060527955003,-0.4881607509280886,0.0,1.0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark13(-87.21475229851318,-1.5189721372658127,-43.27770422172089,-1.0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark13(-87.2258583451984,-1.5707963267948912,-4.257667626400604,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark13(-8.724021541021067,-0.010504721813177659,-65.49380700295399,0.46364526320522537 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark13(-87.24828498479235,-0.25182581541905336,-21.001028946703755,-1.0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark13(-8.727980261216493,-1.5383095521095986,0.8161179872245907,-50.77206748024493 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark13(-87.31086966112953,-1.5707963267948963,-61.53011244685198,1.0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark13(-87.31162789688865,-0.8275027380671022,-100.0,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark13(-87.32523395789462,-0.26579660290207024,-95.51644079356294,89.8139336830491 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark13(-87.3445965500006,-0.025464951679401382,-1.5707896041065073,58.59269241815251 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark13(-8.755723755138206,-1.5707963267948912,-0.3715186816770881,61.97078769733259 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark13(-87.56383903427151,-0.3531314161413377,-120.74806610008478,1.0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark13(-87.6317597486278,-1.3438042258341596,0.0,1.0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark13(-87.70260266549631,-1.3547647006188976,-7.638562309116679,0.4413542543581688 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark13(-87.7993139878109,-1.344929171489206,-0.8478540027749482,-27.923185554555804 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark13(-87.952043587362,-1.0414145778864279,-9.889788463463479,20.689685539109895 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark13(-8.79892429026274,-1.2901993008370543,-42.86940555124137,0.7513898569058217 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark13(-88.00309814780377,-1.0546771246116196,-14.236014105439644,-1.0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark13(-88.01753037358269,-1.1679242090656101,-1.5707963267948966,50.01247597895224 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark13(-88.0260153470999,-0.0010376037023734667,-1.5707963267948888,0.18400094071191408 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark13(-88.02613999597573,-0.30812398089811605,0.0,0.09992047271723781 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark13(-88.06714167378689,-1.4148461178024412,-89.56169878615951,0.70377902400215 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark13(-88.09540432820506,-1.4578218890422048,-83.17880638532998,-4.5082903407156913E-131 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark13(-88.11431645797856,-1.5707963267948912,-91.10888938926462,0.9999999999999991 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark13(-88.13368855471009,-1.5707963267948963,-2.4704699775190696E-15,-82.38851796822553 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark13(-88.14942133210734,-1.437048966516796,-48.09128811341962,51.09319758105799 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark13(-88.20732896412554,-0.18022102302260287,-1.5707963267948963,-1.0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark13(-88.23458383070829,-0.012668786681507394,0.0,-12.30249502351461 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark13(-88.34273215838151,-0.01729664569110234,-67.44125214148848,-1.0245888271588253 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark13(-88.4180732341824,-0.8304607474018395,-8.241034066525856,-0.9999999999999997 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark13(-88.42740667094711,-0.3494547805096788,-66.6625526987406,-85.66218855292382 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark13(-88.48904617145219,-0.2128966172471093,-13.622787924377514,-1.0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark13(-8.855944565089246,-0.8892517702501951,-14.689703562871372,1.0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark13(-88.80503048386583,-3.552713678800501E-15,-1.5707963267948961,0.16281387593155383 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark13(-88.87808316647126,-1.5671804083436234,-97.35775766805372,61.5496320600231 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark13(-88.95532005934393,-0.12640268279322556,1.278344818313106,-0.9999999999999991 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark13(-88.97251497158096,-3.552713678800501E-15,-1.2951121425549843,69.07851381498905 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark13(-88.99425011792044,-1.57079632679487,0.0,-0.01951744124489707 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark13(-89.03112085527121,-0.6038685690248828,-31.91001162315274,-0.527543914066579 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark13(-89.09233684805929,-1.5405097318787735,-55.461357868139864,-0.06255311463366957 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark13(-8.911817872824127,-0.8566520545962721,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark13(-89.29691587421391,-0.3118083389368249,-100.0,2147.6053712191724 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark13(-89.36592278687698,-0.6004801311146792,-28.28618363324381,1.0587911840678754E-22 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark13(-89.42037568680372,-1.3386922872345406,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark13(-89.4258570354527,-0.38001397249741475,-15.576319916788828,-1.0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark13(-89.58653268162612,-1.536975004649804,-68.35349084151568,2218.830777731554 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark13(-8.96158102117257,-0.06239184353118277,-83.45016669393019,16.28507564885573 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark13(-89.62409637291739,-0.07405622642705764,-4.372486143097959,0.5183894417980759 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark13(-89.84623306439104,-2.220446049250313E-16,0.9220269702645912,-1916.2590665816433 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark13(-89.89423129787949,-1.1861125542333735,-28.27199988526662,0.7961195948205457 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark13(-90.42712865669604,-0.01332529550768244,-35.430015403582786,0.06162255034973722 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark13(-90.46080083888988,-1.461367795085928,-1.5707963267948963,0.05344353254622375 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark13(-90.51083050868888,-0.2879383058969117,-100.0,-1.0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark13(-90.51908671511359,-0.7360003842853658,-98.67275574883342,1.0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark13(-90.54486248973794,-1.5707963267948948,-99.81074988934002,-10.961639591204033 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark13(-90.66663147145199,-1.570796326794893,0,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark13(-90.8910976299597,-0.4636805963932463,-74.50455579749627,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark13(-91.01066133495853,-0.8427011681204373,-36.31865786235215,0.06255336588042007 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark13(-91.07541760951082,-1.5707963267948948,0.0,0.05502162812479183 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark13(-91.1937126498845,-1.558099506705112,-57.68353975413976,-0.061464885283633336 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark13(-91.24566683803064,-0.8097163652206465,1.469193229342841,-1.0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark13(-91.24739522891082,-1.481594527266111,-8.052843003296706,-0.9558336456045083 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark13(-91.40553242438106,-4.440892098500626E-16,-0.6755213868859897,3.1392356960044445 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark13(-9.168487306077541,-0.16568177063586753,-100.0,1.0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark13(-92.05437955563735,-1.1234478710470341,-92.24444587753766,86.2959349765438 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark13(-92.1589708410661,-8.881784197001252E-16,-41.792230523978326,-0.9582434963745868 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark13(-9.228494778981833,-0.15628518513936948,-46.36475161934682,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark13(-92.43465169066889,-0.42391413025455904,-163.5899623367052,95.99252611251424 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark13(-92.46932808292134,-2.220446049250313E-16,-80.1909633009869,27.518308460820272 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark13(-9.26844732263446,-6.929691261491243E-16,-1.829722561921173,2241.33314383404 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark13(-92.70523334897914,-0.6491940660981781,-136.44582975456177,0.5152871443192196 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark13(-9.272453223286002,-1.7763568394002505E-15,-1.5707963267948983,0.05061843274100719 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark13(-92.84781163873362,-0.308180492105147,-82.17519577069383,-0.7001937908546143 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark13(-93.25191782080624,-0.4303927743007324,-73.35391381573113,0.9999999999999982 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark13(-93.58152227858062,-1.2795509432551029,1.7763568394002505E-15,0.791805685461128 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark13(-93.59036032713242,-1.5707963267948912,-56.31834476450068,17.425712091659662 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark13(-9.367762239600756,-0.9754867340496383,-46.908859335204625,1.0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark13(-93.75947393627811,-0.4634930069872554,0.0,1.0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark13(-93.84137659809429,-1.5707963267948912,-45.215902766513544,0.27849288634020297 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark13(-93.89917025654317,26.072822140218648,-97.55476790965378,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark13(-93.9072119238148,-1.3189644023790175,-16.632804620196666,0.8900800027147987 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark13(-94.08996421995958,-0.8801825750380947,-1.5707963267948966,49.37856397547594 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark13(-94.24143529624946,-0.8364443542275531,-2.213316151506227,29.361340597835124 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark13(-94.41885031094739,-1.1388286059017014,-1.5707963267948966,0.15855287962196707 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark13(-94.4839452320045,-2.990525016141818E-4,-1.5707963267948966,-0.7258215933977531 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark13(-9.464966276440933,-0.49296837180746167,-81.70018426665462,-1.0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark13(-94.71155195309835,-1.1834346384307313,-99.87103284310797,0.99807841122138 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark13(-94.7249427928879,-1.5707963267948912,-30.97593537969452,-1.0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark13(-94.73305158860397,-0.9541672108126178,0.0,7.6283746434253175 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark13(-94.7430162439678,-1.9721522630525295E-31,-31.464929588013362,0.25702252410591975 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark13(-94.77378070584922,-0.02364135966681126,-0.973147132571015,1.0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark13(-94.87156227623846,-1.403427433965674,-32.86202471072393,-0.6090032166996879 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark13(-95.15736998918699,-0.20306920752485513,-1.5707963267948966,-52.71179405475503 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark13(-95.19940857373797,-0.13725335308750558,-11.164687858095306,-22.48943502844007 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark13(-9.527872672585076,-1.7763568394002505E-15,0.0,-99.99279760271774 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark13(-95.49130616054353,-0.14673450734941434,-1.5707963267949125,-1.0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark13(-95.53684280873496,-0.030415767975941588,-41.939876953779965,3.706962612570692 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark13(-9.555429436016528,-0.022053633952374554,-1.3595546016520004,1.0000000874484407 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark13(-95.72673749609719,-0.6759545182212516,0.0,0.04348517872470836 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark13(-95.77397482153225,-0.07827531303134541,-1.5707963267948957,-0.8963161124648821 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark13(-95.81076643199691,-0.13808384822463046,0.0,4.811390458491076 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark13(-95.86748177319599,-1.5080590620625514,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark13(-9.587789865595818,-0.5031013972059071,-78.9642226533472,-1.000026520140419 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark13(-95.92440041950252,-1.0205636131369435,-8.053151609615445E-6,1.0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark13(-96.0467162215038,-0.8551454107677532,-0.8720624407864349,0.0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark13(-96.06099813759002,-2.220446049250313E-16,-54.346042166846274,0.9999999999999967 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark13(-96.0767284137855,-1.299407020694076,-31.502026319392904,70.44673054694883 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark13(-96.20569963765324,-0.43515734476672296,-69.98245621052355,97.43956659084756 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark13(-96.21863049376421,-0.9854289891521599,-65.34153384492006,-1.0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark13(-96.2885909405492,-6.776263578034403E-21,-1.5536593843558297,3.3087224502121107E-24 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark13(-96.44336442246794,-0.20901065123244078,-9.896923115375998,29.097478389244714 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark13(-96.50217513215236,-0.3150144168522927,-159.78756823913565,-1.0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark13(-9.655645272523275,-0.7623826915139315,-82.49466058590664,-23.33661277001434 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark13(-96.56044655682716,-0.5712489098709078,-28.92154398084198,-88.87769807139105 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark13(-96.61543449331309,-2.9290953396399042E-244,0,0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark13(-96.62893477767754,-1.2777815951401985,-0.6960797911495514,32.460051256925496 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark13(-96.64322090220325,-1.5707963267948961,-1.5707963267949054,-1.0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark13(-9.66846956424925,-0.8822519337963581,-31.779070125182272,9.613227290388975 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark13(-96.72913399946734,-0.6117649110580389,0.0,-1.0 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark13(-96.81653750999614,-0.231066244114495,-1.042500410070614,1.0000073777896799 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark13(-96.84342304645034,-1.5087128731746768,-72.59532246014427,2118.6767818443022 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark13(-96.97860834624035,-1.502307191970116,-12.195717666146663,1.0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark13(-9.704274331385779,-1.2617076995487482,0.0,1.0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark13(-97.0819021740874,-0.8479226155150278,0.0,1.000099772440995 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark13(-97.09961318109723,-2.220446049250313E-16,-0.9315590861829168,53.41367157098997 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark13(-97.1565951971711,-1.5707963267948948,0.0,1.0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark13(-97.18204577586579,-0.003315848116433786,-0.7998651790380436,-29.990460221039477 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark13(-97.19057085825207,-0.8606354839877626,-92.93371916226596,-18.92911896340506 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark13(-97.2202641892714,-7.105427357601002E-15,-38.956033629112085,12.08763143991554 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark13(-97.27530394572528,-1.5707963267948948,-32.93783224187155,-0.03612881499311893 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark13(-97.2823578057177,-1.4636463752920772,-1.5707963267948963,0.7626325423882343 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark13(-9.737321882414975,-1.5707963267948957,-72.37660780183731,0.8399263267455739 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark13(-9.752575593849002,-1.5707963267948912,-82.4124432276386,1.0000001126186095 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark13(-97.6332965663306,-0.3406155185570867,-53.810947813459386,-116.33449423473891 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark13(-97.80686432391185,-1.1493377273357757,-67.11324871919822,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark13(-97.81007223114177,-0.7098135386526687,0.0,-1.0000000000000002 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark13(-97.87795958499936,-1.5707963267948961,-0.6522348788209078,-0.07230860200307998 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark13(-9.789430881215083,-0.9122754452117621,-58.77982917417373,12.495051081520558 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark13(-97.94464722751584,-0.8770371808647304,-39.29843605096611,1.8991135491519597E-65 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark13(-97.94776178936714,-0.003132291156806133,-15.056956023489235,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark13(-98.00834692458533,-3.007509318012769E-14,-1.5707963267948966,0.8814617129417321 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark13(-98.06617195416194,-1.565333450877683,-65.31078402349269,-0.9955752007181254 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark13(-98.084780250994,-0.21461865829840712,-7.1542433420412985,-1.0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark13(-98.29706023445826,-1.2679477562500123,-67.38745317540882,0.3354871788333763 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark13(-9.831210215907488,-7.105427357601002E-15,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark13(-98.37219107299772,-1.5707963267948963,-1.5707963267948983,-25.6489399628875 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark13(-98.59854511089199,-1.232876414194243,-40.68052653371345,0.06106554030140382 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark13(-9.878800887797821,-0.9201304899640775,-71.2120889061266,-0.8971767482752092 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark13(-99.02070246740794,-1.5707963267948912,-19.365216443297456,-2297.3560087105016 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark13(-99.17707037060585,-0.9259366535644551,-1.5707963267948983,-0.9480620581325071 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark13(-99.42214248534098,-0.021660774510277075,0.7763814138692169,-1.0000000000000004 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark13(-99.44017599074463,-0.804259790207881,-40.88649456672086,-2204.0765540147077 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark13(-99.4762968229775,-0.36124032587788296,-15.516177531857863,41.46712884745668 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark13(-99.49149021623646,-1.2821525066528763,-31.912276844713432,-6.192032180255907 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark13(-99.51534279449167,-0.27706213756440834,-14.431107908656145,1.0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark13(-99.58504169491995,-0.8055883048540471,-1.5707963267948961,0.06255279572775695 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark13(-99.63628147514603,-1.1399047469610506,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark13(-99.73191913181206,-0.4400767211202092,-100.0,-0.5467837275273884 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark13(-99.73913960134347,-0.8375925148350504,-39.19968900896515,0.045826370127978855 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark13(-99.86006957637747,-0.49423920709369,-12.215032189914467,-0.9999999999999998 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark13(-99.87483133173474,-0.45222381077141094,-130.12492034779504,-48.833992417656155 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark13(-99.88433480807294,-1.2890660636108098,-99.34123396117631,1.0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark13(-99.89715194190573,-0.008519399666753113,-32.767721163197095,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark13(-9.990879391367997,-1.214363626326243,-52.86351936028731,-1.0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark13(-99.97660077320992,-1.5707963267948912,-88.20851509920074,0.8282031572240542 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark13(-99.99710740842644,-1.566885312847701,-31.926565658922115,-0.05866331050948614 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark13(-99.9994312658721,-1.5707963267948912,14.432669736472072,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark13(-99.99984835748737,-1.5277259226071125,-29.265247338584373,5.421010862427522E-20 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark13(-99.99999999999999,-0.09424509009412049,-1.5707963267948966,4.4647944971963866E-103 ) ;
  }
}
