import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,0.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,0.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-40.0254202671336 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark47(100.0,100.0,-40.191406247663146 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-40.19140624998756 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-100.0,-40.19140624998999 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-40.19140625 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-709.4385678749313 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-709.6114560660085 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-709.8505816208609 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,728.1600379675145 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-745.9999999999999 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-746.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-100.0,-775.431922875294 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,779.746455382204 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark47(100.0,100.0,-80.38253860970927 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-100.0,-80.3828125 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-10.373537528167475,-709.0583841049774 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-26.46716558066538,0.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark47(-100.0407453641004,100.0,-746.0000000000608 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark47(100.0,55.86537512342073,-745.5950247924 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark47(100.0,631.3225568127294,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-646.0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,82.156163749538,-758.656077275885 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-99.99999999999986,-709.3701704921365 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark47(-109.20873335896316,-630.8226333054039,-100.0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark47(-10.948721988465522,10.948721988465522,-709.8679276369128 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark47(-109.88660728610151,82.47577612649057,-746.0042403360129 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark47(-11.503371592477052,50.17982162756306,72.14405168324018 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark47(-11.776989421763176,-82.03379307136436,-22.03714086723822 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark47(-126.99181999444342,-622.2689996091763,-709.6123374344235 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark47(-129.39721852527364,-618.8821828056905,-735.7083783023954 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark47(-131.23319636206864,-578.4851493851304,-759.843475536573 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark47(-13.155624568517581,89.99263098886766,-709.5752847799785 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark47(-132.62471378851143,-577.0286259695824,-745.7096537173885 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark47(-13.382022365063184,-6.4521208493027995,0.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark47(13.422481234143817,-53.18765196916855,-717.0890070599825 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark47(13.851206568448376,10.43552700200965,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark47(-144.27235675189922,-565.7274581547845,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark47(-14.784811043446155,-2.022230773877453,-745.7177221353639 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark47(-14.927440852199808,97.04061633953768,-95.38664963730068 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark47(-149.99691846525454,-608.3816845153638,-745.5401815435002 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark47(-152.19350868191685,-593.8064913557647,-100.0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark47(-152.4958596588534,-603.3042625517324,29.04179599134676 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark47(-15.27064966462089,-40.862284771622704,-746.0000000019426 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark47(-152.73206865955834,-593.2679312516403,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark47(-159.21198415128964,-586.7880158487104,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark47(-16.07400125856502,80.57177736359219,-709.6928649624124 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark47(16.247380993738545,29.010946779402843,-769.3562710104807 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark47(-162.93813689374585,-583.0618631062541,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark47(-163.05807837447682,-546.7532859098775,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark47(-169.47686223435164,-662.1184436258031,-709.1540298471602 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark47(-174.01228067073785,-535.0172154288942,-745.9888068173127 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark47(17.991625254500136,7.196886953517904,-745.9999999991047 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark47(18.168201069406933,-17.427458351338785,0.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark47(-183.16719488647686,-558.1474656577576,-760.604467169807 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark47(18.326329910005185,61.84976144220798,62.633504152359336 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark47(-188.92058603186462,-596.2647448743668,-711.6258989419534 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark47(-191.26305419905276,-617.4545363926907,-4.410548279736261 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark47(-193.22723696829274,-516.7439450388854,851.2810617068444 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark47(-196.28978802975672,-549.7102119702433,-1.4941590449997966 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark47(-199.13906625658652,-557.3777941092127,-744.044479261128 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark47(-199.41776835944782,-546.5822316405522,-0.6387464836620121 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark47(-200.33848593621192,-569.4278274788013,-7.099647489880385E-15 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark47(204.20346265972498,540.3246846372929,47.21285250956319 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark47(-209.9422248236984,-537.7717418017837,-744.2666870418855 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark47(-21.317099489857256,63.7788066349822,-1.494140625 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark47(216.93345901229264,531.5872712762621,100.0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark47(22.048344934400134,95.32099937233195,-707.9143261580712 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark47(-22.66098753692522,88.17508660065968,-24.178351830935412 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark47(-22.73981472338658,22.73981472338658,-1.494140625 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark47(-22.922590199300473,67.49926693489891,-726.865526781254 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark47(22.99036522524871,99.98726560151533,-80.3828125 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark47(-23.419966538769117,98.97185977787782,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark47(-234.95675349782763,-529.4749392438708,-745.9999999991102 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark47(-237.56989442068232,-511.4984995329022,-81.58610181052933 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark47(-238.23733549842927,-471.1561291913531,-736.4331061373276 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark47(-238.8910123302727,-479.58150248897175,-810.6408682084572 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark47(-239.52078690432978,-470.47921268666187,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark47(-241.56107140074784,-468.25117617723805,88.35464553052196 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark47(242.39368026835405,482.10483118350453,-739.3087532317624 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark47(-242.6736008643807,-485.9272058829597,-779.581524092612 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark47(-245.22896926099213,-464.13304387294875,-813.182149328525 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark47(24.6484713058164,-46.85193505910365,-69.96115898167163 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark47(-246.50169765758267,-582.2469793755693,-744.6233036357288 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark47(24.906208305191086,-9.35218370833526,99.25157235882506 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark47(-251.26001872505623,-457.7924593683272,-742.3786804867409 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark47(-251.37102243254895,-464.3785983225227,770.0704504513792 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark47(25.93810066922333,-17.318649022019386,-65.44620916605504 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark47(26.0569460719357,-42.303359455437196,-747.690422406263 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark47(-260.69693338939663,-480.88151148666356,21.082614469925787 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark47(-26.329900924707303,-15.64585391364453,-739.0426586015791 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark47(-268.1577583224207,-531.1476697008699,-709.3457620750518 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark47(-270.0118195932691,-503.1676734705345,-709.2927581101503 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark47(-271.3159006364902,-446.3920232542959,-12.50341892525067 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark47(-273.2616375695104,-442.05152225204216,-63.80931029178352 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark47(-277.4053058617806,-431.9421417167244,-728.7288817253307 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark47(-278.40598867583526,-431.0814568487671,85.21330880130634 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark47(-278.8852436900468,-473.723951520049,-40.19140625 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark47(-279.56889401170787,-430.7433410778756,0.0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark47(-279.9744407499808,-429.7937413392799,-748.2485786442892 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark47(-281.5834689813488,-487.4576645708476,-1.4941406250000056 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark47(-282.710385729868,-426.76395787364714,-745.9999999999997 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark47(-282.72978163515876,-461.3873502894818,-1.276886986457276 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark47(-283.69665171050826,-431.76972389168833,-756.499760280993 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark47(-285.23998857415825,-424.4496762455189,1.3038024216392884E-15 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark47(285.2888936660447,446.2004416148588,-721.7409767598668 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark47(-286.618485126935,-424.6796911535984,-62.402280811765664 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark47(-286.75186958441276,-455.46058469532466,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark47(-2.8709807279969795,37.88239356326798,-718.7733601256348 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark47(28.748836408498192,-42.774372529814976,-40.19140625 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark47(-291.63303409583506,-454.36696590415534,717.2628854156729 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark47(-292.28232169398643,-453.7176783056578,78.70581043178868 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark47(-292.7095828120012,-459.2669340660967,-737.2696134757678 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark47(-293.34765214380286,-446.30836477263347,-709.6322416721645 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark47(-295.2178644889202,-512.94450835626,-709.6769713941684 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark47(-295.3385090766668,-413.7184268338361,-40.19140625 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark47(-295.4013515333416,-457.31956047826105,-83.37109375 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark47(-297.52124825259284,-452.15741319171804,-708.0653962478957 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark47(-29.814955643590466,45.82465255740871,-745.3217452521178 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark47(30.07611215121524,-31.57025277621524,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark47(304.25049066364636,429.27898884134834,-40.19140625 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark47(-306.1616872802422,-403.5227291450618,-97.08180977770964 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark47(-309.5422077923847,-436.45779220748955,-94.49018860049097 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark47(31.023086922802833,3.6070814013254875,26.70652397338617 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark47(-312.3877212573719,-412.3273881173435,-100.0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark47(-312.676015107304,-433.32398489269605,27.63673328990464 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark47(-314.5115671328854,-457.0263852891735,-709.7757785159262 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark47(-316.1404845790443,-430.00230071050424,4.81273553746604 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark47(-318.72649288619925,-390.98919789128564,-100.0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark47(-319.18534205078424,-394.21833030689623,-709.8810568241718 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark47(-319.42471386694655,-426.57528613328793,-709.5255236540572 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark47(-319.6363235458677,-447.61038117656966,-709.3295921279299 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark47(-31.98338271397955,-67.76210309143993,-39.616931948995784 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark47(-321.7917962930604,-479.52853230742033,-709.5830541496833 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark47(-323.26241814401715,-422.7375530955683,-803.221356476692 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark47(-328.6659324629629,-417.33406753703713,-40.45282928706897 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark47(-331.5840789777093,-378.40883914455674,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark47(331.6728024080593,416.78315634847195,-719.2233274824039 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark47(-333.0047081295994,-509.7654445405625,-85.6762860950888 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark47(-333.43395268287907,-376.16937195812835,86.45642687985142 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark47(-333.7363127003067,-393.4938580122272,-708.3051605475505 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark47(333.94482870240756,414.79988399824674,766.0743528062819 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark47(-33.412901009391135,99.83835881619177,-73.9584873736841 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark47(33.41808857004344,45.13479084054492,-731.1097649009447 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark47(-334.7290241450683,-399.5905601474386,-709.8641935602295 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark47(33.51270513041254,-36.75010834346704,0.0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark47(-337.2725492735187,-425.0842347337882,-709.6498929249353 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark47(-337.3239786684493,-372.22107397122244,12.603097876947672 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark47(-337.63443641174456,-371.5038603439133,-725.9507817857528 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark47(-337.70165020043095,-372.02868857113765,-100.0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark47(-338.4966993416101,-412.1548469127394,-40.02125618240443 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark47(338.7441538714328,416.99697849973563,-28.80451087665847 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark47(-339.22770830259003,-484.25280878930295,-83.10484392818415 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark47(-340.12067292984574,-369.6590370265251,-745.9981096211086 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark47(-342.45329166851826,-422.1850851344078,-716.8651563570525 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark47(347.4524248988529,404.57588296481856,-734.1942402585789 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark47(-348.9492212665336,-472.76664475803597,-708.6632031034234 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark47(-3.5202035633673745,40.12888530859007,-709.5851660726382 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark47(353.87897454315925,417.21993562709173,-711.7990111147078 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark47(-354.80219864022934,-397.09462506594883,-708.2355329718936 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark47(-355.09556038145314,-380.14668611615775,23.928690479818854 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark47(-355.6398287221056,-353.6745111905146,-735.5212828203275 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark47(35.596586606118336,-35.596586606118336,0.0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark47(-356.00574139457296,-371.58829643589087,-2.4796116829166394E-15 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark47(-361.83911866139636,-388.6035525857071,-1.1301326596842869 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark47(-362.4249313615346,-387.1030077101745,-709.4131349434235 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark47(-364.12582073799604,-381.8741792603048,-717.3778580295485 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark47(364.37370264843594,389.7639348248806,-783.729992013966 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark47(-366.57479090740105,-347.9525335475485,57.55084651152945 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark47(366.5997349647915,372.7024745975854,1.2856833361302432E-12 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark47(-368.5442035667974,-374.1453884235629,-713.5186381235042 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark47(-370.29625289661305,-376.3284279298582,-75.42238288994032 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark47(-370.496881283081,-338.84152253215063,-734.4125690600705 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark47(37.075508857092046,33.64410080057695,-93.69178444687003 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark47(-372.1529969892447,-373.8470030097981,-745.9991262264339 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark47(-372.297833048327,-358.1009592767731,-729.9994878351994 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark47(-374.4114474821679,-419.6840258856253,-100.0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark47(-376.57804373763,-378.82370627826145,-41.50242843166167 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark47(37.68013389243802,67.81713982981134,-746.0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark47(-376.86766331349116,-334.56372822483456,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark47(-37.69423024891181,-38.22015396473108,71.65891230998074 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark47(-37.76737188451686,-60.51458157137297,-745.787044721418 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark47(379.1075195782513,339.3111615805618,-100.0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark47(38.20608418305957,-51.799252651227846,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark47(-384.23793860721014,-327.9031022905905,0.0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark47(-387.280670599196,-358.719329400804,-47.73740269782578 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark47(-387.32712652889336,-357.95261713447434,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark47(3.8753615570091284,-3.8753615570091284,55.648700061914255 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark47(-387.8159818303828,-358.18401816961716,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark47(-38.85539663081581,-7.744510126969601,-90.56599588193824 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark47(390.08321927898686,347.0819069499722,-83.68806616866149 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark47(-395.99917277161904,-350.00082722838096,-100.0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark47(-398.3067645162331,-311.02216050842554,715.4273325362107 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark47(399.71956189871577,400.79787806596073,-727.6979012836415 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark47(-402.46287301209156,-421.9337540879296,0.0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark47(-403.4386748269305,-408.7882557216887,-82.00012257087924 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark47(-404.196115690678,-451.0094595485704,-707.237649316711 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark47(40.47624036394089,-33.75958467920444,-746.0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark47(-40.54500567302961,58.84945068408942,-93.41730664132997 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark47(-40.65769058848452,45.802748692587414,-716.4742706655697 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark47(-407.36300837879804,-304.4952868813113,-709.8328343798128 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark47(-409.64203673804036,-322.10841904183235,-741.8886984332438 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark47(-411.19631653062794,-320.3527222223533,-40.19140625 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark47(-41.13855246075919,-96.54734168618941,62.70388991397786 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark47(-41.16624120915982,-20.106359656825873,0.0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark47(-413.0101554550983,-383.3593212885012,-708.0130869717691 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark47(413.385057368607,302.7275586861286,-4.989062533999984 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark47(413.7955364138094,354.9536853252647,-708.7637470863373 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark47(41.39371401506483,8.228550887702085,-93.61171777186988 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark47(-414.88534880388374,-306.89668043803954,-745.9153437121915 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark47(41.50506252322923,-100.0,-746.0005524737211 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark47(-415.09739166823414,-294.0147593130906,-14.779624321669084 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark47(-415.5216725370641,-296.596161379791,-732.8537698055547 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark47(-41.81713279326931,-1.8562061398866376,-39.510033860424286 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark47(-418.2104863491277,-327.7895136509441,2.4356416283027176E-8 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark47(-418.9060610375497,-291.0911615807316,-745.7275143838121 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark47(421.1984032340704,328.75315828848096,-100.0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark47(421.369154476861,332.0802905699405,-40.04805119943735 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark47(-423.7393660692955,-349.18860335251713,-709.8965699910342 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark47(425.395745951095,310.03452051927337,0.0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark47(-42.559658842171544,-703.4403411578285,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark47(-427.3120265488936,-281.986383528814,-100.0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark47(42.760486500707316,39.60420191776005,-746.0014453429442 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark47(42.81250979625298,-83.00391604625298,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark47(-429.80775803852384,-377.24078074110184,-709.6960313190557 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark47(-43.14734239292466,43.14734239292466,-722.541525308127 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark47(-432.59393404902664,-277.1882231899516,-65.45098298331658 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark47(-432.67702649207706,-278.5764643916738,0.0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark47(-433.1462383857698,-402.70784491477974,-9.235438164315915E-7 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark47(43.48445387026675,-14.78595144202697,-712.6970590510227 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark47(-437.7522963946429,-281.12505737183403,-3.609805677815398E-16 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark47(-43.85481503882826,-4.20077066339223,6.938893903907228E-18 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark47(-442.21368654058466,-300.84766426648036,-726.8130454333992 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark47(-442.4091515385356,-266.9566031019126,50.62692606188912 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark47(44.32809664588761,-44.32809664588761,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark47(-445.5331030536916,-314.9721776495698,-745.9765244051972 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark47(-448.90794416313224,-296.2471253596393,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark47(-450.7836178415621,-258.7783060529158,-775.104010671316 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark47(-451.72671938744963,-264.32127197311206,95.48524560624745 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark47(452.02313697270256,302.4599807001224,-745.9863661109653 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark47(-452.30590683034677,-401.62067473195816,-709.1328445265976 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark47(-455.3582780908434,-292.3735960144142,-717.6204879854045 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark47(-45.53908858874702,-30.720125860228947,-66.94704327924379 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark47(458.13547196709294,254.6072919502518,-745.9999999999973 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark47(-460.97255758125914,-276.0283652541384,-745.8357557652691 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark47(46.18243649222097,-9.687923046445746,-746.0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark47(-463.82737423918263,-248.79126370644914,-746.0000096985274 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark47(-469.5791520831655,-247.96174845345524,-715.9356995111982 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark47(4.697646909018363,-4.697646909017143,-817.6684922403625 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark47(-47.01581521389378,65.20944849424738,0.0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark47(-472.73345882022005,-273.26654117977995,58.33278715652264 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark47(47.32874082162431,-72.01387652809467,0.0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark47(-47.401184134213224,47.401184134389716,-709.4563821235533 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark47(-477.3564443917981,-268.97876912261955,-737.3905660357369 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark47(-477.41596151586623,-340.6297878474812,-759.9688425773021 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark47(-479.68063591981047,-252.75262923995473,0.0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark47(-48.10107776850163,-11.381763821127606,756.5521089782623 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark47(-481.8986802558178,-233.04987224389382,726.5248585712555 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark47(-483.5628187147614,-262.43718128523864,-47.78671611969774 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark47(-48.575220014818825,48.575220014818825,-97.02504971175466 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark47(48.76390606145657,40.92460011108335,-717.4801483679217 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark47(493.21594382516747,231.92407546516694,-745.2421485535027 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark47(-493.4770612057656,-262.8060122794047,-709.1110407565876 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark47(-493.691489186607,-222.628079795276,-1.494140625 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark47(495.36943026442276,305.9002936617007,-743.7018090948991 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark47(-495.6252723273306,-232.435393995121,-78.23483636030942 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark47(-495.6940120901873,-250.30598790981267,-91.40414057187103 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark47(50.79029541557668,40.877807088526794,-99.85853116306158 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark47(508.8386870472847,233.38387803923663,100.0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark47(-509.82223316875576,-237.032700965953,23.285557216873116 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark47(-517.0136813669607,-280.8516682324789,-745.1006644554465 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark47(-519.6996575999859,-195.2752009340105,-40.098116626178964 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark47(-52.38911153097578,-94.99840210346878,6.388771045076425 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark47(-524.0181233440563,-201.79151685632002,-745.3091672980607 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark47(-52.45758250668145,36.6166597850692,-749.1914797737638 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark47(-525.827693841615,-183.344030199685,-39.53041541053891 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark47(-52.61681043721283,5.638718535272574,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark47(-528.4405822577172,-180.679719099308,-711.2882988994726 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark47(-52.87327481680779,-60.77657654629256,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark47(530.5218363141321,192.4078763309837,0.0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark47(-538.2468095862827,-224.6014108871898,711.1919486544234 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark47(-540.9170352890842,-294.7473581847768,-100.0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark47(-543.0877859478595,-166.45465245869696,0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark47(54.36081155418435,1.3463019257484348,-733.2038828083926 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark47(-543.7001853639424,-199.2612225984707,-100.0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark47(-552.8762501981696,-193.12374980183063,78.7613132206352 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark47(55.43259910801993,39.85448437782517,-77.72632622793552 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark47(-558.2152390814972,-204.23426843066636,-709.9765894300585 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark47(-560.9440728361029,-187.2473334139645,0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark47(56.24285961407432,-34.642405567124726,-746.0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark47(-564.7712173363822,-145.02838703150536,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark47(-56.57371830058893,56.57371830058893,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark47(-5.670757167463506,-74.1720950528396,-745.5980877573401 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark47(56.76428254120347,39.32420926841792,-40.19140625 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark47(-569.1622292096548,-143.74163040553623,-745.5359246453296 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark47(5.703619227018365,-42.468271106479484,-738.7450967624287 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark47(57.08418118863253,-51.69452907701633,-46.4809945108956 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark47(-57.161815224356545,57.16181522435655,-719.6358076335989 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark47(-574.4350079956989,-135.4733153248505,-80.43145828579281 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark47(-579.1473962041172,-159.0598912679917,-716.0231823145511 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark47(-582.378474501734,-126.64295058987808,-708.0769413914406 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark47(58.427746785349,-43.123062180626405,-41.04379689656075 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark47(58.47755224592433,-58.4775522459235,-709.841285991084 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark47(-585.3157069086785,-123.94113987074496,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark47(-59.16122111065141,-22.525900607729227,-76.84418636635881 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark47(-59.27617024659466,-19.698244827617017,-728.6001314088323 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark47(-5.9646408407415095,67.38493964769668,49.95499953072874 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark47(-60.07888254922496,60.07888254922642,-745.4484341113016 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark47(-60.47439889486235,60.47439889486235,-49.32635625388573 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark47(6.0644258078658595,-17.377073967820934,-46.325695123095414 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark47(-607.1129586918156,-117.9191095427197,-712.5320873856012 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark47(-60.887641500362655,60.887641500362655,-1.1196055420355915 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark47(613.5184669685588,98.2439990237564,-745.9691736030998 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark47(61.42423042289428,86.18626446525619,-708.3816628269985 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark47(-614.2740264417504,-199.37818322378672,-84.38228164944661 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark47(-61.54468151029083,-724.716857132915,-41.685546874999936 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark47(-61.70048485664219,-74.52961960916961,-730.2798542428187 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark47(-621.3621575284122,-124.63784247158776,-64.72529637046526 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark47(62.142147362420076,42.20802238426501,-746.0001668258487 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark47(-62.31723772039519,-31.477118625518102,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark47(62.558989898043706,-18.679136134689685,-749.5074647541801 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark47(-625.8130011832825,-159.41288955702942,78.62074016231978 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark47(-629.2603828035019,-137.01822363848768,-709.8521697302965 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark47(-632.5435166684163,-100.0,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark47(-636.3848175345483,-109.61518246552075,-161.5717953383598 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark47(63.76775132146685,51.93608291617085,-0.8015599893544305 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark47(-638.0993544722631,-90.89898377793475,33.004081048437286 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark47(63.925141399920506,-35.224899234524415,-746.0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark47(-645.6559606933174,-100.0,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark47(-646.7617531393715,-99.23824686357572,168.48727558352022 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark47(64.9609959969963,40.11278155645928,-709.1104656256264 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark47(-650.6409164063605,-59.154794869320064,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark47(-65.22461285062826,55.65205245584556,-749.316343106096 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark47(65.24728489043807,62.24934617411324,83.78643320042914 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark47(-653.8065468341492,-55.30314514950595,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark47(66.2166757243088,-37.537017845316825,17.220910957177864 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark47(-662.9545694666343,-107.41433333324343,-709.8385380714419 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark47(-66.47617793464269,-84.29451237938596,39.34755812343292 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark47(66.9646581681477,-66.9646581681477,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark47(67.09947682318068,-98.53132720216723,-746.0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark47(-673.4072659806964,-72.59273401930533,-0.01699635949873146 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark47(-674.3588596451405,-40.76471226196687,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark47(-67.73589219102135,27.581756161116047,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark47(-67.76291395707449,77.00559299946302,-41.685546875 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark47(683.5575017501262,139.89107940578327,-4.936825504715029E-13 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark47(68.38622596210797,-54.87516070434539,-40.19140625 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark47(68.54957673617707,85.20252662149863,-708.4077345674073 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark47(-69.39636388924771,139.54873882137144,-745.6894831172812 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark47(-71.50242030049333,-78.63461667826037,-11.30971377619457 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark47(71.96752392611327,-58.68705388626277,-749.1915044716518 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark47(-72.28476459099645,45.254178398045184,22.826214791682673 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark47(-72.37528728909454,72.37528728909454,-24.047935869391708 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark47(72.72002561247874,-31.769395269429523,-40.19140624999999 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark47(-728.2422036331868,-28.689466945699422,45.88748721069123 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark47(-7.290765083311371,41.636601529855255,68.59712078131935 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark47(-73.26548210497262,-672.7345178950274,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark47(-733.0207202182725,-78.75976870258872,-73.9127161369585 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark47(-733.8303967782491,-64.20617688288932,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark47(-73.90706093944767,50.96532669516506,-746.0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark47(-74.2635134518114,163.51703028810022,-822.1460594940181 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark47(-75.30897539917905,-670.8824308508251,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark47(76.08010171451042,-76.08010171451042,-93.35800494925097 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark47(-76.90816679127602,-30.46646944093763,-740.8802000922736 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark47(-77.04007262253576,-62.23907040701431,70.85946683927406 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark47(78.00168560800977,52.60337511259098,-746.0071610866474 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark47(78.40328021268121,-74.41628487996124,-745.2604478810645 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark47(-78.45607291095548,29.553036243345844,-12.14037103979257 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark47(79.16565926239146,100.0,0.0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark47(-81.23718255082785,14.140271260934071,-94.20529691727818 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark47(-81.48608393731823,-34.147580969654314,93.13893096380065 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark47(-83.35189850143661,-88.46231808333778,76.41376803126002 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark47(83.89787847025255,-29.448168988452323,-746.0052695392475 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark47(-8.412004791417743,79.5642335012486,-706.8651668867258 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark47(84.6372315572109,67.09468115570905,0.0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark47(85.07350368828708,-64.88769757269763,0.0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark47(-85.18291138048693,57.67303256116327,-731.0127714869908 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark47(85.24381765986402,-8.472522793482213,-55.24763542662481 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark47(-85.41834710388724,9.797437194034828,-745.9999817496014 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark47(85.48406485289796,-100.0,-80.38281249987672 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark47(85.71508023036105,20.198372798698514,-728.7294023221667 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark47(-86.04705680604758,-659.95294319409,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark47(8.60510935146182,-8.60510935146182,-709.105152761606 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark47(-86.1226015739927,-623.3308919022841,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark47(86.14455101640021,67.60800082757413,-801.6162796364983 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark47(86.2296911585918,29.531581210560574,68.56939469083176 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark47(-86.42035451965083,-623.489919394594,-725.5536891256523 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark47(88.10371462512416,-88.10371462512416,-32.19429323302512 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark47(-88.43277117358674,88.43277117358674,-41.351320584308155 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark47(90.40127598402975,-34.20128870173794,713.989594791995 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark47(-90.58131739608905,27.122577775938183,-708.7090760870253 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark47(-91.20802464740412,51.016618397404116,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark47(-91.43286657902428,90.1353072758709,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark47(-91.98304894575075,60.73211215867448,-742.863718853886 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark47(-92.69520634514205,74.3606498540388,-744.8109406731139 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark47(-92.79171688644362,-653.2082831135565,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark47(-9.350780932576356,9.350780932576356,-41.685546875 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark47(-93.68468201583764,-119.52559561134186,-709.9191442154887 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark47(-94.02307824931275,-651.9769217506871,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark47(9.466716961317939,-9.466716961327009,-709.0860529228556 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark47(95.24111241751223,95.99093432596857,0.0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark47(9.535404530824394,43.76429377120422,-6.475449131967963 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark47(-9.557546490722842,67.70385662437374,735.8720412574897 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark47(-96.11887623910698,-22.949391067922846,-40.19140625 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark47(-96.22909843047384,-46.46203181591753,-55.7346392219618 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark47(96.31610254655232,59.01999267154835,-98.30801689531879 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark47(96.76521764811221,67.97520248342087,-1.4941406249999998 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark47(-97.29694604898489,57.1055397989849,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark47(-97.51505018446409,-4.016442536449631,714.9235826145429 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark47(-99.14768935531403,100.0,-745.9999999999998 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark47(99.99859258706601,-100.0,-746.0 ) ;
  }
}
