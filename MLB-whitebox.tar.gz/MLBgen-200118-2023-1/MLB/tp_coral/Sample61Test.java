import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,12.598207298513373 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,29.073481216395493 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(0.3883331375958732,-2.7425471117961737E-49,100.0,-97.58250057618656 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(0.5519391195208023,-3.0385816786431356E-64,99.70619227990686,-80.40143827025278 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-1.4836824602749686E-67,26.8990255823588,-99.99999999999645 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-1.6472184286297693E-83,100.0,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(100.0,1.8055593228630336E-35,-32.20660970136796,57.78006967809773 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(100.0,2.507721281754171E-37,-100.0,-100.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(100.0,2.6727647100921956E-51,-100.0,-100.0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(100.0,3.1587301655876523E-176,-50.19062266034437,100.0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(100.0,5.934729841099874E-67,-100.0,100.0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-5.934729841099874E-67,53.77513151439487,-15.789520306781863 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-6.588873714519077E-83,100.0,-52.160866621227484 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-9.00412455520088E-6,100.0,-100.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(12.283350642171783,-95.22442197478958,74.2248926392956,-0.12899370127364773 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(13.934535670438912,4.3368086899420177E-19,-96.00915530338627,-100.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(15.108162226495736,55.69131744331247,83.5488848306604,8.64610141109219 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(15.960627867428329,43.001988014280556,11.1591192387787,18.417427759448927 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(1.8904805735531276,-2.967364920549937E-67,100.0,-91.82145118858958 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(19.093390194038506,38.46824184303679,52.44318085043108,72.5052386511743 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(19.366237048119856,47.068498754759986,-85.15893088096247,-54.50715815083977 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark61(19.961756603223414,-0.09815409156227746,80.13385233583432,-100.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark61(20.39101742643436,76.35236332069817,65.36505698026036,46.978315546902905 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark61(20.852600787646978,-21.317544254197742,28.194119189484372,-60.639886820317415 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark61(2.164493805142731,-8.433758354584419E-81,100.0,-87.47311660885408 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark61(22.073813062763435,5.801633295079142,90.17614428105364,93.0662623097254 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark61(22.323320065386262,-1.6472184286297693E-83,100.0,-99.99715168095919 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark61(25.134353933406306,-2.4728041004582808E-68,32.00807479913267,100.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark61(25.19996465521747,-3.3413884918946646E-5,86.2219384262885,82.95633001607686 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark61(27.653303498361865,10.432659785596314,-75.60214810998278,-62.418590404762675 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark61(30.22608123914759,-7.184663779652254,-11.41254333591668,-22.641700887472197 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark61(32.248404357139194,7.918749059525183E-34,-100.0,-100.0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark61(32.44788484853282,22.86670096734558,-84.84139269596196,-2.033160981423407 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark61(33.906859265674115,2.220446049250313E-16,-29.672041324096995,-71.20095829896536 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark61(36.277232894049156,-6.747006683667535E-80,23.029684870827953,-100.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark61(36.46408308269689,0.0,10.09660750175956,79.06023838978126 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark61(36.722397417649674,-1.7763568394002505E-15,45.303672877101114,59.83780206133338 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark61(3.6747193438307733,56.42816790830083,108.17030088041477,5.451951384275262 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark61(37.439805402167494,1.5249643061391824,-56.26701708612423,-45.656051187641424 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark61(39.282164886189776,-80.98456123791043,-94.68374461702128,-78.29953619234765 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark61(39.831813060894135,2.108439588645292E-81,-57.615135339779684,-54.53080691556653 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark61(40.83633406619313,-16.41978760523841,-89.84962448259037,-95.1336009877221 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark61(45.08179188991951,7.053617145115961,-19.487018442265825,71.62242747730129 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark61(47.335838487088346,2.1684043449710089E-19,-100.0,100.0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark61(53.30676580517457,-3.5597475871862353E-41,0.4988467927206733,-0.15003456784221625 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark61(55.34053838527039,-1.2868893973670072E-85,25.090292171828487,-100.0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark61(56.32497594200899,38.602780005693404,57.399396827834096,37.5283591198683 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark61(56.44629531731362,1.232595164407831E-32,-100.0,42.283411318343035 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark61(5.917004139299479,-2.5751945661908877,48.67639528142436,-19.893864337430017 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark61(60.11293957891566,-6.077163357286271E-64,30.85263754278773,2.6067441057587484 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark61(62.08115433113218,5.551115123125783E-17,-0.569767632762094,-66.20764652035618 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark61(65.90050802863618,-35.59480541609838,29.75572881750952,-92.64086368807882 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark61(67.93044776496889,-4.440892098500626E-16,70.61661873863274,-24.18285620281158 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark61(68.2843444055026,-56.995239254884545,18.397757861594428,86.29362439577159 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark61(70.47279777872563,2.620870373534686,-18.998874692221904,96.29510363659017 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark61(78.80621398828161,-2.7755575615628914E-17,99.99992442956137,-70.8025804570364 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark61(87.80396796240711,-24.27838251611705,86.94715791032382,-81.17057722453734 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark61(88.02528679907701,6.938893903907228E-18,-15.822051612406472,-100.0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark61(90.71949824125639,-64.6562675898671,69.14388978640514,37.94392242528738 ) ;
  }
}
