import org.junit.Test;

public class Sample30Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark30(-0.004502780933762551 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark30(-0.10616477634883381 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark30(-0.11025593031031633 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark30(-0.12582317619546757 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark30(-0.2714082497674184 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark30(-0.3233623399046479 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark30(-0.3893105991183319 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark30(-0.40906896985481467 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark30(-0.42904074168721706 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark30(-0.4511752656784864 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark30(-0.46402423902338796 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark30(-0.47008021609535433 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark30(-0.5495537346000674 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark30(-0.6773609176238722 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark30(-0.7689152145076577 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark30(-0.8008331317980435 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark30(-0.8649492431581365 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark30(-0.8743236354595894 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark30(-10.048954222207513 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark30(-10.069162668047909 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark30(-10.115613050847315 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark30(-10.119971580011565 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark30(-10.148601227391893 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark30(-10.163920904710963 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark30(-10.172726358571424 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark30(-10.179298181668457 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark30(-10.214950086874367 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark30(-10.248517128688434 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark30(-10.263165180093921 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark30(-10.268898915832409 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark30(-10.281867066433506 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark30(-10.330170892703649 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark30(-10.379388058425889 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark30(-10.394879718556098 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark30(-1.0402385495225985 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark30(-1.0412555383626483 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark30(-10.486870475306475 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark30(-10.489463691049664 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark30(-10.498076188216388 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark30(-10.520339508999726 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark30(-10.561282371163344 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark30(-10.620108335636445 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark30(-10.641352755395857 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark30(-10.696511314286127 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark30(-10.719776285937527 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark30(-10.726730911041287 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark30(-10.75465899618986 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark30(-10.769732305751049 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark30(-10.823135963481235 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark30(-10.836744738418318 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark30(-10.849458561558194 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark30(-10.852956038279132 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark30(-10.868607509696986 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark30(-10.91089518712758 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark30(-10.91762399917468 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark30(-10.924597751555012 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark30(-11.036183065784826 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark30(-11.053251425446533 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark30(-11.055194308730165 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark30(-11.076176922443096 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark30(-11.095533042878685 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark30(-1.113539231838672 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark30(-11.276941831290884 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark30(-11.385510791217214 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark30(-11.39398945075844 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark30(-11.432457946828151 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark30(-11.440584061849847 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark30(-11.552403477974622 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark30(-11.562922285134164 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark30(-11.570371973231275 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark30(-11.749992777038315 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark30(-1.1797543425992103 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark30(-11.808401216260904 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark30(-11.859323090387946 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark30(-11.876804614029695 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark30(-11.903347591157342 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark30(-1.190752857604238 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark30(-11.918242077708129 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark30(-1.2019495689019095 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark30(-12.0357819682892 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark30(-1.204458148860482 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark30(-12.081043170656443 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark30(-12.084749646469078 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark30(-12.097942328290202 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark30(-12.202210899567262 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark30(-12.220746851348864 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark30(-12.241480530030117 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark30(-12.301942421374363 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark30(-12.339851717894646 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark30(-1.2363223277596092 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark30(-12.409045507418341 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark30(-12.47760701302299 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark30(-12.584080036321438 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark30(-12.607784036798904 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark30(-12.616188277629774 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark30(-12.617119658241592 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark30(-12.624994720353186 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark30(-12.641909932552949 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark30(-12.666606646855342 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark30(-12.705188699767959 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark30(-12.7078711440803 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark30(-12.729546233880185 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark30(-12.742069549293404 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark30(-12.807584823482543 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark30(-12.82963436238451 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark30(-12.87643613279586 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark30(-12.893819375279875 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark30(-13.04269283309472 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark30(-13.077772610698617 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark30(-1.315503395573117 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark30(-13.186801685782498 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark30(-13.20553176655035 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark30(-13.206843871391811 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark30(-13.209255614990752 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark30(-13.29188187788779 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark30(-1.3301630450326627 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark30(-13.372899834894909 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark30(-13.373984555665231 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark30(-13.412113326236224 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark30(-13.454953949646693 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark30(-13.576517721535609 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark30(-13.630366790400643 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark30(-13.636103526098921 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark30(-13.660077343205998 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark30(-13.691779905430536 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark30(-13.744078132752023 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark30(-13.809266416275918 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark30(-13.816390016493358 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark30(-13.823855824705404 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark30(-1.3993875263937952 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark30(-14.02863035836097 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark30(-14.081808199358377 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark30(-1.4091582939402656 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark30(-14.09391464910361 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark30(-14.11898315704478 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark30(-14.234389023450461 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark30(-14.280895185288387 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark30(-14.299042881870093 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark30(-14.315052807927614 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark30(-14.328090416342604 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark30(-14.395984813147706 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark30(-14.401601086193367 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark30(-14.425546708201935 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark30(-14.436936539619268 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark30(-14.446893954692925 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark30(-14.462647918531204 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark30(-14.47418852476818 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark30(-14.571156705934413 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark30(-14.600727761584366 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark30(-14.625053546931667 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark30(-14.645093388634933 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark30(-14.773651409329318 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark30(-14.778574650015045 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark30(-14.815027480124428 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark30(-14.832805400565547 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark30(-14.85928948809891 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark30(-14.87244059815562 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark30(-14.875789929434774 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark30(-14.926628417602814 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark30(-14.928800987000528 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark30(-14.998165371622065 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark30(-15.033399572190092 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark30(-15.04121776668174 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark30(-15.056340691403818 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark30(-15.228830135049904 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark30(-15.245290523653594 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark30(-15.2477931226408 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark30(-15.25549308688447 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark30(-15.284875817394038 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark30(-15.297471476272378 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark30(-15.315308314448203 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark30(-15.351753585118914 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark30(-15.366497983355075 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark30(-15.388301027584731 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark30(-15.448909852585956 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark30(-15.521441915559393 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark30(-15.571215247511773 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark30(-15.646505939510803 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark30(-15.667105749676296 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark30(-15.742115136807612 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark30(-15.763876410423052 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark30(-15.774530207951614 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark30(-15.804523501400027 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark30(-15.81038419868284 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark30(-15.856411614499137 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark30(-15.85928451044343 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark30(-15.8825538652776 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark30(-15.883540189655406 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark30(-1.5885829373947047 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark30(-15.9064779680985 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark30(-15.916294883202426 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark30(-15.921052133460194 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark30(-15.975107196940613 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark30(-16.005558401681057 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark30(-16.055367553713907 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark30(-16.068281834626134 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark30(-16.11487304615858 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark30(-16.130191030528906 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark30(-16.157368413369937 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark30(-16.20095490142303 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark30(-16.203095807916768 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark30(-16.292446637177676 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark30(-16.318313739242768 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark30(-16.344017869075216 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark30(-16.357776432223574 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark30(-16.361639698226554 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark30(-16.458317279672215 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark30(-16.464332332758943 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark30(-16.509353081838583 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark30(-16.529417898035774 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark30(-16.53709099137093 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark30(-1.6541788402275586 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark30(-16.548757669005568 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark30(-16.551358685949722 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark30(-16.576972945488507 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark30(-16.605233320430997 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark30(-16.63641741921215 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark30(-1.6644782538160854 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark30(-16.688466483138484 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark30(-1.6697533932013897 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark30(-16.735436384185505 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark30(-1.675994952368768 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark30(-16.769295857358955 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark30(-16.786187678854517 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark30(-16.861659970734053 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark30(-16.86979654685726 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark30(-1.6875529947005532 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark30(-16.892272360252193 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark30(-16.953600418006417 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark30(-16.953816693541057 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark30(-17.03333327026479 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark30(-17.211988402496672 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark30(-1.722502760665236 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark30(-17.264587463205274 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark30(-17.273298910294827 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark30(-17.307621103029746 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark30(-1.7320460709525918 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark30(-1.7374124083263922 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark30(-1.7459705428100563 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark30(-17.4827177279753 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark30(-17.531402810866737 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark30(-17.53190833096076 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark30(-17.54507523441002 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark30(-17.573106029856447 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark30(-17.577227112498292 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark30(-17.625831134421915 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark30(-17.714160231873137 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark30(-17.740158829637423 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark30(-17.78484555416368 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark30(-1.7796001044119123 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark30(-17.83358334848286 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark30(-17.83383745916258 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark30(-1.7940418282583295 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark30(-17.95095673101146 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark30(-17.979679791802 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark30(-17.998747942278072 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark30(-18.006606363227746 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark30(-18.051367537341335 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark30(-1.807013296581502 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark30(-18.07288642596481 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark30(-18.161987203588765 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark30(-18.194618949316805 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark30(-18.202878283104965 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark30(-18.274250765504092 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark30(-18.36490550690246 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark30(-18.39763470512959 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark30(-1.8412127552961834 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark30(-18.51575385902086 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark30(-18.545581425224483 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark30(-18.601988329675052 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark30(-18.615001069338334 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark30(-18.66958466742865 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark30(-18.686203822426847 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark30(-1.8789352610104402 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark30(-18.80257930180906 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark30(-18.82828589253647 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark30(-18.847530257274926 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark30(-18.850176856190288 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark30(-18.85384948972704 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark30(-18.889219235864616 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark30(-18.8923452923151 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark30(-18.939691363925903 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark30(-1.8959775297195023 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark30(-18.96361085992592 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark30(-18.965617821976835 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark30(-18.990493889760444 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark30(-19.032192338046897 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark30(-19.067217755400833 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark30(-19.09906899143064 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark30(-19.102545432923264 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark30(-19.108081756801255 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark30(-19.172571494039346 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark30(-19.182663622759932 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark30(-19.18484685795198 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark30(-19.223123005792516 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark30(-19.241189905490018 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark30(-19.2657735001996 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark30(-19.310875212496526 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark30(-19.3152817285591 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark30(-19.3389773951603 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark30(-19.360044626082185 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark30(-19.474880717114402 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark30(-19.499190357730555 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark30(19.526728834419572 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark30(-19.554702197951016 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark30(-19.580898166182052 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark30(-19.581858006901086 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark30(-19.609433483229893 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark30(-19.61659303304853 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark30(-19.622018140342362 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark30(-19.646203061613704 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark30(-19.681988746167534 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark30(1.9721522630525295E-31 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark30(-19.74576851384124 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark30(-19.798268295126604 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark30(-19.8378515730615 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark30(-19.85177121033314 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark30(-1.9890339425060262 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark30(-19.935430178117272 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark30(-19.95586353847638 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark30(-19.985095826826992 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark30(-20.032595873842112 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark30(-2.004011371798569 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark30(-20.07171286562135 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark30(-20.079772870181415 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark30(-20.11921147603401 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark30(-20.13898711445576 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark30(-20.18109503632229 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark30(-20.198164027364584 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark30(-20.209079811191714 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark30(-20.31699795868363 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark30(-20.338037874240584 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark30(-20.36560625215462 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark30(-20.3709575107669 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark30(-20.39284769872654 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark30(-20.48376156353106 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark30(-2.0498511408316915 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark30(-20.514086883130346 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark30(-20.51693216834809 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark30(-20.5198293226226 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark30(-2.0633696656204847 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark30(-20.651737426584774 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark30(-20.658305435344417 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark30(-20.663095381212358 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark30(-20.672551416906586 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark30(-20.730864026508343 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark30(-20.772000716636626 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark30(-20.787317816343332 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark30(-20.789649522121252 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark30(-20.79141465415779 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark30(-20.800359750164787 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark30(-20.822881506088635 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark30(-20.839102700341698 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark30(-20.883853679946498 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark30(-20.96247541107479 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark30(-20.972330316393055 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark30(-20.97686300519561 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark30(-21.035086261795584 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark30(-21.096527590204303 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark30(-21.133181797553107 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark30(-21.142978618012066 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark30(-21.15021612012859 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark30(-21.189782022663437 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark30(-21.203086946243047 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark30(-21.223490395884554 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark30(-2.1237515539535963 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark30(-2.1254356155889838 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark30(-21.278031278498474 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark30(-21.54885113196015 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark30(-21.581872125268674 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark30(-21.63690830324248 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark30(-21.67391302090121 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark30(-21.695911768801608 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark30(-21.70447729925094 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark30(-21.716857503171454 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark30(-21.791988912955333 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark30(-21.830330961830498 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark30(-21.856115220420392 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark30(-22.014194594543184 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark30(-22.0867406873337 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark30(-22.118465268291843 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark30(-22.24347979964773 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark30(-22.26926340408761 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark30(-22.312867826652877 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark30(-22.342019573854486 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark30(-2.234613678370991 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark30(-2.235171206347445 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark30(-2.2431236299053694 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark30(-22.457971483244734 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark30(-22.466997078209843 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark30(-22.48174933092085 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark30(-22.49820902285633 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark30(-22.498548865826677 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark30(-22.557260384663252 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark30(-22.592084854964668 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark30(-22.688703773524892 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark30(-22.6934856084263 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark30(-22.737270929482207 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark30(-22.74550472115311 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark30(-22.75713579507861 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark30(-22.76225741287263 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark30(-22.825194527112075 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark30(-22.838957568842687 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark30(-22.955048938480374 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark30(-23.004866181781907 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark30(-23.032310888518225 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark30(-23.050341562749182 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark30(-23.063108381187945 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark30(-23.06740227958089 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark30(-23.075223716848782 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark30(-23.098358123796487 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark30(-23.15518087147727 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark30(-23.222986074548118 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark30(-23.243811704611645 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark30(-2.329006899412292 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark30(-23.33431500140783 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark30(-23.378990296201138 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark30(-23.40189842975792 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark30(-23.404209090032666 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark30(-23.42503051767477 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark30(-23.49004276415141 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark30(-23.558794036853897 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark30(-23.602120343184183 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark30(-23.61339900117325 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark30(-23.692866282910614 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark30(-23.70515485265325 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark30(-23.71307301664058 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark30(-2.372530620698157 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark30(-23.74708268015536 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark30(-23.772015643857273 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark30(-2.3781750420703816 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark30(-23.797615394147158 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark30(-23.8421002514813 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark30(-23.85055580868655 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark30(-23.89441901201819 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark30(-23.904845752214328 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark30(-23.93137977037172 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark30(-23.954064125124688 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark30(-23.996465338829466 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark30(-24.02901209622806 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark30(-24.064463429721016 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark30(-24.11368775593931 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark30(-24.117672716461954 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark30(-24.1662994279487 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark30(-24.194757105652727 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark30(-24.247467063114186 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark30(-24.258863813848237 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark30(-2.427521187392557 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark30(-24.28437709630829 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark30(-24.32855400023854 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark30(-24.394378812770086 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark30(-24.41280653569673 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark30(-24.46122535049659 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark30(-24.525768913476597 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark30(-24.546952237192656 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark30(-24.562993804958438 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark30(-24.5869479097516 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark30(-24.59116243571451 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark30(-24.59200379010518 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark30(-24.629209298937155 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark30(-24.63275059197501 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark30(-24.679434077192397 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark30(-24.685414441874016 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark30(-24.759397147425204 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark30(-24.7626609271842 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark30(-2.4764021421505475 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark30(-24.767825386156403 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark30(-24.876551862389178 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark30(-24.930190890224992 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark30(-24.967295465828343 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark30(-25.01214212315608 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark30(-25.044752646339674 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark30(-25.065974125474085 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark30(-2.5072650771786726 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark30(-25.08780865365094 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark30(-25.101915211976973 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark30(-25.11720839826721 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark30(-25.123566869670896 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark30(-2.5149744121958406 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark30(-25.19891833440151 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark30(-2.5212470986513864 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark30(-25.221111754697105 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark30(-25.286319722798936 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark30(-25.29097144158412 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark30(-25.33187957062715 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark30(-25.354010648653855 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark30(-25.45847699215018 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark30(-25.542129566765865 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark30(-25.557813559374992 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark30(-25.631715642140307 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark30(-25.67250359867697 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark30(-2.567795555229594 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark30(-25.788716192031515 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark30(-25.78918495148143 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark30(-25.808610655068563 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark30(-2.583022740735558 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark30(-25.857725074598164 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark30(-25.899212963347537 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark30(-26.014300933420813 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark30(-26.04676248295334 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark30(-26.089079371554675 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark30(-26.090091209017288 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark30(-26.196149070865175 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark30(-26.212301721560976 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark30(-26.256051045294697 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark30(-26.33654334454178 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark30(-26.36842469440262 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark30(-26.43886753698945 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark30(-26.53852119632245 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark30(-26.53880445160428 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark30(-26.56495115365051 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark30(-26.607457994065527 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark30(-26.69310088516987 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark30(-26.75023130599763 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark30(-26.75452024899083 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark30(-26.77092009946172 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark30(-26.771005399519353 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark30(-26.780274574457536 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark30(-26.787077331097947 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark30(-26.823827733168045 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark30(-26.82843575238067 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark30(-2.683043969637083 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark30(-26.88867045663632 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark30(-2.6919040862941586 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark30(-2.697802877136894 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark30(-26.99541268913623 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark30(-2.707823162491607 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark30(-27.0793002124706 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark30(-27.101881311398103 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark30(-27.165278918007346 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark30(-27.16838064207157 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark30(-27.173820885032924 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark30(-27.184029617627047 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark30(-27.2613703169434 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark30(-27.290913381889936 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark30(-27.374012489010923 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark30(-27.393330231288246 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark30(-27.48973598682427 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark30(-27.54457453918586 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark30(-27.595742961809748 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark30(-27.601823152344892 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark30(-27.65687951446651 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark30(-27.660912944502414 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark30(-27.748686609509377 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark30(-27.813076585281536 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark30(-27.857035306328044 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark30(-27.863673345734156 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark30(-27.896953591847293 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark30(-27.940064701794512 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark30(-27.946464086466193 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark30(-27.981622071521798 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark30(-27.996213906855232 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark30(-28.0105091603089 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark30(-28.02574715374415 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark30(-28.034821522107876 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark30(-28.091577844144112 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark30(-28.120097951788622 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark30(-28.131406707234092 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark30(-28.15016679815237 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark30(-28.182714402899123 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark30(-28.19382077216457 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark30(-28.20323234122519 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark30(-2.828952227555547 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark30(-28.30197045580583 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark30(-28.30778635628708 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark30(-2.831843794453121 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark30(-28.318679733451944 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark30(-28.341039441863032 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark30(-28.363818723305045 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark30(-28.43644771227649 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark30(-28.441663188526945 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark30(-2.846724975339626 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark30(-28.47825738654008 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark30(-28.534581845426587 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark30(-28.672520618240128 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark30(-2.8704058203132092 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark30(-28.731671388722503 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark30(-28.7603377676449 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark30(-28.810157740775665 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark30(-28.860994858513394 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark30(-28.924538502598082 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark30(-28.94965799772548 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark30(-28.961102856235925 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark30(-28.96330186682168 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark30(-29.019697650854454 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark30(-29.052718301487545 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark30(-29.061300823860847 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark30(-29.136119305552555 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark30(-29.147510350243365 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark30(-29.153798030572474 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark30(-29.23553185428682 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark30(-29.26017781488497 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark30(-29.275697931159556 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark30(-29.2898720277323 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark30(-29.301059991226424 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark30(-29.335641110901435 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark30(-29.419711137755584 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark30(-29.51604095839346 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark30(-29.5456481578682 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark30(-29.602142945308074 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark30(-29.656827130666997 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark30(-29.659159674335143 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark30(-29.731402276112846 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark30(-29.746165986826668 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark30(-2.977419633815728 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark30(-29.85284479846821 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark30(-29.89588940312551 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark30(-29.905698539369553 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark30(-29.931689992121008 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark30(-29.966753895983004 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark30(-29.98150453110115 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark30(-2.9983291722968346 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark30(-2.9991928505030785 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark30(-30.043370276824604 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark30(-30.055306805868653 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark30(-30.061117701269268 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark30(-30.117282036978878 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark30(-30.123160974370094 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark30(-30.130017563810725 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark30(-30.14040914865123 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark30(-30.14226764465171 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark30(-30.15657043150523 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark30(-30.169194957473394 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark30(-3.023847867669275 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark30(-3.034297927103566 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark30(-30.36950817055977 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark30(-30.37161725174178 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark30(-30.425421011152935 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark30(-30.453152845797888 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark30(-30.465560780702106 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark30(-30.46696728364094 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark30(-3.04704920301306 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark30(-30.506710303975666 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark30(-30.545028652743355 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark30(-30.54647871711262 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark30(-30.58085229357701 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark30(-30.60439268241271 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark30(-30.677829556066214 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark30(-30.714590288986727 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark30(-30.732229251217944 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark30(-30.741511647542353 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark30(-30.81587266011914 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark30(-30.83170295869894 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark30(-30.834139258819278 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark30(-30.86054455882858 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark30(-30.866944351502852 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark30(-30.91509036004703 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark30(-31.011975951231975 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark30(-31.03100619005825 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark30(-31.04597030634872 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark30(-31.056372052827342 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark30(-31.086565421104865 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark30(-31.12180819319022 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark30(-31.152064791119003 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark30(-3.1158052688928137 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark30(-31.18092666130711 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark30(-31.217149521975543 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark30(-31.222943863263453 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark30(-31.24223368071064 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark30(-31.259547557475457 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark30(-31.269230608673553 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark30(-31.280145198393456 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark30(-31.30493419438136 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark30(-31.324226110361167 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark30(-3.1328624027985796 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark30(-31.355473068279167 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark30(-31.364218786694124 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark30(-31.372410767684784 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark30(-31.409634586107998 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark30(-31.413567046730265 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark30(-3.148390548167427 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark30(-31.492806833965275 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark30(-31.522237629681314 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark30(-31.524688546464148 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark30(-31.58817735373198 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark30(-31.610695041659426 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark30(-3.1612555668861972 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark30(-31.63266711597717 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark30(-31.637592492689464 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark30(-31.676513652337107 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark30(-31.697602241157966 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark30(-3.17072846567865 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark30(-31.719069468519805 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark30(-31.734567273981156 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark30(-31.782418570525707 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark30(-31.788792958964663 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark30(-31.80896816163748 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark30(-3.1838310355604307 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark30(-31.894487292463026 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark30(-31.90932146424757 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark30(-31.92475405805783 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark30(-31.92752222327438 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark30(-31.95400319670381 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark30(-32.008532048364955 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark30(-32.05412849819287 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark30(-3.210454295881732 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark30(-32.120941077848485 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark30(-32.16365538070427 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark30(-32.22098158229309 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark30(-32.22884911770609 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark30(-32.33138660931263 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark30(-32.422019121930674 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark30(-32.42561531930302 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark30(-3.244522564583093 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark30(-32.50960274176191 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark30(-32.54672062550368 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark30(-32.628659384615986 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark30(-32.62877667113271 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark30(-32.67688425066078 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark30(-32.708133960733974 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark30(-32.74132339340139 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark30(-3.274955570694374 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark30(-32.7998843374488 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark30(-32.825933958444836 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark30(-32.87633232976435 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark30(-32.89118085665052 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark30(-32.90963781725537 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark30(-32.91691542135055 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark30(-32.97720369206816 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark30(-33.00811124640171 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark30(-33.0206391083788 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark30(-33.025668901785465 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark30(-33.07482758670555 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark30(-3.311603459035922 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark30(-33.21910305882794 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark30(-33.2842720646247 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark30(-33.315672685400784 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark30(-3.335478749562924 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark30(-33.355015693272236 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark30(-33.3566574826265 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark30(-33.358044616165 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark30(-33.376600122722365 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark30(-33.38606185392106 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark30(-33.40690944301683 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark30(-33.42269886402747 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark30(-33.43922863381661 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark30(-33.50512818489352 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark30(-33.56965846577353 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark30(-33.58956285172037 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark30(-33.59346520140052 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark30(-3.366074529066921 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark30(-33.67671675442618 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark30(-33.78148071870048 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark30(-33.79325354475695 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark30(-33.83075526135116 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark30(-33.91365386884917 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark30(-33.94233823581354 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark30(-33.953420914193245 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark30(-33.961227074686036 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark30(-34.01987996203253 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark30(-3.411100511663264 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark30(-34.13511137921108 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark30(-34.14475949422906 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark30(-34.25652508553017 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark30(-34.30657856766577 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark30(-34.32513357075804 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark30(-34.34773218532057 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark30(-34.38249386548378 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark30(-34.44968634468812 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark30(-34.518238140018596 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark30(-34.53656265381957 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark30(-34.57914257241943 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark30(-34.63006492253575 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark30(-34.726442197138766 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark30(-34.73229961112314 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark30(-34.7596767834829 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark30(-3.476776631394557 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark30(-34.797813207933075 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark30(-34.810133238040834 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark30(-34.84226773561288 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark30(-34.88475691635193 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark30(-34.92416286918585 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark30(-34.93297401572532 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark30(-34.941093661601386 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark30(-34.961186647767846 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark30(-35.02420870102756 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark30(-35.039933586940904 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark30(-35.04332574586235 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark30(-35.06637003970259 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark30(-35.0973511139256 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark30(-35.12064199050968 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark30(-35.12943535495856 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark30(-35.211061093831205 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark30(-35.22102171923916 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark30(-35.300135080927646 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark30(-35.31406472715564 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark30(-35.33970820183745 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark30(-35.34356088108832 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark30(-35.35925390880665 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark30(-35.4525454775723 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark30(-35.526896953121906 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark30(-35.527764086434274 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark30(-35.562987061758264 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark30(-35.56749140426203 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark30(-35.6412374879861 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark30(-35.73563999975076 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark30(-35.7708492209168 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark30(-35.777327168399324 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark30(-35.804128484739834 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark30(-35.813008570976564 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark30(-35.854447152963886 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark30(-35.924070725259185 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark30(-35.930645939364524 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark30(-35.931738134120494 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark30(-36.062676296097564 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark30(-36.0841697239626 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark30(-36.20864053725106 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark30(-36.21312949712656 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark30(-36.22466524566952 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark30(-36.27016795181899 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark30(-36.28229194025951 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark30(-36.33497306613636 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark30(-3.6361019617634014 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark30(-3.6416221164508755 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark30(-36.42068774460452 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark30(-36.48993909409506 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark30(-36.50688988702417 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark30(-36.576076626712386 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark30(-3.659659622914063 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark30(-3.6606309987209613 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark30(-36.64998019135661 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark30(-36.669174676227016 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark30(-36.671360889202596 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark30(-36.75965533960457 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark30(-36.79083873623752 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark30(-36.808538281733696 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark30(-36.81361121293754 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark30(-36.8176240091467 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark30(-36.84708796186258 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark30(-36.865422992696864 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark30(3.688001588925644 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark30(-36.88056446034622 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark30(-36.891297344651505 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark30(-36.892081381186934 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark30(-36.908064652797655 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark30(-36.935443000711345 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark30(-36.9906680945244 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark30(-37.010498987041316 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark30(-37.057771439099255 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark30(-3.7065605579691407 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark30(-37.079921596960276 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark30(-37.148212068056786 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark30(-37.172255720182434 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark30(-37.188339297250515 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark30(-3.7191492564138287 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark30(-37.225122040945166 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark30(-37.23695687805202 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark30(-37.25189210142812 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark30(-37.303344068908274 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark30(-37.31537166895163 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark30(-37.32567906907327 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark30(-37.34286137493683 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark30(-37.386262061515474 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark30(-37.38699818558686 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark30(-37.39564013128553 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark30(-3.75457897101397 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark30(-37.64790070217241 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark30(-37.64793424928838 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark30(-37.73304196382619 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark30(-37.785330669279915 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark30(-37.792283426576255 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark30(-37.79230186011748 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark30(-37.82026173676223 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark30(-37.84268707741762 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark30(-3.78765731601338 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark30(-37.880432914755644 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark30(-37.88703125877036 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark30(-37.937741366623335 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark30(-37.9927131101905 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark30(-38.100580319830414 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark30(-3.8120904903631896 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark30(-38.15253650846533 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark30(-38.23267303731115 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark30(-38.292034375809195 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark30(-38.32456829099373 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark30(-38.364778563251136 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark30(-38.37236610883681 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark30(-38.39517490196107 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark30(-38.422715857777945 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark30(-38.44261882836815 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark30(-38.48786766262431 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark30(-38.49701266185326 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark30(-38.50496531674597 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark30(-38.50656378009265 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark30(-38.55704167895551 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark30(-38.56737762950409 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark30(-38.58775475909202 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark30(-38.625400360331774 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark30(-38.654619402980764 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark30(-38.80515153238022 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark30(-38.81172324841491 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark30(-38.85009979176937 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark30(-38.86184468555456 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark30(-39.03908960367699 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark30(-3.90509786191015 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark30(-39.05373516151158 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark30(-39.11616863425198 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark30(-39.12290068688185 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark30(-39.14474434157758 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark30(-39.14486772364085 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark30(-39.186572934141516 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark30(-39.24016356266586 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark30(-39.25935668916802 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark30(-39.27595125891921 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark30(-3.9319757211178086 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark30(-3.933072143624642 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark30(-39.353258808208565 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark30(-39.464928981736925 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark30(-39.50532048461595 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark30(-39.54581390640877 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark30(-39.60535659941537 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark30(-39.60713524001807 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark30(-39.64265103282478 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark30(-39.66098147461985 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark30(-39.685489167450115 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark30(-39.704053061848384 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark30(-39.734788708724444 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark30(-3.9752907797023624 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark30(-39.77164658634646 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark30(-39.78824596823416 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark30(-39.833589478826894 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark30(-39.85543748263274 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark30(-39.92062773437939 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark30(-40.045085396709055 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark30(-40.170455050616496 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark30(-40.186572489890814 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark30(-40.197735839258456 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark30(-40.21048787946315 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark30(-40.2619225717596 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark30(-40.27570630536026 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark30(-40.275827057855395 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark30(-40.38197510337449 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark30(-40.38550701478329 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark30(-40.38943905239174 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark30(-40.47947139029291 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark30(-40.54399493450569 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark30(-40.61913746835113 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark30(-4.066925491418843 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark30(-4.067300532013519 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark30(-40.7555248147736 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark30(-40.75553295620966 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark30(-40.77997403294666 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark30(-40.8024404047602 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark30(-4.080832479160449 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark30(-40.82361386599249 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark30(-40.830803258199126 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark30(-40.852705350758775 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark30(-40.862890870352956 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark30(-40.88577422032209 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark30(-40.905318669088864 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark30(-41.028260588487186 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark30(-41.08428737776468 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark30(-41.09600953039407 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark30(-41.10594859670893 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark30(-41.11087751702276 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark30(-41.13406040535321 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark30(-4.113754435342713 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark30(-41.16886092452434 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark30(-41.21017287706257 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark30(-41.21740919248025 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark30(-41.26302915627959 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark30(-41.265254100524395 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark30(-41.372005144606725 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark30(-41.41986781757314 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark30(-41.470041663056854 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark30(-41.49213565389183 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark30(-41.54532860591049 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark30(-41.60782109021166 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark30(-41.63802466904261 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark30(-41.69121999604333 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark30(-41.70644261214112 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark30(-41.750308919941006 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark30(-41.77413367514697 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark30(-41.779598432062095 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark30(-41.78887125226467 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark30(-41.850073149042814 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark30(-41.878044742966615 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark30(-41.90428394891945 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark30(-4.191764875287404 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark30(-4.192145114584804 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark30(-41.93058812246464 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark30(-42.04093066107466 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark30(-42.060889952056236 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark30(-42.06636267420629 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark30(-42.097684975648406 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark30(-42.13365923465986 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark30(-4.215832094762391 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark30(-4.216300487507766 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark30(-42.24101852926792 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark30(-42.25257947478842 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark30(-42.26877685482964 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark30(-42.33998123362952 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark30(-42.423654631851115 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark30(-42.46093792626367 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark30(-42.56613993005152 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark30(-42.592894489924895 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark30(-42.61026899409111 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark30(-42.63876322112405 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark30(-42.732658920937226 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark30(-42.735808990282976 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark30(-4.287126603494329 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark30(-42.88326845212678 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark30(-42.98787935635102 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark30(-43.03193926678792 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark30(-43.054594597418095 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark30(-43.073656192315646 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark30(-43.12795429409915 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark30(-43.13024819382258 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark30(-43.149455012631854 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark30(-43.167807147144856 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark30(-43.21360432644408 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark30(-43.25510053603017 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark30(-43.297233126818014 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark30(-43.304648335320664 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark30(-43.307056875593084 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark30(-4.331461870920478 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark30(-43.34118285080979 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark30(-43.45128258094948 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark30(-4.3459102908306875 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark30(-43.496474572808054 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark30(-43.571225758019104 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark30(-43.597387296753574 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark30(-43.69376750487386 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark30(-43.70576501776953 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark30(-4.371419843302448 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark30(-43.71971674413566 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark30(-43.73821427270206 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark30(-43.772895027467044 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark30(-43.80035183173461 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark30(-43.81952806506051 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark30(-4.383710946339562 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark30(-43.86812991101181 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark30(-43.87151450170421 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark30(-43.892375816926155 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark30(-43.89880680948064 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark30(-43.928422728471105 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark30(-43.93783142325516 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark30(-44.00866274941138 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark30(-44.02151542476596 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark30(-44.03539537275842 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark30(-44.08420917075193 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark30(-44.09355596501436 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark30(-44.11326738263954 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark30(-44.2655381218237 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark30(-4.427305204664208 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark30(-4.42814621997951 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark30(-44.28170339449018 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark30(-44.303955796908824 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark30(-44.35258452742452 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark30(-44.36814998197469 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark30(-44.36891730915884 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark30(-44.3935695069952 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark30(-44.397714175523696 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark30(-44.431486315705214 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark30(-44.45068769105702 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark30(-44.470806791931004 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark30(-4.455659277097283 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark30(-44.59216187303285 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark30(-44.60172956488424 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark30(-44.623335632216076 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark30(-44.646590115108985 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark30(-4.465654952976479 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark30(-44.67764043281244 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark30(-44.6896839352243 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark30(-44.71560080761219 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark30(-44.71813942314631 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark30(-44.76546851124941 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark30(-44.87209353663073 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark30(-44.88538897749639 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark30(-4.4925865361203705 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark30(-44.99197962311865 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark30(-45.021100556615856 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark30(-45.07092392068051 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark30(-45.08355024670374 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark30(-45.12034129148137 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark30(-45.12269121253798 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark30(-45.13388735467505 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark30(-45.16055162747621 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark30(-45.21705315243785 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark30(-45.22180024587714 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark30(-45.41076852750881 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark30(-45.41305926356587 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark30(-45.417042163786924 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark30(-45.4371017568908 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark30(-45.492293170125954 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark30(-45.49265522216848 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark30(-45.53225432895056 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark30(-45.537766023344076 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark30(-45.56985978231924 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark30(-45.61698086138301 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark30(-45.63777801325506 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark30(-45.67610148971322 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark30(-4.573028545221277 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark30(-45.73886600147401 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark30(-4.576180521780543 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark30(-4.586260747151272 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark30(-45.869497691935976 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark30(-45.90773538056816 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark30(-46.021293311089615 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark30(-46.054202250986776 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark30(-46.13605063497697 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark30(-46.18710811854279 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark30(-46.22197980738001 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark30(-46.22780645209828 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark30(-4.626163098375002 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark30(-46.36635863195468 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark30(-46.41630248615007 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark30(-46.42605197408063 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark30(-46.43710313475105 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark30(-46.46550880686413 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark30(-46.498184315535276 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark30(-46.55764749559437 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark30(-46.56849363424445 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark30(-46.572645374526054 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark30(-46.66558451025724 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark30(-46.672465050788304 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark30(-46.68630338747779 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark30(-46.696133335231195 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark30(-46.70349240090281 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark30(-46.71574014546187 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark30(-46.723048299125125 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark30(-46.78517871633492 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark30(-46.80311247800122 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark30(-4.686258075073596 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark30(-46.88564527315688 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark30(-46.94103555945455 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark30(-46.9724202576508 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark30(-46.981001804534486 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark30(-47.016185421242554 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark30(-47.03250450845835 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark30(-47.18780859311658 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark30(-47.23216030468673 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark30(-47.24367552006399 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark30(-4.725016786040797 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark30(-47.28246958816919 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark30(-47.31799006870787 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark30(-47.32552378819885 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark30(-47.35329817348342 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark30(-47.42113034995879 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark30(-47.45720244875065 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark30(-47.46242903151536 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark30(-47.50231639651206 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark30(-47.52010246250853 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark30(-47.52605547928941 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark30(-47.55328640296867 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark30(-47.61182716627444 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark30(-4.782135907381274 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark30(-47.873436296988345 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark30(-47.88196971250176 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark30(-47.90510220723525 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark30(-47.93737182500388 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark30(-47.9407946030523 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark30(-47.94514303032311 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark30(-47.975147679164024 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark30(-4.800208879550482 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark30(-48.0069158130626 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark30(-4.80130808418788 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark30(-48.09678905984216 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark30(-48.111313523998604 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark30(-48.143389693140314 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark30(-48.25204575869692 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark30(-48.25489993107179 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark30(-48.25597023198674 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark30(-48.26239121392641 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark30(-48.27555863428663 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark30(-48.297882574942875 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark30(-48.32630601821246 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark30(-48.32691381950589 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark30(-48.395213754281464 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark30(-48.40225051340672 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark30(-48.414641668118705 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark30(-48.42002476328713 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark30(-48.42210092640686 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark30(-48.44153662987598 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark30(-48.47296290996908 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark30(-48.53537929660465 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark30(-48.54159389305741 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark30(-48.563989247246255 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark30(-4.859717701793301 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark30(-48.60090732758706 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark30(-48.8196393390679 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark30(-48.828151343686784 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark30(-48.85025977176345 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark30(-48.92338848219191 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark30(-48.97196123876198 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark30(-48.97510844015611 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark30(-48.98219363053013 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark30(-49.02669196591272 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark30(-49.05911472421263 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark30(-49.15816492535483 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark30(-49.209696866444915 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark30(-49.238621792299384 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark30(-49.23958380007962 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark30(-4.925114857794526 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark30(-49.27651973483038 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark30(-49.279627887837464 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark30(-4.933327350908897 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark30(-49.344344740285706 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark30(-49.352973787454204 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark30(-49.38720542734565 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark30(-49.39922390825462 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark30(-49.5253246254955 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark30(-49.54748769842956 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark30(-49.718101083486246 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark30(-49.74905132507745 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark30(-49.766829132629574 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark30(-49.80418895079117 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark30(-4.987530422807424 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark30(-4.9997009247049675 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark30(-50.01123119964104 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark30(-50.02804527883909 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark30(-50.03057016931949 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark30(-5.004376189123477 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark30(-50.084060029517666 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark30(-50.088934521720205 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark30(-50.119725811554375 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark30(-50.1200812910122 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark30(-50.16083389850328 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark30(-50.19446192731869 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark30(-50.222366320301326 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark30(-5.02299118832164 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark30(-50.23283689917824 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark30(-50.27724633877961 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark30(-50.30568227047889 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark30(-50.32690503747828 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark30(-5.034846267011602 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark30(-50.389991063596604 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark30(-50.39828730006699 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark30(-50.42481551675628 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark30(-50.43690451318361 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark30(-50.496159836465424 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark30(-50.55260968505393 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark30(-5.055588176300603 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark30(-50.57184148161553 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark30(-50.57794838744607 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark30(-50.61040731832942 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark30(-50.70079964158622 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark30(-50.809790981358205 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark30(-50.811522395168666 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark30(-50.842844228987325 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark30(-50.888327354709915 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark30(-50.90213851645742 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark30(-50.92108113524356 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark30(-50.92473061343594 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark30(-50.98034871268329 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark30(-51.05912777704393 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark30(-51.1834346321336 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark30(-51.19051750988153 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark30(-51.203010525217074 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark30(-51.232510119081766 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark30(-51.29418391527789 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark30(-51.392835454854314 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark30(-51.52191050271704 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark30(-51.5317790045283 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark30(-51.56512023015309 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark30(-51.5934329490942 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark30(-51.61465304614299 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark30(-51.641285503502445 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark30(-51.66995518918962 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark30(-5.172632767440106 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark30(-51.759772264005036 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark30(-51.864769585752455 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark30(-51.91810458277395 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark30(-51.93826001562385 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark30(-51.94802191455281 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark30(-51.99701981281446 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark30(-52.02661373312964 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark30(-52.04232085468927 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark30(-52.05474479425749 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark30(-52.05625157875331 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark30(-52.05661502416304 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark30(-52.06574326282474 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark30(-52.06585283125771 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark30(-52.07495867942469 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark30(-52.08704038395808 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark30(-52.09986815173138 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark30(-52.15991375759166 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark30(-52.16528829727864 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark30(-52.17664194604463 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark30(-52.21075912060697 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark30(-5.223031638401238 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark30(-52.28534315718789 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark30(-5.228683857481343 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark30(-5.229684708670177 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark30(-52.347657050658384 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark30(-52.452945907901174 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark30(-52.59321483690202 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark30(-5.267323452775116 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark30(-52.773136344188806 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark30(-52.82033744529635 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark30(-52.89302465859831 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark30(-52.91940007812068 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark30(-52.95062749365458 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark30(-52.9583831676498 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark30(-53.10999940248817 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark30(-5.315801478791073 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark30(-53.185714163772936 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark30(-5.320468080167956 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark30(-53.21679833349891 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark30(-53.28453020820674 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark30(-53.292767055976256 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark30(-53.33538737349313 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark30(-53.384596382678055 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark30(-53.40454379081241 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark30(-53.45208429643562 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark30(-53.51563732811655 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark30(-53.57494322235246 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark30(-53.58304887692851 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark30(-53.66910623919485 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark30(-5.371797715790166 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark30(-53.72710736711204 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark30(-53.81023592456733 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark30(-5.38409564404904 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark30(-53.90166517106596 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark30(-53.90670774998314 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark30(-53.91659912080908 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark30(-53.94110470297711 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark30(-53.97183340316085 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark30(-53.98476516583366 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark30(-53.988815942632826 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark30(-54.02040954560825 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark30(-54.03174855650317 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark30(-54.034958281667265 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark30(-54.03854768073914 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark30(-54.045846720662524 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark30(-54.119982096232654 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark30(-54.127754692561524 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark30(-54.138914006781455 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark30(-5.415131778101141 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark30(-54.165078749691986 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark30(-54.193233507412984 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark30(-54.235060837060466 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark30(-54.23884032881106 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark30(-54.37970143972881 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark30(-54.383662461141036 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark30(-54.39694193049633 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark30(-54.39734913531253 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark30(-54.42543642996349 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark30(-54.43742527996025 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark30(-54.440802145034354 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark30(-54.46739956982724 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark30(-54.47368757646216 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark30(-54.493474534941754 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark30(-54.494298758520834 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark30(-54.520193516414594 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark30(-54.52143271774994 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark30(-54.52399965439048 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark30(-54.54398333695381 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark30(-54.553408273676474 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark30(-54.57574214364909 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark30(-54.58782520332805 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark30(-54.6766108137414 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark30(-5.469594858445447 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark30(-54.72829741046028 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark30(-54.74192714965864 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark30(-54.751100941361244 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark30(-54.80161431849457 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark30(-54.90200367201934 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark30(-54.91596468897251 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark30(-5.491770233872884 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark30(-54.93895491870211 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark30(-54.96100115471554 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark30(-54.971016175234546 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark30(-54.98324888288455 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark30(-55.06198386728598 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark30(-55.099392139206046 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark30(-55.103420114661205 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark30(-55.12021140258807 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark30(-55.17302254342902 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark30(-5.518022482957036 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark30(-55.21178884609428 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark30(-55.22232930845574 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark30(-55.23212426142059 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark30(-55.23835204840002 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark30(-55.27883412967067 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark30(-55.327223637937585 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark30(-55.3800440855035 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark30(-55.38723588271737 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark30(-55.421646399254975 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark30(-55.43971777144636 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark30(-55.505475943143125 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark30(-55.507874256953826 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark30(-55.52952107026521 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark30(-55.56323037321946 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark30(-55.58104342176557 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark30(-5.558553037689336 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark30(-55.62426559739586 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark30(-55.63576612462335 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark30(-55.66896032926471 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark30(-55.725835864606445 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark30(-55.732180319093196 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark30(-55.78854762868048 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark30(-55.84851632553986 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark30(-55.85803291742537 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark30(-55.86684334996348 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark30(-55.87997152323765 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark30(-55.91329622863026 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark30(-55.9681568504621 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark30(-55.96934173239667 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark30(-55.98339394984744 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark30(-56.03135694677705 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark30(-56.08083411337263 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark30(-56.08794332445595 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark30(-56.11807190266806 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark30(-56.11970693678736 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark30(-56.17765183866865 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark30(-56.21783372503393 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark30(-56.25110083192142 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark30(-56.25247501687702 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark30(-56.2586883414133 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark30(-56.30570535576884 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark30(-56.30812376591599 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark30(-56.354701808687444 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark30(-56.40903647773603 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark30(-56.441350759745504 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark30(-56.44546403737887 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark30(-56.454192115887935 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark30(-56.462485086223225 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark30(-56.52641262179841 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark30(-56.61496822909 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark30(-56.61628045430034 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark30(-56.62686195732158 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark30(-56.64199341314018 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark30(-56.65281674759726 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark30(-56.657287745605565 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark30(-5.669728896060306 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark30(-5.686426734103023 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark30(-56.86663939455978 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark30(-56.880416538191355 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark30(-56.91193580398086 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark30(-56.94877598728034 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark30(-57.04712289330472 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark30(-57.063409833995934 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark30(-57.08234628400064 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark30(-57.096132842909356 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark30(-57.12228491872091 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark30(-57.20345491645815 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark30(-57.22290209256655 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark30(-57.26076648220759 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark30(-57.269869833767515 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark30(-5.728040845243697 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark30(-57.32410233753282 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark30(-57.36920986895875 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark30(-57.51064094896612 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark30(-57.518781650679095 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark30(-57.531438070743505 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark30(-57.53637612136813 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark30(-5.756792881196901 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark30(-57.569238824057976 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark30(-57.640008090282244 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark30(-57.64627101901605 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark30(-57.695891319661065 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark30(-5.775444436383864 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark30(-57.78177812774181 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark30(-57.80868442126659 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark30(-57.82820703846772 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark30(-57.866854479639265 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark30(-57.891196297064916 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark30(-57.920152586588934 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark30(-57.930238669665 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark30(-57.93925844073511 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark30(-57.96294389845802 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark30(-58.060680241099206 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark30(-5.806964618082759 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark30(-58.085576436106855 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark30(-58.11338473670327 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark30(-58.19384183382701 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark30(-58.19967521427787 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark30(-58.22349364890289 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark30(-58.32114136340596 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark30(-5.836867654628406 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark30(-58.37259779157924 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark30(-58.39262560839265 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark30(-58.4144331461516 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark30(-58.476665659756534 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark30(-58.47798012301708 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark30(-58.50149328418488 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark30(-58.54827193090016 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark30(-58.725523663201606 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark30(-58.794365381643466 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark30(-5.885386148354257 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark30(-58.91409263551961 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark30(-58.91701278672878 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark30(-59.005466220058 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark30(-59.089172787633856 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark30(-59.09702522576084 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark30(-59.099152660419804 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark30(-59.14301316493857 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark30(-59.154869781621144 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark30(-59.23926447839967 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark30(-59.25019578057733 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark30(-5.925463990004658 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark30(-59.26752683346326 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark30(-59.28400685384651 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark30(-59.35928529778926 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark30(-5.941875461049932 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark30(-59.42592313813031 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark30(-59.452034752585824 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark30(-59.49304622105333 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark30(-59.51678534050326 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark30(-59.52139530415374 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark30(-5.957713713605472 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark30(-59.58955298794662 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark30(-59.59777306153931 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark30(-59.61494105935075 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark30(-59.61988373179612 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark30(-59.73802479789407 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark30(-59.75033509518117 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark30(-59.7614637799051 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark30(-59.76477395182642 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark30(-59.77926925810535 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark30(-59.78387176489181 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark30(-59.7966663598664 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark30(-59.80796631173866 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark30(-59.80855753075354 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark30(-5.981132628763746 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark30(-5.983289311687173 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark30(-59.848629093135486 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark30(-5.986702983947566 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark30(-59.88697727296932 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark30(-59.88716424175378 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark30(-59.89455465819673 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark30(-5.98952154680741 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark30(-59.90418083077464 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark30(-59.95196974391066 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark30(-59.979436071182676 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark30(-59.98085602934506 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark30(-60.102055233510754 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark30(-60.105827712208914 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark30(-60.13790793338525 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark30(-60.14630518570512 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark30(-60.153026617244024 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark30(-6.0188182652642865 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark30(-6.01929533865291 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark30(-60.23574341448894 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark30(-60.244900779119746 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark30(-60.2794332465298 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark30(-60.30031691644617 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark30(-60.3024203053703 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark30(-60.30528508742496 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark30(-60.37155665951819 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark30(-60.40693122908078 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark30(-60.41064623798489 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark30(-60.42087256745625 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark30(-60.49996266448565 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark30(-60.50182329716329 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark30(-60.62703095410817 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark30(-60.6752357572661 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark30(-60.682634388277876 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark30(-60.71027709776384 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark30(-60.72772368901242 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark30(-60.752144596895086 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark30(-60.85333462676974 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark30(-60.87801423998764 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark30(-60.89462049554961 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark30(-60.90362105290954 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark30(-60.93194899230012 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark30(-60.96858371518881 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark30(-61.001454090812146 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark30(-61.038261185044874 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark30(-61.03884983052301 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark30(-61.05938934759947 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark30(-61.06288122803649 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark30(-61.08858669753128 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark30(-61.12573167908331 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark30(-61.14877852056275 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark30(-61.18724932587109 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark30(-61.22227266432729 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark30(-61.23773841430307 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark30(-61.26288775159669 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark30(-61.3361166429268 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark30(-61.3578936859668 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark30(-61.37410428228114 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark30(-6.1406595386434475 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark30(-61.430314826226784 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark30(-6.146167812601618 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark30(-61.518682817526305 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark30(-61.56986700238891 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark30(-61.597273825544875 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark30(-61.621258464294094 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark30(-61.64152759368031 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark30(-61.694038839911755 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark30(-6.170803621906828 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark30(-61.75771015525804 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark30(-61.776886622671576 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark30(-6.189550959080179 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark30(-61.902752724912546 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark30(-61.944917075140026 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark30(-62.02044620977449 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark30(-62.06982292103138 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark30(-62.105522331708144 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark30(-62.11275526041795 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark30(-62.13794554250289 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark30(-62.14023654499463 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark30(-62.18296246681345 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark30(-62.1921112085724 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark30(-62.20134485416502 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark30(-62.21053306311899 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark30(-62.23970066954996 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark30(-62.249735305655804 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark30(-62.31562069083905 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark30(-62.32947443204901 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark30(-62.33789739882396 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark30(-62.346964211282675 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark30(-62.35156475682035 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark30(-62.42711038287479 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark30(-62.44404592228234 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark30(-62.44863206814828 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark30(-62.481923383675905 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark30(-62.497314996421835 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark30(-62.522994419078316 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark30(-62.53054142524428 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark30(-62.53886922497725 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark30(-62.60884421986403 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark30(-62.61891656337906 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark30(-62.66319178382407 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark30(-62.70022701190643 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark30(-62.73974879748674 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark30(-62.816039563548706 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark30(-62.84894009122877 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark30(-62.85042236673617 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark30(-62.854983118289184 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark30(-62.86465241992219 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark30(-62.928773433700556 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark30(-6.295736249171924 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark30(-62.97201720825956 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark30(-62.980289570392586 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark30(-62.987293275987064 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark30(-63.018835006519794 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark30(-63.04409124534527 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark30(-63.06821826825879 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark30(-63.0875435091429 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark30(-63.09630727362643 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark30(-63.09772841309389 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark30(-6.314900317513121 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark30(-63.16907878337234 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark30(-63.18959332199165 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark30(-63.21125973611137 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark30(-63.22455050031057 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark30(-63.268992373845514 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark30(-6.330936943255551 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark30(-63.3107968267091 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark30(-63.32303358300515 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark30(-63.335317780954824 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark30(-63.39958100944667 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark30(-6.343416131011367 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark30(-63.591682915278255 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark30(-63.65229458274866 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark30(-63.681963589518965 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark30(-63.69356669645762 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark30(-63.753762125446855 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark30(-63.76635474272332 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark30(-63.83606732065641 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark30(-6.386290643241082 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark30(-63.863920705382114 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark30(-63.884052347975675 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark30(-63.89550849951819 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark30(-63.895605381391206 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark30(-63.93402741634284 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark30(-64.02988720137732 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark30(-64.0381891898081 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark30(-64.05016243341888 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark30(-6.4100888584873275 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark30(-64.10983368218177 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark30(-64.13330162598174 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark30(-64.14314302146049 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark30(-64.17377744818727 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark30(-64.197574654243 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark30(-64.21358364643478 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark30(-64.26482954912052 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark30(-64.3107601033405 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark30(-64.35945313733431 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark30(-64.3713121479389 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark30(-64.39717681494878 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark30(-64.40713699096987 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark30(-64.42521554143858 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark30(-64.42781329891929 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark30(-64.43515844960841 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark30(-64.45755722308537 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark30(-6.449742092691423 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark30(-64.51838646106607 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark30(-64.53385500031348 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark30(-64.59147108751706 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark30(-64.60259314044413 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark30(-64.67133496399885 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark30(-64.67572734770455 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark30(-6.469525951300994 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark30(-6.4768768625392 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark30(-64.7835774779816 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark30(-64.78842508238039 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark30(-64.83106990049671 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark30(-64.93146769623982 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark30(-64.95466385484218 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark30(-64.9933711960905 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark30(-65.00801626149781 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark30(-65.01473670284348 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark30(-65.01617274330971 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark30(-65.03268780109046 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark30(-65.06787336387276 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark30(-65.07142147896138 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark30(-65.09536072239732 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark30(-65.1566944656861 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark30(-65.17934124570566 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark30(-65.24348471665328 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark30(-65.26453397764143 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark30(-65.28294906823939 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark30(-65.29432530362133 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark30(-65.31128632610185 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark30(-65.31351520500463 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark30(-65.31593574596614 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark30(-65.36601551532564 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark30(-65.4134318022266 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark30(-65.47902706638133 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark30(-65.55533692230867 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark30(-65.59061599939807 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark30(-65.6076805967609 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark30(-65.6928876258211 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark30(-65.76697423307499 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark30(-65.80955142671907 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark30(-65.82266937794893 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark30(-65.8774761790502 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark30(-65.87845534067577 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark30(-65.96070462092787 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark30(-65.98337807621435 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark30(-65.98468640304085 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark30(-6.5987792851972245 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark30(-66.06426219047671 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark30(-66.06478261798983 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark30(-66.1051318250561 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark30(-66.1594222162914 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark30(-66.3376061575234 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark30(-66.35038822511106 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark30(-66.35056256941317 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark30(-66.37376883327974 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark30(-66.39513604633309 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark30(-6.64528555633315 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark30(-66.54048494386124 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark30(-6.655067008231356 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark30(-66.57785195394928 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark30(-66.78946990389787 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark30(-66.84778262727846 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark30(-66.89842954836266 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark30(-66.93994127017675 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark30(-66.94371832188247 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark30(-66.96007630608224 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark30(-67.0591780977252 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark30(-67.06830652360344 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark30(-67.08541565632062 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark30(-6.719566887654182 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark30(-67.22003608789196 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark30(-67.24453306922913 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark30(-67.26035521837173 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark30(-67.27062311583 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark30(-67.30516583901864 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark30(-67.32450342909704 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark30(-67.398895933732 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark30(-67.43380113236366 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark30(-67.46997861253259 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark30(-67.47524290450355 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark30(-67.51448324402307 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark30(-67.52822543285629 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark30(-6.75400220270221 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark30(-67.54326998948967 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark30(-67.55876399510043 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark30(-67.5845363602576 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark30(-67.62303573860169 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark30(-67.69619130923431 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark30(-67.73384379886556 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark30(-67.73442279164533 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark30(-67.7726577745423 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark30(-67.77830524486257 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark30(-6.777857416328629 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark30(-67.8129343437343 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark30(-67.82894412126738 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark30(-67.8472197915625 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark30(-67.87305586859094 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark30(-67.88425603403662 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark30(-6.791124836594491 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark30(-6.791263163699483 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark30(-67.93567945355754 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark30(-67.95535529399051 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark30(-67.99736622965635 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark30(-6.801895842189936 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark30(-68.0244124049363 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark30(-68.03486242861176 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark30(-68.04281574270377 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark30(-68.07829979001991 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark30(-68.09732696593011 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark30(-68.15837090385901 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark30(-68.18840176673284 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark30(-68.20298319883342 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark30(-68.20302893233034 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark30(-68.22088658266605 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark30(-68.26398084057257 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark30(-68.30034626806204 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark30(-68.30299854756213 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark30(-68.32097804511481 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark30(-68.37791796467712 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark30(-68.38725908717593 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark30(-68.41367025371966 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark30(-68.49360319329716 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark30(-68.50358954651574 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark30(-68.50876911846461 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark30(-68.50878168513114 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark30(-68.51241882026198 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark30(-6.851629569475094 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark30(-68.52275359576625 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark30(-68.56563619593261 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark30(-68.61467123825665 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark30(-68.69022181198947 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark30(-68.74703079535706 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark30(-6.874828953427922 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark30(-68.81744850170904 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark30(-68.82383159187948 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark30(-68.83808744942262 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark30(-68.8759762376292 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark30(-68.88267198421644 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark30(-68.88936672613417 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark30(-68.8992095208828 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark30(-68.96416873454798 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark30(-68.9833940093269 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark30(-68.98698779528958 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark30(-69.0256371466356 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark30(-69.04928140983601 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark30(-69.05812841650763 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark30(-69.05995836865833 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark30(-69.06917470474887 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark30(-69.1314060104471 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark30(-69.16527974328596 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark30(-69.17728296977303 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark30(-69.21353407358413 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark30(-69.27589876287384 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark30(-69.36580435251338 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark30(-69.48462453493835 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark30(-69.48773596977995 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark30(-69.49575715491002 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark30(-69.5131238191167 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark30(-6.953845531081626 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark30(-69.54510823135489 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark30(-69.58466546301436 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark30(-6.959189495250612 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark30(-69.65825112804045 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark30(-69.66922139446343 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark30(-69.74162414470638 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark30(-69.74569632247079 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark30(-69.75004884201931 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark30(-69.75902861630657 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark30(-69.7909760825852 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark30(-69.81965548032458 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark30(-6.9841549726844505 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark30(-69.84743259654084 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark30(-69.85760153268987 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark30(-69.89564655093716 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark30(-69.89839343026527 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark30(-69.9524282971667 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark30(-69.95692704999036 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark30(-69.99561681002014 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark30(-70.02991915413594 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark30(-70.03168440397751 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark30(-70.06837793481344 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark30(-70.08773011660088 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark30(-70.13682190759407 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark30(-70.19307246258224 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark30(-7.031794387483515 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark30(-70.37741006438252 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark30(-70.41804947873055 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark30(-70.43268916967563 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark30(-70.4416723781817 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark30(-70.52264391620577 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark30(-70.53216855853356 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark30(-70.5481581787669 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark30(-70.56028365963616 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark30(-70.56616454081843 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark30(-70.58969886677366 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark30(-70.59202225785377 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark30(-70.66746241100637 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark30(-70.67443153720059 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark30(-70.70942764646875 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark30(-70.71512517313772 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark30(-70.80476659370403 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark30(-70.83329264005344 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark30(-70.870028413958 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark30(-70.8790962501765 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark30(-70.88626660471273 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark30(-70.88803589526364 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark30(-70.89117688939078 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark30(-70.89189890480488 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark30(-71.01694385214539 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark30(-71.06875370715375 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark30(-71.07808041211526 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark30(-71.07864694730162 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark30(-71.09328357837366 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark30(-71.09734401649517 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark30(-71.11826020320702 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark30(-71.12025988468011 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark30(-7.114562641503781 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark30(-71.17080469105852 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark30(-7.118797667122109 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark30(-71.19994580821859 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark30(-71.22073899103452 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark30(-71.24928727374848 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark30(-71.37901069242247 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark30(-71.38977271790212 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark30(-71.40660641369416 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark30(-71.43194415932314 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark30(-71.52120817425684 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark30(-71.54566134411189 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark30(-71.55512685765598 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark30(-71.57915478971665 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark30(-7.160749338082283 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark30(-71.66372200522513 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark30(-71.68894628386042 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark30(-71.69437330227217 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark30(-71.73728506584155 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark30(-71.74645960698685 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark30(-71.76732396254455 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark30(-71.79575857792403 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark30(-71.8185816284048 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark30(-71.84285076841223 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark30(-71.88427715308183 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark30(-71.89813971000112 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark30(-71.91030924980284 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark30(-71.92306277945818 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark30(-71.92887523491066 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark30(-71.93739561632356 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark30(-71.93818560300463 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark30(-71.94153329930278 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark30(-71.94934095889406 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark30(-71.9591546699738 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark30(-72.0340626785003 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark30(-72.04213857728601 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark30(-72.09263392709433 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark30(-72.10188164341017 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark30(-72.11525467316784 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark30(-72.13600314094319 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark30(-7.216137144831762 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark30(-72.27396410747923 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark30(-7.238939134193089 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark30(-72.3932147586374 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark30(-7.23988316850361 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark30(-72.41693478675305 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark30(-72.43647946324373 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark30(-72.47630875659954 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark30(-72.58179725130674 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark30(-72.58424175635226 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark30(-72.59826316967278 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark30(-72.63306687405542 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark30(-72.64552568046136 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark30(-7.265130458792839 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark30(-72.75666525753152 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark30(-72.76781774696255 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark30(-72.82909537979852 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark30(-72.83761731249572 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark30(-72.85960104330388 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark30(-72.88648622300353 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark30(-72.97736428146365 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark30(-73.01145007899486 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark30(-73.02448282862173 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark30(-73.04019515521543 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark30(-73.04299293591933 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark30(-73.11474290183355 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark30(-73.14096031907928 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark30(-73.14639158406595 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark30(-73.17211346850135 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark30(-73.17293974261293 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark30(-73.224211487588 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark30(-73.25866528924718 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark30(-73.26272041852681 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark30(-73.29216855395926 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark30(-7.352861731902905 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark30(-73.52893719043044 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark30(-73.53470994787344 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark30(-73.5355552300916 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark30(-73.5797576746277 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark30(-73.58162779806297 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark30(-73.59640767577119 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark30(-7.360083688102705 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark30(-73.61895985465061 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark30(-73.66953731252707 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark30(-73.73107170588831 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark30(-73.73379899754178 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark30(-73.75007386620929 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark30(-73.78218693866887 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark30(-73.82461484229563 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark30(-73.86138716507149 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark30(-73.8953344781525 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark30(-73.97867002462877 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark30(-73.97995112128062 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark30(-74.02244686378907 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark30(-74.05687244761674 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark30(-74.0578089741534 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark30(-74.06471130073515 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark30(-74.11127410678542 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark30(-74.13895969042093 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark30(-74.21028452162781 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark30(-74.21128413898506 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark30(-74.21969604237235 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark30(-74.25355068338479 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark30(-74.26178065911495 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark30(-74.34041277984417 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark30(-74.35303944124345 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark30(-74.37233391427569 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark30(-74.37316397370732 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark30(-74.39289205510815 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark30(-74.39362432097955 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark30(-74.41135031676365 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark30(-74.47299545946336 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark30(-7.450812978997902 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark30(-74.57552276019655 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark30(-74.65000554923857 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark30(-74.66836183236592 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark30(-74.67351519849416 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark30(-74.68858966068382 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark30(-74.80276784508526 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark30(-74.80622648909664 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark30(-74.82195968736929 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark30(-74.85487522866677 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark30(-74.9050134663908 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark30(-7.491381255030021 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark30(-74.9675078562725 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark30(-74.98796985202398 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark30(-75.01662863555217 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark30(-7.505490251361962 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark30(-75.09179174626486 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark30(-75.10835966123997 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark30(-75.14448481148543 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark30(-75.1461901779799 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark30(-75.17736468576655 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark30(-75.21886728248626 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark30(-75.24535099554512 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark30(-75.28897693609757 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark30(-75.30768656952533 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark30(-75.32121631035386 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark30(-75.32983237610098 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark30(-75.47759975727477 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark30(-75.56613557311749 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark30(-7.560555716758316 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark30(-75.61188874572211 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark30(-75.62430028828926 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark30(-75.62971736953989 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark30(-75.64546732665904 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark30(-75.72590464620359 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark30(-75.7309497743668 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark30(-75.73169933283444 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark30(-7.578908162679369 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark30(-75.79860864280849 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark30(-75.82230377505891 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark30(-75.87163954751179 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark30(-75.88230484310061 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark30(-75.93849753155435 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark30(-75.94357892934936 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark30(-7.5997800085479525 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark30(-76.08015100292376 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark30(-76.09259306543368 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark30(-76.10797415893418 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark30(-76.1185805810048 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark30(-76.13144623049081 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark30(-76.15974718619438 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark30(-76.27031894328059 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark30(-76.35179900314867 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark30(-76.35615607939437 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark30(-76.35990382977975 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark30(-76.36909605206787 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark30(-76.39847077237327 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark30(-76.42327539900451 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark30(-76.43179532145861 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark30(-7.645483411295714 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark30(-76.57078788800544 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark30(-76.58213822862092 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark30(-76.62480616092218 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark30(-76.65915244188706 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark30(-76.66926720389074 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark30(-76.67068766184018 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark30(-7.670272493632922 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark30(-76.7724064666279 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark30(-76.80546349184479 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark30(-76.81823167885489 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark30(-7.685815305497485 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark30(-76.85967128503033 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark30(-76.87530915611352 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark30(-76.91720433552065 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark30(-76.95667179189584 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark30(-76.96534309222855 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark30(-77.02187361122779 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark30(-77.02212945395739 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark30(-77.06086576950663 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark30(-77.10417451896727 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark30(-77.1279526948195 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark30(-77.17054346279251 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark30(-77.17466961013812 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark30(-77.21301017879397 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark30(-77.29975349548198 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark30(-77.31320546723248 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark30(-77.35020514120802 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark30(-77.40047012212541 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark30(-7.741305950361536 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark30(-77.42605669589769 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark30(-77.52660472951662 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark30(-77.52996207509146 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark30(-77.56167359056056 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark30(-77.56567715253078 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark30(-77.60763520852183 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark30(-77.61533325424952 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark30(-77.65684019630032 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark30(-77.74669546097171 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark30(-77.80247007513834 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark30(-77.8027659861248 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark30(-77.86426390582099 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark30(-7.7879761709784106 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark30(-77.9630096433826 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark30(-77.97798178044599 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark30(-77.9812518241497 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark30(-78.05018030847054 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark30(-78.09274703461111 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark30(-78.10357974539801 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark30(-7.813487131404088 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark30(-78.13691188181748 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark30(-78.15220483209093 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark30(-78.15562291790033 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark30(-78.18510554537015 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark30(-78.25389155353068 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark30(-78.26850090445052 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark30(-78.30938833337203 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark30(-78.31289743464609 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark30(-78.35882260856994 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark30(-7.838428351732048 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark30(-78.40281183950806 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark30(-78.45733425393043 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark30(-78.46225401937764 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark30(-78.51161615753574 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark30(-78.52391357555916 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark30(-78.53936364547386 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark30(-78.60718864892063 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark30(-78.6436778452575 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark30(-78.65703818605967 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark30(-78.6583970076964 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark30(-7.868272263642211 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark30(-78.7082420276021 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark30(-78.73618799138531 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark30(-78.74378359379175 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark30(-78.74487165538586 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark30(-78.77410803126455 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark30(-78.83982634188848 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark30(-78.87883717509563 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark30(-78.8810670886251 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark30(-78.91580076226813 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark30(-78.91825338887368 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark30(-78.97035341806978 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark30(-7.902781742652337 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark30(-79.07134078486841 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark30(-79.0912796148529 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark30(-7.910194419695898 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark30(-79.1252569405255 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark30(-7.924044587429947 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark30(-79.25075231993814 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark30(-7.929489324497837 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark30(-79.36343534175643 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark30(-79.388102704761 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark30(-79.40032829095385 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark30(-79.45700767752655 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark30(-79.49338654707853 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark30(-79.49753788278147 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark30(-79.52169735233991 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark30(-79.57579321065555 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark30(-79.5871708885479 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark30(-79.60067009835103 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark30(-79.64456428989223 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark30(-79.65708939867366 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark30(-79.69346847411514 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark30(-79.69979782858279 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark30(-79.7294140144572 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark30(-7.973579975148198 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark30(-79.77507788547267 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark30(-79.9304053068712 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark30(-79.9949927514812 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark30(-79.9979670753524 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark30(-80.01287407619591 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark30(-80.05638290937327 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark30(-80.06962165605475 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark30(-80.07765399349091 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark30(-80.08286396045278 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark30(-80.13554276842325 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark30(-80.23837975526942 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark30(-80.27302182812178 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark30(-80.33326386582544 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark30(-80.39209927860631 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark30(-80.3946910148403 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark30(-80.43242521289191 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark30(-80.4476058270761 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark30(-80.48519632247096 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark30(-80.49398405180104 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark30(-80.50371807108061 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark30(-80.52461510959705 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark30(-80.5506832079673 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark30(-80.55929842182806 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark30(-80.56115585618821 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark30(-80.5940361974533 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark30(-80.5985808022985 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark30(-80.6023796147403 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark30(-80.61531817308068 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark30(-80.68856610840118 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark30(-80.73322315899914 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark30(-80.7583699882088 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark30(-80.75988884977652 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark30(-80.77766098710157 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark30(-80.8074870956487 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark30(-8.082316862607456 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark30(-80.85505028835938 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark30(-80.86182730200666 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark30(-80.86327714985578 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark30(-80.90694237754634 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark30(-80.96781034326943 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark30(-8.097768309227277 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark30(-80.97779436145927 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark30(-81.01028219751998 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark30(-8.102508357142497 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark30(-81.07443675873414 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark30(-81.08670433674763 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark30(-81.11053974614389 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark30(-81.11185915540813 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark30(-81.12069543012204 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark30(-81.12229922819863 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark30(-81.19160335897242 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark30(-81.21205713285902 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark30(-81.32117436883956 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark30(-81.33583351876683 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark30(-81.42639441281274 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark30(-8.146468390327271 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark30(-8.148841754965105 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark30(-81.50503935365568 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark30(-81.51323205912718 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark30(-81.54182168605135 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark30(-81.56704796232503 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark30(-81.58215132112565 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark30(-81.62006657042974 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark30(-81.67439367806335 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark30(-81.68328377355874 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark30(-81.70244062200744 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark30(-81.73034572957592 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark30(-81.7776318315507 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark30(-81.88568880831926 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark30(-81.90758770826207 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark30(-81.90894961620943 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark30(-81.94362308033442 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark30(-81.9609859503357 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark30(-81.969502057424 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark30(-81.98122876179235 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark30(-81.9949204646187 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark30(-81.99569098386212 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark30(-8.203913540041995 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark30(-82.05085466063935 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark30(-82.08722991434794 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark30(-82.16822667425745 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark30(-82.22660815424823 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark30(-82.24638129998544 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark30(-82.2476835555437 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark30(-82.27083233137391 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark30(-82.32035093899219 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark30(-82.50811921496725 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark30(-82.53464104468739 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark30(-82.54023654781264 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark30(-82.5416617166858 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark30(-82.54760763585134 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark30(-82.55330687236281 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark30(-82.57232256923086 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark30(-82.67206186097874 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark30(-82.67537949442449 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark30(-82.70257537291846 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark30(-82.73560725482886 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark30(-82.76312232295192 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark30(-82.78524550042114 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark30(-82.79230939364496 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark30(-82.82467638427495 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark30(-82.86425751625018 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark30(-8.286578617197435 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark30(-82.91042761485915 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark30(-82.95476016356895 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark30(-82.99486484347325 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark30(-83.05857217045161 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark30(-83.08456927446555 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark30(-83.08644664493039 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark30(-83.10740190000554 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark30(-83.11082193031504 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark30(-8.31213655936736 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark30(-83.12530940653375 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark30(-83.12742292915945 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark30(-83.13263428561231 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark30(-83.16961931704566 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark30(-83.22801778473637 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark30(-83.23342198241829 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark30(-8.323659032237046 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark30(-83.25588476612444 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark30(-83.25648167234635 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark30(-8.33006043806202 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark30(-83.35738958633365 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark30(-83.36736007733947 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark30(-83.42241353174981 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark30(83.44506597703898 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark30(-83.4553377410965 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark30(-83.4647157175915 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark30(-83.50125749534436 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark30(-83.58871394217067 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark30(-83.6403040156857 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark30(-83.6538813523887 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark30(-83.69950985002794 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark30(-83.71512612968544 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark30(-83.72910064979882 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark30(-83.83245956471976 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark30(-83.89751967030685 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark30(-83.89927444257208 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark30(-83.90689117418289 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark30(-83.91798641697636 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark30(-83.97223569440506 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark30(-8.406374612008676 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark30(-84.07951053622816 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark30(-84.09707512138277 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark30(-84.15761211983406 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark30(-84.15825514878192 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark30(-84.17914055927349 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark30(-84.18716555981341 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark30(-84.21698307293485 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark30(-84.22211032886221 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark30(-84.24937788228442 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark30(-84.2724243018927 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark30(-84.28486746179948 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark30(-84.34240115707937 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark30(-84.36803282341432 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark30(-84.38700016756965 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark30(-84.41361934806493 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark30(-84.45111378786874 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark30(-84.4634438966569 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark30(-84.49305632027726 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark30(-84.59810514422874 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark30(-84.60511476115897 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark30(-84.61186077900946 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark30(-84.66019516574761 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark30(-84.66683498596853 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark30(-84.66974465441841 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark30(-84.67267254581323 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark30(-84.7809471031368 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark30(-84.79375776103669 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark30(-84.8159743101202 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark30(-84.82387551193264 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark30(-84.85651642406143 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark30(-84.85831412160327 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark30(-8.48609536550346 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark30(-84.88119811476436 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark30(-84.9165991482935 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark30(-84.93881310950269 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark30(-84.95063111483412 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark30(-84.95459198632508 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark30(-84.96720157272651 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark30(-84.98910480595588 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark30(-85.01861587971256 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark30(-85.08365583224793 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark30(-85.11332184278768 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark30(-85.15859444703725 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark30(-85.16721589566552 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark30(-85.18235612836418 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark30(-85.20138037737294 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark30(-8.523725452102553 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark30(-85.25407214404545 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark30(-85.26656768019762 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark30(-85.28636551100021 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark30(-85.31503849157664 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark30(-85.32245018274372 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark30(-8.535918631752253 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark30(-85.3621231091935 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark30(-85.39987603635754 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark30(-8.542289090690417 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark30(-85.4812182669512 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark30(-85.53717622078582 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark30(-8.563260387857113 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark30(-85.64413550044769 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark30(-85.68040871931768 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark30(-85.70574510336976 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark30(-85.75862092696242 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark30(-85.80988232739011 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark30(-85.902740233281 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark30(-85.90378856693313 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark30(-85.96659751063314 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark30(-85.97037859939414 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark30(-85.97782967191125 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark30(-86.00580302350404 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark30(-86.0675264606162 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark30(-86.07120497447387 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark30(-86.10611183223978 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark30(-86.11541357393727 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark30(-86.16005240896945 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark30(-86.19377967852013 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark30(-86.26001653859691 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark30(-8.629806901656536 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark30(-86.30381411296122 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark30(-86.33821908244175 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark30(-86.35882367075686 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark30(-86.39454078957718 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark30(-8.643632828857179 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark30(-86.45829555142579 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark30(-86.47777222579988 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark30(-86.49527775117451 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark30(-86.54788072590054 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark30(-86.6483491103488 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark30(-86.71689030327794 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark30(-86.7404810382205 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark30(-86.76151985028311 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark30(-86.78548712633001 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark30(-86.82979700738221 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark30(-8.685993291034123 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark30(-86.87080284510962 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark30(-86.88846299757236 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark30(-87.0340172117506 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark30(-87.03506638700853 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark30(-87.10683175104496 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark30(-87.17493974805444 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark30(-87.21060157513791 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark30(-87.22314291417537 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark30(-8.722401956505593 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark30(-87.27090785185385 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark30(-87.3713662598564 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark30(-87.39154424015163 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark30(-8.741624780231462 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark30(-87.45615222513486 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark30(-87.46305982488276 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark30(-87.48425937173734 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark30(-87.55209282835904 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark30(-87.580754934902 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark30(-87.58966628203575 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark30(-87.63059318916955 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark30(-87.681362781176 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark30(-87.69027807314531 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark30(-87.79261234298524 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark30(-87.87168541223265 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark30(-87.87880096604775 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark30(-87.90243528035542 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark30(-87.90880350130755 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark30(-87.92593526980284 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark30(-8.795432464458287 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark30(-87.96732689364546 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark30(-88.00235313333415 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark30(-88.02304064181837 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark30(-88.02764562489618 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark30(-8.804713941981703 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark30(-88.15480993487306 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark30(-88.18365860136697 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark30(-88.20172671887461 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark30(-88.25070146125451 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark30(-88.37047377805018 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark30(-88.383500994741 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark30(-8.838628312920122 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark30(-88.44135560752176 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark30(-88.48976161621655 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark30(-88.52624863636235 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark30(-88.56282071119237 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark30(-88.60931794846502 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark30(-88.6270763205039 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark30(-88.63762044016332 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark30(-88.64723989227316 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark30(-88.65268375971449 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark30(-88.66956427269919 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark30(-88.68210351484875 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark30(-88.68863314738198 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark30(-88.79081727519782 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark30(-88.80304312236926 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark30(-88.81966313357327 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark30(-88.82135861376486 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark30(-88.82167777132224 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark30(-88.86876398100729 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark30(-88.95393920073735 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark30(-88.96581961433125 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark30(-88.98979730209606 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark30(-8.90087022701536 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark30(-89.01702055202611 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark30(-89.04615807838437 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark30(-89.11754661760942 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark30(-89.11997686682285 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark30(-89.12566833824344 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark30(-89.1528415688528 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark30(-89.17734592762099 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark30(-89.28396321088516 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark30(-89.3218022782308 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark30(-89.37153159330026 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark30(-89.41658791319824 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark30(-8.941962075889336 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark30(-89.46421780827139 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark30(-89.50505982524102 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark30(-89.53957669124114 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark30(-89.54074318947374 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark30(-89.59360333830983 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark30(-8.963321734415501 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark30(-89.68901197959347 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark30(-89.74644996098942 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark30(-89.77862948169744 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark30(-89.79518933649734 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark30(-8.98165627841108 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark30(-89.87184471548414 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark30(-89.88412270290999 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark30(-89.92865442654998 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark30(-9.001163648184345 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark30(-90.0168007355421 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark30(-90.03905760720387 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark30(-90.0509703071916 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark30(-90.06961069541559 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark30(-90.10952473309035 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark30(-90.10958453909876 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark30(-90.122180473719 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark30(-90.15756591796898 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark30(-90.16555273700581 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark30(-90.23043665378219 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark30(-90.25518406906153 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark30(-90.26127468776247 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark30(-90.29167376063785 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark30(-90.33042344322064 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark30(-90.34847397000962 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark30(-9.036133114265326 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark30(-90.38075695305348 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark30(-90.39154889446144 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark30(-90.4518326985871 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark30(-9.046137277802984 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark30(-90.47430918430747 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark30(-90.4820928759947 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark30(-90.52977315041689 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark30(-90.5475103105398 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark30(-90.5672198979423 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark30(-90.57225742571167 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark30(-90.60386175612298 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark30(-90.62381969362458 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark30(-90.62900442310833 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark30(-90.68735774672993 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark30(-90.75698838338096 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark30(-90.78040084757734 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark30(-9.084466541826956 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark30(-9.084947529206872 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark30(-90.88131342327716 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark30(-90.89228171993213 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark30(-90.90251635416644 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark30(-90.9587629188789 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark30(-91.0238517689938 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark30(-91.02951012697449 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark30(-91.03596077216127 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark30(-91.04815974886358 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark30(-9.105641371987574 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark30(-91.07139186711872 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark30(-91.07282770084024 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark30(-91.07752833116007 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark30(-91.07975829738011 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark30(-91.08345349354848 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark30(-91.09036803513042 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark30(-91.09183606439515 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark30(-91.15419654390777 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark30(-91.16803061737963 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark30(-91.18994226937889 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark30(-91.18999513701824 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark30(-91.22205218382564 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark30(-91.23397122726173 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark30(-91.2572086426085 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark30(-91.27325579178893 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark30(-91.28364292245037 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark30(-91.45999597619858 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark30(-91.47631989439967 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark30(-91.48082220074987 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark30(-91.5300109777504 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark30(-91.55389044926501 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark30(-91.55867791360204 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark30(-91.59226415003485 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark30(-91.62475795894488 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark30(-91.63138516809055 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark30(-91.6565733437195 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark30(-91.69157682200688 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark30(-91.71317922243247 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark30(-91.72973481962647 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark30(-91.77011445090156 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark30(-91.77515382126857 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark30(-91.8076099562318 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark30(-91.82373421699297 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark30(-91.87068877423104 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark30(-9.189717146548745 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark30(-91.90784628173942 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark30(-91.90817397143847 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark30(-91.92075800130831 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark30(-91.97296931853475 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark30(-9.19835612385613 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark30(-92.0097243841011 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark30(-92.07023151657994 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark30(-92.16328978702093 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark30(-92.1790413469632 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark30(-92.20513595394866 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark30(-92.21456740673253 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark30(-92.31875265839626 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark30(-92.34637296575161 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark30(-92.35087543779268 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark30(-92.41112443917541 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark30(-92.46303759196812 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark30(-92.49918524672478 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark30(-92.49934669541592 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark30(-92.53711934777617 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark30(-92.54224462480678 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark30(-92.63102198788155 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark30(-92.66265345111195 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark30(-92.67817200254049 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark30(-92.70848978514925 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark30(-92.73461553676017 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark30(-9.276565631552458 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark30(-92.80787526601371 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark30(-92.83948363586903 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark30(-92.84496105059151 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark30(-92.86048839650101 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark30(-92.89550643087794 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark30(-92.90977863220064 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark30(-92.92283613963414 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark30(-9.292690487055438 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark30(-92.93978713797082 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark30(-92.94571668742735 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark30(-92.98191982757405 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark30(-93.12780638797061 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark30(-93.19609909852855 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark30(-93.30815034770797 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark30(-93.35303894764635 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark30(-9.337207958744557 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark30(-93.38620138958402 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark30(-93.3957922964921 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark30(-93.41550829410907 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark30(-93.43646127856628 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark30(-93.51061211464378 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark30(-93.5476814064269 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark30(-93.5497992272031 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark30(-93.57338303538938 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark30(-9.357600091150232 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark30(-93.5881097698147 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark30(-93.6048812408714 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark30(-93.62700671948767 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark30(-93.68718266293754 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark30(-93.72857635128918 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark30(-93.764526931535 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark30(-93.78190892709286 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark30(-9.381229481614554 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark30(-93.82555872834084 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark30(-9.38294429927258 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark30(-93.84416844271783 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark30(-93.86328513615598 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark30(-93.91091657974151 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark30(-93.94001803153802 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark30(-93.95054716927953 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark30(-93.97795826467026 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark30(-94.04132163965069 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark30(-94.08163923738384 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark30(-94.12868021786839 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark30(-94.13093772648347 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark30(-94.15996535629263 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark30(-94.219703986319 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark30(-94.25549793252463 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark30(-94.32140867646058 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark30(-94.35162887447923 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark30(-94.4584256639279 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark30(-94.4802667786389 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark30(-94.49289504112726 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark30(-94.50792474783083 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark30(-94.51642054260978 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark30(-94.53301090999682 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark30(-94.58904487165279 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark30(-94.59756405802007 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark30(-94.5999182032946 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark30(-94.602596896933 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark30(-94.63935932849184 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark30(-94.65414193430026 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark30(-94.6685987507373 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark30(-94.68875198603826 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark30(-94.69589784799754 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark30(-94.70932840259967 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark30(-94.75258999766719 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark30(-94.77531358432371 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark30(-94.83635992952966 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark30(-94.85528645895445 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark30(-94.87252189763842 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark30(-94.91155370614844 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark30(-94.92970678155395 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark30(-94.93937298773962 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark30(-94.95660055408814 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark30(-94.9706414884145 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark30(-94.98526854421765 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark30(-94.99103726276579 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark30(-9.499457227929199 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark30(-95.02509332660087 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark30(-95.04303103749858 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark30(-95.11772122573798 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark30(-9.516331337918388 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark30(-95.21290714035231 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark30(-95.2510065817367 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark30(-95.29148976239115 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark30(-95.29461232584198 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark30(-95.29758188455743 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark30(-95.30036153526942 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark30(-95.30288734010712 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark30(-95.32671330331625 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark30(-95.33190859672567 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark30(-95.42068788966485 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark30(-95.43073744679738 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark30(-95.46380882212429 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark30(-95.47171720135998 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark30(-95.60090686391057 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark30(-95.63522771355657 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark30(-95.65060310665933 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark30(-95.65833701065947 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark30(-95.6824964245713 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark30(-95.70061559994087 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark30(-95.70438293491803 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark30(-95.71566958811665 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark30(-95.73162328938845 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark30(-95.81654588712942 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark30(-9.58394919479315 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark30(-95.84215254377817 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark30(-95.8646213369037 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark30(-95.90981028684666 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark30(-95.96912558814279 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark30(-96.03790410807396 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark30(-96.08592116872 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark30(-96.1276182307214 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark30(-96.20346598948264 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark30(-96.21922527876107 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark30(-96.23365534665407 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark30(-9.625296759499776 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark30(-96.26767277047846 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark30(-96.3188296210351 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark30(-96.37494281684833 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark30(-96.39172910353508 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark30(-96.46032121314292 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark30(-9.649101289554608 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark30(-96.52828174279593 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark30(-96.63136857321086 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark30(-96.67058235855002 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark30(-96.69809315722541 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark30(-96.73194792285051 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark30(-96.73862736808181 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark30(-9.678397559989051 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark30(-96.78968715068778 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark30(-96.7983273070266 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark30(-96.82284440632162 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark30(-96.87735737662466 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark30(-96.90828714527674 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark30(-96.9269242983383 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark30(-96.93205129996025 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark30(-9.698162755209452 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark30(-96.99521281155148 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark30(-97.07333030797581 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark30(-97.0884916848848 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark30(-97.20649016512233 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark30(-97.24263901714627 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark30(-97.28895368051052 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark30(-97.30804578497269 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark30(-97.3106765095738 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark30(-97.4061094169735 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark30(-97.49296545128728 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark30(-97.51750557725283 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark30(-97.52017141911742 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark30(-97.54544963584894 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark30(-97.58782336795716 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark30(-97.62239514840785 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark30(-97.63763746641025 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark30(-97.6831624512808 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark30(-97.68442751456806 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark30(-9.769533853398542 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark30(-97.7349929505901 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark30(-97.74695538712268 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark30(-97.79166168190159 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark30(-97.80219204202827 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark30(-97.83477920894757 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark30(-97.9163688378289 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark30(-97.92793055929118 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark30(-98.0288011336398 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark30(-98.13795964581695 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark30(-98.22085307525803 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark30(-98.25463371024634 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark30(-98.2547676531208 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark30(-98.27007986138246 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark30(-98.27392841957945 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark30(-98.34401109458535 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark30(-98.36033978651302 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark30(-98.38067926191627 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark30(-98.38296105262366 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark30(-98.40940252876223 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark30(-98.45219276650442 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark30(-98.51505913827626 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark30(-98.54169658169975 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark30(-98.58922060550267 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark30(-9.860761315262648E-32 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark30(-98.62877209019454 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark30(-98.64922111018618 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark30(-98.74379438347806 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark30(-98.77068391728055 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark30(-98.85237559662015 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark30(-98.9148746701396 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark30(-9.891519427510246 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark30(-9.892856849411018 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark30(-9.90993109429948 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark30(-99.11616494530118 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark30(-99.13545823107899 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark30(-99.16995766113578 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark30(-99.22104967163499 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark30(-9.923125001476592 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark30(-99.23569629345303 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark30(-99.24840529279648 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark30(-99.31854698575002 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark30(-99.32520253398884 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark30(-9.932816317219135 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark30(-99.35746939348284 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark30(-99.37586908540985 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark30(-99.40743017461422 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark30(-99.45401649061152 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark30(-99.48631621218922 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark30(-99.62106084433245 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark30(-99.62275939093279 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark30(-99.62630792828529 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark30(-99.62815039066713 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark30(-99.68470218924956 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark30(-99.6924175903182 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark30(-99.74932671797112 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark30(-99.78481393579241 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark30(-9.985517116359247 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark30(-99.85637626840503 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark30(-99.87696544741735 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark30(-99.8908657637452 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark30(-99.90255011557761 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark30(-99.90322333653745 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark30(-99.97778690365027 ) ;
  }
}
