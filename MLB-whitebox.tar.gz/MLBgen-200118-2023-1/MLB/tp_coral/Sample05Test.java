import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
//    0.6757741550216234;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(0.04527533351870475,-1.5707963267948966,-43.08812482876337 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(-0.07430221524420463,-66.97251155525454,-1.122517853109167 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark05(0.14132468548420662,-60.19946757973347,-71.06358940476835 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark05(0.18476067014256614,19.31875696623547,-74.38640415838765 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark05(-0.20910807297075448,-1.178530662658018,21.725704389001145 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark05(-0.21731612267018882,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark05(-0.27819685494710467,-54.80713568269093,-54.401283856776814 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark05(-0.27869258025333254,-9.892108290247137,81.84725247684624 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark05(0.27911522279764256,-38.63397374124904,59.85759001828359 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark05(0.3448046122619529,-91.39550109889723,-88.61536454801666 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark05(-0.3888163694145891,-47.60607650798281,1.5707963267948912 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark05(-0.4096822473188101,-0.4093504465232802,15.740574523721747 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark05(-0.46425039025704884,-66.92402157537053,-23.968021611156132 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark05(-0.49999998047506417,-54.29076332060436,1.4518074979657551 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark05(-0.5258145571318448,-123.27976228476383,-35.97420471868237 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark05(-0.5374839145922242,-1.5707963267948966,-1.5707963267949054 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark05(-0.5440190462658171,-60.780232434842915,37.771262953905385 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark05(-0.5449087648181502,-1.5707963267948966,-35.25691790341244 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark05(-0.5457972555010354,-1.5707963267948966,78.36988806880095 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark05(-0.5528479137613088,-1.5707963267948966,48.36419335155534 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark05(-0.5625506841632429,-1.570796326794896,-1.5707963267948983 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark05(-0.5651124434389546,-47.79648924540917,1.4390273896340506 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark05(-0.5676999816598199,-54.00157584748616,-42.783172864216326 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark05(-0.5693475696350948,-0.7431040854573335,-15.524723682307418 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark05(-0.5696079996747488,-1.3068599771026224,-44.14192360036693 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark05(-0.5702066177852531,-1.5707963267948966,-32.93729092607647 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark05(-0.5702616446648455,-1.5444203517891832,55.260581683406485 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark05(-0.570549681040229,-59.692476555417414,-1.5707963267948966 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark05(-0.5705544390977778,-1.2198687453764445,1.5707963267948963 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark05(-0.5706338620197765,-1.5707963267948966,-72.54361782964673 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark05(-0.5707675219346485,-0.7829485368113919,0.0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark05(0.576115946582774,-86.37113507620887,-1.5707963267948966 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark05(-0.6042814589735315,-9.380760764386594,75.37881648174226 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark05(0.7453113227244899,-54.804535639829766,-23.338112019078963 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark05(-0.852192083341663,-35.884516920785714,-52.074856178776365 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark05(-0.8924445773561303,89.71370924388836,-48.01478292990227 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark05(-0.9956733101486748,59.3460550344104,50.2140454752452 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark05(-10.293557091232913,0,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark05(-1.0302767526032651E-13,-16.600660141489016,-215.04827326658142 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark05(-1.0842021724855044E-19,-0.8666923190614501,1.5707963267948966 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark05(-10.896966849712271,-65.6982803480368,97.45293900432554 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark05(-10.954441076021638,-9.477968676968914,-37.47073497838649 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark05(11.00386198489312,48.0831227312176,37.07007053512655 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark05(11.174766478288817,94.43473357608738,89.61888800803834 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark05(-11.213099603521613,-87.78295328354066,-58.877180298558464 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark05(-11.267485320311877,14.781630649159297,73.99182901734855 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark05(-12.130061258270544,37.1965292244692,81.77655071291281 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark05(-12.164393051456386,67.82453232821857,-35.279914852915866 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark05(-12.231272614474946,26.496032998459015,83.00856414271081 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark05(-1.232595164407831E-32,-0.021726743294282855,21.973689906860727 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark05(-1.232595164407831E-32,-1.5707963267948966,-50.17228856258974 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark05(-1.233363419918117E-16,-0.24428198112314892,91.106186954104 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark05(-12.540263190480516,9.904080850073555,59.558878435567095 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark05(-1.2627824507454944E-15,-54.7374565316064,0.0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark05(-12.778597399290788,-61.02238992094551,50.86595972479279 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark05(-12.962415196607552,-94.62214740346214,64.91553855747068 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark05(1.3176521668658479,-79.00508223209721,-7.566656721353659 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark05(1.3234889800848443E-23,-0.11744363757376736,-2.4108091257107134 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark05(-1.3234889800848443E-23,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark05(1.3234889800848443E-23,-1.5707963267948966,-26.155197344835543 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark05(-1.3234889800848443E-23,-47.345112928913125,-95.65337820792413 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark05(13.471798344609581,84.6864267077811,-99.88845835259428 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark05(-1.3552527156068805E-20,-29.279030440558863,-1.5707963267948966 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark05(-13.830669014800606,31.18290934132071,-42.32220515515712 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark05(13.875989988112352,-49.259342573598495,26.549794698607812 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark05(1.3877787807814457E-17,-1.5707963267948966,-22.278969648936844 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark05(1.3877787807814457E-17,-1.5707963267948966,-77.11984300939335 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark05(-14.274705883443687,-76.46294977115666,-24.95750756619468 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark05(14.276173152840016,86.59107654610995,47.08974575166661 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark05(-14.290656743894488,76.37698226700041,36.88022324071065 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark05(-14.361102141356625,-59.089012769188656,4.449051868199945 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark05(14.429203879976669,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark05(14.42922471914543,-1.3408548975446084,5.614963347706998 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark05(14.429266477522006,-1.5558791407704307,-0.3131353413874365 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark05(14.429299326665472,-35.213439426334034,54.87195325706053 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark05(14.431117453261287,-0.7873285886684686,13.447348455818528 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark05(14.432271566806698,-1.4436076005750231,10.710315997966887 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark05(14.434783396661004,-154.15150716604316,100.0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark05(14.44108921032791,-1.5707963267948961,-44.78679263454597 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark05(14.443887855294172,-28.537846335591794,-3.2045697701123395 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark05(14.45516847572108,-192.4773603166422,67.25604406409508 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark05(14.48849606620282,-1.5707963267948912,14.373507919133814 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark05(14.527722756163847,-1.5707963267948983,-1.0858879073314207 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark05(-1.4544199270171156E-15,-34.77004466127851,-63.6929828609347 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark05(14.556047868279272,-23.309647225040063,203.74589580222892 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark05(14.589119054549428,-30.498371913993452,37.09188845412973 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark05(14.600515837246753,-1.4627030589754901,-100.0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark05(-1.4889487655511506,0.7842431345169165,1.5707972813690865 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark05(-14.990702140379454,-37.493427351951645,95.38064797370288 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark05(-1.502527110607379E-16,-1.5707963267948966,-0.4235714247880533 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark05(15.09535995710283,-39.53958122015395,-59.57788309948893 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark05(1.5183553821824631,0,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark05(15.226257814619018,-57.018933204561506,97.98502211797282 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark05(-15.397045351924206,-35.74971117569936,-70.61100960136744 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark05(-1.5615041484184555,-186.52009719279548,-4.163290536697806 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark05(-1.567049190200094,-3.266592656612537,-104.72108722594014 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark05(-1.5671690992150156,-0.051574756521974074,-6.283849272398487 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark05(-1.5704580079288735,-122.7077386692426,-331.43794830675637 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark05(-1.570528031165165,-4.1415926628882245,82.35013993341312 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark05(-1.570530401238004,4.141705634186992,73.70312889465512 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707106949049312,-67.53412942514782,-207.65252989221713 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707394364443985,-79.15636040609027,-415.18552126172517 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707609863884682,-4.141643543938283,133.75780168032998 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707678502809506,-3.143465107082696,-180.30061362254077 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707710700684732,-506.38491523849893,57.553182029759824 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707725660219256,-537.9687401044905,-1.8559843749010192 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707922983399925,-10.403119374658631,3.2234911242162005 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707936277891292,-745.0944307277767,38.588457468537115 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079531061147,-3.5846023994825558,14.429587079836736 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707955326101846,-123.55159243020391,3.266594042089273 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707957967657848,-3.1420811584467594,-112.97274094459415 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707959648204408,-123.68066793684535,2.113101108277137E-12 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796278960288,-261.90646884918954,-60.314502548173635 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707962795737813,-10.257470306553344,-34.82942826808338 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707962882227233,-1.5707963268966316,139.84075429836753 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963185297877,-129.72891768356791,139.40287431271483 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963218062562,-0.3098756981505071,144.9952334276701 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963246180758,-73.58655122550533,265.4676131763897 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963258574358,-1.5707963267948912,-20.67335302448074 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963259714839,-0.07471694504248794,-4.712389487525442 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963262344806,-67.06638590929819,-12.568353688163475 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963264736169,-53.54248624655752,88.66589890708616 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326529387,-124.05409496033965,28.163395228660278 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265885947,-1.0933405989429106,1.5707963267948966 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326606466,-22.30091527365213,100.0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266318794,-1.5707963267948966,-21.356975566066826 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326638862,-29.170498995780115,-54.88849881220233 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266613423,-1.5707963267948963,-0.014783786976698049 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267134089,-0.0156365315806289,84.34648112874412 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267395433,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267525142,-35.8160409353528,0.10843002299991883 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326754956,-59.91019651277285,-1.5707963267948966 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267584968,-0.0919092633731607,78.53981633974483 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267592966,-186.41348342912704,1.5707963384388264 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267743197,-72.47181556386256,181.99626739748476 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267759837,-1.5709595146987063,-141.28474163469036 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267835685,-1.5707963267948966,-81.79828660954642 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326786968,-4.270716282446465,-335.7890362244857 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267872118,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079632678981,-1.5707963267948966,-0.25837966498027354 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267912635,-1.570796327195046,232.60094044715464 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326791411,-1.5707963267948966,-55.57914836441675 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326791663,-135.4197805036433,-44.01806327573644 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267922451,-66.76000168414932,-62.98531082145417 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267925105,-0.6310478495970417,161.80219032880893 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267926586,-154.62361594847528,122.48519758416865 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326792797,-0.20486318288347924,-1.5707963267948983 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267930285,-29.553679371924737,-49.852278373182266 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267932754,6.429756970489486,-100.0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267940621,-29.216880131110237,-20.88218630514973 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267943095,-47.582903597457666,60.847332530918656 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267944043,-1.5707963267948968,-1.5707963267948966 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267944365,-1.5707963267948966,30.776184284197488 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267946816,-1.5707963267948966,53.0642298641503 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947043,-104.98723582802035,-1.5708005123456634 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947365,-103.74370777874478,141.53753642820777 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947538,-122.67612268565988,0.00918033819854079 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794769,-123.54049694304626,-191.95605012484071 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948,-281.05441495598967,-11.463181616046647 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948328,-34.6902930312386,1.5707963267948966 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948404,-0.206534352959598,97.28565535075467 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948486,-97.94471906234742,139.90817540344392 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948695,-154.80802573325082,-82.10089036748394 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794874,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948788,-35.09047099755478,77.05478628597561 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948812,-17.126751772042837,-141.01535980433226 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948812,-48.52784057567433,-73.17789749215704 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794882,-9.976619964685318,-79.51997749928611 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948843,-1.5707963267948966,11.269701513666917 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794887,-41.438892490537896,-1.1884275775115396 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794888,-54.00130623367873,-118.87071576442149 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948888,-3.149405164644824,-1.5707963267948886 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948888,-66.18668520910603,75.52985239585145 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794889,-1.5707963267948983,-274.8893571871623 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948892,-1.5707963267948966,-98.19067666223081 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948901,-123.81467417450429,-60.34629134990925 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794891,-1.5707963267948966,35.36513026870977 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.081972835348708,45.07011830866574 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.154781182808108,1.5707963267948948 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.677839478043026,1.4620336066854702 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.708568069248884,-26.671997765668223 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-116.78971806753151,6.854546586124016 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-117.50296554797397,-80.05637629225812 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-122.76813043207426,-9.897441659912047 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-123.5221100848315,-0.6675710976979728 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-13.293245118647661,-1.5707963267948966 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.4513309685172593,79.60011349014312 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948912,-21.698139343205852 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948912,44.562264462074126 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948957,-84.4845640446806 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,26.815675061770055 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,27.608520017965038 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948983,95.07183991378818 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-160.5618173685386,-105.24339931693257 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-161.48872327395637,1.5707963267948966 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-22.870106619470306,0.7273409717741188 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-23.24419862315261,-67.52646671283952 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-28.684445779725593,-21.37220898428552 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-29.337951283364532,90.66892332727778 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.16705233855702,-147.52659801269886 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-42.05266216294171,30.801429700041414 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-4.682214230531301,-55.537740508538455 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.027419022928996,-52.16447920728449 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.09963679078073,-17.281079723099353 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-53.799715448639205,-185.915726778716 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.87786939523331,-95.34792535813361 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.89692099025771,-85.59170030919637 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-60.07973558199933,-122.88464694508454 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-60.76565572977102,-32.28481738499689 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-67.00976603740841,-21.51013289149249 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-67.25303531088832,-41.204637215796595 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-67.39769992985143,-1.5707963267948966 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-72.75819303105717,65.15654090486191 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-73.1001108773735,-17.042217341188902 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-73.51289521714637,-1809.2462617851331 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-78.99575221632064,-61.40000483451621 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-79.39000433208201,-1.06892388182831 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-82.73149742074244,91.58257199213143 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-86.202471905338,84.29015946025307 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794891,-66.00452831408938,-172.89766240433076 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948917,-1.464881411343221,-1.5707963267948966 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948921,-98.86589470533407,-85.07326891192109 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948926,-160.38455534712097,-1.5733022168044417 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-0.5771019458254121,36.151337889690524 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-17.068586902848452,84.42397368581044 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-41.6191369902681,1.5707963267844003 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948937,-1.5707963267948966,5.03548864819433E-17 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948937,-53.74308814669967,-31.415926456507634 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794894,-123.19052644757713,-113.80751037664524 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794894,-1.5707599299012636,139.50751866336861 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794894,-1.5707963267948983,-25.738986982093124 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948943,-0.9838661055322655,73.82742735936014 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948943,-1.5707963267948966,1.7287648337705877 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948943,-15.739482194136594,70.05998722039487 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948943,-41.55598291252469,-9.719612092550452 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794894,-487.94519999747064,1.5707963267948957 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948946,-1.5707963267948966,1.5707963267948941 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948946,-166.61979085625092,27.73825605404013 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948946,-3.295641724314571,-1.5707963266714773 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948946,-47.77150276875728,1.5321234351896278 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.6635556255739461,-69.95757625782922 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.6901464533044361,28.27445368314447 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.9425592560824351,22.46177671288953 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.033804994336174,73.37120122638854 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-104.90734435896033,-44.84432777398217 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-10.526456750229306,-41.36218479694847 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-10.779898100301295,-3.586930470044962 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.2645904007882662,96.24044281340613 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.3554737353903468,-1.5707963267948966 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-135.75320156466532,80.4111582868524 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.570796326794877,-94.3212776557196 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.570796326794893,-44.95008389467448 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948948,-99.15236504370087 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,115.73967928434024 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-90.6623279338953 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948983,30.15006165048123 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948983,-35.92083657105165 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-16.092089139117576,-94.90496109469211 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-23.357038371504316,2.220446049250313E-16 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-312.45345913061976,-49.661920159478214 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-3.1420809348397936,-86.6794313841662 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-41.12375498837664,-47.8378921236795 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-66.40769381008226,-6.974381102263333 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-66.41445654816935,-1.5707963267948948 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-72.71062768066543,-118.94302448336181 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-78.68505369390053,47.703158557047175 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-79.72522074192504,75.81101198517256 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-85.88844306079471,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-86.34702819354109,62.97670769626896 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-92.27988234538545,1.5707963267948966 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-97.6855886041261,-7.310475079324107 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794895,-0.03836995674023047,47.23569849857415 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794895,-0.49002412372913084,-70.36266174378316 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794895,-136.41573741031118,-6.042646618158699 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794895,-1.5115053530909044,174.53820185754245 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794895,-1.5646760983762995,1.5707963267948966 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794895,-161.09308837380445,4.327145750755946 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794895,-186.515957620157,0.34686514934391305 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948952,-104.26234469211131,-142.74675729001783 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948952,-179.59236263558273,-13.925537622466038 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948952,-9.984799810849344,94.57335424129234 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948954,-10.128295566917403,-0.2706392585304047 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948954,-1.1166088686142137,8.103981633978467 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948954,-1.5707963267948966,-1.5707964841228903 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948954,-1.5707963267948966,6.52270707130629 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.65762926835669,8.103981633974485 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.8079796456462928,-3.3951206841210738E-15 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-10.879188445529069,10.424777960769392 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-148.13033269643006,-42.47577620915284 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963266164815,64.89389101071434 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,63.87133865301465 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-16.01257731592068,146.82735296999851 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-2530.124260197709,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-31.34041221083524,6.701213340952577 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-4.120003849345082,91.17332503077827 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-53.723565930187064,-6.412502053463877 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-59.92535265237176,-1.5707963267948966 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-60.472035279649404,-119.38247397688409 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-66.127551125664,-51.56388911114449 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794895,-9.871511896733578,-83.35425703572974 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-0.7007127353775694,-30.27323851278599 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.04421622441288578,-7.823010455250264 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.5668371351699413,-149.2263180222866 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.5681951776154561,27.85472704449886 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.9580735375294562,0.5866962082875822 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-110.39591841029817,91.38572805196938 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.188506044633525,6.28416187001229 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.4475700262161724,1193.4043772986547 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948788,-6.530011193754305 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948948,0.9117349634392823 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,18.930918900764656 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,-28.628058887700167 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-22.884905132860276,-1.5707963267948912 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-1.5378646265471183,0.2455946977095877 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-1.5707963267948966,72.93525290152382 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-61.22692510130037,0.163954120607789 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-73.27971269316376,-56.54866776417176 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-92.61877947591609,-6.283246496702948 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-92.6769832806958,-135.0870508924163 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.014172618665591566,-11.433463732083155 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.01641682907071141,73.81675923906134 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.026740621029363636,7.249727112695908 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.1311575635178695,0.0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.4708814527754752,-64.00279217875118 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.5855792476530997,-65.58032389967735 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.7343804003093215,-1.5707963267948966 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.0683834679760567,8.10398163885356 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.1260880067381893,566.7022254112309 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.2901694315680867,64.05350799594065 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.4001789331854189,25.479355593928815 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5027387181203196,-82.37600351340097 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5137723751843406,-80.51296559251148 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.51649347476271,42.757470610383976 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,13.91717915070005 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,1.5707963267948901 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-16.779936985217375 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,27.04871607561544 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-65.97458784969078 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-81.8202612949422 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948997,-65.80294868264045 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-16.716232241206658,21.83343177704738 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-180.28488062018195,-141.78879998868408 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-305.7335013570625,-18.863985022507066 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-3.1415926684909703,-68.15248430122153 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-35.02491978248798,1.5707963267948912 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-41.89104098806513,58.5076220529669 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-4.365693466259444,-0.6456504929848746 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-47.88819175760044,1.5707963267948912 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-47.91904484055458,27.073699288078124 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-48.21486155664988,-1.5707963267948966 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-53.751999365122934,1.570796326107371 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-54.45125739175752,-438.0967349493683 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-60.0822566453656,-4.712388980384695 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-60.31284035946681,-32.66118903481725 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-66.06686506410438,6.283372531096402 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-66.99714049980163,-89.68015729565809 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-67.36797794588517,-3.1417530936337426 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-80.02262724542044,-90.62479343512878 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-85.42573655187024,-8.79244739682342 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-85.52455968340826,-5.707681778733923 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-92.27658675438639,-31.340796698958954 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-9.424777990571796,1.5707963267948968 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-98.93062451610096,-4.71238899830528 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-47.876438840143905,-1.570796326893354 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0.0,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.0011470927000526258,1.5707963267948966 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.0014902501332932348,83.62082431327028 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.0015335865394395624,60.02464554055969 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.0021505704055542808,-63.826792087719774 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.0022016431295377283,-57.18645396510964 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.0025519379076563327,-95.27654372262683 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.0030263685168631232,-618.3137107098225 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.0031064009212193036,0.0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.0032886702149349653,51.84064283485279 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.0040032500910651995,16.09782644890041 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.0046373792713549425,77.03366552271194 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.005054729543854303,-1.5707963267949072 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.005648081612007447,-50.74275457408875 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.00604047161212908,55.01976793646537 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.006248263654221708,-23.561989732233897 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.007489618182791615,8.10398163409924 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.007969324468227049,-20.818179597572033 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.008023664545485858,81.99664802494031 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.008287746389032624,2202.693669106024 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.00921560592910418,-0.5126141247746985 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.009843758034941774,-21.670502862121168 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.010553902712509283,5.608488075686031 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.0108288444557606,-1.5707969121313978 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.011469316893492579,17.371199644500763 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.012042717369446544,-1.4723747250159416 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.015342141948837184,53.73278382955415 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.015382438020787249,0.0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.015396693098378864,0.0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.01578565526509977,3.142080934840612 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.017168975631890793,-18.849589525723804 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.017177376523783684,67.63362151854813 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.017492995455801873,73.99830893159977 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.0190340757519322,-0.5381132926265005 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0.02006811762698228,-94.60987859992858 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.020107988000643517,65.98125822538569 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.02099869825514356,1.5707963267948966 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.021726835162212403,1.5707963267948912 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.023435527641433477,100.0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.024670317528000002,0.0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.024728179990906998,77.10660095760926 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.025083203604421844,90.67330890492855 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.025338059587690864,-359.67091570429466 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.025926788172625576,-1.570687120684814 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.026296047881873896,20.87532215199166 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.026313036908395173,29.83464557503578 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.026401991408807945,78.29792162521314 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.028683377105242866,-83.3443389679634 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.029534459529881762,47.12804307003721 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.029757708006273486,32.98674009368993 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.03071424256719979,1.5707963267948948 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.031558146891265015,20.95551374238217 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.03180958925414136,1.5707963267948966 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.031837329327411436,-1.5707963267948966 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.0324266840681394,3.1415928920103884 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.03281356043264312,1.5636853032170432 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.033318765562221686,6.989848791117922 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.033636505929567725,-40.12722209989728 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0.03643959331511087,133.14265126636124 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.036860424985189225,-0.0012053878739662072 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.03701190759423334,23.281023386594736 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.03727614156714465,-1.5707963267948966 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.038854617826743265,-273.23191685587136 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.039835390121691704,-8.377604435474549 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.04018302773045602,35.648860531695135 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.04208518560875523,51.56249784419914 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.04295918567602779,1.570796335514976 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.04324950084550494,20.611721317287394 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.04516007997509405,-68.37675438897443 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.04557517603925454,1.5707963267948983 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.04771970737717346,-77.41086706573225 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.048468872078743175,1.5707963267948966 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.04864035034436087,100.0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.04867499490241516,-34.05587708577154 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.04893574288791064,0.0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.050882955454051484,82.38791520962384 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.05451259552808313,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.0551256129535006,-20.269643338607835 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.05596867360918187,91.106182235622 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.05832039842779846,-2.791272983265762 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.05999996608281244,1.5707963267948948 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.06055528428436387,-478.76790596366004 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.060907602130503787,-77.72597344013067 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.0648028225250098,-18.661487020956713 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0.06781508209437405,4.155003524528419 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.06790619402431508,90.8973948579584 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.0695062986260312,4.712388980384691 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.06989809003028973,-4.712389040901894 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.07011223000225364,8.404922443375145 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.070345605898396,-3.1415271445370325 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.07643876643806259,0.0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0.07694477506713564,8.111982762527578 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.0785072886898631,-0.12096872596835673 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.08076674604054557,-100.0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.08079718522819325,0.0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.08382699581278226,-18.269464567532154 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.08611094138235509,-7.933051227892591 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.08727659017500694,8.309060711184365 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.08928439299768443,-55.97074906854822 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.09003674608259837,-74.9242699594345 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.09029184276834112,39.065591538695 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.09325128617133617,-20.88238388307012 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.09785706163924408,-4.712389036477634 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.09874333059746168,61.10331903410358 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0.10208849362343464,40.302186643592705 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.10640798900517466,21.991434378725504 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.10658188024357584,-19.535405385879734 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.10668894789219605,83.25220544601193 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.10792951805810827,0.0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.10893446557071511,-67.54424205218055 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.10951308826096344,-1.5707963267948966 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.10961441432848329,-100.0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.11090670013422799,6.283309282531042 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.11165168284617755,30.808927756096615 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.11172630641505177,1.6411255077510134 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0.11279369763280067,-1.134648673406841 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.11361434782594938,28.947391235553283 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.11375499968054338,34.289863657593344 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.11608108211767865,-1.0806454419566534E-224 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.11644844514320624,56.317670613603696 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.11855466166652842,1.5707963267948966 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.11908967138309107,98.91457699109895 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.11920993934514729,-75.40135640745983 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.12037812796993706,57.19375449921071 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.12045193124332239,-6.6735765394972626E-15 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.12090839020817057,8.104606105387955 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.12160210437675262,24.593931529685193 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.12201549173420387,-1.5707963201507846 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.12291242356506171,-46.39375965741239 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.124577129580355,-3.2697617161657835 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.13017702720359428,1.5707963267948963 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.13020331221339826,31.716264121668935 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.13363375205293,-1.5707963267948966 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.13434078003625383,-71.53705484408817 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.13562845264258278,9.42868421094323 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.13739897525549286,-31.594313742749968 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.13750012517769422,29.06522779560723 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.1392190827664047,-56.65893090727085 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.13951982618331726,1.5707963267948948 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.13959666945464588,-100.0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.14682566393229365,-420.3817135738619 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.1488573040343104,-48.22093498906136 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0.14973142726697686,-1.5707963267948966 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.15061206411798986,-1.5707963267948966 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.15675223601087995,92.7154933811795 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.15992314733002158,76.96902001294994 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.16524449107542616,-30.16057399539769 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.1664237563747527,8.295213064909166 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.16699954906324876,76.36009592310913 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0.16718898393703788,-1.5707963267948966 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.1672460308812587,-74.79073007157433 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.16896042577490233,84.82300162837313 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.17231072957062077,-83.92712104875557 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.17275211449977357,51.60898897730473 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.1797468101502383,-100.0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.18147563266546154,-43.29199599945787 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.18282126824835157,-0.9936338393305759 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.18306140182853464,21.4277425267999 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.1836783434330445,-52.698045512156135 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.18407653248626374,20.97402486931645 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.18489738923142846,71.50541347623104 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.18548551166679772,28.143842673182377 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.18592374153273106,-64.18337405586874 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.191276932636241,9.886917835493136 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.19161319593271361,-1.5707963267948966 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.1929148667246966,77.0258388758894 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.19340931140070672,-4.71238898038469 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.1935142441314252,40.96621795370364 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.1966334024952053,1.5707963267948983 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.1981266675997647,-23.614668000172003 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.1985151149134936,-0.2279627220853153 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.20426604281877844,78.98077046284907 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.20480308088307453,-0.6854512405474311 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.20896692982612036,20.77542159376557 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.2103755302867114,91.24378794351692 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0.2106580382992357,-0.43434100226569966 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.21137194705385243,81.95851891806876 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.21283033289464492,12.823577744814614 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.21353043179356127,16.63615053490775 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.21532750593348804,-0.010798990816018055 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.21734267926997392,59.69026041820607 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.220310092162352,89.40166169014697 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.22288082724529676,92.1866465867349 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.22412931700549343,-78.09373953291927 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.22487030498813565,0.0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.2250813094427294,38.566832083461776 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.2251198048324294,-0.034067364627048846 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.22753204529198,-69.71854739698867 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.22940442201423317,9.066941718535881 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.2319021806796654,-4.712389345846873 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.24192439258034426,39.07127259856219 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.24340175615193205,22.504082908021992 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.24473511058319647,6.2832005659687695 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.2511401503527907,-1.5707963267948968 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.25225057667265993,-1.5707963267948966 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0.25340602787538546,-99.0552482900783 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.25505482519993516,0.0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.2606926461204534,-129.02011625179182 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.26145450563792905,20.420352248333657 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0.26669641642609976,2.557816963777161E-17 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.26766235095816093,-4.712389378214771 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.26784401445321715,-6.162975822039155E-33 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.269454847397618,-1.5707963216684802 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.2717720189706359,-23.97897406615313 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.27446891124151523,-64.87533979705515 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.27518398160314894,98.25194097604484 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.27791942972940425,-1.5707963267948966 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.2789290194858032,-77.12646201801276 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0.27974963450501933,20.10134711593223 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.2841854034671204,97.70670890028163 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.2903369346334982,73.33100948531666 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.29097332610793747,-10.995574287564276 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.2962058246866441,-51.47858915372343 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.29830658796475135,91.106186954104 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.29864942430324454,-0.013422488420231278 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.29874716959784886,83.32951863186432 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3052421375117449,89.95681016205246 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.30813550896604386,-1.5707963267948966 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.31016958725911065,-6.314435958284167 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3102418469296956,89.89753080355182 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.312450081185503,51.71028833101553 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.31271291195700635,-28.35946761192377 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.316745283400637,33.42379935786801 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3171187660822632,-57.66061086593818 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3178238005134606,0.0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.32251940900709003,-26.584089113078118 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3226427509522378,-1.5707963267948966 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.32464803880190535,1.5707963267948954 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0.3254845034287682,4.7124692627463745 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.32635582991945,49.86850966304172 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3293291298911095,-95.89675514332208 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.33294867928399274,-6.3174603311753045E-176 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3341043945285619,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.33540938485040267,-44.44312654825677 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.33569678799120084,-1.5707963267948966 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.33849253320417705,-31.51249212188378 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3531579071264225,212.05719194136327 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3542800979841666,65.82744411693106 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.35474484187941213,-69.17602676028807 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3595724382147898,1.5707963267948966 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3631821507033882,98.88837410274891 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3648848672427062,76.96902001294994 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.36914142423057544,-31.705877697507546 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0.3691477477750581,-1.5741834211536765 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3694284331622147,-74.51713630626844 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3725068759289101,-1.5707963267948963 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.37597296894834287,1.5707963267948966 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3834885386345862,-1.5132069430421298 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3846653224851774,-15.173273679684522 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.38602433827137295,-20.78819010523501 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.38741172983021777,-75.81257793404544 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.38892012000649784,82.0868458936357 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.38989244874943874,84.15951310098332 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.39101026848518605,-107.29361036106762 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0.39224724994334037,-14.417679608729912 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.39245087175879795,-1.5707963267948983 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.39408865570551055,73.65408393975349 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3944204927234795,-25.89916348077132 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3951140278049238,-1.5707963267948968 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3954084481335084,-21.956567903151125 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.39602256383812506,-1.5707963267948966 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3962679111615436,-43.9821917352202 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3964104679264445,0.0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.3999847568027689,-1.5707963267948966 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.4052115477729453,-10.995574287564276 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.40706076441283734,-63.4958861340934 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.41066992854957507,-5.762016560424644 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.4115902301732801,38.0771037939211 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.415114748819341,57.27050376512962 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.41997118965038505,-25.69037323356764 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.4200582733642662,29.662225612197822 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.42575710446583637,-1.570796326794897 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.42702045903937247,-59.35157060587848 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.42821341975094185,0.07752982489785405 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.4304419326230691,-65.65820353396381 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.4329696198406084,45.152082771990784 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.4334405765412479,72.00432318924 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.43362022633903446,6.283185877604461 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.4364672100115718,26.200226620740086 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.43934524173186884,55.501853216689796 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.443247935657455,4.7801600742412165E-176 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.4435530860556287,2.104427581513349 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.44958619140715483,66.68716913622936 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.45243498928440895,-88.23987841125526 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.4566029733352197,-1.7859177988785547E-102 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.45892262209880763,75.90492863939468 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.4618000492580194,35.415609116133545 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.4657521893519565,32.02057571604308 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.4704928133193388,-6.279262282651828 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.473883548775705,33.9789152790854 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.47479920028148925,-1.5707963267948966 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.47679088897627,650.0346643629322 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.47821915794498776,-76.54555874437615 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.4818713077507182,-0.021159879338030953 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.4852106148285993,0.0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.4884612778494162,0.8129839415064969 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.4912285048060211,15.307515115837504 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.49171920786370105,-0.6832028702463482 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.4918327753044478,57.625660536623826 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.4933143942935121,1.314746024018557 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.4935114092104085,3.405120518650513 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.4964059969450888,737.3166769944407 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0.49673133751564946,20.420352248333657 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.49838270652777705,-18.535462207157778 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.499176848281482,63.237350034420764 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.49994293050217675,-38.50270379793281 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5021755240946557,-1.5707963267948966 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5033069401849396,28.169097419932648 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5042516798829072,0.0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5198611603739685,-6.283186385671334 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5203958707348466,-88.43978713202344 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5295703585370671,66.35833603917153 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5323917088583554,64.91197455254792 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5376007105769105,13.607070244125822 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5384634467711596,53.83280945802454 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5427287503089203,21.9911523898676 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5457487279097735,-11.631533752434692 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5482914760137845,1.5707963267948968 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.552074711501991,-46.92639741703395 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5521272200482353,-83.38235811678086 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5526066389442744,100.0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5533070976101611,-36.201599338988245 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5554071172893132,0.0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5554386865954568,-34.53139020132545 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5565338545179297,71.00608008604432 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5573719241121916,-6.283233839835403 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5574580277734809,88.78427571791812 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5612856893793389,-63.669886415869044 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5621937053538805,35.205535304836616 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5630643445430814,-37.05934632643122 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5631124499398955,1.4181399871104545 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5634612309952363,-1.5707963267948983 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5665996390950913,-42.222358551422424 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5677327602656944,20.420352248333657 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5677897633153807,-1.5726277730826863 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5695278919787526,-32.62371612682645 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5697261418743844,1.5707963267948821 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5811565356473432,-18.662319345526992 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5834735099015963,82.63747469247707 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5842689280327777,35.07549571792828 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5867177606228116,-82.9440667727254 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.5875731031785869,99.90477269713364 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.594435308935153,-1.5707963267948983 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.602087486166687,43.93326545131808 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6257672083705152,15.708193792637427 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6299520084111834,1.5707963261450673 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6304894644291428,26.713156134304256 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6422924995411119,64.57197881115613 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6433621496454612,88.6444510248978 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6510034836476543,1.5707963267948966 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6541189429794984,19.286639885383696 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6571096067450541,1.5707963267948983 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6620337477463647,1.5707963267948966 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6636613993674614,-45.217097396093436 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6644107707247889,-72.10031814149266 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6646300145656328,26.67990268710139 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6650714036252743,54.04748506415518 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6652588725269472,3.142080946393345 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6657452642544203,-71.84459035106445 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6694203119478762,27.163050485402124 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6699857820852664,50.459550039278554 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6765959664135487,-20.634818988900847 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.683740421437274,91.106186954104 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.685452505207259,33.540761089297035 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6860482047010737,61.49511375315172 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6886062713644309,-90.79155114922204 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6942239426050173,-1.5707963267948966 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.6954028542396248,52.09716861144116 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.698987975292163,1.5707963267948966 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7017287036591711,-100.0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7021817194437233,77.2859070654693 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7025155493719526,71.88962026958988 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7106655786615512,68.31074357775051 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7126312857454732,32.87747893422818 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7137510749872804,0.0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7156376529649728,-34.323375603639285 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7184703683681573,-100.0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7217156450046208,28.32832891441874 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7281402142209856,-67.73683664431076 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7283606251287132,7.888609052210118E-31 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7340799653463813,-30.65635486101135 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7379155951863546,1.5707963267948966 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7499095837809918,1.5487459345803245 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7565919881391452,-1.5707963267948983 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7617282750406481,10.203217747941824 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7681179511032723,38.54458574877577 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.770722024533668,-4.71238898038469 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7708120789728476,-0.5075253923339915 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7732038051395513,47.124866370023504 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7756806067783624,0.0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.780332822692282,58.88994204786536 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7811960893102554,1.5707963267948968 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7860279076231276,-1.509819277237869 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7862713834674102,22.48832451778418 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7885391178330758,81.92901019403874 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.7911646526141247,44.29128668031231 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8054105700377876,0.5245839887890545 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8104531449537761,46.71763602838263 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8174390779264902,82.86466306316719 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8277692032520635,-1.5707963267948966 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8285429538469962,720.6643575018558 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8300990148943822,5.141592655777229 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8336537154151591,-10.447045733760174 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8342395859181481,62.8776232129744 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8345741181663162,-36.42605776749146 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8406525130183445,1.5707963267948966 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8413970758817775,63.44895995660838 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8475112128176538,44.49735774151029 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8554171788647578,-56.56355056431748 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8561194282403004,-78.51686411714543 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8616965638613525,-1.5707963267948966 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8644971744321343,62.24244807823946 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8654221448221967,-9.113436858896577 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8698888475379323,-18.14655919697461 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8703960414001266,-13.309232026465702 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8746538272563233,3.142081296477434 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8816215000031769,1.5707963267948966 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8839776739245553,90.1823603842509 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8885108239477102,0.8137583014164451 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.8942522890288761,1.5707963267948966 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9078033085061948,9.658710899604932 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9089507015374068,-6.283194946833652 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.915150253931604,1.5707963267948966 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9177428773767374,56.014739922453884 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9192473551672331,32.9433847629648 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9229465074335348,-1.5707963267948966 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9247834056661128,1.5707963267948966 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9273036371781618,-1.5707963267948966 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.928333117781798,73.4471655689318 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9301447209045488,-1.5707963267949 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9418575604260131,80.93150431689787 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9425572386342231,-57.42717676590391 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9445042694367478,4.0144860754905797E-17 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9489988428718394,4.196186701055083 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.952345263885909,27.783950333751335 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9574701655360678,346.57518706199033 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.964740393419113,-42.758207785761016 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9704720860917355,71.93766142480237 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9705744171588175,38.783832338086796 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9735895024203786,10.695574439523426 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9752953963270578,39.150307426914935 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9758641900950109,1.5707963267111327 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.978593673626535,0.0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9901872894007866,-11.15432228875197 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9905092582585889,1.3763855789617268 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.9919802866460883,-2533.3197139127037 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-0.995632241266172,13.041448986051176 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-100.0,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-100.0,-0.6632894537868832 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.005617696441831,-54.7958043458 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.007497244652171,6.92795604836828 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.011007639613643,63.4259307310183 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.011410763150732,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.016637424189838,-78.98729318583527 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.020605477394955,-63.48419238004567 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.02127645088813,-44.63671113224566 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.055964959120999,-43.90847053548268 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0100687931487367,4.712388982514357 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.10503703832019,-30.895360845929687 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.114892611526907,-79.55704299179324 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0162440739937249E-16,27.001866961939783 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0164125907832355,-8.645163535653227E-224 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.183455337347093,1.570796326794896 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.205920599642578,-93.26445721871309 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0222365008746295E-4,-4.713904880933258 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0231414144709512,-3.1415926535896253 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0264320421206583,37.69911184307752 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.2839845892737,91.80249125513038 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.293241658692414,-72.25663150940312 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0294728505178483,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.029590856243832,82.4965112000225 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0301002193680544,20.93187484837149 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.307629982346564,-91.22157589051093 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0339414093809753,64.96791035618254 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0339757656912846E-25,-91.10614099423147 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.347495897664329,26.62789857268712 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.35525292226798,0.008887704123236029 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0355302261342107E-9,-43.98452087974215 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.371847283036885,0.24080761946155121 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.393850608961953,0.0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.398929292788804,63.04123674475136 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.409598190276167,-100.0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-104.1103594419631,-3.0604737069599217 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.042120374069711,-20.721703920253052 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.425090492474231,0.1066864158906245 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.436934927340964,-9.67845404046328 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.449108756696603,-0.48232255320618966 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.047723307832526,-61.26105674500097 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.48522526089403,-1.5707963267948912 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.491709210628464,-532.0939840385352 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-104.9271830021981,-993.1128008687039 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0494138675823237,-6.440282327373406E-17 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0525686128498253,-92.6769832808989 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.52692169568121,-3.188535500576746 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.543128573759034,-1.5707963267948966 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.546116623658968,-1.5707963267948966 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.55168568578857,-1.5707963267948761 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.552176257846266,-97.28441085275843 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.574612438246447,-18.275130427706674 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.589139534183388,-49.105083584478095 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.62444775465515,-4.71238898090028 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.629058965340091,-29.160896976329703 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.630367589592993,-97.96451510109547 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.633023601148821,-50.147806228068966 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0648335729524867,1.5707963267948966 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.65289712000391,-53.94257317710529 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0676386689852917,92.07558238612984 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.680462530948233,-76.90241528441156 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.680587431442191,20.724994211068157 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0689778876630271,-44.095011413753824 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.693561523119774,-7.342766776151926 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.698910285549303,-12.807182000565891 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.717109252114398,1.5707963267948966 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.731689118715735,1.1607443701196866E-15 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.744793963576642,1.0872780664488338E-14 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.758759347343778,-86.63138563775627 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.763511594521475,-28.955124586629395 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.766530536944863,-11.503755221336778 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.768059235785145,0.3871485861685272 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.77018081313626,0.2547834564826771 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0770503109495742,-1.007053170100738 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.770734231637931,1.5707963267948966 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0774360679322068,1.5707963267948966 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.829710714216759,0.25185580190749335 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.83382484594946,-67.88583699502142 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0840288710239257E-12,78.27400766080095 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0842021724855044E-19,-67.54460778047333 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0842021724855044E-19,76.96902001294994 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0842021724855044E-19,-78.53981319485783 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.844715704773463,-4.712388980388066 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.874215100394792,-55.123167700021746 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.882905128086446,-77.27275730388655 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0915158065555781,16.143164207667937 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.928217040134715,-66.20565561230492 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0932520437719435E-18,31.986722833886272 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.95628493148361,7.853981860593848 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.0967625549666804,-4.712389980548421 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-10.967872398567835,-4.71238898038469 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-110.21637646546365,-100.0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-110.50837651260478,-1.5707963267948912 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1064988840283871,-12.56832630326774 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1066592355418644E-16,28.502964003718603 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1067030208738373,-70.40499485795478 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1070375352265813,-2327.9141643347284 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.108379386317939,-38.800079426885816 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.109063887371042,32.79621354833293 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1102230246251565E-16,0.0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1102230246251565E-16,-1.5699828319699811 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1102230246251565E-16,29.74107421506285 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1102230246251565E-16,3.092047754294171 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1102230246251565E-16,86.00666264840197 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-111.15524556852986,-9.49297538438628 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.112894040348658,27.726540708845135 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1145804857810653,-90.71736340069275 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1146109935983544,6.287091557183932 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1150917549580184,11.908402707415684 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1179575674291904,43.239498729264994 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.124954941776389,-10.995574287564276 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.128200726691646,91.48733449331093 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1293676956113634,-1.5353167773369851 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1298828143760218,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.130305458108341,29.777157347274255 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.131572586903642,71.03763466724178 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.13462729643047,-0.1336968575773616 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1361668293577132,74.99239054186174 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1407238106954258,-70.71212240474632 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1409208695530004,50.720297440425036 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1495648609535116,41.90474715499752 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1534433716977972,-127.06542013870201 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1593803897500403,-69.54364324133282 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-116.67729256124369,-151.02599585755542 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-116.75281230308653,-89.97269186626706 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-117.39245010494223,-23.059177592631983 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.174379913456674,-43.37884996160941 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1758661753525628,-100.0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-117.80270532367048,-2.7721230775297277E-5 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.18007907142092,80.51708868290591 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.183344623334785,3.141600282984334 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1870517146557098,8.103982314225478 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1898190670107116,-0.6545366932350021 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.193301584337803,66.82308326411086 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.1970860719245122,0.0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2020491576770993,14.318413473678405 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2037805399357184E-6,-15.674321153538642 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2072614984219824E-12,-21.453195741894643 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2116924948300325,76.53145862878844 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.216293272618329,90.0131569895988 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2195574285042915E-7,-144.52894304143683 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.220111140655955,-1.5707963267949698 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2202049198463873,55.58256181092191 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2223018503603425E-6,39.26707308821686 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2231836237649223,86.08548481252143 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-122.66834546599036,-92.00069518583562 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-122.79565538128927,-145.60243815448788 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-122.8999199161501,-44.01834837839884 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-122.98202406918801,60.49571696282095 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2325364563020778,136.25431340803016 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.232595164407831E-32,-1.514872270820627 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.23704237419029,0.0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.237468770159921,7.904333759362032 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-123.86125348348313,-273.3635094949216 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-123.960199384348,-171.60386148617545 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.240724389413387,-43.120184453231246 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.241467458729439,42.78529759417425 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2496200212564474,-1.5707963267948966 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2549540076674224E-15,17.278759594743864 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2594315652147032,-94.96931010452813 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.267830901176525,94.24975108382192 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.274025413916911,12.56637086957011 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2747788601307208,0.0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2768608282878877,1.5707963267948966 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2769306097606932,3.1751979401753943 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.277462877467201,12.618968673602394 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.282868695472034,5.141599382485253 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2854512820841624,-1.5707963267948966 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2859467591488083,57.264572093996435 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2892314048915936,10.65282292521248 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2893475584478689,1.5707963423136846 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-129.1105656072554,-85.11359151275254 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2924697071141057E-26,1.5707963267948966 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2924697071141057E-26,-69.11516047184742 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-12.928329463945104,-91.99643217461009 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2937215842365914,0.8545141091249544 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-129.72145531116823,0.8251983796332716 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.2977999742003774,28.359158680350898 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-129.85589473402567,27.72918649743592 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-130.06593169674872,-142.139200851379 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.300880144510659,17.278759594743864 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3009480647397176,-26.43654643491373 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3056953957973816,8.853980565672366 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3071604527447247,-0.2332010168307388 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3087642167679472E-6,28.076511856057305 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3098503194023254,-94.64658858121034 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3104703850284594,1.5707963267948966 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3147519958753902,-6.283201543597357 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3182301497348272,0.0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.318278419009768,-23.56194490192345 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3234889800848443E-23,-1.5707963267948966 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3242062520050608,-1.5707963267948966 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3252540743982777,-70.13294340706837 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.33040678743059,42.49891709923377 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3330321955231754,1.5159081237888805 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3345364086604237,-1.5707963267948966 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3439463843260724,77.09613727107728 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.343981948281415,4.712425533647672 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3511057506711914,1.5707963267948974 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3517960141472745,-100.0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-135.2409453856459,28.109690883285964 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-135.50997282278885,-13.142225918050972 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3552527156068805E-20,-42.411500823462205 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,1.3552527156068805E-20,84.78230217914076 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-135.62644731440523,0.11804512742183548 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3586689297089942,7.273661547324616E-16 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3618053257806797,64.00166930218614 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.366215459155125,-45.27519523500398 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3667337715861834,54.16429700252166 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3677770246359706,220.43701713820334 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.370672532874931,-30.351903752024256 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.370937164688292,90.36596550777584 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3709419735548153E-16,-8.475032515120613E-25 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3749268689085863,37.34808919156221 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3779979021029733,34.94137026431832 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3787282590260692,-51.11021827598774 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.379609353372226,6.048125501668506 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3829426479810858,-89.59952796637837 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3833474507759451,6.28318578768148 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3877787807814457E-17,-12.56875063588781 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3877787807814457E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,1.3877787807814457E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3877787807814457E-17,59.69026065713897 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3893611010387448,-4.71238898038469 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3901804455431135,1.5707963267948966 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3905303962235793,0.0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3939831211077918,109.95871942757512 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3956228641350799,-17.997794415609246 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3964071815614418,0.0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3972867957493007,0.0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.3973779450915682,52.34972842911578 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.398453335400669,3.1416755760533697 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4028050053529206,416.23555759679533 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.407542897999923,-107.54957764980024 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4134159245868745,147.65434724708038 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4162045546669624,-8.103982377191494 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-142.03606753156328,-20.859883312016663 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4210854715202004E-14,-32.27648224578867 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-142.1346446108316,32.714719927802065 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4253454885723212E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4285083216961574,-62.28348907285979 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-142.93928906816052,-1.3117308311122092E-7 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.432351711464181,3.1415926535897953 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4337742510161795,6.283185307179593 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4344158646126586,17.09501662649214 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.438930870133999,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4427790885317797E-6,-99.60222426780159 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,14.429225596149656,-82.25174468371492 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,14.429237024655322,-1.5707963267948983 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,14.429445530887783,-6.866386890153909 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,14.429942466947914,1.5707963267948974 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,14.431522847250669,-1.5571048527601308 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,14.432382871004371,1.5707963267948966 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,14.43843472890476,6.283555646345027 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4473955303115735,-1.5707963267948968 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.449218918294889,14.53140676153523 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4518575012191954,-52.299866285145725 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4531610767972964,-82.03964466531072 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4562380508126673,34.84894270866944 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4572115787688684,85.48727395500549 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,14.585812515991805,68.39457891104297 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4694845159604268,53.40707511102649 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4723485074732086,-40.21197733540712 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.482246807018136,331.4317346269391 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4825465989304358,87.96462439418052 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4830188535443785,-56.959886853518384 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4854893422202515,-20.494167380408385 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-148.99390328637148,-17.585994378289165 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4903171801967362E-15,-11.123774735461339 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4903198690702388,-1.5634932425166366 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4911464951289581,4.712388986603394 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4912386419459982,7.273661547324616E-16 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4925027501537447,54.93043950424454 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.496133763749045,0.6694124396894721 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4967898651211333,22.79668630609838 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4983286068467732,21.086386485225315 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.4987715853986052,-1.5707963267949054 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5038610447891045,82.05576907788728 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5051013392408814,89.66646023910934 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5090484675236482,-78.12289367944531 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5093697715129029,66.82452326420236 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5111532705357362,-63.58296720074084 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5123598217734475,-0.5068467194859068 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5168485234279938,-1.5707963203059825 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5199893974857914,-1.5707963267948966 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.521047106783615,74.92599886587283 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.521980949149879,47.81894284552691 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5234196273305676,-38.3711038420068 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.524840383909213,-2.2804246405437506E-20 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5261928608676223,-1.5707963267948957 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5287755158484118,58.8263939081761 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.533433306390923,66.51664145592065 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5394219786858354,81.02947957189832 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-154.06258382880688,38.286913178373396 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.540813535954101,47.17465830114921 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.540968282683351,-8.179738964704713 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5412408236877357,-50.91447290762339 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.542964760958154,1.5707963267948983 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5430546873550843,9.424795698933659 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-154.49783602851466,2.6365188348073473E-21 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5456157016860657,-4.712388981032588 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5460128080202404,-1.626758584645464E-15 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5465812351698172,-82.17252385836544 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-154.71472077683853,75.48240631679249 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-154.80622132561473,79.92965250178557 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5481299123440997,85.18467724457886 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-154.8265898810199,13.55041617621372 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.548353113925458,-96.58012201942051 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5485349346921484,-46.93851631747779 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5499548408843253,-30.55968741931197 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5510431836321275,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5517935568502077,15.3824785731813 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5531387287070737,84.93962645576889 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5533737978437145,-69.35474680678271 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5559476555841,0.0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5561546158578188,-100.0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.556487192832651,-33.135257403799564 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5571228845960685,80.02082374863846 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5588733300387498,42.023857252714166 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5596819070439873,1.5707963267948983 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5618412398395756,69.44100938552737 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.563063458445235,-8.103982054407828 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5641796713679759,3.1416027538847486 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5648574786837193,1.3338123137796802 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5654596215858259,-94.73542026279758 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5658793223291976,21.991273240042585 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.565918833494927,73.82742735936014 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5665184828561067,-0.8314718572507647 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5667764756440248,18.460837333910277 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5672327238557553,96.3408047121631 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5682970745758866,1.5707963267948983 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5703666935838552,65.2386790993688 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5706694950038058,-582.753371086388 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570736132312831,34.625475752225555 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707812959979957,719.6774777288169 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796194093033,0.0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707962951235104,-1.5707963267948983 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707962964245392,3.1416011443249294 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963226084167,1.041271603207827E-7 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963238621137,-1.5707963267948966 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963246732903,0.0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963257501991,88.53141585369538 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326074883,-70.45887385816476 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326201624,-26.884054182242977 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963262759508,-26.703537555513243 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326303695,-1.5707963267948966 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963264286278,85.44825900326148 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963265253009,4.440892098500626E-16 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963265262235,27.125503393530966 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963265518345,-90.77045787881961 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326580329,-0.8170027910888678 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963265945248,88.0651383369653 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963265988698,-1.570796326794896 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326613572,67.37185012330303 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963266544933,1.5707963267948957 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963266621168,-20.0344628511739 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963266757894,3.1415930104630085 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963266982623,-1.5707963267949054 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267149567,-72.62888794583267 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267396587,132.2088688388046 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267576577,10.183232222092446 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267840543,19.686495598674412 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267915794,-33.277145378392476 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267926672,-8.251611677083375 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267930882,-1.5707963267948966 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267937173,-1.5707963267948966 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326794358,-20.768631275584177 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267944973,-1.5707963267948966 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326794558,-32.58673710123202 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267945595,69.99289626865234 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267946627,91.55226500227072 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267946676,59.51770705490404 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267947036,1.5707963267948912 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267947838,41.057093296610134 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267947869,0.5702066733437509 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948095,100.0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948266,26.16046264884193 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948377,81.68140899333463 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948397,-92.6769832808989 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948486,1.5273757496784857 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948706,1.5707963267948983 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948708,-51.36632045382517 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948732,-100.0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948735,-33.95488290686279 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948737,-42.44251225190195 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948764,1.5707963267948966 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948764,3.0846974273316917E-179 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948772,66.56417934371933 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948806,1.5707963267948957 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948806,-26.06892916911211 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948832,-19.22325395098501 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948832,6.283185307179591 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948835,69.31419753911744 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948837,100.0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948841,1.5707963267948966 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948841,-18.857385350440108 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948841,-76.49932990426005 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948841,91.97329938815086 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326794885,0.6293508516675347 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948857,62.01406164189697 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948877,-1.5707963267948966 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948877,1.5707963267951615 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948881,-45.79149441444418 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326794888,9.00625913069089 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948892,-63.83508820959778 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948892,94.29974957849247 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948895,0.0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948895,-144.66455638897168 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948897,0.0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948901,0.4907737960949724 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948908,3.7199091698316007 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326794891,-1.5707963267948966 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,0.07436719732291586 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,10.74449321874799 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,10.777884674626108 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,-107.95248052648216 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,-12.80351923521279 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,-140.95799962045288 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,14.699152344803 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,-14.83117316236925 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,1.5707963267948966 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,-26.026861986595172 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,-26.720110212483355 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,27.00302147303057 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,31.461457412294255 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,-38.93959434852425 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,40.84461077102952 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,42.2515879348874 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,4.2333129950367483E-16 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,42.55816176048995 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,-472.761641749576 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,47.603106430891934 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,-53.02718787535771 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,53.40707511102649 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,54.92923689668146 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,55.47725114428755 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,58.70174148051876 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,-59.1449137837835 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,-62.422670956303435 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,-6.28320056597078 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,67.17898478731419 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,74.05653936413091 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,7.417475782596924 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,75.89841195098822 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,77.37409013951677 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,78.7948250114137 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,-82.19041717701347 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,83.25237626558234 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,90.74588050412774 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,92.08449715814291 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948912,-96.66683332602346 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326794891,84.21583851959437 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.57079632679489,26.90640100768522 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326794892,81.2098215093453 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948928,-52.15697893054298 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948928,57.92451360509564 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326794893,-18.89157108191876 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948932,147.95067154488103 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.57079632679489,36.042848333484265 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948937,-20.95924531557121 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948937,-35.34776864184941 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326794893,82.22230002058922 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948946,-14.54433695967758 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948946,550.659458326563 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,1.1588877627024141 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,1.4724834191577383 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,150.9553202309323 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,-1.5707963265334137 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,-1.5707963267948966 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,1.5707963267948966 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,1.5707963267948968 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,28.00896549987263 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,-28.0952458838761 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,-28.72606031052517 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,3.7249002271029455E-19 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,-37.798187089057826 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,386.9956185848015 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,-44.248305830230606 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,44.54084105478745 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,-47.11759039517614 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,-48.546662344008794 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,51.73361401851224 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,-52.882869893435476 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,58.844561022660635 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,6.28416188798896 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,66.25687120651506 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,-68.24622604577374 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,-78.12521397441475 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,78.44082868917856 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,-88.98756750999812 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,-91.89403158781488 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,-92.76855155786474 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948948,9.927867064709535 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326794895,-1.25323846204818 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948952,0.9934736385129804 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948952,-1.4354072185780886 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948952,33.85504988342759 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948954,-48.92484479737246 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948957,0.1640212006436259 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948957,-1.5707963267948966 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326794895,-73.09722677387762 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948957,-390.52981256726986 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948957,-45.97555617412059 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948957,46.73479180497115 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948957,-4.712389131545204 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948957,52.40640100251784 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948957,67.32663900563986 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948957,78.47957285365197 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948957,804.1359870186546 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948957,85.05304555325756 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948957,-86.66708181680242 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948961,0.05246029621965967 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948961,-1.5707963267186444 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948961,-1.7534474792067224E-192 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948961,-21.86653635354342 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948961,-30.271428852966434 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948961,4.712390608559192 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948961,-5.212389238972 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326794896,-1.5707963267948966 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948961,65.38160357885626 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948961,73.0482210072186 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948961,-78.31684929352824 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948961,-88.77159239219465 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948961,-91.10613868422489 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,1.5707963267948963,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,-0.07446143829370366 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,-0.2812339135099164 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,100.0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,1.0057387013579402 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,1.302181580366451 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,13.0743536244314 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,-1.5707963267948966 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,1.5707963267948966 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,-20.421913529546465 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,-23.498585968511627 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,2.710505431213761E-20 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,28.108428718214803 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,30.32573894681792 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,-31.324860523562606 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,-34.69071585748683 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,36.96645212739705 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,41.523015526370564 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,-44.52184874457132 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,44.69831924811069 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,-4.956814594865297 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,56.32030536783146 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,-6.283200618800722 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,-75.39834575688478 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,-75.7809803334215 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,-77.8851166468175 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,-82.71038080337973 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,-83.00352951522947 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,-83.50147523427277 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,85.20715613409845 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,-90.63663807194072 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,-9.547345943260282 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948963,95.56258082730315 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326794896,-40.46610677120305 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326794896,50.68360546333068 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326794896,-5.141592653685149 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326794896,-56.669889244816574 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-0.014356987207531448 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,0.03528036104921206 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,0.045799962159082615 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-0.04913528978713739 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,0.05936187257366485 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,0.07099566335549237 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-0.08576670546592403 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-0.11321077213215945 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-0.1439454359827903 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-0.19533320826937148 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-0.19609583276304832 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,0.20939178184410367 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-0.23857521916581345 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,0.2863272373395607 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,0.3765475585853468 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-0.3960896544782536 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,0.40202847848365186 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-0.4038093305226651 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,0.4073276244987739 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-0.4253598763692281 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-0.4440047064316108 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,0.47510199612936677 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,0.49931381699457417 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,0.5460930658911666 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,0.558881829119136 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-0.5990328851627993 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-0.6439569518282414 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-0.6535514652463074 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,0.6867030527532645 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,0.7311211274258083 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-0.7357502588906555 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-0.8363734849700967 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-0.8618370618627162 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,0.9050375380366065 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-10.240381659943147 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-10.340755296083046 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,10.37072123491265 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.0551968450286413 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.0624740865998277 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,11.422793643109351 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,11.456711325354107 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,11.491927174440832 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-11.653684081078731 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.1704190886730496E-97 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-11.718296425918282 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.1755879526358115 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.2086506274818622 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-12.119329605486069 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-12.231345926325858 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.2262398028143093 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,12.40590129400612 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.2513019344894381E-147 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,12.566359605829893 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,12.566370582792786 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,12.566370613835325 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-12.566377101696215 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-12.56650412314369 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-12.568323859363723 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,12.83332882527894 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.3168023101905513 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.3463281856188294 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,13.515507120941523 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.3758210268297398E-135 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.3780652929318338 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,13.895236653684567 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-139.22347716582055 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-14.087857300469267 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,14.137289038180027 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,14.45034295368913 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-15.08860905163533 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.5096146318854373 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.5356895374291261E-238 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,15.506578656743216 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.5583654349726828 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.568252136108714 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.5707963121930388 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.5707963221474743 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.570796325608897 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.5707963258765527 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.570796326502654 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.5707963267947704 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.5707963267947915 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.5707963267948806 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.5707963267948817 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.5707963267948886 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.5707963267948908 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.570796326794891 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.5707963267948937 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.570796326794895 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.5707963267948957 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.5707963267948957 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.5707963267948961 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.5707963267948972 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.5707963267949054 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.5707963267949223 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-15.707963267949895 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.5707963268089005 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.5707963269470093 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.5707963292082614 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.5707963328134813 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.5707965649778437 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.5708040014055815 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,15.954842256440887 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,16.018353180923782 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1613.6078785326958 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,16.17633793421041 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-16.499607125249412 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-16.645895274425555 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-16.850020510763613 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.688508503057271E-226 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-17.06481353374157 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.7133069828023163E-15 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-17.144201296118105 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-17.27875971395373 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-17.286697072543802 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-17.83207051681319 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.7869661803921844 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,18.041946561170377 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,18.465700983172248 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.86137214358631E-14 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,18.849555897625162 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,18.849555921528992 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-18.95655276782492 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,19.186208300034906 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-19.510349813979946 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-19.73147680039802 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,1.9742063534922827E-177 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-19.74385657822505 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-20.150677695994546 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,20.541756699893057 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,20.64318621695928 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,20.694352783232585 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,20.81302760281904 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,21.278377684630776 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-21.313131274130754 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,21.35708868580491 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,21.881543930061184 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-2.191809349008403E-193 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-22.369700800799404 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,22.438921331562085 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-22.761120683883433 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-22.90100528546455 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-23.283430183410186 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-2413.2594730010833 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,2.465190328815662E-32 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,24.75016570036277 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,24.953162900261788 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-25.626124981222862 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,25.65352911396378 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,25.76149272444469 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-25.833104124257623 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,26.37189156354664 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,2.652834815279272 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-2.715426954731162 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,27.233139773741087 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-27.37066696563935 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-27.59076538887477 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,28.018854843144254 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-28.37914470523799 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-28.58398986759832 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-29.088355135891746 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-29.306739491338647 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,2.9636535312676053 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-29.845130042904763 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,29.845130209103036 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,29.99119322775894 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,30.112231572140338 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,3.1415926535897953 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,3.141592654412531 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-3.1415934655836555 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-3.141594219489513 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-3.1416536887460453 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,3.1418949278926056 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-31.419163383354082 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-3.142080956136993 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-3.142081107376004 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-3.1497953062192257 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,31.50324859082268 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-32.39472020259802 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,3.266592653916472 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-32.97091739363303 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,33.04110787847084 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-33.041237008621906 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-33.18494148454867 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,33.734214187975326 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-34.2072930927514 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-34.42909343821033 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-34.55751918851486 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-34.55751918971882 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,34.671419138769046 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,34.92846573053424 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,34.99440530677822 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,35.213062985824365 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-35.584653884060984 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-35.92914344677952 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-35.9444708575296 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,35.958674045089445 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-36.12831548751904 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-36.128319061640205 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-36.441254586363605 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-36.678418503059554 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-3.6957164703164285 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,37.00988638467686 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,37.235944519043386 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-3.749757614807194 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,3.751492407013476 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-37.94103415547164 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,3.796331988831094 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,38.11685544132654 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-38.75952497337738 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-38.76399619054919 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-38.90879140560931 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,39.26998311164089 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-39.97984059776525 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,403.00630861369586 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,40.374804188405406 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,4.047474640071556 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-41.01091618493383 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,41.28688465003816 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-4.1415926537777175 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-4.141592661133591 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,41.46583381882584 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-41.58434419252879 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,41.778954839721806 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-41.84236993281963 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-41.941066380772696 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,41.969165037728835 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-42.025511508422284 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-42.03940991290811 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-42.10367306314227 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,42.15106995118831 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,4.2212712576431773E-227 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-42.411500823436356 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-42.52437716225694 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,42.64359627297566 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-42.990746666614015 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-43.416427033625865 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-4.366990771082428 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-44.04479715025711 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-44.31800853030952 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-44.37664881195753 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-44.41988776139917 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,44.502878139419295 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-45.26672754969891 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-45.53376201820915 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,45.613330132500344 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-45.63349328113444 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-45.689948328584485 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-45.82625371643279 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-45.911709404941554 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-4.616785709222505 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,46.23486104360194 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,4.654560904037865 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,46.7282451381634 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-4.67376253373393 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-46.92970818986299 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-47.056175843739545 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-4.712388980383529 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-4.712388980384442 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-4.712388980384758 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,4.712388980444523 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,4.7123889806876065 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-4.712388980960611 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-4.712388981510575 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,4.712388983933872 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-4.71238903269932 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,4.7123892354848405 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,47.1239511400951 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-47.85059732703957 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-47.914367705789985 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,48.41539639374687 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-4.850942836404129 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,48.619846803512104 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-48.6947013982928 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,4.921738593793108 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,5.0148456570290716E-17 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,50.370594429700304 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,50.60188738172208 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,50.630746454441635 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-50.904276951041915 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-51.00340874477831 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-5.141592653591011 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-5.141592653601345 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-51.48495145582475 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-5.154284492439075 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-51.70745462748665 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-5.2158378665208005 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,52.20258947034401 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-52.28880650601717 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,52.5999073929651 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-52.68749509487054 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,52.871060663310885 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-53.40706082931464 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-53.40707511032796 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-53.4554880173014 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-53.465557040605916 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,53.54291879688796 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-53.55122084670138 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-54.12327172394858 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,54.61665003233002 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,54.72595400942292 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,54.7385632344703 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,54.82185721030569 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-54.971355739765386 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-55.15559117295992 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-55.31565983256628 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,55.423925257806246 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,55.56198363333879 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,55.65419118745511 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-55.72238089217505 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-56.432581984075455 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-56.54869839039814 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,56.709101329146264 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-56.95547021625147 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-57.11540370324844 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-57.17219400791556 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-57.51334365836638 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-57.75125443197949 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-57.91998437744546 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-58.119464091411174 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-58.18305755906246 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,5.8586764883700795 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,58.63232742273476 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-59.42787969935279 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-59.58845222204092 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,59.690260641717295 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-60.16696422166827 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-60.3132372858954 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-60.39588990493902 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-60.40648652161434 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,6.041149246359018E-16 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,60.67142925739535 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,60.828001866777285 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-6.083799735999709 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-6.094320431979057 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-61.316357557454864 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,61.560940233309196 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,61.68626983783344 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-61.86844162010553 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,62.04138582568214 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-62.179565454105386 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,62.59793088601182 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,6.283185307103299 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,6.28318530739836 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,6.283185341055114 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,6.283200565968854 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,6.283200566006971 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,6.283200734917967 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,6.2832017043459025 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,6.28320531448927 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-6.298810315252113 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,63.73632566308377 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,64.03483552495915 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,6.428389343688561 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,64.40295088188815 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-64.4334475850518 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-65.25482127317282 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,6.533653706495272 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,65.34694297161823 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,65.36783441561766 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-65.38973230188478 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,656.5928642458538 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,6.602002064978519 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,66.07889373010926 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-66.09188551336574 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-66.09515795847763 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-66.54424201332344 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-67.52580354575298 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,6.761287293951995 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,68.1646448200763 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,68.422836370304 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,68.64375851291724 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-6.865114677127006E-17 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,6.938893903907228E-18 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-69.55456219982341 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-7.015155018397214E-15 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,70.50663545053561 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-706.1961404138175 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-7.076572794062157 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,70.88890823094647 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,71.02405215190485 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,717.2008148998326 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,71.87799634654655 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,71.91192469104968 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-72.42576597352661 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-72.4721665006608 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-72.50663103256524 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-72.74176908775054 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,72.82961205506233 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-73.30538794055495 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-73.45398657842364 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,7.3515723499540435 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,73.98591457133942 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,75.12537717952 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,7.533878955011558 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,75.42070398941476 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-75.76846845817909 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,76.00720028076702 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,76.18460951094197 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,7.675064372349322 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,77.0133305178157 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,77.16033794023133 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,77.2090829086653 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,77.21591089558495 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-77.23872186122071 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-77.3991688331111 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,77.42169926036607 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,77.50757939220594 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-77.60315982261918 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-77.64185678635104 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,77.69548620713144 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,77.79008083726343 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-7.794726970816058E-17 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,77.99419972790898 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,78.04316471097493 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,78.15791650686114 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,78.20031716533306 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,78.24601715835585 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,78.4842928633692 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-7.853981633984993 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-78.79504240580732 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-7.894598711416851 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-79.45310159200031 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-79.68062585834245 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-79.92709988030383 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,8.006963354582135 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,80.33149952716131 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,8.103981633979332 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,8.111265622844058 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,81.41613708578838 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,82.02885916017055 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-82.18094499751182 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-82.3059890964077 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,83.07483694552266 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-83.86334400551668 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,84.55949548439798 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-85.06980743157328 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-85.11552427978891 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-85.53890759498819 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-86.39379789381019 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-86.43837707886688 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,86.71848274320034 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-87.70383234564585 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-88.08959430052015 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-88.75391842761769 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-88.88167023118586 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,89.61522626623733 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,89.71163876614885 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,89.9981932525557 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,90.06576760406791 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-901.2586265691124 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-9.016580681431383E-131 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-90.27734993751395 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,90.32485824088454 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,90.3592255961808 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-90.59645910354905 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,90.75158382304782 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-90.85251899793823 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,91.07632178527871 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,91.11776085466505 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-91.7603592312834 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-92.67697399697384 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-93.27817694023406 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-93.41665195356828 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,93.56883261873239 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-93.59882779861637 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,93.67828212017014 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,93.90027186173957 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,94.1952565421854 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-9.424812016260853 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-9.42490091691248 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,9.425088929942667 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,9.428684212711271 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-9.428684223617651 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-9.502159625537242 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-9.512571227892975E-16 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,9.536492135535724 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-95.65240284942571 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-95.70656878833161 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-9.57137288999905 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-95.82646028015996 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-95.96231250208686 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-96.80363704444497 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,96.83094433642214 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,96.86886069172654 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-96.94144795214079 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-97.20870627164607 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-97.45541478318712 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,97.68629258301883 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-97.79493472571441 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,97.82367789907954 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-98.1734364254972 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-98.23296884828837 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-98.41943936985979 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,98.67388397750899 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,98.93184462097814 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-98.96016858807849 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-98.96407490063888 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,99.45375699145957 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,99.63901369166226 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948966,-99.98538118194529 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-15.707963267948967,1.5707963267948877 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-15.707963267948967,-80.02008384618686 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948968,-100.0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948968,100.0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948968,-1.5707963267948966 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948968,-36.634459338406955 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948968,-3.8343440662486347E-35 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948968,-4.2554033287816555 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948968,64.91437166513624 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948968,-72.44766345004649 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948968,78.98241867857864 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948968,-9.34051864315865 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.570796326794897,-100.0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948972,-18.850532484080443 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948974,-1.5707963267948966 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948974,4.053943015677348 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948974,4.111118508174114 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948974,80.21861968891858 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948974,-8.103981665497207 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,-100.0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,1029.8692089787685 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,13.702251174223434 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,147.28460338063712 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,-1.5707963267948948 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,-1.5707963267948966 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,1.5707963267948966 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,1.5707963267948981 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,-1.5707963267948983 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,1.5707963267948983 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,-17.278655413266005 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,-2270.300474106733 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,23.47132496349485 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,-24.16617027993766 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,-26.093467724812243 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,-26.424085541362388 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,32.619851345499825 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,-38.01108771548758 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,-41.797965072746734 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,43.232260232689605 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,-46.755381729327695 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,-47.59820761495794 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,-57.57369845498121 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,-64.66153176129995 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,-7.459982701567782 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,77.44707410765868 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,-80.57352512039051 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,82.01395334114312 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267948983,-92.70651216551417 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267949006,100.0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267949017,1.5707963267948966 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267949019,-32.87685517804786 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267949019,-437.301410039601 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267949023,1.5707963267948912 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267949028,-92.66564967723703 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267949,-8.55186189684595 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267951188,-66.96242835673874 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963267951843,72.11590876631355 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963268022735,32.09212814196121 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963268134888,-0.02365782648457841 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5707963269673788,1.296270910628435 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-15.710095565681286,-55.314488799641445 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5712197597644633,2278.6468496616426 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-15.719967625692032,-13.923680026954798 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-15.723255106324062,77.14410741250725 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-15.76934464162725,-6.28330739767979 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-15.787483864926932,-47.93336303062801 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-15.813800342326886,-1.0372311190662344 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-15.839278164422618,-0.4496578475239139 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-15.852778820298623,-47.22083180108379 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-15.876955857542946,-80.2317001090158 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-15.8779643063853,64.35628289469062 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-15.908760290698524,-54.9441185531314 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-15.915690056547987,-80.51521494634032 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-15.92699879452637,0.8063959839744363 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-15.928286031969808,-1.4571182525218114 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-15.9857776319847,-1.5707963267948912 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.030534390560454,-1.5707963267948966 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.032420948381894,94.70479577855423 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.03362517536432,6.283200565996968 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.057518326384866,-54.36083388748591 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.060452902333985,3.447546513748975 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.072384975498274,-23.199398637734948 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.08097519543709,-66.8030633115934 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.092020829913093,4.5082903407156913E-131 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.100737068007376,0.9395367500483904 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-161.2174928803022,-26.59692549620989 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.146819275016114,-1.5707963267948966 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.152773231762186,-1.57079632679488 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.162403925391054,-3.267055311457914 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.18066965513086,-4.559871234903348 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.191638701474325,25.909116346096667 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.227715600496282,-5.745857857614323 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.240114127634158,-88.05937857304144 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.258499052419758,-13.894566058852718 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.267899711304242,-12.568344046418659 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.30084529427016,1.5707963267948966 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.320989023621618,267.0349952683525 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.35799057652867,-16.75660548231386 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.358131850378363,-52.52227534687297 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.404925221008355,-624.9057928893378 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.459723646355172,-91.20804089245051 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.48948619723355,-1.1438844745585138E-16 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.51213599476155,1.5707963267948966 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.516618796947775,-26.58166748482384 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.525413084288342,1.5707963267948966 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,1.6543612251060553E-24,11.338521267706744 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.55920270034295,-83.3937492180213 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.582558667476647,4.930380657631324E-32 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.598674963274068,1.5707963267948966 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.602353041475126,-1.570796326794905 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.67404082326845,8.141531799395054 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.696967285082195,9.424777960233634 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.69852191455875,0.0026876032867547387 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.715736460647904,0.030943754917932435 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-167.15848010363777,0.05804780494271711 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.7302145269149,1.5707963267948966 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-167.33418263701304,-19.652618619403817 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-167.3705513415823,4.310981577226954 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.75501830605528,-18.20758439660137 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.760474574083318,1.5707963267948966 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.76169159876001,-42.65724234388034 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.76346318444233,-6.447249022757849 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.76484487163809,-0.9111691141273184 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.826597724898384,-100.0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-168.5109293574103,-1.5707963267948966 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.861914312383963,-51.74426253289122 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.688508503057271E-226,0.0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.891812682089814,77.07412045750003 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.919879609533396,1.9390588845887606 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.92580803661706,-3.1822424285169717 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.6940658945086007E-21,-1.5707963267948966 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.6940658945086007E-21,1.5707963267948983 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.946655954074387,-90.0859731958003 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.6958303447609539E-167,39.21090807066503 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-16.961925469575313,-85.18808940157817 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.004574407796746,81.6889120333595 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.0074772671412,-54.97787143782138 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.014083923530773,-75.62660519862962 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.016968013475676,-1.5707963267948983 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.02463806715086,-22.26290839652276 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.02718598702735,-1.4088407314736535E-132 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.029854105066917,-138.85083755312218 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.08069072113015,91.00578732346352 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.08881323246662,84.4146394172439 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.091950756031963,-1.5707963267949072 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.099128641735838,-7.784856721211995 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.104043826101755,-12.35014919459724 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.14448045696919,0.41197905876079677 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.145745506581616,-21.936125300206804 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.148992411056966,-55.466932441668284 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.15538824100596,-31.691274354669122 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.17901933968554,-0.9539614358339031 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.2057333270707,-960.737786078711 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.20880032225702,89.63626277068315 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.27731455287073,-37.69917562163167 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.278759342381573,-1.096116486206004E-19 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.27875959464948,-25.195624824137045 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.27875959469822,-1.5707963267948966 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-17.27875959472274,-43.9842850854423 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.7284380207810348E-14,80.08760698512563 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.734723475976807E-18,-26.399822917742178 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.734723475976807E-18,-77.53981633973798 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.734723475976807E-18,8.433794814904985 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-174.08947445549563,-6.28712035741424 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.7763568394002505E-15,50.110168186315974 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.7763568394002505E-15,-59.38151088245359 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.7831800561729738E-15,-87.96464648043121 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.7902504049653399E-7,65.99538174416821 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-186.01335350062874,-86.40375411492333 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.8645851828000517E-155,43.172754267876826 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-186.85124780940757,-97.53246836219067 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-191.83236015579573,48.31256546764792 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.9227154756426118E-9,65.97509907072617 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-192.33789902701918,3.020869611628941 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-192.70887933202323,-141.87745268956905 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.9721522630525295E-31,32.671666922000995 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-198.32655880845445,0.013361019249893562 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-198.43719084469066,-0.5705341574248429 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-198.90958150847956,-100.0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.991635180221503E-14,63.11165837180431 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.0017703627426494E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.002083095183101E-146,-81.37441330441965 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,2.0679515313825692E-25,-57.450402120682504 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.1084395886461046E-81,56.00867432138982 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,2.1175823681357508E-22,37.84220409593374 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.1175823681357508E-22,98.49181734719858 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-21.991392715753555,-0.04721316192443355 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-21.991392715759716,-85.66213828340922 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-21.99310521532443,-50.81516072995617 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.008932962003325,1.353152053572439 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.01066349339358,-44.305700415843894 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.022824781706554,-47.803218497094996 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.03102100339336,-10.266405194321027 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.03218857428213,-2.1000802069848037 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.055956369187644,-98.59831116260295 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.06399726144382,0.11942894255178943 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.081252571173074,1.5707963267948966 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.12264542358547,38.9095456065155 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.214921332125065E-16,-52.348298228414265 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.150031948704605,-13.659641794580239 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.17936184017239,6.421937981940175 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.19311418787214,-31.927858214178137 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.220446049250313E-16,0.0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.220446049250313E-16,-0.3800158347224047 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.220446049250313E-16,-109.95574146089764 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.220446049250313E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.220446049250313E-16,-20.885151553300076 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.220446049250313E-16,-20.921118436930527 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.213123012371014,-1.776356839400248E-15 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.229360528318182,0.2013329066456549 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.2795002507961,-61.15034657743483 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.31836963685307,-1.5707963267948966 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.371321279014154,-29.413829204522003 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.2374691146143893E-8,-98.96410981101046 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.380338063739316,13.98486912773891 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.383480151243546,-1.5707963267193015 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.395396899000104,-40.90826250855362 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.41305204401081,16.54148351954024 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.467251196570274,-54.947793253610165 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.48550114706759,-82.69969954978014 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.50045382124391,-50.21071834496306 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.50743891188298,-42.83574457032734 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.60762819943693,1.5707963267949019 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.609776499713092,-118.91933144605684 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.62249944188436,-1.5707963267948966 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.62395559225412,-78.0479024037299 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.69500845985815,-51.41506108539473 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.711430480247092,-1.5707963267948966 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.712105025076813,6.283267794846285 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.721718827373962,21.651973732703947 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.727463897564892,8.21771633221495 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.736563898805375,89.76463083508875 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.768786653445616,-52.06649492443037 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.79348547023374,-0.871018980555694 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.816206107163122,-122.93426300741764 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.832799224158947,-89.03320947102054 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.84551479174813,-1.5707963267948963 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.859538188293932,-1.5504020710019921 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.288355254683749E-15,-80.86666642733846 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.923925960666054,-1.5707963267948983 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-22.994736536357152,-69.79060330849676 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.003306971953553,-44.08461621145086 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.054211640576984,7.853981633974542 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.057433620955933,-6.283200567097064 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.111344752303808,-75.6570286142508 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.14107738798304,-55.43010488324016 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.143583670607853,-6.4985004239426765 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.187957106285936,8.10398163609646 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.195731184602735,62.68874685932212 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.2754842936484,1.5707963267948966 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.32941939234999,31.774357049468513 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.34557781465554,-71.51763395803681 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.358199369466988,-33.444763270971706 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.399913201243763,-4.712388980384709 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.455381433946112,1.5707963267948963 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.457516023206566,-1.4863484177700785 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.464075038495327,-43.058369464876066 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.466577874756922,-15.284401120004706 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.468448865130533,1.890489169468652E-15 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.469747063801606,-1.5707963267948983 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.5232190632119,-31.512772763546728 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.541384790270996,-57.58256474019414 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-23.55155644465761,8.96786018981182 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.3609902624006038E-6,-42.446902719848666 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,2.43840113378779,59.69145931619625 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,2.4426996415487436,91.06137986990673 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,2.463397647715309,73.40242846798213 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,2.465190328815662E-32,-55.538454858552896 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.4777838538100357E-4,1.5707963267948948 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,2.5392044847953215,8.106446692026271 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,2.5795342393929928,3.552713678800501E-15 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.606192665887195E-20,39.26998798728978 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,2.6469779601696886E-23,-19.491704406345505 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.648276413619694E-30,0.0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-268.20221546929804,-90.08860947677641 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,2.6885437423506455,3.2074754976379003 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.710505431213761E-20,1.5707963267948948 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,2.710505431213761E-20,-72.30479667791144 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.7734755685361395E-15,-0.06527029106717519 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.7755575615628914E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.7755575615628914E-17,45.34969501377775 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.812466951295641E-17,3.1415945766178144 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.817681462947307E-132,59.80454950382216 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.274333925190643,-47.958769258655046 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.274334120726785,-1.5707963267948966 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.274336427228413,20.81424995030271 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.274578023919272,-7.372244090633742 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.310196286148127,-66.91136698449466 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.319634146729598,-1.5707963267948966 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.32157875694233,77.3342928256769 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.334181096606244,77.04093896826757 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.337504807567434,-18.85146003915788 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.835500731633769E-15,-45.26709751490335 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.366929799019918,4.589852989678491 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.378147172703656,-56.60229133841702 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.45195840487588,-1.5707963267948912 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.462783492260726,-99.47674172460876 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.473452274188418,-63.4847589930946 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.47889673538989,-72.95208217476194 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.51546318081391,-15.742136805107293 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.5525543595163,-76.72657960876617 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.553401478535562,50.847862354965415 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.572743293634527,-1.5707963267948966 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.656417729330318,-0.5691183659718978 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.662541505376055,-1.5707963267948966 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.69900792806422,1.5707963267948966 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.70878209462975,-34.82206083679139 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.710973984434087,-91.07762529529178 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.720352663751115,-15.397082064911702 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.73073140595824,-3.358858316502995 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,2.8738117359519555E-16,-71.2399328252269 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.789562134605774,1.5707963267948966 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.83421909484605,89.69000149218186 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.8853058180580424E-129,3.1489119618693038 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.85831469128371,-155.3873819275845 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,2.88676870146266,-36.33676803063633 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.86778986080678,84.32538436571747 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.887052177126931E-5,-5.961827229711373E-6 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.892453187076217,-100.0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.901255709082847,-65.10401376543717 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.91387771544844,-0.06270652790470972 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-28.96906141133428,-1.5707963267948912 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.00960740157643,-20.316935964959484 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.030056701675136,-761.3508995530213 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.079006125574047,-1.4871994699042386 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.09300768366079,-2.9579905475706085 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.096574324821706,-1.5707963267948966 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.102298895645973,-55.20435782317536 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.106128566247293,26.813999982208813 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.106904975786918,-96.29210662715283 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.11905851217392,-5.141594017042862 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.16013285600775,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.161061782300408,-40.18826009430409 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.223817187507436,-17.46693554014955 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.237771665486097,-1.5707963267949054 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.257079632641535,-77.61379159015706 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.278879728967873,-100.0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.29410882267493,-39.132251243559345 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.361826894197574,-26.794042615321484 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.456820774356885,120.57045962194297 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.486624221310535,-44.33455758665444 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.500809539483765,20.762588041520047 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.513221630591943,-42.813801773760694 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.540723548515373,-34.33054187911736 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-2.955150202189867E-14,30.144361147834772 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.573186987501842,5.03387049180604E-13 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.583379220660085,21.85318502451899 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.655940816158278,-55.37745894500027 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.66046139673788,-1.2649366931862076 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.663312718298457,-27.452453082580448 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.6668570735531,1.5707963267948966 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.67761200437407,-1.5707963267948966 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.678036088990822,0.0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.683994744320984,-29.603417807700026 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.69927537053243,-3.3992436558140184 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.720734120797136,0.06606758407795754 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.726214918188216,1.5707963266389693 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.7756087916081,-15.300095812473373 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.825395872239337,-1.5707963267948966 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.83547945405165,-55.198150783246206 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.840940840189816,1.5707963267948912 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-29.845130209064326,-81.74484670781699 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-306.3043636794891,24.167000561019332 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-311.9217431172581,69.13848250115339 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,3.1236281672935866,-84.25747346963551 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-312.58844453855147,-1.5707963267948755 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1415926535897953,-1.5707963267948966 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1415926535897953,-22.582327133790944 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1415926535897953,-31.540306322150535 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1415926535897953,31.604777733860686 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1415926535897953,3.1792894069431554 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1415926535897953,-38.50920776320471 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1415926535897953,69.89538772331618 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1415926535897953,76.90281326541316 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1415926535898056,84.72612937348968 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1415926535899366,23.9228543106186 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1415926535916245,19.83931721712807 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.141592653758649,-1.112920630790697 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1415926541999455,-7.722036001464205 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.141592668619339,30.61080690199017 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1415926918440182,-1.5707963267948966 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.14159289201118,100.0 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.141592892013747,-23.813626454957813 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1415929314451456,-17.15387969764288 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1415936710868277,70.05524584702468 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.141594610987997,-1.7275095313954252 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.141594732828986,0.6273922562573302 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1415950095435417,-1.5707963267948966 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1416002830342262,-0.32998340894453576 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1416002952037974,-1.5707963267948966 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.141600304273519,-1.3919066777898437 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.141653706507234,0.4005356891985769 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1416549583867543,-6.84901578420812 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1416562950222313,-1.5707963267948966 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.141683789568343,10.361961242769226 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.141904461681645,86.0478583544105 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1420809348397936,-70.89460806129793 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1420809348440666,-6.553339310857243 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.142080934855943,76.96902001294994 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1420809348668226,1.5707963267948966 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1420809348888135,-155.4881508089474 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.142080935197229,1.5707963267948966 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1420809353059957,-1.5707963267948966 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1420809356266384,0.0041570619030628355 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.142080935671603,20.59659669122376 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1420835291208307,1.495338338757764 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.142084763020741,-85.95675681963654 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.142088629030311,-84.52160772060762 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1422176796911434,0.36646743050371533 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.142821311597863,-1.5707963267948966 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1429945718230887,-42.93008375194896 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.143545778591282,79.00321065071431 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1435457828799374,1.5707963267948912 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1473285987880066,-0.09410423497325593 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1494051535901773,-97.9547690876979 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1494051538521752,21.559524230032032 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1494051694623173,-45.13791216273583 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1494060592681095,-92.53190156096213 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1494063313701908,-52.53277790355139 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1494167374781927,-1.5399485778639144 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1546666175885476,-100.0 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.154772150670788,-1.5707962424775235 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.156689246722607,37.87361283902381 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1576514702139704,-92.44451783021698 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1585090525329496,11.260901180204872 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1627982635907674,-70.21368079669898 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.165550274685441,-6.283185337247136 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.168014758773154,3.1415926535897953 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1701373351294864,-43.98229715025714 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1717827981559203,-6.2870915583337394 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.172856747110823,-47.68052466846407 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1729607850303334,-20.650092500157736 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-317.44726607984774,-22.59969788974622 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.1783443971701653,-88.9059581306002 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.20247879996668E-11,25.1325558745258 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.2147423315647554,-23.075527652397426 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.217946460072568,-10.371331742540605 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.230010200638283,78.16995004556253 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.247404558442384E-149,-1.5707963267948948 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.24970386888646,-54.7553705439535 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.2547911832935315,7.853981702282112 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.266604390268788,0.9230596503159562 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.2694216513604815,-3.1416047225457464 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.2924090244388964,-22.509312793440174 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.30629028438301,81.79359352597486 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.307114790717426,55.30758430809992 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,3.3087224502121107E-24,1.5707963267948966 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,3.3087224502121107E-24,43.10780669166054 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.3138675909966615,0.4893291435258571 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.3614671848952256,62.155263444093606 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.3881317890172014E-21,0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.3881317890172014E-21,62.90385454844579 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.415563006865995,-20.378360877057844 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.419722325801388,1.5707963267948948 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.421991711995119,-61.26376571207166 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.4436512494262064,91.10618763258779 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.444750917139835,64.21208704644596 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.4462332068155503,579.4858200196479 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.55751920438866,72.73873367150108 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.55849575199155,-1.5707963267948966 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.558538477914816,-41.38931935184053 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.56533172207427,-44.12878154591019 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.57425158603948,-68.50432428106166 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.577787412252746,-36.109655394553016 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.6004949325166,-35.229995357729194 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.625217072720865,-48.32081583254711 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.62746388664064,-19.300910351586477 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.66583797058601,0.49450951582981895 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.67945552444268,-0.5146379583537909 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.469446951953614E-18,1.5240176276274526 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.469446951953615E-18,-46.415695434856154 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.73576801177585,-3.1420809566187153 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.764531180509294,-6.283443531939495 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.77139151261646,1.5707963267948912 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.771421938473225,44.12926348025107 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.795595642563356,-5.1977048828224496E-113 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.803588772047846,-1.837589179357618E-15 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.80653554053226,27.877484594949657 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.81054977280489,86.30714929481583 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.836216151409005,0.39062913345142647 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.85640474188017,-100.0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.865552929378374,-61.702111066744465 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.88065072756061,-0.6145101010716161 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.90631632695526,-69.93469623566153 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-34.925019698267604,89.34185908089961 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.4986127078382054,86.84519803869398 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.002435549879266,2.6355494858076308E-82 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-350.2727898949713,1.5707963267948912 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.039127405643136,349.216784539771 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.04664376069808,-3.1415967576146393 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.05716014436359,-23.781256185193403 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.5101269515101183,-4.712388984410142 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.12589473179319,92.8803804415729 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.12908149145104,-16.44529263705907 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,3.5169250499914493,6.283218479571303 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.27079396324518,-92.8623692284376 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.527149735310317,-56.265878325469856 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.30547223829405,-48.592188777526005 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.315579041260634,1.5707963267948963 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.33896613514273,94.28242099030682 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.36757642947535,34.79891489330209 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.38220231106199,-80.05909571035173 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.38516934808885,-97.83952759210848 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.5394913445064784,-7.4010731599567094 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.41629710460149,0.9891878064028365 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.42599829594475,76.34619361632494 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.543061422061007,94.58152177654648 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.441807838322184,3.0106345306692843E-13 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.457987098519524,0.7770774510931019 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.552713678800501E-15,47.201146579597555 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.552713678800501E-15,91.106186954104 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.552713678800501E-15,-926.2492654837753 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.552772791987219E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.551712818314414,1.070057544188522 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.56837615651014,77.41295552924831 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.57506513882345,70.00325868823151 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.58917873961585,56.58366980842486 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.59624204053264,-23.766971076918054 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.60896898885504,-4.712388980389 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.63094418934143,-12.368157958935882 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.63627524457468,98.77783569629067 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.67458558667802,67.45612405535496 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.67780360189647,-22.26329306519702 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.70615854466837,29.865555911154548 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.74530466560674,-18.77642096098495 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.74957926951241,75.28861256799875 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.76599317300967,-41.431111416097664 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.7886230249952,-98.6775334951849 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.80907587351632,450.8175112539958 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.82122735273112,13.194751036032471 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.82715151242743,-1.5707963267948966 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.828939071729195,-60.102058160343844 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.83159733033366,1.5707963267948966 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.84026114294414,-2.308244654446434E-128 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.85294483242511,-55.9179110907277 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.5866843210368273,-87.37648197943287 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.88727439039633,17.015047021718644 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.897528543828585,-13.643326574284997 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.89996678294503,-10.23030173694049 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.90638456836565,37.264818119749464 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-35.98311547819017,4.15042591759857 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-36.02485528971104,64.13100539354294 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-36.03449108330277,-1.5707963267948966 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-36.06355941418723,-3.1422014835261867 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-36.06816653427572,-0.4182695292796905 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-36.117430501101516,4.14159265359047 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-36.1283150970831,66.00469597440454 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.61352688243341,1.495866793416932 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-362.1737039459855,-161.57043650063937 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.6306813390471753,-3.712571174575495 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.6362538058140785,49.149059645186874 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.658163240190479,79.32674945850117 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.679586908303067,31.415926535897935 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-368.7410477056588,-57.81664817569451 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.688377549368255,38.253751975947736 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.705296109093865,-1.570796326794877 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.752142128151405,-89.44613658652095 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.7707336934964286,-1.47435578783697 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,3.777063352704202E-17,60.81040962673892 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.7940443543097864,2.4695944647145636 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-380.6948416517975,142.30244857663433 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.845152576375188,-100.0 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-38.45404708580023,0 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.878518027794148,-80.65634329874777 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.909445200666628,79.34847747244507 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.910115842762664E-17,1.5707963267948963 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.910318545279494E-149,39.54510475605247 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.940593712637269E-8,75.39796715431271 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.944304526105059E-31,8.11042624097928 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.944865927208584E-6,47.1460925027602 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-3.946475187681929,-49.2361998542193 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.035255704317663,-18.474107393922502 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.0389678347315804E-28,65.98125961589999 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.0723051174505867E-14,95.81857494949398 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.0821182628899845E-15,50.34947710069159 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-40.840704496667314,1.5707963267948966 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-40.840704496667314,-3.154889768753703 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-40.84070449666732,-16.002230475166513 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-40.84461207632245,-85.66642596655909 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-40.85097453340162,-43.57330831561941 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-40.85897809243889,-17.15004757051679 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-40.875623196621035,16.87655065558667 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-40.89139013813921,-0.1157147508143056 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.094542944938617,-68.99218868248037 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-40.945691264376464,-6.3513238510560726 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.0960861793822945,-0.9021519250643861 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-40.9635858082334,-1.0137000357143166E-15 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-40.985055733809645,1.0277781898276137 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.018090842804476,-135.20404389294356 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.03661320818712,24.954999447283626 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.04678665942954,-5.0758836746312984E-116 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.0527885976328,47.78350586326081 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.060320569562016,1.298276584489761 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.06923992183164,22.714242309321154 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.11302335929006E-14,28.274333882308138 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.135777028495546,-0.5608602984695544 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.13768464727284,-1.5707963267948966 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.139989438445234,-240.248408617473 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.21254720370149,-1.5707963267948966 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.27661587617828,-14.643081651663206 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.314373185232704,-24.500450011323785 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.318697958101495,-10.247169103194114 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.329043981092795,82.3656577820503 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.33029964737004,77.32333435287569 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.33449970329437,-72.25345560841458 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.336779768151104,37.992627169855666 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.38868127795565,56.67758144968738 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.393378406441485,0.20018216771968134 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.40550597776612,-72.7399893580284 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.141592653589794,-36.48661569896062 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.141592653589821,-45.16303606711656 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.141592653775394,-1.5707963267948966 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.141592653827527,-73.45452413827617 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,4.14159265502297,38.30972414484379 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.141592658571702,-83.41630374481895 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.4207262938875,82.15037184449744 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.142748712909096,-1.5707963267949054 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.146839228909753,-3.142090485222772 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.47153770194904,-97.74793959468094 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.47425348969901,-6.2831853082177425 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.147594913364073,-19.857829658979583 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.150027264942811,-59.69034935814152 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.534059891374625,-98.01272298935825 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.54902808206948,-88.98898335485396 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.583331909327555,-1.2563534045313696 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.58540854409523,-31.290960045396233 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.59062433536225,26.747118161562973 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.160351426978126,1.570796326794877 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.619220687853975,-12.675695227571012 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.63465547638999,12.936936795345062 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.164457021337235,90.9592590283597 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.652961383416454,89.99876809745487 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.656732214124446,-4.508036924291801 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.67647503206497,38.23362930929237 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.71825217843244,0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.7304877994674,36.32513835337197 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.75525069469011,-86.0147550913581 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.760464421934216,60.453780060624155 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.77056322151309,-99.99569750607463 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.79598134254797,-3.141592654973253 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.813579865607856,-11.314148995013667 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.8199505561338,1.2274419664140908 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.85079613407449,66.19793875355226 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.887410079467394,-3.142081648439071 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.912217258594325,47.56291453293835 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.91688597286408,-1.5707963267967537 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.91849991026544,-26.143611071594293 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.925439605352466,0 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.97920949657079,-100.0 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-41.991684822517364,62.363668627775766 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-42.03915881513238,31.94625161965891 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-42.04505102838294,56.69086913691447 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-42.05344090155374,-1.5707963267948966 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-42.05652356793104,-0.45377752077587996 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-42.08597924796753,-16.551861298328348 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-42.116057258487196,47.47681965283436 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-42.12108632685198,1.5707963267948912 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-42.15819869237101,44.53909723844586 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-42.17561663106943,-24.38161115080962 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-42.177522428224236,-85.85722863863886 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.2201259578016135,-42.70193167924922 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-42.20434543107183,-0.004130252032839861 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-42.212888512570466,-1.5707963267948966 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-42.235372226129535,57.35565570666532 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.2236003611249555E-16,-39.29244301541971 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-42.266303261034466,-35.71672999371186 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-42.27751808486812,0.0 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-42.28631274507896,78.39956613106635 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.230409882561143,-50.03960659124256 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-42.30989088122357,-62.35735909074797 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.2351647362715017E-22,91.1066766778776 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.2355346831473595,-5.141592653917885 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-42.38415200293086,6.287093008687874 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-42.41109913757214,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-42.41149597636385,-1.5707963267948966 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.2450305169890106E-17,-3.107321117026714 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.265482311209617,84.61275410849339 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.2930561951523885,-29.072953261012557 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.3002059328164774,1.5707963267948912 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.320932794639705,-1.5707963267948966 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.333542835177722,1.5707963267948966 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.3368086899420177E-19,0.0 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.3368086899420177E-19,20.420352248333657 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.3368086899420177E-19,78.29003468053679 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.355446158470642,0.04002370141719419 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.367852353426237,-9.838163958636727 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.370233726863748,1.0870499940031987E-16 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.371730013936826,-131.89865922052303 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.378587876783418E-15,-78.04471839073733 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.38438487693123E-8,73.82742735936014 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-43.982297150257104,0 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.4241066897784895,-45.12988049921002 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.439758269392777,-23.604577534127287 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.440892098500626E-16,0.0 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.440892098500626E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.440892098500626E-16,26.61822404008192 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.440892098500626E-16,72.3873178603231 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.440892098500626E-16,-90.99964828007109 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.4428716453271235,-48.328495868168524 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.479497793575296,7.853981729573407 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.481123627292554,-5.141592683957159 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.493080308178246,8.334916372937608 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.4949342662406035,-38.858371780168795 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.4E-323,0 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.5489116890441466,21.469271938880432 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.571250007357865,-22.728996783953352 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.578996512036325,0.2558714809285174 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.600007509812132,7.8545495444763625E-90 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.611275205414042,8.10398262541494 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.61189648792039,-1.5707963267949054 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.628485402451171,-2.54425429666982 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.640814421871426,-6.283185434100185 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.659502640383247,-3.142080943159843 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.6782866011336414E-5,-45.07620578448528 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.684082150049985,-43.981895901110796 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.712388980383747,-2.284645952109025E-28 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.12487006615852,-52.80472108033343 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.13261479288741,-35.14083533189107 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.13951480761542,89.20296544424342 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.15378300796727,107.29850634819542 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.17097419449155,1.6472184286297693E-83 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.188841892846845,-0.48640069504792305 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.30959680691052,-0.0860757351020558 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.34273470066811,-1.6155871338926322E-27 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.35581326592575,-3.695250832223852 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.36373362620539,-0.06325892156989366 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.37090430120321,79.81140355827543 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.39910631153899,-35.174848956710406 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.41427932996963,3.552713678800501E-15 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.43431448700876,0.0 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.48987269930166,3.5124572746576916 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.49504658230185,6.704314774851996 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.512274064142076,-1.2091293891360984 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.519769451088514,13.213600454809647 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.55950347074542,6.283225376447834 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.57892132281074,-85.86207216701222 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.59153730852781,-26.999390542209397 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.59683262456866,70.27447571249455 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.63083297690485,0.37196583905333513 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.63654004563165,-48.70427366160021 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.64350089060619,56.99976855679071 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.651660704660976,1.876930690752045E-4 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.68121657853783,-39.52106658175656 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.781905159749414,1.5707963267948966 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.80145699014309,1.5707963267948983 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.902927716734,1.5707963267948966 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.90299346511453,-9.638168708750598 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.91697209966861,-1.5707963267948981 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.93106689550144,-1.5707963267948966 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.93545084428117,1.5707963267948968 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-47.971567105752285,-38.237172390447725 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.007178341722145,-42.795085134983445 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.062702673372186,-123.28931587420414 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.095326900414356,-1.5707963267948966 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.12326869499921,84.80662561905702 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.13955511772403,-26.656189659348918 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.15771189402865,40.000935035095885 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.178472218382765,69.5991077161646 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.18222036225166,-79.55488353454845 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.18362783938714,-9.976030321067864 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.819237867255377E-15,-90.96636769163068 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.822389434428566E-15,-0.2942947581743835 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.22661097254663,35.72942130215429 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.31605201973558,10.766163302182198 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.33415114789239,0 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.346123576956224,-28.813041586455938 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.35903597705946,72.68642496101262 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.38558229742062,-98.97355542921113 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.39781411842945,-35.971579309276905 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.47210150776525,-6.337457868823305 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.48889226574704,-17.975147456361128 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.49124732086094,59.84472814985284 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.502718812804815,-6.2834800349471465 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.52618164465205,-299.7402962024832 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.5475140685242,-0.4865660794509253 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.548331111535205,0.0 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.55796445231985,-616.0244215086087 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.56090658920243,-1.5707963267948966 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.56840358766084,98.23320619783667 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.57040313906079,-3.141984654490406 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.583593110069124,57.22702758485471 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.591525921483175,-9.871031767461413E-178 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.594446084818784,1.5707963267948948 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.618076011911484,-85.66586460439889 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.620507366381375,-20.364594025788392 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.6312235495327,-81.82273860818918 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.644264305036394,-1.5707963267948966 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.663994731010554,-1.4149930273386988 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.66461503927717,-25.109475046010747 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.66530487990624,81.99425687169638 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.6661941987345,-15.940941565748915 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.6829118719056,67.46374641031574 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.687080123065066,-69.71827683860309 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.692631658616925,0 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-48.72941180727422,-1.5707963267948966 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-487.92000593228124,-21.946190197535255 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-4.923439017976906E-17,-36.12831551631215 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,4.930380657631324E-32,71.30795015654019 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-49.84022279401405,0 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-500.47570568187797,44.472710345518436 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-5.0052077379577523E-147,-90.07476683424527 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-500.92987132354716,0.037895975153634194 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-50.20943731247449,-48.74394299229165 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-506.57608084009155,-22.925826690142713 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-5.0758836746312984E-116,-2.8702194491974033 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-5.117963610674778E-4,-6.443702065841777 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-513.6467719481188,20.649992776057772 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-513.6503661635711,82.62483375969006 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-5.144341870805125E-19,70.68583470568812 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-5.190610600179402E-13,-62.89437875580238 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-5.293955920339377E-23,1.5707963267948983 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-531.3462695875143,-80.7361966702978 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-5.321001439160637,-1.5707963267948912 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-5.327993384780537E-256,-1.5707963267948966 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.40707511102653,-14.050814309480717 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.40708227479929,-1.5707963267948963 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.413866738811606,-22.68231160768148 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.44777708594392,-1.5707963267948966 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.47355251165085,-1.5707963267948954 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.476660360380855,-173.48022834127445 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.49036076882155,-5.123158057207821 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.517629636225934,8.92777911669367 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.52669479702492,2.778448436856347E-163 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.55634138703549,-1.5707963267948966 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.61441774465487,-13.271758944902833 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.6490742528218,-84.8230103271365 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.71276549967828,-0.7562116386309395 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.713075471777614,-1.4210854715202004E-14 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.732035885309095,26.77546213517919 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.73330199567779,0.47413917904699254 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.7513748688029,-42.71654849046346 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.75326622646788,-3.2665926535905796 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.75328406175147,26.70353755551324 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.755664435865874,-37.30540810198833 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.80291851433968,-48.694686137021264 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.81331807548422,26.834685297578183 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.81506150139901,1.5707963267645666 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.8286737106278,-1.3786800371451777 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.84592289267854,1.5706983764222764 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.84834993227708,-1.570796326787245 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.863640988939,78.30073182777359 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.86795513960713,-28.1312902087571 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.87336067451332,-11.247854018878499 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.87447938645128,-1.5707963265472835 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.87564272959091,27.79353505047871 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.878440374577416,-4.712388983798834 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.88800114589806,-41.262699868363995 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.89904955447939,20.5799603160968 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.903544290892064,-1.570796326794897 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.90380172347963,-5.212415456817803 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.91882879691224,-46.480277272412174 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.93933812085238,-9.81725848122807 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.94630339250363,-5.141592653597492 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.95608190743913,-1.5707963267948966 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-53.95782754503122,26.703537555513243 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.01629011297025,-20.092759591875165 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.04336636231195,90.79043328997601 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.04862324805335,-44.67775157381692 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.08036683188361,-53.44524118159299 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.107915457431076,-1.5707963267948966 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.10797566779001,-1.5707963267948966 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.156945813371784,-1.0742667757115505 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.17197028078448,-98.97078195749876 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.19750021272401,-48.08120042963364 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.20751021526344,-84.30616881196424 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-5.421010862427522E-20,-43.982410464550625 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.2261237932112,-44.387743329331144 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.23876719771142,-1.5707963267948948 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.25142033965713,89.54380903195619 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.34154000419666,-42.97032176875716 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.39545214929079,-41.60048166538009 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.396044817627924,-1.5707963267948963 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.398521124519846,0.1639180530112371 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.43927337749157,37.79698499176586 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.4532712817133,-66.5439666569176 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.47511554452292,-44.180227084210586 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.53513299730268,-93.3767223269804 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.55039373057679,-54.31477637814555 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.59026895708368,-1.1408140842823353E-15 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.594294206401756,-75.32548803705151 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.60302461805047,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.610050354661574,68.07604760535071 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.62015259730073,-48.6924505801245 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.67771331209528,-0.0053280713786901315 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.68780781642872,-85.84667612683333 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.711572968311295,-79.22571143981192 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.72176431616669,-0.9068330592085502 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.74594672734544,47.70583028465817 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.762998024674,-91.99022670700145 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.77146466405084,-0.1896200030972773 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.78749217787153,22.447807699280588 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.8189876062524,-1.5707963267948966 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.843941502135365,-24.86103429879971 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.8918160529192,-23.984467771044844 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.90705800631136,-1.5707963267948966 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.93919299914572,51.80583675746705 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-54.952831019963845,-98.12013736613268 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-551.3483071413565,-1.5707963267948992 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-55.19937644654537,16.49117323353643 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-5.529829937133173E-20,2.999393627791262E-241 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-576.4684141698744,-169.5317842335164 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-5.799254637370231E-16,87.50472370103387 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-595.3306496527244,-149.51175928799478 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-59.69026042006876,1.5707963267948966 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-59.69033163978235,140.82058482547853 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-59.71295143477933,-34.55479394708281 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-59.758453845812355,76.96902001294994 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-59.76994794901753,-6.287124374002564 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-59.77117347993786,2.220446049250313E-16 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-59.78197811934936,-1.5707963267948963 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-59.79550124928369,32.43430879870502 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-59.80248848180225,1.5707963267948966 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-59.85301042046182,20.505778597147298 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-59.874396853447855,-97.39629042038929 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-59.945974632889,3.1420809350200294 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-59.96411350628317,-3.514358188412473 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-59.97114107534924,-1.5707963271152297 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-59.978169080041724,-79.64547231924233 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-59.98189194732208,-1.5707963267948957 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-59.985037090630136,-1.5707963267948966 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-59.99812364310561,-3.1435457785954175 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.02337146013841,-31.601496572841615 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.029152112385965,-68.77349071454093 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.193322570805876,-42.5430762124149 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.19605449851626,20.84041174702073 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.19975624191025,-17.192361614693546 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.22069550270319,-22.02121856697272 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.266922009564055,-2.2744251615110187 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.27083912641915,-4.712388980771582 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.28908722837873,1.570796326794893 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.298197002875156,-25.132743093587166 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.305350116405855,-87.14481909213217 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.317020537487636,8.245239226928183 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.31828407131665,-27.49685110607829 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.34633331488431,-3.1708388012633364 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.41297525641161,-4.712388988372998 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.41723724273436,-29.045325525591068 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.420043166361225,1.5567348689112994 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.43317472581451,-1.5707963267948963 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.448867242845175,7.853981634543914 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.4790236910392,-6.284257665973172 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.48488186516392,-116.41939824567365 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.52504912748765,-34.55758023787992 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.546212105894924,-31.450180354323585 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.55060315089626,-72.50099309407469 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.588570701112914,1.570796326794897 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.600538247794645,-3.285429311916573 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.62222137824402,8.103982562462608 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.63172685480709,-0.7581888048854163 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.644439874691514,-2.4965535883579264 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.65936853622909,-1.5707963267948966 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.67399668668675,-15.072006308472496 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.690260418206066,-1.5707963267948966 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.703524148433026,0.2600309507927611 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-607.315673425307,-7.427312288333761 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.74943117884062,-1.5707963267948966 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.86888357421276,94.70036900324997 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.87773051424241,-35.217542411856485 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.89370794392741,-66.24948781709976 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.90534256766464,3.1730878397032276 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.92209464489131,23.74344628562866 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-60.98563263225208,-6.283185810494497 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-61.00105424348317,1.834068052727872 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-61.037268175572315,62.89124329282973 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-61.05583921464966,-54.61265619865707 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-61.05964487290324,23.932129948480807 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-61.12364473434509,-35.155327978189355 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-61.130789569562225,-26.13745246141505 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-61.13389555070603,-1.5707963267948966 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-61.14632699361593,11.008427505487802 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-61.162328070151226,-1.5707963267948912 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-61.20201940391275,-141.37289462288484 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-61.21635206841498,1.5707963267948912 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-61.23479354965013,-73.89970890604428 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-6.169394854663383E-179,-62.98802350902064 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-625.5767659118094,-193.56395232441326 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-6.280444259946801E-14,75.3982236861535 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-631.7946694542568,-1.570796326794897 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-63.27601815672732,-1.5707963267948961 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-6.46324191973764E-15,-31.62451471764472 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,6.492968143583863,-0.13393587515103073 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,6.498025509692426,1.5707963267948966 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,6.546492553625304,-304.5900447985288 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-6.56778059642941E-6,101.04679296470772 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-65.97344572544387,-30.661589492571128 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-65.97344572635744,31.7023491296485 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-65.98034301489974,10.132563885562803 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-65.99767576220047,-3.141594580246853 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.00077955585702,-0.1633760290071844 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.00156991612444,-4.141599073934483 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.0144720789676,-100.0 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.0259797420744,-99.50144202167952 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.03922556499357,-1.570796326794895 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.04719466010692,-168.23834530854666 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.06921191420228,14.432290939892617 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.08327246876186,38.025965754346146 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.09003219075586,-1.2621774483536189E-29 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.1018749759197,0.895782082564847 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-6.6107713339373875E-15,100.0 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.1115479508474,-139.36428939662093 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.12523273049757,-136.6144623691481 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.12864950042517,9.860761315262648E-32 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.13865346362789,-181.18330190444144 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.13968070727373,-5.1415926535900605 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.14947106717212,84.79282081087332 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.16257439043024,-62.86947560156675 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.20315640610832,-1.2195555893834742 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.21681612649604,1.5707963267948966 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.21726401635829,0.8754609852003816 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.2220476411608,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.23637335090078,6.413507763933553 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.2388504269181,-6.866398688578239 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.24031087857944,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.24292634486895,-1.5707963257135218 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.26002524442549,-1.5707963267948912 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.26804139137032,-50.26548291027366 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.27404045431231,-44.52063075583048 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.28378881173309,0.28268365246492627 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.29597227930971,-83.24384009373587 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.2962541571679,-1.5707963267948912 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.30105374171549,2.1084395886461046E-81 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.30636650626676,-798.5919017227237 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.30698609901151,-79.40760615445124 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.32346737871522,-1.0959046745042015E-193 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.33210922074184,-19.880391148073457 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.33233588148626,94.4666873070307 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.33855319779866,-980.861471221126 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.34675161726419,-0.8108747951034436 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.38078406751545,-38.63929201469307 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.3983936431464,-13.419373372170716 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.40255397554147,-1.5709857716875428 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.40725369678181,8.3262685627725E-17 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.41190767790798,-29.506570108503993 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.41551417365758,-6.337672597499445 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.41828594092678,-1.5707963267948912 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.42764607795574,-97.96610409321573 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.4312377789251,-61.80799965640859 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.4352312543129,-1.5707963267948968 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.44660946717968,-11.917271553738189 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.45310649233036,-0.9101383450987154 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.46166595825639,79.14942135768297 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.46515174777204,-53.38843617698361 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.49326449632261,-31.70985463154571 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.49781947250972,77.45630242144331 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.50838863249928,-6.287091557193925 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.5115309810288,27.755097288507933 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.53848278877075,-3.1415926684909583 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.5442420521288,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.54424205218055,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.57069285019462,71.73266179365626 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.57759740034567,56.96523639126201 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.62445022081079,-1.5707963267948966 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.65263144132267,8.103981633974493 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.65789788018967,16.800582525293606 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.68103642500309,76.69730080843172 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.7538214010252,-76.01299999787891 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.8282628056215,-0.6491953467126028 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.88598892464627,-0.1464820723090325 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.9350557227716,-1.5707963267948966 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.94010303537392,19.10549006875134 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.94188142457564,-26.16230462042672 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-66.98662350074314,-15.710973631003256 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.01627092936863,-46.04300121529532 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.03162315035324,-117.84473519692898 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.06730217062967,43.982297150257104 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.0917088366374,-1.5707963267948983 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.09658558417671,-50.503051576515105 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.10277762156645,-1.5707963267948966 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.10621629582289,-55.504390233338505 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.11084193521097,21.910241730973297 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.12836887540098,1.5707963267948966 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.13017898209007,-72.64039997868743 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.13066028611247,-1.6073621688935348E-15 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.13590058265443,1.2338789709326767E-178 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.13651408997927,-4.888221726199614 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.1679774033073,1.742614554067983 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.17844190504519,182.86874143526103 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.18124748523572,90.98378705699635 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.2018530528392,83.25220532012952 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,6.7222262902982175,7.538443606249913 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.22988090787523,-1.511903878508289 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.23490177458562,-66.79454200008789 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.24431212778234,-1.5707963267948957 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.26167391951326,1.5707963267948966 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.26495081070274,1.5707963267940963 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.27344269985956,209.38595085548337 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.27466220434265,77.19829825632249 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.2761094689548,-1.5707963267948966 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.28614704653423,-39.130571484513496 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.29072354490397,77.01202617399882 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.29285024275882,6.286127295404352 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.33311696326938,1.5707963267948966 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.34774778759056,1.5707963267948966 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.35876915361577,-56.331025128127486 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.37040359338752,-6.283499240629146 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.41339803879825,-1.5707963267948966 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.41353841810691,-35.0933898693679 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.42968962273804,-1.5707963267948966 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.44012627944977,6.338927000009782 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.44025641000198,0.005403525391338199 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.44427454641348,1.5707963267874652 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.45121309225244,-4.14159280183312 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.45650876837979,69.44302975494125 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.46314699133093,-24.1299808460316 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.46740781519777,-62.457734037399874 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.46772764549246,-6.533185307179646 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.48161266596476,-54.977871437821385 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.48350962038147,-89.16749834023754 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.50781947848209,-32.695259151225684 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.51519932873632,-5.141592653590074 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.51836517514121,-66.95600719574458 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-67.5304426009486,-41.2603580679922 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-676.4410158286764,-3.6646543803245635 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,6.776263578034403E-21,-1.2741282172667086 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-68.00342402958856,-1.5707963267948966 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-682.5778373436582,162.69125050551668 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-6.829460644849648E-17,-27.912316081468965 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-6.8494042156512595E-195,-45.344147343880095 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-6.887270324199142E-17,2320.376405797998 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-6.938893903907228E-18,114.66813176777679 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,6.938893903907228E-18,83.33367505924 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-6.946121092140867E-164,1.5707963267948966 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-6.98155267698706E-13,0.0 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,69.95233869058632,0 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-7.014967938341075E-25,50.54145820051144 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-7.105010634544169E-15,5.141592653597221 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-7.105427357601001E-15,22.107425452956136 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-7.105427357601002E-15,158.38968654271028 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-7.105427357601002E-15,181.80758020520153 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-7.105427357601002E-15,32.53678904690653 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-7.105427357601002E-15,78.19632509320897 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-7.105427357601002E-15,85.23702556463863 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.25663104001583,-1.5707963267948966 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.25687565646066,-0.9500135644897063 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.26150983650179,-47.75671742766107 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.2893091055764,20.420352249982912 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.32373409290385,-22.29797475756144 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.33280479246064,-37.43959804663202 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.35870514192038,-66.2495379084742 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.37009198993132,-1.0053823416929744E-87 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.37694383452171,-1.570796326790049 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.37797618563513,56.49848432233784 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.38475617333035,3.142083693960858 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.39050641106381,-3.150115028456435 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.4006248683293,-3.1520303482258587 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.40405857113744,-24.968623956382537 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.40559689757245,-0.013458165500182922 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.4065049178164,-29.174856560470715 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-7.24165379725373E-18,53.40707603462061 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.42388823533791,-1.5707963267948966 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.43617746820013,-40.911985818217424 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.45637966957288,6.533505165785913 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.46436699100288,-1.2354633016555425 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.46859301035859,0.21703985495969516 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.47367536719787,85.96821521719949 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.48937153483448,-50.73380792933568 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.51018065563146,-1.5707963267948966 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.52900473404046,26.91134543672778 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.53191514514003,67.50479238778914 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.54591649599075,20.42035226819769 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.55850535874588,-1.5707963267948966 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.56034893222498,-73.41230286425571 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.58036267338974,-6.513312341894389E-17 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.5856763711496,-64.30688059443435 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.60478223844478,-46.794773342147295 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.61026005718472,-1.5707963267948966 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.63768361985213,84.55859251764987 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.67303120330614,-88.84165848248726 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.67674346998722,-2406.886347608983 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.69947695368315,-42.635649184755145 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.72492102116335,-81.88269419630225 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.74299990556405,-17.27876748572977 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.76937971651877,-5.343949917912475 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.79197314706785,-1.5707963267948966 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.79749591814524,48.34827210065453 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.81301231797147,14.429353301400766 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.8205186746641,1.5707963267948983 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.83227816438587,-1356.515552014132 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.85112427590805,-1.5707963267948966 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.87627219644962,62.51428499720032 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.89744701071798,31.82979456469061 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.95991563848423,-2.1229824868103476E-17 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.96872365619404,91.10618917149327 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.97147121889317,91.97300690714727 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.97945413615831,-5.1722373607174E-16 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.98001783626687,-82.25228086473713 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.9938349969018,-100.0 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-72.99784814321879,-92.93050528425091 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.00262742157702,5.421010862427522E-20 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.02065275580965,22.700875524026728 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.02222691006617,-19.716192905538506 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.02238423342033,-1.5707963267948966 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.02451417118559,-1.1252288379450635 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.0595123726668,-68.59403411645079 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.09235299357559,31.463056379624398 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.14658023981877,-15.723588332831856 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.1983837138387,1.412373165590862 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.20142879132696,87.76801513326082 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.22866467961167,-4.3366023733009085 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.25142528662921,31.81700907384085 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.2566187827199,58.824975433108605 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.26492875175433,-2.8451311993408992E-160 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.28609347485536,-17.320538189519997 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.30401039974515,-40.1980982291914 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.31506881394625,74.23126825572513 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.34094999012747,-76.71169303421892 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.35838554257656,28.064195106545114 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.36598538819736,-49.009759080768056 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.37527858822766,-36.0876874209302 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.37711130743158,1.570796326794893 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.38027151742098,-99.62225965449944 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.38648461495275,2.5154847619858987 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.38766599134424,-6.045485954158833 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.4119672066841,1.5707963267948966 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.43535033311983,-27.977529002430305 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.45338717673945,-49.10184804043701 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-7.34822331007841E-17,51.836278784190156 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.4870573230082,-1.5707963267948966 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.49488052042847,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.49994730227006,-50.2651411658455 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.5586302553862,-80.22926712781528 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.55884475492704,-93.20593984890333 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.56117752525242,0 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.57022151439593,0.7365515139496369 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.58528445596735,-60.78918862869084 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.59499676954076,-99.75526661115526 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.6057882966044,77.32302448341598 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.61426449298582,-1.5707963267948966 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.619190677017,-94.28552904545165 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.62997834956712,90.9819503189547 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.7128240079575,-1.5707963267948948 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.72107095644584,-17.13271206257496 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.7297368945948,-1.1435391376955651E-16 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.74953615208817,-1.5707963269269134 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.79831120460014,-174.50824967996613 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.80991345062156,1.5707963267948963 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.81089058430246,-374.16432312732553 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.8115169702561,-56.740881620155136 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.81598291150347,1.570796326794877 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-73.82742732547496,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-739.02531840417,0.0921320400747491 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-7.429855765414136E-16,0.2025344835885594 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-7.445694740206752E-12,0.0 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-7.454125042689287E-8,94.24714168145907 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-75.31319702641079,0 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,7.617389767362664E-17,56.212519053950786 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-7.675655095329752E-11,89.50271020303768 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-7.73382847986328E-15,1.5707963267948963 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-7.820637090558988E-149,89.45291564377774 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-783.3428147829761,-60.86473840199827 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-78.53981633974485,-1.5707963267948966 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-78.5398163397576,-42.18883824785885 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-78.539816363187,0.26928559986365475 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-78.55955206169463,-54.77888928938522 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-78.57431641448579,-23.91916834961368 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-78.58306395718807,1.5707963265043747 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-78.6076567129269,133.89468645604646 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-78.65038142556702,-87.58756505008482 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-78.65357944992759,-34.248744990011424 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-78.66024075986056,58.488195776085064 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-78.66460364464042,57.84374409504386 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-78.68480190688423,-49.50356123077206 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-78.84431926560427,34.631178395613034 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-78.84480404635205,34.76971694718148 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-78.85410448313927,-0.1621577158078651 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,7.889327491525262,19.691790066420445 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-78.90338441412696,-66.66344660336519 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-78.9234963282667,-100.0 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-78.9497849165601,-1.5707963267948966 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.00689818560373,-1.5707963267948966 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.01024582774181,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.01590839936159,-22.650835130667172 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.0177276908154,1.5707963267949339 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.06163212952919,-47.06869051797193 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.07374165463952,-1.5707963267948934 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.08290442451444,-94.34557796024067 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.08567907810217,-18.862003521622604 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.14038332669845,0.42138426540304474 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.1469424960095,-710.4226137063439 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.15913206848865,-57.52240979154648 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.18167607106112,8.08634922390439E-174 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.18737204226989,76.96902011637005 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.31259498441213,-56.91363521048562 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.31458641899881,-74.07947799502323 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.3174011997494,-61.26047394111795 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.32782448972651,79.9216814565778 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.32942520336961,-40.62945161348347 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.33435974195169,-49.71594318357974 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.34614703782825,-1.5707963267948983 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.35772736634657,1.5707963267948966 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.36491055454663,27.177691694298982 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.37911558587543,-88.6695598183513 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.3874263502127,-0.3851508258190754 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.39431633447045,-53.336305023171015 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.42611782107865,-32.18874406699518 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.45033404428344,20.68876522712063 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.45216260023811,1.5707963267948966 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.4676281075775,-1.5707963267948966 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.51014504622502,-57.117701472834206 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.55427799401518,2.220446049250313E-16 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-795.7717558172322,-54.15142201542205 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.58603312353243,21.473467132490015 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.59928562086378,0 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,7.96044961177665,305.7344636182114 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.62067340999528,-22.3740429898003 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.62555636184696,-5.000925198471533 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.62598878789595,2.0679515313825692E-25 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.63136784553535,-54.134328646540474 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.63586164206632,-56.84227468996241 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.64766438766506,1.570796326794895 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.65299941067681,-98.24814624016433 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.65938686848672,6.283189010534616 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.68484008307516,6.776263578034403E-21 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.72944788183771,26.777312128138917 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.73817901597256,-1.5707963267948966 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.77586714328658,78.2795603898764 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.77930590602504,-13.567056820786789 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.80923440237073,-59.82897037034295 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.81634833810512,-75.29190758345047 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.81835992180396,-48.72670047407319 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.83993783004516,-7.697353594527229 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.85147141404032,-50.14785947271845 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.85791750648427,1.5707963267948966 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.8907308101823,-26.77201771597064 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.91555187489988,1.5707963267948966 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.94969568093885,1.5707963267948912 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.95929272104891,-35.357896456820924 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-79.96689300047987,-30.716532094944313 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-80.03545635312979,89.87701090392227 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-80.06095868328808,-78.79025684491984 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-80.07319488535678,1.5707963267948966 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-80.11042843076002,-79.7192481181552 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-80.1105984586729,-6.283365209371284 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-80.11061036205601,-103.67252413305833 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-80.11061249359794,-97.3877858195145 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-808.2472545834431,-13.288084524797371 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-8.085212625435957E-11,44.19213918565898 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-8.194185227199932E-4,1.5707963267948966 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-8.271806125530277E-25,1.5707963267948963 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-8.44002061080295E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-84.82300164692448,0.19609127773155194 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-84.82300927635036,-72.64179656635996 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-84.82300927690935,91.95362326844707 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-84.82982765111117,152.21631842386353 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-84.85425164692442,-100.0 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-84.86711126591051,0.10490475185554314 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-84.92161394693173,4.367158766445385 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-84.94184658775902,1.0473516708648565 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-84.97096322369153,99.66344231022987 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-84.9777480128792,1.5707963267948912 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-84.97973726527738,8.804230159285773E-14 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.0126396948683,-1.5707963267948966 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.01440619331304,0.0 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.02090688692552,-76.65449348408033 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.04360741452658,-457.10139430476704 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.05125211916413,-16.592670894094145 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.0608436730065,-1.5707963267948966 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.06230244490459,-95.63977092819792 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.07706551650537,-1.5707963267948968 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.10238206692715,-0.2881599850350654 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.11925782996562,-17.499167419064634 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.13069085176552,-33.505244961594855 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-8.515375199910608E-19,-97.38934525210189 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.16542036523622,-38.801457804200524 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.18686474664835,-50.626705119312476 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.2050079738399,20.846529633217582 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.21033835651228,-49.25494775746362 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.22008692994206,2398.242086812489 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.2610557636809,-1.5707963267948457 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.36070493572396,-22.083096775845505 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-8.53892603380428E-17,-0.23653616005864792 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.47344585297873,-65.58905152202495 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.50003314705322,-56.026831198163684 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.54086293230776,-4.471942176824288 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-8.554840523609442E-14,-18.87505596858707 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.55091174812476,1.5707963267948963 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.57726787385688,-55.93428717526878 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.60490907425802,-6.283187109467697 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.6349517482104,-10.800179410744562 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.64079041990514,-50.657701483819345 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.65386021391596,-1.5707963267948966 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.67535836298653,0.10281198353848875 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.73510091028012,-1.5707963267948983 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.74991760607126,-24.708075119055888 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.7843875402566,-1.5707963267949019 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.79092133631943,-3.700451733654319 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.79247306506971,-19.834232017362382 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.83894040744042,32.54543182605049 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.88512559441395,0 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.90716199754755,-26.61420616348923 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.91166245725161,-0.39267491500028484 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.92344990370617,-42.846154085774415 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-85.96283522076165,-1.5707963267948928 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.03014077875093,-55.075609282215865 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.0326811572425,6.429229409916471 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.06643415044859,-51.44035217251304 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.06942464653163,-32.191103175516346 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.08112218318902,1.5707963267946994 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.10729810880011,-76.48150212742907 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.10815214623189,-36.106008447699374 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.10980851114468,-954.6295824897941 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.12491930230122,-29.647493650396772 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.19551934988237,1.5707963267948966 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.19717517167653,-130.21802572208054 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.23362153769068,-80.59785399711058 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.24015753213018,-54.84496060013007 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.29126434925169,7.853981633974504 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.29445044725146,-36.20077050524348 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.2977874257335,-1.5707963267948966 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.30208979384604,-52.83900363867719 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.32551302918223,-94.36015430504575 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.34674966343292,-1.5707963267948966 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.35589096852848,1.5707963267948037 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.35637905217423,25.136955399297257 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.38425991877395,-1.5707963267948912 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.39348720015022,-62.831853074586576 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-86.39359468431132,-59.69023626773492 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-864.8798035370505,-70.1826518981735 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-8.671990992609389E-14,43.5524816270717 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-8.673617379884035E-19,0.0 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-8.673617379884035E-19,-88.6396750513781 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-8.698642324468967E-15,35.47215294100015 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-8.878247515006222E-14,17.335265811939585 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-8.881784197001252E-16,0.0 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-8.881784197001252E-16,100.0 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-8.881784197001252E-16,41.92754959481538 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-8.881784197001252E-16,93.78592432876468 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-8.881784197001252E-16,-99.63577238444203 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-8.965426487018747E-11,-34.557285272877074 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.010069899873062E-15,-91.642470667133 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.018483583277324E-4,1.5707963267948948 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.106675235354,1.5707963267948966 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.11624554269633,-136.4720169075045 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.13355114680446,-3.1415931672753126 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.18225727496903,-1.5707963267948957 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.18238830592708,1.5707963267948983 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.21045505460224,-12.875836423276695 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.22330891932418,8.103992441147051 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.2536348067675,-681.4922412878583 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.31693480690966,2.465190328815662E-32 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.132255225627075E-15,6.0834930121445114E-210 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.32449079694344,-49.95968258975401 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.38816444087996,0.7747408561910507 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.41695361498361,-84.31370050405347 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.43783859403632,-1.5707961111702147 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.4844821698262,-45.41784029899944 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.49519815363527,78.14455064566063 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.49705296295164,-0.5344213678772105 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.50476420870714,-40.84638385752076 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.58846581608091,-1.5707963267948983 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.6582223065931,-66.92551409715045 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.7249314673881,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.75888235131245,-30.23846867769002 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.82818609126566,0.024298899177044975 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.8298499897571,6.916632523806744 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.87585057601834,-100.0 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.91422238383369,-175.69498315977648 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-91.98733309928724,-1.5707963267948966 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.00009121473198,-3.1415926891763166 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.00116309337203,-1.5707963267948966 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.03414699816719,-95.14569191240601 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.05865050674504,-9.548412046696775 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.12865658715626,-74.09522492214 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.14231390651979,-56.650889154454084 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.33409321116193,-44.217436983679484 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.34567379874215,-3.1415926689835216 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.38317498312085,1.5707963267948966 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.41475226630946,-6.283246797771466 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.47306081257673,-56.18311970423508 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.48426528820397,-53.332190983605436 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.49040412169946,-41.52701358096368 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.51110878737025,-72.32286471000546 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.51742778425317,-49.85904543023115 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.53368880249216,-76.7735722597789 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.54150093134045,-87.73015685595604 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.55544551841322,-9.566443335772902 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.5591425949384,-49.717477216376 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.6520821733355,-35.6299966473618 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.65339234925071,0.6472591047866842 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.67686707187876,-37.71523985541914 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-92.77555480636413,-38.18950824245061 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.424777960769381,-1.3658721431493674 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.424777960769381,53.97865764330917 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.424778032163031,-29.89722321609398 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.424900032471092,-66.6721351739953 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.425082764530867,0 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.42526704326186,-1.5707963267949088 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.42868421076947,-54.675749464589614 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.42868421081577,1.5707963267948966 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.430420411913666,-56.40649035267965 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.433011368280766,-85.84948747151505 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.471333628641743,-1.2757104340757108 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.488691348758149,-16.789289622279966 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.494065849456135,-574.9570014630661 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.518086014755056,-1.5707963261080677 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.533143479064845,-82.80230533950343 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.538019385819908,-1.5707963267948966 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.541546057152742,21.46336773198977 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.543134910616004,-1.5707963267948966 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.545736699831785,-1.3234889800848443E-23 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.54764994296685,45.30266627747887 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.547683505668004,-6.283200565969278 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.549609956101202,-79.14386359730081 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.575083274053465,-1.5707963267948966 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.592417266918197,-0.9934358519258613 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.593282818883085E-17,-26.79934955740168 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.59532370334452,-0.8758191463042575 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.606747602855094,-1.5707963267948966 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.627134351688527,-1.2141888007347976 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.640245833376214,-59.81372208218836 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.674777960769404,-1.2054954022285291 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.67483236942929,78.46013257720233 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.693318961033341,-12.138633079961679 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.701276226943804,-0.2583432829307409 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.701580649298217,-40.11686121838602 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.734369277131208,1.570796326794882 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.38950369532697,-55.22680587630728 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.38992668960915,-100.0 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.40304484828083,100.0 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.4103383194776,63.97871931165517 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.743773621882767,1.5707963267948966 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.745125816355522,-72.37631249327274 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.4732526654481,1.5707963267948966 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.47387862294057,-97.96517231221564 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.50603587016369,-22.403716126351075 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.51527774383527,25.698321375565026 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.51632148037702,-60.825298942304045 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.5255763232908,-1.5707963267948966 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.754035401834612,-73.59856602462455 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.54076725125829,-99.2838638716401 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.55871384339078,-1.5707963263590554 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.61765808543925,-1.5707963267948966 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.767815116471638,27.192727975710504 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.69483034703578,-6.690466773399422 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.6955885108409,-26.308019124939122 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.70512172789152,-129.4911604999154 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.774402082131132,-72.66554037071774 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.78062828991082,-1.5707963267948983 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.78744265717813,72.7169701002682 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.80702606796365,1.5707963267948968 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.8265898355331,34.69566075221418 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.783591669895245,-2.7182308067752246 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.85889665093076,3.142080935125269 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.89635959544643,91.04743362594049 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-97.98215740817639,-1.5707963267948966 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.0295691994622,-80.92223941292113 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.0505613153671,1.4051691329608011 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.05343102650978,-2218.538236869628 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.07017906917841,-1.5707963267948966 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.81253083779352,-88.87430031000683 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.14985062162216,31.553220793058887 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.16973185119303,97.41098921222084 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.817149753733945,0.09212292888468437 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.18390326339286,94.83874339359267 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.19086874013976,40.91371250414841 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.26084586176059,-67.14796770904063 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.26342236059969,-30.005781751008655 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.33963382834813,0 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.35034035379937,-28.34599896600308 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.3703460485164,2.6469779601696886E-23 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.4424050620352,-82.73362812683591 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.47256388935898,-1.5707963253175945 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.49290183645405,-13.73101612066842 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.53492939546325,0.25624041907946976 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.53503221110542,-60.6190433335487 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.53778550221797,0.9740979790156901 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.56913998599613,-100.0 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.6059408798566,1.570796326794896 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,9.860761315262648E-32,2.037847319695424E-34 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.860761315262648E-32,-86.94155082148322 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.62937355185865,75.76046802680224 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.866962722399743,-13.128728910982971 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.6773741440567,-26.310153617210602 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.74599292064346,6.283217705195523 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.7557184952401,54.83045954332971 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.76516589781804,88.2399820582316 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.82583682782186,98.42588706793771 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.84790850430366,-4.712388980617131 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.84791568282911,16.938747183541377 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.886752001463293,-49.841973864473196 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.88913169799511,67.54298070219846 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.89861343887965,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.93406395077614,-24.12460038364634 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.895520696335609,-14.476467317319297 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.95699307981153,95.31626686271697 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-98.96016857899107,-1.5707963267948966 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.896884810999003,-22.567823775824834 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.913835302014255E-119,0.6402564857936998 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.917023921376463,0.12066282440605643 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.918534496652011,-76.07333831896739 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.930658729198107,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.931891558525297,20.892004139469986 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.940557356018541,-88.06920881838064 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.944303976572481,-157.15691299124265 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.949273942660085,-28.27433433745673 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.959524980750569E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.981430087688196,59.83577528814096 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-9.995574283676474,-25.153200569226495 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-0.028275110984827802,0.0 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-0.03223232386274688,77.18291143432438 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-0.29684287040524754,-7.645942083889693 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-0.6082789636217946,41.86538777036775 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-0.9077397724338867,-566.7813265007421 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-0.9589911372734424,3.552713678800501E-15 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-1.2486949415495319,48.06684106883511 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-1.4705049904706229,19.07272474853294 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-1.564046519249572,34.221653808170714 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-1.5707962909187216,0.7554161434074304 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-1.570796326794886,-1.2597522938937153 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-1.5707963267948948,-51.411122982646475 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-1.5707963267948966,-0.03937505826895581 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-1.5707963267948966,-16.814368520922873 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-1.5707963267948966,-17.237867985546746 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-1.5707963267948966,48.30781051602608 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-1.5707963267948966,-54.588338956457456 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-1.5707963267948966,70.27918039216533 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-1.5707963267948966,-82.30372672856338 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-17.115799421419194,273.197662479733 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-192.94698898930142,-42.57517130645381 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-3.1738603078869936,-88.18886303673035 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-3.2630383558521174,7.853981634971988 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-35.0619631826454,-1.5707963267948966 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-3.525874547954136,-79.80643596058091 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-35.33166361722565,100.0 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-41.364668595827176,88.08254483176567 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-41.95793402294038,-1.5707963267948966 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-457.10003862963885,-42.08970154687767 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-4.616261312137642,-64.08565752696236 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-47.84402700989572,-111.78714796096536 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-48.394224161492716,60.207059778687714 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-53.407075111026515,-100.0 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-54.864120443425975,-106.81555791761221 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-59.83615305389116,-1.5707963267948966 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-60.290425320694,-2420.347775874565 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-66.49931221976354,66.43709932387294 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-67.32461976705538,-18.27629342573995 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-73.39470204525423,-1.5707963267948841 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-78.53982396914147,-1.5707963267949054 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-79.8184780166304,-55.70884006005312 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-80.09105967066037,0.1370538859389953 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-85.67829830245876,1.5707963267948966 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-85.87860768797312,-90.65813607747394 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-91.10667523546451,-84.6754611531211 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-91.29188233929108,-0.8699004941307038 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-91.98631281320213,90.91323610309414 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-92.27762768664228,-96.164595168969 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794897,-0.12509350066259428,-558.4619103129227 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794897,-1.2641178598506406,-57.96564802191104 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794897,-1.4484958975621525,112.73806404726523 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794897,-1.5707963205733098,-2.120178488959841 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794897,-1.570796326794893,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794897,-1.5707963267948966,-4.141593020401831 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794897,-1.5707963267948966,-4.989481684233567 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794897,-1.5707963267948977,46.9479911882384 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948972,-116.42425676043413,-47.26557234864203 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948972,-1.5707963265738165,1.5707963267948983 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948972,-1.5707963267948966,83.51185964906225 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948972,-1.5707963267948966,94.58021320374799 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794897,-22.51896009229941,0.1098035637512993 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948972,-29.488065999975298,-148.4010108828777 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948972,-4.145765079251982,-21.83506932886964 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948972,-67.17593464696932,-0.03714216014215242 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948974,-0.7057646607550332,76.89780842282272 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948974,-1.5707963267948912,20.420352248333653 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948974,-1.5707963267948966,66.25366163196358 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948974,-1.5707963267948966,78.50946852904275 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948974,-179.37799912796422,134.02216511272354 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948974,-28.58933582126469,-99.51895905959587 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948974,-394.2668038003499,-15.440867350314562 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948974,-54.28896171098197,89.8337742288569 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948974,-54.54399288015407,-100.0 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948974,-92.63880788940551,1.5707963267948966 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794897,-60.595702213847375,-1.2256911059035371 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794897,-61.003884705115,182.34023071276516 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794897,-66.05994785185524,0.09272275540879184 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794897,-66.56329186151271,-54.61312898425639 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948977,-111.48672469836855,28.27435582200011 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948977,-3.4874220631532507,-135.60877552145752 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794897,-73.57338324939946,-1.5707963267948966 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794897,-73.69283081173378,-1.5707963267948966 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794897,-78.63837303664701,7.853981633974484 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794897,-97.79902039625044,-1.5707963267948966 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794898,14.429351108460239,111.28549739216044 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.007276650969128953,-90.18607719330267 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.02140566938003661,-1.5707963267948966 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.03847452238725513,-1.5707963267948966 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.05799284580876358,38.92848374985448 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.06981296038441372,-99.57995626806301 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.09865422182638811,78.1954157572147 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.11877326853817038,-40.29401988368222 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.1250133869449852,-169.54373322167876 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.12778054818681017,91.09071846777633 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.14406491046780445,422.52529460538443 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.14837302010064773,-100.0 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.17983055593649055,15.434976301001683 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.19318537462756583,1.5707963267948966 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.19808196415905188,22.14333556570341 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.2705577577519571,-893.086229760439 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.28966521909801624,0.12683143337626523 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.2964137025109568,41.0983336431051 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.3507588720877294,68.26026691428382 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.4158781221344867,-32.85551439752727 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.456986867588136,65.9174471587119 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.47870429564174827,8.853981633847717 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.49956546475692826,-57.21232294095411 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.5551807989644961,-8.761087680242682 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.5748562819160488,67.75885167910039 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.6059054008495252,-50.926494165516154 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.6238518399786049,128.5158158817854 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.6246022036613798,-26.835906500055316 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.6407090186023164,66.21258526405177 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.7172059871364787,34.55751918948773 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.7261040627089886,9.316220018108481 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.7625195414194617,147.619952221024 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.7987937362642817,-32.481904829933065 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.9416496438643804,2.826395520648545E-15 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.9509928575385636,18.135863857684555 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.951484397970443,6.175184846673915 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.9575682109127472,-30.159482651658948 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-0.9956562954444882,-154.86363346944725 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-100.0,-16.90880528706981 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-10.0116392336868,194.77874475087162 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.0014240235739433,55.14909120161202 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-10.297540839196003,19.111189498430726 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-10.325904415055817,13.94740596411485 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-104.65629563950307,68.35701465714087 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-10.644937636766588,-31.84229070416702 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.071476492655563,657.6946090067912 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.0873417635016125,-84.79638025349617 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-10.991484375729137,-50.84498219223386 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.1231970538060474,-36.20978646820926 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.1479722420811742,132.00113307649377 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.14966354577471,-97.0965883099169 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-116.78174917059962,-131.94807343756236 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-117.3835992125843,1.442493021082952 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.2116488906526843,95.11499071864083 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-122.63494282242603,-20.128315968972103 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-122.8306613935529,4.239548204725277 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.2304532975759592,-1236.85430083124 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.264083302320369,-82.76333752233592 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-129.51023108528705,-123.09964401294398 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-129.72245860688335,-2377.842668860084 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.3226605507956999,84.29964648270717 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.350678200540835,-1470.03309753045 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-135.16576882165944,-92.21253404170422 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-136.32892924732906,-31.702430892864854 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.4312306824097902,50.27677684168901 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.4431007383332564,50.06366076132517 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,14.438668432505821,-630.2611659660873 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5242554037523814,-39.26929202089305 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.550444042518461,0.0 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.570796326524792,18.903477361287134 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963265553762,-18.14702923591662 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963265787506,0.6269886039432128 ) ;
  }

  @Test
  public void test3659() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267864686,89.90877593124019 ) ;
  }

  @Test
  public void test3660() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267941012,35.79274567145504 ) ;
  }

  @Test
  public void test3661() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267947198,33.397453652229615 ) ;
  }

  @Test
  public void test3662() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948124,-1.5707963267948966 ) ;
  }

  @Test
  public void test3663() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948721,100.0 ) ;
  }

  @Test
  public void test3664() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948912,272.3158756426117 ) ;
  }

  @Test
  public void test3665() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948912,32.34019610674886 ) ;
  }

  @Test
  public void test3666() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.570796326794893,-1.5707963267948966 ) ;
  }

  @Test
  public void test3667() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948941,0.0 ) ;
  }

  @Test
  public void test3668() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948948,30.548515682111343 ) ;
  }

  @Test
  public void test3669() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948957,-67.08226945475663 ) ;
  }

  @Test
  public void test3670() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948961,-21.484963985489447 ) ;
  }

  @Test
  public void test3671() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948961,72.37325432100049 ) ;
  }

  @Test
  public void test3672() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948961,84.410404081787 ) ;
  }

  @Test
  public void test3673() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,1.5707963267948963,0 ) ;
  }

  @Test
  public void test3674() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948963,-1.5707963267948983 ) ;
  }

  @Test
  public void test3675() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948963,2.220446049250313E-16 ) ;
  }

  @Test
  public void test3676() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948963,-73.82805700521234 ) ;
  }

  @Test
  public void test3677() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,0.7642247798479646 ) ;
  }

  @Test
  public void test3678() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3679() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,141.742821127365 ) ;
  }

  @Test
  public void test3680() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,-1.5707963267948957 ) ;
  }

  @Test
  public void test3681() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,-1.5707963267948961 ) ;
  }

  @Test
  public void test3682() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3683() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,-19.4177940084324 ) ;
  }

  @Test
  public void test3684() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,-20.109003137885708 ) ;
  }

  @Test
  public void test3685() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,20.836456303570642 ) ;
  }

  @Test
  public void test3686() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,-21.49312675009434 ) ;
  }

  @Test
  public void test3687() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,-23.898319565351628 ) ;
  }

  @Test
  public void test3688() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,-25.393035806676217 ) ;
  }

  @Test
  public void test3689() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,-28.25779591414465 ) ;
  }

  @Test
  public void test3690() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,28.610648290990838 ) ;
  }

  @Test
  public void test3691() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,42.84240873916892 ) ;
  }

  @Test
  public void test3692() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,-48.30097275888514 ) ;
  }

  @Test
  public void test3693() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,-58.89914352403823 ) ;
  }

  @Test
  public void test3694() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,-66.05373859142273 ) ;
  }

  @Test
  public void test3695() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,66.84523873120716 ) ;
  }

  @Test
  public void test3696() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,-6.703734108154205 ) ;
  }

  @Test
  public void test3697() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,-73.57358854147381 ) ;
  }

  @Test
  public void test3698() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,744.4230219562442 ) ;
  }

  @Test
  public void test3699() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,90.6718938044991 ) ;
  }

  @Test
  public void test3700() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948966,-9.96221489426408 ) ;
  }

  @Test
  public void test3701() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.570796326794897,59.20467033659909 ) ;
  }

  @Test
  public void test3702() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948983,0.9128340875143977 ) ;
  }

  @Test
  public void test3703() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948983,10.408909695542363 ) ;
  }

  @Test
  public void test3704() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948983,-1079.6925620164866 ) ;
  }

  @Test
  public void test3705() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948983,-1.5707963267948948 ) ;
  }

  @Test
  public void test3706() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948983,-16.94816527066652 ) ;
  }

  @Test
  public void test3707() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948983,-22.32895281628933 ) ;
  }

  @Test
  public void test3708() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948983,26.998308636731025 ) ;
  }

  @Test
  public void test3709() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948983,-33.786541287757146 ) ;
  }

  @Test
  public void test3710() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948983,-78.9776424555334 ) ;
  }

  @Test
  public void test3711() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948983,90.36748480482967 ) ;
  }

  @Test
  public void test3712() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948983,-92.16146205816177 ) ;
  }

  @Test
  public void test3713() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267948986,0.0 ) ;
  }

  @Test
  public void test3714() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.5707963267949054,17.147325739078155 ) ;
  }

  @Test
  public void test3715() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-15.978295734302122,-35.00238268937454 ) ;
  }

  @Test
  public void test3716() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-161.40975502700212,10.430418458734579 ) ;
  }

  @Test
  public void test3717() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-16.338714998612136,1.5707963267948968 ) ;
  }

  @Test
  public void test3718() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-16.65836268063773,-5.212705111900618 ) ;
  }

  @Test
  public void test3719() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-16.820893547999674,-76.21273000531623 ) ;
  }

  @Test
  public void test3720() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-1.7763568394002505E-15,-56.362641254447695 ) ;
  }

  @Test
  public void test3721() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-185.67337952961844,-68.90155125711499 ) ;
  }

  @Test
  public void test3722() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-186.51364731467348,-3.5689208156849617 ) ;
  }

  @Test
  public void test3723() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-22.00038871037725,34.87929125171985 ) ;
  }

  @Test
  public void test3724() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-22.43151955411281,-16.215901108091007 ) ;
  }

  @Test
  public void test3725() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-22.754742676401065,0.9079266782750204 ) ;
  }

  @Test
  public void test3726() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-22.831030023174023,41.073943037361815 ) ;
  }

  @Test
  public void test3727() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-23.170142453098087,-40.17739340829425 ) ;
  }

  @Test
  public void test3728() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-23.557219715004948,-44.365014308661166 ) ;
  }

  @Test
  public void test3729() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-2559.67845894251,0 ) ;
  }

  @Test
  public void test3730() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-28.30872233373396,-72.39053816069722 ) ;
  }

  @Test
  public void test3731() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-29.025372618902445,-66.88762421638864 ) ;
  }

  @Test
  public void test3732() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-29.37905982161891,-27.86376666932657 ) ;
  }

  @Test
  public void test3733() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-29.50141787268615,26.961985921192955 ) ;
  }

  @Test
  public void test3734() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-29.545274707397297,-82.10374326304233 ) ;
  }

  @Test
  public void test3735() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-29.823350504933018,-67.05806689968806 ) ;
  }

  @Test
  public void test3736() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-3.1416152588604445,-83.05637214649211 ) ;
  }

  @Test
  public void test3737() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-3.1421543748652576,-138.6746095049711 ) ;
  }

  @Test
  public void test3738() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-3.17390194343621,-25.30619136225941 ) ;
  }

  @Test
  public void test3739() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-3.201134363262071E-12,104.80781083362066 ) ;
  }

  @Test
  public void test3740() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-3.207455977837199,-25.759951138372372 ) ;
  }

  @Test
  public void test3741() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-32.3766839765936,-23.716659132667502 ) ;
  }

  @Test
  public void test3742() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-3.2445536278006433,114.07597972983325 ) ;
  }

  @Test
  public void test3743() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-3.2456208891789373,-109.17535590281955 ) ;
  }

  @Test
  public void test3744() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-3.268424323807117,148.45436533372362 ) ;
  }

  @Test
  public void test3745() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-3.2699259527370925,-25.434052642755375 ) ;
  }

  @Test
  public void test3746() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-336.44611130235916,-41.22679501698018 ) ;
  }

  @Test
  public void test3747() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-34.557519189487735,3.552713678800501E-15 ) ;
  }

  @Test
  public void test3748() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-35.10626099056799,-1.5707963267948966 ) ;
  }

  @Test
  public void test3749() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-35.32778366381669,6.733854217625588 ) ;
  }

  @Test
  public void test3750() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-3.5730863655239204,-100.0 ) ;
  }

  @Test
  public void test3751() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-3.6011962458850917,64.29088757939556 ) ;
  }

  @Test
  public void test3752() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-3.6107455327391165,35.48225895620587 ) ;
  }

  @Test
  public void test3753() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-3.8105803754247916,-110.10142099127945 ) ;
  }

  @Test
  public void test3754() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-381.51421321365905,1.333479429279488 ) ;
  }

  @Test
  public void test3755() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-394.26987799809456,-25.32647169096866 ) ;
  }

  @Test
  public void test3756() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-399.82117042128675,7.261710805509978 ) ;
  }

  @Test
  public void test3757() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-4.108724284391229,73.45670190563004 ) ;
  }

  @Test
  public void test3758() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-41.11776870235086,1.5707963267948966 ) ;
  }

  @Test
  public void test3759() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-41.55416379970845,-544.8697893866114 ) ;
  }

  @Test
  public void test3760() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-42.003082158742224,66.48053778282542 ) ;
  }

  @Test
  public void test3761() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-42.00581158544674,-0.2453840855517717 ) ;
  }

  @Test
  public void test3762() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-462.9801699448168,-0.13465530931697833 ) ;
  }

  @Test
  public void test3763() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-47.37055306750373,79.56978073692657 ) ;
  }

  @Test
  public void test3764() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-47.41996511840689,36.14125727026281 ) ;
  }

  @Test
  public void test3765() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-47.465380903479314,-117.93841633232472 ) ;
  }

  @Test
  public void test3766() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-47.75498762138517,-79.86059936518497 ) ;
  }

  @Test
  public void test3767() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-47.95008566399459,1.499935873927301 ) ;
  }

  @Test
  public void test3768() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-48.12086187113148,1.5707963267948912 ) ;
  }

  @Test
  public void test3769() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-48.59560926702209,-1.5707963267948963 ) ;
  }

  @Test
  public void test3770() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-50.775652047942984,-10.385961622719336 ) ;
  }

  @Test
  public void test3771() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-53.62442928757071,459.0194671563924 ) ;
  }

  @Test
  public void test3772() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-53.694331139342566,25.620200626071195 ) ;
  }

  @Test
  public void test3773() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-53.85180041259446,-1.5707963267948966 ) ;
  }

  @Test
  public void test3774() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-54.30305086606735,21.91106856648358 ) ;
  }

  @Test
  public void test3775() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-54.32975466344919,-47.23466370781841 ) ;
  }

  @Test
  public void test3776() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-54.42787663539458,-1180.0880675483327 ) ;
  }

  @Test
  public void test3777() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-544.9884699071031,-1.5707963267948983 ) ;
  }

  @Test
  public void test3778() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-54.87512954916216,-97.41666916399015 ) ;
  }

  @Test
  public void test3779() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-54.906066052135685,-1.5707963267948961 ) ;
  }

  @Test
  public void test3780() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-55.48774512237591,29.302177058540792 ) ;
  }

  @Test
  public void test3781() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-576.4743708653382,21.690377727348803 ) ;
  }

  @Test
  public void test3782() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-59.691239381517306,-21.748109785530172 ) ;
  }

  @Test
  public void test3783() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-59.827700058549226,-25.693985611623546 ) ;
  }

  @Test
  public void test3784() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-59.88323638422907,-128.07502313398737 ) ;
  }

  @Test
  public void test3785() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-60.10303315932097,-91.13760853454072 ) ;
  }

  @Test
  public void test3786() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-60.54251527916961,-145.0277570096434 ) ;
  }

  @Test
  public void test3787() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-60.598335657758575,-38.81552287169073 ) ;
  }

  @Test
  public void test3788() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-60.752273118788324,85.7683273719664 ) ;
  }

  @Test
  public void test3789() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-60.863065903499745,69.73813106602518 ) ;
  }

  @Test
  public void test3790() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-61.004593417888444,-68.16526938829296 ) ;
  }

  @Test
  public void test3791() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-62.831931678822095,-75.51547828369685 ) ;
  }

  @Test
  public void test3792() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-66.15925305168142,-142.90163027689266 ) ;
  }

  @Test
  public void test3793() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-66.27905596287845,-1.5483883130273082 ) ;
  }

  @Test
  public void test3794() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-66.30024811479917,151.75959849673526 ) ;
  }

  @Test
  public void test3795() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-66.31534836850192,-121.1261079911565 ) ;
  }

  @Test
  public void test3796() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-66.37564510248153,-24.68908847798809 ) ;
  }

  @Test
  public void test3797() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-67.41369810381492,97.55078221617279 ) ;
  }

  @Test
  public void test3798() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-72.46690132629358,-85.96917661970994 ) ;
  }

  @Test
  public void test3799() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-72.70073684272447,-9.468978339841755 ) ;
  }

  @Test
  public void test3800() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-72.84975668940534,-4.560524949804588 ) ;
  }

  @Test
  public void test3801() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-72.85532605794081,45.531169639838566 ) ;
  }

  @Test
  public void test3802() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-72.87375113693619,72.4353759526881 ) ;
  }

  @Test
  public void test3803() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-73.0095040285308,35.78506157508792 ) ;
  }

  @Test
  public void test3804() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-73.4223453309953,1.1753735252486168 ) ;
  }

  @Test
  public void test3805() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-73.56564282912866,-100.0 ) ;
  }

  @Test
  public void test3806() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-73.74557758216547,-44.7526529973963 ) ;
  }

  @Test
  public void test3807() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-79.30593597143914,15.707963261119014 ) ;
  }

  @Test
  public void test3808() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-79.96765400402487,2323.952959093947 ) ;
  }

  @Test
  public void test3809() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-81.06590067888608,54.246678138956725 ) ;
  }

  @Test
  public void test3810() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-85.45511929879888,-45.97434245091391 ) ;
  }

  @Test
  public void test3811() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-85.48821920800033,1.5707963267948966 ) ;
  }

  @Test
  public void test3812() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-85.99472350920968,-21.188546499969313 ) ;
  }

  @Test
  public void test3813() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-89.23384949962248,-72.552453510238 ) ;
  }

  @Test
  public void test3814() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-91.33956563738657,-25.81365454199039 ) ;
  }

  @Test
  public void test3815() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-91.45977839648141,-100.0 ) ;
  }

  @Test
  public void test3816() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-91.61805908715343,1.5707963267948983 ) ;
  }

  @Test
  public void test3817() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-91.6931486850658,-1.5707963267948983 ) ;
  }

  @Test
  public void test3818() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-91.7927028175367,-1.570796326794898 ) ;
  }

  @Test
  public void test3819() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-92.25461022032445,-49.71057690084378 ) ;
  }

  @Test
  public void test3820() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-92.65965945425319,-1.5707963267937615 ) ;
  }

  @Test
  public void test3821() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-9.426130541470457,2446.485597069609 ) ;
  }

  @Test
  public void test3822() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-97.45115376582967,7.494597767077252 ) ;
  }

  @Test
  public void test3823() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-97.54875707380384,-15.925924431007616 ) ;
  }

  @Test
  public void test3824() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-9.772375406971534,-0.014946284123165133 ) ;
  }

  @Test
  public void test3825() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-97.80592234868317,185.65034750567108 ) ;
  }

  @Test
  public void test3826() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-97.96018070119239,-3.5703783882099245 ) ;
  }

  @Test
  public void test3827() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-98.07913947570097,2358.4556830315646 ) ;
  }

  @Test
  public void test3828() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-98.21088408509915,59.85507385493818 ) ;
  }

  @Test
  public void test3829() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-98.26333078487099,-42.05666000431701 ) ;
  }

  @Test
  public void test3830() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-98.3363421098949,-1.5707963267948912 ) ;
  }

  @Test
  public void test3831() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-98.67305983979448,-32.16985760068587 ) ;
  }

  @Test
  public void test3832() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-98.70421685098958,25.35096054495416 ) ;
  }

  @Test
  public void test3833() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-9.969190715273996,119.07204732000304 ) ;
  }

  @Test
  public void test3834() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079632679489,-85.89832382236833,-7.666911352566785 ) ;
  }

  @Test
  public void test3835() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948986,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3836() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794898,-66.98075952564719,-12.954290939419764 ) ;
  }

  @Test
  public void test3837() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948988,-1.5707963265932852,89.17463806760634 ) ;
  }

  @Test
  public void test3838() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794898,-85.7884978870414,7.853981633996544 ) ;
  }

  @Test
  public void test3839() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794898,-91.92590949246969,-42.81443024693575 ) ;
  }

  @Test
  public void test3840() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948992,-186.27102381464232,0.6578102313732082 ) ;
  }

  @Test
  public void test3841() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948992,-91.86546581101534,1.5707963262076337 ) ;
  }

  @Test
  public void test3842() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794899,-29.58852485582348,-295.244246011934 ) ;
  }

  @Test
  public void test3843() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948997,-3.713156646038502,8.69508641374495 ) ;
  }

  @Test
  public void test3844() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948999,-135.09904781740855,-145.8180304168488 ) ;
  }

  @Test
  public void test3845() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948999,-173.22087659442101,93.40743331312814 ) ;
  }

  @Test
  public void test3846() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949006,-0.15669388549685614,3.1519497749350878 ) ;
  }

  @Test
  public void test3847() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949019,-135.63088860600638,-0.8868872814555822 ) ;
  }

  @Test
  public void test3848() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949019,-1.570796326794889,-1.1115414870502889 ) ;
  }

  @Test
  public void test3849() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949019,-1.5707963267948912,2479.733780124217 ) ;
  }

  @Test
  public void test3850() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949019,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3851() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949019,-1.5707963267948966,1481.5303524483404 ) ;
  }

  @Test
  public void test3852() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949019,-1.5707963267948983,1.5707963267948966 ) ;
  }

  @Test
  public void test3853() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949019,-1.5707963267948983,-81.05703922744058 ) ;
  }

  @Test
  public void test3854() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949019,-16.48721083474193,-96.43079697435645 ) ;
  }

  @Test
  public void test3855() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949019,-1.8112325394491024E-13,-104.82918508602476 ) ;
  }

  @Test
  public void test3856() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949019,-53.61399305775128,86.23310386627607 ) ;
  }

  @Test
  public void test3857() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949019,-538.7169094778792,53.8591367436451 ) ;
  }

  @Test
  public void test3858() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949019,-86.2445335001221,-87.50170875619456 ) ;
  }

  @Test
  public void test3859() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794902,-154.7360543577965,-59.913309630163006 ) ;
  }

  @Test
  public void test3860() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949026,-22.578221156033294,-120.64363126648013 ) ;
  }

  @Test
  public void test3861() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949026,-97.53602882973235,145.28414701695863 ) ;
  }

  @Test
  public void test3862() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949034,-29.233556957623218,-479.08614662213563 ) ;
  }

  @Test
  public void test3863() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949037,-1.5707963267948966,-65.04994073530243 ) ;
  }

  @Test
  public void test3864() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794905,-0.38398568090624335,-1.5707963267949125 ) ;
  }

  @Test
  public void test3865() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949054,-0.3153497323032546,-76.68134642520664 ) ;
  }

  @Test
  public void test3866() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949054,-0.6668657320829313,37.28534560527515 ) ;
  }

  @Test
  public void test3867() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949054,-0.73519113239729,45.04973968482089 ) ;
  }

  @Test
  public void test3868() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949054,-116.80808365890687,-293.5600025634577 ) ;
  }

  @Test
  public void test3869() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949054,-1.5707963267948912,22.45797088746461 ) ;
  }

  @Test
  public void test3870() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949054,-1.5707963267948966,23.51465468929132 ) ;
  }

  @Test
  public void test3871() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949054,-22.148311515744954,1.5707963267949019 ) ;
  }

  @Test
  public void test3872() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949054,-60.092099840090164,-42.67341530869485 ) ;
  }

  @Test
  public void test3873() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949054,-789.3124031685485,-49.763319804342636 ) ;
  }

  @Test
  public void test3874() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949054,-9.631785393885936,-154.29583350347272 ) ;
  }

  @Test
  public void test3875() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949054,-98.13272600600882,84.53811276821673 ) ;
  }

  @Test
  public void test3876() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949057,-110.4766426637455,-3.2666072632214322 ) ;
  }

  @Test
  public void test3877() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949074,-85.06512028847192,132.51227224660025 ) ;
  }

  @Test
  public void test3878() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949079,-154.72726623823425,-128.96234882302667 ) ;
  }

  @Test
  public void test3879() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949094,-4.419438331220706,-238.34598100587652 ) ;
  }

  @Test
  public void test3880() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949,-0.9905891579541463,15.030786854365353 ) ;
  }

  @Test
  public void test3881() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949123,-116.31988555796475,-26.56657993809762 ) ;
  }

  @Test
  public void test3882() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949,-1.5707963267948966,-88.10048434545074 ) ;
  }

  @Test
  public void test3883() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949,-22.50234442380507,-90.86610924313283 ) ;
  }

  @Test
  public void test3884() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794923,-122.78757197955213,-13.265485133055407 ) ;
  }

  @Test
  public void test3885() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949232,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3886() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949274,-61.24197999901662,1.1541179803518482 ) ;
  }

  @Test
  public void test3887() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949,-3.1704352899060915,6.779487549334206 ) ;
  }

  @Test
  public void test3888() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949343,-0.057365139898108986,-180.84900433168923 ) ;
  }

  @Test
  public void test3889() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267949951,-98.1487687784256,177.4834694485437 ) ;
  }

  @Test
  public void test3890() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267950156,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3891() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267950298,-80.00279231942406,-144.85023055017865 ) ;
  }

  @Test
  public void test3892() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267950342,-160.82537756278703,-72.29686867549634 ) ;
  }

  @Test
  public void test3893() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267950689,-0.8055643093491304,-77.28993146766086 ) ;
  }

  @Test
  public void test3894() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326795117,-66.83650198530984,-69.66987934313242 ) ;
  }

  @Test
  public void test3895() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267951257,-130.25690681502073,-77.6429453339162 ) ;
  }

  @Test
  public void test3896() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267951657,-0.5396249794828025,104.28003045427502 ) ;
  }

  @Test
  public void test3897() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267951914,-1.5707963267948966,-94.19156598390444 ) ;
  }

  @Test
  public void test3898() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267952194,-9.428684217176011,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test3899() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267952623,-86.3146888242079,-54.65051645679817 ) ;
  }

  @Test
  public void test3900() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267953398,-0.11956029345506014,153.94710549648985 ) ;
  }

  @Test
  public void test3901() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326795437,-1.5707963267948966,21.583937951362422 ) ;
  }

  @Test
  public void test3902() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326795738,-1.5707739159929812,-112.78775887187604 ) ;
  }

  @Test
  public void test3903() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267958578,-0.2811609091952095,-1.5707963267948966 ) ;
  }

  @Test
  public void test3904() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326795998,-135.74807860202105,-1.5707963216170913 ) ;
  }

  @Test
  public void test3905() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267960443,-1.4368263055111097,-101.79018561674715 ) ;
  }

  @Test
  public void test3906() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326797141,-54.15266562456366,-1.5707963267948981 ) ;
  }

  @Test
  public void test3907() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267975293,-9.799076831460664E-8,1.5707963267948961 ) ;
  }

  @Test
  public void test3908() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267988982,-1.5707963267948966,0.4149083977141643 ) ;
  }

  @Test
  public void test3909() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326799349,-1.5707963267948966,142.99685364945222 ) ;
  }

  @Test
  public void test3910() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267998504,-1.5707963267948948,-100.0 ) ;
  }

  @Test
  public void test3911() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267998877,-1.5707963267948966,-113.11559120057834 ) ;
  }

  @Test
  public void test3912() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963268006022,-173.55408329941412,94.33462558449047 ) ;
  }

  @Test
  public void test3913() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963268018819,-9.71004436293591,-418.8317748124576 ) ;
  }

  @Test
  public void test3914() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963268035199,-274.8893571889685,1.5707963267948966 ) ;
  }

  @Test
  public void test3915() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963268083063,-86.11403004150415,-95.26365756060741 ) ;
  }

  @Test
  public void test3916() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963268316516,-1.5707922981255296,117.83770297007402 ) ;
  }

  @Test
  public void test3917() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963268905165,-1.5709110201756304,183.9830447790995 ) ;
  }

  @Test
  public void test3918() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796327322253,-0.02125406814363373,1.5707963267948948 ) ;
  }

  @Test
  public void test3919() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963275024692,-47.507926377717304,-0.03864167332796114 ) ;
  }

  @Test
  public void test3920() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963285353743,-153.95472656261828,1.2250666251575044 ) ;
  }

  @Test
  public void test3921() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796330468869,-0.9680063755203836,158.29669127549766 ) ;
  }

  @Test
  public void test3922() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963319716316,-8.374493771867166E-5,147.31703140598268 ) ;
  }

  @Test
  public void test3923() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963650565548,-122.89661323913194,-3.1494052651497335 ) ;
  }

  @Test
  public void test3924() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796367694397,-1.5707963267948966,-7.0035736989364645 ) ;
  }

  @Test
  public void test3925() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796385280081,-59.690260657020396,-42.593658395138334 ) ;
  }

  @Test
  public void test3926() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707964384646467,-0.7145158174536953,111.54288262376471 ) ;
  }

  @Test
  public void test3927() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796818004246,-4.322058115098911,-56.456825574216296 ) ;
  }

  @Test
  public void test3928() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707970347348479,-10.493367719440663,202.64050674307512 ) ;
  }

  @Test
  public void test3929() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707971302895125,-3.266593610016998,176.59439943969323 ) ;
  }

  @Test
  public void test3930() {
    coral.tests.JPFBenchmark.benchmark05(-1.5708034188387827,-1.5707961478540213,-138.38175390194354 ) ;
  }

  @Test
  public void test3931() {
    coral.tests.JPFBenchmark.benchmark05(-1.5708072704746499,-135.40236908903606,-124.90032562607738 ) ;
  }

  @Test
  public void test3932() {
    coral.tests.JPFBenchmark.benchmark05(-1.5708072871727512,-84.82300928018589,-129.2615514330965 ) ;
  }

  @Test
  public void test3933() {
    coral.tests.JPFBenchmark.benchmark05(-1.5708118318020836,-450.81847363246584,-1.4376615601950435 ) ;
  }

  @Test
  public void test3934() {
    coral.tests.JPFBenchmark.benchmark05(-1.5708357981939989,-136.33135073936788,-596.3234543905816 ) ;
  }

  @Test
  public void test3935() {
    coral.tests.JPFBenchmark.benchmark05(-1.5708436278367748,-3.1423023468173565,37.74214009405976 ) ;
  }

  @Test
  public void test3936() {
    coral.tests.JPFBenchmark.benchmark05(-1.5708503706916792,-136.13759442806492,-4.712394992178625 ) ;
  }

  @Test
  public void test3937() {
    coral.tests.JPFBenchmark.benchmark05(-1.5709905314838812,-475.35714477852434,-1.5707963267948966 ) ;
  }

  @Test
  public void test3938() {
    coral.tests.JPFBenchmark.benchmark05(-1.5710014354837938,-29.176351892794333,-727.1777846850204 ) ;
  }

  @Test
  public void test3939() {
    coral.tests.JPFBenchmark.benchmark05(-1.571174304146026,-1.5707963267948966,-151.9794188789882 ) ;
  }

  @Test
  public void test3940() {
    coral.tests.JPFBenchmark.benchmark05(-1.5712730762692935,-254.71428548897342,-100.53593687013006 ) ;
  }

  @Test
  public void test3941() {
    coral.tests.JPFBenchmark.benchmark05(-1.5806279294937255,-3.1424814117842303,-119.15840371322025 ) ;
  }

  @Test
  public void test3942() {
    coral.tests.JPFBenchmark.benchmark05(-15.870479432115062,-97.2842781560487,84.27862122274371 ) ;
  }

  @Test
  public void test3943() {
    coral.tests.JPFBenchmark.benchmark05(-15.940407724446956,-11.714246771835505,-72.436996399779 ) ;
  }

  @Test
  public void test3944() {
    coral.tests.JPFBenchmark.benchmark05(-16.290319223687447,-45.54738852772569,-44.79468571141623 ) ;
  }

  @Test
  public void test3945() {
    coral.tests.JPFBenchmark.benchmark05(-16.411426912980744,69.52787176338106,-80.55901666915896 ) ;
  }

  @Test
  public void test3946() {
    coral.tests.JPFBenchmark.benchmark05(1.6534320489251684,63.7294259979777,71.56955024709706 ) ;
  }

  @Test
  public void test3947() {
    coral.tests.JPFBenchmark.benchmark05(-16.779663697592113,87.93663869517553,-64.19979011925862 ) ;
  }

  @Test
  public void test3948() {
    coral.tests.JPFBenchmark.benchmark05(-1.6809143420361892,63.69213204955338,-55.80007219963656 ) ;
  }

  @Test
  public void test3949() {
    coral.tests.JPFBenchmark.benchmark05(-1.6940658945086007E-21,-98.78784863159018,1.0558120813825238 ) ;
  }

  @Test
  public void test3950() {
    coral.tests.JPFBenchmark.benchmark05(17.076930935823455,-14.194822382009022,-68.03325809232672 ) ;
  }

  @Test
  public void test3951() {
    coral.tests.JPFBenchmark.benchmark05(-1.710732271224913,0,0 ) ;
  }

  @Test
  public void test3952() {
    coral.tests.JPFBenchmark.benchmark05(-17.12358342107767,13.443991642234636,-57.44936144717245 ) ;
  }

  @Test
  public void test3953() {
    coral.tests.JPFBenchmark.benchmark05(17.165732728985958,81.09750978425475,-39.094881555736016 ) ;
  }

  @Test
  public void test3954() {
    coral.tests.JPFBenchmark.benchmark05(17.31318350673176,76.70492071704075,-35.88523804074708 ) ;
  }

  @Test
  public void test3955() {
    coral.tests.JPFBenchmark.benchmark05(-1.734723475976807E-18,-0.8473767410114157,9.84935344099766 ) ;
  }

  @Test
  public void test3956() {
    coral.tests.JPFBenchmark.benchmark05(-1.734723475976807E-18,-1.5546016528687283,-46.92703355607962 ) ;
  }

  @Test
  public void test3957() {
    coral.tests.JPFBenchmark.benchmark05(-1.734723475976807E-18,-1.5707522712148578,-78.37143067188399 ) ;
  }

  @Test
  public void test3958() {
    coral.tests.JPFBenchmark.benchmark05(-1.734723475976807E-18,-3.5103554689291245,66.65535932218394 ) ;
  }

  @Test
  public void test3959() {
    coral.tests.JPFBenchmark.benchmark05(-1.734723475976807E-18,-91.60964304822296,0.6659514014640727 ) ;
  }

  @Test
  public void test3960() {
    coral.tests.JPFBenchmark.benchmark05(-17.436116082330003,-73.27332119679919,-79.17883988317979 ) ;
  }

  @Test
  public void test3961() {
    coral.tests.JPFBenchmark.benchmark05(17.698248478668404,85.2244904412266,-50.34283170629128 ) ;
  }

  @Test
  public void test3962() {
    coral.tests.JPFBenchmark.benchmark05(17.717416120620342,-95.41827871112415,-57.457113538913184 ) ;
  }

  @Test
  public void test3963() {
    coral.tests.JPFBenchmark.benchmark05(-1.827087795043749E-10,-111.30474275222556,-42.91958993576458 ) ;
  }

  @Test
  public void test3964() {
    coral.tests.JPFBenchmark.benchmark05(1.8298186486130719,3.426255269100771,-3.944304526105059E-31 ) ;
  }

  @Test
  public void test3965() {
    coral.tests.JPFBenchmark.benchmark05(-18.449395802294006,98.87441991659853,-97.18147183255698 ) ;
  }

  @Test
  public void test3966() {
    coral.tests.JPFBenchmark.benchmark05(-18.596172251550257,35.18647866175374,-59.418416206518465 ) ;
  }

  @Test
  public void test3967() {
    coral.tests.JPFBenchmark.benchmark05(-18.61302759747778,-83.86085546078462,-94.70036695832316 ) ;
  }

  @Test
  public void test3968() {
    coral.tests.JPFBenchmark.benchmark05(1.8712466990648202,-84.83902232520413,70.7579505903624 ) ;
  }

  @Test
  public void test3969() {
    coral.tests.JPFBenchmark.benchmark05(-19.393552389879147,-19.303181510451367,0 ) ;
  }

  @Test
  public void test3970() {
    coral.tests.JPFBenchmark.benchmark05(-1.9465559529250242E-15,-1.5707963267948912,56.07675901082011 ) ;
  }

  @Test
  public void test3971() {
    coral.tests.JPFBenchmark.benchmark05(19.481443362663825,21.626786824468127,-31.594173022621263 ) ;
  }

  @Test
  public void test3972() {
    coral.tests.JPFBenchmark.benchmark05(1.9721522630525295E-31,-1.5292742725389912,-1.5707963267948966 ) ;
  }

  @Test
  public void test3973() {
    coral.tests.JPFBenchmark.benchmark05(-1.9721522630525295E-31,-1.5707963267948966,41.242292557184776 ) ;
  }

  @Test
  public void test3974() {
    coral.tests.JPFBenchmark.benchmark05(19.896696978391077,-39.39471466926949,47.979220687412834 ) ;
  }

  @Test
  public void test3975() {
    coral.tests.JPFBenchmark.benchmark05(-19.92653546329089,-91.21412672828764,-64.13012410767509 ) ;
  }

  @Test
  public void test3976() {
    coral.tests.JPFBenchmark.benchmark05(-20.158827679121714,-48.99497882527646,-12.956209924140396 ) ;
  }

  @Test
  public void test3977() {
    coral.tests.JPFBenchmark.benchmark05(-20.237761025513493,-12.972034920415993,75.06444400423231 ) ;
  }

  @Test
  public void test3978() {
    coral.tests.JPFBenchmark.benchmark05(-20.606034746289964,81.49703339786296,32.56991007022495 ) ;
  }

  @Test
  public void test3979() {
    coral.tests.JPFBenchmark.benchmark05(-20.662926347927794,10.505057890982101,-14.001992019268243 ) ;
  }

  @Test
  public void test3980() {
    coral.tests.JPFBenchmark.benchmark05(2.0679515313825692E-25,-1.5707963267948966,-73.30522609604881 ) ;
  }

  @Test
  public void test3981() {
    coral.tests.JPFBenchmark.benchmark05(-20.690462645198153,0.9395862501440604,-35.765103225713176 ) ;
  }

  @Test
  public void test3982() {
    coral.tests.JPFBenchmark.benchmark05(-21.015671821920165,43.52952127192185,-91.8962089571317 ) ;
  }

  @Test
  public void test3983() {
    coral.tests.JPFBenchmark.benchmark05(21.286908493324262,-8.832811721735538,82.43553070999369 ) ;
  }

  @Test
  public void test3984() {
    coral.tests.JPFBenchmark.benchmark05(-2.1354480011318403E-16,-1.5707963267948966,42.222841560984506 ) ;
  }

  @Test
  public void test3985() {
    coral.tests.JPFBenchmark.benchmark05(-2.141184912656347E-15,-1.5707963267948966,78.00823521279978 ) ;
  }

  @Test
  public void test3986() {
    coral.tests.JPFBenchmark.benchmark05(-21.45314447241647,86.08096227399679,38.65495180527404 ) ;
  }

  @Test
  public void test3987() {
    coral.tests.JPFBenchmark.benchmark05(21.557555588502012,-57.616034187163834,-3.4344957956439686 ) ;
  }

  @Test
  public void test3988() {
    coral.tests.JPFBenchmark.benchmark05(21.631221343722956,6.284602308355119,85.36145880388659 ) ;
  }

  @Test
  public void test3989() {
    coral.tests.JPFBenchmark.benchmark05(-2.1684043449710089E-19,-16.515441287412784,-55.320302401268236 ) ;
  }

  @Test
  public void test3990() {
    coral.tests.JPFBenchmark.benchmark05(2.1684043449710089E-19,-28.54048087426423,25.593315824038 ) ;
  }

  @Test
  public void test3991() {
    coral.tests.JPFBenchmark.benchmark05(22.134217453189024,-82.76007059843144,-20.870369041119986 ) ;
  }

  @Test
  public void test3992() {
    coral.tests.JPFBenchmark.benchmark05(-22.139700027311065,0,0 ) ;
  }

  @Test
  public void test3993() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-0.9770377145921749,37.062330950730754 ) ;
  }

  @Test
  public void test3994() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948948,-1.2847854262229217 ) ;
  }

  @Test
  public void test3995() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948948,-70.33355018565291 ) ;
  }

  @Test
  public void test3996() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948966,1.1615021871765245 ) ;
  }

  @Test
  public void test3997() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948966,55.93019526610392 ) ;
  }

  @Test
  public void test3998() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-35.055248120647576,100.0 ) ;
  }

  @Test
  public void test3999() {
    coral.tests.JPFBenchmark.benchmark05(2.220446049250313E-16,-54.91980045652455,-91.10629197368539 ) ;
  }

  @Test
  public void test4000() {
    coral.tests.JPFBenchmark.benchmark05(-22.374388333256647,-19.7745672799106,49.05411365247889 ) ;
  }

  @Test
  public void test4001() {
    coral.tests.JPFBenchmark.benchmark05(-22.379008735783003,85.04757867951284,-75.40459323196207 ) ;
  }

  @Test
  public void test4002() {
    coral.tests.JPFBenchmark.benchmark05(-22.611053398854224,-17.391584609130234,-95.45124115732393 ) ;
  }

  @Test
  public void test4003() {
    coral.tests.JPFBenchmark.benchmark05(-22.635416642062964,24.37036870939832,38.52714213106577 ) ;
  }

  @Test
  public void test4004() {
    coral.tests.JPFBenchmark.benchmark05(2.2815770371573905,-7.73965653929811,42.670355166753495 ) ;
  }

  @Test
  public void test4005() {
    coral.tests.JPFBenchmark.benchmark05(-23.187847774988285,9.264636181420045,-48.946326610578716 ) ;
  }

  @Test
  public void test4006() {
    coral.tests.JPFBenchmark.benchmark05(2.360506829980011,-35.42994419529259,-56.13382526195867 ) ;
  }

  @Test
  public void test4007() {
    coral.tests.JPFBenchmark.benchmark05(-23.692399939315038,28.10455551415282,-81.91030010454219 ) ;
  }

  @Test
  public void test4008() {
    coral.tests.JPFBenchmark.benchmark05(24.07768855358279,-75.04381443068891,-98.86761333412647 ) ;
  }

  @Test
  public void test4009() {
    coral.tests.JPFBenchmark.benchmark05(24.198972531439054,15.002394314743285,14.753869542780592 ) ;
  }

  @Test
  public void test4010() {
    coral.tests.JPFBenchmark.benchmark05(2.4343994412542287,-19.028729149388553,16.01980352259153 ) ;
  }

  @Test
  public void test4011() {
    coral.tests.JPFBenchmark.benchmark05(2.465190328815662E-32,0,0 ) ;
  }

  @Test
  public void test4012() {
    coral.tests.JPFBenchmark.benchmark05(2.465190328815662E-32,-1.5707963267948948,1.5707963267948966 ) ;
  }

  @Test
  public void test4013() {
    coral.tests.JPFBenchmark.benchmark05(2.465190328815662E-32,-1.5707963267948966,0.8609923552079245 ) ;
  }

  @Test
  public void test4014() {
    coral.tests.JPFBenchmark.benchmark05(2.465190328815662E-32,-1.5707963267948966,-33.06487493667732 ) ;
  }

  @Test
  public void test4015() {
    coral.tests.JPFBenchmark.benchmark05(2.465190328815662E-32,-28.602021122258222,63.78357336307056 ) ;
  }

  @Test
  public void test4016() {
    coral.tests.JPFBenchmark.benchmark05(2.465190328815662E-32,-54.57814293831619,100.0 ) ;
  }

  @Test
  public void test4017() {
    coral.tests.JPFBenchmark.benchmark05(-2.465190328815662E-32,-60.914964810449675,-1.5707963267948966 ) ;
  }

  @Test
  public void test4018() {
    coral.tests.JPFBenchmark.benchmark05(-24.672006525920636,24.064078626935185,97.76274381354352 ) ;
  }

  @Test
  public void test4019() {
    coral.tests.JPFBenchmark.benchmark05(-24.903028358758462,54.2204143324725,-84.47401928654105 ) ;
  }

  @Test
  public void test4020() {
    coral.tests.JPFBenchmark.benchmark05(-25.218634014242554,-47.101739085268,-40.370996177092636 ) ;
  }

  @Test
  public void test4021() {
    coral.tests.JPFBenchmark.benchmark05(2.5243548967072378E-29,-54.641596549761616,60.46464866517661 ) ;
  }

  @Test
  public void test4022() {
    coral.tests.JPFBenchmark.benchmark05(25.80712456499748,-33.975271657332314,-76.9337593567289 ) ;
  }

  @Test
  public void test4023() {
    coral.tests.JPFBenchmark.benchmark05(2.5849394142282115E-26,-35.97828553825558,1.2715305377321666 ) ;
  }

  @Test
  public void test4024() {
    coral.tests.JPFBenchmark.benchmark05(-2.606088136272078,-74.24419562613224,-10.091037550170668 ) ;
  }

  @Test
  public void test4025() {
    coral.tests.JPFBenchmark.benchmark05(-26.12201476740961,91.6483695179187,-62.70674069359408 ) ;
  }

  @Test
  public void test4026() {
    coral.tests.JPFBenchmark.benchmark05(-26.189694764783383,78.57061140556726,-20.793902320552576 ) ;
  }

  @Test
  public void test4027() {
    coral.tests.JPFBenchmark.benchmark05(26.318666240480184,12.791472123306136,-16.922107156649346 ) ;
  }

  @Test
  public void test4028() {
    coral.tests.JPFBenchmark.benchmark05(-2641.8931723134338,0,0 ) ;
  }

  @Test
  public void test4029() {
    coral.tests.JPFBenchmark.benchmark05(2.6469779601696886E-23,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test4030() {
    coral.tests.JPFBenchmark.benchmark05(27.0450350636889,74.9816711194255,18.174939200382354 ) ;
  }

  @Test
  public void test4031() {
    coral.tests.JPFBenchmark.benchmark05(-2723.573548359349,0,0 ) ;
  }

  @Test
  public void test4032() {
    coral.tests.JPFBenchmark.benchmark05(2.7549060228480897,54.344706190665335,-97.9964989541422 ) ;
  }

  @Test
  public void test4033() {
    coral.tests.JPFBenchmark.benchmark05(-2.7755575615628914E-17,-1.48329467648573,51.606681718704095 ) ;
  }

  @Test
  public void test4034() {
    coral.tests.JPFBenchmark.benchmark05(-2.7755575615628914E-17,-48.53291894111967,84.09661038901288 ) ;
  }

  @Test
  public void test4035() {
    coral.tests.JPFBenchmark.benchmark05(-2.7755575615628914E-17,-60.86774302338813,-1.5707963267948966 ) ;
  }

  @Test
  public void test4036() {
    coral.tests.JPFBenchmark.benchmark05(27.834469747384645,15.456557941573251,-68.68235897895325 ) ;
  }

  @Test
  public void test4037() {
    coral.tests.JPFBenchmark.benchmark05(27.873232435101556,95.19500934719707,-53.4978346533846 ) ;
  }

  @Test
  public void test4038() {
    coral.tests.JPFBenchmark.benchmark05(2.7915612643612593,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test4039() {
    coral.tests.JPFBenchmark.benchmark05(-27.962402976373824,70.1926612722252,-93.93371215317865 ) ;
  }

  @Test
  public void test4040() {
    coral.tests.JPFBenchmark.benchmark05(27.995195443128452,-61.886933749235396,-53.86124134578021 ) ;
  }

  @Test
  public void test4041() {
    coral.tests.JPFBenchmark.benchmark05(-28.047683339916148,85.15261238315065,-39.15721126915548 ) ;
  }

  @Test
  public void test4042() {
    coral.tests.JPFBenchmark.benchmark05(28.08591795368261,-74.43388304725815,-97.7337465008269 ) ;
  }

  @Test
  public void test4043() {
    coral.tests.JPFBenchmark.benchmark05(-28.25276731974003,36.44248241954199,72.17607791954305 ) ;
  }

  @Test
  public void test4044() {
    coral.tests.JPFBenchmark.benchmark05(-28.326730745666737,19.741434763413125,-19.743369236023 ) ;
  }

  @Test
  public void test4045() {
    coral.tests.JPFBenchmark.benchmark05(28.57077930931021,11.883906153876708,-43.65728430760745 ) ;
  }

  @Test
  public void test4046() {
    coral.tests.JPFBenchmark.benchmark05(-2.861126565992125E-15,-1.5707963267944278,-82.4815055750052 ) ;
  }

  @Test
  public void test4047() {
    coral.tests.JPFBenchmark.benchmark05(28.716304391312974,-13.832567038109161,77.02071731896442 ) ;
  }

  @Test
  public void test4048() {
    coral.tests.JPFBenchmark.benchmark05(-29.103565258297465,-61.75752370957204,39.70369813083968 ) ;
  }

  @Test
  public void test4049() {
    coral.tests.JPFBenchmark.benchmark05(-29.145845966633118,49.75065814079218,-34.2462735985856 ) ;
  }

  @Test
  public void test4050() {
    coral.tests.JPFBenchmark.benchmark05(-29.639797264252536,48.70076621325532,-69.23515152786068 ) ;
  }

  @Test
  public void test4051() {
    coral.tests.JPFBenchmark.benchmark05(-29.741746126117178,-91.70661301869825,-75.45632895439307 ) ;
  }

  @Test
  public void test4052() {
    coral.tests.JPFBenchmark.benchmark05(29.882345516448737,87.42904703929514,-89.66354101518887 ) ;
  }

  @Test
  public void test4053() {
    coral.tests.JPFBenchmark.benchmark05(29.925757772895082,-46.75212134040192,-74.04253739196838 ) ;
  }

  @Test
  public void test4054() {
    coral.tests.JPFBenchmark.benchmark05(-30.1904191563422,0,0 ) ;
  }

  @Test
  public void test4055() {
    coral.tests.JPFBenchmark.benchmark05(30.384647903189574,70.07176039329241,27.514509499684237 ) ;
  }

  @Test
  public void test4056() {
    coral.tests.JPFBenchmark.benchmark05(3.046177126455987,67.30822279618457,-72.33697808683495 ) ;
  }

  @Test
  public void test4057() {
    coral.tests.JPFBenchmark.benchmark05(-30.575942570278983,99.4387348377154,83.42394328257791 ) ;
  }

  @Test
  public void test4058() {
    coral.tests.JPFBenchmark.benchmark05(30.84736592603784,-29.094030513107867,94.69198598982672 ) ;
  }

  @Test
  public void test4059() {
    coral.tests.JPFBenchmark.benchmark05(-30.942879017773734,87.23183308340586,-38.49680861035416 ) ;
  }

  @Test
  public void test4060() {
    coral.tests.JPFBenchmark.benchmark05(-3.107066018360044,0,0 ) ;
  }

  @Test
  public void test4061() {
    coral.tests.JPFBenchmark.benchmark05(31.460031174346597,40.15130304846582,-6.121104658923812 ) ;
  }

  @Test
  public void test4062() {
    coral.tests.JPFBenchmark.benchmark05(31.67912870401088,-26.810528372072298,11.277300806079353 ) ;
  }

  @Test
  public void test4063() {
    coral.tests.JPFBenchmark.benchmark05(-31.697872577108924,-10.347135829758372,-42.62751338849036 ) ;
  }

  @Test
  public void test4064() {
    coral.tests.JPFBenchmark.benchmark05(31.988317530492907,41.83130462846677,75.9564269765263 ) ;
  }

  @Test
  public void test4065() {
    coral.tests.JPFBenchmark.benchmark05(32.212006414975235,-31.10349824120526,65.45859894310982 ) ;
  }

  @Test
  public void test4066() {
    coral.tests.JPFBenchmark.benchmark05(32.21925168719926,77.11604102422109,-86.11669337586265 ) ;
  }

  @Test
  public void test4067() {
    coral.tests.JPFBenchmark.benchmark05(32.41633320846938,-96.13956171185156,-28.415365879745153 ) ;
  }

  @Test
  public void test4068() {
    coral.tests.JPFBenchmark.benchmark05(-3.253967837003202,4.947562995453978,-80.66299317675916 ) ;
  }

  @Test
  public void test4069() {
    coral.tests.JPFBenchmark.benchmark05(32.9381667744008,49.10887073706667,6.011904489929904 ) ;
  }

  @Test
  public void test4070() {
    coral.tests.JPFBenchmark.benchmark05(33.19391968241979,73.09950005901806,56.77952294268823 ) ;
  }

  @Test
  public void test4071() {
    coral.tests.JPFBenchmark.benchmark05(33.19548088838823,-47.01769181672275,-44.07704469384981 ) ;
  }

  @Test
  public void test4072() {
    coral.tests.JPFBenchmark.benchmark05(-33.303122246342824,4.804803878411931,69.41549662166975 ) ;
  }

  @Test
  public void test4073() {
    coral.tests.JPFBenchmark.benchmark05(-33.43622826774674,96.35336305898835,74.28570333635412 ) ;
  }

  @Test
  public void test4074() {
    coral.tests.JPFBenchmark.benchmark05(-3.3472474220656206E-16,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4075() {
    coral.tests.JPFBenchmark.benchmark05(-3.350914989348266E-12,-123.5455839432966,-106.43424310998869 ) ;
  }

  @Test
  public void test4076() {
    coral.tests.JPFBenchmark.benchmark05(-33.53158819531106,67.06670558034398,22.308459985515043 ) ;
  }

  @Test
  public void test4077() {
    coral.tests.JPFBenchmark.benchmark05(-33.571973902307505,-78.77842168045919,-60.897807433974215 ) ;
  }

  @Test
  public void test4078() {
    coral.tests.JPFBenchmark.benchmark05(3.382425676604896,-34.3437110497715,37.188020444172395 ) ;
  }

  @Test
  public void test4079() {
    coral.tests.JPFBenchmark.benchmark05(-3.3881317890172014E-21,-66.40153845087485,-0.24041392140588347 ) ;
  }

  @Test
  public void test4080() {
    coral.tests.JPFBenchmark.benchmark05(-3.3881317890172014E-21,-92.6180500064732,50.388261708482915 ) ;
  }

  @Test
  public void test4081() {
    coral.tests.JPFBenchmark.benchmark05(-33.97559177580824,59.46113316308427,21.19197666811499 ) ;
  }

  @Test
  public void test4082() {
    coral.tests.JPFBenchmark.benchmark05(-34.0908484380233,22.697025959179058,-62.29672643879858 ) ;
  }

  @Test
  public void test4083() {
    coral.tests.JPFBenchmark.benchmark05(-34.09372551743846,-73.9614547013525,76.09023765408759 ) ;
  }

  @Test
  public void test4084() {
    coral.tests.JPFBenchmark.benchmark05(-3.469446951953614E-18,-28.992332774803145,19.588299420451666 ) ;
  }

  @Test
  public void test4085() {
    coral.tests.JPFBenchmark.benchmark05(-3.469446951953614E-18,-35.059970029002024,-42.69514749233643 ) ;
  }

  @Test
  public void test4086() {
    coral.tests.JPFBenchmark.benchmark05(3.469446951953614E-18,-3.5129876221869694,0.0 ) ;
  }

  @Test
  public void test4087() {
    coral.tests.JPFBenchmark.benchmark05(3.469446951953614E-18,-85.68822692078517,-52.16809199713347 ) ;
  }

  @Test
  public void test4088() {
    coral.tests.JPFBenchmark.benchmark05(-34.74288610087915,76.2281936635328,60.3365487590836 ) ;
  }

  @Test
  public void test4089() {
    coral.tests.JPFBenchmark.benchmark05(34.92231885011907,-29.820932940864893,96.92927077485072 ) ;
  }

  @Test
  public void test4090() {
    coral.tests.JPFBenchmark.benchmark05(-34.955016617132856,75.4432299209349,63.3831947399581 ) ;
  }

  @Test
  public void test4091() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-155.42359553835954,56.01530467574423 ) ;
  }

  @Test
  public void test4092() {
    coral.tests.JPFBenchmark.benchmark05(-35.57335375625303,0,0 ) ;
  }

  @Test
  public void test4093() {
    coral.tests.JPFBenchmark.benchmark05(35.69201416849472,6.242460639872263,29.612310554273392 ) ;
  }

  @Test
  public void test4094() {
    coral.tests.JPFBenchmark.benchmark05(-35.80991851096418,39.767138700135206,-0.2593337995117224 ) ;
  }

  @Test
  public void test4095() {
    coral.tests.JPFBenchmark.benchmark05(-36.016825502643115,2.4153094130725066,-38.09287074714251 ) ;
  }

  @Test
  public void test4096() {
    coral.tests.JPFBenchmark.benchmark05(36.232005284396735,54.56265409469424,44.034158569039704 ) ;
  }

  @Test
  public void test4097() {
    coral.tests.JPFBenchmark.benchmark05(36.50610981382064,47.34088345361448,-18.538421392744937 ) ;
  }

  @Test
  public void test4098() {
    coral.tests.JPFBenchmark.benchmark05(-36.74719186621345,0,0 ) ;
  }

  @Test
  public void test4099() {
    coral.tests.JPFBenchmark.benchmark05(-3.707220962236452E-15,-1.5707963267948966,33.56371343766696 ) ;
  }

  @Test
  public void test4100() {
    coral.tests.JPFBenchmark.benchmark05(-37.34373422003712,3.2319899267572367,18.84100663144497 ) ;
  }

  @Test
  public void test4101() {
    coral.tests.JPFBenchmark.benchmark05(-37.36675169845747,-47.79474041771656,4.727121961619289 ) ;
  }

  @Test
  public void test4102() {
    coral.tests.JPFBenchmark.benchmark05(-37.92928394235875,8.391253757385613,6.14357864968143 ) ;
  }

  @Test
  public void test4103() {
    coral.tests.JPFBenchmark.benchmark05(38.88810012625447,-43.64040035389325,12.002942214181147 ) ;
  }

  @Test
  public void test4104() {
    coral.tests.JPFBenchmark.benchmark05(38.89287000036842,-36.01741102065608,-13.900144575021471 ) ;
  }

  @Test
  public void test4105() {
    coral.tests.JPFBenchmark.benchmark05(-38.956521024769316,36.97802368033396,-37.7520017556243 ) ;
  }

  @Test
  public void test4106() {
    coral.tests.JPFBenchmark.benchmark05(-38.969660032449795,-57.60448427115614,9.289027336539405 ) ;
  }

  @Test
  public void test4107() {
    coral.tests.JPFBenchmark.benchmark05(39.07511370880846,-39.71624602976138,-43.00569820707316 ) ;
  }

  @Test
  public void test4108() {
    coral.tests.JPFBenchmark.benchmark05(3.944304526105059E-31,-60.76750029815173,63.02616222891953 ) ;
  }

  @Test
  public void test4109() {
    coral.tests.JPFBenchmark.benchmark05(-39.530920377289114,27.735784084644948,69.2758432273479 ) ;
  }

  @Test
  public void test4110() {
    coral.tests.JPFBenchmark.benchmark05(39.57532146195905,-78.39029922487674,-71.9597581321829 ) ;
  }

  @Test
  public void test4111() {
    coral.tests.JPFBenchmark.benchmark05(39.93408246301124,90.41363842593998,-71.79096713215787 ) ;
  }

  @Test
  public void test4112() {
    coral.tests.JPFBenchmark.benchmark05(-39.98272915814631,-5.25746838606797,-39.5789069931797 ) ;
  }

  @Test
  public void test4113() {
    coral.tests.JPFBenchmark.benchmark05(4.0007974021754675E-11,-0.06230677181111718,56.49547544597682 ) ;
  }

  @Test
  public void test4114() {
    coral.tests.JPFBenchmark.benchmark05(-4.0184352876737574E-16,-10.967957559907829,-9.282483645459322 ) ;
  }

  @Test
  public void test4115() {
    coral.tests.JPFBenchmark.benchmark05(-40.21025640528768,58.212030575923364,83.79965417631419 ) ;
  }

  @Test
  public void test4116() {
    coral.tests.JPFBenchmark.benchmark05(40.32684707292563,-35.45359843502145,-25.128595770264937 ) ;
  }

  @Test
  public void test4117() {
    coral.tests.JPFBenchmark.benchmark05(40.396893426100604,12.772144166329895,-99.55615599681565 ) ;
  }

  @Test
  public void test4118() {
    coral.tests.JPFBenchmark.benchmark05(-40.42459787429742,-88.15364355777027,60.320159312186206 ) ;
  }

  @Test
  public void test4119() {
    coral.tests.JPFBenchmark.benchmark05(-40.713858432842656,96.23195625214612,-0.40200921593174144 ) ;
  }

  @Test
  public void test4120() {
    coral.tests.JPFBenchmark.benchmark05(40.761968755023446,-95.98505515128497,-57.87240780693512 ) ;
  }

  @Test
  public void test4121() {
    coral.tests.JPFBenchmark.benchmark05(4.105278149523443,-32.537911865906864,-11.058466009316533 ) ;
  }

  @Test
  public void test4122() {
    coral.tests.JPFBenchmark.benchmark05(41.33386628887391,58.78269451027751,14.552994911975418 ) ;
  }

  @Test
  public void test4123() {
    coral.tests.JPFBenchmark.benchmark05(4.1359030627651384E-25,-1.013370569387313,31.999883578695954 ) ;
  }

  @Test
  public void test4124() {
    coral.tests.JPFBenchmark.benchmark05(-41.83434143975289,-62.51037899281322,59.465804720116495 ) ;
  }

  @Test
  public void test4125() {
    coral.tests.JPFBenchmark.benchmark05(-42.19020570251506,52.626497872774394,-22.05739924613701 ) ;
  }

  @Test
  public void test4126() {
    coral.tests.JPFBenchmark.benchmark05(4.2351647362715017E-22,-41.79793377629439,-57.30414839923362 ) ;
  }

  @Test
  public void test4127() {
    coral.tests.JPFBenchmark.benchmark05(-4.2351647362715017E-22,-78.79278308334676,78.77925603871206 ) ;
  }

  @Test
  public void test4128() {
    coral.tests.JPFBenchmark.benchmark05(42.78717816174762,67.86497466699777,48.240434842935485 ) ;
  }

  @Test
  public void test4129() {
    coral.tests.JPFBenchmark.benchmark05(-43.085925511004895,-84.9163458253905,28.603990883411797 ) ;
  }

  @Test
  public void test4130() {
    coral.tests.JPFBenchmark.benchmark05(43.086776103703585,51.320067145953175,87.01133706730445 ) ;
  }

  @Test
  public void test4131() {
    coral.tests.JPFBenchmark.benchmark05(-43.293256466824694,-80.0203236221509,-49.753312056739944 ) ;
  }

  @Test
  public void test4132() {
    coral.tests.JPFBenchmark.benchmark05(-4.3368086899420177E-19,-1.5707963267948966,25.19168283824311 ) ;
  }

  @Test
  public void test4133() {
    coral.tests.JPFBenchmark.benchmark05(-4.3368086899420177E-19,-1.5707963267948966,56.464445211768066 ) ;
  }

  @Test
  public void test4134() {
    coral.tests.JPFBenchmark.benchmark05(-4.3368086899420177E-19,-1.5707963267948966,-67.49883085094112 ) ;
  }

  @Test
  public void test4135() {
    coral.tests.JPFBenchmark.benchmark05(-43.639536014078885,-88.74390538604322,48.521583355972325 ) ;
  }

  @Test
  public void test4136() {
    coral.tests.JPFBenchmark.benchmark05(43.86219941458239,79.49434742486798,-66.57116477328509 ) ;
  }

  @Test
  public void test4137() {
    coral.tests.JPFBenchmark.benchmark05(-43.892054315677264,-1.0179918297184827,-7.91260746472264 ) ;
  }

  @Test
  public void test4138() {
    coral.tests.JPFBenchmark.benchmark05(44.23236997795368,86.70592285911655,-91.58734347519537 ) ;
  }

  @Test
  public void test4139() {
    coral.tests.JPFBenchmark.benchmark05(-44.4522717241721,78.52326775109253,-12.918762508410737 ) ;
  }

  @Test
  public void test4140() {
    coral.tests.JPFBenchmark.benchmark05(-44.837364751597384,24.410401330643936,-22.998105685633988 ) ;
  }

  @Test
  public void test4141() {
    coral.tests.JPFBenchmark.benchmark05(44.987000719923486,-95.68368428749083,-32.00065377504828 ) ;
  }

  @Test
  public void test4142() {
    coral.tests.JPFBenchmark.benchmark05(45.03292672614705,92.8002366298476,38.28847444336222 ) ;
  }

  @Test
  public void test4143() {
    coral.tests.JPFBenchmark.benchmark05(45.16172634099547,58.364064041498665,-1.906984005093861 ) ;
  }

  @Test
  public void test4144() {
    coral.tests.JPFBenchmark.benchmark05(-45.30120488676441,-11.76223695603457,-90.54392655838404 ) ;
  }

  @Test
  public void test4145() {
    coral.tests.JPFBenchmark.benchmark05(-46.064552261489624,53.114041100236875,63.64653154614061 ) ;
  }

  @Test
  public void test4146() {
    coral.tests.JPFBenchmark.benchmark05(-46.08745415838917,-69.8327739127385,98.49011880567014 ) ;
  }

  @Test
  public void test4147() {
    coral.tests.JPFBenchmark.benchmark05(46.094884419238184,-35.54770281890633,21.725456949824263 ) ;
  }

  @Test
  public void test4148() {
    coral.tests.JPFBenchmark.benchmark05(46.13234220295874,44.562009438273805,31.32149883001395 ) ;
  }

  @Test
  public void test4149() {
    coral.tests.JPFBenchmark.benchmark05(-46.210249720276494,58.631716388189034,-64.58755870381201 ) ;
  }

  @Test
  public void test4150() {
    coral.tests.JPFBenchmark.benchmark05(-46.340624913125225,69.10822679910024,41.35556625262629 ) ;
  }

  @Test
  public void test4151() {
    coral.tests.JPFBenchmark.benchmark05(-46.66616219509743,50.66251790444451,-23.087261101829924 ) ;
  }

  @Test
  public void test4152() {
    coral.tests.JPFBenchmark.benchmark05(-46.803553499280824,66.70785486421207,-51.75747078174384 ) ;
  }

  @Test
  public void test4153() {
    coral.tests.JPFBenchmark.benchmark05(-46.93912486692224,-81.075174037869,-5.583240471070511 ) ;
  }

  @Test
  public void test4154() {
    coral.tests.JPFBenchmark.benchmark05(-47.07773909691044,-68.74748411424854,68.64989971551131 ) ;
  }

  @Test
  public void test4155() {
    coral.tests.JPFBenchmark.benchmark05(47.428349779819456,75.4068673046605,-63.95315918147739 ) ;
  }

  @Test
  public void test4156() {
    coral.tests.JPFBenchmark.benchmark05(-47.68772170739921,88.7009556610326,-22.05429734471673 ) ;
  }

  @Test
  public void test4157() {
    coral.tests.JPFBenchmark.benchmark05(-48.00607191622748,-97.12148980280774,-23.36012690201403 ) ;
  }

  @Test
  public void test4158() {
    coral.tests.JPFBenchmark.benchmark05(48.26195204044902,41.09789661756167,-46.87999361006116 ) ;
  }

  @Test
  public void test4159() {
    coral.tests.JPFBenchmark.benchmark05(-48.40016797316502,-97.77782491790173,-77.8825915918334 ) ;
  }

  @Test
  public void test4160() {
    coral.tests.JPFBenchmark.benchmark05(48.44035469998232,-73.06953074600133,-56.96133500720959 ) ;
  }

  @Test
  public void test4161() {
    coral.tests.JPFBenchmark.benchmark05(-48.45978624245759,-63.97461692973465,76.97174892519044 ) ;
  }

  @Test
  public void test4162() {
    coral.tests.JPFBenchmark.benchmark05(-48.91805867850951,1.2517053978289,-72.82843597175348 ) ;
  }

  @Test
  public void test4163() {
    coral.tests.JPFBenchmark.benchmark05(-49.12330965619087,-46.92138608537395,65.29962392047403 ) ;
  }

  @Test
  public void test4164() {
    coral.tests.JPFBenchmark.benchmark05(-49.24898296750224,-43.971987910482156,62.78998004893478 ) ;
  }

  @Test
  public void test4165() {
    coral.tests.JPFBenchmark.benchmark05(4.930380657631324E-32,-85.48604306856706,-1.5707963267948966 ) ;
  }

  @Test
  public void test4166() {
    coral.tests.JPFBenchmark.benchmark05(-49.573904096574765,-25.855328751650106,-82.28838347236027 ) ;
  }

  @Test
  public void test4167() {
    coral.tests.JPFBenchmark.benchmark05(-4.992885391000286,61.10251870500943,-72.1350070382666 ) ;
  }

  @Test
  public void test4168() {
    coral.tests.JPFBenchmark.benchmark05(5.0052578148669085,-73.07334405051759,18.334709475300073 ) ;
  }

  @Test
  public void test4169() {
    coral.tests.JPFBenchmark.benchmark05(-50.23834964024025,24.631484860134464,-70.02556622991871 ) ;
  }

  @Test
  public void test4170() {
    coral.tests.JPFBenchmark.benchmark05(-50.293891497740084,50.87784726852112,-21.835081865506865 ) ;
  }

  @Test
  public void test4171() {
    coral.tests.JPFBenchmark.benchmark05(50.551667593921906,32.98043669212515,-78.89124080232754 ) ;
  }

  @Test
  public void test4172() {
    coral.tests.JPFBenchmark.benchmark05(-50.60588530320811,66.5306920767662,82.84510753600324 ) ;
  }

  @Test
  public void test4173() {
    coral.tests.JPFBenchmark.benchmark05(51.01451245163025,-20.0382285681264,-62.909904527835806 ) ;
  }

  @Test
  public void test4174() {
    coral.tests.JPFBenchmark.benchmark05(-51.02911293109776,32.78967174461309,-5.971272360450584 ) ;
  }

  @Test
  public void test4175() {
    coral.tests.JPFBenchmark.benchmark05(-51.22378312633402,-70.55303660518577,12.98194537269896 ) ;
  }

  @Test
  public void test4176() {
    coral.tests.JPFBenchmark.benchmark05(51.31215504999244,86.09465437133278,9.259227394727702 ) ;
  }

  @Test
  public void test4177() {
    coral.tests.JPFBenchmark.benchmark05(51.34345275444409,39.200387941370735,-76.80983053909486 ) ;
  }

  @Test
  public void test4178() {
    coral.tests.JPFBenchmark.benchmark05(5.169878828456423E-26,-29.761480794204047,-82.2023379631761 ) ;
  }

  @Test
  public void test4179() {
    coral.tests.JPFBenchmark.benchmark05(-5.190958169691511E-14,-1.5707963267948966,-82.2152670912236 ) ;
  }

  @Test
  public void test4180() {
    coral.tests.JPFBenchmark.benchmark05(-52.044182669546935,7.1737339930634505,-97.28706245337082 ) ;
  }

  @Test
  public void test4181() {
    coral.tests.JPFBenchmark.benchmark05(-52.09544719995187,-95.98649491308207,-49.65489081432259 ) ;
  }

  @Test
  public void test4182() {
    coral.tests.JPFBenchmark.benchmark05(-52.12668786278052,1.7486473594697145,-75.29669278439113 ) ;
  }

  @Test
  public void test4183() {
    coral.tests.JPFBenchmark.benchmark05(52.13622086183213,2.3597063464083163,94.81524610029436 ) ;
  }

  @Test
  public void test4184() {
    coral.tests.JPFBenchmark.benchmark05(52.208400183972316,7.806600495973214,-61.72117581498344 ) ;
  }

  @Test
  public void test4185() {
    coral.tests.JPFBenchmark.benchmark05(-52.402626837097934,98.4365017169875,-17.47835804589741 ) ;
  }

  @Test
  public void test4186() {
    coral.tests.JPFBenchmark.benchmark05(-5.2436742660902045E-14,-154.6767190791278,-43.8819139119003 ) ;
  }

  @Test
  public void test4187() {
    coral.tests.JPFBenchmark.benchmark05(52.72873478937905,-40.04293373573724,43.56497428328464 ) ;
  }

  @Test
  public void test4188() {
    coral.tests.JPFBenchmark.benchmark05(5.293955920339377E-23,-16.893213449995855,77.45561650287542 ) ;
  }

  @Test
  public void test4189() {
    coral.tests.JPFBenchmark.benchmark05(-53.41561670070219,-80.00342818235373,-62.16493789818589 ) ;
  }

  @Test
  public void test4190() {
    coral.tests.JPFBenchmark.benchmark05(-5.421010862427522E-20,-1.3156561869806023,9.594185935423852 ) ;
  }

  @Test
  public void test4191() {
    coral.tests.JPFBenchmark.benchmark05(5.421010862427522E-20,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4192() {
    coral.tests.JPFBenchmark.benchmark05(-5.421010862427522E-20,-29.226507221828882,-89.80893733480177 ) ;
  }

  @Test
  public void test4193() {
    coral.tests.JPFBenchmark.benchmark05(-54.599292216432225,-82.36849358129618,61.55373637113266 ) ;
  }

  @Test
  public void test4194() {
    coral.tests.JPFBenchmark.benchmark05(-54.85150661598806,-15.899132205349645,-59.603508855850265 ) ;
  }

  @Test
  public void test4195() {
    coral.tests.JPFBenchmark.benchmark05(5.490839316765732E-16,-104.98751353444072,2.997374419705338 ) ;
  }

  @Test
  public void test4196() {
    coral.tests.JPFBenchmark.benchmark05(-54.988672671687496,-20.62926151190902,26.132835918917323 ) ;
  }

  @Test
  public void test4197() {
    coral.tests.JPFBenchmark.benchmark05(55.42727188971986,-3.385009138053036,67.11764521334175 ) ;
  }

  @Test
  public void test4198() {
    coral.tests.JPFBenchmark.benchmark05(-5.551115123125783E-17,-0.9119936280269557,-48.77048228876297 ) ;
  }

  @Test
  public void test4199() {
    coral.tests.JPFBenchmark.benchmark05(5.551115123125783E-17,-1.5707963267948966,-0.0076281689978280574 ) ;
  }

  @Test
  public void test4200() {
    coral.tests.JPFBenchmark.benchmark05(-5.551115123125783E-17,-29.600086086595695,-4.3410872403955665 ) ;
  }

  @Test
  public void test4201() {
    coral.tests.JPFBenchmark.benchmark05(55.73360395105112,-69.95362198170272,-74.03280725727242 ) ;
  }

  @Test
  public void test4202() {
    coral.tests.JPFBenchmark.benchmark05(55.99235353997736,0,0 ) ;
  }

  @Test
  public void test4203() {
    coral.tests.JPFBenchmark.benchmark05(-56.436308185634964,-27.63534797239997,-76.14774453699602 ) ;
  }

  @Test
  public void test4204() {
    coral.tests.JPFBenchmark.benchmark05(-56.69453748927613,99.5785793466714,81.85589998313486 ) ;
  }

  @Test
  public void test4205() {
    coral.tests.JPFBenchmark.benchmark05(5.669621529153517,69.88735370331193,-2.5337381454820047 ) ;
  }

  @Test
  public void test4206() {
    coral.tests.JPFBenchmark.benchmark05(56.79959285132824,50.19719313185416,26.50871585520862 ) ;
  }

  @Test
  public void test4207() {
    coral.tests.JPFBenchmark.benchmark05(56.88767610286416,-57.41975923620068,-72.903731389272 ) ;
  }

  @Test
  public void test4208() {
    coral.tests.JPFBenchmark.benchmark05(5.702151074413948,32.173932481858316,-79.8836534223407 ) ;
  }

  @Test
  public void test4209() {
    coral.tests.JPFBenchmark.benchmark05(57.43120396501229,32.89679918830356,81.20642487943971 ) ;
  }

  @Test
  public void test4210() {
    coral.tests.JPFBenchmark.benchmark05(57.451523736956915,-20.551830597084802,-40.786838689406224 ) ;
  }

  @Test
  public void test4211() {
    coral.tests.JPFBenchmark.benchmark05(57.478665205195654,-35.35343055817894,68.4106635247332 ) ;
  }

  @Test
  public void test4212() {
    coral.tests.JPFBenchmark.benchmark05(58.317282910474944,44.70275367148517,-31.665219324828755 ) ;
  }

  @Test
  public void test4213() {
    coral.tests.JPFBenchmark.benchmark05(-58.49899472524363,71.10341478380698,73.30592267694942 ) ;
  }

  @Test
  public void test4214() {
    coral.tests.JPFBenchmark.benchmark05(-58.884582885524935,0,0 ) ;
  }

  @Test
  public void test4215() {
    coral.tests.JPFBenchmark.benchmark05(58.88707932166557,-99.65434346260176,87.10901202007116 ) ;
  }

  @Test
  public void test4216() {
    coral.tests.JPFBenchmark.benchmark05(-58.90239401312949,28.27073456914715,40.47617185238548 ) ;
  }

  @Test
  public void test4217() {
    coral.tests.JPFBenchmark.benchmark05(59.118059452015586,2.5308154923998814,-14.759385045384008 ) ;
  }

  @Test
  public void test4218() {
    coral.tests.JPFBenchmark.benchmark05(-59.308645357144286,10.894754466916766,-98.61045843764305 ) ;
  }

  @Test
  public void test4219() {
    coral.tests.JPFBenchmark.benchmark05(-59.3405896736285,59.6231611953734,-3.9370823215981545 ) ;
  }

  @Test
  public void test4220() {
    coral.tests.JPFBenchmark.benchmark05(59.41121050640271,-48.280311486856235,23.556783216496683 ) ;
  }

  @Test
  public void test4221() {
    coral.tests.JPFBenchmark.benchmark05(-59.43827766015546,76.94185496357667,-3.7200941096400726 ) ;
  }

  @Test
  public void test4222() {
    coral.tests.JPFBenchmark.benchmark05(59.617147697034824,-21.261857886092955,-39.83096178332135 ) ;
  }

  @Test
  public void test4223() {
    coral.tests.JPFBenchmark.benchmark05(-60.96676815580317,92.02957935751738,15.16417321824241 ) ;
  }

  @Test
  public void test4224() {
    coral.tests.JPFBenchmark.benchmark05(-61.02286762733024,12.609609359502798,34.709145343709224 ) ;
  }

  @Test
  public void test4225() {
    coral.tests.JPFBenchmark.benchmark05(-61.034496492978874,47.78056011979049,94.36097170908536 ) ;
  }

  @Test
  public void test4226() {
    coral.tests.JPFBenchmark.benchmark05(-61.12966498606487,13.315751375359113,19.49185255764634 ) ;
  }

  @Test
  public void test4227() {
    coral.tests.JPFBenchmark.benchmark05(-61.6194780078541,46.58838957994499,91.11910004332245 ) ;
  }

  @Test
  public void test4228() {
    coral.tests.JPFBenchmark.benchmark05(61.750514891160066,-12.118808358166987,-9.482874851907354 ) ;
  }

  @Test
  public void test4229() {
    coral.tests.JPFBenchmark.benchmark05(61.91921599204994,12.168800606054475,-72.75713937400002 ) ;
  }

  @Test
  public void test4230() {
    coral.tests.JPFBenchmark.benchmark05(61.96822033423379,-6.039145969016332,23.965901191708255 ) ;
  }

  @Test
  public void test4231() {
    coral.tests.JPFBenchmark.benchmark05(62.076026550145286,83.16681884884383,-22.772436085384328 ) ;
  }

  @Test
  public void test4232() {
    coral.tests.JPFBenchmark.benchmark05(-62.24185718491297,3.122708921752121,89.776796313445 ) ;
  }

  @Test
  public void test4233() {
    coral.tests.JPFBenchmark.benchmark05(62.609362996567995,-22.94040610000083,31.323908891578554 ) ;
  }

  @Test
  public void test4234() {
    coral.tests.JPFBenchmark.benchmark05(62.91041496944521,10.883331286121717,-12.174894408054413 ) ;
  }

  @Test
  public void test4235() {
    coral.tests.JPFBenchmark.benchmark05(-62.97531097577516,0,0 ) ;
  }

  @Test
  public void test4236() {
    coral.tests.JPFBenchmark.benchmark05(-6.317041158319045E-17,-1.5707963267948966,-77.59098994454841 ) ;
  }

  @Test
  public void test4237() {
    coral.tests.JPFBenchmark.benchmark05(63.23965988237211,-38.869631885263715,90.5382987772968 ) ;
  }

  @Test
  public void test4238() {
    coral.tests.JPFBenchmark.benchmark05(63.57084514743164,0,0 ) ;
  }

  @Test
  public void test4239() {
    coral.tests.JPFBenchmark.benchmark05(-63.647636047220615,-76.48680187922305,-25.17758435032742 ) ;
  }

  @Test
  public void test4240() {
    coral.tests.JPFBenchmark.benchmark05(63.91129762559527,-92.28760044786004,-7.08042986254047 ) ;
  }

  @Test
  public void test4241() {
    coral.tests.JPFBenchmark.benchmark05(-64.01958156152341,85.07184745878519,-19.01397211391229 ) ;
  }

  @Test
  public void test4242() {
    coral.tests.JPFBenchmark.benchmark05(6.4293894542964205,-1.5707963267948966,0.7082238248825732 ) ;
  }

  @Test
  public void test4243() {
    coral.tests.JPFBenchmark.benchmark05(-64.64689536867776,90.0704280020039,-58.49035107366496 ) ;
  }

  @Test
  public void test4244() {
    coral.tests.JPFBenchmark.benchmark05(-64.79400651662655,96.36436498287634,-79.33437589572173 ) ;
  }

  @Test
  public void test4245() {
    coral.tests.JPFBenchmark.benchmark05(65.34817357271749,76.1313097225908,26.277095301653674 ) ;
  }

  @Test
  public void test4246() {
    coral.tests.JPFBenchmark.benchmark05(-65.6441707145874,-42.91553396284109,-6.262237091017383 ) ;
  }

  @Test
  public void test4247() {
    coral.tests.JPFBenchmark.benchmark05(65.65401856742204,-93.67740737376585,16.18720264614946 ) ;
  }

  @Test
  public void test4248() {
    coral.tests.JPFBenchmark.benchmark05(6.578858461173435E-8,-1.5941744375771316E-4,-101.67521529133899 ) ;
  }

  @Test
  public void test4249() {
    coral.tests.JPFBenchmark.benchmark05(-65.84894246338118,-93.22373160940842,-67.6074927390542 ) ;
  }

  @Test
  public void test4250() {
    coral.tests.JPFBenchmark.benchmark05(6.608312025356321E-17,-1.4898836092287224,91.106186954104 ) ;
  }

  @Test
  public void test4251() {
    coral.tests.JPFBenchmark.benchmark05(-6.6174449004242214E-24,-66.05398634951416,-35.669852697500545 ) ;
  }

  @Test
  public void test4252() {
    coral.tests.JPFBenchmark.benchmark05(66.23387019896495,-59.82476185242302,-55.785487073017535 ) ;
  }

  @Test
  public void test4253() {
    coral.tests.JPFBenchmark.benchmark05(66.51786682160133,83.8832932390898,-53.382029349155815 ) ;
  }

  @Test
  public void test4254() {
    coral.tests.JPFBenchmark.benchmark05(-66.55080950654911,56.254615225872726,-27.3789574491977 ) ;
  }

  @Test
  public void test4255() {
    coral.tests.JPFBenchmark.benchmark05(-66.58791584699102,75.57053199971662,-13.516952224697135 ) ;
  }

  @Test
  public void test4256() {
    coral.tests.JPFBenchmark.benchmark05(-66.62285067994324,-69.30042265806236,-53.43256408339827 ) ;
  }

  @Test
  public void test4257() {
    coral.tests.JPFBenchmark.benchmark05(6.666839419465213,-256.035559265077,-43.98024124937551 ) ;
  }

  @Test
  public void test4258() {
    coral.tests.JPFBenchmark.benchmark05(66.69346354000993,-11.188157104002443,-48.449232388976824 ) ;
  }

  @Test
  public void test4259() {
    coral.tests.JPFBenchmark.benchmark05(66.73679974578823,60.91960230812492,67.5796679778901 ) ;
  }

  @Test
  public void test4260() {
    coral.tests.JPFBenchmark.benchmark05(-66.806103384445,-69.12389368630427,61.3234545396094 ) ;
  }

  @Test
  public void test4261() {
    coral.tests.JPFBenchmark.benchmark05(66.80726278722315,30.49517386163626,-76.19491655262705 ) ;
  }

  @Test
  public void test4262() {
    coral.tests.JPFBenchmark.benchmark05(66.83767138651925,62.79109506079567,-67.27269232214624 ) ;
  }

  @Test
  public void test4263() {
    coral.tests.JPFBenchmark.benchmark05(-67.25240930573406,44.38505020030391,34.33897546824696 ) ;
  }

  @Test
  public void test4264() {
    coral.tests.JPFBenchmark.benchmark05(67.46195274526175,-12.586274445592466,21.013702453100166 ) ;
  }

  @Test
  public void test4265() {
    coral.tests.JPFBenchmark.benchmark05(-6.776263578034403E-21,-1.4846509861004742,8.322244300956601 ) ;
  }

  @Test
  public void test4266() {
    coral.tests.JPFBenchmark.benchmark05(-6.776263578034403E-21,-1.5707963267948966,70.19821401023873 ) ;
  }

  @Test
  public void test4267() {
    coral.tests.JPFBenchmark.benchmark05(-6.776263578034403E-21,-1.5707963267948966,-78.20810355887222 ) ;
  }

  @Test
  public void test4268() {
    coral.tests.JPFBenchmark.benchmark05(6.777319685110094E-7,-1.5707675431823103,169.57308181170805 ) ;
  }

  @Test
  public void test4269() {
    coral.tests.JPFBenchmark.benchmark05(-68.12212323153169,-98.14403092449524,-89.89728459526731 ) ;
  }

  @Test
  public void test4270() {
    coral.tests.JPFBenchmark.benchmark05(-68.3832499497317,-0.313451233026953,0 ) ;
  }

  @Test
  public void test4271() {
    coral.tests.JPFBenchmark.benchmark05(6.849731514528568,-2.219556992744449E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test4272() {
    coral.tests.JPFBenchmark.benchmark05(68.57890535636457,-31.109379723109853,55.73709608662264 ) ;
  }

  @Test
  public void test4273() {
    coral.tests.JPFBenchmark.benchmark05(6.863885104698505,-73.65730267833266,-0.5815721359293999 ) ;
  }

  @Test
  public void test4274() {
    coral.tests.JPFBenchmark.benchmark05(68.93512765788216,-63.62545865630709,11.20365881206557 ) ;
  }

  @Test
  public void test4275() {
    coral.tests.JPFBenchmark.benchmark05(68.93580775636246,92.62439343153412,51.03207585391186 ) ;
  }

  @Test
  public void test4276() {
    coral.tests.JPFBenchmark.benchmark05(69.00112038715528,67.02202365018971,96.3796530919754 ) ;
  }

  @Test
  public void test4277() {
    coral.tests.JPFBenchmark.benchmark05(-6.901665486256775,-18.278089419276327,-68.07636930028272 ) ;
  }

  @Test
  public void test4278() {
    coral.tests.JPFBenchmark.benchmark05(69.10677470858039,16.52006000264032,6.250019240004505 ) ;
  }

  @Test
  public void test4279() {
    coral.tests.JPFBenchmark.benchmark05(-6.938893903907228E-18,-1.5707736655550544,-0.929598329350755 ) ;
  }

  @Test
  public void test4280() {
    coral.tests.JPFBenchmark.benchmark05(-6.938893903907228E-18,-41.26813437890999,1.5707963267948966 ) ;
  }

  @Test
  public void test4281() {
    coral.tests.JPFBenchmark.benchmark05(-6.938893903907228E-18,-61.062215525523804,-63.71363467149181 ) ;
  }

  @Test
  public void test4282() {
    coral.tests.JPFBenchmark.benchmark05(-69.81192712326423,6.902309583516612,-64.07744289070956 ) ;
  }

  @Test
  public void test4283() {
    coral.tests.JPFBenchmark.benchmark05(70.3320918828062,49.125100796175246,-82.35686819226993 ) ;
  }

  @Test
  public void test4284() {
    coral.tests.JPFBenchmark.benchmark05(-70.75800676019401,21.712326826986256,38.006027814821294 ) ;
  }

  @Test
  public void test4285() {
    coral.tests.JPFBenchmark.benchmark05(7.126861738944939,55.76649259241938,-48.57572357440534 ) ;
  }

  @Test
  public void test4286() {
    coral.tests.JPFBenchmark.benchmark05(-71.99272864725293,-87.69637632943895,31.789393382477385 ) ;
  }

  @Test
  public void test4287() {
    coral.tests.JPFBenchmark.benchmark05(-72.13334796596516,13.759112500292375,-54.88918961658111 ) ;
  }

  @Test
  public void test4288() {
    coral.tests.JPFBenchmark.benchmark05(72.15181391264875,-32.77699195080241,1.4133618758171735 ) ;
  }

  @Test
  public void test4289() {
    coral.tests.JPFBenchmark.benchmark05(72.42682314546525,-42.15643429252116,83.89611414663855 ) ;
  }

  @Test
  public void test4290() {
    coral.tests.JPFBenchmark.benchmark05(-72.47172025622007,-99.73525496670665,9.701966150576283 ) ;
  }

  @Test
  public void test4291() {
    coral.tests.JPFBenchmark.benchmark05(-72.59552189190612,68.87449409602954,-38.51443174531233 ) ;
  }

  @Test
  public void test4292() {
    coral.tests.JPFBenchmark.benchmark05(7.270144841006112,-47.79507061253333,-27.14508065669347 ) ;
  }

  @Test
  public void test4293() {
    coral.tests.JPFBenchmark.benchmark05(73.14384717001826,-25.437527499894713,-20.06078236376962 ) ;
  }

  @Test
  public void test4294() {
    coral.tests.JPFBenchmark.benchmark05(-73.23296206487802,-88.53378638046381,26.480025133074818 ) ;
  }

  @Test
  public void test4295() {
    coral.tests.JPFBenchmark.benchmark05(73.25090901251951,-40.83272114238399,-64.12215269256211 ) ;
  }

  @Test
  public void test4296() {
    coral.tests.JPFBenchmark.benchmark05(73.25256574178954,70.60278183642203,-56.771124989927266 ) ;
  }

  @Test
  public void test4297() {
    coral.tests.JPFBenchmark.benchmark05(-73.35935142484513,6.141150309189541,-46.752550887784054 ) ;
  }

  @Test
  public void test4298() {
    coral.tests.JPFBenchmark.benchmark05(-73.51126562272646,87.92519679564433,55.84357388286918 ) ;
  }

  @Test
  public void test4299() {
    coral.tests.JPFBenchmark.benchmark05(-73.60636244978701,57.60515096313529,28.347109182079265 ) ;
  }

  @Test
  public void test4300() {
    coral.tests.JPFBenchmark.benchmark05(73.67467521165781,30.41075617915908,-57.853608755065245 ) ;
  }

  @Test
  public void test4301() {
    coral.tests.JPFBenchmark.benchmark05(7.379642179921618,-60.70669848179839,-9.236797432445215 ) ;
  }

  @Test
  public void test4302() {
    coral.tests.JPFBenchmark.benchmark05(-74.36759521805175,14.757775913378751,-81.22063123061862 ) ;
  }

  @Test
  public void test4303() {
    coral.tests.JPFBenchmark.benchmark05(-74.68947914164983,77.52095525005339,-74.45274873740249 ) ;
  }

  @Test
  public void test4304() {
    coral.tests.JPFBenchmark.benchmark05(74.81193015585032,62.05958328767221,-28.781371727668173 ) ;
  }

  @Test
  public void test4305() {
    coral.tests.JPFBenchmark.benchmark05(-75.21451048600949,22.144042216974128,88.95891801482608 ) ;
  }

  @Test
  public void test4306() {
    coral.tests.JPFBenchmark.benchmark05(-75.55885585603399,-48.01891827522557,57.59395595188866 ) ;
  }

  @Test
  public void test4307() {
    coral.tests.JPFBenchmark.benchmark05(75.85779860465212,-61.33925283202348,94.6278648029255 ) ;
  }

  @Test
  public void test4308() {
    coral.tests.JPFBenchmark.benchmark05(75.93337900355564,73.93271664072842,-38.1053942025932 ) ;
  }

  @Test
  public void test4309() {
    coral.tests.JPFBenchmark.benchmark05(76.01816203757602,93.09836430002377,-94.94248803465123 ) ;
  }

  @Test
  public void test4310() {
    coral.tests.JPFBenchmark.benchmark05(-76.05250385394531,-33.3089893094827,-80.89398787677978 ) ;
  }

  @Test
  public void test4311() {
    coral.tests.JPFBenchmark.benchmark05(-76.78398263518068,-6.041890958458779,80.58924101211852 ) ;
  }

  @Test
  public void test4312() {
    coral.tests.JPFBenchmark.benchmark05(76.94493650246818,-31.1431995491742,-90.73274438698607 ) ;
  }

  @Test
  public void test4313() {
    coral.tests.JPFBenchmark.benchmark05(-77.6754799968719,26.896718725492434,29.138006537847247 ) ;
  }

  @Test
  public void test4314() {
    coral.tests.JPFBenchmark.benchmark05(-7.77571396036824E-16,-1.5707963267948966,19.520104407480133 ) ;
  }

  @Test
  public void test4315() {
    coral.tests.JPFBenchmark.benchmark05(77.88273552202952,-28.8306535975144,-38.247164444242074 ) ;
  }

  @Test
  public void test4316() {
    coral.tests.JPFBenchmark.benchmark05(-7.804191940141564,90.17934661764684,20.833894650162236 ) ;
  }

  @Test
  public void test4317() {
    coral.tests.JPFBenchmark.benchmark05(-78.0683308538441,-41.40983188308975,-83.51310653630102 ) ;
  }

  @Test
  public void test4318() {
    coral.tests.JPFBenchmark.benchmark05(-78.09491468641866,50.999722253330134,49.15621313425308 ) ;
  }

  @Test
  public void test4319() {
    coral.tests.JPFBenchmark.benchmark05(78.34303479800113,-41.02413420044415,12.139937973648827 ) ;
  }

  @Test
  public void test4320() {
    coral.tests.JPFBenchmark.benchmark05(78.41892588840525,64.30437279036289,-26.312446702736295 ) ;
  }

  @Test
  public void test4321() {
    coral.tests.JPFBenchmark.benchmark05(7.866712709150065,-22.7974393080723,-77.15784073902356 ) ;
  }

  @Test
  public void test4322() {
    coral.tests.JPFBenchmark.benchmark05(-78.79836242493836,-94.99431879040029,-58.04458856182 ) ;
  }

  @Test
  public void test4323() {
    coral.tests.JPFBenchmark.benchmark05(7.888609052210118E-31,-1.471062238196634,97.47323176619534 ) ;
  }

  @Test
  public void test4324() {
    coral.tests.JPFBenchmark.benchmark05(7.888609052210118E-31,-1.5707963267948966,10.644191254435142 ) ;
  }

  @Test
  public void test4325() {
    coral.tests.JPFBenchmark.benchmark05(-7.915319925768642,18.269011796296425,79.53902754914537 ) ;
  }

  @Test
  public void test4326() {
    coral.tests.JPFBenchmark.benchmark05(7.936460046607593,-8.844485594128045,-64.74623148417065 ) ;
  }

  @Test
  public void test4327() {
    coral.tests.JPFBenchmark.benchmark05(-79.54825931965892,67.66460946091942,74.80421031384071 ) ;
  }

  @Test
  public void test4328() {
    coral.tests.JPFBenchmark.benchmark05(-79.63608976348739,-27.810861664861946,-41.65507459746218 ) ;
  }

  @Test
  public void test4329() {
    coral.tests.JPFBenchmark.benchmark05(-7.965045272972306E-16,-1.5707963267948966,-81.7747719076682 ) ;
  }

  @Test
  public void test4330() {
    coral.tests.JPFBenchmark.benchmark05(79.72726736873042,-33.719946886133386,-84.72460780051472 ) ;
  }

  @Test
  public void test4331() {
    coral.tests.JPFBenchmark.benchmark05(-80.36118852023002,-69.51440499267467,-54.60518767977136 ) ;
  }

  @Test
  public void test4332() {
    coral.tests.JPFBenchmark.benchmark05(-8.077935669463161E-28,-41.7043494967275,67.4208175410092 ) ;
  }

  @Test
  public void test4333() {
    coral.tests.JPFBenchmark.benchmark05(-81.12022487889317,21.69945503950275,-24.155703847765736 ) ;
  }

  @Test
  public void test4334() {
    coral.tests.JPFBenchmark.benchmark05(-81.34795154374845,17.275771343046415,-44.61511266696962 ) ;
  }

  @Test
  public void test4335() {
    coral.tests.JPFBenchmark.benchmark05(81.43942721075945,-29.723396591641986,-24.65553050180351 ) ;
  }

  @Test
  public void test4336() {
    coral.tests.JPFBenchmark.benchmark05(8.168811360591533,43.78306673148461,-67.69156939317733 ) ;
  }

  @Test
  public void test4337() {
    coral.tests.JPFBenchmark.benchmark05(-82.04375022769241,-95.05544147963185,99.02654891137502 ) ;
  }

  @Test
  public void test4338() {
    coral.tests.JPFBenchmark.benchmark05(-82.37718738934001,-71.81400600624386,-54.754478354167865 ) ;
  }

  @Test
  public void test4339() {
    coral.tests.JPFBenchmark.benchmark05(82.40104257981497,-74.61303672836364,-55.40669350962051 ) ;
  }

  @Test
  public void test4340() {
    coral.tests.JPFBenchmark.benchmark05(82.58389775228946,-2.3405142221478314,-97.62825908011521 ) ;
  }

  @Test
  public void test4341() {
    coral.tests.JPFBenchmark.benchmark05(-82.6405138186418,-96.90125173015713,-66.15024308746035 ) ;
  }

  @Test
  public void test4342() {
    coral.tests.JPFBenchmark.benchmark05(-8.271806125530277E-25,-0.7206662570785738,-49.86806193113093 ) ;
  }

  @Test
  public void test4343() {
    coral.tests.JPFBenchmark.benchmark05(-83.26840072919074,47.723093343755096,-79.76198677660986 ) ;
  }

  @Test
  public void test4344() {
    coral.tests.JPFBenchmark.benchmark05(-8.340829805356872E-16,-85.22658032418903,-1.5164503305923802 ) ;
  }

  @Test
  public void test4345() {
    coral.tests.JPFBenchmark.benchmark05(-8.370164937803303E-17,-1.5707963267948966,-51.807965390406856 ) ;
  }

  @Test
  public void test4346() {
    coral.tests.JPFBenchmark.benchmark05(-83.79221055238004,-46.82408970297401,-73.3059568940212 ) ;
  }

  @Test
  public void test4347() {
    coral.tests.JPFBenchmark.benchmark05(83.81826212586901,-49.4773266777782,75.75790167420519 ) ;
  }

  @Test
  public void test4348() {
    coral.tests.JPFBenchmark.benchmark05(-84.3029822902551,-79.41395337313502,5.495106677000749 ) ;
  }

  @Test
  public void test4349() {
    coral.tests.JPFBenchmark.benchmark05(84.40571101755242,95.65783945839183,-96.65097755702783 ) ;
  }

  @Test
  public void test4350() {
    coral.tests.JPFBenchmark.benchmark05(-84.70013656559689,-37.62601843219644,57.77329714688432 ) ;
  }

  @Test
  public void test4351() {
    coral.tests.JPFBenchmark.benchmark05(8.470329472543003E-22,-1.1762496004530425,-20.891437369408592 ) ;
  }

  @Test
  public void test4352() {
    coral.tests.JPFBenchmark.benchmark05(8.470329472543003E-22,-1.5707963267948948,90.170497590546 ) ;
  }

  @Test
  public void test4353() {
    coral.tests.JPFBenchmark.benchmark05(-8.470329472543003E-22,-66.78925480602929,-35.982019799088846 ) ;
  }

  @Test
  public void test4354() {
    coral.tests.JPFBenchmark.benchmark05(-84.77368073587411,98.97064297664363,76.05948887934343 ) ;
  }

  @Test
  public void test4355() {
    coral.tests.JPFBenchmark.benchmark05(-84.78269127672237,-27.298638948023296,-58.05180253643838 ) ;
  }

  @Test
  public void test4356() {
    coral.tests.JPFBenchmark.benchmark05(-84.89922610249928,-93.92238941361224,-36.92773019865621 ) ;
  }

  @Test
  public void test4357() {
    coral.tests.JPFBenchmark.benchmark05(84.93357601706788,84.73900838562841,99.53183071580878 ) ;
  }

  @Test
  public void test4358() {
    coral.tests.JPFBenchmark.benchmark05(-85.10841177781224,40.31024222944524,-52.356629819841594 ) ;
  }

  @Test
  public void test4359() {
    coral.tests.JPFBenchmark.benchmark05(85.1206564374092,-18.882870652516814,-20.42594912019402 ) ;
  }

  @Test
  public void test4360() {
    coral.tests.JPFBenchmark.benchmark05(85.22184923647251,98.63021078443722,-98.69243348933998 ) ;
  }

  @Test
  public void test4361() {
    coral.tests.JPFBenchmark.benchmark05(85.33315145404313,58.17251610756796,80.62194057292166 ) ;
  }

  @Test
  public void test4362() {
    coral.tests.JPFBenchmark.benchmark05(85.6918321991204,-68.48211770899184,70.44308702077964 ) ;
  }

  @Test
  public void test4363() {
    coral.tests.JPFBenchmark.benchmark05(86.24531830283951,43.39561555177974,-10.635171918394676 ) ;
  }

  @Test
  public void test4364() {
    coral.tests.JPFBenchmark.benchmark05(86.56768278182,-39.685700526203085,76.04051679296506 ) ;
  }

  @Test
  public void test4365() {
    coral.tests.JPFBenchmark.benchmark05(-8.673617379884035E-19,-0.6590698060871937,1.5707963267948983 ) ;
  }

  @Test
  public void test4366() {
    coral.tests.JPFBenchmark.benchmark05(-8.673617379884035E-19,-1.4123866128227578,-100.0 ) ;
  }

  @Test
  public void test4367() {
    coral.tests.JPFBenchmark.benchmark05(-8.673617379884035E-19,-1.5707963267945573,75.76313638903548 ) ;
  }

  @Test
  public void test4368() {
    coral.tests.JPFBenchmark.benchmark05(8.673617379884035E-19,-1.5707963267948966,64.6938922995009 ) ;
  }

  @Test
  public void test4369() {
    coral.tests.JPFBenchmark.benchmark05(-8.673617379884035E-19,-79.0919535108166,1.3153133187653865 ) ;
  }

  @Test
  public void test4370() {
    coral.tests.JPFBenchmark.benchmark05(-8.673617379884035E-19,-97.74865763512469,-0.6209860248891573 ) ;
  }

  @Test
  public void test4371() {
    coral.tests.JPFBenchmark.benchmark05(-8.673617379884035E-19,-98.90430776885931,50.87548619262316 ) ;
  }

  @Test
  public void test4372() {
    coral.tests.JPFBenchmark.benchmark05(-87.36130133331439,-11.507780975639804,-98.61679718027541 ) ;
  }

  @Test
  public void test4373() {
    coral.tests.JPFBenchmark.benchmark05(-8.881784197001252E-16,-92.50683073695225,-91.18698935400147 ) ;
  }

  @Test
  public void test4374() {
    coral.tests.JPFBenchmark.benchmark05(-88.818815014885,59.38584656817795,-59.07394961747894 ) ;
  }

  @Test
  public void test4375() {
    coral.tests.JPFBenchmark.benchmark05(8.884247461352544,38.266373490045936,-32.918124085087186 ) ;
  }

  @Test
  public void test4376() {
    coral.tests.JPFBenchmark.benchmark05(89.50212376445882,59.09134341779111,-0.5322908266785191 ) ;
  }

  @Test
  public void test4377() {
    coral.tests.JPFBenchmark.benchmark05(-89.66497416909813,57.98971257396536,-97.238055799056 ) ;
  }

  @Test
  public void test4378() {
    coral.tests.JPFBenchmark.benchmark05(90.34484410913731,9.75155846202253,91.33830319914367 ) ;
  }

  @Test
  public void test4379() {
    coral.tests.JPFBenchmark.benchmark05(90.43629644117615,-72.8632817387711,-94.3214639269343 ) ;
  }

  @Test
  public void test4380() {
    coral.tests.JPFBenchmark.benchmark05(-90.93343801877924,18.950074816183758,4.33178293852707 ) ;
  }

  @Test
  public void test4381() {
    coral.tests.JPFBenchmark.benchmark05(-91.29773437355885,-66.77011339791541,-15.365058752970981 ) ;
  }

  @Test
  public void test4382() {
    coral.tests.JPFBenchmark.benchmark05(91.66608850871006,59.42197870645103,24.003816441986842 ) ;
  }

  @Test
  public void test4383() {
    coral.tests.JPFBenchmark.benchmark05(92.26817188228995,6.475480106022587,-71.90663024504458 ) ;
  }

  @Test
  public void test4384() {
    coral.tests.JPFBenchmark.benchmark05(-92.40793072642708,-31.33511035179066,-26.516814982488967 ) ;
  }

  @Test
  public void test4385() {
    coral.tests.JPFBenchmark.benchmark05(92.55703623796603,-99.49790606817903,-18.228979329383748 ) ;
  }

  @Test
  public void test4386() {
    coral.tests.JPFBenchmark.benchmark05(92.66907455204529,29.873659793389947,75.54540741526353 ) ;
  }

  @Test
  public void test4387() {
    coral.tests.JPFBenchmark.benchmark05(-92.72116481511745,43.567243841817486,27.494651924711874 ) ;
  }

  @Test
  public void test4388() {
    coral.tests.JPFBenchmark.benchmark05(-92.87989215089254,42.08003695320215,-44.5939103123266 ) ;
  }

  @Test
  public void test4389() {
    coral.tests.JPFBenchmark.benchmark05(-93.13735250524857,9.213302983733413,-5.447231361225761 ) ;
  }

  @Test
  public void test4390() {
    coral.tests.JPFBenchmark.benchmark05(93.14691614200058,86.71943946387256,21.282389118127583 ) ;
  }

  @Test
  public void test4391() {
    coral.tests.JPFBenchmark.benchmark05(-93.15090232997629,-45.829054290985205,63.54239673307305 ) ;
  }

  @Test
  public void test4392() {
    coral.tests.JPFBenchmark.benchmark05(-93.52004979544336,-58.08136983592451,35.5125823046985 ) ;
  }

  @Test
  public void test4393() {
    coral.tests.JPFBenchmark.benchmark05(-93.64317922090493,-48.21533284909234,94.22748014352968 ) ;
  }

  @Test
  public void test4394() {
    coral.tests.JPFBenchmark.benchmark05(94.10731224462006,82.10545725636922,-49.88459078807699 ) ;
  }

  @Test
  public void test4395() {
    coral.tests.JPFBenchmark.benchmark05(94.23741276265145,47.64240664065028,63.142040826176725 ) ;
  }

  @Test
  public void test4396() {
    coral.tests.JPFBenchmark.benchmark05(-94.5602381757569,68.71511521973858,16.772953653370436 ) ;
  }

  @Test
  public void test4397() {
    coral.tests.JPFBenchmark.benchmark05(-94.7204556309602,33.07621053258168,-26.144754939200126 ) ;
  }

  @Test
  public void test4398() {
    coral.tests.JPFBenchmark.benchmark05(-94.79744182905101,-5.274838339887438,31.50658480165268 ) ;
  }

  @Test
  public void test4399() {
    coral.tests.JPFBenchmark.benchmark05(94.87274176836152,95.69449120762243,39.7005150797508 ) ;
  }

  @Test
  public void test4400() {
    coral.tests.JPFBenchmark.benchmark05(-94.92268104328139,-29.496733781838074,-3.277466333682753 ) ;
  }

  @Test
  public void test4401() {
    coral.tests.JPFBenchmark.benchmark05(94.9901219047758,35.57452218557978,90.25641799008164 ) ;
  }

  @Test
  public void test4402() {
    coral.tests.JPFBenchmark.benchmark05(95.03969315418703,-98.39942458760245,-5.873767665299894 ) ;
  }

  @Test
  public void test4403() {
    coral.tests.JPFBenchmark.benchmark05(-95.3735338311935,15.72977925742751,-64.87514289410854 ) ;
  }

  @Test
  public void test4404() {
    coral.tests.JPFBenchmark.benchmark05(-95.53629800894188,81.99139083195695,-95.62498618090234 ) ;
  }

  @Test
  public void test4405() {
    coral.tests.JPFBenchmark.benchmark05(9.554184710060014,99.77472761810958,-14.539311668457586 ) ;
  }

  @Test
  public void test4406() {
    coral.tests.JPFBenchmark.benchmark05(-95.68027289310261,-15.773349126680287,-81.86195909774104 ) ;
  }

  @Test
  public void test4407() {
    coral.tests.JPFBenchmark.benchmark05(95.80319258515422,50.7608317445069,-98.48307244206995 ) ;
  }

  @Test
  public void test4408() {
    coral.tests.JPFBenchmark.benchmark05(-95.98390068531187,-30.409976455049033,33.10826355808331 ) ;
  }

  @Test
  public void test4409() {
    coral.tests.JPFBenchmark.benchmark05(96.7215626651844,-18.659647683860044,21.50576768596015 ) ;
  }

  @Test
  public void test4410() {
    coral.tests.JPFBenchmark.benchmark05(-96.97544875503932,-13.88490326186242,-53.07657511667965 ) ;
  }

  @Test
  public void test4411() {
    coral.tests.JPFBenchmark.benchmark05(97.74610350026322,-74.91970414349296,-58.596276426505 ) ;
  }

  @Test
  public void test4412() {
    coral.tests.JPFBenchmark.benchmark05(9.791014252473246,57.77051166308976,-11.988133991931704 ) ;
  }

  @Test
  public void test4413() {
    coral.tests.JPFBenchmark.benchmark05(-98.118250420443,56.86169777132204,36.72693576123004 ) ;
  }

  @Test
  public void test4414() {
    coral.tests.JPFBenchmark.benchmark05(-98.24844569324485,-61.7345028989895,-7.211060001023924 ) ;
  }

  @Test
  public void test4415() {
    coral.tests.JPFBenchmark.benchmark05(98.3135298404809,-65.78979545913276,85.20837834817914 ) ;
  }

  @Test
  public void test4416() {
    coral.tests.JPFBenchmark.benchmark05(98.44877303593893,56.515637741624204,-8.732333217154249 ) ;
  }

  @Test
  public void test4417() {
    coral.tests.JPFBenchmark.benchmark05(-98.50335312926681,0,0 ) ;
  }

  @Test
  public void test4418() {
    coral.tests.JPFBenchmark.benchmark05(-9.860761315262648E-32,0,0 ) ;
  }

  @Test
  public void test4419() {
    coral.tests.JPFBenchmark.benchmark05(-98.6844521555178,-99.01747478471773,77.72574565846034 ) ;
  }

  @Test
  public void test4420() {
    coral.tests.JPFBenchmark.benchmark05(98.72476072517873,-47.42635297980999,85.6339611016252 ) ;
  }

  @Test
  public void test4421() {
    coral.tests.JPFBenchmark.benchmark05(-98.81088683269658,61.29647590505721,50.60381427171848 ) ;
  }

  @Test
  public void test4422() {
    coral.tests.JPFBenchmark.benchmark05(9.88645140695452,-88.06737225352641,41.058388788465095 ) ;
  }

  @Test
  public void test4423() {
    coral.tests.JPFBenchmark.benchmark05(-98.91176563370077,47.59915758912862,1.2129487934278416 ) ;
  }

  @Test
  public void test4424() {
    coral.tests.JPFBenchmark.benchmark05(-99.26701647256921,-46.756537298212606,-70.74881530237542 ) ;
  }

  @Test
  public void test4425() {
    coral.tests.JPFBenchmark.benchmark05(-99.30986891600921,-24.15568597533455,-52.26991566030315 ) ;
  }

  @Test
  public void test4426() {
    coral.tests.JPFBenchmark.benchmark05(-9.945244295532248,-43.741574732923105,-52.65676611475787 ) ;
  }

  @Test
  public void test4427() {
    coral.tests.JPFBenchmark.benchmark05(99.82574797571783,-17.708423003005905,62.51403584683507 ) ;
  }

  @Test
  public void test4428() {
    coral.tests.JPFBenchmark.benchmark05(99.97962606553187,-89.88369251139446,-26.635985420510195 ) ;
  }

  @Test
  public void test4429() {
    coral.tests.JPFBenchmark.benchmark05(-99.99568981555709,64.53074768231983,-72.26979209936721 ) ;
  }

  @Test
  public void test4430() {
//    	UnSolved;
  }
}
